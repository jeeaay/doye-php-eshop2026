<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\exception\BizException;
use app\common\lib\RedisCache;
use app\common\model\SecurityEvent;
use app\common\model\SecurityIpRule;
use app\common\model\SecurityPathRule;
use app\common\support\AppContext;
use think\facade\Config;
use think\facade\Db;
use think\facade\Log;
use think\facade\Session;
use think\Request;

/**
 * 安全防护服务
 *
 * 同时承担两类职责：
 *   1. 运行时防护（{@see self::inspect()}）：黑名单拦截、白名单放行、客户端真实 IP 识别、
 *      探针路径识别、恶意 UA 封禁、自动加黑与事件落库。由全局中间件 SecurityGuard 调用。
 *   2. 后台/管理 API 数据操作：黑白名单、探针规则、拦截日志、防护设置。
 *
 * 配置读取顺序：config/security.php 的 defaults < setting 表 security.* 覆盖值。
 *
 * 运行时缓存（均走 Redis，避免每次请求查库）：
 *   - security:cache:settings  合并后的防护设置（10 分钟，任何设置保存后立即失效）
 *   - security:cache:rules     黑名单 + 白名单 + 探针规则（120 秒，规则写操作后立即失效）
 *   - security:cache:storage   数据表就绪标记（1 小时，避免重复 SHOW COLUMNS）
 * Redis 不可用时自动回源数据库/站点配置，功能不受影响。
 */
class SecurityService
{
    /** 合并后的安全设置缓存键 */
    private const CACHE_SETTINGS = 'security:cache:settings';

    /** 黑白名单 + 探针规则缓存键（一次 GET 取全部规则） */
    private const CACHE_RULES = 'security:cache:rules';

    /** 数据表就绪标记缓存键 */
    private const CACHE_STORAGE = 'security:cache:storage';

    /** 探针计数缓存键前缀 */
    private const PROBE_KEY = 'security:probe:';

    /** 事件去重缓存键前缀 */
    private const EVENT_KEY = 'security:event:';

    /** 设置缓存时长（秒） */
    private const SETTINGS_TTL = 600;

    /** 规则缓存时长（秒） */
    private const RULES_TTL = 120;

    /** 事件去重窗口（秒） */
    private const EVENT_DEDUPE_TTL = 60;

    /** 事件类型 => 展示文案 */
    private const EVENT_LABELS = [
        'blacklist_hit' => '黑名单拦截',
        'probe'         => '探针扫描',
        'bad_ua'        => '恶意 UA',
        'auto_block'    => '自动封禁',
    ];

    /** 来源 => 展示文案 */
    private const SOURCE_LABELS = [
        'manual'    => '手动',
        'auto_path' => '探针自动',
        'auto_ua'   => 'UA 自动',
    ];

    /** @var array|null 单次请求内的合并配置 */
    private static ?array $configCache = null;

    /** @var string|null 单次请求内解析出的客户端 IP */
    private static ?string $resolvedIp = null;

    /** @var array|null 单次请求内的黑白名单 + 探针规则 */
    private static ?array $runtimeRulesCache = null;

    /** @var bool|null 数据表是否就绪 */
    private static ?bool $storageReady = null;

    // ==================================================================
    // 运行时防护
    // ==================================================================

    /**
     * 检查当前请求，需要拦截时返回 403 响应，否则返回 null
     *
     * @param Request $request 当前请求
     * @return \think\Response|null
     */
    public function inspect(Request $request)
    {
        $settings = $this->settings();
        if (!$settings['enabled']) {
            return null;
        }

        $path = '/' . ltrim((string) $request->pathinfo(), '/');
        $app  = self::detectApp($path);
        if ($this->isBypassed($app, $path)) {
            return null;
        }

        $ip = self::clientIp($request);
        if ($ip === '' || $this->isWhitelisted($ip, $settings)) {
            return null;
        }

        $entry = $this->findBlacklist($ip);
        if ($entry !== null) {
            $this->recordEvent('blacklist_hit', '黑名单：' . ($entry['reason'] !== '' ? $entry['reason'] : $entry['ip']), $path, $ip, (int) $entry['hit_count']);
            return $this->blockedResponse($app, $settings['block_message']);
        }

        $userAgent = (string) $request->header('user-agent', '');

        if ($settings['ua_block']) {
            $badUa = $this->matchUserAgent($userAgent);
            if ($badUa !== null) {
                $this->recordEvent('bad_ua', '恶意 UA：' . $badUa, $path, $ip);
                $this->autoBlock($ip, 'auto_ua', 'malicious-ua:' . $badUa, $path, 1, $settings);
                return $this->blockedResponse($app, $settings['block_message']);
            }
        }

        $match = $this->matchSuspiciousPath($path);
        if ($match === null) {
            return null;
        }

        $count = $this->bumpProbeCounter($ip, $settings['window']);
        if ($count <= 0) {
            // Redis 不可用时只记录事件，不做自动封禁（避免无计数的误封）
            $this->recordEvent('probe', $match['reason'], $path, $ip);
            return null;
        }

        $this->recordEvent('probe', $match['reason'] . '（累计 ' . $count . ' 次）', $path, $ip, $count);
        if ($match['rule_id'] !== null && $count % 10 === 1) {
            $this->bumpPathRuleHit($match['rule_id']);
        }

        if ($settings['auto_block'] && $count >= $settings['threshold']) {
            $this->autoBlock($ip, 'auto_path', 'probe:' . $match['reason'], $path, $count, $settings);
            $this->recordEvent('auto_block', '探针命中 ' . $count . ' 次后自动封禁：' . $match['reason'], $path, $ip, $count);
            return $this->blockedResponse($app, $settings['block_message']);
        }

        return null;
    }

    /**
     * 解析客户端真实 IP
     *
     * 默认取 REMOTE_ADDR；开启信任代理后，满足以下任一条件才采信代理请求头：
     *   - REMOTE_ADDR 命中「可信代理地址」（可选配置）；
     *   - 请求携带「回源密钥头」且值与「回源密钥」一致（CDN 场景，防伪造）。
     * 采信后按可信请求头顺序读取（默认 CF-Connecting-IP / X-Real-IP / X-Forwarded-For，左起第一个合法地址）。
     *
     * @param Request|null $request 当前请求
     * @return string
     */
    public static function clientIp(?Request $request = null): string
    {
        if (self::$resolvedIp !== null && $request === null) {
            return self::$resolvedIp;
        }

        if ($request === null) {
            try {
                $request = app('request');
            } catch (\Throwable $e) {
                return '';
            }
        }

        $remote = trim((string) $request->server('REMOTE_ADDR', ''));
        if ($remote !== '' && filter_var($remote, FILTER_VALIDATE_IP) === false) {
            $remote = '';
        }

        $service  = new self();
        $settings = $service->settings();
        $resolved = $remote;

        if ($remote !== '' && $settings['trusted_proxy'] && $service->isTrustedSource($request, $remote)) {
            foreach ($service->trustedHeaderList() as $header) {
                $value = trim((string) $request->header((string) $header, ''));
                if ($value === '') {
                    continue;
                }
                $candidate = self::firstValidIp($value);
                if ($candidate !== '') {
                    $resolved = $candidate;
                    break;
                }
            }
        }

        if ($request === null) {
            self::$resolvedIp = $resolved;
        } else {
            // 同一次请求内后续调用（后台页面展示当前 IP）复用第一次解析结果
            self::$resolvedIp = self::$resolvedIp ?? $resolved;
        }

        return $resolved;
    }

    /**
     * 合并后的安全设置（config/security.php defaults + setting 表覆盖）
     *
     * @return array
     */
    public function settings(): array
    {
        if (self::$configCache !== null) {
            return self::$configCache;
        }

        // 先读 Redis：正常情况下每次请求只有 1 次 GET，不碰文件缓存与数据库
        $cached = null;
        try {
            $cached = RedisCache::get(self::CACHE_SETTINGS);
        } catch (\Throwable $e) {
            $cached = null;
        }

        if (is_array($cached) && isset($cached['enabled'])) {
            return self::$configCache = $this->normalizeSettings($cached);
        }

        $settings = $this->normalizeSettings($this->loadSettings());
        try {
            // 加 0-60 秒抖动，避免多台机器同时过期后一起回源
            RedisCache::set(self::CACHE_SETTINGS, $settings, self::SETTINGS_TTL + random_int(0, 60));
        } catch (\Throwable $e) {
            // Redis 不可用时退回 site_config（文件缓存 / 数据库）
        }

        return self::$configCache = $settings;
    }

    /**
     * 从 config/security.php 默认值 + setting 表覆盖值读取原始设置
     *
     * @return array
     */
    private function loadSettings(): array
    {
        $defaults = (array) Config::get('security.defaults', []);
        $saved    = [];
        try {
            $saved = (array) site_config('security', []);
        } catch (\Throwable $e) {
            $saved = [];
        }

        return array_merge($defaults, array_filter($saved, static function ($value) {
            return $value !== null;
        }));
    }

    /**
     * 把设置值统一转换为运行时类型
     *
     * @param array $merged 原始设置
     * @return array
     */
    private function normalizeSettings(array $merged): array
    {
        return [
            'enabled'              => self::toBool($merged['enabled'] ?? true),
            'auto_block'           => self::toBool($merged['auto_block'] ?? false),
            'ua_block'             => self::toBool($merged['ua_block'] ?? false),
            'log_enabled'          => self::toBool($merged['log_enabled'] ?? true),
            'threshold'            => max(1, (int) ($merged['threshold'] ?? 5)),
            'window'               => max(60, (int) ($merged['window'] ?? 86400)),
            'block_ttl'            => max(0, (int) ($merged['block_ttl'] ?? 86400)),
            'trusted_proxy'        => self::toBool($merged['trusted_proxy'] ?? false),
            'trusted_proxies'      => trim((string) ($merged['trusted_proxies'] ?? '')),
            'proxy_secret_header'  => self::normalizeHeaderName((string) ($merged['proxy_secret_header'] ?? ''))
                ?: self::normalizeHeaderName((string) Config::get('security.defaults.proxy_secret_header', 'cdn-src-sec')),
            'proxy_secret'         => trim((string) ($merged['proxy_secret'] ?? '')),
            'trusted_headers'      => trim((string) ($merged['trusted_headers'] ?? '')),
            'extra_whitelist'      => trim((string) ($merged['extra_whitelist'] ?? '')),
            'event_retention_days' => max(1, (int) ($merged['event_retention_days'] ?? 30)),
            'block_message'        => trim((string) ($merged['block_message'] ?? '')) ?: 'Your IP has been blocked due to suspicious activity.',
        ];
    }

    /**
     * 读取菜单/页面展示用设置（含可编辑字段的展示值）
     *
     * @return array
     */
    public function settingsForForm(): array
    {
        $settings = $this->settings();
        // 后台展示「实际生效」的请求头顺序：未保存自定义值时回退 config/security.php 的默认值
        $settings['trusted_headers'] = implode("\n", $this->trustedHeaderList());

        return $settings;
    }

    /**
     * 保存安全设置
     *
     * @param array $input 表单数据（键名不带 security. 前缀）
     * @return void
     * @throws BizException 校验失败
     */
    public function saveSettings(array $input): void
    {
        $threshold = (int) ($input['threshold'] ?? 5);
        if ($threshold < 1 || $threshold > 1000) {
            throw new BizException('自动封禁阈值需在 1 - 1000 之间');
        }

        $window = (int) ($input['window'] ?? 86400);
        if ($window < 60 || $window > 2592000) {
            throw new BizException('统计窗口需在 60 - 2592000 秒之间');
        }

        $ttl = (int) ($input['block_ttl'] ?? 86400);
        if ($ttl < 0 || $ttl > 31536000) {
            throw new BizException('自动封禁时长需在 0 - 31536000 秒之间（0 表示长期）');
        }

        $retention = (int) ($input['event_retention_days'] ?? 30);
        if ($retention < 1 || $retention > 3650) {
            throw new BizException('拦截日志保留天数需在 1 - 3650 之间');
        }

        $trustedProxies = $this->normalizeIpList((string) ($input['trusted_proxies'] ?? ''), '可信代理地址');
        $extraWhitelist = $this->normalizeIpList((string) ($input['extra_whitelist'] ?? ''), '额外放行地址');
        $trustedHeaders = $this->normalizeHeaderList((string) ($input['trusted_headers'] ?? ''));

        $proxySecretHeader = self::normalizeHeaderName((string) ($input['proxy_secret_header'] ?? ''));
        $proxySecret       = trim((string) ($input['proxy_secret'] ?? ''));

        if (!empty($input['trusted_proxy'])) {
            if ($proxySecret === '') {
                throw new BizException('开启反向代理识别前，请先填写回源密钥（CDN 回源请求携带的密钥）');
            }
            if ($proxySecretHeader === '') {
                throw new BizException('回源密钥头名称不正确');
            }
        }

        $values = [
            'security.enabled'              => !empty($input['enabled']),
            'security.auto_block'           => !empty($input['auto_block']),
            'security.ua_block'             => !empty($input['ua_block']),
            'security.log_enabled'          => !empty($input['log_enabled']),
            'security.threshold'            => (string) $threshold,
            'security.window'               => (string) $window,
            'security.block_ttl'            => (string) $ttl,
            'security.trusted_proxy'        => !empty($input['trusted_proxy']),
            'security.trusted_proxies'      => $trustedProxies,
            'security.proxy_secret_header'  => mb_substr($proxySecretHeader, 0, 64),
            'security.proxy_secret'         => mb_substr($proxySecret, 0, 255),
            'security.trusted_headers'      => $trustedHeaders,
            'security.extra_whitelist'      => $extraWhitelist,
            'security.event_retention_days' => (string) $retention,
            'security.block_message'        => mb_substr(trim((string) ($input['block_message'] ?? '')), 0, 255),
        ];

        (new SettingService())->save('security', $values);

        self::$configCache = null;
        self::$resolvedIp = null;
        $this->refreshCache();
    }

    /**
     * 刷新运行时缓存（后台写操作后调用）
     *
     * @return void
     */
    public function refreshCache(): void
    {
        RedisCache::forget(self::CACHE_RULES);
        self::flushSettingsCache();

        self::$runtimeRulesCache = null;
    }

    /**
     * 仅清空安全设置缓存
     *
     * 由 SettingService::flush() 调用，保证无论从安全设置页、管理 API 还是
     * 通用设置接口修改 security.*，下一次请求都会重新读取。
     *
     * @return void
     */
    public static function flushSettingsCache(): void
    {
        RedisCache::forget(self::CACHE_SETTINGS);
        self::$configCache = null;
        self::$resolvedIp = null;
    }

    /**
     * 数据表是否已创建（未执行迁移时后台给出提示而不是 500）
     *
     * @return bool
     */
    public function storageReady(): bool
    {
        if (self::$storageReady !== null) {
            return self::$storageReady;
        }

        // 已确认过表结构时直接用 Redis 标记，避免每次都 SHOW FULL COLUMNS
        try {
            if (RedisCache::get(self::CACHE_STORAGE)) {
                return self::$storageReady = true;
            }
        } catch (\Throwable $e) {
            // Redis 不可用时继续实际探测
        }

        try {
            $connection = (string) config('database.default', 'mysql');
            $prefix     = (string) config('database.connections.' . $connection . '.prefix', '');

            // 用原生 SELECT 1 探测，避免 ORM 触发 SHOW FULL COLUMNS
            foreach (['security_ip_rule', 'security_path_rule', 'security_event'] as $table) {
                Db::query('SELECT 1 FROM `' . $prefix . $table . '` LIMIT 1');
            }

            self::$storageReady = true;
            try {
                RedisCache::set(self::CACHE_STORAGE, 1, 3600);
            } catch (\Throwable $e) {
                // 标记写入失败不影响本次判断
            }
        } catch (\Throwable $e) {
            self::$storageReady = false;
            Log::warning('[security] storage check failed: ' . $e->getMessage());
        }

        return self::$storageReady;
    }

    // ==================================================================
    // 黑白名单与规则数据
    // ==================================================================

    /**
     * 黑白名单列表（分页）
     *
     * @param array $filters 支持 list_type / keyword / status
     * @param int   $page    页码
     * @param int   $size    每页数量
     * @return array{list:array,total:int,page:int,page_size:int,pager:\think\Paginator}
     */
    public function ipRuleList(array $filters, int $page = 1, int $size = 20): array
    {
        $size = max(1, min($size, 100));
        if (!$this->storageReady()) {
            return ['list' => [], 'total' => 0, 'page' => 1, 'page_size' => $size, 'pager' => null];
        }

        $listType = $this->normalizeListType((string) ($filters['list_type'] ?? 'blacklist'));
        $query    = SecurityIpRule::where('list_type', $listType);

        $keyword = trim((string) ($filters['keyword'] ?? ''));
        if ($keyword !== '') {
            $query->where(function ($q) use ($keyword) {
                $q->whereLike('ip', '%' . $keyword . '%')
                    ->whereOr('reason', 'like', '%' . $keyword . '%')
                    ->whereOr('remark', 'like', '%' . $keyword . '%')
                    ->whereOr('last_uri', 'like', '%' . $keyword . '%');
            });
        }

        $status = $filters['status'] ?? '';
        if ($status !== '' && $status !== null) {
            $query->where('status', (int) $status);
        }

        $pager = $query->order('id', 'desc')->paginate([
            'list_rows' => max(1, min($size, 100)),
            'page'      => max(1, $page),
            'query'     => ['tab' => $listType, 'keyword' => $keyword, 'status' => $status],
        ]);

        $list = [];
        foreach ($pager->items() as $row) {
            $list[] = $this->formatIpRow($row);
        }

        return [
            'list'      => $list,
            'total'     => (int) $pager->total(),
            'page'      => (int) $pager->currentPage(),
            'page_size' => (int) $pager->listRows(),
            'pager'     => $pager,
        ];
    }

    /**
     * 新增或修改黑白名单
     *
     * @param array    $data 表单数据
     * @param int|null $id   为 null 时新增
     * @return array 保存后的行
     * @throws BizException 校验失败
     */
    public function saveIpRule(array $data, ?int $id = null): array
    {
        $this->assertStorageReady();

        $listType = $this->normalizeListType((string) ($data['list_type'] ?? 'blacklist'));
        $ip       = $this->normalizeIpRule((string) ($data['ip'] ?? ''));
        $reason   = mb_substr(trim((string) ($data['reason'] ?? '')), 0, 255);
        $remark   = mb_substr(trim((string) ($data['remark'] ?? '')), 0, 255);
        $status   = (int) ($data['status'] ?? 1) === 1 ? 1 : 0;
        $expire   = $this->normalizeExpireTime((string) ($data['expire_time'] ?? ''));

        if ($listType === 'blacklist' && $this->isWhitelisted($ip)) {
            throw new BizException('该地址已命中白名单（白名单优先），加入黑名单不会生效');
        }

        $duplicate = SecurityIpRule::where('list_type', $listType)->where('ip', $ip)->where('id', '<>', $id ?? 0)->find();
        if ($duplicate) {
            throw new BizException('该地址已在' . ($listType === 'blacklist' ? '黑名单' : '白名单') . '中');
        }

        $operator = AppContext::getAdminUsername() ?: 'system';

        if ($id !== null) {
            $row = SecurityIpRule::find($id);
            if (!$row) {
                throw new BizException('记录不存在');
            }
            $row->list_type   = $listType;
            $row->ip          = $ip;
            $row->reason      = $reason;
            $row->remark      = $remark;
            $row->status      = $status;
            $row->expire_time = $expire;
            $row->updated_by  = $operator;
            $row->save();
        } else {
            $row = SecurityIpRule::create([
                'list_type'   => $listType,
                'ip'          => $ip,
                'source'      => 'manual',
                'reason'      => $reason !== '' ? $reason : 'manual',
                'status'      => $status,
                'expire_time' => $expire,
                'hit_count'   => 0,
                'last_uri'    => '',
                'remark'      => $remark,
                'created_by'  => $operator,
                'updated_by'  => $operator,
            ]);
        }

        $this->refreshCache();

        return $this->formatIpRow($row);
    }

    /**
     * 删除黑白名单（批量）
     *
     * @param array $ids 记录 ID
     * @return int 删除条数
     * @throws BizException ID 为空
     */
    public function deleteIpRules(array $ids): int
    {
        $this->assertStorageReady();

        $ids = $this->normalizeIds($ids);
        if (empty($ids)) {
            throw new BizException('请选择要删除的记录');
        }

        $count = (int) SecurityIpRule::whereIn('id', $ids)->delete();
        $this->refreshCache();

        return $count;
    }

    /**
     * 启用/停用黑白名单
     *
     * @param int $id     记录 ID
     * @param int $status 1 启用 / 0 停用
     * @return void
     * @throws BizException 记录不存在
     */
    public function setIpRuleStatus(int $id, int $status): void
    {
        $this->assertStorageReady();

        $row = SecurityIpRule::find($id);
        if (!$row) {
            throw new BizException('记录不存在');
        }
        $row->status     = $status === 1 ? 1 : 0;
        $row->updated_by = AppContext::getAdminUsername() ?: 'system';
        $row->save();

        $this->refreshCache();
    }

    /**
     * 探针规则列表（分页）
     *
     * @param array $filters 支持 keyword / status
     * @param int   $page    页码
     * @param int   $size    每页数量
     * @return array
     */
    public function pathRuleList(array $filters, int $page = 1, int $size = 20): array
    {
        $size = max(1, min($size, 100));
        if (!$this->storageReady()) {
            return ['list' => [], 'total' => 0, 'page' => 1, 'page_size' => $size, 'pager' => null];
        }

        $query = SecurityPathRule::order('id', 'desc');

        $keyword = trim((string) ($filters['keyword'] ?? ''));
        if ($keyword !== '') {
            $query->where(function ($q) use ($keyword) {
                $q->whereLike('name', '%' . $keyword . '%')
                    ->whereOr('pattern', 'like', '%' . $keyword . '%')
                    ->whereOr('remark', 'like', '%' . $keyword . '%');
            });
        }

        $status = $filters['status'] ?? '';
        if ($status !== '' && $status !== null) {
            $query->where('status', (int) $status);
        }

        $pager = $query->paginate([
            'list_rows' => max(1, min($size, 100)),
            'page'      => max(1, $page),
            'query'     => ['tab' => 'path-rules', 'keyword' => $keyword, 'status' => $status],
        ]);

        $list = [];
        foreach ($pager->items() as $row) {
            $list[] = $this->formatPathRow($row);
        }

        return [
            'list'      => $list,
            'total'     => (int) $pager->total(),
            'page'      => (int) $pager->currentPage(),
            'page_size' => (int) $pager->listRows(),
            'pager'     => $pager,
        ];
    }

    /**
     * 新增或修改探针规则
     *
     * @param array    $data 表单数据
     * @param int|null $id   为 null 时新增
     * @return array
     * @throws BizException 校验失败
     */
    public function savePathRule(array $data, ?int $id = null): array
    {
        $this->assertStorageReady();

        $name      = trim((string) ($data['name'] ?? ''));
        $pattern   = trim((string) ($data['pattern'] ?? ''));
        $matchType = (string) ($data['match_type'] ?? 'contains');
        $remark    = mb_substr(trim((string) ($data['remark'] ?? '')), 0, 255);
        $status    = (int) ($data['status'] ?? 1) === 1 ? 1 : 0;

        if ($name === '') {
            throw new BizException('规则名称不能为空');
        }
        if ($pattern === '') {
            throw new BizException('规则内容不能为空');
        }
        if (!in_array($matchType, ['exact', 'prefix', 'contains', 'regex'], true)) {
            throw new BizException('匹配方式不正确');
        }
        if ($matchType === 'regex' && @preg_match($pattern, '') === false) {
            throw new BizException('正则表达式不合法');
        }

        $operator = AppContext::getAdminUsername() ?: 'system';

        if ($id !== null) {
            $row = SecurityPathRule::find($id);
            if (!$row) {
                throw new BizException('规则不存在');
            }
            $row->name       = $name;
            $row->match_type = $matchType;
            $row->pattern    = $pattern;
            $row->remark     = $remark;
            $row->status     = $status;
            $row->updated_by = $operator;
            $row->save();
        } else {
            $row = SecurityPathRule::create([
                'name'       => $name,
                'match_type' => $matchType,
                'pattern'    => $pattern,
                'risk_level' => 'high',
                'status'     => $status,
                'hit_count'  => 0,
                'remark'     => $remark,
                'created_by' => $operator,
                'updated_by' => $operator,
            ]);
        }

        $this->refreshCache();

        return $this->formatPathRow($row);
    }

    /**
     * 删除探针规则（批量）
     *
     * @param array $ids 规则 ID
     * @return int
     * @throws BizException ID 为空
     */
    public function deletePathRules(array $ids): int
    {
        $this->assertStorageReady();

        $ids = $this->normalizeIds($ids);
        if (empty($ids)) {
            throw new BizException('请选择要删除的规则');
        }

        $count = (int) SecurityPathRule::whereIn('id', $ids)->delete();
        $this->refreshCache();

        return $count;
    }

    /**
     * 启用/停用探针规则
     *
     * @param int $id     规则 ID
     * @param int $status 1 启用 / 0 停用
     * @return void
     * @throws BizException 规则不存在
     */
    public function setPathRuleStatus(int $id, int $status): void
    {
        $this->assertStorageReady();

        $row = SecurityPathRule::find($id);
        if (!$row) {
            throw new BizException('规则不存在');
        }
        $row->status     = $status === 1 ? 1 : 0;
        $row->updated_by = AppContext::getAdminUsername() ?: 'system';
        $row->save();

        $this->refreshCache();
    }

    /**
     * 拦截/探针事件列表（分页）
     *
     * @param array $filters 支持 ip / event_type / keyword
     * @param int   $page    页码
     * @param int   $size    每页数量
     * @return array
     */
    public function eventList(array $filters, int $page = 1, int $size = 30): array
    {
        $size = max(1, min($size, 100));
        if (!$this->storageReady()) {
            return ['list' => [], 'total' => 0, 'page' => 1, 'page_size' => $size, 'pager' => null];
        }

        $query = SecurityEvent::order('id', 'desc');

        $ip = trim((string) ($filters['ip'] ?? ''));
        if ($ip !== '') {
            $query->whereLike('ip', '%' . $ip . '%');
        }

        $eventType = trim((string) ($filters['event_type'] ?? ''));
        if ($eventType !== '' && isset(self::EVENT_LABELS[$eventType])) {
            $query->where('event_type', $eventType);
        }

        $keyword = trim((string) ($filters['keyword'] ?? ''));
        if ($keyword !== '') {
            $query->where(function ($q) use ($keyword) {
                $q->whereLike('path', '%' . $keyword . '%')
                    ->whereOr('reason', 'like', '%' . $keyword . '%')
                    ->whereOr('user_agent', 'like', '%' . $keyword . '%');
            });
        }

        $pager = $query->paginate([
            'list_rows' => max(1, min($size, 100)),
            'page'      => max(1, $page),
            'query'     => ['tab' => 'events', 'ip' => $ip, 'event_type' => $eventType, 'keyword' => $keyword],
        ]);

        $list = [];
        foreach ($pager->items() as $row) {
            $list[] = $this->formatEventRow($row);
        }

        return [
            'list'      => $list,
            'total'     => (int) $pager->total(),
            'page'      => (int) $pager->currentPage(),
            'page_size' => (int) $pager->listRows(),
            'pager'     => $pager,
        ];
    }

    /**
     * 清理拦截日志
     *
     * @param int $days 0 表示清空全部，否则删除早于 N 天的记录
     * @return int 删除条数
     */
    public function clearEvents(int $days = 0): int
    {
        if (!$this->storageReady()) {
            return 0;
        }

        $query = SecurityEvent::where('id', '>', 0);
        if ($days > 0) {
            $query->where('create_time', '<', date('Y-m-d H:i:s', time() - $days * 86400));
        }

        return (int) $query->delete();
    }

    /**
     * 概览统计
     *
     * @return array
     */
    public function overview(): array
    {
        $empty = [
            'ready'           => false,
            'blacklist'       => 0,
            'whitelist'       => 0,
            'path_rules'      => 0,
            'blocked_24h'     => 0,
            'probe_24h'       => 0,
            'events_total'    => 0,
            'top_ips'         => [],
            'last_event_time' => '',
        ];

        if (!$this->storageReady()) {
            return $empty;
        }

        $since = date('Y-m-d H:i:s', time() - 86400);

        try {
            $now = date('Y-m-d H:i:s');
            $top = Db::name('security_event')
                ->field('ip, COUNT(*) AS cnt')
                ->where('create_time', '>=', $since)
                ->group('ip')
                ->order('cnt', 'desc')
                ->limit(5)
                ->select()
                ->toArray();

            $topIps = [];
            foreach ($top as $row) {
                $topIps[] = ['ip' => (string) $row['ip'], 'count' => (int) $row['cnt']];
            }

            return [
                'ready'           => true,
                'blacklist'       => (int) SecurityIpRule::where('list_type', 'blacklist')->where('status', 1)
                    ->where(function ($q) use ($now) {
                        $q->whereNull('expire_time')->whereOr('expire_time', '>', $now);
                    })->count(),
                'whitelist'       => (int) SecurityIpRule::where('list_type', 'whitelist')->where('status', 1)
                    ->where(function ($q) use ($now) {
                        $q->whereNull('expire_time')->whereOr('expire_time', '>', $now);
                    })->count(),
                'path_rules'      => (int) SecurityPathRule::where('status', 1)->count(),
                'blocked_24h'     => (int) SecurityEvent::whereIn('event_type', ['blacklist_hit', 'auto_block'])
                    ->where('create_time', '>=', $since)->count(),
                'probe_24h'       => (int) SecurityEvent::where('event_type', 'probe')
                    ->where('create_time', '>=', $since)->count(),
                'events_total'    => (int) SecurityEvent::count(),
                'top_ips'         => $topIps,
                'last_event_time' => (string) (SecurityEvent::order('id', 'desc')->value('create_time') ?: ''),
            ];
        } catch (\Throwable $e) {
            Log::warning('[security] overview failed: ' . $e->getMessage());
            return $empty;
        }
    }

    /**
     * 当前请求的客户端 IP（后台页面展示用）
     *
     * @return string
     */
    public function currentIp(): string
    {
        return self::clientIp();
    }

    // ==================================================================
    // 运行时内部方法
    // ==================================================================

    /**
     * 根据请求路径推断所在应用
     *
     * @param string $path 请求路径
     * @return string index / api / admin / adminapi
     */
    public static function detectApp(string $path): string
    {
        $segments = array_values(array_filter(explode('/', trim($path, '/')), static fn ($v) => $v !== ''));
        $first    = strtolower((string) ($segments[0] ?? ''));

        return match ($first) {
            'admin-api' => 'adminapi',
            'admin'     => 'admin',
            'api'       => 'api',
            default     => 'index',
        };
    }

    /**
     * 是否跳过拦截
     *
     * - 静态资源/公开文档前缀
     * - 已登录的后台账号（避免误封运维自己，登录态本身已是可信凭据）
     *
     * @param string $app  应用名
     * @param string $path 请求路径
     * @return bool
     */
    private function isBypassed(string $app, string $path): bool
    {
        $relative = strtolower(ltrim($path, '/'));
        foreach ((array) Config::get('security.bypass_prefixes', []) as $prefix) {
            $prefix = strtolower((string) $prefix);
            if ($prefix !== '' && str_starts_with($relative, $prefix)) {
                return true;
            }
        }

        if ($app === 'admin') {
            try {
                $admin = Session::get('admin');
                if (is_array($admin) && !empty($admin['id'])) {
                    return true;
                }
            } catch (\Throwable $e) {
                // Session 不可用时按未登录处理
            }
        }

        return false;
    }

    /**
     * 是否命中白名单（内置安全地址 + 额外放行 + 库表白名单）
     *
     * @param string     $ip       IP
     * @param array|null $settings 已合并设置
     * @return bool
     */
    private function isWhitelisted(string $ip, ?array $settings = null): bool
    {
        if ($ip === '') {
            return false;
        }

        foreach ((array) Config::get('security.safe_ips', []) as $safe) {
            if (self::ipMatches($ip, (string) $safe)) {
                return true;
            }
        }

        $settings = $settings ?? $this->settings();
        foreach (self::splitIpList($settings['extra_whitelist']) as $rule) {
            if (self::ipMatches($ip, $rule)) {
                return true;
            }
        }

        $sets = $this->ipRuleSets('whitelist');

        return $this->matchEntry($ip, $sets) !== null;
    }

    /**
     * 查找命中的黑名单记录
     *
     * @param string $ip IP
     * @return array|null
     */
    private function findBlacklist(string $ip): ?array
    {
        return $this->matchEntry($ip, $this->ipRuleSets('blacklist'));
    }

    /**
     * 读取某类 IP 规则（与探针规则共用同一个 Redis key）
     *
     * @param string $type blacklist / whitelist
     * @return array{exact:array,networks:array}
     */
    private function ipRuleSets(string $type): array
    {
        $rules = $this->runtimeRules();

        return $rules[$type] ?? ['exact' => [], 'networks' => []];
    }

    /**
     * 读取启用的探针规则（与黑白名单共用同一个 Redis key）
     *
     * @return array
     */
    private function pathRules(): array
    {
        $rules = $this->runtimeRules();

        return $rules['path'] ?? [];
    }

    /**
     * 一次性读取黑白名单 + 探针规则（Redis 单 key 缓存，正常请求只 1 次 GET）
     *
     * @return array
     */
    private function runtimeRules(): array
    {
        if (self::$runtimeRulesCache !== null) {
            return self::$runtimeRulesCache;
        }

        $cached = null;
        try {
            $cached = RedisCache::get(self::CACHE_RULES);
        } catch (\Throwable $e) {
            $cached = null;
        }

        $valid = is_array($cached)
            && isset($cached['blacklist']['exact'], $cached['blacklist']['networks'])
            && isset($cached['whitelist']['exact'], $cached['whitelist']['networks'])
            && isset($cached['path']) && is_array($cached['path']);

        if (!$valid) {
            $cached = $this->loadRuntimeRules();
            try {
                RedisCache::set(self::CACHE_RULES, $cached, self::RULES_TTL + random_int(0, 30));
            } catch (\Throwable $e) {
                // Redis 不可用时每次回源，功能不受影响
            }
        }

        return self::$runtimeRulesCache = $cached;
    }

    /**
     * 从数据库加载全部运行时规则
     *
     * @return array
     */
    private function loadRuntimeRules(): array
    {
        $out = [
            'blacklist' => ['exact' => [], 'networks' => []],
            'whitelist' => ['exact' => [], 'networks' => []],
            'path'      => [],
        ];

        if (!$this->storageReady()) {
            return $out;
        }

        try {
            $rows = SecurityIpRule::whereIn('list_type', ['blacklist', 'whitelist'])
                ->where('status', 1)
                ->select();

            foreach ($rows as $row) {
                $type = (string) $row->list_type;
                if (!isset($out[$type])) {
                    continue;
                }

                $entry = $this->normalizeEntry($row);
                if ($entry === null) {
                    continue;
                }
                if (str_contains($entry['ip'], '/') || str_contains($entry['ip'], '*')) {
                    $out[$type]['networks'][] = $entry;
                } else {
                    $out[$type]['exact'][$entry['ip']] = $entry;
                }
            }
        } catch (\Throwable $e) {
            Log::warning('[security] load ip rules failed: ' . $e->getMessage());
        }

        try {
            foreach (SecurityPathRule::where('status', 1)->select() as $row) {
                $out['path'][] = [
                    'id'         => (int) $row->id,
                    'name'       => (string) $row->name,
                    'match_type' => (string) $row->match_type,
                    'pattern'    => (string) $row->pattern,
                ];
            }
        } catch (\Throwable $e) {
            Log::warning('[security] load path rules failed: ' . $e->getMessage());
        }

        return $out;
    }

    /**
     * 在规则集合中匹配 IP
     *
     * @param string $ip   IP
     * @param array  $sets 规则集合
     * @return array|null
     */
    private function matchEntry(string $ip, array $sets): ?array
    {
        $exact = $sets['exact'][$ip] ?? null;
        if (is_array($exact) && !$this->entryExpired($exact)) {
            return $exact;
        }

        foreach ($sets['networks'] as $entry) {
            if ($this->entryExpired($entry)) {
                continue;
            }
            if (self::ipMatches($ip, (string) $entry['ip'])) {
                return $entry;
            }
        }

        return null;
    }

    /**
     * 缓存中的记录是否已过期（缓存 120 秒内也要按真实时间判断）
     *
     * @param array $entry 规则记录
     * @return bool
     */
    private function entryExpired(array $entry): bool
    {
        $expire = (string) ($entry['expire_time'] ?? '');
        if ($expire === '') {
            return false;
        }
        $ts = strtotime($expire);
        return $ts !== false && $ts < time();
    }

    /**
     * 规范化名单记录（过期返回 null）
     *
     * @param SecurityIpRule $row 记录
     * @return array|null
     */
    private function normalizeEntry(SecurityIpRule $row): ?array
    {
        $expire = (string) ($row->expire_time ?? '');
        if ($expire !== '') {
            $ts = strtotime($expire);
            if ($ts !== false && $ts < time()) {
                return null;
            }
        }

        return [
            'id'          => (int) $row->id,
            'ip'          => (string) $row->ip,
            'list_type'   => (string) $row->list_type,
            'source'      => (string) $row->source,
            'reason'      => (string) $row->reason,
            'hit_count'   => (int) $row->hit_count,
            'expire_time' => $expire,
        ];
    }

    /**
     * 匹配内置与自定义探针路径
     *
     * @param string $path 请求路径
     * @return array{reason:string,rule_id:int|null}|null
     */
    private function matchSuspiciousPath(string $path): ?array
    {
        $path  = '/' . ltrim(str_replace('\\', '/', rawurldecode($path)), '/');
        $lower = strtolower($path);

        $patterns = (array) Config::get('security.probe_patterns', []);
        foreach ($patterns as $regex => $label) {
            if (@preg_match((string) $regex, $path) === 1) {
                return ['reason' => '内置规则：' . (string) $label, 'rule_id' => null];
            }
        }

        foreach ($this->pathRules() as $rule) {
            $pattern = (string) $rule['pattern'];
            $matched = false;
            switch ($rule['match_type']) {
                case 'exact':
                    $matched = $lower === strtolower($pattern);
                    break;
                case 'prefix':
                    $matched = str_starts_with($lower, strtolower($pattern));
                    break;
                case 'regex':
                    $matched = @preg_match($pattern, $path) === 1;
                    break;
                default:
                    $matched = str_contains($lower, strtolower($pattern));
                    break;
            }
            if ($matched) {
                return ['reason' => '自定义规则：' . (string) $rule['name'], 'rule_id' => (int) $rule['id']];
            }
        }

        return null;
    }

    /**
     * 匹配恶意 UA
     *
     * @param string $userAgent UA
     * @return string|null 命中的特征
     */
    private function matchUserAgent(string $userAgent): ?string
    {
        $ua = strtolower($userAgent);
        if ($ua === '') {
            return null;
        }

        foreach ((array) Config::get('security.bad_user_agents', []) as $bad) {
            $bad = strtolower((string) $bad);
            if ($bad !== '' && str_contains($ua, $bad)) {
                return substr($bad, 0, 50);
            }
        }

        return null;
    }

    /**
     * 探针请求计数（Redis 不可用返回 0）
     *
     * @param string $ip     IP
     * @param int    $window 统计窗口（秒）
     * @return int
     */
    private function bumpProbeCounter(string $ip, int $window): int
    {
        $key = self::PROBE_KEY . md5($ip);

        try {
            $count = RedisCache::inc($key);
            if ($count === 1) {
                RedisCache::expire($key, $window);
            }
            return $count;
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /**
     * 累加自定义规则命中次数（按采样写入，避免高频扫描打爆数据库）
     *
     * @param int $ruleId 规则 ID
     * @return void
     */
    private function bumpPathRuleHit(int $ruleId): void
    {
        try {
            SecurityPathRule::where('id', $ruleId)->inc('hit_count')->update();
        } catch (\Throwable $e) {
            // 统计失败不影响拦截
        }
    }

    /**
     * 自动加入黑名单（存在则更新触发信息）
     *
     * @param string     $ip       IP
     * @param string     $source   auto_path / auto_ua
     * @param string     $reason   原因
     * @param string     $path     触发路径
     * @param int        $hits     触发次数
     * @param array|null $settings 已合并设置
     * @return void
     */
    private function autoBlock(string $ip, string $source, string $reason, string $path, int $hits, ?array $settings = null): void
    {
        if ($ip === '' || !$this->storageReady()) {
            return;
        }

        $settings = $settings ?? $this->settings();
        $expire   = $settings['block_ttl'] > 0
            ? date('Y-m-d H:i:s', time() + $settings['block_ttl'])
            : null;

        try {
            $row = SecurityIpRule::where('list_type', 'blacklist')->where('ip', $ip)->find();

            if ($row) {
                $row->hit_count = max((int) $row->hit_count, $hits);
                $row->last_uri  = mb_substr($path, 0, 255);
                // 手动记录保持后台设置的状态与过期时间，自动任务只补充命中信息
                if ((string) $row->source !== 'manual') {
                    $row->status      = 1;
                    $row->source      = $source;
                    $row->reason      = mb_substr($reason, 0, 255);
                    $row->expire_time = $expire;
                }
                $row->updated_by = 'system';
                $row->save();
            } else {
                SecurityIpRule::create([
                    'list_type'   => 'blacklist',
                    'ip'          => $ip,
                    'source'      => $source,
                    'reason'      => mb_substr($reason, 0, 255),
                    'status'      => 1,
                    'expire_time' => $expire,
                    'hit_count'   => $hits,
                    'last_uri'    => mb_substr($path, 0, 255),
                    'remark'      => '',
                    'created_by'  => 'system',
                    'updated_by'  => 'system',
                ]);
            }
        } catch (\Throwable $e) {
            Log::warning('[security] auto block failed: ' . $e->getMessage());
            return;
        }

        $this->refreshCache();
    }

    /**
     * 写入安全事件（相同事件 60 秒内去重）
     *
     * @param string $type  事件类型
     * @param string $reason 原因
     * @param string $path  请求路径
     * @param string $ip    IP
     * @param int    $hits  累计次数
     * @return void
     */
    private function recordEvent(string $type, string $reason, string $path, string $ip, int $hits = 0): void
    {
        $settings = $this->settings();
        if (!$settings['log_enabled'] || !$this->storageReady()) {
            return;
        }

        // 单 IP 每分钟最多写 30 条，避免扫描器用不同路径打爆数据库
        $rateKey = self::EVENT_KEY . 'rate:' . md5($ip);
        try {
            $rate = RedisCache::inc($rateKey);
            if ($rate === 1) {
                RedisCache::expire($rateKey, 60);
            }
            if ($rate > 30) {
                return;
            }
        } catch (\Throwable $e) {
            // Redis 不可用时继续写入
        }

        $dedupeKey = self::EVENT_KEY . md5($ip . '|' . $type . '|' . $path);
        try {
            if (RedisCache::get($dedupeKey) !== null) {
                return;
            }
            RedisCache::set($dedupeKey, 1, self::EVENT_DEDUPE_TTL);
        } catch (\Throwable $e) {
            // 去重失败时继续写入，宁可多记也不漏记
        }

        try {
            $request = null;
            try {
                $request = app('request');
            } catch (\Throwable $e) {
                $request = null;
            }

            SecurityEvent::create([
                'ip'         => mb_substr($ip, 0, 64),
                'event_type' => $type,
                'reason'     => mb_substr($reason, 0, 255),
                'path'       => mb_substr($path, 0, 512),
                'method'     => $request ? strtoupper((string) $request->method()) : '',
                'user_agent' => $request ? mb_substr((string) $request->header('user-agent', ''), 0, 255) : '',
                'hit_count'  => $hits,
            ]);

            if (random_int(1, 100) === 1 && $settings['event_retention_days'] > 0) {
                $this->clearEvents($settings['event_retention_days']);
            }
        } catch (\Throwable $e) {
            Log::warning('[security] record event failed: ' . $e->getMessage());
        }
    }

    /**
     * 构造拦截响应（API 返回 JSON，页面返回 HTML）
     *
     * @param string $app     应用名
     * @param string $message 提示文案
     * @return \think\Response
     */
    private function blockedResponse(string $app, string $message)
    {
        $message = trim($message) !== '' ? $message : 'Access denied.';

        if (in_array($app, ['api', 'adminapi'], true)) {
            return json(['code' => 403, 'message' => $message, 'data' => null], 403)
                ->header(['X-Security-Guard' => 'blocked']);
        }

        $html = '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">'
            . '<meta name="viewport" content="width=device-width, initial-scale=1">'
            . '<title>403 Forbidden</title><style>'
            . 'body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;'
            . 'background:#f5f6f8;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;color:#1f2329}'
            . '.box{max-width:560px;padding:40px;background:#fff;border-radius:12px;box-shadow:0 8px 30px rgba(0,0,0,.06);text-align:center}'
            . 'h1{margin:0 0 12px;font-size:28px}p{margin:0;color:#646a73;line-height:1.7}'
            . '</style></head><body><div class="box"><h1>403 Forbidden</h1><p>'
            . htmlspecialchars($message, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')
            . '</p></div></body></html>';

        return response($html, 403)->contentType('text/html', 'utf-8')
            ->header(['X-Security-Guard' => 'blocked']);
    }

    // ==================================================================
    // 工具方法
    // ==================================================================

    /**
     * 解析设置中的可信代理列表
     *
     * @return array
     */
    private function trustedProxyList(): array
    {
        return self::splitIpList($this->settings()['trusted_proxies']);
    }

    /**
     * 当前请求是否可信，可以采信反向代理请求头
     *
     * 满足任一条件即可：
     *   1. REMOTE_ADDR 命中「可信代理地址」（可选配置，留空则跳过此判断）；
     *   2. 请求携带「回源密钥头」且值与「回源密钥」一致（CDN 场景防伪造）。
     *
     * @param Request $request 当前请求
     * @param string  $remote  REMOTE_ADDR
     * @return bool
     */
    private function isTrustedSource(Request $request, string $remote): bool
    {
        $settings = $this->settings();

        $proxies = $this->trustedProxyList();
        if (!empty($proxies) && self::matchIpRuleList($remote, $proxies)) {
            return true;
        }

        $secret = (string) $settings['proxy_secret'];
        $header = (string) $settings['proxy_secret_header'];
        if ($secret !== '' && $header !== '') {
            $provided = trim((string) $request->header($header, ''));
            if ($provided !== '' && hash_equals($secret, $provided)) {
                return true;
            }
        }

        return false;
    }

    /**
     * 实际生效的可信请求头顺序
     *
     * 后台保存过 security.trusted_headers 时以其为准（可自行增删、调整顺序）；
     * 未保存或为空时回退 config/security.php 的默认列表。
     *
     * @return array
     */
    private function trustedHeaderList(): array
    {
        $headers = [];
        foreach (self::splitIpList($this->settings()['trusted_headers'] ?? '') as $line) {
            $name = self::normalizeHeaderName($line);
            if ($name !== '') {
                $headers[] = $name;
            }
        }

        if (empty($headers)) {
            foreach ((array) Config::get('security.trusted_headers', []) as $line) {
                $name = self::normalizeHeaderName((string) $line);
                if ($name !== '') {
                    $headers[] = $name;
                }
            }
        }

        return array_values(array_unique($headers));
    }

    /**
     * 校验并规范化请求头列表（每行一个，允许 X-Client-IP / HTTP_X_CLIENT_IP 写法）
     *
     * @param string $value 原始文本
     * @return string
     * @throws BizException 请求头名称不合法或数量过多
     */
    private function normalizeHeaderList(string $value): string
    {
        $out = [];
        foreach (self::splitIpList($value) as $line) {
            $name = self::normalizeHeaderName($line);
            if ($name === '') {
                throw new BizException('请求头名称不正确：' . mb_substr($line, 0, 64));
            }
            $out[$name] = $name;
        }

        if (count($out) > 15) {
            throw new BizException('可信请求头最多填写 15 个');
        }

        return implode("\n", array_values($out));
    }

    /**
     * 规范化单个请求头名称（大小写、下划线、HTTP_ 前缀都兼容）
     *
     * @param string $name 原始名称
     * @return string 合法名称；不合法返回空字符串
     */
    private static function normalizeHeaderName(string $name): string
    {
        $name = strtolower(trim($name));
        if ($name === '') {
            return '';
        }

        // 兼容 Nginx/Apache 常见的 HTTP_X_CLIENT_IP 写法
        $name = preg_replace('/^http[_-]/', '', $name) ?? $name;
        $name = str_replace('_', '-', rtrim($name, ':'));

        if (!preg_match('/^[a-z0-9!#$%&\'*+.^`|~-]{1,64}$/', $name)) {
            return '';
        }

        return $name;
    }

    /**
     * 把多行 IP/请求头列表拆成数组
     *
     * @param string $value 文本
     * @return array
     */
    private static function splitIpList(string $value): array
    {
        $out = [];
        foreach (preg_split('/\r\n|\r|\n/', $value) ?: [] as $line) {
            $line = trim($line);
            if ($line !== '' && !str_starts_with($line, '#')) {
                $out[] = $line;
            }
        }
        return $out;
    }

    /**
     * 从代理头值中取第一个合法 IP
     *
     * @param string $value 请求头值（可能为逗号分隔列表）
     * @return string
     */
    private static function firstValidIp(string $value): string
    {
        foreach (explode(',', $value) as $candidate) {
            $candidate = trim($candidate);
            if ($candidate === '') {
                continue;
            }
            // 去掉 IPv4 端口与方括号
            $candidate = preg_replace('/^\[(.+)\](?::\d+)?$/', '$1', $candidate) ?? $candidate;
            $candidate = preg_replace('/^(\d{1,3}(?:\.\d{1,3}){3}):\d+$/', '$1', $candidate) ?? $candidate;
            if (filter_var($candidate, FILTER_VALIDATE_IP) !== false) {
                return $candidate;
            }
        }
        return '';
    }

    /**
     * 判断 IP 是否命中规则列表中的任意一项
     *
     * @param string $ip    IP
     * @param array  $rules 规则列表
     * @return bool
     */
    private static function matchIpRuleList(string $ip, array $rules): bool
    {
        foreach ($rules as $rule) {
            if (self::ipMatches($ip, (string) $rule)) {
                return true;
            }
        }
        return false;
    }

    /**
     * IP 匹配：支持精确 IP、CIDR、IPv4 通配（192.168.1.*）
     *
     * @param string $ip   IP
     * @param string $rule 规则
     * @return bool
     */
    public static function ipMatches(string $ip, string $rule): bool
    {
        $ip   = trim($ip);
        $rule = trim($rule);
        if ($ip === '' || $rule === '') {
            return false;
        }

        if ($rule === $ip) {
            return true;
        }

        if (str_ends_with($rule, '.*')) {
            return str_starts_with($ip, substr($rule, 0, -1));
        }

        if (!str_contains($rule, '/')) {
            return false;
        }

        [$network, $mask] = explode('/', $rule, 2);
        $ipBin    = @inet_pton($ip);
        $networkBin = @inet_pton($network);
        if ($ipBin === false || $networkBin === false || strlen($ipBin) !== strlen($networkBin)) {
            return false;
        }

        $bits = (int) $mask;
        $full = intdiv($bits, 8);
        $rem  = $bits % 8;

        if ($full > 0 && substr($ipBin, 0, $full) !== substr($networkBin, 0, $full)) {
            return false;
        }

        if ($rem > 0) {
            $bitMask = (0xFF << (8 - $rem)) & 0xFF;
            if ((ord($ipBin[$full]) & $bitMask) !== (ord($networkBin[$full]) & $bitMask)) {
                return false;
            }
        }

        return true;
    }

    /**
     * 校验并规范化单条 IP 规则
     *
     * @param string $value 原始值
     * @return string
     * @throws BizException 格式不合法
     */
    private function normalizeIpRule(string $value): string
    {
        $value = trim($value);
        if ($value === '') {
            throw new BizException('请输入 IP 地址');
        }

        if (str_ends_with($value, '.*')) {
            $prefix = substr($value, 0, -2);
            $parts  = explode('.', $prefix);
            if (count($parts) !== 3) {
                throw new BizException('通配格式仅支持 192.168.1.* 这种前三段写法');
            }
            foreach ($parts as $part) {
                if (!ctype_digit($part) || (int) $part > 255) {
                    throw new BizException('IP 地址格式不正确');
                }
            }
            return $prefix . '.*';
        }

        if (str_contains($value, '/')) {
            [$ip, $mask] = explode('/', $value, 2);
            if (filter_var($ip, FILTER_VALIDATE_IP) === false) {
                throw new BizException('IP 地址格式不正确');
            }
            $max = str_contains($ip, ':') ? 128 : 32;
            if (!ctype_digit($mask) || (int) $mask < 0 || (int) $mask > $max) {
                throw new BizException('CIDR 掩码需在 0 - ' . $max . ' 之间');
            }
            return $ip . '/' . (int) $mask;
        }

        if (filter_var($value, FILTER_VALIDATE_IP) === false) {
            throw new BizException('IP 地址格式不正确');
        }

        return $value;
    }

    /**
     * 校验多行 IP 列表并规范化输出
     *
     * @param string $value 文本
     * @param string $label 字段名（用于报错）
     * @return string
     * @throws BizException 格式不合法
     */
    private function normalizeIpList(string $value, string $label): string
    {
        $out = [];
        foreach (self::splitIpList($value) as $line) {
            $out[] = $this->normalizeIpRule($line);
        }
        return implode("\n", $out);
    }

    /**
     * 规范化过期时间
     *
     * @param string $value 文本（空表示长期）
     * @return string|null
     * @throws BizException 格式不合法
     */
    private function normalizeExpireTime(string $value): ?string
    {
        $value = trim($value);
        if ($value === '') {
            return null;
        }

        $ts = strtotime($value);
        if ($ts === false) {
            throw new BizException('过期时间格式不正确，应为 Y-m-d H:i:s');
        }

        return date('Y-m-d H:i:s', $ts);
    }

    /**
     * 数据表未就绪时给出可操作提示
     *
     * @return void
     * @throws BizException
     */
    private function assertStorageReady(): void
    {
        if (!$this->storageReady()) {
            throw new BizException('安全数据表尚未创建，请先执行 php think migrate:run');
        }
    }

    /**
     * 规范化名单类型
     *
     * @param string $type 类型
     * @return string
     * @throws BizException 类型不合法
     */
    private function normalizeListType(string $type): string
    {
        if (!in_array($type, ['blacklist', 'whitelist'], true)) {
            throw new BizException('名单类型不正确');
        }
        return $type;
    }

    /**
     * 批量 ID 规范化
     *
     * @param array $ids 原始 ID
     * @return array
     */
    private function normalizeIds(array $ids): array
    {
        $out = [];
        foreach ($ids as $id) {
            $id = (int) $id;
            if ($id > 0) {
                $out[$id] = $id;
            }
        }
        return array_values($out);
    }

    /**
     * 名单行格式化
     *
     * @param SecurityIpRule $row 记录
     * @return array
     */
    private function formatIpRow(SecurityIpRule $row): array
    {
        $expire = (string) ($row->expire_time ?? '');
        $source = (string) ($row->source ?? 'manual');

        return [
            'id'           => (int) $row->id,
            'list_type'    => (string) $row->list_type,
            'ip'           => (string) $row->ip,
            'source'       => $source,
            'source_label' => self::SOURCE_LABELS[$source] ?? $source,
            'reason'       => (string) ($row->reason ?? ''),
            'status'       => (int) $row->status,
            'expire_time'  => $expire,
            'expired'      => $expire !== '' && strtotime($expire) !== false && strtotime($expire) < time(),
            'hit_count'    => (int) ($row->hit_count ?? 0),
            'last_uri'     => (string) ($row->last_uri ?? ''),
            'remark'       => (string) ($row->remark ?? ''),
            'created_by'   => (string) ($row->created_by ?? ''),
            'create_time'  => (string) ($row->create_time ?? ''),
            'update_time'  => (string) ($row->update_time ?? ''),
        ];
    }

    /**
     * 探针规则行格式化
     *
     * @param SecurityPathRule $row 记录
     * @return array
     */
    private function formatPathRow(SecurityPathRule $row): array
    {
        return [
            'id'          => (int) $row->id,
            'name'        => (string) $row->name,
            'match_type'  => (string) $row->match_type,
            'pattern'     => (string) $row->pattern,
            'risk_level'  => (string) ($row->risk_level ?? 'high'),
            'status'      => (int) $row->status,
            'hit_count'   => (int) ($row->hit_count ?? 0),
            'remark'      => (string) ($row->remark ?? ''),
            'created_by'  => (string) ($row->created_by ?? ''),
            'create_time' => (string) ($row->create_time ?? ''),
        ];
    }

    /**
     * 事件行格式化
     *
     * @param SecurityEvent $row 记录
     * @return array
     */
    private function formatEventRow(SecurityEvent $row): array
    {
        $type = (string) $row->event_type;

        return [
            'id'          => (int) $row->id,
            'ip'          => (string) $row->ip,
            'event_type'  => $type,
            'event_label' => self::EVENT_LABELS[$type] ?? $type,
            'reason'      => (string) ($row->reason ?? ''),
            'path'        => (string) ($row->path ?? ''),
            'method'      => (string) ($row->method ?? ''),
            'user_agent'  => (string) ($row->user_agent ?? ''),
            'hit_count'   => (int) ($row->hit_count ?? 0),
            'create_time' => (string) ($row->create_time ?? ''),
        ];
    }

    /**
     * 值转 bool
     *
     * @param mixed $value 值
     * @return bool
     */
    private static function toBool($value): bool
    {
        if (is_bool($value)) {
            return $value;
        }
        return in_array((string) $value, ['1', 'true', 'on', 'yes'], true);
    }
}