<?php

/**
 * 系统设置字段注册表
 *
 * 后台「系统设置」页面的结构来源：分组 -> 字段 -> 控件定义。
 * 字段的「值」统一通过 site_config($key) 读取（数据库 setting 表覆盖 config/site.php 的默认值），
 * 因此新增一个设置项只需在此登记，不需要写数据库迁移。
 *
 * 字段可用属性：
 *   label       控件标签
 *   type        text / textarea / number / bool / select / password / readonly
 *   placeholder 输入提示
 *   help        字段下方的说明文字
 *   options     type=select 时的可选值 ['value' => '显示文案']
 *   secret      true 表示敏感项（后台不回显已保存的值，留空表示不修改）
 *   rows        type=textarea 时的行数
 *   standalone  true 表示该分组有独立后台页面（如安全设置），不在「系统设置」标签里重复展示
 */
return [
    'groups' => [
        'basic' => [
            'title'  => '基础信息',
            'desc'   => '站点名称、货币、模板选择与公告条等全局展示信息',
            'fields' => [
                'brand.name'      => ['label' => '站点名称', 'type' => 'text', 'placeholder' => 'Almi'],
                'brand.logo_text' => ['label' => 'Logo 文字', 'type' => 'text', 'placeholder' => 'Almi'],
                'brand.tagline'   => ['label' => '站点标语', 'type' => 'text', 'placeholder' => 'Smart, durable tools for an organised home'],
                'announcement'    => ['label' => '顶部公告条', 'type' => 'text', 'placeholder' => 'FREE DELIVERY ON ORDERS OF £80 OR MORE'],
                'currency.code'   => ['label' => '货币代码', 'type' => 'text', 'placeholder' => 'GBP'],
                'currency.symbol' => ['label' => '货币符号', 'type' => 'text', 'placeholder' => '£'],
                'region_label'    => ['label' => '地区选择器文案', 'type' => 'text', 'placeholder' => 'United Kingdom / GBP'],
                'site.template'   => [
                    'label'   => '前台模板',
                    'type'    => 'select',
                    'options' => ['almi2026' => 'almi2026（默认模板）', 'none' => '无（纯 API 站）'],
                    'help'    => '选择"无"时所有前台页面返回 404，适合纯小程序站。更多模板可在「模板管理」中查看。',
                ],
            ],
        ],

        'seo' => [
            'title'  => '首页 SEO',
            'desc'   => '首页的标题、描述与关键词，直接影响搜索引擎收录与广告落地页质量',
            'fields' => [
                'seo.title'       => ['label' => '首页标题', 'type' => 'text', 'placeholder' => 'Almi — Smart, durable tools for an organised home'],
                'seo.description' => ['label' => '首页描述', 'type' => 'textarea', 'rows' => 3],
                'seo.keywords'    => ['label' => '首页关键词', 'type' => 'textarea', 'rows' => 2, 'help' => '多个关键词用英文逗号分隔'],
            ],
        ],

        'contact' => [
            'title'  => '联系方式',
            'desc'   => '页脚与联系页展示的客服信息',
            'fields' => [
                'contact.email'   => ['label' => '客服邮箱', 'type' => 'text', 'placeholder' => 'service@example.com'],
                'contact.support' => ['label' => '支持邮箱', 'type' => 'text', 'placeholder' => 'service@example.com'],
                'contact.phone'   => ['label' => '联系电话', 'type' => 'text'],
                'contact.hours'   => ['label' => '服务时间', 'type' => 'text', 'placeholder' => 'Mon - Fri: 9:00 AM - 6:00 PM (GMT)'],
                'contact.address' => ['label' => '公司地址', 'type' => 'text'],
                'contact.country' => ['label' => '所在国家/地区', 'type' => 'text'],
            ],
        ],

        'shipping' => [
            'title'  => '配送说明',
            'desc'   => '免运费文案，展示在商品页与购物车页',
            'fields' => [
                'shipping.free_shipping_text' => ['label' => '免运费短文案', 'type' => 'text'],
                'shipping.free_shipping_note' => ['label' => '免运费说明', 'type' => 'textarea', 'rows' => 2],
            ],
        ],

        'mail' => [
            'title'  => '邮件服务',
            'desc'   => '用于发送登录验证码、订单通知等邮件。关闭后系统只写日志不发信。',
            'fields' => [
                'mail.enabled'         => ['label' => '启用邮件发送', 'type' => 'bool'],
                'mail.from'            => ['label' => '发件人邮箱', 'type' => 'text', 'placeholder' => 'no-reply@example.com'],
                'mail.from_name'       => ['label' => '发件人名称', 'type' => 'text', 'placeholder' => 'Almi'],
                'mail.notify_to'       => ['label' => '客服通知收件邮箱', 'type' => 'text', 'help' => '留言、下单等事件的通知接收地址'],
                'mail.smtp.host'       => ['label' => 'SMTP 服务器', 'type' => 'text', 'placeholder' => 'smtp.example.com'],
                'mail.smtp.port'       => ['label' => 'SMTP 端口', 'type' => 'number', 'placeholder' => '465'],
                'mail.smtp.encryption' => [
                    'label'   => '加密方式',
                    'type'    => 'select',
                    'options' => ['ssl' => 'SSL（465）', 'tls' => 'STARTTLS（587）', 'none' => '不加密（25）'],
                ],
                'mail.smtp.username'   => ['label' => 'SMTP 账号', 'type' => 'text'],
                'mail.smtp.password'   => ['label' => 'SMTP 密码/授权码', 'type' => 'password', 'secret' => true, 'help' => '留空表示不修改已保存的密码'],
            ],
        ],

        'social' => [
            'title'  => '社交链接',
            'desc'   => '页脚社交图标跳转地址，留空则不显示该图标',
            'fields' => [
                'social.facebook'  => ['label' => 'Facebook', 'type' => 'text'],
                'social.instagram' => ['label' => 'Instagram', 'type' => 'text'],
                'social.twitter'   => ['label' => 'X / Twitter', 'type' => 'text'],
                'social.pinterest' => ['label' => 'Pinterest', 'type' => 'text'],
                'social.tiktok'    => ['label' => 'TikTok', 'type' => 'text'],
            ],
        ],

        'advanced' => [
            'title'  => '其他设置',
            'desc'   => '列表分页、登录安全等进阶参数。后续新增的能力也会归入本组。',
            'fields' => [
                'per_page'          => ['label' => '商品列表每页数量', 'type' => 'number', 'placeholder' => '24'],
                'auth.dev_show_code' => [
                    'label' => '开发模式：回显登录验证码',
                    'type'  => 'bool',
                    'help'  => '生产环境必须关闭，否则前台登录接口会直接返回验证码',
                ],
                'theme'             => ['label' => '前台主题目录', 'type' => 'readonly', 'help' => '主题切换尚未开放，需在代码中调整'],
            ],
        ],

        // 多语言 / 多货币 / AI 配置（分别有独立后台页面，标记 standalone 不出现在系统设置标签页）
        'i18n' => [
            'title'      => '多语言',
            'desc'       => '语种清单与默认语种在上方「网站语言」维护（默认语种即模板源语言，通过「设为默认」切换）；这里只控制自动识别与翻译发布策略',
            'standalone' => true,
            'fields'     => [
                'i18n.enabled'                => ['label' => '启用多语言', 'type' => 'bool', 'help' => '关闭后前台只输出英文，语言前缀不生效'],
                'i18n.auto_detect'            => ['label' => '按浏览器语言自动识别', 'type' => 'bool', 'help' => '首次访问读取 Accept-Language；之后以 Cookie 为准'],
                'i18n.auto_publish_ai'        => ['label' => 'AI 翻译结果自动发布', 'type' => 'bool', 'help' => '关闭后 AI 结果先存草稿，需人工发布'],
                'i18n.auto_translate_on_save' => ['label' => '保存商品时自动排队翻译', 'type' => 'bool'],
                'i18n.fallback_to_base'       => ['label' => '译文缺失时回退英文', 'type' => 'bool', 'help' => '关闭后缺失语种会显示空白，一般保持开启'],
            ],
        ],

        'currency' => [
            'title'      => '多货币展示',
            'desc'       => '订单与支付始终使用 USD；这里只控制前台参考价的展示币种',
            'standalone' => true,
            'fields'     => [
                'currency.enabled'        => ['label' => '启用多货币展示', 'type' => 'bool'],
                'currency.provider'       => [
                    'label'   => '汇率数据源',
                    'type'    => 'select',
                    'options' => ['open.er-api' => 'open.er-api.com（主）', 'fawazahmed0' => 'fawazahmed0（备）'],
                ],
                'currency.sync_time'      => ['label' => '每日同步时间', 'type' => 'text', 'placeholder' => '00:10'],
                'currency.default_code'   => ['label' => '默认展示币种', 'type' => 'text', 'placeholder' => 'USD'],
                'currency.sanity_percent' => ['label' => '汇率异常阈值（%）', 'type' => 'number', 'placeholder' => '10', 'help' => '单日变动超过该比例时拒绝更新并告警'],
                'currency.alert_email'    => ['label' => '汇率告警邮箱', 'type' => 'text'],
            ],
        ],

        'translation' => [
            'title'      => 'AI 配置',
            'desc'       => '仅支持 OpenAI 兼容协议；切换供应商只需修改地址、密钥与模型 ID',
            'standalone' => true,
            'fields'     => [
                'translation.base_url'    => ['label' => '接口地址', 'type' => 'text', 'placeholder' => 'https://api.deepseek.com/v1', 'help' => '兼容 OpenAI 的 base_url，可带或不带 /v1'],
                'translation.api_key'     => ['label' => 'API Key', 'type' => 'password', 'secret' => true, 'help' => '留空表示不修改已保存的密钥'],
                'translation.model'       => ['label' => '模型 ID', 'type' => 'text', 'placeholder' => 'deepseek-chat'],
                'translation.temperature' => ['label' => 'Temperature（非思考模式）', 'type' => 'number', 'placeholder' => '0.3', 'help' => '仅关闭思考模式时生效'],
                'translation.thinking'    => [
                    'label'   => '思考模式',
                    'type'    => 'select',
                    'options' => ['enabled' => '开启（DeepSeek thinking）', 'disabled' => '关闭'],
                    'default' => 'enabled',
                    'help'    => '开启后请求体带 thinking.type=enabled；关闭后使用普通模式',
                ],
                'translation.reasoning_effort' => [
                    'label'   => '思考强度',
                    'type'    => 'select',
                    'options' => ['low' => '低（low）', 'high' => '高（high）', 'max' => '最高（max）'],
                    'default' => 'low',
                    'help'    => '仅思考模式开启时生效；默认低强度',
                ],
                'translation.timeout'     => ['label' => '单次请求超时（秒）', 'type' => 'number', 'placeholder' => '120', 'default' => 120],
                'translation.max_chars'   => ['label' => '单次最大字符数', 'type' => 'number', 'placeholder' => '6000'],
                'translation.daily_budget'=> ['label' => '每日预算（USD）', 'type' => 'number', 'placeholder' => '5'],
                'translation.price_per_1k' => ['label' => '每 1K Token 成本（USD）', 'type' => 'number', 'placeholder' => '0.002', 'help' => '用于估算任务成本，按所用模型的实际价格填写'],
            ],
        ],

        // 安全设置独立成页（左侧「系统设置 → 安全设置」），不在「系统设置」标签里重复出现，
        // 因此标记 standalone=true；字段仍登记在此，保存/类型转换复用 SettingService。
        'security' => [
            'title'      => '安全设置',
            'desc'       => 'IP 黑白名单、客户端真实 IP 识别、探针扫描与恶意 UA 自动封禁',
            'standalone' => true,
            'fields'     => [
                'security.enabled'              => [
                    'label' => '启用安全防护',
                    'type'  => 'bool',
                    'help'  => '关闭后不拦截、不记录任何请求；黑名单与规则数据仍保留',
                ],
                'security.auto_block'           => [
                    'label' => '探针命中自动封禁',
                    'type'  => 'bool',
                    'help'  => '同一 IP 在统计窗口内命中高风险路径达到阈值后自动加入黑名单',
                ],
                'security.ua_block'             => [
                    'label' => '恶意 UA 直接封禁',
                    'type'  => 'bool',
                    'help'  => '命中扫描器 UA（sqlmap、nikto、curl 等）立即封禁，可能影响监控脚本',
                ],
                'security.threshold'            => ['label' => '自动封禁阈值', 'type' => 'number', 'placeholder' => '5', 'help' => '统计窗口内命中高风险路径的次数'],
                'security.window'               => ['label' => '统计窗口（秒）', 'type' => 'number', 'placeholder' => '86400'],
                'security.block_ttl'            => ['label' => '自动封禁时长（秒）', 'type' => 'number', 'placeholder' => '86400', 'help' => '填 0 表示长期封禁'],
                'security.trusted_proxy'        => [
                    'label' => '信任反向代理请求头',
                    'type'  => 'bool',
                    'help'  => '开启后，REMOTE_ADDR 命中「可信代理地址」或请求携带匹配的「回源密钥头」时，才按「可信请求头」顺序读取客户端 IP',
                ],
                'security.trusted_proxies'      => [
                    'label' => '可信代理地址',
                    'type'  => 'textarea',
                    'rows'  => 3,
                    'help'  => '每行一个，支持 IP 或 CIDR，如 10.0.0.0/8；可选，与回源密钥任一命中即可',
                ],
                'security.proxy_secret_header'  => [
                    'label'       => '回源密钥头',
                    'type'        => 'text',
                    'placeholder' => 'CDN_SRC_SEC',
                    'help'        => 'CDN 回源请求携带的密钥请求头名称，默认 cdn-src-sec',
                ],
                'security.proxy_secret'         => [
                    'label' => '回源密钥',
                    'type'  => 'text',
                    'help'  => '开启「信任反向代理请求头」时必填；请求携带的回源密钥头值与此一致才采信客户端 IP 请求头',
                ],
                'security.trusted_headers'      => [
                    'label' => '可信请求头（按优先级）',
                    'type'  => 'textarea',
                    'rows'  => 3,
                    'help'  => '每行一个，可自行增删；默认 CF-Connecting-IP / X-Real-IP / X-Forwarded-For。仅当来源命中可信代理地址或回源密钥匹配时生效',
                ],
                'security.extra_whitelist'      => [
                    'label' => '额外放行地址',
                    'type'  => 'textarea',
                    'rows'  => 3,
                    'help'  => '每行一个，支持 IP / CIDR / 192.168.1.*；优先级高于黑名单，适合临时放行运维出口 IP',
                ],
                'security.event_retention_days' => ['label' => '拦截日志保留天数', 'type' => 'number', 'placeholder' => '30'],
                'security.log_enabled'          => ['label' => '记录拦截/探针日志', 'type' => 'bool'],
                'security.block_message'        => ['label' => '拦截提示文案', 'type' => 'text', 'placeholder' => 'Your IP has been blocked...'],
            ],
        ],

        // 更新设置独立成页（系统与安全 → 更新设置），不在系统设置标签页里重复展示
        // 开关字段（update.enabled / backup_keep / maintenance_enabled）仍登记在此
        'update' => [
            'title'      => '更新设置',
            'desc'       => '在线增量更新开关与维护窗口策略；检查版本、执行升级与历史在同一页面下方',
            'standalone' => true,
            'fields'     => [
                'update.enabled'             => ['label' => '启用在线更新', 'type' => 'bool'],
                'update.backup_keep'         => ['label' => '备份保留批次', 'type' => 'number', 'placeholder' => '3'],
                'update.maintenance_enabled' => [
                    'label' => '升级期间开启维护窗口',
                    'type'  => 'bool',
                    'help'  => '安装期间前台返回 503，后台与管理 API 放行',
                ],
            ],
        ],
    ],
];
