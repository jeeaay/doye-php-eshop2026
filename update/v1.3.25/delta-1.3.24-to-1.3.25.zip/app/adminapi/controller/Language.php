<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\service\LanguageService;

/**
 * 管理 API：语种
 */
class Language extends ApiBaseController
{
    /**
     * GET /admin-api/v1/languages
     *
     * @return \think\response\Json
     */
    public function index()
    {
        return $this->run(function () {
            $this->assertSuper();

            $rows = (new LanguageService())->all();

            return array_map(fn(array $row): array => $this->payload($row), $rows);
        });
    }

    /**
     * POST /admin-api/v1/languages
     *
     * @return \think\response\Json
     */
    public function save()
    {
        return $this->run(function () {
            $this->assertSuper();

            $row = (new LanguageService())->save($this->input());

            return $this->payload($row->toArray());
        }, '语种已添加');
    }

    /**
     * 语种对外字段
     *
     * @param array<string,mixed> $row
     * @return array<string,mixed>
     */
    private function payload(array $row): array
    {
        $currency = trim((string) ($row['default_currency'] ?? ''));

        return [
            'id'               => (int) ($row['id'] ?? 0),
            'code'             => LanguageService::normalizeCode((string) ($row['code'] ?? '')),
            'name'             => (string) ($row['name'] ?? ''),
            'native_name'      => (string) ($row['native_name'] ?? ''),
            'direction'        => (string) ($row['direction'] ?? 'ltr'),
            'default_currency' => $currency !== '' ? $currency : null,
            'status'           => (int) ($row['status'] ?? 0),
            'is_default'       => (int) ($row['is_default'] ?? 0),
            'sort'             => (int) ($row['sort'] ?? 0),
        ];
    }
}