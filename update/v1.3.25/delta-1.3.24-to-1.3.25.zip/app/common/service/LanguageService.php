<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\exception\BizException;
use app\common\lib\RedisCache;
use app\common\model\Language;

/**
 * 语种注册表读取（带缓存）
 */
class LanguageService
{
    /**
     * 常用语种预设：code => [英文名, 原生名, 国旗]
     * 供「多语言管理」添加语种与「模板翻译」选择目标语言时快速填写
     */
    public const COMMON = [
        'en' => ['English',    'English',   '🇬🇧'],
        'zh' => ['Chinese',    '中文',       '🇨🇳'],
        'es' => ['Spanish',    'Español',   '🇪🇸'],
        'fr' => ['French',     'Français',  '🇫🇷'],
        'de' => ['German',     'Deutsch',   '🇩🇪'],
        'it' => ['Italian',    'Italiano',  '🇮🇹'],
        'pt' => ['Portuguese', 'Português', '🇵🇹'],
        'ru' => ['Russian',    'Русский',   '🇷🇺'],
        'ja' => ['Japanese',   '日本語',     '🇯🇵'],
        'ar' => ['Arabic',     'العربية',   '🇸🇦'],
    ];

    private const CACHE_KEY = 'site:languages';
    private const CACHE_TTL = 600;

    /**
     * 语言代码别名归一化，英语统一使用 en
     *
     * @param string $code 语言代码
     * @return string
     */
    public static function normalizeCode(string $code): string
    {
        $code = strtolower(trim(str_replace('_', '-', $code)));

        return match ($code) {
            'gb', 'uk', 'en-gb', 'en-uk', 'eng' => 'en',
            default => $code,
        };
    }

    /**
     * 全部语种（含停用，后台管理用）
     *
     * @return array<int,array<string,mixed>>
     */
    public function all(): array
    {
        $rows = Language::order('is_default', 'desc')->order('sort')->order('id')->select()->toArray();

        return array_map(static function ($row): array {
            $row = (array) $row;
            $row['code'] = self::normalizeCode((string) ($row['code'] ?? ''));
            return $row;
        }, $rows);
    }

    /**
     * 启用的语种列表
     *
     * @return array<int,array<string,mixed>>
     */
    public function enabled(): array
    {
        $rows = RedisCache::remember(self::CACHE_KEY, self::CACHE_TTL, static function (): array {
            try {
                return Language::enabled()->toArray();
            } catch (\Throwable $e) {
                return [];
            }
        });

        // 历史数据兼容：英语统一显示为 en，避免出现 GB / UK 等别名
        $rows = array_map(static function ($row): array {
            $row = (array) $row;
            $row['code'] = self::normalizeCode((string) ($row['code'] ?? ''));
            return $row;
        }, $rows);

        if (is_domestic_edition()) {
            $base = base_locale();
            $filtered = array_values(array_filter($rows, static function ($row) use ($base): bool {
                return strtolower((string) ($row['code'] ?? '')) === $base;
            }));
            if ($filtered) {
                return $filtered;
            }
        }

        return $rows;
    }

    /**
     * 按 code 查找启用语种（大小写不敏感）
     *
     * @param string $code 语言短码
     * @return array<string,mixed>|null
     */
    public function find(string $code): ?array
    {
        $code = self::normalizeCode($code);
        if ($code === '') {
            return null;
        }
        foreach ($this->enabled() as $language) {
            if (strtolower((string) $language['code']) === $code) {
                return $language;
            }
        }
        return null;
    }

    /**
     * 新增 / 编辑语种（后台页面与管理 API 共用）
     *
     * @param array<string,mixed> $data 字段：code、name、native_name、direction、default_currency、status、sort
     * @param int $id 0 表示新增
     * @return Language
     * @throws BizException
     */
    public function save(array $data, int $id = 0): Language
    {
        $code       = self::normalizeCode((string) ($data['code'] ?? ''));
        $name       = trim((string) ($data['name'] ?? ''));
        $nativeName = trim((string) ($data['native_name'] ?? ''));
        $direction  = (string) ($data['direction'] ?? 'ltr');
        $currency   = strtoupper(trim((string) ($data['default_currency'] ?? '')));
        $status     = (int) ($data['status'] ?? 1) === 1 ? 1 : 0;
        $sort       = (int) ($data['sort'] ?? 0);

        if (!preg_match('/^[a-z]{2}(-[a-z]{2,4})?$/', $code)) {
            throw new BizException('语言代码格式不正确，例如 en、zh、pt-br');
        }
        if ($name === '' || $nativeName === '') {
            throw new BizException('请填写语种名称与原生名称');
        }
        if (!in_array($direction, ['ltr', 'rtl'], true)) {
            $direction = 'ltr';
        }
        if ($currency !== '' && !preg_match('/^[A-Z]{3}$/', $currency)) {
            throw new BizException('默认币种请填写 3 位代码，如 USD');
        }

        $exists = Language::where('code', $code)->where('id', '<>', $id)->find();
        if ($exists) {
            throw new BizException('语言代码 ' . $code . ' 已存在');
        }

        if ($id > 0) {
            $row = Language::find($id);
            if (!$row) {
                throw new BizException('语种不存在或已被删除');
            }
            // 默认语种（模板源语言）不允许停用，保证兜底链路可用
            if ((int) $row->is_default === 1) {
                $status = 1;
            }
        } else {
            $row = new Language();
            $row->is_default = 0;
        }

        $row->code             = $code;
        $row->name             = $name;
        $row->native_name      = $nativeName;
        $row->direction        = $direction;
        $row->default_currency = $currency !== '' ? $currency : null;
        $row->status           = $status;
        $row->sort             = $sort;
        $row->save();

        $this->flush();

        return $row;
    }

    /**
     * 默认语种
     *
     * @return array<string,mixed>
     */
    public function default(): array
    {
        $base = base_locale();
        foreach ($this->enabled() as $language) {
            if (strtolower((string) $language['code']) === $base) {
                return $language;
            }
        }
        foreach ($this->enabled() as $language) {
            if ((int) ($language['is_default'] ?? 0) === 1) {
                return $language;
            }
        }
        $all = $this->enabled();
        return $all[0] ?? [
            'code'             => $base,
            'name'             => $base === 'zh' ? '中文' : '英语',
            'native_name'      => $base === 'zh' ? '中文' : 'English',
            'direction'        => 'ltr',
            'default_currency' => base_currency_code(),
            'is_default'       => 1,
            'status'           => 1,
        ];
    }

    /**
     * 清除缓存（后台保存语种后调用）
     */
    public function flush(): void
    {
        RedisCache::forget(self::CACHE_KEY);
    }
}