# 多语种与多货币实现说明

> 范围：独立站前台（`index`）、消费者接口（`api`）、管理后台（`admin` / `admin-api`）。
> 配套流程检查表：[`docs/i18n-multicurrency-checklist.md`](./i18n-multicurrency-checklist.md)
> 国内版/国际版部署：[`docs/site-edition-mode.md`](./site-edition-mode.md)

> 站点版本：`site.edition` 决定基准语言与基准币种。
> 国际版：`en` + `USD`；国内版：`zh` + `CNY`。两套部署共用代码、各自独立数据库。

## 1. 核心决策

| 项目 | 结论 |
|---|---|
| 基准语言 | 国际版英文（`en`），国内版中文（`zh`） |
| 支持语种 | `en`、`zh`、`ru`、`fr`、`ar`、`ja`、`it`、`de`、`pt`、`es` |
| 语言 URL | 默认语种无前缀；其他语种 `/ru/...`、`/zh/...` |
| 翻译存储 | 翻译副表，按 `(实体 id, lang_code)` 唯一 |
| 基准币种 | 国际版 **USD**，国内版 **CNY**；订单/支付/退款/结算按基准币种 |
| 多货币 | 只做前台参考价展示，不收本币 |
| 汇率来源 | `open.er-api.com` 主、`fawazahmed0` 备，免费接口 |
| 汇率保护 | 不做上下限钳制；无效值或单日变动超过阈值（默认 10%）→ 拒绝更新、保留旧值、告警 |
| AI 翻译 | OpenAI 兼容协议，后台填 `base_url` / `api_key` / `model` |
| AI 发布 | 默认自动发布（`i18n.auto_publish_ai=true`） |

设计取舍：不做本币收款，避免汇兑损失、退款汇兑损益、支付渠道币种矩阵与 PayPal pending 问题。本币只作为「参考价」，结算页明确提示实际以 USD 扣款。

---

## 2. 业务流程图

### 2.1 语言与币种解析

```
请求
  │
  ├─ LocalePrefix（全局最前，MultiApp 之前）
  │    ├─ 第一段命中已启用语种？→ 剥离前缀，记录 LocaleContext::prefix
  │    └─ 否 → 不动
  │
  ├─ MultiApp 解析应用（index / api / admin / adminapi）
  │
  └─ 语言：URL 前缀指定语种（/zh/products/1）；无前缀一律默认语种（/products/1）
     币种：?currency= > Cookie site_currency > 语种 default_currency > USD
```

- 同一 URL 永远返回同一内容：无前缀 URL 不读 Cookie / Accept-Language，不做 302 自动跳转；
- 浏览器语言与页面语种不同时，由前端「语言建议」弹框询问是否切换（可忽略，记住 30 天）；
- 根路径带 `Vary: Accept-Language, Cookie`；
- 手动选择写入 1 年 Cookie（仅币种沿用 Cookie；语言完全由 URL 前缀决定）。

### 2.2 翻译写入

```
后台手工编辑 ─┐
AI 任务完成  ─┼─▶ TranslationService::saveTranslations()
批量补全     ─┘        │
                       ├─ 校验语种、长度、HTML 白名单
                       ├─ 空字段存 NULL（前台回退英文）
                       ├─ 写 source / status / source_hash
                       └─ 清理商品详情缓存
```

AI 任务状态机：

```
pending → running → done
              │
              └─ 失败 → pending（指数退避）→ 3 次后 dead
```

### 2.3 汇率同步

```
currency:sync
  ├─ 拉取主源；失败切备用
  ├─ 逐币种校验：非数字 / ≤0 / 单日变动 > 阈值
  │     └─ rejected：保留旧汇率、写日志、发告警
  └─ accepted：更新 rate / rate_updated_at / 来源
```

### 2.4 下单与展示

```
商品价格（USD）
  ├─ 前台展示：USD × 展示汇率 → 本币参考价（format_money）
  └─ 下单：订单金额仍为 USD
        ├─ order.display_currency / display_rate / display_total_amount 快照
        ├─ Stripe / PayPal 固定 USD 扣款
        └─ 订单详情：USD 实付 + ≈ 本币参考价
```

---

## 3. 数据库变更

迁移文件（已按顺序执行）：

| 迁移 | 内容 |
|---|---|
| `000033_create_language_translation.php` | `language`、`product_translation`、`category_translation`、`brand_translation`、`page_translation` |
| `000034_create_currency.php` | `currency`、`currency_rate_log` |
| `000035_create_translation_job.php` | `translation_job` |
| `000036_add_order_display_snapshot.php` | `order.display_currency` / `display_rate` / `display_total_amount` / `display_rate_at` |
| `000037_add_order_charge_currency.php` | `order.charge_currency`、`order_pay.charge_currency` |

关键字段：

- `language`：`code`、`name`、`native_name`、`direction`、`default_currency`、`status`、`is_default`、`sort`
- 翻译表：`lang_code`、业务字段、`source`（ai/manual）、`status`（0 草稿 / 1 发布）、`stale`、`source_hash`、`reviewed_by/at`
- `currency`：`code`、`symbol`、`decimals`、`symbol_position`、`rate`、`rate_override`、`rate_source`、`rate_updated_at`、`status`、`sort`
- `currency_rate_log`：`raw_rate`、`applied_rate`、`prev_rate`、`change_percent`、`status`、`source`、`effective_date`、`message`
- `translation_job`：`entity_type`、`entity_id`、`target_lang`、`fields_json`、`status`、`attempts`、`error`、`next_retry_at`、`cost`
- `order.display_*`：仅参考价快照，不参与支付/退款/结算
- `order.charge_currency` / `order_pay.charge_currency`：订单/支付金额所属币种（国际版 USD、国内版 CNY）

---

## 4. 代码结构

### 4.1 模型

`app/common/model/`

- `Language`、`Currency`、`CurrencyRateLog`
- `ProductTranslation`、`CategoryTranslation`、`BrandTranslation`、`PageTranslation`
- `TranslationJob`

`Product` / `Category` / `Brand` / `Page` 增加 `translations()` 关联。

### 4.2 服务

`app/common/service/`

| 服务 | 职责 |
|---|---|
| `LanguageService` | 启用语种、默认语种、按码查找（Redis 缓存 10 分钟） |
| `CurrencyService` | 展示币种、汇率同步/校验/历史、后台 CRUD、人工覆盖 |
| `PricingService` | USD → 展示币种换算与格式化 |
| `TranslationService` | 译文读取、逐字段回退、保存/发布、源内容快照 |
| `TranslationJobService` | 入队、抢占、执行、重试、预算与成本 |
| `StorefrontService` | 商品/分类/品牌/单页译文接入、价格展示 |
| `OrderService` | 订单展示快照、USD 实付 + 本币参考价 |
| `PageService` | CMS 单页译文 |
| `AdminCrudService` | 商品保存时同事务写翻译、翻译管理 API |

### 4.3 中间件与上下文

- `app/common/middleware/LocalePrefix.php`
  - 通过 `AppService::boot()` 在 `HttpRun` 事件 `unshift` 到全局最前
  - 必须在 MultiApp 之前剥离语言前缀
- `app/common/support/LocaleContext.php`
  - 当前语言、展示币种、URL 前缀

> **禁止创建 `app/index/middleware.php`**：会让 `app/index/` 目录存在，MultiApp 切换默认应用路径，导致 `app\index\controller\Index` 不存在、全站 500。

### 4.4 命令

| 命令 | 说明 |
|---|---|
| `php think currency:sync [--currency=EUR] [--dry-run]` | 同步汇率 |
| `php think currency:selftest` | 展示价换算自测（不依赖 DB） |
| `php think translate:work [--once] [--limit=20] [--sleep=3]` | AI 翻译 worker |
| `php think translate:backfill --type=all --lang=ru,fr --limit=100 [--force]` | 批量补全翻译 |

### 4.5 公共函数

`app/common.php`

- `current_locale()`
- `display_currency()`
- `format_money($usd, ?array $currency)`
- `localized_url($path, ?string $locale)`
- `site_lang($key, $replace)`

---

## 5. 后台功能

### 5.1 商品编辑页

路径：`/admin/products/create`、`/admin/products/edit?id=`

「多语种内容」区：

- 语种标签（除 `en`）
- 标题 / 副标题 / 详情 HTML / SEO 标题 / SEO 描述
- 发布开关
- 状态徽标：未翻译 / 草稿 / 已发布 / 已校对
- AI 翻译按钮（入队 → 轮询 → 回填）
- 清空回退英文

保存时 `translations` 与商品、SKU **同一事务**提交。

商品列表（超管）提供「批量补全翻译」。

### 5.2 货币与汇率

路径：`/admin/currencies`（财务 → 货币与汇率，平台超管）

- 币种名称、符号、小数位、符号位置、启停
- 当前汇率 / 人工覆盖
- 单币种刷新、全部同步
- 汇率历史
- 新增 / 删除币种

### 5.3 菜单

`config/admin_menu.php` 新增：

- 财务 → 货币与汇率（`roles: ['super']`）

---

## 6. 管理 API

### 6.1 商品翻译

| 方法 | 路径 |
|---|---|
| GET | `/admin-api/v1/products/:id/translations` |
| PUT | `/admin-api/v1/products/:id/translations/:lang` |
| POST | `/admin-api/v1/products/:id/translations/:lang/publish` |
| POST | `/admin-api/v1/products/:id/translations/:lang/ai` |

### 6.2 AI 任务

| 方法 | 路径 |
|---|---|
| GET | `/admin-api/v1/translation-jobs` |
| POST | `/admin-api/v1/translation-jobs/:id/retry` |
| POST | `/admin-api/v1/translations/backfill` |

### 6.3 币种与汇率

| 方法 | 路径 |
|---|---|
| GET / POST | `/admin-api/v1/currencies` |
| PUT / DELETE | `/admin-api/v1/currencies/:id` |
| POST | `/admin-api/v1/currencies/:id/rate/refresh` |
| PUT / DELETE | `/admin-api/v1/currencies/:id/rate/override` |
| GET | `/admin-api/v1/currency-rates` |

所有写操作自动进入 `admin_audit_log`。任务列表 / 批量补全 / 币种管理仅平台超管；商品单条翻译按商品所属商户校验范围。

---

## 7. 前台与 SEO

- URL：
  - 默认：`/products/12`
  - 俄语：`/ru/products/12`
- `html lang` / `dir` 动态输出，阿语 `rtl`
- `<link rel="canonical">`
- 每种启用语种 `hreflang` + `x-default`
- `GET /sitemap.xml`：商品、分类、单页、政策页，带全部语种 `xhtml:link`
- 语言切换器、币种切换器在页脚
- 商品价格：`format_money()` 输出展示币种
- 结算页：USD 实付 + ≈ 本币参考价 + 换汇提示

---

## 8. 配置项

后台「系统设置」新增：

### 站点版本

| 键 | 默认 | 说明 |
|---|---|---|
| `site.edition` | international | `international` / `domestic`，决定基准语言与基准币种 |

> 通过「系统与安全 → 站点版本」切换，不在普通设置表单里直接编辑。

### 多语言

| 键 | 默认 | 说明 |
|---|---|---|
| `i18n.enabled` | false | 多语言总开关 |
| `i18n.default_locale` | en | 默认语种 |
| `i18n.auto_detect` | true | 按浏览器语言识别 |
| `i18n.auto_publish_ai` | true | AI 结果直接发布 |
| `i18n.auto_translate_on_save` | false | 保存商品自动入队 |
| `i18n.fallback_to_base` | true | 缺失译文回退英文 |

### 多货币展示

| 键 | 默认 | 说明 |
|---|---|---|
| `currency.enabled` | false | 多货币展示开关 |
| `currency.provider` | open.er-api | 汇率源 |
| `currency.sync_time` | 00:10 | 每日同步时间（供运维参考） |
| `currency.default_code` | USD | 默认展示币种 |
| `currency.sanity_percent` | 10 | 单日变动阈值 |
| `currency.alert_email` | 空 | 汇率异常告警邮箱 |

### AI 翻译

| 键 | 默认 | 说明 |
|---|---|---|
| `translation.base_url` | 空 | OpenAI 兼容地址 |
| `translation.api_key` | 空 | API Key（secret，不回显） |
| `translation.model` | 空 | 模型 ID |
| `translation.temperature` | 0.3 | 仅关闭思考模式时生效 |
| `translation.thinking` | enabled | DeepSeek 思考模式：`enabled` 请求体带 `thinking.type=enabled` + `reasoning_effort`；`disabled` 普通模式 |
| `translation.reasoning_effort` | low | 思考强度：`low` / `high` / `max` |
| `translation.timeout` | 120 | 单次 AI 请求超时（秒） |
| `translation.max_chars` | 6000 | 单次最大字符数 |
| `translation.daily_budget` | 5 | 每日预算 USD |
| `translation.price_per_1k` | 0.002 | 每 1K token 成本 |

### 队列与 worker

- 任务存 MySQL `translation_job`（状态/成本/错误的事实来源），调度走 Redis：
  - `b2cshop:translation:queue:ready`（ZSET，按 priority + 入队时间排序）
  - `b2cshop:translation:queue:delayed`（ZSET，失败退避重试）
  - `b2cshop:translation:queue:processing`（LIST，崩溃恢复用）
- **单消费者**：`translate:work` 启动时抢全局锁 `lock:translate:worker`（TTL 30 分钟，每个任务前续期）；
  第二个 worker 会提示退出。同一时间只有一个任务在执行。
- worker 启动自动恢复：`processing` 残留、数据库 `running`/`pending` 未入队的任务全部补回 Redis。
- 失败指数退避（60s × 2^n），超过 `max_attempts` 转 `dead` 并清理 Redis 残留。
- 响应解析：优先 `message.content`；为空时回退 `reasoning_content`；剥离 `<think>` 标签；
  `finish_reason=length` 明确报错。

---

## 9. 部署步骤

```bash
# 1. 备份数据库
# 2. 执行迁移
php think migrate:run

# 3. 选择站点版本（后台 系统与安全 → 站点版本）
#    国内版：zh + CNY + 小程序 + 微信/支付宝
#    国际版：en + USD + 独立站 + Stripe/PayPal

# 4. 确认新表
php think migrate:status

# 4. 配置 AI（后台「系统设置 → AI 翻译」）
# 5. 配置汇率（后台「财务 → 货币与汇率」）
# 6. 开启多语言 / 多货币（后台「系统设置」）
# 7. 启动翻译 worker（Supervisor / systemd，单消费者）
#    不要启动多个实例：抢不到锁的实例会自动退出
php think translate:work --sleep=3

# 8. 配置每日汇率同步（cron 00:10）
php think currency:sync

# 9. 批量补全历史翻译
php think translate:backfill --type=all --limit=100
```

环境要求：

- PHP 8.0+，`curl`、`openssl` 扩展
- 生产配置 CA（`curl.cainfo` 或 `CURL_CA_BUNDLE`）；开发环境未配置时 `APP_DEBUG=true` 会临时关闭校验并写日志
- Redis 可用（语种/币种缓存、token、限流、**翻译队列调度**）
- MySQL 版本支持 JSON 字段
- Stripe / PayPal 后台不再需要填币种，固定 USD

---

## 10. 回滚

优先级从高到低：

1. **关闭功能开关**（推荐，无数据风险）
   - `i18n.enabled=false`
   - `currency.enabled=false`
   - 前台恢复单语、USD，订单/支付不受影响
2. **停止 worker / cron**
   - 停 `translate:work`
   - 停 `currency:sync`
3. **代码回滚**
   - 回退本次提交
4. **数据库回滚**（谨慎）
   - `php think migrate:rollback` 会删除翻译表、币种表、任务表，并移除订单展示字段
   - 必须确认已备份；历史订单仅丢失「本币参考价」，USD 金额不受影响

---

## 11. 已知限制

- 分类 / 品牌 / 单页没有后台翻译编辑页，可用 `translate:backfill` 由 AI 填充，或直接改库
- 规格 / SKU 文案由 AI 填充，暂不支持手工逐项编辑
- 新增的英文静态键（筛选、配送、评价、Hero）只有英文基准，其他语种回退英文
- 首页 Hero、About/Service/Contact 内置模板标题未翻译
- sitemap 未做缓存；`robots.txt` 未声明 Sitemap
- 阿拉伯语只做了基础 RTL，完整视觉走查待做
- 小程序端如果继续使用，微信/支付宝仍按 CNY，需单独确认定价策略
- AI Key 与现有 SMTP 密码一样存 `setting` 表（后台不回显），未做加密存储

---

## 12. 变更文件索引

### 新增

```
app/common/middleware/LocalePrefix.php
app/common/support/LocaleContext.php
app/common/lib/CurlTls.php
app/common/lib/translation/TranslationProviderInterface.php
app/common/lib/translation/OpenAiCompatibleProvider.php
app/common/service/LanguageService.php
app/common/service/CurrencyService.php
app/common/service/PricingService.php
app/common/service/TranslationService.php
app/common/service/TranslationJobService.php
app/common/model/{Language,Currency,CurrencyRateLog,TranslationJob}.php
app/common/model/{Product,Category,Brand,Page}Translation.php
app/common/command/{CurrencySync,CurrencySelftest,TranslateWork,TranslateBackfill}.php
app/admin/controller/Currencies.php
app/admin/view/currencies/index.html
app/adminapi/controller/{Currency,Translation}.php
app/controller/Sitemap.php
app/lang/{en,zh,ru,fr,ar,ja,it,de,pt,es}/site.php
database/migrations/000033..000036
```

### 修改

```
app/AppService.php
app/common.php
app/common/service/{StorefrontService,AdminCrudService,OrderService,PageService,PaymentService}.php
app/common/model/{Product,Category,Brand,Page}.php
app/common/lib/payment/{PaymentChannelCatalog,StripeGateway,PaypalGateway,PaymentHttpClient}.php
app/controller/{SiteBase,Index}.php
app/api/controller/Order.php
app/admin/controller/{Products,Orders}.php
app/adminapi/controller/Product.php
app/admin/route/admin.php
app/adminapi/route/adminapi.php
route/app.php
app/view/site/{layout/base,index,products,product,checkout,cart,account_orders,account_order_detail}.html
app/admin/view/products/{form,index}.html
app/admin/view/orders/detail.html
config/{site,setting,console,admin_menu}.php
docs/admin-api.md
public/admin-api/openapi.yaml
```