<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\lib\translation\OpenAiCompatibleProvider;
use app\common\lib\translation\TranslationQueue;
use app\common\model\Brand;
use app\common\model\Category;
use app\common\model\Page;
use app\common\model\Product;
use app\common\model\TranslationJob;
use app\common\support\AppContext;
use think\facade\Db;
use think\facade\Log;

/**
 * AI 翻译任务：入队、抢占、执行、重试、成本统计
 *
 * 任务状态以数据库为准；worker 通过原子更新抢占，重启不丢任务。
 */
class TranslationJobService
{
    private TranslationService $translations;

    public function __construct()
    {
        $this->translations = new TranslationService();
    }

    /**
     * 入队一个实体的若干语种
     *
     * @param array<int,string> $locales 目标语种，空数组表示全部启用语种
     * @return array<int,int> 新建的任务 ID
     */
    public function enqueue(string $type, int $id, array $locales = [], bool $force = false, int $priority = 1, ?int $createdBy = null): array
    {
        $source = $this->translations->sourceData($type, $id);
        if (!$source) {
            return [];
        }

        $enabled = $this->translations->targetLocales();
        $locales = $locales ? array_values(array_intersect(array_map('strtolower', $locales), $enabled)) : $enabled;

        $ids = [];
        foreach ($locales as $lang) {
            if (!$force && $this->translations->isUpToDate($type, $id, $lang)) {
                continue;
            }
            $exists = TranslationJob::where('entity_type', $type)
                ->where('entity_id', $id)
                ->where('target_lang', $lang)
                ->whereIn('status', [TranslationJob::STATUS_PENDING, TranslationJob::STATUS_RUNNING])
                ->find();
            if ($exists) {
                continue;
            }

            $job = new TranslationJob();
            $job->entity_type = $type;
            $job->entity_id = $id;
            $job->source_lang = base_locale();
            $job->target_lang = $lang;
            $job->fields_json = $source;
            $job->status = TranslationJob::STATUS_PENDING;
            $job->priority = $priority;
            $job->attempts = 0;
            $job->max_attempts = 3;
            $job->created_by = $createdBy ?? (int) (AppContext::getAdminId() ?? 0);
            $job->save();
            $this->pushSafely((int) $job->id, (int) $job->priority);
            $ids[] = (int) $job->id;
        }

        return $ids;
    }

    /**
     * 批量补全缺失翻译
     *
     * @param string $type product|category|brand|page|all
     * @return array{entities:int,jobs:int}
     */
    public function enqueueMissing(string $type = 'all', array $locales = [], int $limit = 100, bool $force = false): array
    {
        $entities = 0;
        $jobs = 0;
        $types = $type === 'all' ? ['product', 'category', 'brand', 'page'] : [$type];

        foreach ($types as $entityType) {
            $ids = $this->entityIds($entityType, $limit);
            foreach ($ids as $id) {
                $entities++;
                $jobs += count($this->enqueue($entityType, $id, $locales, $force, 5));
            }
        }

        return ['entities' => $entities, 'jobs' => $jobs];
    }

    /**
     * 抢占一个到期任务
     */
    public function claim(): ?TranslationJob
    {
        $now = date('Y-m-d H:i:s');
        $job = TranslationJob::where('status', TranslationJob::STATUS_PENDING)
            ->where(function ($query) use ($now) {
                $query->whereNull('next_retry_at')->whereOr('next_retry_at', '<=', $now);
            })
            ->order('priority', 'desc')
            ->order('id', 'asc')
            ->find();
        if (!$job) {
            return null;
        }

        $affected = Db::name('translation_job')
            ->where('id', (int) $job->id)
            ->where('status', TranslationJob::STATUS_PENDING)
            ->update([
                'status'      => TranslationJob::STATUS_RUNNING,
                'started_at'  => $now,
                'update_time' => $now,
            ]);

        return $affected > 0 ? TranslationJob::find((int) $job->id) : null;
    }

    /**
     * 按 Redis 队列给出的 job id 抢占任务
     *
     * 仅当任务仍为 pending 时才成功，避免重复执行。
     */
    public function claimById(int $jobId): ?TranslationJob
    {
        if ($jobId <= 0) {
            return null;
        }

        $now = date('Y-m-d H:i:s');
        $affected = Db::name('translation_job')
            ->where('id', $jobId)
            ->where('status', TranslationJob::STATUS_PENDING)
            ->update([
                'status'      => TranslationJob::STATUS_RUNNING,
                'started_at'  => $now,
                'update_time' => $now,
            ]);

        return $affected > 0 ? TranslationJob::find($jobId) : null;
    }

    /**
     * 执行一个任务；异常由调用方捕获后 fail()
     *
     * @throws \Throwable
     */
    public function run(TranslationJob $job): void
    {
        $config = $this->config();
        $provider = new OpenAiCompatibleProvider($config);
        $fields = (array) $job->fields_json;
        $target = (string) $job->target_lang;

        $maxChars = max(500, (int) ($config['max_chars'] ?? 6000));
        $result = $this->translateFields($provider, $fields, $target, $maxChars);

        // 源字段非空但 AI 没返回，视为失败，避免写入空译文
        foreach ($fields as $key => $value) {
            if ($key === 'specs_json' || !is_string($value) || trim($value) === '') {
                continue;
            }
            if (trim((string) ($result['fields'][$key] ?? '')) === '') {
                throw new \RuntimeException('AI 未返回字段：' . $key);
            }
        }

        $status = (bool) site_config('i18n.auto_publish_ai', true) ? 1 : 0;
        $this->translations->saveTranslations((string) $job->entity_type, (int) $job->entity_id, [
            $target => array_merge($result['fields'], [
                'source' => 'ai',
                'status' => $status,
            ]),
        ]);

        $job->status = TranslationJob::STATUS_DONE;
        $job->provider = 'openai-compatible';
        $job->model = (string) ($config['model'] ?? '');
        $job->input_chars = mb_strlen(json_encode($fields, JSON_UNESCAPED_UNICODE) ?: '');
        $job->output_chars = mb_strlen(json_encode($result['fields'], JSON_UNESCAPED_UNICODE) ?: '');
        $job->cost = $result['cost'];
        $job->error = null;
        $job->finished_at = date('Y-m-d H:i:s');
        $job->save();
    }

    /**
     * 任务失败：指数退避，超过最大次数转 dead
     *
     * @return array{status:string,next_retry_at:?string}
     */
    public function fail(TranslationJob $job, \Throwable $e): array
    {
        $attempts = (int) $job->attempts + 1;
        $max = max(1, (int) $job->max_attempts);
        $now = date('Y-m-d H:i:s');

        $update = [
            'attempts'    => $attempts,
            'error'       => mb_substr($e->getMessage(), 0, 500),
            'update_time' => $now,
        ];
        $nextRetry = null;
        if ($attempts >= $max) {
            $update['status'] = TranslationJob::STATUS_DEAD;
            $update['finished_at'] = $now;
        } else {
            $nextRetry = date('Y-m-d H:i:s', time() + 60 * (2 ** $attempts));
            $update['status'] = TranslationJob::STATUS_PENDING;
            $update['next_retry_at'] = $nextRetry;
        }

        Db::name('translation_job')->where('id', (int) $job->id)->update($update);

        // Redis 队列同步：pending 进入延迟队列，dead 清理所有残留
        if ($update['status'] === TranslationJob::STATUS_DEAD) {
            $this->ackQueueSafely((int) $job->id);
        } else {
            $this->delayQueueSafely((int) $job->id, (int) strtotime((string) $nextRetry));
        }

        return [
            'status'        => (string) $update['status'],
            'next_retry_at' => $nextRetry,
        ];
    }

    /**
     * 人工重试
     */
    public function retry(int $jobId): void
    {
        $job = TranslationJob::find($jobId);
        if (!$job) {
            throw new \app\common\exception\BizException('翻译任务不存在');
        }
        Db::name('translation_job')->where('id', $jobId)->update([
            'status'         => TranslationJob::STATUS_PENDING,
            'attempts'       => 0,
            'error'          => null,
            'next_retry_at'  => null,
            'started_at'     => null,
            'finished_at'    => null,
            'update_time'    => date('Y-m-d H:i:s'),
        ]);

        $this->pushSafely($jobId, (int) $job->priority);
    }

    /**
     * worker 启动恢复：processing / running / pending -> Redis
     *
     * @return array{reset:int,queued:int,processing:int}
     */
    public function recoverQueue(): array
    {
        $queue = new TranslationQueue();
        $reset = 0;
        $queued = 0;

        $processingIds = $queue->processingIds();
        $processing = array_fill_keys($processingIds, true);

        foreach ($processingIds as $id) {
            $job = TranslationJob::find($id);
            if (!$job || in_array($job->status, [
                TranslationJob::STATUS_DONE,
                TranslationJob::STATUS_DEAD,
                TranslationJob::STATUS_FAILED,
                TranslationJob::STATUS_SKIPPED,
            ], true)) {
                $queue->ack($id);
                continue;
            }

            if ($job->status === TranslationJob::STATUS_RUNNING) {
                $this->resetForQueue($id);
                $reset++;
            }
            $queue->push($id, (int) $job->priority);
            $queued++;
        }

        // 数据库 running 但不在 processing：上次进程异常退出
        foreach (TranslationJob::where('status', TranslationJob::STATUS_RUNNING)->select() as $job) {
            $id = (int) $job->id;
            if (isset($processing[$id])) {
                continue;
            }
            $this->resetForQueue($id);
            $queue->push($id, (int) $job->priority);
            $reset++;
            $queued++;
        }

        // 数据库 pending：到期进 ready，未来进 delayed
        $now = time();
        foreach (TranslationJob::where('status', TranslationJob::STATUS_PENDING)->select() as $job) {
            $id = (int) $job->id;
            $runAt = $job->next_retry_at ? (int) strtotime((string) $job->next_retry_at) : 0;
            if ($runAt > $now) {
                $queue->delay($id, $runAt);
            } else {
                $queue->push($id, (int) $job->priority);
            }
            $queued++;
        }

        return [
            'reset'      => $reset,
            'queued'     => $queued,
            'processing' => count($processingIds),
        ];
    }

    /**
     * 将 running 任务重置为 pending，由队列重新抢占
     */
    private function resetForQueue(int $jobId): void
    {
        Db::name('translation_job')->where('id', $jobId)->update([
            'status'        => TranslationJob::STATUS_PENDING,
            'next_retry_at' => null,
            'started_at'    => null,
            'update_time'   => date('Y-m-d H:i:s'),
        ]);
    }

    /**
     * Redis 写失败不阻断数据库任务：任务保持 pending，worker 启动恢复时会补入。
     */
    private function pushSafely(int $jobId, int $priority): void
    {
        try {
            TranslationQueue::push($jobId, $priority);
        } catch (\Throwable $e) {
            Log::error('translation queue push failed: job=' . $jobId . ' ' . $e->getMessage());
        }
    }

    private function delayQueueSafely(int $jobId, int $runAt): void
    {
        try {
            TranslationQueue::delay($jobId, $runAt);
        } catch (\Throwable $e) {
            Log::error('translation queue delay failed: job=' . $jobId . ' ' . $e->getMessage());
        }
    }

    private function ackQueueSafely(int $jobId): void
    {
        try {
            TranslationQueue::ack($jobId);
        } catch (\Throwable $e) {
            Log::error('translation queue ack failed: job=' . $jobId . ' ' . $e->getMessage());
        }
    }

    /**
     * 今日已花费（估算）
     */
    public function todayCost(): float
    {
        return (float) TranslationJob::where('create_time', '>=', date('Y-m-d 00:00:00'))->sum('cost');
    }

    /**
     * 是否超出今日预算
     */
    public function isBudgetExceeded(): bool
    {
        $budget = (float) site_config('translation.daily_budget', 0);
        return $budget > 0 && $this->todayCost() >= $budget;
    }

    /**
     * 后台展示用任务字段
     *
     * @return array<string,mixed>
     */
    public function payload(TranslationJob $job): array
    {
        return [
            'id'           => (int) $job->id,
            'entity_type'  => (string) $job->entity_type,
            'entity_id'    => (int) $job->entity_id,
            'target_lang'  => (string) $job->target_lang,
            'status'       => (string) $job->status,
            'attempts'     => (int) $job->attempts,
            'max_attempts' => (int) $job->max_attempts,
            'provider'     => (string) ($job->provider ?? ''),
            'model'        => (string) ($job->model ?? ''),
            'cost'         => (string) $job->cost,
            'error'        => (string) ($job->error ?? ''),
            'next_retry_at'=> $job->next_retry_at ? (string) $job->next_retry_at : '',
            'finished_at'  => $job->finished_at ? (string) $job->finished_at : '',
            'create_time'  => (string) ($job->create_time ?? ''),
        ];
    }

    /**
     * 后台配置
     *
     * @return array<string,mixed>
     */
    public function config(): array
    {
        $config = (array) site_config('translation', []);
        $config['base_url'] = trim((string) ($config['base_url'] ?? ''));
        $config['api_key'] = trim((string) ($config['api_key'] ?? ''));
        $config['model'] = trim((string) ($config['model'] ?? ''));
        $config['temperature'] = (float) ($config['temperature'] ?? 0.3);
        $config['max_chars'] = max(500, (int) ($config['max_chars'] ?? 6000));
        $config['daily_budget'] = max(0, (float) ($config['daily_budget'] ?? 0));
        $config['price_per_1k'] = max(0, (float) ($config['price_per_1k'] ?? 0.002));
        $config['thinking'] = in_array(strtolower((string) ($config['thinking'] ?? 'enabled')), ['enabled', 'disabled'], true)
            ? strtolower((string) ($config['thinking'] ?? 'enabled'))
            : 'enabled';
        $config['reasoning_effort'] = in_array(strtolower((string) ($config['reasoning_effort'] ?? 'low')), ['low', 'high', 'max'], true)
            ? strtolower((string) ($config['reasoning_effort'] ?? 'low'))
            : 'low';
        $config['timeout'] = max(10, (int) ($config['timeout'] ?? 120));
        return $config;
    }

    /**
     * 翻译字段，detail_html 超长时按块切分
     *
     * @param array<string,mixed> $fields
     * @return array{fields:array<string,mixed>,cost:float}
     */
    private function translateFields(OpenAiCompatibleProvider $provider, array $fields, string $target, int $maxChars): array
    {
        $config = $this->config();
        $price = (float) $config['price_per_1k'];
        $tokens = ['prompt' => 0, 'completion' => 0];

        $detail = (string) ($fields['detail_html'] ?? '');
        [$detail, $images] = $this->protectImages($detail);
        if ($images !== []) {
            // 图片标签改为占位符送入 AI，避免模型翻译时丢失或改写
            $fields['detail_html'] = $detail;
        }

        if (mb_strlen($detail) <= $maxChars) {
            $result = $provider->translate($fields, base_locale(), $target);
            $tokens['prompt'] += $result['usage']['prompt_tokens'] ?? 0;
            $tokens['completion'] += $result['usage']['completion_tokens'] ?? 0;
            $translated = $result['fields'];
        } else {
            $withoutDetail = $fields;
            $withoutDetail['detail_html'] = '';
            $baseResult = $provider->translate($withoutDetail, base_locale(), $target);
            $tokens['prompt'] += $baseResult['usage']['prompt_tokens'] ?? 0;
            $tokens['completion'] += $baseResult['usage']['completion_tokens'] ?? 0;
            $translated = $baseResult['fields'];

            $detailParts = [];
            foreach ($this->splitHtml($detail, $maxChars) as $chunk) {
                $chunkResult = $provider->translate(['detail_html' => $chunk], base_locale(), $target);
                $tokens['prompt'] += $chunkResult['usage']['prompt_tokens'] ?? 0;
                $tokens['completion'] += $chunkResult['usage']['completion_tokens'] ?? 0;
                $detailParts[] = (string) ($chunkResult['fields']['detail_html'] ?? '');
            }
            $translated['detail_html'] = implode('', $detailParts);
        }

        if ($images !== [] && is_array($translated)) {
            $translated['detail_html'] = $this->restoreImages((string) ($translated['detail_html'] ?? ''), $images);
        }

        $cost = (($tokens['prompt'] + $tokens['completion']) / 1000) * $price;
        return ['fields' => is_array($translated) ? $translated : [], 'cost' => round($cost, 6)];
    }

    /**
     * 将 detail_html 中的 <img> 标签替换为占位符，保护其不参与翻译
     *
     * @return array{0:string,1:array<int,string>} [替换后的 HTML, 图片标签列表]
     */
    private function protectImages(string $html): array
    {
        if (stripos($html, '<img') === false) {
            return [$html, []];
        }
        $images = [];
        $out = preg_replace_callback('/<img\b[^>]*>/i', static function (array $m) use (&$images): string {
            $token = '[[ALMIIMG' . count($images) . ']]';
            $images[] = $m[0];
            return $token;
        }, $html) ?? $html;
        return [$out, $images];
    }

    /**
     * 翻译结束后从占位符还原图片标签；模型漏掉的占位符按原文顺序回补
     *
     * @param array<int,string> $images protectImages 返回的图片标签列表
     */
    private function restoreImages(string $text, array $images): string
    {
        $text = preg_replace_callback('/\[\[ALMIIMG(\d+)\]\]/i', static function (array $m) use ($images): string {
            return $images[(int) $m[1]] ?? '';
        }, $text) ?? $text;

        foreach ($images as $index => $tag) {
            if (strpos($text, (string) $tag) === false) {
                $text .= $tag;
            }
        }
        return $text;
    }

    /**
     * 按块级标签切分 HTML，避免截断标签
     *
     * @return array<int,string>
     */
    private function splitHtml(string $html, int $maxChars): array
    {
        $parts = preg_split('/(?<=<\/(?:p|div|li|h[1-6])>)/i', $html) ?: [$html];
        $chunks = [];
        $buffer = '';
        foreach ($parts as $part) {
            if ($buffer !== '' && mb_strlen($buffer . $part) > $maxChars) {
                $chunks[] = $buffer;
                $buffer = $part;
            } else {
                $buffer .= $part;
            }
        }
        if (trim($buffer) !== '') {
            $chunks[] = $buffer;
        }
        return $chunks ?: [$html];
    }

    /**
     * @return array<int,int>
     */
    private function entityIds(string $type, int $limit): array
    {
        $limit = max(1, min(1000, $limit));
        $query = match ($type) {
            'product'  => Product::where('status', 1)->whereNull('delete_time'),
            'category' => Category::where(1),
            'brand'    => Brand::where(1),
            'page'     => Page::where('status', 1),
            default    => null,
        };
        if (!$query) {
            return [];
        }
        return array_map('intval', $query->order('id', 'asc')->limit($limit)->column('id'));
    }
}