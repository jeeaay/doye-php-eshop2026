<?php
declare(strict_types=1);

namespace app\common\middleware;

use app\common\service\CurrencyService;
use app\common\service\LanguageService;
use app\common\support\LocaleContext;
use think\facade\Cookie;
use think\Request;
use think\Response;

/**
 * 前台 / API 的语言与展示币种引导
 *
 * 这个中间件被 unshift 到全局队列最前面，原因是 think-multi-app 会把 URL 第一段
 * 当作应用名：/ru/products 会被解析成 app=ru 而 404。所以必须在 MultiApp 之前
 * 剥离语言前缀，并同时完成语言/币种解析。
 *
 * 语言解析规则：URL 前缀指定语种（/zh/products/1）；无前缀一律默认语种（/products/1）
 * 币种优先级：?currency= > Cookie site_currency > 语种 default_currency > USD
 */
class LocalePrefix
{
    private const COOKIE_TTL = 31536000; // 1 年

    /**
     * @param Request $request
     * @param \Closure $next
     * @return Response
     */
    public function handle(Request $request, \Closure $next)
    {
        $path = trim((string) $request->pathinfo(), '/');
        $segments = $path === '' ? [] : explode('/', $path);
        $first = strtolower((string) ($segments[0] ?? ''));
        $second = strtolower((string) ($segments[1] ?? ''));
        $isApi = $first === 'api';
        $isAdmin = in_array($first, ['admin', 'admin-api'], true);

        // 多语言关闭或国内版：只写入默认上下文，保持单语行为
        if (is_domestic_edition() || !(bool) site_config('i18n.enabled', false)) {
            LocaleContext::setLocale($this->defaultLanguage());
            LocaleContext::setCurrency($this->baseCurrency());
            return $next($request);
        }

        $languages = new LanguageService();
        $currencies = new CurrencyService();
        $defaultLanguage = $languages->default();

        // 1) 剥离语言前缀（在 MultiApp 之前）
        $prefixed = null;
        if (preg_match('/^[a-z]{2}$/', $first)
            && !in_array($second, ['admin', 'admin-api', 'api'], true)) {
            $prefixed = $languages->find($first);
            if ($prefixed) {
                LocaleContext::setPrefix($first);
                array_shift($segments);
                $path = implode('/', $segments);
                $request->setPathinfo($path);
            }
        }

        // 2) 语言解析：无前缀 URL 一律使用默认语种（Cookie / Accept-Language 只影响自动跳转历史，不再参与解析）
        $language = $prefixed ?? $defaultLanguage;
        LocaleContext::setLocale($language);

        // 3) 展示币种
        $currency = $this->resolveCurrency($request, $currencies, $language);
        LocaleContext::setCurrency($currency);

        // 4) 让 ?currency 选择在后续请求中保持
        if ($request->get('currency', '') !== '') {
            Cookie::set('site_currency', (string) $currency['code'], self::COOKIE_TTL);
        }

        $response = $next($request);

        // 根路径内容随语言变化，声明 Vary 避免 CDN 串语种
        if (!$isApi && !$isAdmin && $path === '') {
            $response->header(['Vary' => 'Accept-Language, Cookie']);
        }

        return $response;
    }

    /**
     * 展示币种解析
     *
     * @param array<string,mixed> $language
     * @return array<string,mixed>
     */
    private function resolveCurrency(Request $request, CurrencyService $currencies, array $language): array
    {
        if (!(bool) site_config('currency.enabled', false)) {
            return $currencies->base();
        }

        $query = trim((string) $request->get('currency', ''));
        if ($query !== '' && ($found = $currencies->find($query))) {
            return $found;
        }

        $cookie = trim((string) $request->cookie('site_currency', ''));
        if ($cookie !== '' && ($found = $currencies->find($cookie))) {
            return $found;
        }

        $default = (string) ($language['default_currency'] ?? '');
        return $default !== '' ? ($currencies->find($default) ?? $currencies->base()) : $currencies->base();
    }

    /**
     * @return array<string,mixed>
     */
    private function defaultLanguage(): array
    {
        try {
            return (new LanguageService())->default();
        } catch (\Throwable $e) {
            $code = base_locale();
            return [
                'code'             => $code,
                'name'             => $code === 'zh' ? '中文' : '英语',
                'native_name'      => $code === 'zh' ? '中文' : 'English',
                'direction'        => 'ltr',
                'default_currency' => base_currency_code(),
                'is_default'       => 1,
                'status'           => 1,
            ];
        }
    }

    /**
     * @return array<string,mixed>
     */
    private function baseCurrency(): array
    {
        try {
            return (new CurrencyService())->base();
        } catch (\Throwable $e) {
            $code = base_currency_code();
            $isCny = $code === 'CNY';
            return [
                'code'            => $code,
                'name'            => $isCny ? '人民币' : '美元',
                'symbol'          => $isCny ? '¥' : '$',
                'decimals'        => 2,
                'symbol_position' => 'before',
                'symbol_space'    => 0,
                'is_base'         => 1,
                'rate'            => 1,
                'rate_override'   => null,
                'status'          => 1,
            ];
        }
    }
}