<?php
/**
 * 前台静态文案（简体中文）
 */
return [
    'nav.home'     => '首页',
    'nav.products' => '全部商品',
    'nav.service'  => '服务',
    'nav.about'    => '关于我们',
    'nav.contact'  => '联系我们',

    'header.search'   => '今天想找点什么？',
    'header.account'  => '账户',
    'header.cart'     => '购物车',
    'header.wishlist' => '心愿单',
    'header.menu'     => '菜单',
    'header.close'    => '关闭',

    'footer.newsletter_title' => '订阅立享首单 9 折！',
    'footer.newsletter_text'  => '订阅我们的邮件，获取最新动态与专属优惠，首单还可享 9 折。',
    'footer.email'            => '请输入邮箱地址',
    'footer.signup'           => '订阅',
    'footer.customer_care'    => '客户服务',
    'footer.contact'          => '联系我们',
    'footer.track_order'      => '查询订单',
    'footer.shipping'         => '配送说明',
    'footer.returns'          => '退款与退货政策',
    'footer.about_legal'      => '关于与法律',
    'footer.about'            => '关于',
    'footer.terms'            => '条款与条件',
    'footer.privacy'          => '隐私政策',
    'footer.cookies'          => 'Cookie 政策',
    'footer.collections'      => '商品分类',
    'footer.my_account'       => '我的账户',
    'footer.account'          => '我的账户',
    'footer.orders'           => '我的订单',
    'footer.addresses'        => '我的地址',
    'footer.wishlist'         => '我的心愿单',
    'footer.accessibility'    => '无障碍声明',
    'footer.cookie_policy'    => 'Cookie 政策',
    'footer.security'         => '安全政策',

    'common.all_products'      => '全部商品',
    'common.breadcrumb_home'   => '首页',
    'common.all_products_desc' => '浏览我们完整的家居收纳与整理方案，从厨房到卧室，发现创新且节省空间的设计。',
    'common.add_to_bag'        => '加入购物车',
    'common.adding'            => '添加中...',
    'common.added'             => '已添加',
    'common.buy_now'           => '立即购买',
    'common.details'           => '商品详情',
    'common.specifications'    => '规格参数',
    'common.shipping_returns'  => '配送与退货',
    'common.reviews'           => '用户评价',
    'common.related_products'  => '相关商品',
    'common.free_delivery'     => '订单满 $80 免运费*',
    'common.quantity'          => '数量选择',

    'common.charged_in'        => '将以 {currency} 结算',

    'switcher.language' => '语言',
    'switcher.currency' => '货币',

    'hint.language_title' => '此页面提供{name}版本，是否切换？',
    'hint.switch'         => '切换到{name}',
    'hint.stay'           => '不用了',

    'cookie.text'   => '我们使用 Cookie 来改善您的体验并衡量广告效果。',
    'cookie.reject' => '拒绝',
    'cookie.accept' => '接受',

    'checkout.approx'      => '约',
    'checkout.charge_note' => '实际将以 {currency} 结算；本币金额仅供参考，发卡行可能另收换汇费。',
];