# 站点版本（国内版 / 国际版）

> 结论：**两套独立部署，共用同一套代码**。
> 后台通过「站点版本」选择运行形态；在线实例之间互不干扰。
> 配套说明：[`docs/i18n-multicurrency.md`](./i18n-multicurrency.md)

## 1. 两种版本

| 维度 | 国内版 | 国际版 |
|---|---|---|
| 主要入口 | 微信小程序 | 独立站 |
| 结算币种 | **CNY** | **USD** |
| 基准语言 | **简体中文** | **英语** |
| 展示币种 | 仅 CNY | USD + 多币种参考价 |
| 其他语言 | 不做 | 多语言翻译 |
| 支付渠道 | 微信支付、支付宝 | Stripe、PayPal |
| 汇率同步 | 关闭 | 每日同步 |
| 多语言/多货币菜单 | 隐藏/不生效 | 开启 |
| 订单金额 | CNY | USD |

> 版本决定「基准语言 + 基准币种」。主表内容与 SKU 价格按当前版本的基准解释，
> **切换版本不会自动换算价格，也不会自动翻译内容**。

---

## 2. 配置与数据语义

### 2.1 设置项

| 键 | 值 | 说明 |
|---|---|---|
| `site.edition` | `domestic` / `international` | 当前版本；**未写入表示尚未初始化**（新部署或从旧版本升级） |

> 1.0.6 及更早版本没有 `site.edition`。升级后后台会显示「未初始化」，
> 需要在「站点版本」页面显式选择一次历史数据所属版本。
> 未选择前运行时兜底为 `international`，请在升级后尽快完成选择。

派生值（不单独存储，避免不一致）：

| 函数 | 国内版 | 国际版 |
|---|---|---|
| `base_locale()` | `zh` | `en` |
| `base_currency_code()` | `CNY` | `USD` |
| `site_edition()` | `domestic` | `international` |

### 2.2 数据语义

- 国内版部署：
  - 主表（商品/分类/品牌/单页）直接存中文
  - `product_sku.price` 为 CNY
  - 订单 `charge_currency=CNY`
- 国际版部署：
  - 主表存英文
  - `product_sku.price` 为 USD
  - 订单 `charge_currency=USD`
- 两套部署各自一个数据库，不共享商品/订单/支付数据。
- 不做「同一套数据库双价格/双语言」；如未来需要，另行设计。

---

## 3. 后台交互

### 3.1 入口

- 路径：`/admin/edition`
- 菜单：系统与安全 → **站点版本**（仅平台超管）
- 顶部显示：`当前版本：国内版 / 国际版 / 未初始化`

### 3.2 页面

- 两张版本卡片：国内版、国际版
- 卡片展示：币种、语言、入口、支付渠道、功能开关
- 当前版本高亮；未初始化时两张卡片都不高亮
- 显示商品数 / 订单数
- **未初始化**（新部署或旧版本升级）：
  - 顶部显示提示条，要求选择现有数据所属版本
  - 两张卡片的按钮始终可点，文字为「使用国内版（CNY）」「使用国际版（USD）」
  - 即使有历史订单也允许选择一次，因为这是「声明已有数据属于哪个版本」，不是切换
  - 系统按已启用支付渠道给出建议：微信/支付宝 → 国内版；Stripe/PayPal → 国际版
- **已初始化**：
  - 有订单时按钮禁用，并提示「需走迁移流程」
  - 有商品时显示风险提示：不会自动换算/翻译

### 3.3 切换确认

点击卡片按钮后弹出：

- 影响对照表（基准币种、基准语言、价格解释、多语言、支付渠道、汇率同步、小程序）
- 必须勾选备份确认；未初始化时文案为「确认现有数据属于所选版本」
- 必须输入 `SWITCH`
- 两项满足后「确认版本 / 确认切换」才可点击
- 弹窗可通过「取消」、点击遮罩或 `Esc` 关闭

> 页面样式必须保留 `.edition-modal-mask[hidden]{display:none!important}`：
> 遮罩本身是 `display:flex`，否则会覆盖 HTML `hidden` 属性，导致弹窗一进页面就常显。

### 3.4 守卫

| 条件 | 行为 |
|---|---|
| 非超管 | 拒绝 |
| **未初始化（无 `site.edition`）** | **允许选择历史数据版本，即使订单数 > 0**；需备份确认 + 输入 SWITCH |
| 已初始化 + 订单数 > 0 | **禁止切换** |
| 已初始化 + 商品数 > 0 | 需勾选备份确认 + 输入 SWITCH |
| 已初始化 + 商品和订单都为空 | 允许直接切换 |
| 切换成功 | 清语言/币种/设置缓存 |

### 3.5 切换后

- `site.edition`
- `i18n.enabled`：国内版 0，国际版 1
- `i18n.default_locale`：zh / en
- `currency.enabled`：国内版 0，国际版 1
- `currency.default_code`：CNY / USD
- `language.is_default`：仅基准语言为 1
- `currency.is_base`：仅基准币种为 1
- 不修改商品、翻译、支付配置

### 3.6 旧版本升级兼容

1.0.6 及更早版本没有 `site.edition`，也没有订单/支付单的 `charge_currency`。
升级到 1.0.7 后：

1. 页面显示「未初始化」，不会把站点直接锁死为国际版。
2. 管理员选择版本并确认后：
   - 写入 `site.edition`、基准语言、基准币种、多语言/多货币开关；
   - **按所选版本回填历史订单**：
     - 国内版：`order.charge_currency=CNY`、`order_pay.charge_currency=CNY`；
       同时回填 `display_currency=CNY`、`display_rate=1`、`display_total_amount=total_amount`；
     - 国际版：`order.charge_currency=USD`、`order_pay.charge_currency=USD`。
   - 不换算商品价格，不修改 `order.total_amount`。
3. 初始化完成后进入正常守卫：有订单时不能再切换，所以**首次选择必须选对**。
4. 如果选错且已有订单，只能通过数据库迁移/恢复备份修正，不能依赖后台再次切换。

> **升级后切换版本报 `Table 'xxx.language' doesn't exist`**：说明 1.0.7 的
> `000033`–`000037` 迁移没有执行（PHP 8.5 下可能被 `$http_response_header`
> 废弃提示中断）。先执行：
>
> ```bash
> php think migrate:run
> php think migrate:status
> ```
>
> 1.0.9 起已在 CLI 启动时忽略废弃提示，更新器可正常完成迁移步骤；
> 若仍在 1.0.7/1.0.8，可临时使用 PHP 8.2/8.3/8.4 CLI 执行迁移。

---

## 4. 功能门禁

| 功能 | 国内版 | 国际版 |
|---|---|---|
| 前台语言 | 强制 zh | 按配置多语言 |
| URL 前缀 | 不识别 `/ru/...` | 支持 |
| 语言切换器 | 隐藏 | 显示 |
| 币种 | 强制 CNY | 多币种展示 |
| 币种切换器 | 隐藏 | 显示 |
| 汇率同步 | 关闭 | 开启 |
| 多语言/多货币菜单 | 不生效 | 正常 |
| 支付渠道 | 微信/支付宝 | Stripe/PayPal |
| 商品翻译标签页 | 无（单语） | 有 |
| 商品价格标签 | `价格（CNY）` | `价格（USD）` |
| 订单展示 | CNY 实付 | USD 实付 + 本币参考价 |
| 结算提示 | 「实际将以 CNY 结算」 | 「实际将以 USD 结算」 |
| 小程序 API | 中文 + CNY | 不使用 |

支付渠道按版本**过滤展示**，不修改 `payment_channel.enabled`，切回时无需重配。

---

## 5. 订单与支付

新增字段（迁移 `000037_add_order_charge_currency.php`）：

| 表 | 字段 | 说明 |
|---|---|---|
| `order` | `charge_currency` | USD / CNY |
| `order_pay` | `charge_currency` | USD / CNY |

- 订单金额始终以 `charge_currency` 计价。
- `display_*` 仍是展示参考价；国际版用于本币参考，国内版与实付一致。
- 支付回调金额校验使用 `order_pay.charge_currency`。
- 支付渠道限制：
  - 国内版：微信支付、支付宝（CNY）
  - 国际版：Stripe、PayPal（USD）
- 小程序 `createPayment` 在国内版只允许微信/支付宝；国际版只允许 Stripe/PayPal。

---

## 6. 实现落点

### 6.1 新增

```
app/common/service/EditionService.php
app/admin/controller/Edition.php
app/admin/view/edition/index.html
app/adminapi/controller/Edition.php
database/migrations/000037_add_order_charge_currency.php
```

### 6.2 修改

- `app/common.php`：`site_edition()` / `is_domestic_edition()` / `base_locale()` / `base_currency_code()`
- `LanguageService` / `CurrencyService`：按版本过滤
- `TranslationService` / `TranslationJobService`：源语言改为 `base_locale()`
- `OrderService`：写入 `charge_currency`；`displaySummary` 支持 CNY/USD
- `PaymentService` / `PaymentGatewayFactory`：按版本限制渠道与币种
- `SiteBase` / `base.html` / `checkout.html` / `product.html`：基准币种动态显示
- `admin/controller/Orders.php`：后台订单金额按基准币种显示
- `config/site.php`：`site.edition` 默认值
- `config/admin_menu.php`：站点版本菜单
- `SettingService::set()`：供版本切换写入设置

### 6.3 管理 API

| 方法 | 路径 |
|---|---|
| GET | `/admin-api/v1/edition` |
| PUT | `/admin-api/v1/edition` |

`PUT` body：

```json
{
  "edition": "domestic",
  "confirmed": true,
  "phrase": "SWITCH"
}
```

---

## 7. 新部署步骤

### 国内版

1. 部署代码 + 空数据库
2. `php think migrate:run`
3. 后台 `/admin/edition` 选择「使用国内版（CNY）」并确认
4. 后台录入中文商品、CNY 价格
5. 支付管理启用微信/支付宝并填写配置
6. 配置小程序 AppID / 微信登录
7. 关闭 `translate:work`、`currency:sync`（国内版不需要）

### 国际版

1. 部署代码 + 空数据库
2. `php think migrate:run`
3. 后台 `/admin/edition` 选择「使用国际版（USD）」并确认（默认兜底也是国际版）
4. 录入英文商品、USD 价格
5. 支付管理启用 Stripe/PayPal
6. 配置 AI 翻译与汇率同步
7. 启动 `translate:work`、配置 `currency:sync` 定时任务

---

## 8. 验证记录

已实际验证：

- 国际版 → 国内版切换：`base_locale=zh`、`base_currency=CNY`、可用语言 1 个、可用币种 1 个
- 国内版 → 国际版切换：恢复 `en` / `USD`
- 错误确认词：拒绝
- 有订单时切换：拒绝（提示走迁移流程）
- 国内版前台：
  - `html lang="zh"`
  - 商品价格 `¥19.99`，不做换算
  - `/ru/products` 404
  - sitemap 仅 `zh` + `x-default`
  - 结算提示「实际将以 CNY 结算」
- 国际版前台：`/ru/products/1`、hreflang、canonical、多币种参考价正常
- 版本切换页面：`/admin/edition` 200，菜单高亮正常
- **1.0.6 升级兼容**：
  - 删除 `site.edition` 模拟未初始化，页面显示「未初始化」，两张卡片均可点
  - 弹窗默认 `hidden` 且 `getComputedStyle(modal).display === 'none'`
  - 点击卡片可打开弹窗，取消/遮罩/`Esc` 可关闭，勾选 + `SWITCH` 后确认按钮可用
  - 有 1 个历史订单时选择「国内版」成功，`order.charge_currency=CNY`、
    `order_pay.charge_currency=CNY`、`display_currency=CNY`、`display_total_amount=total_amount`
  - 再次切换被拒绝，提示「已有历史订单」
  - 删除 `site.edition` 后再选「国际版」成功，订单币种恢复 `USD`
- 订单展示：`$21.99`（USD 国际版）；临时 RUB 订单 `$21.99 + ₽1,772.80`
- 下单快照：`$19.99` → `display_total_amount=1611.56 RUB`

---

## 9. 限制

- 不支持「同一套数据库随时切换」的双价格/双语言模式
- 切换版本不迁移商品/订单数据
- 国内版仍复用同一套商品表结构；需要中文内容与 CNY 价格
- 小程序端如与国际站同时运行，应使用两套独立部署
- 国内版货币页只展示 CNY；汇率同步/新增币种按钮隐藏
- 国内版 AI 翻译目标语种为空，不会产生翻译任务

---

## 10. 后续可选项

- 版本初始化向导（选版本 → 建基准语言/币种 → 引导录商品）
- 双价格字段（同库双版本）
- 商品/内容跨部署导入导出
- 版本切换自动检查清单与回滚