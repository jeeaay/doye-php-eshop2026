<?php
declare (strict_types = 1);

namespace app;

use think\Service;

/**
 * 应用服务类
 */
class AppService extends Service
{
    public function register()
    {
        // 服务注册
    }

    public function boot()
    {
        // PHP 8.5 起 curl_close、$http_response_header 等会触发 E_DEPRECATED，
        // ThinkPHP 默认把 E_ALL 转成异常，会让 migrate/worker 等 CLI 命令或生产请求直接中断。
        // CLI 始终忽略废弃提示；HTTP 仅在非调试模式忽略，开发环境仍保留提示。
        if ($this->app->runningInConsole() || !$this->app->isDebug()) {
            error_reporting(E_ALL & ~E_DEPRECATED & ~E_USER_DEPRECATED);
        }

        // 多应用解析会把第一段 URL 当作应用名，语言前缀必须在它之前剥离
        $this->app->event->listen('HttpRun', function () {
            $this->app->middleware->unshift(\app\common\middleware\LocalePrefix::class);
        });
    }
}
