<?php
use think\migration\Migrator;

/**
 * 创建安全防护相关表：security_ip_rule / security_path_rule / security_event
 *
 * - security_ip_rule    黑白名单（list_type=blacklist|whitelist），支持手工与自动来源、过期时间
 * - security_path_rule  自定义探针/高风险路径规则（精确/前缀/包含/正则）
 * - security_event      拦截与探针事件日志，用于后台审计与排障
 *
 * 三张表都是平台级数据，不参与商户隔离；后台页面与管理 API 均仅平台超管可用。
 * 表结构变更请追加新迁移，不要直接改这里的历史文件。
 */
class CreateSecurityTables extends Migrator
{
    /**
     * 执行迁移
     *
     * @return void
     */
    public function change()
    {
        $ipRule = $this->table('security_ip_rule', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => 'IP 黑白名单',
        ]);

        $ipRule->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('list_type', 'string', ['limit' => 10, 'default' => 'blacklist', 'comment' => 'blacklist / whitelist'])
            ->addColumn('ip', 'string', ['limit' => 64, 'null' => false, 'comment' => 'IP / CIDR / 192.168.1.*'])
            ->addColumn('source', 'string', ['limit' => 20, 'default' => 'manual', 'comment' => 'manual / auto_path / auto_ua'])
            ->addColumn('reason', 'string', ['limit' => 255, 'default' => '', 'comment' => '封禁原因'])
            ->addColumn('status', 'tinyinteger', ['default' => 1, 'comment' => '1 启用 0 停用'])
            ->addColumn('expire_time', 'datetime', ['null' => true, 'comment' => '为空表示长期'])
            ->addColumn('hit_count', 'integer', ['default' => 0, 'comment' => '命中/触发次数'])
            ->addColumn('last_uri', 'string', ['limit' => 255, 'default' => '', 'comment' => '最近命中的 URI'])
            ->addColumn('remark', 'string', ['limit' => 255, 'default' => ''])
            ->addColumn('created_by', 'string', ['limit' => 64, 'null' => true, 'comment' => '后台操作人'])
            ->addColumn('updated_by', 'string', ['limit' => 64, 'null' => true])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addIndex(['list_type', 'ip'], ['unique' => true])
            ->addIndex(['list_type', 'status'])
            ->addIndex(['expire_time'])
            ->create();

        $pathRule = $this->table('security_path_rule', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '高风险路径（探针）规则',
        ]);

        $pathRule->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('name', 'string', ['limit' => 100, 'null' => false, 'comment' => '规则名称'])
            ->addColumn('match_type', 'string', ['limit' => 10, 'default' => 'contains', 'comment' => 'exact / prefix / contains / regex'])
            ->addColumn('pattern', 'string', ['limit' => 255, 'null' => false, 'comment' => '匹配内容'])
            ->addColumn('risk_level', 'string', ['limit' => 10, 'default' => 'high'])
            ->addColumn('status', 'tinyinteger', ['default' => 1])
            ->addColumn('hit_count', 'integer', ['default' => 0, 'comment' => '命中次数'])
            ->addColumn('remark', 'string', ['limit' => 255, 'default' => ''])
            ->addColumn('created_by', 'string', ['limit' => 64, 'null' => true])
            ->addColumn('updated_by', 'string', ['limit' => 64, 'null' => true])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addIndex(['status'])
            ->create();

        $event = $this->table('security_event', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '安全拦截与探针事件日志',
        ]);

        $event->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('ip', 'string', ['limit' => 64, 'default' => ''])
            ->addColumn('event_type', 'string', ['limit' => 32, 'default' => 'probe', 'comment' => 'blacklist_hit / probe / bad_ua / auto_block'])
            ->addColumn('reason', 'string', ['limit' => 255, 'default' => ''])
            ->addColumn('path', 'string', ['limit' => 512, 'default' => ''])
            ->addColumn('method', 'string', ['limit' => 8, 'default' => ''])
            ->addColumn('user_agent', 'string', ['limit' => 255, 'default' => ''])
            ->addColumn('hit_count', 'integer', ['default' => 0, 'comment' => '触发时的累计次数'])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addIndex(['event_type', 'create_time'])
            ->addIndex(['ip', 'create_time'])
            ->addIndex(['create_time'])
            ->create();
    }
}