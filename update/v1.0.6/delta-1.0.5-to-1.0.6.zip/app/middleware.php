<?php

return [
    \think\middleware\LoadLangPack::class,
    \think\middleware\SessionInit::class,
    \think\middleware\CheckRequestCache::class,
    \app\common\middleware\Cors::class,
    \app\common\middleware\SecurityGuard::class,
    \app\common\middleware\UpdateMaintenance::class,
    \app\common\middleware\RequestLog::class,
];
