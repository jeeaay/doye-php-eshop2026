<?php
declare(strict_types=1);

namespace app\api\controller;

use app\BaseController;
use app\common\exception\BizException;
use app\common\lib\SiteAuth;
use app\common\support\AppContext;

/**
 * 独立站前台专用接口（浏览器）
 *
 * 只补齐浏览器确实拿不到的登录能力，其余购物车/订单/地址/用户接口
 * 全部复用小程序那套 Bearer token 接口，不做重复实现。
 */
class Site extends BaseController
{
    /** POST /api/site/auth/send-code */
    public function sendCode()
    {
        try {
            $email = (string) $this->request->post('email', '');
            $result = (new SiteAuth())->sendCode($email);
            return $this->success($result, $result['sent'] ? '验证码已发送' : '验证码已生成（开发模式）');
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    /** POST /api/site/auth/verify-code */
    public function verifyCode()
    {
        try {
            $email = (string) $this->request->post('email', '');
            $code = (string) $this->request->post('code', '');
            $result = (new SiteAuth())->verifyCode($email, $code);
            $user = $result['user'];

            return $this->success([
                'token' => $result['token'],
                'user'  => [
                    'id'       => (int) $user->id,
                    'email'    => (string) ($user->email ?? ''),
                    'nickname' => (string) ($user->nickname ?? ''),
                    'avatar'   => (string) ($user->avatar ?? ''),
                    'phone'    => (string) ($user->phone ?? ''),
                ],
            ]);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    /** GET /api/site/auth/me */
    public function me()
    {
        $user = SiteAuth::userFromToken($this->bearerToken());
        if (!$user) {
            return json(['code' => 401, 'message' => '未登录', 'data' => null], 401);
        }

        return $this->success([
            'id'       => (int) $user->id,
            'email'    => (string) ($user->email ?? ''),
            'nickname' => (string) ($user->nickname ?? ''),
            'avatar'   => (string) ($user->avatar ?? ''),
            'phone'    => (string) ($user->phone ?? ''),
            'openid'   => (string) $user->openid,
        ]);
    }

    /** POST /api/site/auth/sign-out */
    public function signOut()
    {
        $token = $this->bearerToken();
        if ($token) {
            \app\common\lib\RedisCache::del('token:' . $token);
        }
        return $this->success();
    }

    /** POST /api/site/contact —— 联系页留言 */
    public function contact()
    {
        try {
            $name = trim((string) $this->request->post('name', ''));
            $email = trim((string) $this->request->post('email', ''));
            $subject = trim((string) $this->request->post('subject', ''));
            $content = trim((string) $this->request->post('content', ''));

            if ($name === '' || mb_strlen($name) > 64) {
                throw new BizException('请填写姓名');
            }
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new BizException('邮箱格式不正确');
            }
            if (mb_strlen($content) < 5) {
                throw new BizException('请填写留言内容');
            }

            \think\facade\Db::name('site_message')->insert([
                'name'        => $name,
                'email'       => $email,
                'subject'     => mb_substr($subject, 0, 128),
                'content'     => mb_substr($content, 0, 5000),
                'ip'          => client_ip() ?: (string) $this->request->ip(),
                'status'      => 0,
                'create_time' => date('Y-m-d H:i:s'),
            ]);

            // 通知邮件：失败不影响落库，接口始终返回成功
            (new \app\common\service\MessageService())->notify([
                'name'    => $name,
                'email'   => $email,
                'subject' => $subject,
                'content' => $content,
                'ip'      => client_ip() ?: (string) $this->request->ip(),
            ]);

            return $this->success(null, '留言已提交，我们会尽快联系您');
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    private function bearerToken(): ?string
    {
        $auth = (string) $this->request->header('authorization', '');
        if (stripos($auth, 'Bearer ') === 0) {
            return trim(substr($auth, 7));
        }
        return null;
    }
}