<?php
// 应用公共文件
declare(strict_types=1);

if (!function_exists('h')) {
    /**
     * HTML 转义输出（模板中使用 {:h($var)}）
     */
    function h($value): string
    {
        if (is_array($value) || is_object($value)) {
            return '';
        }
        return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

if (!function_exists('site_config')) {
    /**
     * 读取前台站点配置：site_config('brand.name', 'DepthX')
     *
     * 取值优先级：数据库 setting 表（后台「系统设置」写入的覆盖值）
     *           > config/site.php（默认值）。
     * 合并结果在单次请求内缓存，实际读取逻辑见 SettingService::mergedConfig()。
     */
    function site_config(?string $key = null, $default = null)
    {
        $config = \app\common\service\SettingService::mergedConfig();
        if ($key === null || $key === '') {
            return $config;
        }
        $value = $config;
        foreach (explode('.', $key) as $segment) {
            if (!is_array($value) || !array_key_exists($segment, $value)) {
                return $default;
            }
            $value = $value[$segment];
        }
        return $value;
    }
}

if (!function_exists('money')) {
    /**
     * 金额格式化（PHP 后台价格为 decimal(10,2)，没有分单位）
     */
    function money($amount, int $decimals = 2): string
    {
        return number_format((float) $amount, $decimals, '.', '');
    }
}

if (!function_exists('theme_asset')) {
    /**
     * 主题静态资源 URL
     */
    function theme_asset(string $path = ''): string
    {
        $theme = (string) site_config('theme', 'tape2026');
        // 文档根目录是 public/，静态资源直接以主题目录名暴露
        return '/' . $theme . '/' . ltrim($path, '/');
    }
}

if (!function_exists('storefront_product_url')) {
    /**
     * 前台商品详情 URL。
     * PHP 后台商品没有 slug / custom_route 字段（见 todo.md），暂用 ID。
     */
    function storefront_product_url($id): string
    {
        return '/products/' . (int) $id;
    }
}

if (!function_exists('client_ip')) {
    /**
     * 客户端真实 IP（遵循后台「系统设置 → 安全设置」的可信代理配置）
     *
     * 默认取 REMOTE_ADDR；开启「信任反向代理请求头」且代理地址命中
     * 可信代理列表时，才采信 CF-Connecting-IP / X-Real-IP / X-Forwarded-For。
     * 与安全防护拦截使用同一解析结果，避免审计日志、限流与封禁口径不一致。
     */
    function client_ip(): string
    {
        try {
            return \app\common\service\SecurityService::clientIp();
        } catch (\Throwable $e) {
            return '';
        }
    }
}