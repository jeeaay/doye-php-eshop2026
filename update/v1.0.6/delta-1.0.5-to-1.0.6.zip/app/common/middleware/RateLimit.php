<?php

namespace app\common\middleware;

use app\common\lib\RedisCache;
use think\Request;

class RateLimit
{
    protected int $max = 120;
    protected int $window = 60;

    public function handle(Request $request, \Closure $next)
    {
        $key = 'rl2:' . (client_ip() ?: '0.0.0.0');
        $count = RedisCache::inc($key);
        if ($count === 1) {
            RedisCache::expire($key, $this->window);
        }
        if ($count > $this->max) {
            return json(['code' => 429, 'message' => '请求过于频繁', 'data' => null], 429);
        }
        return $next($request);
    }
}
