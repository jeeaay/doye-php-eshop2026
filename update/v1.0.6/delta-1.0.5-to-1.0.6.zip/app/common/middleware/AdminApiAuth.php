<?php
declare(strict_types=1);

namespace app\common\middleware;

use app\common\enum\AdminRole;
use app\common\model\Admin;
use app\common\service\ApiKeyService;
use app\common\support\AppContext;
use think\facade\Db;
use think\Request;

/**
 * 后台管理 API 鉴权（/admin-api/v1/*）
 *
 * 通过 Authorization: Bearer <API Key> 或 X-API-Key 认证。
 * 认证成功后按 API 密钥所属管理员实时填充 AppContext，
 * 后续业务层（Service）沿用与 Session 后台完全相同的权限判断。
 */
class AdminApiAuth
{
    /**
     * 执行鉴权
     *
     * @param Request $request 当前请求
     * @param \Closure $next   后续中间件
     * @return mixed
     */
    public function handle(Request $request, \Closure $next)
    {
        $plainKey = $this->parseKey($request);
        if (!$plainKey) {
            return $this->deny();
        }

        $service = new ApiKeyService();
        $record = $service->authenticate($plainKey);
        if (!$record) {
            return $this->deny();
        }

        $admin = Admin::find((int) $record->admin_id);
        if (!$admin || (int) $admin->status !== 1) {
            return $this->deny();
        }

        $merchantIds = $admin->role === AdminRole::SUPER
            ? []
            : array_map('intval', Db::table('admin_merchant')
                ->where('admin_id', (int) $admin->id)
                ->column('merchant_id'));

        AppContext::setAdminId((int) $admin->id);
        AppContext::setAdminRole((string) $admin->role);
        AppContext::setMerchantIds($merchantIds);
        AppContext::setAuthSource('api_key');
        AppContext::setApiKeyId((int) $record->id);
        AppContext::setAdminUsername((string) $admin->username);

        $service->touch($record, client_ip() ?: (string) $request->ip());

        return $next($request);
    }

    /**
     * 解析请求中的明文密钥
     *
     * @param Request $request 当前请求
     * @return string|null
     */
    private function parseKey(Request $request): ?string
    {
        $authorization = trim((string) $request->header('authorization', ''));
        if (stripos($authorization, 'Bearer ') === 0) {
            $key = trim(substr($authorization, 7));
            if ($key !== '') {
                return $key;
            }
        }

        $key = trim((string) $request->header('x-api-key', ''));
        return $key !== '' ? $key : null;
    }

    /**
     * 统一未认证响应
     *
     * @return \think\response\Json
     */
    private function deny()
    {
        return json(['code' => 401, 'message' => '未认证或密钥无效', 'data' => null], 401);
    }
}