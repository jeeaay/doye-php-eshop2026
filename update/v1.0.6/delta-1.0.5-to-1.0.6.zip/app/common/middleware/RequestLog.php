<?php

namespace app\common\middleware;

use think\facade\Log;
use think\Request;

class RequestLog
{
    public function handle(Request $request, \Closure $next)
    {
        $start = microtime(true);
        $response = $next($request);
        $ms = round((microtime(true) - $start) * 1000, 2);
        Log::info('REQUEST', [
            'method' => $request->method(),
            'path' => $request->pathinfo(),
            'ip' => client_ip() ?: $request->ip(),
            'status' => $response->getCode(),
            'ms' => $ms,
        ]);
        return $response;
    }
}
