<?php
declare(strict_types=1);

namespace app\common\middleware;

use app\common\service\SecurityService;
use think\Request;

/**
 * 全局安全防护中间件
 *
 * 在路由分发前完成黑名单拦截、白名单放行、探针识别、恶意 UA 拦截与自动加黑。
 * 开关与阈值来自后台「系统设置 → 安全设置」；数据表未创建或 Redis 不可用时自动降级，
 * 不会因为安全功能本身导致站点 500。
 */
class SecurityGuard
{
    /**
     * 执行安全检查
     *
     * @param Request  $request 当前请求
     * @param \Closure $next    后续中间件
     * @return mixed
     */
    public function handle(Request $request, \Closure $next)
    {
        try {
            $blocked = (new SecurityService())->inspect($request);
            if ($blocked !== null) {
                return $blocked;
            }
        } catch (\Throwable $e) {
            // 安全模块异常不得影响主流程，交由框架日志留痕
            \think\facade\Log::warning('[security] guard failed: ' . $e->getMessage());
        }

        return $next($request);
    }
}