<?php
declare(strict_types=1);

namespace app\common\middleware;

use app\common\service\AuditLogService;
use app\common\support\AppContext;
use think\facade\Log;
use think\facade\Session;
use think\Request;

/**
 * 后台写操作审计
 *
 * 仅记录 POST / PUT / PATCH / DELETE；登录/登出由 Auth 控制器显式记录。
 * 审计写入失败只写框架日志，不改变业务响应。
 */
class AdminAudit
{
    /**
     * 执行审计
     *
     * @param Request  $request 当前请求
     * @param \Closure $next    后续中间件
     * @return mixed
     */
    public function handle(Request $request, \Closure $next)
    {
        if (!(bool) config('audit.enabled', true) || !$this->shouldRecord($request)) {
            return $next($request);
        }

        $start = microtime(true);
        $status = 200;
        $resultCode = 0;
        $error = '';

        try {
            $response = $next($request);
            $status = (int) $response->getCode();
            [$resultCode, $error] = $this->inspect($response);
            return $response;
        } catch (\Throwable $e) {
            $status = 500;
            $resultCode = 1;
            $error = $e->getMessage();
            throw $e;
        } finally {
            try {
                $this->write(
                    $request,
                    $status,
                    $resultCode,
                    $error,
                    (int) round((microtime(true) - $start) * 1000)
                );
            } catch (\Throwable $e) {
                Log::warning('[audit] middleware failed: ' . $e->getMessage());
            }
        }
    }

    /**
     * 是否记录该请求
     *
     * @param Request $request 当前请求
     * @return bool
     */
    private function shouldRecord(Request $request): bool
    {
        return in_array(strtoupper($request->method()), ['POST', 'PUT', 'PATCH', 'DELETE'], true);
    }

    /**
     * 解析响应中的业务结果
     *
     * @param mixed $response 响应对象
     * @return array{0:int,1:string} [业务 code, 错误信息]
     */
    private function inspect($response): array
    {
        if ($response instanceof \think\response\Json) {
            $data = (array) $response->getData();
            $code = (int) ($data['code'] ?? 0);
            $message = $code === 0 ? '' : (string) ($data['message'] ?? '');
            return [$code, $message];
        }

        return [0, ''];
    }

    /**
     * 组装并写入日志
     *
     * @param Request $request    当前请求
     * @param int     $status     HTTP 状态
     * @param int     $resultCode 业务 code
     * @param string  $error      错误信息
     * @param int     $duration   耗时毫秒
     * @return void
     */
    private function write(Request $request, int $status, int $resultCode, string $error, int $duration): void
    {
        $appName = (string) app('http')->getName();
        $pathinfo = trim((string) $request->pathinfo(), '/');

        $segments = array_values(array_filter(explode('/', $pathinfo), static fn ($item) => $item !== ''));
        if ($appName === 'adminapi' && ($segments[0] ?? '') === 'v1') {
            array_shift($segments);
        }

        $module = (string) ($segments[0] ?? 'other');
        if ($appName === 'adminapi' && $module === 'keys') {
            $module = 'api-keys';
        }
        $last = (string) (end($segments) ?: 'other');
        $method = strtoupper($request->method());

        $actionMap = (array) config('audit.actions', []);
        $action = isset($actionMap[$last])
            ? $last
            : match ($method) {
                'POST'         => $last === (string) ($segments[0] ?? '') ? 'create' : 'save',
                'PUT', 'PATCH' => 'update',
                'DELETE'       => 'delete',
                default        => 'other',
            };

        $params = $request->param();
        $targetId = '';
        foreach ((array) config('audit.target_keys', []) as $key) {
            if (isset($params[$key]) && $params[$key] !== '') {
                $targetId = is_array($params[$key]) ? implode(',', array_map('strval', $params[$key])) : (string) $params[$key];
                break;
            }
        }

        $payload = $params;
        if (!empty($_FILES) && is_array($_FILES)) {
            $files = [];
            foreach ($_FILES as $field => $info) {
                $files[$field] = [
                    'name' => (string) ($info['name'] ?? ''),
                    'size' => (int) ($info['size'] ?? 0),
                ];
            }
            if ($files) {
                $payload['_files'] = $files;
            }
        }

        $moduleLabel = (string) (config('audit.modules.' . $module) ?? $module);
        $actionLabel = (string) (config('audit.actions.' . $action) ?? $action);
        $summary = $moduleLabel . $actionLabel . ($targetId !== '' ? ' #' . $targetId : '');
        if ($action === 'purge') {
            $summary = '清理 ' . (int) ($params['days'] ?? 0) . ' 天前日志';
        }

        $username = AppContext::getAdminUsername();
        $role = AppContext::getAdminRole();
        if ($username === '') {
            $session = Session::get('admin');
            $username = is_array($session) ? (string) ($session['username'] ?? '') : '';
            $role = $role ?: (is_array($session) ? ($session['role'] ?? null) : null);
        }

        $prefix = $appName === 'adminapi' ? '/admin-api/' : '/admin/';

        (new AuditLogService())->record([
            'admin_id'       => AppContext::getAdminId(),
            'admin_username' => $username,
            'role'           => $role,
            'auth_source'    => AppContext::getAuthSource(),
            'api_key_id'     => AppContext::getApiKeyId(),
            'module'         => $module,
            'action'         => $action,
            'method'         => $method,
            'path'           => $prefix . $pathinfo,
            'target_type'    => $module !== 'other' ? $module : null,
            'target_id'      => $targetId,
            'summary'        => $summary,
            'detail'         => $payload,
            'ip'             => client_ip() ?: (string) $request->ip(),
            'user_agent'     => (string) $request->header('user-agent', ''),
            'http_status'    => $status,
            'result_code'    => $resultCode,
            'error_message'  => $error,
            'duration_ms'    => $duration,
        ]);
    }
}