<?php
declare(strict_types=1);

namespace app\common\command;

use app\common\lib\RedisCache;
use app\common\model\SecurityIpRule;
use app\common\service\SecurityService;
use think\console\Command;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;

/**
 * 安全防护应急命令
 *
 * 典型场景：误把自己/运维出口 IP 加入黑名单后无法进入后台。
 * 用法：
 *   php think security:unblock --list              列出当前生效的黑名单
 *   php think security:unblock 1.2.3.4             解除该 IP 的黑名单并清空探针计数
 */
class SecurityUnblock extends Command
{
    /**
     * 配置命令
     *
     * @return void
     */
    protected function configure(): void
    {
        $this->setName('security:unblock')
            ->addArgument('ip', Argument::OPTIONAL, '要解除封禁的 IP')
            ->addOption('list', null, Option::VALUE_NONE, '只列出当前黑名单，不做修改')
            ->setDescription('查看或解除安全防护黑名单（应急用）');
    }

    /**
     * 执行命令
     *
     * @param Input  $input  输入
     * @param Output $output 输出
     * @return void
     */
    protected function execute(Input $input, Output $output): void
    {
        $service = new SecurityService();
        if (!$service->storageReady()) {
            $output->writeln('<error>安全数据表不存在，请先执行 php think migrate:run</error>');
            return;
        }

        $rows = SecurityIpRule::where('list_type', 'blacklist')->order('id', 'desc')->select();
        if ($input->getOption('list') || !$input->getArgument('ip')) {
            if (count($rows) === 0) {
                $output->writeln('<info>当前没有黑名单记录。</info>');
                return;
            }

            $output->writeln('<comment>当前黑名单（' . count($rows) . ' 条）：</comment>');
            foreach ($rows as $row) {
                $output->writeln(sprintf(
                    '  #%d  %s  status=%d  source=%s  expire=%s  reason=%s',
                    (int) $row->id,
                    (string) $row->ip,
                    (int) $row->status,
                    (string) $row->source,
                    (string) ($row->expire_time ?: '长期'),
                    (string) $row->reason
                ));
            }

            if (!$input->getOption('list')) {
                $output->writeln('如需解除，执行：php think security:unblock <ip>');
            }
            return;
        }

        $ip = trim((string) $input->getArgument('ip'));
        if (filter_var($ip, FILTER_VALIDATE_IP) === false && !str_contains($ip, '/') && !str_contains($ip, '*')) {
            $output->writeln('<error>IP 格式不正确：' . $ip . '</error>');
            return;
        }

        $deleted = 0;
        foreach ($rows as $row) {
            if (SecurityService::ipMatches($ip, (string) $row->ip)) {
                $rowId = (int) $row->id;
                $rowIp = (string) $row->ip;
                $row->delete();
                $deleted++;
                $output->writeln('已删除黑名单记录 #' . $rowId . ' ' . $rowIp);
            }
        }

        try {
            RedisCache::del('security:probe:' . md5($ip));
        } catch (\Throwable $e) {
            // Redis 不可用时忽略
        }

        $service->refreshCache();
        $output->writeln($deleted > 0
            ? '<info>完成，已解除 ' . $deleted . ' 条匹配记录。</info>'
            : '<comment>没有找到与 ' . $ip . ' 匹配的黑名单记录。</comment>');
    }
}