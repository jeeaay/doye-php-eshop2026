<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * IP 黑白名单模型
 *
 * list_type=blacklist 表示封禁，whitelist 表示放行；两者共用一张表，
 * 通过 (list_type, ip) 唯一索引避免重复录入。
 * 平台级数据，不带商户维度。
 */
class SecurityIpRule extends BaseModel
{
    /** @var string 数据表名 */
    protected $name = 'security_ip_rule';

    /** @var string 自动时间戳类型 */
    protected $autoWriteTimestamp = 'datetime';
}