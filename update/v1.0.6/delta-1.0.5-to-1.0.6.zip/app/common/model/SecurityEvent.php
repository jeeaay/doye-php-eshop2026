<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 安全事件日志模型
 *
 * 记录黑名单命中、探针扫描、恶意 UA 与自动封禁，用于后台排障与追溯。
 * 只追加不更新，因此关闭 update_time 自动写入。
 */
class SecurityEvent extends BaseModel
{
    /** @var string 数据表名 */
    protected $name = 'security_event';

    /** @var string 自动时间戳类型 */
    protected $autoWriteTimestamp = 'datetime';

    /** @var string|bool 表无 update_time 列 */
    protected $updateTime = false;
}