<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 高风险路径（探针）规则模型
 *
 * 与内置规则叠加生效：内置规则覆盖常见扫描器路径，这里用于补充站点特有的特征。
 * 平台级数据，不带商户维度。
 */
class SecurityPathRule extends BaseModel
{
    /** @var string 数据表名 */
    protected $name = 'security_path_rule';

    /** @var string 自动时间戳类型 */
    protected $autoWriteTimestamp = 'datetime';
}