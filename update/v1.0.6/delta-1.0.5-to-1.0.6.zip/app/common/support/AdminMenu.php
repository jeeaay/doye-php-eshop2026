<?php
declare(strict_types=1);

namespace app\common\support;

/**
 * 后台左侧菜单
 *
 * 菜单结构来自 config/admin_menu.php；这里只负责：
 *   - 按当前管理员角色过滤可见项；
 *   - 标记当前页面所在分组/子项；
 *   - 生成顶部面包屑。
 *
 * 控制器仍只需调用 assignActiveMenu('orders') 这类标识，无需感知分组结构。
 */
class AdminMenu
{
    /**
     * 生成当前角色可见的侧边栏菜单树
     *
     * @param string|null $role       当前角色
     * @param string      $activeMenu 当前页面标识
     * @return array
     */
    public static function tree(?string $role, string $activeMenu): array
    {
        $role   = (string) $role;
        $groups = [];

        foreach (self::definitions() as $group) {
            if (!is_array($group)) {
                continue;
            }
            if (($group['in_sidebar'] ?? true) === false) {
                continue;
            }

            $children = [];
            foreach ((array) ($group['children'] ?? []) as $item) {
                if (!self::visible($item, $role)) {
                    continue;
                }
                $item['is_active'] = self::isActive($item, $activeMenu);
                $children[] = $item;
            }

            $hasChildren = array_key_exists('children', $group);
            if ($hasChildren && empty($children)) {
                continue;
            }
            if (!$hasChildren && !self::visible($group, $role)) {
                continue;
            }

            $group['children']  = $children;
            $group['is_active'] = self::groupActive($group, $activeMenu);
            $groups[]           = $group;
        }

        return $groups;
    }

    /**
     * 当前页面所属的侧边栏分组 key（不在侧边栏时返回空字符串）
     *
     * @param string $activeMenu 当前页面标识
     * @return string
     */
    public static function activeGroup(string $activeMenu): string
    {
        foreach (self::definitions() as $group) {
            if (($group['in_sidebar'] ?? true) === false) {
                continue;
            }
            if (self::groupActive($group, $activeMenu)) {
                return (string) ($group['key'] ?? '');
            }
        }

        return '';
    }

    /**
     * 顶部面包屑：['group' => 一级菜单, 'item' => 二级菜单]
     *
     * 头像下拉里的页面（账户设置/密钥管理）也会返回「账户 / xxx」。
     *
     * @param string $activeMenu 当前页面标识
     * @return array{group:string,item:string}
     */
    public static function breadcrumb(string $activeMenu): array
    {
        if ($activeMenu === '') {
            return ['group' => '', 'item' => ''];
        }

        foreach (self::definitions() as $group) {
            if (self::isActive($group, $activeMenu)) {
                return ['group' => '', 'item' => (string) ($group['title'] ?? '')];
            }
            foreach ((array) ($group['children'] ?? []) as $item) {
                if (self::isActive($item, $activeMenu)) {
                    return [
                        'group' => (string) ($group['title'] ?? ''),
                        'item'  => (string) ($item['title'] ?? ''),
                    ];
                }
            }
        }

        return ['group' => '', 'item' => ''];
    }

    /**
     * 读取菜单定义
     *
     * @return array
     */
    private static function definitions(): array
    {
        return (array) config('admin_menu', []);
    }

    /**
     * 分组内是否包含当前页面
     *
     * @param array  $group      分组
     * @param string $activeMenu 当前页面标识
     * @return bool
     */
    private static function groupActive(array $group, string $activeMenu): bool
    {
        if ($activeMenu === '') {
            return false;
        }
        if (self::isActive($group, $activeMenu)) {
            return true;
        }
        foreach ((array) ($group['children'] ?? []) as $item) {
            if (self::isActive($item, $activeMenu)) {
                return true;
            }
        }

        return false;
    }

    /**
     * 单条菜单是否命中当前页面
     *
     * @param array  $item       菜单项
     * @param string $activeMenu 当前页面标识
     * @return bool
     */
    private static function isActive(array $item, string $activeMenu): bool
    {
        return $activeMenu !== '' && (string) ($item['active'] ?? '') === $activeMenu;
    }

    /**
     * 当前角色是否可以看到该菜单项
     *
     * @param array  $item 菜单项
     * @param string $role 角色
     * @return bool
     */
    private static function visible(array $item, string $role): bool
    {
        $roles = $item['roles'] ?? [];
        if (empty($roles)) {
            return true;
        }

        return in_array($role, array_map('strval', (array) $roles), true);
    }
}