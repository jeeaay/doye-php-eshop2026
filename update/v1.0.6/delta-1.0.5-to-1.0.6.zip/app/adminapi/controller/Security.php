<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\exception\BizException;
use app\common\service\SecurityService;

/**
 * 管理 API：安全防护
 *
 * 与后台「系统设置 → 安全设置」共用 SecurityService：
 * 黑白名单、探针规则、拦截日志、防护开关与运行时缓存刷新。
 * 全部端点仅平台超管可用。
 */
class Security extends ApiBaseController
{
    /**
     * GET /admin-api/v1/security/overview
     *
     * @return \think\response\Json
     */
    public function overview()
    {
        return $this->run(function () {
            $this->assertSuper();
            $service = new SecurityService();

            return [
                'overview'      => $service->overview(),
                'settings'      => $service->settingsForForm(),
                'current_ip'    => $service->currentIp(),
                'storage_ready' => $service->storageReady(),
            ];
        });
    }

    /**
     * GET /admin-api/v1/security/ip-rules
     *
     * 查询参数：list_type=blacklist|whitelist、keyword、status、page、page_size
     *
     * @return \think\response\Json
     */
    public function ipRules()
    {
        return $this->run(function () {
            $this->assertSuper();
            [$page, $size] = $this->pageParams();

            $result = (new SecurityService())->ipRuleList([
                'list_type' => (string) $this->request->param('list_type', 'blacklist'),
                'keyword'   => (string) $this->request->param('keyword', ''),
                'status'    => $this->request->param('status', ''),
            ], $page, $size);

            return [
                'list'      => $result['list'],
                'total'     => $result['total'],
                'page'      => $result['page'],
                'page_size' => $result['page_size'],
            ];
        });
    }

    /**
     * POST /admin-api/v1/security/ip-rules
     *
     * body: {list_type, ip, reason?, remark?, status?, expire_time?}
     *
     * @return \think\response\Json
     */
    public function saveIpRule()
    {
        return $this->run(function () {
            $this->assertSuper();
            $input = $this->input();
            return (new SecurityService())->saveIpRule($input, null);
        }, '已添加');
    }

    /**
     * PUT /admin-api/v1/security/ip-rules/:id
     *
     * @return \think\response\Json
     */
    public function updateIpRule()
    {
        return $this->run(function () {
            $this->assertSuper();
            $id = (int) $this->request->param('id', 0);
            return (new SecurityService())->saveIpRule($this->input(), $id > 0 ? $id : null);
        }, '已更新');
    }

    /**
     * DELETE /admin-api/v1/security/ip-rules/:id
     *
     * @return \think\response\Json
     */
    public function deleteIpRule()
    {
        return $this->run(function () {
            $this->assertSuper();
            $id = (int) $this->request->param('id', 0);
            return ['deleted' => (new SecurityService())->deleteIpRules([$id])];
        }, '已删除');
    }

    /**
     * POST /admin-api/v1/security/ip-rules/:id/status
     *
     * body: {status: 0|1}
     *
     * @return \think\response\Json
     */
    public function ipRuleStatus()
    {
        return $this->run(function () {
            $this->assertSuper();
            (new SecurityService())->setIpRuleStatus(
                (int) $this->request->param('id', 0),
                (int) $this->request->param('status', 1)
            );
            return null;
        }, '状态已更新');
    }

    /**
     * GET /admin-api/v1/security/path-rules
     *
     * @return \think\response\Json
     */
    public function pathRules()
    {
        return $this->run(function () {
            $this->assertSuper();
            [$page, $size] = $this->pageParams();

            $result = (new SecurityService())->pathRuleList([
                'keyword' => (string) $this->request->param('keyword', ''),
                'status'  => $this->request->param('status', ''),
            ], $page, $size);

            return [
                'list'      => $result['list'],
                'total'     => $result['total'],
                'page'      => $result['page'],
                'page_size' => $result['page_size'],
            ];
        });
    }

    /**
     * POST /admin-api/v1/security/path-rules
     *
     * body: {name, match_type, pattern, status?, remark?}
     *
     * @return \think\response\Json
     */
    public function savePathRule()
    {
        return $this->run(function () {
            $this->assertSuper();
            return (new SecurityService())->savePathRule($this->input(), null);
        }, '已添加');
    }

    /**
     * PUT /admin-api/v1/security/path-rules/:id
     *
     * @return \think\response\Json
     */
    public function updatePathRule()
    {
        return $this->run(function () {
            $this->assertSuper();
            $id = (int) $this->request->param('id', 0);
            return (new SecurityService())->savePathRule($this->input(), $id > 0 ? $id : null);
        }, '已更新');
    }

    /**
     * DELETE /admin-api/v1/security/path-rules/:id
     *
     * @return \think\response\Json
     */
    public function deletePathRule()
    {
        return $this->run(function () {
            $this->assertSuper();
            $id = (int) $this->request->param('id', 0);
            return ['deleted' => (new SecurityService())->deletePathRules([$id])];
        }, '已删除');
    }

    /**
     * POST /admin-api/v1/security/path-rules/:id/status
     *
     * @return \think\response\Json
     */
    public function pathRuleStatus()
    {
        return $this->run(function () {
            $this->assertSuper();
            (new SecurityService())->setPathRuleStatus(
                (int) $this->request->param('id', 0),
                (int) $this->request->param('status', 1)
            );
            return null;
        }, '状态已更新');
    }

    /**
     * GET /admin-api/v1/security/events
     *
     * 查询参数：ip、event_type、keyword、page、page_size
     *
     * @return \think\response\Json
     */
    public function events()
    {
        return $this->run(function () {
            $this->assertSuper();
            [$page, $size] = $this->pageParams();

            $result = (new SecurityService())->eventList([
                'ip'         => (string) $this->request->param('ip', ''),
                'event_type' => (string) $this->request->param('event_type', ''),
                'keyword'    => (string) $this->request->param('keyword', ''),
            ], $page, $size);

            return [
                'list'      => $result['list'],
                'total'     => $result['total'],
                'page'      => $result['page'],
                'page_size' => $result['page_size'],
            ];
        });
    }

    /**
     * POST /admin-api/v1/security/events/clear
     *
     * body: {days: 0|N, confirm: 1}
     *
     * @return \think\response\Json
     */
    public function clearEvents()
    {
        return $this->run(function () {
            $this->assertSuper();
            if ((int) $this->request->param('confirm', 0) !== 1) {
                throw new BizException('请传 confirm=1 确认清理操作');
            }

            $days = max(0, (int) $this->request->param('days', 0));
            return ['deleted' => (new SecurityService())->clearEvents($days)];
        }, '日志已清理');
    }

    /**
     * GET /admin-api/v1/security/settings
     *
     * @return \think\response\Json
     */
    public function settings()
    {
        return $this->run(function () {
            $this->assertSuper();
            $service = new SecurityService();

            return [
                'settings'      => $service->settingsForForm(),
                'current_ip'    => $service->currentIp(),
                'storage_ready' => $service->storageReady(),
            ];
        });
    }

    /**
     * PUT /admin-api/v1/security/settings
     *
     * 支持两种请求体：
     * - {"values": {"enabled": true, ...}}
     * - {"enabled": true, ...}
     *
     * @return \think\response\Json
     */
    public function saveSettings()
    {
        return $this->run(function () {
            $this->assertSuper();
            $input = $this->input();
            $values = isset($input['values']) && is_array($input['values']) ? $input['values'] : $input;
            unset($values['id'], $values['values']);

            (new SecurityService())->saveSettings($values);
            return (new SecurityService())->settingsForForm();
        }, '安全设置已保存');
    }

    /**
     * POST /admin-api/v1/security/cache/refresh
     *
     * @return \think\response\Json
     */
    public function refreshCache()
    {
        return $this->run(function () {
            $this->assertSuper();
            (new SecurityService())->refreshCache();
            return null;
        }, '规则缓存已刷新');
    }
}