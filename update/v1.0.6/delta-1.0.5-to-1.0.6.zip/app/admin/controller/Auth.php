<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\middleware\AdminAuth;
use app\common\model\Admin;
use app\common\service\AuditLogService;
use think\facade\Db;
use think\facade\Session;
use think\facade\View;

class Auth extends AdminBaseController
{
    public function loginForm()
    {
        if (Session::has('admin')) {
            return redirect('/admin/index');
        }
        View::assign('error', '');
        return View::fetch('auth/login');
    }

    public function login()
    {
        $username = (string)$this->request->post('username', '');
        $password = (string)$this->request->post('password', '');

        if (!$username || !$password) {
            View::assign('error', '请输入账号和密码');
            return View::fetch('auth/login');
        }

        $admin = Admin::where('username', $username)->find();
        if (!$admin) {
            $this->auditLogin($username, null, '账号或密码错误');
            View::assign('error', '账号或密码错误');
            return View::fetch('auth/login');
        }

        if ((int) $admin->status !== 1) {
            $this->auditLogin($username, $admin, '账号已禁用');
            View::assign('error', '账号或密码错误');
            return View::fetch('auth/login');
        }

        if (!password_verify($password, (string) $admin->password_hash)) {
            $this->auditLogin($username, $admin, '账号或密码错误');
            View::assign('error', '账号或密码错误');
            return View::fetch('auth/login');
        }

        $merchantIds = $admin->role === AdminRole::SUPER
            ? []
            : array_map('intval', Db::table('admin_merchant')->where('admin_id', $admin->id)->column('merchant_id'));

        Session::set('admin', [
            'id'           => (int)$admin->id,
            'username'     => $admin->username,
            'role'         => $admin->role,
            'merchant_ids' => $merchantIds,
            'expire_at'    => time() + (int)config('session.expire', 2592000),
        ]);

        $this->auditLogin($admin->username, $admin, null);

        return redirect('/admin/index');
    }

    public function logout()
    {
        $admin = Session::get('admin');
        if (is_array($admin)) {
            (new AuditLogService())->record([
                'admin_id'       => (int) ($admin['id'] ?? 0) ?: null,
                'admin_username' => (string) ($admin['username'] ?? ''),
                'role'           => $admin['role'] ?? null,
                'auth_source'    => 'session',
                'module'         => 'auth',
                'action'         => 'logout',
                'method'         => 'POST',
                'path'           => '/admin/logout',
                'summary'        => '管理员登出',
                'detail'         => ['username' => (string) ($admin['username'] ?? '')],
                'ip'             => client_ip() ?: (string) $this->request->ip(),
                'user_agent'     => (string) $this->request->header('user-agent', ''),
                'http_status'    => 200,
                'result_code'    => 0,
            ]);
        }

        Session::clear();
        return redirect('/admin/login');
    }

    /**
     * 记录登录事件
     *
     * @param string      $username   尝试登录的用户名
     * @param Admin|null  $admin      匹配到的账号（失败时可能为空）
     * @param string|null $error      失败原因；null 表示成功
     * @return void
     */
    private function auditLogin(string $username, ?Admin $admin, ?string $error): void
    {
        $success = $error === null;
        (new AuditLogService())->record([
            'admin_id'       => $admin ? (int) $admin->id : null,
            'admin_username' => $username,
            'role'           => $admin?->role,
            'auth_source'    => 'login',
            'module'         => 'auth',
            'action'         => 'login',
            'method'         => 'POST',
            'path'           => '/admin/login',
            'summary'        => $success ? '登录成功' : '登录失败：' . $error,
            'detail'         => ['username' => $username],
            'ip'             => client_ip() ?: (string) $this->request->ip(),
            'user_agent'     => (string) $this->request->header('user-agent', ''),
            'http_status'    => 200,
            'result_code'    => $success ? 0 : 1,
            'error_message'  => $success ? '' : (string) $error,
        ]);
    }
}
