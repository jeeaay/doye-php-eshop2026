<?php

/**
 * 后台操作审计配置
 */
return [
    // 总开关
    'enabled' => true,

    // detail 字段最大字节数，超出截断
    'detail_limit' => 8192,

    // 清理批次大小与单次最大批次数（防止单请求超时）
    'batch_size'  => 5000,
    'max_batches' => 200,

    // 系统设置中提供的清理档位（天）
    'cleanup_options' => [7, 30, 365],

    // 路径首段 => 模块展示名
    'modules' => [
        'products'   => '商品',
        'categories' => '分类',
        'brands'     => '品牌',
        'orders'     => '订单',
        'aftersales' => '售后',
        'merchants'  => '商户',
        'staff'      => '人员',
        'users'      => '用户',
        'payments'   => '支付',
        'pages'      => '单页',
        'coupons'    => '优惠',
        'messages'   => '留言',
        'settings'   => '账户设置',
        'system'     => '系统设置',
        'home-ops'   => '推荐位',
        'api-keys'   => '密钥',
        'audit-logs' => '审计日志',
        'security'   => '安全设置',
        'auth'       => '登录',
        'update'     => '系统更新',
        'updates'    => '系统更新',
    ],

    // 路径末段 => 动作展示名
    'actions' => [
        'save'    => '保存',
        'create'  => '创建',
        'update'  => '更新',
        'delete'  => '删除',
        'status'  => '状态变更',
        'toggle'  => '状态变更',
        'ship'    => '发货',
        'deliver' => '确认送达',
        'approve' => '同意',
        'reject'  => '拒绝',
        'receive' => '确认收货',
        'upload'  => '上传',
        'login'   => '登录',
        'logout'  => '登出',
        'purge'   => '清理日志',
        'revoke'  => '吊销',
        'profile' => '修改资料',
        'password'=> '修改密码',
        'check'    => '检查更新',
        'plan'     => '规划升级',
        'step'     => '执行升级步骤',
        'retry'    => '重试升级',
        'rollback' => '回滚升级',
        'other'   => '其他',
    ],

    // 键名完全匹配时脱敏（支持 _password / _secret / _token 后缀）
    'sensitive_keys' => [
        'password',
        'password_hash',
        'old_password',
        'new_password',
        'secret',
        'token',
        'authorization',
        'api_key',
        'private_key',
        'smtp_password',
        'smtp.password',
        'verification_code',
        'auth_code',
    ],

    // 文件字段只记录元信息，不记录二进制内容
    'file_keys' => ['file', 'files', 'upload', 'avatar_file', 'image_file', 'video_file'],

    // 从这些参数中提取操作目标 ID
    'target_keys' => ['id', 'ids', 'order_no', 'slug', 'group'],
];