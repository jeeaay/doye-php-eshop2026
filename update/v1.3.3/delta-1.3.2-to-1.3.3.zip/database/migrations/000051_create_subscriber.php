<?php
use think\migration\Migrator;

/**
 * 邮件订阅用户
 *
 * subscriber：
 * - uk_email(email)：同一邮箱只保留一行，newsletter 快捷登录重复订阅幂等；
 * - status：1=订阅中 0=退订（后台退订只改状态，不删行）。
 */
class CreateSubscriber extends Migrator
{
    public function change()
    {
        $table = $this->table('subscriber', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '邮件订阅用户',
        ]);
        $table->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('email', 'string', ['limit' => 190, 'null' => false])
            ->addColumn('source', 'string', ['limit' => 32, 'null' => false, 'default' => 'newsletter', 'comment' => '订阅来源'])
            ->addColumn('ip', 'string', ['limit' => 64, 'null' => false, 'default' => ''])
            ->addColumn('status', 'tinyinteger', ['default' => 1, 'comment' => '1=订阅中 0=退订'])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addIndex(['email'], ['unique' => true, 'name' => 'uk_email'])
            ->create();
    }
}
