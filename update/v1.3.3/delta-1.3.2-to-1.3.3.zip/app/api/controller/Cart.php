<?php
declare(strict_types=1);

namespace app\api\controller;

use app\BaseController;
use app\common\exception\BizException;
use app\common\service\CartService;
use app\common\support\AppContext;

class Cart extends BaseController
{
    public function add()
    {
        try {
            $userId = (int)AppContext::getUserId();
            $skuId = (int)$this->request->post('sku_id', 0);
            $quantity = (int)$this->request->post('quantity', 1);
            if (!$skuId || $quantity < 1) {
                return $this->error(40001, '参数错误');
            }
            (new CartService())->addItem($userId, $skuId, $quantity);
            return $this->success();
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    public function list()
    {
        $userId = (int)AppContext::getUserId();
        $groups = (new CartService())->listCart($userId);

        $result = [];
        foreach ($groups as $group) {
            $merchant = $group['merchant'];
            $items = [];
            foreach ($group['items'] as $item) {
                $sku = $item->sku;
                $product = $sku ? $sku->product : null;
                $items[] = [
                    'id'            => $item->id,
                    'sku_id'         => $item->sku_id,
                    'product_title' => $product ? $product->title : '',
                    'spec_name'     => $sku ? $sku->spec_name : '',
                    'price'         => $sku ? (string)$sku->price : '0.00',
                    'quantity'      => $item->quantity,
                    'main_image'    => $product ? $product->main_image : '',
                    'stock'         => $sku ? $sku->stock : 0,
                    'selected'      => $item->selected,
                ];
            }
            $result[] = [
                'merchant' => $merchant ? ['id' => $merchant->id, 'name' => $merchant->name] : null,
                'items'    => $items,
            ];
        }

        return $this->success(['groups' => $result]);
    }

    public function update()
    {
        try {
            $userId = (int)AppContext::getUserId();
            $id = (int)$this->request->post('id', 0);
            if (!$id) {
                return $this->error(40001, '参数错误');
            }
            $cartService = new CartService();
            $quantity = $this->request->post('quantity');
            if ($quantity !== null) {
                $cartService->updateQty($id, $userId, (int)$quantity);
            }
            $selected = $this->request->post('selected');
            if ($selected !== null) {
                $cartService->toggleSelect($id, $userId, (int)$selected);
            }
            return $this->success();
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    public function remove()
    {
        try {
            $userId = (int)AppContext::getUserId();
            $ids = $this->request->post('ids', []);
            if (!is_array($ids) || empty($ids)) {
                return $this->error(40001, '参数错误');
            }
            $ids = array_map('intval', $ids);
            (new CartService())->remove($ids, $userId);
            return $this->success();
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    /** POST /api/cart/preview —— 游客车展示数据（无需登录） */
    public function preview()
    {
        $items = $this->request->post('items', []);
        if (!is_array($items)) {
            return $this->error(40001, '参数错误');
        }
        return $this->success((new CartService())->previewItems($items));
    }

    /** POST /api/cart/merge —— 登录后合并游客车 */
    public function merge()
    {
        try {
            $items = $this->request->post('items', []);
            if (!is_array($items)) {
                return $this->error(40001, '参数错误');
            }
            $userId = (int)AppContext::getUserId();
            return $this->success((new CartService())->mergeItems($userId, $items));
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }
}
