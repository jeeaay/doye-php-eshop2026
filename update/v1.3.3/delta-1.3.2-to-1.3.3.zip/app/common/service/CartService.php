<?php

namespace app\common\service;

use app\common\exception\BizException;
use app\common\model\Cart;
use app\common\model\ProductSku;
use think\facade\Db;

class CartService
{
    public function addItem(int $userId, int $skuId, int $qty): void
    {
        $sku = ProductSku::find($skuId);
        if (!$sku || $sku->status != 1) {
            throw new BizException('商品规格不存在或已下架');
        }
        $this->upsertItem($userId, $sku, $qty, false);
    }

    /**
     * 游客购物车合并：同 sku 累加，超库存静默截断（不因某条失败中断登录）
     *
     * @return array{merged: int[], dropped: int[]}
     */
    public function mergeItems(int $userId, array $items): array
    {
        $normalized = $this->normalizeItems($items);
        $merged = [];
        $dropped = [];
        if (!$normalized) {
            return ['merged' => $merged, 'dropped' => $dropped];
        }

        $map = [];
        foreach (ProductSku::whereIn('id', array_keys($normalized))->select() as $sku) {
            $map[(int) $sku->id] = $sku;
        }

        foreach ($normalized as $skuId => $qty) {
            $sku = $map[$skuId] ?? null;
            if (!$sku || $sku->status != 1 || (int) $sku->stock < 1) {
                $dropped[] = $skuId;
                continue;
            }
            $this->upsertItem($userId, $sku, $qty, true);
            $merged[] = $skuId;
        }

        return ['merged' => $merged, 'dropped' => $dropped];
    }

    /**
     * 游客购物车展示数据（服务端取价，前端不做金额推断）
     *
     * @return array{items: array<int, array<string, mixed>>, subtotal: string}
     */
    public function previewItems(array $items): array
    {
        $normalized = $this->normalizeItems($items);
        if (!$normalized) {
            return ['items' => [], 'subtotal' => '0.00'];
        }

        $map = [];
        foreach (ProductSku::with(['product'])->whereIn('id', array_keys($normalized))->select() as $sku) {
            $map[(int) $sku->id] = $sku;
        }

        $rows = [];
        $subtotal = 0.0;
        foreach ($normalized as $skuId => $qty) {
            $sku = $map[$skuId] ?? null;
            $product = $sku ? $sku->product : null;
            $available = $sku && $sku->status == 1 && $product && (int) $sku->stock > 0;
            $price = $sku ? (float) $sku->price : 0.0;
            if ($available) {
                $subtotal += $price * $qty;
            }
            $rows[] = [
                'sku_id'        => $skuId,
                'product_title' => $product ? (string) $product->title : '',
                'spec_name'     => $sku ? (string) $sku->spec_name : '',
                'price'         => number_format($price, 2, '.', ''),
                'quantity'      => $qty,
                'main_image'    => $product ? (string) $product->main_image : '',
                'stock'         => $sku ? (int) $sku->stock : 0,
                'available'     => (bool) $available,
            ];
        }

        return ['items' => $rows, 'subtotal' => number_format($subtotal, 2, '.', '')];
    }

    /**
     * 累加到 (user_id, sku_id) 唯一行
     *
     * @param bool $clampToStock 超库存时截断到库存；false 则抛「库存不足」
     */
    private function upsertItem(int $userId, ProductSku $sku, int $qty, bool $clampToStock): bool
    {
        $stock = (int) $sku->stock;
        $existing = Cart::where('user_id', $userId)->where('sku_id', (int) $sku->id)->find();
        $newQty = ($existing ? (int) $existing->quantity : 0) + $qty;
        if ($newQty > $stock) {
            if (!$clampToStock) {
                throw new BizException('库存不足');
            }
            $newQty = $stock;
        }
        if ($newQty < 1) {
            return false;
        }
        if ($existing) {
            $existing->quantity = $newQty;
            $existing->save();
        } else {
            $cart = new Cart();
            $cart->user_id = $userId;
            $cart->sku_id = (int) $sku->id;
            $cart->quantity = $newQty;
            $cart->selected = 1;
            $cart->save();
        }
        return true;
    }

    /**
     * 入参整形：条数 ≤100，quantity 夹 1..999，同 sku 合并
     *
     * @return array<int, int> sku_id => quantity
     */
    private function normalizeItems(array $items): array
    {
        $normalized = [];
        foreach (array_slice($items, 0, 100) as $item) {
            if (!is_array($item)) {
                continue;
            }
            $skuId = (int) ($item['sku_id'] ?? 0);
            $qty = (int) ($item['quantity'] ?? 0);
            if ($skuId < 1 || $qty < 1) {
                continue;
            }
            $qty = min($qty, 999);
            $normalized[$skuId] = min(999, ($normalized[$skuId] ?? 0) + $qty);
        }
        return $normalized;
    }

    public function updateQty(int $id, int $userId, int $qty): void
    {
        $cart = Cart::where('id', $id)->where('user_id', $userId)->find();
        if (!$cart) {
            throw new BizException('购物车项不存在');
        }
        $sku = ProductSku::find($cart->sku_id);
        if ($qty > ($sku->stock ?? 0)) {
            throw new BizException('库存不足');
        }
        $cart->quantity = $qty;
        $cart->save();
    }

    public function remove(array $ids, int $userId): void
    {
        Cart::where('id', 'in', $ids)->where('user_id', $userId)->delete();
    }

    public function toggleSelect(int $id, int $userId, int $selected): void
    {
        $cart = Cart::where('id', $id)->where('user_id', $userId)->find();
        if (!$cart) {
            throw new BizException('购物车项不存在');
        }
        $cart->selected = $selected ? 1 : 0;
        $cart->save();
    }

    public function listCart(int $userId): array
    {
        $items = Cart::with(['sku.product.merchant'])
            ->where('user_id', $userId)
            ->order('id', 'desc')
            ->select();
        $groups = [];
        foreach ($items as $item) {
            $sku = $item->sku;
            $product = $sku ? $sku->product : null;
            $merchant = $product ? $product->merchant : null;
            $merchantId = $merchant ? $merchant->id : 0;
            if (!isset($groups[$merchantId])) {
                $groups[$merchantId] = [
                    'merchant' => $merchant,
                    'items' => [],
                ];
            }
            $groups[$merchantId]['items'][] = $item;
        }
        return array_values($groups);
    }
}
