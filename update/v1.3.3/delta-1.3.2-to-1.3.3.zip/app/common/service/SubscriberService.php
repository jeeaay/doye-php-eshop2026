<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\lib\SiteAuth;
use think\facade\Db;

class SubscriberService
{
    /**
     * 记录订阅（同邮箱幂等）
     *
     * @return bool 是否新建了订阅行
     */
    public function subscribe(string $email, string $source = 'newsletter', string $ip = ''): bool
    {
        $email = SiteAuth::normalizeEmail($email);
        if (Db::name('subscriber')->where('email', $email)->find()) {
            return false;
        }

        $now = date('Y-m-d H:i:s');
        try {
            Db::name('subscriber')->insert([
                'email'       => $email,
                'source'      => mb_substr($source, 0, 32),
                'ip'          => mb_substr($ip, 0, 64),
                'status'      => 1,
                'create_time' => $now,
                'update_time' => $now,
            ]);
        } catch (\Throwable $e) {
            // 并发插入撞 uk_email：已存在即视为成功，其余异常继续抛出
            if (!Db::name('subscriber')->where('email', $email)->find()) {
                throw $e;
            }
            return false;
        }
        return true;
    }
}
