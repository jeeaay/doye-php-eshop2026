/*
 * 独立站前台 API 客户端
 *
 * 对应关系（原 Go 商城 -> PHP 后台）：
 *   GET  /api/auth/me                 -> GET  /api/site/auth/me
 *   POST /api/auth/send-code          -> POST /api/site/auth/send-code
 *   POST /api/auth/verify-code        -> POST /api/site/auth/verify-code
 *   POST /api/auth/sign-out           -> POST /api/site/auth/sign-out
 *   POST /api/cart/add   (product)    -> POST /api/cart/add   (sku_id)
 *   GET  /api/cart/:cart_id           -> GET  /api/cart/list
 *   POST /api/cart/sync               -> POST /api/cart/update | /api/cart/remove
 *   GET  /api/orders                  -> GET  /api/order/list
 *   GET  /api/addresses               -> GET  /api/user/address/list
 * 统一响应包：{ code: 0, message: 'ok', data: ... }
 */
(function () {
  var TOKEN_KEY = 'site_token';
  var GUEST_CART_KEY = 'guest_cart';

  var StoreAPI = {
    currency: function () {
      return (document.body && document.body.dataset && document.body.dataset.currency) || '$';
    },

    token: function () {
      return localStorage.getItem(TOKEN_KEY) || '';
    },

    setToken: function (token) {
      if (token) {
        localStorage.setItem(TOKEN_KEY, token);
      } else {
        localStorage.removeItem(TOKEN_KEY);
      }
    },

    headers: function (extra) {
      var headers = { Accept: 'application/json' };
      var token = StoreAPI.token();
      if (token) {
        headers.Authorization = 'Bearer ' + token;
      }
      return Object.assign(headers, extra || {});
    },

    request: async function (path, options) {
      options = options || {};
      var init = {
        method: options.method || 'GET',
        headers: StoreAPI.headers(options.body ? { 'Content-Type': 'application/json' } : {}),
        credentials: 'same-origin'
      };
      if (options.body) {
        init.body = JSON.stringify(options.body);
      }

      var res = await fetch(path, init);
      var payload = null;
      try {
        payload = await res.json();
      } catch (e) {
        throw new Error('Server response error');
      }

      if (payload.code === 401 || res.status === 401) {
        StoreAPI.setToken('');
        StoreAuth.emit(false);
        throw new Error('Please sign in first');
      }
      if (payload.code !== 0) {
        throw new Error(payload.message || 'Request failed');
      }
      return payload.data;
    },

    get: function (path) {
      return StoreAPI.request(path, { method: 'GET' });
    },

    post: function (path, body) {
      return StoreAPI.request(path, { method: 'POST', body: body || {} });
    }
  };

  var StoreAuth = {
    _listeners: [],
    _loggedIn: null,

    isLoggedIn: function () {
      return !!StoreAPI.token();
    },

    onChange: function (fn) {
      StoreAuth._listeners.push(fn);
      if (StoreAuth._loggedIn !== null) {
        fn({ loggedIn: StoreAuth._loggedIn });
      }
    },

    emit: function (loggedIn) {
      StoreAuth._loggedIn = loggedIn;
      StoreAuth._listeners.forEach(function (fn) {
        try { fn({ loggedIn: loggedIn }); } catch (e) { /* ignore */ }
      });
      window.dispatchEvent(new CustomEvent('site-auth-changed', { detail: { loggedIn: loggedIn } }));
    },

    /** 校验本地 token 是否仍然有效 */
    check: async function () {
      if (!StoreAPI.token()) {
        StoreAuth.emit(false);
        return null;
      }
      try {
        var user = await StoreAPI.get('/api/site/auth/me');
        StoreAuth.emit(true);
        // 上次合并失败留下的游客车：登录态下补一次合并
        if (StoreCart.guestItems().length) { StoreCart.merge(); }
        return user;
      } catch (e) {
        StoreAPI.setToken('');
        StoreAuth.emit(false);
        return null;
      }
    },

    sendCode: function (email) {
      return StoreAPI.post('/api/site/auth/send-code', { email: email });
    },

    verifyCode: async function (email, code) {
      var data = await StoreAPI.post('/api/site/auth/verify-code', { email: email, code: code });
      StoreAPI.setToken(data.token);
      StoreAuth.emit(true);
      // 三个登录入口共用：登录后立即合并游客车（失败不阻塞登录）
      await StoreCart.merge();
      return data.user;
    },

    logout: async function () {
      try {
        await StoreAPI.post('/api/site/auth/sign-out', {});
      } catch (e) { /* ignore */ }
      StoreAPI.setToken('');
      StoreAuth.emit(false);
    }
  };

  var StoreCart = {
    _merging: null,

    /** 游客车本地条目 [{sku_id, quantity}]；隐私模式等异常降级为空车 */
    guestItems: function () {
      try {
        var list = JSON.parse(localStorage.getItem(GUEST_CART_KEY) || '[]');
        if (!Array.isArray(list)) { return []; }
        return list.map(function (i) {
          return {
            sku_id: parseInt(i && i.sku_id, 10) || 0,
            quantity: Math.max(1, parseInt(i && i.quantity, 10) || 1)
          };
        }).filter(function (i) { return i.sku_id > 0; });
      } catch (e) {
        return [];
      }
    },

    _saveGuest: function (items) {
      try {
        if (items.length) {
          localStorage.setItem(GUEST_CART_KEY, JSON.stringify(items));
        } else {
          localStorage.removeItem(GUEST_CART_KEY);
        }
      } catch (e) { /* 存储不可用时按空车处理 */ }
    },

    guestCount: function () {
      return StoreCart.guestItems().reduce(function (sum, i) { return sum + i.quantity; }, 0);
    },

    /** 购物车商品件数（顶部角标） */
    count: async function () {
      if (!StoreAuth.isLoggedIn()) {
        return StoreCart.guestCount();
      }
      try {
        var data = await StoreAPI.get('/api/cart/list');
        var total = 0;
        (data.groups || []).forEach(function (group) {
          (group.items || []).forEach(function (item) { total += parseInt(item.quantity, 10) || 0; });
        });
        return total;
      } catch (e) {
        return 0;
      }
    },

    list: async function () {
      if (!StoreAuth.isLoggedIn()) {
        return { groups: [] };
      }
      return StoreAPI.get('/api/cart/list');
    },

    /** 游客车展示条目：本地 sku_id/quantity + 服务端 preview 取价 */
    guestDisplayItems: async function () {
      var local = StoreCart.guestItems();
      if (!local.length) { return { items: [], subtotal: '0.00' }; }
      var data = await StoreAPI.post('/api/cart/preview', { items: local });
      var items = ((data && data.items) || []).map(function (r) {
        return {
          id: 'g:' + r.sku_id,
          sku_id: r.sku_id,
          product_title: r.product_title,
          spec_name: r.spec_name,
          price: r.price,
          quantity: r.quantity,
          main_image: r.main_image,
          stock: r.stock,
          available: !!r.available,
          selected: true
        };
      });
      return { items: items, subtotal: (data && data.subtotal) || '0.00' };
    },

    add: async function (skuId, quantity) {
      var qty = Math.max(1, parseInt(quantity, 10) || 1);
      if (!StoreAuth.isLoggedIn()) {
        var items = StoreCart.guestItems();
        var found = items.find(function (i) { return String(i.sku_id) === String(skuId); });
        if (found) {
          found.quantity = Math.min(999, found.quantity + qty);
        } else {
          items.push({ sku_id: parseInt(skuId, 10) || 0, quantity: qty });
        }
        StoreCart._saveGuest(items);
        StoreCart.notify();
        return;
      }
      try {
        await StoreAPI.post('/api/cart/add', { sku_id: skuId, quantity: qty });
      } catch (e) {
        // token 失效：降级为游客车，不打断加购
        if (e.message === 'Please sign in first') {
          return StoreCart.add(skuId, qty);
        }
        throw e;
      }
      StoreCart.notify();
    },

    update: async function (id, payload) {
      await StoreAPI.post('/api/cart/update', Object.assign({ id: id }, payload));
      StoreCart.notify();
    },

    remove: async function (ids) {
      await StoreAPI.post('/api/cart/remove', { ids: ids });
      StoreCart.notify();
    },

    updateLocal: function (skuId, quantity) {
      var qty = Math.min(999, Math.max(1, parseInt(quantity, 10) || 1));
      var items = StoreCart.guestItems();
      items.forEach(function (i) {
        if (String(i.sku_id) === String(skuId)) { i.quantity = qty; }
      });
      StoreCart._saveGuest(items);
      StoreCart.notify();
    },

    removeLocal: function (skuIds) {
      var drop = (Array.isArray(skuIds) ? skuIds : [skuIds]).map(String);
      var rest = StoreCart.guestItems().filter(function (i) {
        return drop.indexOf(String(i.sku_id)) === -1;
      });
      StoreCart._saveGuest(rest);
      StoreCart.notify();
    },

    /**
     * 登录后合并游客车：只清除成功合并的条目，失败保留本地待下次重试；
     * 合并异常不向上抛，避免阻塞登录主流程。
     */
    merge: async function () {
      if (!StoreAuth.isLoggedIn()) { return null; }
      var local = StoreCart.guestItems();
      if (!local.length) { return null; }
      if (StoreCart._merging) { return StoreCart._merging; }
      StoreCart._merging = (async function () {
        try {
          var data = await StoreAPI.post('/api/cart/merge', { items: local });
          var merged = ((data && data.merged) || []).map(String);
          var rest = StoreCart.guestItems().filter(function (i) {
            return merged.indexOf(String(i.sku_id)) === -1;
          });
          StoreCart._saveGuest(rest);
          StoreCart.notify();
          return data;
        } catch (e) {
          return null;
        } finally {
          StoreCart._merging = null;
        }
      })();
      return StoreCart._merging;
    },

    notify: async function () {
      var count = await StoreCart.count();
      window.dispatchEvent(new CustomEvent('cart-updated', { detail: { count: count } }));
    }
  };

  var StoreOrders = {
    list: function (page, status) {
      return StoreAPI.get('/api/order/list?page=' + (page || 1) + '&status=' + encodeURIComponent(status || 'all'));
    },
    detail: function (id) {
      return StoreAPI.get('/api/order/detail?id=' + id);
    },
    confirm: function (orderId) {
      return StoreAPI.post('/api/order/confirm', { order_id: orderId });
    },
    cancel: function (payId) {
      return StoreAPI.post('/api/order/cancel', { order_pay_id: payId });
    },
    checkout: function (payload) {
      return StoreAPI.post('/api/order/checkout', payload);
    },
    pay: function (payId, channel) {
      return StoreAPI.post('/api/order/pay', { order_pay_id: payId, channel: channel });
    },
    paymentStatus: function (payId) {
      return StoreAPI.get('/api/payment/status?order_pay_id=' + payId);
    },
    channels: function () {
      return StoreAPI.get('/api/payment/channels');
    }
  };

  var StoreAddress = {
    list: function () {
      return StoreAPI.get('/api/user/address/list');
    },
    add: function (payload) {
      return StoreAPI.post('/api/user/address/add', payload);
    },
    update: function (payload) {
      return StoreAPI.post('/api/user/address/update', payload);
    },
    remove: function (id) {
      return StoreAPI.post('/api/user/address/delete', { id: id });
    }
  };

  var StoreUser = {
    profile: function () {
      return StoreAPI.get('/api/user/profile');
    },
    update: function (payload) {
      return StoreAPI.post('/api/user/update', payload);
    }
  };

  var StoreUI = {
    money: function (value) {
      var num = parseFloat(value || 0);
      return StoreAPI.currency() + num.toFixed(2);
    },
    toast: function (message, type) {
      var host = document.getElementById('site-toast');
      if (!host) {
        host = document.createElement('div');
        host.id = 'site-toast';
        host.className = 'site-toast';
        document.body.appendChild(host);
      }
      host.textContent = message;
      host.dataset.type = type || 'info';
      host.classList.add('is-visible');
      clearTimeout(host._timer);
      host._timer = setTimeout(function () { host.classList.remove('is-visible'); }, 3000);
    }
  };

  window.StoreAPI = StoreAPI;
  window.StoreAuth = StoreAuth;
  window.StoreCart = StoreCart;
  window.StoreOrders = StoreOrders;
  window.StoreAddress = StoreAddress;
  window.StoreUser = StoreUser;
  window.StoreUI = StoreUI;
})();