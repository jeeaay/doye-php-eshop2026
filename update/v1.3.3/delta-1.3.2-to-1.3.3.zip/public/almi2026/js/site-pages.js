/*
 * 前台页面逻辑（Alpine 组件）
 *
 * 全部对接 PHP 后台已有接口（见 store.js 顶部映射表）：
 *  商品详情  -> 服务端渲染 + 本文件的 SKU 选择/加购
 *  登录      -> /api/site/auth/*
 *  结算      -> /api/order/checkout + /api/order/pay
 *  心愿单    -> localStorage（后台无收藏表，见 todo.md）
 */
(function () {
  function productData() {
    var el = document.querySelector('main[data-product]');
    if (!el) { return null; }
    try { return JSON.parse(el.dataset.product); } catch (e) { return null; }
  }

  /* ---------------- 商品详情 ---------------- */
  window.productDetail = function () {
    var product = productData() || { skus: [] };
    var skus = product.skus || [];

    return {
      quantity: 1,
      skus: skus,
      selectedSkuId: skus.length ? skus[0].id : 0,
      detailsOpen: true,
      specsOpen: false,
      shippingOpen: false,
      reviewsOpen: false,
      adding: false,
      added: false,

      init() {},

      get selectedSku() {
        var id = this.selectedSkuId;
        return this.skus.find(function (s) { return String(s.id) === String(id); }) || null;
      },
      get inStock() {
        var sku = this.selectedSku;
        return !sku || sku.stock > 0;
      },
      selectSku(id) {
        this.selectedSkuId = id;
      },
      priceOf(id) {
        var sku = this.skus.find(function (s) { return String(s.id) === String(id); });
        return sku ? sku.price : '';
      },
      async addToCart() {
        if (!this.selectedSkuId) { return; }
        this.adding = true;
        try {
          await StoreCart.add(this.selectedSkuId, this.quantity);
          this.added = true;
          StoreUI.toast('Added to basket', 'success');
          setTimeout(() => { this.added = false; }, 2000);
        } catch (e) {
          StoreUI.toast(e.message, 'error');
        } finally {
          this.adding = false;
        }
      },
      async buyNow() {
        if (!this.selectedSkuId) { return; }
        try {
          await StoreCart.add(this.selectedSkuId, this.quantity);
          window.location.href = '/checkout';
        } catch (e) {
          StoreUI.toast(e.message, 'error');
        }
      },
      toggle() {}
    };
  };

  window.wishlistButton = function () {
    var product = productData();
    return {
      active: false,
      init() {
        if (product) { this.active = StoreWishlist.has(product.id); }
      },
      toggle() {
        if (!product) { return; }
        this.active = StoreWishlist.toggle({
          id: product.id,
          name: product.name,
          price: StoreAPI.currency() + product.price,
          image: product.image,
          url: product.url
        });
        StoreUI.toast(this.active ? 'Added to wishlist' : 'Removed from wishlist', 'info');
      }
    };
  };

  /* ---------------- 商品评论 ---------------- */
  window.productReviews = function () {
    function escapeHtml(value) {
      return String(value == null ? '' : value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
    }

    return {
      productId: 0,
      pageSize: 5,
      page: 1,
      total: 0,
      hasMore: false,
      loading: false,
      _seq: 0,
      filters: { rating: '', media: false, keyword: '' },

      // 写评论面板
      panelOpen: false,
      formOpen: false,
      eligible: [],
      selectedOrderItemId: 0,
      rating: 0,
      title: '',
      content: '',
      images: [],
      anonymous: false,
      uploading: false,
      submitting: false,
      submitted: false,
      formError: '',
      notice: '',

      labels: {},
      urls: {},

      init() {
        var ds = this.$root.dataset;
        this.productId = parseInt(ds.reviewProduct, 10) || 0;
        this.pageSize = parseInt(ds.reviewPageSize, 10) || 5;
        this.total = parseInt(ds.reviewTotal, 10) || 0;
        this.hasMore = ds.reviewHasMore === '1';

        this.urls = {
          star: ds.starUrl || '',
          thumbUp: ds.thumbUpUrl || '',
          thumbDown: ds.thumbDownUrl || ''
        };
        this.labels = {
          verified: ds.labelVerified || '',
          helpful: ds.labelHelpful || '',
          yes: ds.labelYes || '',
          no: ds.labelNo || '',
          reply: ds.labelReply || '',
          empty: ds.labelEmpty || '',
          emptyFiltered: ds.labelEmptyFiltered || '',
          error: ds.msgError || '',
          uploadFailed: ds.msgUploadFailed || '',
          maxImages: ds.msgMaxImages || '',
          ratingRequired: ds.msgRatingRequired || '',
          pending: ds.msgPending || '',
          noEligible: ds.msgNoEligible || ''
        };

        this.syncFooter();
      },

      /* ---- 列表 / 筛选 / 加载更多 ---- */

      listEl() { return this.$root.querySelector('.review-list'); },
      emptyEl() { return this.$root.querySelector('.review-empty'); },
      moreEl() { return this.$root.querySelector('.review-more'); },

      hasActiveFilters() {
        return !!(this.filters.rating || this.filters.media || this.filters.keyword);
      },

      syncFooter() {
        var list = this.listEl();
        var count = list ? list.querySelectorAll('.review-item').length : 0;
        var empty = this.emptyEl();
        if (empty) {
          if (count === 0) {
            empty.textContent = this.hasActiveFilters() ? this.labels.emptyFiltered : this.labels.empty;
            empty.hidden = false;
          } else {
            empty.hidden = true;
          }
        }
        var more = this.moreEl();
        if (more) { more.hidden = !(this.hasMore && count > 0); }
      },

      async fetchList(reset) {
        var seq = this._seq = this._seq + 1;
        this.loading = true;
        var nextPage = reset ? 1 : this.page + 1;
        var query = new URLSearchParams();
        query.set('product_id', String(this.productId));
        query.set('page', String(nextPage));
        query.set('size', String(this.pageSize));
        if (this.filters.rating) { query.set('rating', String(this.filters.rating)); }
        if (this.filters.media) { query.set('media', '1'); }
        if (this.filters.keyword) { query.set('keyword', this.filters.keyword); }

        try {
          var data = await StoreAPI.get('/api/review/list?' + query.toString());
          if (seq !== this._seq) { return; }
          var html = (data.list || []).map(this.itemHtml, this).join('');
          var list = this.listEl();
          if (list) {
            if (reset) {
              list.innerHTML = html;
            } else {
              list.insertAdjacentHTML('beforeend', html);
            }
          }
          this.page = parseInt(data.page, 10) || nextPage;
          this.total = parseInt(data.total, 10) || 0;
          this.hasMore = !!data.hasMore;
          this.syncFooter();
        } catch (e) {
          if (seq !== this._seq) { return; }
          StoreUI.toast(e.message || this.labels.error, 'error');
        } finally {
          if (seq === this._seq) { this.loading = false; }
        }
      },

      applyFilters() { return this.fetchList(true); },

      loadMore() {
        if (!this.hasMore || this.loading) { return; }
        return this.fetchList(false);
      },

      starsHtml(rating) {
        var out = '';
        for (var n = 1; n <= 5; n++) {
          out += '<img src="' + escapeHtml(this.urls.star) + '" width="12" height="12" alt="" class="star'
            + (n <= rating ? '' : ' star--empty') + '">';
        }
        return out;
      },

      itemHtml(item) {
        var esc = escapeHtml;
        var rating = parseInt(item.rating, 10) || 0;
        var html = '<article class="review-item" data-review-id="' + esc(item.id) + '">';

        html += '<div class="review-meta"><div class="reviewer-info"><strong>' + esc(item.author) + '</strong>';
        if (parseInt(item.is_verified, 10) === 1) {
          html += '<span class="verified-buyer">' + esc(this.labels.verified) + '</span>';
        }
        html += '</div><span class="review-date">' + esc(String(item.create_time || '').slice(0, 10)) + '</span></div>';

        html += '<div class="review-content"><div class="stars" role="img" aria-label="' + rating + ' / 5">'
          + this.starsHtml(rating) + '</div>';
        if (item.title) { html += '<h4>' + esc(item.title) + '</h4>'; }
        html += '<p>' + esc(item.content) + '</p>';
        if (item.images && item.images.length) {
          html += '<div class="review-images">';
          for (var i = 0; i < item.images.length; i++) {
            html += '<a href="' + esc(item.images[i]) + '" target="_blank" rel="noopener">'
              + '<img src="' + esc(item.images[i]) + '" alt="" loading="lazy"></a>';
          }
          html += '</div>';
        }
        html += '</div>';

        if (item.admin_reply) {
          html += '<div class="review-reply"><strong>' + esc(this.labels.reply) + '</strong><p>'
            + esc(item.admin_reply) + '</p></div>';
        }

        var myVote = parseInt(item.my_vote, 10) || 0;
        html += '<div class="review-actions"><span>' + esc(this.labels.helpful) + '</span>'
          + '<button type="button" data-review-vote="1" aria-label="' + esc(this.labels.yes) + '"'
          + (myVote === 1 ? ' class="is-active"' : '') + '>'
          + '<img src="' + esc(this.urls.thumbUp) + '" width="14" height="14" alt=""> '
          + '<span data-vote-count="1">' + (parseInt(item.helpful_yes, 10) || 0) + '</span></button>'
          + '<button type="button" data-review-vote="2" aria-label="' + esc(this.labels.no) + '"'
          + (myVote === 2 ? ' class="is-active"' : '') + '>'
          + '<img src="' + esc(this.urls.thumbDown) + '" width="14" height="14" alt=""> '
          + '<span data-vote-count="2">' + (parseInt(item.helpful_no, 10) || 0) + '</span></button>'
          + '</div>';

        return html + '</article>';
      },

      /* ---- 有用 / 无用投票 ---- */

      onListClick(event) {
        var button = event.target.closest('[data-review-vote]');
        if (!button) { return; }
        var item = button.closest('[data-review-id]');
        if (item) { this.vote(item, button); }
      },

      async vote(item, button) {
        if (!StoreAuth.isLoggedIn()) { this.gotoLogin(); return; }
        var reviewId = parseInt(item.dataset.reviewId, 10) || 0;
        var vote = parseInt(button.dataset.reviewVote, 10) || 0;
        if (!reviewId || !vote) { return; }

        button.disabled = true;
        try {
          var data = await StoreAPI.post('/api/review/helpful', { review_id: reviewId, vote: vote });
          var buttons = item.querySelectorAll('[data-review-vote]');
          for (var i = 0; i < buttons.length; i++) {
            var self = buttons[i];
            var type = parseInt(self.dataset.reviewVote, 10);
            self.classList.toggle('is-active', parseInt(data.vote, 10) === type);
            var counter = self.querySelector('[data-vote-count]');
            if (counter) {
              counter.textContent = String(type === 1 ? data.helpful_yes : data.helpful_no);
            }
          }
        } catch (e) {
          if (e.message === 'Please sign in first') { this.gotoLogin(); return; }
          StoreUI.toast(e.message || this.labels.error, 'error');
        } finally {
          button.disabled = false;
        }
      },

      /* ---- 写评论 ---- */

      gotoLogin() {
        var redirect = encodeURIComponent(window.location.pathname + window.location.search);
        window.location.href = '/login?redirect=' + redirect;
      },

      async openForm() {
        if (!StoreAuth.isLoggedIn()) { this.gotoLogin(); return; }
        if (this.panelOpen && (this.formOpen || this.notice)) { return; }

        this.formError = '';
        this.notice = '';
        this.panelOpen = true;

        try {
          var data = await StoreAPI.get('/api/review/eligible?product_id=' + this.productId);
          var list = (data && data.list) || [];
          this.eligible = list;
          if (!list.length) {
            this.formOpen = false;
            this.notice = this.labels.noEligible;
            return;
          }
          this.selectedOrderItemId = parseInt(list[0].order_item_id, 10) || 0;
          this.formOpen = true;
        } catch (e) {
          if (e.message === 'Please sign in first') { this.gotoLogin(); return; }
          this.panelOpen = false;
          StoreUI.toast(e.message || this.labels.error, 'error');
        }
      },

      closeForm() {
        this.formOpen = false;
        this.formError = '';
        if (!this.submitted) { this.panelOpen = false; }
      },

      async upload(event) {
        var input = event.target;
        var files = Array.prototype.slice.call(input.files || []);
        input.value = '';
        if (!files.length || !this.formOpen) { return; }
        if (!StoreAuth.isLoggedIn()) { this.gotoLogin(); return; }

        var room = 6 - this.images.length;
        if (room <= 0) { StoreUI.toast(this.labels.maxImages, 'error'); return; }
        if (files.length > room) {
          files = files.slice(0, room);
          StoreUI.toast(this.labels.maxImages, 'error');
        }

        this.uploading = true;
        for (var i = 0; i < files.length; i++) {
          try {
            var url = await this.uploadOne(files[i]);
            if (url) { this.images.push(url); }
          } catch (e) {
            if (e.message === 'Please sign in first') { this.gotoLogin(); break; }
            StoreUI.toast(e.message || this.labels.uploadFailed, 'error');
          }
        }
        this.uploading = false;
      },

      async uploadOne(file) {
        var body = new FormData();
        body.append('file', file);

        var res = await fetch('/api/review/upload', {
          method: 'POST',
          headers: StoreAPI.headers(),
          credentials: 'same-origin',
          body: body
        });

        var payload = null;
        try { payload = await res.json(); } catch (e) { payload = null; }
        if (res.status === 401 || (payload && payload.code === 401)) {
          StoreAPI.setToken('');
          StoreAuth.emit(false);
          throw new Error('Please sign in first');
        }
        if (!payload || payload.code !== 0) {
          throw new Error((payload && payload.message) || this.labels.uploadFailed);
        }
        return payload.data && payload.data.url ? payload.data.url : '';
      },

      async submit() {
        if (this.submitting || this.submitted) { return; }
        this.formError = '';

        if (!this.rating) { this.formError = this.labels.ratingRequired; return; }
        if (!this.selectedOrderItemId) { this.formError = this.labels.noEligible; return; }

        this.submitting = true;
        try {
          await StoreAPI.post('/api/review/create', {
            order_item_id: this.selectedOrderItemId,
            rating: this.rating,
            title: this.title,
            content: this.content,
            images: this.images,
            is_anonymous: this.anonymous ? 1 : 0
          });

          this.submitted = true;
          this.formOpen = false;
          this.notice = this.labels.pending;
          this.title = '';
          this.content = '';
          this.images = [];
          this.rating = 0;
          this.anonymous = false;
        } catch (e) {
          if (e.message === 'Please sign in first') { this.gotoLogin(); return; }
          this.formError = e.message || this.labels.error;
        } finally {
          this.submitting = false;
        }
      }
    };
  };

  /* ---------------- 登录 ---------------- */
  window.loginPage = function () {
    return {
      step: 'email',
      email: '',
      code: '',
      error: '',
      sending: false,
      verifying: false,
      countdown: 0,
      _timer: null,

      init() {
        var params = new URLSearchParams(window.location.search);
        var email = params.get('email');
        if (email) { this.email = email; }
        if (StoreAuth.isLoggedIn()) { window.location.href = this.redirectTo(); }
      },

      redirectTo() {
        var params = new URLSearchParams(window.location.search);
        return params.get('redirect') || '/account';
      },

      startCountdown() {
        this.countdown = 60;
        clearInterval(this._timer);
        this._timer = setInterval(() => {
          this.countdown -= 1;
          if (this.countdown <= 0) { clearInterval(this._timer); }
        }, 1000);
      },

      async sendCode() {
        this.error = '';
        if (!this.email) { this.error = 'Please enter your email'; return; }
        this.sending = true;
        try {
          var res = await StoreAuth.sendCode(this.email);
          this.step = 'code';
          this.startCountdown();
          if (res && res.dev_code) {
            this.code = res.dev_code;
            StoreUI.toast('Dev mode code: ' + res.dev_code, 'info');
          } else {
            StoreUI.toast('Verification code sent', 'success');
          }
        } catch (e) {
          this.error = e.message;
        } finally {
          this.sending = false;
        }
      },

      async verifyCode() {
        this.error = '';
        if (this.code.length !== 6) { this.error = 'Enter the 6-digit code'; return; }
        this.verifying = true;
        try {
          await StoreAuth.verifyCode(this.email, this.code);
          window.location.href = this.redirectTo();
        } catch (e) {
          this.error = e.message;
        } finally {
          this.verifying = false;
        }
      }
    };
  };

  /* ---------------- 页脚 newsletter 快捷登录 ---------------- */
  window.newsletterAuth = function () {
    return {
      open: false,
      email: '',
      code: '',
      error: '',
      sending: false,
      verifying: false,
      countdown: 0,
      _timer: null,

      openFromForm(e) {
        var form = (e && e.target) || document.getElementById('newsletter-form');
        var input = form ? form.querySelector('input[name="email"]') : null;
        if (StoreAuth.isLoggedIn()) {
          StoreUI.toast("You're already signed in", 'info');
          return;
        }
        var email = input ? String(input.value || '').trim() : '';
        if (!email) {
          if (input) { input.focus(); }
          StoreUI.toast('Please enter your email', 'error');
          return;
        }
        this.email = email;
        this.code = '';
        this.error = '';
        this.open = true;
        this.sendCode();
      },

      close() {
        this.open = false;
        this.error = '';
        this.code = '';
        clearInterval(this._timer);
        this.countdown = 0;
      },

      startCountdown() {
        this.countdown = 60;
        clearInterval(this._timer);
        this._timer = setInterval(() => {
          this.countdown -= 1;
          if (this.countdown <= 0) { clearInterval(this._timer); }
        }, 1000);
      },

      async sendCode() {
        if (this.sending) { return; }
        this.error = '';
        this.sending = true;
        try {
          var res = await StoreAuth.sendCode(this.email);
          this.startCountdown();
          if (res && res.dev_code) {
            this.code = res.dev_code;
            StoreUI.toast('Dev mode code: ' + res.dev_code, 'info');
          } else {
            StoreUI.toast('Verification code sent', 'success');
          }
        } catch (e) {
          this.error = e.message;
        } finally {
          this.sending = false;
        }
      },

      async verify() {
        this.error = '';
        if (this.code.length !== 6) { this.error = 'Enter the 6-digit code'; return; }
        this.verifying = true;
        try {
          // 内含游客购物车合并 + 登录态事件通知
          await StoreAuth.verifyCode(this.email, this.code);
          var email = this.email;
          try {
            await StoreAPI.post('/api/site/subscribe', { email: email });
          } catch (err) {
            if (window.console) { console.warn('newsletter subscribe failed', err); }
          }
          this.close();
          StoreUI.toast('Signed in. Welcome, ' + email, 'success');
        } catch (e) {
          this.error = e.message;
        } finally {
          this.verifying = false;
        }
      }
    };
  };

  /* ---------------- 结算 ---------------- */
  window.checkoutAuth = function () {
    return {
      isLoggedIn: false,
      email: '',
      code: '',
      authStep: 1,
      authError: '',
      sending: false,
      verifying: false,
      countdown: 0,
      _timer: null,

      addresses: [],
      loadingAddresses: true,
      selectedAddressId: 0,
      showAddForm: false,
      newAddress: { name: '', phone: '', address_detail: '', is_default: false },
      addressError: '',
      savingAddress: false,

      submitting: false,
      payChannel: 'paypal',
      channels: [],
      toast: { visible: false, message: '', type: 'info' },
      _toastTimer: null,

      async init() {
        this.isLoggedIn = StoreAuth.isLoggedIn();
        if (this.isLoggedIn) {
          await Promise.all([this.fetchAddresses(), this.fetchChannels()]);
        } else {
          this.loadingAddresses = false;
        }
        // 未登录也挂载：游客车条目与金额展示在订单摘要中
        CartPage.mount(this);
      },

      async fetchChannels() {
        try {
          var list = await StoreOrders.channels();
          this.channels = (list || []).map(function (c) { return { code: c.code, name: c.name }; });
          if (this.channels.length) { this.payChannel = this.channels[0].code; }
        } catch (e) { /* 渠道接口不可用时保留下单，支付页会提示 */ }
      },

      async fetchAddresses() {
        this.loadingAddresses = true;
        try {
          var list = await StoreAddress.list();
          this.addresses = (list || []).map(function (a) {
            return {
              id: a.id,
              name: a.name,
              phone: a.phone,
              street: a.address_detail,
              is_default: !!Number(a.is_default)
            };
          });
          var def = this.addresses.find(function (a) { return a.is_default; });
          if (def) { this.selectedAddressId = def.id; }
          else if (this.addresses.length) { this.selectedAddressId = this.addresses[0].id; }
          if (!this.addresses.length) { this.showAddForm = true; }
        } catch (e) {
          this.authError = e.message;
        } finally {
          this.loadingAddresses = false;
        }
      },

      formatCity(addr) { return addr.city || ''; },

      selectedAddress() {
        var id = this.selectedAddressId;
        return this.addresses.find(function (a) { return String(a.id) === String(id); }) || null;
      },

      formatSelectedAddress() {
        var a = this.selectedAddress();
        if (!a) { return ''; }
        return [a.name, a.street, a.phone].filter(Boolean).join(', ');
      },

      async saveNewAddress() {
        this.addressError = '';
        var f = this.newAddress;
        if (!f.name || !f.street) { this.addressError = 'Name and address are required'; return; }
        this.savingAddress = true;
        try {
          await StoreAddress.add({
            name: f.name,
            phone: f.phone || '',
            address_detail: f.street,
            is_default: f.is_default ? 1 : 0
          });
          this.showAddForm = false;
          this.newAddress = { name: '', phone: '', address_detail: '', is_default: false };
          await this.fetchAddresses();
          StoreUI.toast('Address saved', 'success');
        } catch (e) {
          this.addressError = e.message;
        } finally {
          this.savingAddress = false;
        }
      },

      async sendCode() {
        this.authError = '';
        this.sending = true;
        try {
          var res = await StoreAuth.sendCode(this.email);
          this.authStep = 2;
          this.startCountdown();
          if (res && res.dev_code) {
            this.code = res.dev_code;
            StoreUI.toast('Dev mode code: ' + res.dev_code, 'info');
          }
        } catch (e) {
          this.authError = e.message;
        } finally {
          this.sending = false;
        }
      },

      startCountdown() {
        this.countdown = 60;
        clearInterval(this._timer);
        this._timer = setInterval(() => {
          this.countdown -= 1;
          if (this.countdown <= 0) { clearInterval(this._timer); }
        }, 1000);
      },

      async verifyCode() {
        this.authError = '';
        this.verifying = true;
        try {
          // verifyCode 内部会合并游客车，成功后服务端购物车即包含本地条目
          await StoreAuth.verifyCode(this.email, this.code);
          this.isLoggedIn = true;
          await Promise.all([this.fetchAddresses(), this.fetchChannels()]);
          CartPage.mount(this);
        } catch (e) {
          this.authError = e.message;
        } finally {
          this.verifying = false;
        }
      },

      async submitOrder() {
        var items = CartPage.selectedItems();
        if (!items.length) { StoreUI.toast('Your basket is empty', 'error'); return; }
        if (!this.selectedAddressId) { StoreUI.toast('Please choose a delivery address', 'error'); return; }
        this.submitting = true;
        try {
          var order = await StoreOrders.checkout({
            items: items,
            address_id: this.selectedAddressId,
            remark: '',
            pay_channel: this.payChannel
          });
          var pay = await StoreOrders.pay(order.order_pay_id, this.payChannel);
          if (pay && pay.type === 'redirect' && pay.url) {
            window.location.href = pay.url;
            return;
          }
          if (pay && pay.h5_url) { window.location.href = pay.h5_url; return; }
          window.location.href = '/order-success?pay_id=' + encodeURIComponent(order.order_pay_id);
        } catch (e) {
          StoreUI.toast(e.message, 'error');
        } finally {
          this.submitting = false;
        }
      },

      showToast(message, type) {
        this.toast = { visible: true, message: message, type: type || 'info' };
        clearTimeout(this._toastTimer);
        this._toastTimer = setTimeout(() => { this.toast.visible = false; }, 3000);
      },
      hideToast() { this.toast.visible = false; }
    };
  };

  /* ---------------- 心愿单 ---------------- */
  window.wishlistApp = function () {
    return {
      items: [],
      loading: false,
      error: '',
      init() {
        this.items = StoreWishlist.items().map(function (i) {
          return { product: { id: i.id, name: i.name, amount: i.price, image: i.image, url: i.url } };
        });
      },
      formatPrice(v) { return v || ''; },
      removeWishlist(id) {
        StoreWishlist.remove(id);
        this.items = this.items.filter(function (i) { return String(i.product.id) !== String(id); });
      },
      addToCart(id) {
        StoreUI.toast('Choose options on the product page', 'info');
        window.location.href = '/products/' + id;
      }
    };
  };

  /* ---------------- 退出登录 ---------------- */
  window.logoutPage = function () {
    return {
      countdown: 3,
      init() {
        StoreAuth.logout().then(() => {
          var timer = setInterval(() => {
            this.countdown -= 1;
            if (this.countdown <= 0) {
              clearInterval(timer);
              window.location.href = '/';
            }
          }, 1000);
        });
      }
    };
  };
})();