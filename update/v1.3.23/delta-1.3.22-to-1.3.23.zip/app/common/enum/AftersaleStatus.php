<?php
declare (strict_types = 1);

namespace app\common\enum;

class AftersaleStatus
{
    public const PENDING_REVIEW = 0;
    public const APPROVED = 1;
    public const REJECTED = 2;
    public const PENDING_RETURN = 3;
    public const COMPLETED = 4;

    public static function label(int $status): string
    {
        return [
            self::PENDING_REVIEW => '待审核',
            self::APPROVED => '审核通过',
            self::REJECTED => '已拒绝',
            self::PENDING_RETURN => '待退货',
            self::COMPLETED => '已完成',
        ][$status] ?? '未知';
    }

    /**
     * 前台展示用文案，跟随当前请求语种（后台继续使用 label() 的中文）
     */
    public static function labelI18n(int $status): string
    {
        $key = 'aftersale.status.' . $status;
        $label = site_lang($key);

        return $label === $key ? site_lang('common.unknown') : $label;
    }
}
