<?php
declare (strict_types = 1);

namespace app\common\enum;

class OrderStatus
{
    public const PENDING_PAY = 0;
    public const PENDING_SHIP = 1;
    public const SHIPPING = 2;
    public const DELIVERED = 3;
    public const COMPLETED = 4;
    public const SETTLEABLE = 5;
    public const SETTLED = 6;
    public const CANCELLED = -1;
    public const REFUNDED = -2;

    public static function label(int $status): string
    {
        return [
            self::PENDING_PAY => '待支付',
            self::PENDING_SHIP => '待发货',
            self::SHIPPING => '配送中',
            self::DELIVERED => '已送达',
            self::COMPLETED => '已完成',
            self::SETTLEABLE => '可结算',
            self::SETTLED => '已结算',
            self::CANCELLED => '已取消',
            self::REFUNDED => '已退款',
        ][$status] ?? '未知';
    }

    /**
     * 前台展示用文案，跟随当前请求语种（后台继续使用 label() 的中文）
     */
    public static function labelI18n(int $status): string
    {
        $key = 'order.status.' . $status;
        $label = site_lang($key);

        return $label === $key ? site_lang('common.unknown') : $label;
    }
}
