<?php
declare(strict_types=1);

namespace app\api\controller;

use app\BaseController;
use app\common\enum\AftersaleStatus;
use app\common\exception\BizException;
use app\common\model\Aftersale as AftersaleModel;
use app\common\model\RefundLog;
use app\common\service\AftersaleService;
use app\common\support\AppContext;

class Aftersale extends BaseController
{
    public function apply()
    {
        try {
            $userId = (int)AppContext::getUserId();
            $orderId = (int)$this->request->post('order_id', 0);
            $type = (int)$this->request->post('type', 0);
            $reason = (string)$this->request->post('reason', '');

            if (!$orderId || !in_array($type, [1, 2], true) || $reason === '') {
                return $this->error(40001, '参数错误');
            }

            $as = (new AftersaleService())->apply($orderId, $userId, $type, $reason);
            return $this->success([
                'id'           => $as->id,
                'aftersale_no' => $as->aftersale_no,
                'status'       => $as->status,
                'status_label' => AftersaleStatus::labelI18n((int)$as->status),
            ]);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    public function list()
    {
        $userId = (int)AppContext::getUserId();
        $page = (int)$this->request->get('page', 1);
        $size = min(max((int)$this->request->get('size', 15), 1), 50);

        $pager = AftersaleModel::with(['order.items'])
            ->where('user_id', $userId)
            ->order('id', 'desc')
            ->paginate(['list_rows' => $size, 'page' => $page]);

        // 退款进度：同一售后最多一条退款记录（uk_refund_target），批量取回避免逐行查库
        $asItems = $pager->items();
        $refunds = [];
        $aftersaleIds = array_map(static fn($as): int => (int) $as->id, $asItems);
        if ($aftersaleIds) {
            foreach (RefundLog::whereIn('aftersale_id', $aftersaleIds)->select() as $refund) {
                $refunds[(int) $refund->aftersale_id] = $refund;
            }
        }

        $list = [];
        foreach ($asItems as $as) {
            $refund = $refunds[(int) $as->id] ?? null;
            $refundStatus = $refund ? (string) $refund->status : '';
            $productTitle = '';
            $productImage = '';
            $firstItem = $as->order?->items?->first();
            if ($firstItem) {
                $snap = $firstItem->sku_snapshot_json;
                if (is_string($snap)) {
                    $snap = json_decode($snap, true) ?: [];
                }
                $productTitle = $snap['title'] ?? '';
                $productImage = $snap['main_image'] ?? '';
            }
            $list[] = [
                'id'            => $as->id,
                'aftersale_no'  => $as->aftersale_no,
                'order_id'       => $as->order_id,
                'type'          => $as->type,
                'type_label'    => (int)$as->type === 1 ? site_lang('aftersale.type.refund_only') : site_lang('aftersale.type.return_refund'),
                'status'        => $as->status,
                'status_label'  => AftersaleStatus::labelI18n((int)$as->status),
                'refund_amount' => (string)$as->refund_amount,
                'apply_at'      => $as->apply_at ? (string)$as->apply_at : '',
                'product_title' => (string)$productTitle,
                'product_image' => (string)$productImage,
                'refund_status' => $refundStatus,
                'refund_status_label' => $refundStatus !== '' ? site_lang('refund.status.' . $refundStatus) : '',
            ];
        }

        return $this->success([
            'list'    => $list,
            'total'   => $pager->total(),
            'page'    => $pager->currentPage(),
            'size'    => $pager->listRows(),
            'hasMore' => $pager->hasMore(),
        ]);
    }

    public function detail()
    {
        $userId = (int)AppContext::getUserId();
        $id = (int)$this->request->get('id', 0);
        if (!$id) {
            return $this->error(40001, '参数错误');
        }

        $as = AftersaleModel::with(['order.items'])
            ->where('id', $id)
            ->where('user_id', $userId)
            ->find();
        if (!$as) {
            return $this->error(40004, '售后单不存在');
        }

        // 退款进度：同一售后最多一条退款记录；未发起退款时为空字符串
        $refund = RefundLog::where('aftersale_id', $id)->find();
        $refundStatus = $refund ? (string) $refund->status : '';

        $items = [];
        if ($as->order) {
            foreach ($as->order->items as $item) {
                $snap = $item->sku_snapshot_json;
                if (is_string($snap)) {
                    $snap = json_decode($snap, true) ?: [];
                }
                $items[] = [
                    'sku_id'        => $item->sku_id,
                    'product_title' => $snap['title'] ?? '',
                    'spec_name'     => $snap['spec_name'] ?? '',
                    'unit_price'    => (string)$item->unit_price,
                    'quantity'      => $item->quantity,
                    'total_price'   => (string)$item->total_price,
                    'main_image'    => $snap['main_image'] ?? '',
                ];
            }
        }

        return $this->success([
            'id'            => $as->id,
            'aftersale_no'  => $as->aftersale_no,
            'order_id'       => $as->order_id,
            'type'          => $as->type,
            'type_label'    => (int)$as->type === 1 ? site_lang('aftersale.type.refund_only') : site_lang('aftersale.type.return_refund'),
            'reason'        => $as->reason,
            'status'        => $as->status,
            'status_label'  => AftersaleStatus::labelI18n((int)$as->status),
            'refund_amount' => (string)$as->refund_amount,
            'apply_at'      => $as->apply_at ? (string)$as->apply_at : '',
            'approve_at'    => $as->approve_at ? (string)$as->approve_at : '',
            'complete_at'   => $as->complete_at ? (string)$as->complete_at : '',
            'refund_status' => $refundStatus,
            'refund_status_label' => $refundStatus !== '' ? site_lang('refund.status.' . $refundStatus) : '',
            'items'         => $items,
            'order'         => $as->order ? [
                'id'           => $as->order->id,
                'order_no'     => $as->order->order_no,
                'total_amount' => (string)$as->order->total_amount,
            ] : null,
        ]);
    }
}
