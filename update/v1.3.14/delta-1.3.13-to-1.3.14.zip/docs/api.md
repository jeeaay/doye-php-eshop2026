# C 端 API 接口文档（小程序 / 独立站）

> Base URL: `/api`
> 统一响应格式: `{ "code": 0, "message": "ok", "data": {...} }`
> 鉴权方式: `Authorization: Bearer <token>`
> 金额单位: 元 (字符串，保留两位小数，如 `"29.99"`)
> 时间格式: `Y-m-d H:i:s`（如 `"2026-10-13 10:00:00"`）
> 分页结构: `{ list, total, page, size, hasMore }`
> 图片路径: 站内相对路径（如 `/uploads/products/images/202610/xxx.png`），由前端补域名

---

## 目录

| 模块 | 鉴权 | 端点数 | 说明 |
|------|------|--------|------|
| [认证](#1-认证) | 免登录 | 1 | 微信小程序登录 |
| [首页运营](#2-首页运营) | 免登录 | 1 | Banner / 分类入口 / 公告 / 专题 / 推荐商品 / 精选评论 |
| [商品](#3-商品) | 免登录 | 2 | 列表 / 详情（含规格与视频） |
| [分类](#4-分类) | 免登录 | 1 | 两级分类树 |
| [购物车](#5-购物车) | 部分需登录 | 6 | 增查改删、游客车预览与合并 |
| [优惠券](#6-优惠券) | 需登录 | 5 | 可领列表 / 领取 / 我的券 / 可用券 / 试算 |
| [营销](#7-营销) | 需登录 | 1 | 订单已到账返利 |
| [订单](#8-订单) | 需登录 | 7 | 结算 / 支付 / 列表 / 详情 / 物流 / 确认 / 取消 |
| [支付](#9-支付) | 部分需登录 | 3 | 通道列表 / 支付状态 / 异步回调 |
| [售后](#10-售后) | 需登录 | 3 | 申请 / 列表 / 详情 |
| [商品评论](#11-商品评论) | 部分需登录 | 7 | 列表 / 统计 / 资格 / 我的评价 / 提交 / 上传 / 投票 |
| [分享归因](#12-分享归因) | 需登录 | 1 | 上报分享来源 |
| [用户中心](#13-用户中心) | 需登录 | 8 | 资料 / 头像 / 手机号 / 地址 CRUD |
| [独立站登录](#14-独立站浏览器登录) | 免登录 | 6 | 邮箱验证码登录、联系表单、订阅 |

---

## 错误码

| code | HTTP | 含义 |
|------|------|------|
| 0 | 200 | 成功 |
| 40001 | 200 | 参数错误 / 业务异常（含库存不足、优惠不可用等） |
| 40004 | 200 | 资源不存在 |
| 40010 | 200 | 订单状态不允许操作 |
| 401 | 401 | 未登录 / token 失效 |
| 429 | 429 | 请求过于频繁（默认单 IP 120 次/分钟） |

- 业务失败统一返回 HTTP 200 + 非 0 `code`；只有鉴权失败与限流使用真实 HTTP 状态码。
- 小程序端收到 `401` 时应重新 `wx.login` 静默登录后重试（详见 [登录流程](#15-前端对接要点)）。

---

## 1. 认证

### POST `/api/auth/login`

微信小程序登录，用 `wx.login` 获取的 code 换取 token。

**请求**

```json
{
  "code": "wx_login_code_string"
}
```

**响应**

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "token": "a1b2c3d4e5f6...",
    "user": {
      "id": 1,
      "openid": "oxxxxxxxx",
      "nickname": "微信用户",
      "avatar": "/uploads/avatars/202610/xxx.png",
      "phone": null
    }
  }
}
```

**说明**

- 后端调用 `WechatLogin::code2session` 用 code 换取 openid。
- 若 appid/secret 未配置，进入 mock 模式，openid 为 `mock_<code>`。
- 首次登录自动注册，并触发注册礼（营销规则发券，失败不影响登录）。
- token 有效期 30 天（Redis 存储）；剩余不足 7 天时访问自动续期到 30 天。
- token 失效后前端自动 `wx.login` 静默重登录（无需用户授权），并按 openid 恢复已保存的昵称、头像、手机号。

---

## 2. 首页运营

### GET `/api/home/ops`（免登录）

首页全部运营位一次返回。

**响应**

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "banners": [
      {
        "id": 1,
        "image": "/uploads/...",
        "title": "",
        "subtitle": "",
        "link_type": "product",
        "link_target": "1"
      }
    ],
    "categories": [
      {"id": 1, "name": "数码", "icon": "/uploads/..."}
    ],
    "notices": [
      {"id": 1, "title": "", "summary": "", "link_type": "none", "link_target": ""}
    ],
    "topics": [
      {"id": 1, "image": "", "title": "", "description": "", "link_type": "topic", "link_target": "1"}
    ],
    "products": [
      {"id": 1, "title": "旗舰智能手机", "main_image": "/uploads/...", "price_min": "1999.00"}
    ],
    "testimonials": [
      {"id": 12, "content": "Very good quality...", "author": "A***n"}
    ]
  }
}
```

**说明**

- `link_type` 取值：`none` / `page` / `product` / `category` / `topic`，前端按此跳转。
- 公告按上下线时间过滤；分类入口、专题、推荐商品均只返回启用项。
- `testimonials` 为后台置顶且已通过审核的评论（作者名已脱敏），可为空数组。

---

## 3. 商品

### GET `/api/product/list`（免登录）

商品列表（仅 `status=1` 在售商品）。

**Query 参数**

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| page | int | 1 | 页码 |
| size | int | 20 | 每页数量（上限 50） |
| category_id | int | - | 分类筛选（一级分类包含其子分类商品） |
| keyword | string | - | 标题 / 副标题模糊搜索 |
| merchant_id | int | - | 商户筛选 |

**响应**

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "list": [
      {
        "id": 1,
        "title": "旗舰智能手机",
        "main_image": "/uploads/products/images/202610/xxx.png",
        "price_min": "1999.00",
        "price_max": "3999.00",
        "merchant_name": "官方旗舰店"
      }
    ],
    "total": 100,
    "page": 1,
    "size": 20,
    "hasMore": true
  }
}
```

### GET `/api/product/detail`（免登录）

商品详情（含 SKU、规格、视频）。结果缓存 300 秒。

**Query 参数**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| id | int | 是 | 商品 ID |

**响应**

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "id": 1,
    "title": "旗舰智能手机",
    "subtitle": "5G全网通 256GB",
    "main_image": "/uploads/products/images/202610/xxx.png",
    "images": ["/uploads/.../1.png", "/uploads/.../2.png"],
    "video_url": "",
    "video_cover": "",
    "detail_html": "<p>商品详情富文本...</p>",
    "skus": [
      {
        "id": 10,
        "spec_name": "颜色:黑色 256G",
        "price": "2999.00",
        "stock": 999,
        "sku_code": "SKU-BLACK-256",
        "spec_values_json": {"颜色": "黑色", "容量": "256G"}
      }
    ],
    "specs": [
      {"name": "颜色", "values": ["黑色", "白色"], "value_images": {"黑色": "/uploads/.../1.png", "白色": "/uploads/.../2.png"}},
      {"name": "容量", "values": ["128G", "256G"]}
    ],
    "merchant": {"id": 1, "name": "官方旗舰店"}
  }
}
```

**说明**

- 只返回 `status=1`（在售）的商品；不存在或已下架返回 `code=40004`。
- `specs` 由后台 `specs_json` 生成；老商品缺失时按 SKU 的 `spec_values_json` 自动聚合。
- `specs[].value_images` 可选；键为规格值，值为图片 URL；仅用于前台展示联动（未配置该值的规格项不返回此字段）。
- `spec_values_json` 与 `specs` 同名同序，前端按名称匹配唯一 SKU 后取 `id` 与 `stock`。
- `video_url` / `video_cover` 在后台未配置视频时为空字符串。

---

## 4. 分类

### GET `/api/category/tree`（免登录）

分类树（两级），仅保留有在售商品的分类。结果缓存 300 秒。

```json
{
  "code": 0,
  "message": "ok",
  "data": [
    {
      "id": 1,
      "name": "数码",
      "children": [
        {"id": 11, "name": "手机"},
        {"id": 12, "name": "电脑"}
      ]
    }
  ]
}
```

- 父分类自身有商品但子分类无商品时，`children` 为空数组。

---

## 5. 购物车

### POST `/api/cart/add`（需登录）

```json
// Request
{ "sku_id": 10, "quantity": 1 }

// Response
{ "code": 0, "message": "ok", "data": null }
```

- 同一 SKU 重复加车会累加数量。
- 库存不足返回 `code=40001, message="库存不足"`。
- SKU 不存在或下架返回 `code=40001`。

### GET `/api/cart/list`（需登录）

购物车列表（按商户分组）。

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "groups": [
      {
        "merchant": {"id": 1, "name": "官方旗舰店"},
        "items": [
          {
            "id": 100,
            "sku_id": 10,
            "product_title": "旗舰智能手机",
            "spec_name": "颜色:黑色 256G",
            "price": "2999.00",
            "quantity": 2,
            "main_image": "/uploads/...",
            "stock": 999,
            "selected": 1
          }
        ]
      }
    ]
  }
}
```

- tabBar 角标可直接对 `groups[].items[].quantity` 求和。
- 商品/商户被删除时对应字段可能为空，`merchant` 可能为 `null`。

### POST `/api/cart/update`（需登录）

修改数量或选中状态，两个字段可只传一个。

```json
// 修改数量
{ "id": 100, "quantity": 3 }

// 修改选中状态
{ "id": 100, "selected": 0 }
```

- 数量不得超过库存，否则 `code=40001, message="库存不足"`。
- 购物车项不存在或不属于当前用户返回 `code=40001`。

### POST `/api/cart/remove`（需登录）

```json
{ "ids": [100, 101] }
```

- 只会删除属于当前用户的购物车项。

### POST `/api/cart/preview`（免登录）

游客购物车展示数据：服务端取价，前端不做金额推断。

```json
// Request
{ "items": [{"sku_id": 10, "quantity": 2}] }

// Response
{
  "code": 0,
  "message": "ok",
  "data": {
    "items": [
      {
        "sku_id": 10,
        "product_title": "旗舰智能手机",
        "spec_name": "颜色:黑色 256G",
        "price": "2999.00",
        "quantity": 2,
        "main_image": "/uploads/...",
        "stock": 999,
        "available": true
      }
    ],
    "subtotal": "5998.00"
  }
}
```

- 入参最多 100 条，同 SKU 自动合并，`quantity` 收敛到 1..999。
- `available=false` 的项不计入 `subtotal`。

### POST `/api/cart/merge`（需登录）

登录后合并游客购物车（同 SKU 累加）。

```json
// Request
{ "items": [{"sku_id": 10, "quantity": 2}] }

// Response
{
  "code": 0,
  "message": "ok",
  "data": { "merged": [10], "dropped": [20] }
}
```

- `merged`：成功合并的 sku_id；`dropped`：已下架/无库存被丢弃的 sku_id。
- 超出库存时静默截断到库存，不中断合并。

---

## 6. 优惠券

> 以下接口均需 `Authorization: Bearer <token>`

### GET `/api/coupon/list`

当前用户可领取的优惠券（仅前台领取类型；优惠码券与系统自动发放券不在列表内）。

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "list": [
      {
        "id": 1,
        "name": "新人立减 10 元",
        "discount_type": "fixed",
        "discount_value": "10.00",
        "min_amount": "99.00",
        "scope": "all",
        "end_time": "2026-12-31 23:59:59",
        "discount_text": "满 99 减 10",
        "remark": "",
        "claimable": true
      }
    ]
  }
}
```

- `discount_type`：`fixed`（固定金额）/ `percent`（百分比）。
- `scope`：`all`（全场）/ `product`（指定商品）。
- `claimable=false` 表示已达每人领取上限。

### POST `/api/coupon/claim`

```json
// Request
{ "coupon_id": 1 }

// Response
{
  "code": 0,
  "message": "ok",
  "data": { "coupon_user_id": 88, "expire_time": "2026-12-31 23:59:59" }
}
```

- 已发完 / 超过每人上限 / 不在活动时间 / 非领取型券均返回 `code=40001`。

### GET `/api/coupon/my-coupons`

我的优惠券（账户中心）。

**Query 参数**：`status`（`unused` / `used` / `expired`，不传返回全部）

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "list": [
      {
        "coupon_user_id": 88,
        "coupon_id": 1,
        "name": "新人立减 10 元",
        "discount_text": "满 99 减 10",
        "min_amount": "99.00",
        "expire_time": "2026-12-31 23:59:59",
        "status": 0,
        "status_label": "未使用",
        "tab": "unused",
        "auto_apply": 0,
        "tier": 40,
        "tier_label": "优惠券/优惠码",
        "scope": "all",
        "scope_label": "全场通用",
        "use_type": "manual"
      }
    ],
    "counts": {"unused": 1, "used": 0, "expired": 0}
  }
}
```

### POST `/api/coupon/mine`

结算页：当前购物车下可用的已领取券。

```json
// Request
{ "items": [{"sku_id": 10, "quantity": 2}] }

// Response
{
  "code": 0,
  "message": "ok",
  "data": {
    "list": [
      {
        "coupon_user_id": 88,
        "coupon_id": 1,
        "name": "新人立减 10 元",
        "tier": 40,
        "auto_apply": 0,
        "discount_text": "满 99 减 10",
        "discount_value": "10.00",
        "min_amount": "99.00",
        "expire_time": "2026-12-31 23:59:59",
        "usable": true,
        "amount": "10.00",
        "reason": ""
      }
    ],
    "subtotal": "5998.00"
  }
}
```

- `usable=false` 时 `reason` 给出不可用原因（门槛不足、商品不符等）。

### POST `/api/coupon/quote`

折扣试算（已领券 / 优惠码），与结算同一套 `CouponService::quote()` 口径。

```json
// Request
{
  "items": [{"sku_id": 10, "quantity": 2}],
  "coupon_code": "WELCOME10",
  "coupon_user_id": 88
}

// Response
{
  "code": 0,
  "message": "ok",
  "data": {
    "lines": [
      {
        "tier": 40,
        "tier_label": "优惠券/优惠码",
        "source": "code",
        "coupon_id": 1,
        "coupon_user_id": null,
        "name": "新人立减 10 元",
        "discount_text": "满 99 减 10",
        "amount": "10.00"
      }
    ],
    "discount": "10.00",
    "payable": "5988.00",
    "subtotal": "5998.00",
    "coupon_user_id": null
  }
}
```

- `coupon_code` 与 `coupon_user_id` 可只传一个；同时传时以实际命中结果为准。
- 优惠不可用（门槛不足、商品券未命中）返回 `code=40001` 并带具体原因。

---

## 7. 营销

### GET `/api/marketing/benefits`（需登录）

查询某笔订单已到账的返利（仅自己的订单），用于确认收货后的提示模块。

**Query 参数**：`order_id`（int，必填）

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "list": [
      {
        "order_id": 50,
        "rule_id": 3,
        "rule_name": "确认收货返利",
        "reward_amount": "5.00",
        "coupon_user_id": 120,
        "expire_time": "2026-12-31 23:59:59"
      }
    ]
  }
}
```

- 无命中规则或尚未发放时返回空数组。

---

## 8. 订单

> 以下接口均需 `Authorization: Bearer <token>`

### POST `/api/order/checkout`

下单结算：校验库存 → 优惠试算 → 建支付单 + 按商户拆子订单 → 预扣库存 → 投 15 分钟延时取消任务。

**请求**

```json
{
  "items": [
    {"sku_id": 10, "quantity": 1},
    {"sku_id": 20, "quantity": 2}
  ],
  "address_id": 5,
  "remark": "尽快发货",
  "pay_channel": "wechat",
  "coupon_code": "",
  "coupon_user_id": 0
}
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| items | array | 是 | `[{sku_id, quantity}]` |
| address_id | int | 是 | 已保存的收货地址 ID（必须属于当前用户） |
| remark | string | 否 | 订单备注 |
| pay_channel | string | 否 | 预期支付通道，默认 `wechat` |
| coupon_code | string | 否 | 优惠码 |
| coupon_user_id | int | 否 | 已领取券记录 ID |

**响应**

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "order_pay_id": 88,
    "total_amount": "8997.00",
    "discount_amount": "0.00",
    "sub_orders": [
      {
        "id": 50,
        "order_no": "20261013100000123456",
        "merchant_name": "官方旗舰店",
        "total_amount": "2999.00",
        "discount_amount": "0.00",
        "item_count": 1,
        "display": {
          "charge_currency": "CNY",
          "charge_text": "¥2,999.00",
          "currency": "CNY",
          "usd_text": "¥2,999.00",
          "local_text": "",
          "rate": "1",
          "is_reference": false
        }
      }
    ]
  }
}
```

**行为约定**

- 跨商户商品会拆成多个子订单，共享一个 `order_pay_id`，仍只发起一次支付。
- `sub_orders[].id` 必须用于支付成功后跳转订单详情。
- 折扣按各商户商品小计占比分摊，尾差归最后一家，保证子订单折扣之和等于总折扣。
- 库存不足返回 `code=40001, message="库存不足:<规格名>"`。
- 未支付订单 15 分钟后自动取消并释放预扣库存。
- 下单后自动关联分享归因（若存在）。
- 运费：当前版本全场包邮，运费恒为 0，接口不单独返回运费字段。
- 资料门槛：**必须已绑定手机号才允许下单**；未绑定返回 `code=40001, message="请先绑定手机号后再下单"`（小程序用 `/api/user/bind-phone`，独立站用户需先绑定手机号）。

### POST `/api/order/pay`

创建支付。`channel` 可选，默认 `wechat`。

**请求**

```json
{ "order_pay_id": 88, "channel": "wechat" }
```

**响应（wechat）**

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "appId": "wx1234567890abcdef",
    "timeStamp": "1697164800",
    "nonceStr": "abc123",
    "package": "prepay_id=wx20261013100000",
    "signType": "RSA",
    "paySign": "signature_string"
  }
}
```

**响应（alipay / stripe / paypal）**

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "type": "redirect",
    "url": "https://gateway.example.com/...",
    "trade_no": "渠道单号"
  }
}
```

- `channel` 必须是后台已启用且当前站点版本支持的通道：
  - 国内版：`wechat`、`alipay`
  - 国际版：`stripe`、`paypal`
- 微信通道要求用户已有 `openid`（小程序登录后自动具备）。
- 未启用、配置不完整、订单非待支付状态、非本人订单均返回 `code=40001` 及具体原因。
- 支付宝额外返回 `method`；Stripe 额外返回 `session_id`；PayPal 额外返回 `order_id`。

### GET `/api/order/list`

订单列表（分页 / 状态筛选）。

**Query 参数**

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| page | int | 1 | 页码 |
| size | int | 15 | 每页数量（上限 50） |
| status | string | all | 状态筛选 |

**status 取值**

| 值 | 说明 | 对应状态码 |
|------|------|------|
| all | 全部 | 无筛选 |
| unpaid | 待支付 | 0 |
| unshipped | 待发货 | 1 |
| unreceived | 待收货 | 2, 3 |
| done | 已完成 | 4 |

**响应**

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "list": [
      {
        "id": 50,
        "pay_id": 88,
        "order_no": "20261013100000123456",
        "merchant_name": "官方旗舰店",
        "status": 1,
        "status_label": "待发货",
        "total_amount": "2999.00",
        "first_image": "/uploads/...",
        "created_at": "2026-10-13 10:00:00",
        "display": {
          "charge_currency": "CNY",
          "charge_text": "¥2,999.00",
          "currency": "CNY",
          "usd_text": "¥2,999.00",
          "local_text": "",
          "rate": "1",
          "is_reference": false
        }
      }
    ],
    "total": 5,
    "page": 1,
    "size": 15,
    "hasMore": false
  }
}
```

- `pay_id` 用于列表页直接发起支付 / 取消。
- `first_image` 取第一件商品下单快照图。

### GET `/api/order/detail`

订单详情（含商品、地址、状态时间线、优惠明细、售后）。

**Query 参数**：`id`（int，必填）

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "id": 50,
    "pay_id": 88,
    "order_no": "20261013100000123456",
    "status": 1,
    "status_label": "待发货",
    "total_amount": "2999.00",
    "remark": "尽快发货",
    "merchant": {"id": 1, "name": "官方旗舰店"},
    "display": {
      "charge_currency": "CNY",
      "charge_text": "¥2,999.00",
      "currency": "CNY",
      "usd_text": "¥2,999.00",
      "local_text": "",
      "rate": "1",
      "is_reference": false
    },
    "discount_lines": [
      {
        "tier": 40,
        "tier_label": "优惠券/优惠码",
        "source": "code",
        "coupon_id": 1,
        "coupon_user_id": null,
        "name": "新人立减 10 元",
        "discount_text": "满 99 减 10",
        "amount": "10.00"
      }
    ],
    "items": [
      {
        "sku_id": 10,
        "product_id": 1,
        "product_title": "旗舰智能手机",
        "spec_name": "颜色:黑色 256G",
        "unit_price": "2999.00",
        "quantity": 1,
        "total_price": "2999.00",
        "main_image": "/uploads/..."
      }
    ],
    "address": {
      "name": "张三",
      "phone": "13800138000",
      "address_detail": "广东省深圳市南山区科技园"
    },
    "timeline": [
      {"label": "下单成功", "time": "2026-10-13 10:00:00"},
      {"label": "已支付", "time": "2026-10-13 10:01:00"}
    ],
    "aftersale": {
      "id": 20,
      "status": 0,
      "status_label": "待审核"
    }
  }
}
```

- `aftersale` 无售后时为 `null`。
- `items[].product_id` 用于跳转商品详情，以及调用 `GET /api/review/eligible?product_id=` 判断是否展示「写评价」入口。
- `discount_lines` 为下单时的优惠快照，只读不重算；老订单可能为空数组。
- 商品信息取订单快照，商品下架或删除后仍可展示。

### GET `/api/order/logistics`

物流详情（旧文档未写，小程序在用）。

**Query 参数**：`id`（订单 ID，必填）

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "order_id": 50,
    "order_no": "20261013100000123456",
    "status": 2,
    "status_label": "配送中",
    "shipping_no": "SF1234567890",
    "shipping_company": "顺丰速运",
    "delivery_method": "express",
    "delivery_method_label": "快递物流",
    "timeline": [
      {"label": "下单成功", "time": "2026-10-13 10:00:00"},
      {"label": "已支付", "time": "2026-10-13 10:01:00"},
      {"label": "已发货", "time": "2026-10-13 12:00:00"}
    ]
  }
}
```

- `delivery_method`：`express`（快递物流）/ `self`（商家自行配送），未设置时为空字符串。

### POST `/api/order/confirm`

确认收货（已送达 → 已完成）。

```json
{ "order_id": 50 }
```

- 状态不允许时返回 `code=40010`。

### POST `/api/order/cancel`

取消未支付订单并释放库存。

```json
{ "order_pay_id": 88 }
```

- 已支付或已退款订单无法取消，返回 `code=40010`。
- 取消的是整个支付单下的全部子订单。

---

## 9. 支付

### GET `/api/payment/channels`（免登录）

返回后台已启用的支付通道，不含任何密钥。

```json
{
  "code": 0,
  "message": "ok",
  "data": [
    {
      "code": "wechat",
      "name": "微信支付",
      "description": "微信小程序 JSAPI 支付（APIv3），当前小程序使用此通道。",
      "test_mode": 1
    }
  ]
}
```

- 仅返回当前站点版本支持的通道（国内版 wechat/alipay，国际版 stripe/paypal）。

### GET `/api/payment/status`（需登录）

**Query 参数**：`order_pay_id`

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "order_pay_id": 88,
    "pay_status": 1,
    "status_label": "已支付",
    "channel": "wechat",
    "is_test": 0,
    "total_amount": "2999.00",
    "paid_at": "2026-10-22 16:00:00"
  }
}
```

- `pay_status`：`0 待支付`、`1 已支付`、`2 已退款`。

### POST `/api/payment/notify/:channel`（免登录）

统一异步回调入口，`channel` 可取 `wechat` / `alipay` / `stripe` / `paypal`；省略时兼容旧版 `wechat`（`POST /api/payment/notify`）。

| 通道 | 验签方式 | 成功响应 |
|------|----------|----------|
| 微信支付 | APIv3 平台证书 + AES-256-GCM | `{"code":"SUCCESS","message":"成功"}` |
| 支付宝 | RSA2 支付宝公钥 | `success` |
| Stripe | `Stripe-Signature` HMAC-SHA256 | JSON 2xx |
| PayPal | `verify-webhook-signature` | JSON 2xx |

- 请求体必须是网关原始报文，不能经过框架表单解析。
- 后端验签 + 金额校验 + 分布式锁幂等处理；重复回调不会重复入账。
- 验签失败或金额不一致返回 HTTP 400，触发网关重试。
- 回调会分别尝试测试、正式两套凭据验签。

---

## 10. 售后

> 以下接口均需 `Authorization: Bearer <token>`

### POST `/api/aftersale/apply`

```json
// Request
{
  "order_id": 50,
  "type": 1,
  "reason": "不想要了"
}

// type: 1=仅退款, 2=退货退款

// Response
{
  "code": 0,
  "message": "ok",
  "data": {
    "id": 20,
    "aftersale_no": "20261013100001234",
    "status": 0,
    "status_label": "待审核"
  }
}
```

### GET `/api/aftersale/list`

**Query 参数**：`page`（默认 1）、`size`（默认 15，上限 50）

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "list": [
      {
        "id": 20,
        "aftersale_no": "20261013100001234",
        "order_id": 50,
        "type": 1,
        "type_label": "仅退款",
        "status": 0,
        "status_label": "待审核",
        "refund_amount": "2999.00",
        "apply_at": "2026-10-13 10:00:00",
        "product_title": "旗舰智能手机",
        "product_image": "/uploads/...",
        "refund_status": "",
        "refund_status_label": ""
      }
    ],
    "total": 1,
    "page": 1,
    "size": 15,
    "hasMore": false
  }
}
```

- `product_title` / `product_image` 取该订单第一件商品的快照，用于列表卡片。

### GET `/api/aftersale/detail`

**Query 参数**：`id`（int，必填）

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "id": 20,
    "aftersale_no": "20261013100001234",
    "order_id": 50,
    "type": 1,
    "type_label": "仅退款",
    "reason": "不想要了",
    "status": 0,
    "status_label": "待审核",
    "refund_amount": "2999.00",
    "apply_at": "2026-10-13 10:00:00",
    "approve_at": "",
    "complete_at": "",
    "refund_status": "",
    "refund_status_label": "",
    "items": [
      {
        "sku_id": 10,
        "product_title": "旗舰智能手机",
        "spec_name": "颜色:黑色 256G",
        "unit_price": "2999.00",
        "quantity": 1,
        "total_price": "2999.00",
        "main_image": "/uploads/..."
      }
    ],
    "order": {
      "id": 50,
      "order_no": "20261013100000123456",
      "total_amount": "2999.00"
    }
  }
}
```

- 售后状态：`0 待审核`、`1 审核通过`、`2 已拒绝`、`3 待退货`、`4 已完成`。
- 退款进度：`refund_status` 取值 `pending`（待发起）/ `requesting`（结果待确认）/ `success`（退款成功）/ `failed`（退款失败），同时返回 `refund_status_label`；尚未产生退款记录时两个字段均为空字符串。
- `requesting` 表示通道结果未知（可能已出款），前端只做展示提示，不要触发重试或自动重放。
- 自动退款当前仅支持微信通道；其他通道的退款在渠道后台人工处理，不影响本接口的售后状态展示。

---

## 11. 商品评论

### GET `/api/review/list`（免登录，可带 Bearer）

评论列表。可见集合随登录态变化：

| 调用方 | 返回的评论 |
|---|---|
| 未登录 / token 无效 | 仅 `status=1`（已通过审核） |
| 登录用户 A | `status=1` **或** 「`status=0` 且作者是 A」的待审核评论 |

- 已拒绝 / 已隐藏的评论在任何情况下都不返回。
- 下方 `rating` / `media` / `keyword` 只在上面的可见集合内叠加（`media=1` 时作者自己的待审核图片/视频同样命中），
  `total` / `hasMore` 也按可见集合统计。
- 带有效 Bearer token 时额外返回 `my_vote`。
- 注意：统计接口 `GET /api/review/summary` **不**随登录态变化（只算已通过），
  因此作者可能看到 1 条评论但统计条数为 0，属预期。

**Query 参数**

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| product_id | int | - | 必填 |
| rating | int | 0 | 1-5 星筛选，0 不限 |
| media | int | 0 | 1 只看「有图片 **或** 有视频」的评论 |
| keyword | string | - | 标题 / 内容模糊搜索 |
| page | int | 1 | 页码 |
| size | int | 5 | 每页条数（1-20） |

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "list": [
      {
        "id": 12,
        "rating": 5,
        "title": "很好用",
        "content": "做工精致，物流很快……",
        "images": ["/uploads/reviews/images/202610/xxx.png"],
        "image_thumbs": ["/uploads/thumbs/480/reviews/images/202610/xxx.png"],
        "videos": ["/uploads/reviews/videos/202610/0123456789abcdef0123456789abcdef.mp4"],
        "author": "Jo***ny",
        "avatar": "",
        "is_anonymous": 0,
        "is_verified": 1,
        "create_time": "2026-10-13 10:00:00",
        "admin_reply": "",
        "replied_at": "",
        "helpful_yes": 0,
        "helpful_no": 0,
        "my_vote": 0
      }
    ],
    "total": 1,
    "page": 1,
    "size": 5,
    "hasMore": false
  }
}
```

- `my_vote`：`0 未投票`、`1 有用`、`2 无用`；未登录恒为 0。
- `author`：作者展示名，规则见下；原始昵称/邮箱永不返回（后台管理接口不受影响）。
  - 有昵称用昵称掩码，无昵称用邮箱整体掩码（不保留域名）；
  - 长度 ≥5 → 首 2 + `***` + 末 2（`Johnny → Jo***ny`、`dave@example.com → da***om`）；
  - 长度 3-4 → 首 1 + `***` + 末 1（`Dave → D***e`）；长度 ≤2 → `***`（`Jo → ***`）；
  - 匿名评论固定 `Anonymous`；无昵称且无邮箱回退 `Customer`。
- `images` / `videos`：本站 `/uploads/reviews/images|videos/YYYYMM/<32hex>.<ext>` 地址数组；
  `videos` 只含通过校验的本站地址，最多 2 个，历史评论（无视频）返回 `[]`（不会省略该字段）。
- `image_thumbs`：与 `images` **等长**的 480px 展示缩略图地址数组（`/uploads/thumbs/480/reviews/...`），
  前台列表用它做 `src`、用 `images[i]` 做 Lightbox / 新窗口原图。契约保证：
  - 新上传图片在上传时已预生成 160/480/960 缩略图，直接命中缓存；
  - 历史图片（缩略图上线前上传）首次请求时同步生成一次并落盘，之后走静态缓存，不做批量回填；
  - GD 缺失、源图宽度本来就不超过 480 或生成失败时，该项回退为与 `images[i]` 相同的原图地址，
    前端可无条件使用该字段。
- `author` 的掩码规则见上方字段说明；前台所有评论入口（商品页列表、首页精选）共用
  `ReviewService::maskVisibleName()`，原始昵称 / 邮箱永不返回。

### GET `/api/review/summary`（免登录）

评论统计，**只统计 `status=1`（已通过）且未删除的评论**，与登录态无关。
商品详情页的评分、条数与星级分布也读这里，因此作者自己的待审核评论不计入统计。

**Query 参数**：`product_id`

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "count": 8,
    "avg": 4.6,
    "distribution": {"5": 5, "4": 2, "3": 1, "2": 0, "1": 0}
  }
}
```

### GET `/api/review/eligible`（需登录）

当前用户可评价的订单商品（已送达及以上状态、尚未评论）。

**Query 参数**：`product_id`

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "list": [
      {
        "order_item_id": 300,
        "order_no": "20261013100000123456",
        "sku_name": "颜色:黑色 256G",
        "received_at": "2026-10-13 10:00:00"
      }
    ]
  }
}
```

- `product_id` 取自 `GET /api/order/detail` 的 `items[].product_id`；前端据此判断是否展示「写评价」入口。

### GET `/api/review/mine`（需登录）

我的评价（账户中心），按提交时间倒序分页。**只返回 `status in (0,1)`（待审核 + 已通过）**，
被拒绝（2）/ 已隐藏（3）的评论不出现在任何前台入口。

**Query 参数**：`page`（默认 1）、`size`（默认 10，上限 50）

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "list": [
      {
        "id": 12,
        "product_id": 1,
        "product_title": "旗舰智能手机",
        "product_image": "/uploads/...",
        "order_id": 50,
        "order_no": "20261013100000123456",
        "order_item_id": 300,
        "rating": 5,
        "title": "很好用",
        "content": "做工精致，物流很快，推荐购买。",
        "images": ["/uploads/reviews/images/202610/xxx.png"],
        "image_thumbs": ["/uploads/thumbs/480/reviews/images/202610/xxx.png"],
        "videos": [],
        "is_anonymous": 0,
        "is_verified": 1,
        "status": 0,
        "status_label": "待审核",
        "admin_reply": "",
        "replied_at": "",
        "helpful_yes": 0,
        "helpful_no": 0,
        "create_time": "2026-10-13 10:00:00"
      }
    ],
    "total": 1,
    "page": 1,
    "size": 10,
    "hasMore": false
  }
}
```

- 状态：`0 待审核`、`1 已通过`、`2 已拒绝`、`3 已隐藏`；本接口只返回 0 / 1。
  `status` / `status_label` 仅为兼容其它消费者（如小程序）保留，Web「我的评价」页面不展示审核状态。
- `videos` 与 `images` 对称：本站视频地址数组，最多 2 个；未上传视频时返回 `[]`。
- `image_thumbs`：与 `images` 等长的 480px 缩略图数组，口径同 `GET /api/review/list`
  （历史图片首次请求按需生成、失败回退原图）。
- 商品已下架或删除时，仍返回评论时的商品标题与主图。

### POST `/api/review/create`（需登录）

提交评论，默认进入待审核。

```json
// Request
{
  "order_item_id": 300,
  "rating": 5,
  "title": "很好用",
  "content": "做工精致，物流很快，推荐购买。",
  "images": ["/uploads/reviews/images/202610/xxx.png"],
  "videos": ["/uploads/reviews/videos/202610/0123456789abcdef0123456789abcdef.mp4"],
  "is_anonymous": 0
}

// Response
{
  "code": 0,
  "message": "ok",
  "data": {
    "id": 12,
    "status": 0,
    "status_label": "待审核",
    "auto_approved": false
  }
}
```

- `content` 最少 10 字、最多 2000 字；`title` 最多 120 字；图片最多 6 张。
- `videos`：先调 `POST /api/review/upload-video` 拿到 URL 再提交，最多 2 个（`ReviewService::MAX_VIDEOS`）；
  只接受本站 `/uploads/reviews/videos/YYYYMM/<32hex>.mp4|webm`，外链、其他路径、其他扩展名一律 `code=40001` 且不落库。
- 每个订单商品仅可评价一次，重复提交返回 `code=40001`。
- 仅已送达 / 已完成订单的已购商品可评价。

### POST `/api/review/upload-video`（需登录）

评论视频上传（multipart，字段名 `file`）。与图片上传同构，走 `MediaUploadService` 的 video 分支
（容器签名校验 `ftyp` / EBML，伪扩展名文件返回 `code=40001`）。

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "url": "/uploads/reviews/videos/202610/0123456789abcdef0123456789abcdef.mp4",
    "size": 5242880,
    "mime": "video/mp4"
  }
}
```

- 规格见 `config/media.php` 的 `reviews.video`：**单个 ≤ 50MB，仅 `mp4` / `webm`**（`video/mp4`、`video/webm`）。
- 视频不做转码 / 压缩 / 封面帧（本期 Out of Scope），iOS Safari 不支持 WebM，端上提示推荐 MP4。
- **部署要求**：PHP 默认 `upload_max_filesize=2M` / `post_max_size=8M`，50MB 视频必然被拒，
  需在 `php.ini`（或 FPM pool）设置 `upload_max_filesize` 与 `post_max_size` ≥ `64M`，
  nginx 另需 `client_max_body_size 64m;`（否则 413）。

### POST `/api/review/upload`（需登录）

评论图片上传（multipart，字段名 `file`）。

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "url": "/uploads/reviews/images/202610/xxx.png",
    "size": 102400,
    "mime": "image/png",
    "width": 1600,
    "height": 1200
  }
}
```

- `size` / `width` / `height` 为**压缩后的落盘结果**（跳过压缩时即原图值），与磁盘上的文件一致。
- 服务端压缩（`config/media.php` 的 `reviews.image.compress`）：最长边 1600px 等比缩放、不放大，
  JPEG 先按 EXIF Orientation 纠正方向，按原格式与扩展名写回（jpg/webp quality 82、png 压缩级别 9，PNG/WebP 保留透明）。
- 跳过条件：最长边已 ≤1600 且体积 <150KB（小图不做二次编码）、像素 >4000 万（OOM 保护）、
  当前 `memory_limit` 不足以解码该像素数（大图保护，如 128M 下 >25MP）、或 GD/解码不可用；
  跳过时原文件保持不变，接口照常返回成功。
- 上传成功后立即预生成 160/480/960 缩略图（`/uploads/thumbs/{width}/reviews/...`），`size` 为压缩后的落盘字节数。
- 大图上传同样受 PHP ini 限制：`upload_max_filesize` / `post_max_size` 需 ≥ 业务上限（见上方视频章节），
  否则请求在进入业务代码前就被 413 拦截。

### POST `/api/review/helpful`（需登录）

有用 / 无用投票。

```json
// Request
{ "review_id": 12, "vote": 1 }

// vote: 1=有用, 2=无用

// Response
{
  "code": 0,
  "message": "ok",
  "data": {
    "review_id": 12,
    "vote": 1,
    "helpful_yes": 3,
    "helpful_no": 0
  }
}
```

- 同一用户同一评论只保留一票：重复同票取消，异票切换。

---

## 12. 分享归因

### POST `/api/share/report`（需登录）

上报分享归因。

```json
// Request
{
  "referrer_user_id": 5,
  "product_id": 1,
  "scene": "group"
}

// scene: group=群聊, share=朋友圈, direct=直接分享

// Response
{ "code": 0, "message": "ok", "data": null }
```

- `referrer_user_id` 等于当前用户时忽略（自己分享给自己不计归因）。
- 归因记录在用户下单结算时自动关联到子订单。

---

## 13. 用户中心

> 以下接口均需 `Authorization: Bearer <token>`

### GET `/api/user/profile`

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "id": 1,
    "openid": "oxxxxxxxx",
    "nickname": "微信用户",
    "avatar": "/uploads/avatars/202610/xxx.png",
    "phone": "13800138000"
  }
}
```

- 注意：接口返回的是数据库原值，手机号脱敏由前端按需处理。

### POST `/api/user/update`

更新资料，**返回更新后的完整用户对象**（前端直接缓存）。

```json
// Request
{
  "nickname": "新昵称",
  "avatar": "/uploads/avatars/202610/xxx.png",
  "phone": "13900139000"
}

// Response
{
  "code": 0,
  "message": "ok",
  "data": {
    "id": 1,
    "openid": "oxxxxxxxx",
    "nickname": "新昵称",
    "avatar": "/uploads/avatars/202610/xxx.png",
    "phone": "13900139000"
  }
}
```

- 所有字段可选，只传需要更新的字段。
- 小程序推荐流程：昵称/头像走本接口，手机号走 `/api/user/bind-phone` 获取微信授权号码。
- 独立站（浏览器）用户没有微信授权能力，可直接通过本接口提交 `phone` 以满足下单门槛。

### POST `/api/user/avatar`

头像上传（multipart，字段名 `file`）。

```json
{
  "code": 0,
  "message": "ok",
  "data": { "url": "/uploads/avatars/202610/xxx.png" }
}
```

- 仅支持 jpg / jpeg / png / webp，大小上限 2MB，服务端校验文件内容 MIME。

### POST `/api/user/bind-phone`

用 `getPhoneNumber` 返回的 code 绑定手机号。

```json
// Request
{ "code": "phone_code_from_wx" }

// Response
{
  "code": 0,
  "message": "ok",
  "data": { "phone": "13800138000" }
}
```

### GET `/api/user/address/list`

```json
{
  "code": 0,
  "message": "ok",
  "data": [
    {
      "id": 5,
      "name": "张三",
      "phone": "13800138000",
      "address_detail": "广东省深圳市南山区科技园",
      "is_default": 1
    }
  ]
}
```

- 默认地址排在最前。

### POST `/api/user/address/add`

```json
// Request
{
  "name": "张三",
  "phone": "13800138000",
  "address_detail": "广东省深圳市南山区科技园",
  "is_default": 1
}

// Response
{ "code": 0, "message": "ok", "data": {"id": 5} }
```

- 首个地址自动设为默认；`is_default=1` 时自动取消其他地址的默认状态。
- `name` / `phone` / `address_detail` 必填。

### POST `/api/user/address/update`

```json
{
  "id": 5,
  "name": "李四",
  "phone": "13900139000",
  "address_detail": "广东省深圳市南山区科技园 1 栋",
  "is_default": 1
}
```

- 除 `id` 外所有字段可选。
- 取消唯一默认地址时自动把最早创建的另一个地址设为默认。

### POST `/api/user/address/delete`

```json
{ "id": 5 }
```

- 删除默认地址后自动补选一个默认地址。

---

## 14. 独立站（浏览器）登录

浏览器无法获取 `wx.login` 的 code，独立站使用邮箱 + 验证码登录，签发与小程序相同格式的 token，可直接复用上述全部用户接口。

### POST `/api/site/auth/send-code`

```json
// Request
{ "email": "user@example.com" }

// Response
{
  "code": 0,
  "message": "验证码已发送",
  "data": {
    "sent": true,
    "ttl": 600,
    "dev_mode": false,
    "dev_code": null
  }
}
```

- 60 秒内重复发送返回 `code=40001`。
- 未配置邮件服务时 `dev_mode=true` 且 `dev_code` 回显验证码（仅开发环境）。

### POST `/api/site/auth/verify-code`

```json
// Request
{ "email": "user@example.com", "code": "123456" }

// Response
{
  "code": 0,
  "message": "ok",
  "data": {
    "token": "a1b2c3d4e5f6...",
    "user": {
      "id": 1,
      "email": "user@example.com",
      "nickname": "user",
      "avatar": "",
      "phone": ""
    }
  }
}
```

- 验证码 10 分钟有效，最多尝试 5 次；首次登录自动建号并触发注册礼。

### GET `/api/site/auth/me`

返回当前登录用户；未登录返回 HTTP 401。

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "id": 1,
    "email": "user@example.com",
    "nickname": "user",
    "avatar": "",
    "phone": "",
    "openid": "web_xxxx"
  }
}
```

### POST `/api/site/auth/sign-out`

使当前 token 失效，`data` 为 `null`。

### POST `/api/site/contact`

联系页留言（落库 + 邮件通知，邮件失败不影响返回成功）。

```json
// Request
{
  "name": "张三",
  "email": "user@example.com",
  "subject": "咨询",
  "content": "请问……"
}

// Response
{ "code": 0, "message": "留言已提交，我们会尽快联系您", "data": null }
```

### POST `/api/site/subscribe`

Newsletter 订阅（同邮箱幂等）。

```json
// Request
{ "email": "user@example.com" }

// Response
{
  "code": 0,
  "message": "订阅成功",
  "data": { "subscribed": true, "created": true }
}
```

---

## 订单状态流转

```
待支付(0) ──支付成功──→ 待发货(1) ──商户发货──→ 配送中(2) ──送达──→ 已送达(3)
     │                                                                        │
     │取消                                                          确认收货│
     ↓                                                                        ↓
 已取消(-1)                                                             已完成(4)
                                                                              │
                                      ┌──── 售后退款完成 ────→ 已退款(-2) ←──┘
                                      │
                                      └── 平台结算：(5) 可结算 → (6) 已结算（后台内部）
```

**状态码对照**

| 状态 | 说明 |
|------|------|
| -2 | 已退款 |
| -1 | 已取消 |
| 0 | 待支付 |
| 1 | 待发货 |
| 2 | 配送中 |
| 3 | 已送达 |
| 4 | 已完成 |
| 5 | 可结算（后台） |
| 6 | 已结算（后台） |

## 售后状态流转

```
待审核(0) ──审核通过(仅退款)──→ 已完成(4)
         │
         ├──审核通过(退货退款)──→ 待退货(3) ──确认收货──→ 已完成(4)
         │
         └──拒绝──→ 已拒绝(2)
```

---

## 15. 前端对接要点

1. **登录流程**：`wx.login()` → 拿到 `code` → `POST /api/auth/login` → 存 `token` 到 storage。
2. **请求封装**：所有请求带 `Authorization: Bearer <token>`；收到 HTTP 401 时重新登录并重试一次。
3. **金额处理**：后端返回元字符串（`"29.99"`），前端直接显示或 `parseFloat` 后计算。
4. **分页**：`page` 从 1 开始，`hasMore` 判断是否还有更多。
5. **SKU 选择器**：用 `specs` 构建多维度选择，按 `spec_values_json` 匹配唯一 SKU 后取 `id` 和 `stock`。
6. **支付流程**：`checkout` → 拿 `order_pay_id` 与 `sub_orders[].id` → `pay` → 微信参数直接调 `wx.requestPayment`；跳转型通道用返回的 `url`。
7. **游客车**：未登录用本地 `sku_id + quantity`，展示走 `/api/cart/preview`；登录后调 `/api/cart/merge` 合并。
8. **优惠**：结算页用 `/api/coupon/mine` + `/api/coupon/quote` 展示可用券与实付；下单把 `coupon_user_id` / `coupon_code` 传给 `checkout`。
9. **图片**：后端返回站内相对路径，前端用统一的 `resolveImageUrl` 补域名。

---

## 附：与早期接口文档的差异（已按实现修正）

| # | 位置 | 旧写法 | 当前实现 |
|---|---|---|---|
| 1 | checkout 响应 | `sub_orders` 无 `id` | 返回 `sub_orders[].id`，用于跳转订单详情 |
| 2 | order/list | 无 `pay_id` | 返回 `pay_id`，用于列表直接支付/取消 |
| 3 | order/detail | 无 `pay_id`、`remark` | 均返回 |
| 4 | order/detail | `aftersale: null`，无状态名 | 返回 `{id, status, status_label}` |
| 5 | product/detail | 无 `specs`、无视频 | 返回 `specs[]`、`video_url`、`video_cover` |
| 6 | aftersale/list | 无商品信息 | 返回 `product_title` / `product_image` |
| 7 | aftersale/detail | 无 `items[]` | 返回 `items[]` |
| 8 | 用户 | 无 `/user/avatar`、`/user/bind-phone` | 两个接口均已实现 |
| 9 | 订单 | 无 `/order/logistics` | 已实现 |
| 10 | checkout 请求 | 支持内联 `address` 对象 | 仅支持 `address_id`（推荐先保存地址） |
| 11 | 订单列表/详情 | 无币种展示 | 增加 `display` 币种展示对象（国际版参考价） |
| 12 | 订单详情 | 无优惠明细 | 增加 `discount_lines` 下单快照 |
| 13 | 售后 | 无退款进度 | 增加 `refund_status` / `refund_status_label` |
| 14 | order/detail | `items[]` 无 `product_id` | 增加 `product_id`（评论资格查询依赖） |
| 15 | 评论 | 无「我的评价」 | 新增 `GET /api/review/mine` |
