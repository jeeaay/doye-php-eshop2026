<?php
// 应用公共文件
declare(strict_types=1);

if (!function_exists('h')) {
    /**
     * HTML 转义输出（模板中使用 {:h($var)}）
     */
    function h($value): string
    {
        if (is_array($value) || is_object($value)) {
            return '';
        }
        return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

if (!function_exists('site_config')) {
    /**
     * 读取前台站点配置：site_config('brand.name', 'DepthX')
     *
     * 取值优先级：数据库 setting 表（后台「系统设置」写入的覆盖值）
     *           > config/site.php（默认值）。
     * 合并结果在单次请求内缓存，实际读取逻辑见 SettingService::mergedConfig()。
     */
    function site_config(?string $key = null, $default = null)
    {
        $config = \app\common\service\SettingService::mergedConfig();
        if ($key === null || $key === '') {
            return $config;
        }
        $value = $config;
        foreach (explode('.', $key) as $segment) {
            if (!is_array($value) || !array_key_exists($segment, $value)) {
                return $default;
            }
            $value = $value[$segment];
        }
        return $value;
    }
}

if (!function_exists('money')) {
    /**
     * 金额格式化（PHP 后台价格为 decimal(10,2)，没有分单位）
     */
    function money($amount, int $decimals = 2): string
    {
        return number_format((float) $amount, $decimals, '.', '');
    }
}

if (!function_exists('min_payable_amount')) {
    /**
     * 最低起送金额（基准币种，两位小数字符串；0 表示不限）
     *
     * 口径是整笔结算单「优惠后实付」，由 OrderService::checkout() 与前台试算共用。
     */
    function min_payable_amount(): string
    {
        $value = bcadd((string) site_config('order.min_payable', '0.00'), '0', 2);
        return bccomp($value, '0', 2) > 0 ? $value : '0.00';
    }
}

if (!function_exists('theme_asset')) {
    /**
     * 主题静态资源 URL（旧版兼容）
     * 已废弃，请使用 template_asset()
     */
    function theme_asset(string $path = ''): string
    {
        return template_asset($path);
    }
}

if (!function_exists('template_asset')) {
    /**
     * 模板静态资源 URL
     *
     * 读取当前启用的模板名（site.template），拼出 /{template}/xxx 路径。
     * 模板中使用：{:template_asset('css/app.css')}
     */
    function template_asset(string $path = ''): string
    {
        $template = (string) site_config('site.template', 'almi2026');
        if ($template === '' || $template === 'none') {
            return '';
        }
        return '/' . $template . '/' . ltrim($path, '/');
    }
}

if (!function_exists('media_thumb')) {
    /**
     * 本地媒体缩略图 URL（按需生成并缓存到 uploads/thumbs/{width}/）
     *
     * 非本地地址、GD 缺失、源图宽度已足够或生成失败时原样返回入参，
     * 因此模板可以无条件使用：`{:media_thumb($image, 480)}`。
     * 模板里不要直接写 `{:\app\common\service\ThumbnailService::url(...)}`——模板标签会
     * `stripslashes()`，命名空间反斜杠会被吃掉导致类名解析失败。
     */
    function media_thumb(string $url, int $width = 480): string
    {
        return \app\common\service\ThumbnailService::url($url, $width);
    }
}

if (!function_exists('storefront_product_url')) {
    /**
     * 前台商品详情 URL。
     *
     * 商品设置了 custom_path 时优先返回自定义路径：
     *   - 未开启根级：/products/{custom_path}
     *   - 开启根级  ：/{custom_path}（省略 .html 后缀）
     * 否则回落 /products/{id}（数字路径始终可用，不做 301）。
     *
     * @param int|string|array|object $product 商品 ID，或含 custom_path / custom_path_root 的商品数据
     */
    function storefront_product_url($product): string
    {
        $id = 0;
        $customPath = '';
        $isRoot = false;

        if (is_object($product)) {
            $id = (int) ($product->id ?? 0);
            $customPath = trim((string) ($product->custom_path ?? ''));
            $isRoot = (int) ($product->custom_path_root ?? 0) === 1;
        } elseif (is_array($product)) {
            $id = (int) ($product['id'] ?? 0);
            $customPath = trim((string) ($product['custom_path'] ?? ''));
            $isRoot = (int) ($product['custom_path_root'] ?? 0) === 1;
        } else {
            $id = (int) $product;
        }

        if ($customPath !== '') {
            if ($isRoot) {
                return '/' . (preg_replace('/\.html$/', '', $customPath) ?: $customPath);
            }
            return '/products/' . $customPath;
        }

        return '/products/' . $id;
    }
}

if (!function_exists('admin_path')) {
    /**
     * 后台入口前缀（不含斜杠），来自 .env 的 ADMIN_PATH，默认 console
     */
    function admin_path(): string
    {
        $path = trim((string) config('app.admin_path', 'admin'), '/');

        return $path !== '' ? $path : 'admin';
    }
}

if (!function_exists('admin_base')) {
    /**
     * 后台入口基址：admin_base() => /console
     */
    function admin_base(): string
    {
        return '/' . admin_path();
    }
}

if (!function_exists('admin_url')) {
    /**
     * 生成后台 URL：admin_url('products') => /console/products
     *
     * 兼容传入旧式路径（/admin/products），便于逐步迁移调用点。
     */
    function admin_url(string $path = ''): string
    {
        $path = trim($path);

        if ($path === '' || $path === '/') {
            return admin_base();
        }
        if (preg_match('#^(?:https?:)?//#i', $path)) {
            return $path;
        }
        if ($path === '/admin' || $path === 'admin') {
            $path = '';
        } elseif (preg_match('#^/admin/(.*)$#', $path, $matches) || preg_match('#^admin/(.*)$#', $path, $matches)) {
            $path = $matches[1];
        }

        $path = ltrim($path, '/');

        return $path === '' ? admin_base() : admin_base() . '/' . $path;
    }
}

if (!function_exists('client_ip')) {
    /**
     * 客户端真实 IP（遵循后台「系统设置 → 安全设置」的可信代理配置）
     *
     * 默认取 REMOTE_ADDR；开启「信任反向代理请求头」且代理地址命中
     * 可信代理列表时，才采信 CF-Connecting-IP / X-Real-IP / X-Forwarded-For。
     * 与安全防护拦截使用同一解析结果，避免审计日志、限流与封禁口径不一致。
     */
    function client_ip(): string
    {
        try {
            return \app\common\service\SecurityService::clientIp();
        } catch (\Throwable $e) {
            return '';
        }
    }
}

if (!function_exists('site_edition')) {
    /**
     * 当前站点版本：international / domestic
     */
    function site_edition(): string
    {
        $edition = strtolower(trim((string) site_config('site.edition', 'international')));
        return in_array($edition, ['international', 'domestic'], true) ? $edition : 'international';
    }
}

if (!function_exists('is_domestic_edition')) {
    function is_domestic_edition(): bool
    {
        return site_edition() === 'domestic';
    }
}

if (!function_exists('base_locale')) {
    /**
     * 基准语言（模板源语言）：取「多语言管理」中标记为默认的语种
     *
     * 默认语种即模板语言，模板翻译的目标语言会自动排除它。
     * 数据表尚未创建（安装/迁移阶段）时回退到版本默认值。
     */
    function base_locale(): string
    {
        static $cached = null;
        if ($cached !== null) {
            return $cached;
        }

        try {
            $code = \app\common\model\Language::where('is_default', 1)->value('code');
            if (is_string($code) && $code !== '') {
                return $cached = \app\common\service\LanguageService::normalizeCode($code);
            }
        } catch (\Throwable $e) {
            // 忽略：安装阶段语种表可能还不存在
        }

        return $cached = is_domestic_edition() ? 'zh' : 'en';
    }
}

if (!function_exists('base_currency_code')) {
    /**
     * 基准币种：国内版 CNY，国际版 USD
     */
    function base_currency_code(): string
    {
        return is_domestic_edition() ? 'CNY' : 'USD';
    }
}

if (!function_exists('current_locale')) {
    /**
     * 当前请求的语种短码（en / ru / zh ...）
     */
    function current_locale(): string
    {
        return \app\common\support\LocaleContext::localeCode();
    }
}

if (!function_exists('display_currency')) {
    /**
     * 当前展示币种（数组：code / symbol / decimals / rate ...）
     *
     * @return array<string,mixed>
     */
    function display_currency(): array
    {
        return \app\common\support\LocaleContext::currency();
    }
}

if (!function_exists('format_money')) {
    /**
     * 把 USD 金额换算成当前展示币种并格式化
     *
     * 仅用于前台展示；订单、支付、退款、结算一律使用 USD 原值。
     */
    function format_money($usd, ?array $currency = null): string
    {
        return (new \app\common\service\PricingService())->format($usd, $currency);
    }
}

if (!function_exists('localized_url')) {
    /**
     * 生成带语种前缀的站内 URL
     *
     * 默认语种不带前缀：/products/1
     * 其他语种带前缀：/ru/products/1
     */
    function localized_url(string $path, ?string $locale = null): string
    {
        $path = '/' . ltrim($path, '/');
        $locale = strtolower(trim($locale ?? current_locale()));

        try {
            $default = strtolower((string) ((new \app\common\service\LanguageService())->default()['code'] ?? 'en'));
        } catch (\Throwable $e) {
            $default = 'en';
        }

        if ($locale === '' || $locale === $default) {
            return $path;
        }

        return '/' . $locale . ($path === '/' ? '/' : $path);
    }
}

if (!function_exists('site_lang')) {
    /**
     * 读取前台静态文案（app/lang/{locale}/site.php）
     *
     * 译文缺失时回退英文；再缺则返回 key，便于发现未翻译项。
     *
     * @param string $key 文案键，如 nav.home
     * @param array<string,string> $replace 占位符替换，{name} => value
     */
    function site_lang(string $key, array $replace = []): string
    {
        static $packs = [];

        $load = static function (string $code) use (&$packs): array {
            $code = preg_replace('/[^a-z\-]/i', '', strtolower($code)) ?: 'en';
            if (isset($packs[$code])) {
                return $packs[$code];
            }

            $file = app()->getBasePath() . 'lang' . DIRECTORY_SEPARATOR . $code . DIRECTORY_SEPARATOR . 'site.php';
            if (!is_file($file)) {
                $file = app()->getBasePath() . 'lang' . DIRECTORY_SEPARATOR . 'en' . DIRECTORY_SEPARATOR . 'site.php';
            }

            return $packs[$code] = is_file($file) ? (array) require $file : [];
        };

        $locale = current_locale();
        $value = $load($locale)[$key] ?? $load('en')[$key] ?? $key;

        if (is_array($replace) && $replace) {
            foreach ($replace as $name => $replacement) {
                $value = str_replace('{' . $name . '}', (string) $replacement, $value);
            }
        }

        return (string) $value;
    }
}