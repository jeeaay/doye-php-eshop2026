<?php
declare(strict_types=1);

namespace app\controller;

/**
 * 账户中心（eshop2026 主题）
 *
 * 页面骨架与原站一致，数据由 store.js 调 /api/* 获取。
 * 说明：eshop2026 的 account-* 页面在源项目里是静态设计稿，本迁移只保证页面可访问，
 * 数据绑定见 todo.md「账户中心页仍是静态稿」。
 */
class Account extends SiteBase
{
    public function index()
    {
        return $this->page('account-overview', 'My Account');
    }

    public function orders()
    {
        return $this->page('account-orders', 'My Orders');
    }

    public function orderDetail($id = 0)
    {
        return $this->page('account_order_detail', 'Order Detail', ['order_id' => (int) $id]);
    }

    public function addresses()
    {
        return $this->page('account-addresses', 'My Addresses', [
            // 国家下拉只服务国际版发货时效；国内版不渲染（模板按空数组隐藏）
            'ship_to_groups' => is_domestic_edition() ? [] : (new \app\common\service\ShippingEtaService())->countries(),
        ]);
    }

    public function wishlist()
    {
        return $this->page('account-wishlist', 'My Wishlist');
    }

    public function rewards()
    {
        return $this->page('account-rewards', 'My Rewards');
    }

    /**
     * 我的优惠券：站内唯一兜底入口（收不到邮件也能看到到账券）
     *
     * @return \think\Response
     */
    public function coupons()
    {
        return $this->page('account-coupons', 'My Coupons');
    }

    /**
     * 我的评价：只读列表，数据由 /api/review/mine 提供（审核状态 / 商家回复）
     *
     * @return \think\Response
     */
    public function reviews()
    {
        return $this->page('account-reviews', 'My Reviews');
    }

    public function logout()
    {
        return $this->page('account-logout', 'Signed out');
    }

    private function page(string $view, string $title, array $extra = [])
    {
        $brand = $this->store->brand();
        return $this->render($view, array_merge([
            'nav_active' => 'account',
            'page_title' => $title . ' - ' . $brand['name'],
        ], $extra));
    }
}
