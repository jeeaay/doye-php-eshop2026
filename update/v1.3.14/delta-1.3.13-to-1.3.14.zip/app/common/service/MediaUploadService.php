<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\exception\BizException;
use think\facade\Log;
use think\file\UploadedFile;

class MediaUploadService
{
    public function cleanupUnreferenced(int $olderThanSeconds = 86400, int $limit = 500): int
    {
        $root = realpath(public_path() . 'uploads/products');
        if (!$root || $olderThanSeconds < 0 || $limit < 1) {
            return 0;
        }

        $cutoff = time() - $olderThanSeconds;
        $deleted = 0;
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ($iterator as $file) {
            if (!$file->isFile() || $file->getMTime() > $cutoff || $deleted >= $limit) {
                continue;
            }
            $path = str_replace('\\', '/', $file->getPathname());
            if (!preg_match('~/products/(images|videos)/\d{6}/[a-f0-9]{32}\.(jpg|jpeg|png|webp|mp4|webm)$~', $path)) {
                continue;
            }
            $url = '/' . substr($path, strpos($path, '/uploads/'));
            $referenced = \think\facade\Db::name('product')
                ->where(function ($query) use ($url) {
                    $query->where('main_image', $url)
                        ->whereOr('video_url', $url)
                        ->whereOr('video_cover', $url)
                        ->whereOrLike('detail_html', '%' . addcslashes($url, '%_') . '%');
                })->find();
            if (!$referenced) {
                foreach (\think\facade\Db::name('product')->whereNotNull('images_json')->column('images_json') as $images) {
                    $images = is_array($images) ? $images : json_decode((string) $images, true);
                    if (is_array($images) && in_array($url, $images, true)) {
                        $referenced = true;
                        break;
                    }
                }
            }
            if (!$referenced && @unlink($file->getPathname())) {
                $deleted++;
            }
        }
        return $deleted;
    }

    public function upload(?UploadedFile $file, string $mediaType, string $namespace = 'products'): array
    {
        if (!$file || !$file->isValid()) {
            throw new BizException('请选择有效的上传文件');
        }
        if (!in_array($mediaType, ['image', 'video'], true)) {
            throw new BizException('媒体类型无效');
        }

        $isImage = $mediaType === 'image';
        $namespaceConfig = config('media.' . $namespace);
        if (!is_array($namespaceConfig) || !isset($namespaceConfig[$isImage ? 'image' : 'video'])) {
            throw new BizException('媒体资源类型无效');
        }
        $config = $namespaceConfig[$isImage ? 'image' : 'video'];
        $maxSize = (int) $config['max_size'];
        $extension = strtolower((string) $file->extension());
        $allowedExtensions = $config['extensions'];
        if ((int) $file->getSize() <= 0 || (int) $file->getSize() > $maxSize || !in_array($extension, $allowedExtensions, true)) {
            // 文案按命名空间配置生成：reviews.video 是 50MB，products.video 是 200MB，不能写死
            throw new BizException(
                ($isImage ? '图片' : '视频') . '必须是 ' . (int) ceil($maxSize / 1024 / 1024) . 'MB 以内的 '
                . implode('、', $allowedExtensions) . ' 文件'
            );
        }

        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($file->getPathname());
        $allowedMimes = $config['mimes'];
        if (!in_array($mime, $allowedMimes, true)) {
            throw new BizException('文件真实类型与扩展名不匹配');
        }
        $meta = ['size' => (int) $file->getSize(), 'mime' => $mime];
        if ($isImage) {
            $dimensions = @getimagesize($file->getPathname());
            if (!$dimensions) {
                throw new BizException('图片解析失败');
            }
            $meta['width'] = (int) $dimensions[0];
            $meta['height'] = (int) $dimensions[1];
        } elseif (!$this->hasVideoContainerSignature($file->getPathname(), $extension)) {
            throw new BizException('视频容器格式无效');
        }

        $month = date('Ym');
        $relativeDirectory = '/uploads/' . $namespace . '/' . ($isImage ? 'images/' : 'videos/') . $month . '/';
        $directory = public_path() . ltrim($relativeDirectory, '/');
        if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
            throw new BizException('上传目录不可写');
        }
        $filename = bin2hex(random_bytes(16)) . '.' . $extension;
        if (!move_uploaded_file($file->getPathname(), $directory . $filename)) {
            throw new BizException('文件保存失败');
        }
        $url = $relativeDirectory . $filename;
        if ($isImage) {
            $meta = array_merge($meta, $this->finalizeImage($directory . $filename, $url, $extension, $config, $namespace));
        }

        return ['url' => $url, 'mime' => $mime] + $meta;
    }

    /**
     * 通过原始字节保存媒体（API base64 / 下载场景）
     *
     * @param string $contents     文件内容
     * @param string $originalName 原始文件名（用于推导扩展名）
     * @param string $mediaType    image | video
     * @param string $namespace    products | brands | pages | merchants
     * @return array{url:string,mime:string,size:int}
     */
    public function storeContents(string $contents, string $originalName, string $mediaType, string $namespace = 'products'): array
    {
        if ($contents === '') {
            throw new BizException('媒体内容为空');
        }

        $tmp = tempnam(sys_get_temp_dir(), 'media_');
        if ($tmp === false || file_put_contents($tmp, $contents) === false) {
            throw new BizException('媒体临时文件写入失败');
        }

        try {
            return $this->storeFromTempFile($tmp, $originalName, $mediaType, $namespace);
        } finally {
            @unlink($tmp);
        }
    }

    /**
     * 通过临时文件保存媒体
     *
     * @param string $tmpPath      临时文件路径
     * @param string $originalName 原始文件名（用于推导扩展名）
     * @param string $mediaType    image | video
     * @param string $namespace    products | brands | pages | merchants
     * @return array{url:string,mime:string,size:int}
     */
    public function storeFromTempFile(string $tmpPath, string $originalName, string $mediaType, string $namespace = 'products'): array
    {
        if (!is_file($tmpPath)) {
            throw new BizException('媒体临时文件不存在');
        }

        $config = $this->mediaConfig($namespace, $mediaType);
        $isImage = $mediaType === 'image';
        $size = (int) filesize($tmpPath);
        $extension = strtolower((string) pathinfo($originalName, PATHINFO_EXTENSION));
        if ($extension === '') {
            $extension = $this->extensionFromMime((string) ($config['mimes'][0] ?? ''), $config);
        }

        $this->assertMediaSizeAndExtension($size, $extension, $config, $isImage);

        $mime = (string) (new \finfo(FILEINFO_MIME_TYPE))->file($tmpPath);
        if (!in_array($mime, (array) $config['mimes'], true)) {
            throw new BizException('文件真实类型与扩展名不匹配');
        }

        $meta = ['size' => $size, 'mime' => $mime];
        if ($isImage) {
            $dimensions = @getimagesize($tmpPath);
            if (!$dimensions) {
                throw new BizException('图片解析失败');
            }
            $meta['width'] = (int) $dimensions[0];
            $meta['height'] = (int) $dimensions[1];
        } elseif (!$this->hasVideoContainerSignature($tmpPath, $extension)) {
            throw new BizException('视频容器格式无效');
        }

        $month = date('Ym');
        $relativeDirectory = '/uploads/' . $namespace . '/' . ($isImage ? 'images/' : 'videos/') . $month . '/';
        $directory = public_path() . ltrim($relativeDirectory, '/');
        if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
            throw new BizException('上传目录不可写');
        }
        $filename = bin2hex(random_bytes(16)) . '.' . $extension;
        if (!copy($tmpPath, $directory . $filename)) {
            throw new BizException('文件保存失败');
        }
        $url = $relativeDirectory . $filename;
        if ($isImage) {
            $meta = array_merge($meta, $this->finalizeImage($directory . $filename, $url, $extension, $config, $namespace));
        }

        return ['url' => $url, 'mime' => $mime] + $meta;
    }

    /**
     * 解析 data:image/...;base64,... 形式的媒体
     *
     * @param string $dataUri   data URI
     * @param string $mediaType image | video
     * @param string $namespace 资源命名空间
     * @return array{url:string,mime:string,size:int}
     */
    public function parseDataUri(string $dataUri, string $mediaType, string $namespace = 'products'): array
    {
        if (!preg_match('#^data:([a-z0-9.+/-]+);base64,(.*)$#is', $dataUri, $matches)) {
            throw new BizException('base64 媒体格式无效');
        }

        $mime = strtolower(trim($matches[1]));
        $config = $this->mediaConfig($namespace, $mediaType);
        $index = array_search($mime, (array) $config['mimes'], true);
        if ($index === false) {
            throw new BizException('base64 媒体类型不受支持');
        }

        $bytes = base64_decode(preg_replace('/\s+/', '', $matches[2]) ?? '', true);
        if ($bytes === false) {
            throw new BizException('base64 内容解码失败');
        }

        $extension = $this->extensionFromMime($mime, $config);
        if ($extension === '') {
            throw new BizException('base64 媒体类型不受支持');
        }

        return $this->storeContents($bytes, 'upload.' . $extension, $mediaType, $namespace);
    }

    /**
     * 从远程 URL 下载并保存媒体
     *
     * 安全约束：仅 http/https、最多 3 次跳转、拒绝私有/环回/保留地址、
     * 超时 10 秒、大小受 config/media.php 限制。
     *
     * @param string $url       远程地址
     * @param string $mediaType image | video
     * @param string $namespace 资源命名空间
     * @return array{url:string,mime:string,size:int}
     */
    public function importFromUrl(string $url, string $mediaType, string $namespace = 'products'): array
    {
        $config = $this->mediaConfig($namespace, $mediaType);
        $maxSize = (int) $config['max_size'];

        $tmp = tempnam(sys_get_temp_dir(), 'media_url_');
        if ($tmp === false) {
            throw new BizException('媒体临时文件创建失败');
        }

        $handle = fopen($tmp, 'wb');
        if (!$handle) {
            @unlink($tmp);
            throw new BizException('媒体临时文件不可写');
        }

        $current = $url;
        $contentType = '';
        $finalUrl = $url;
        $downloaded = false;

        try {
            for ($redirect = 0; $redirect <= 3; $redirect++) {
                $this->assertSafeRemoteUrl($current);

                $location = '';
                $ch = curl_init($current);
                if ($ch === false) {
                    throw new BizException('媒体下载初始化失败');
                }

                curl_setopt_array($ch, [
                    CURLOPT_FILE            => $handle,
                    CURLOPT_FOLLOWLOCATION  => false,
                    CURLOPT_TIMEOUT         => 10,
                    CURLOPT_CONNECTTIMEOUT  => 5,
                    CURLOPT_MAXFILESIZE     => $maxSize,
                    CURLOPT_USERAGENT       => 'AlmiAdminAPI/1.0',
                    CURLOPT_SSL_VERIFYPEER  => true,
                    CURLOPT_HEADERFUNCTION  => static function ($curl, string $header) use (&$location): int {
                        if (stripos($header, 'location:') === 0) {
                            $location = trim(substr($header, 9));
                        }
                        return strlen($header);
                    },
                    CURLOPT_NOPROGRESS       => false,
                    CURLOPT_PROGRESSFUNCTION => static function ($curl, $downloadTotal, $downloaded) use ($maxSize): int {
                        return $downloaded > $maxSize ? 1 : 0;
                    },
                ]);

                $ok = curl_exec($ch);
                $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
                $contentType = (string) curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
                $finalUrl = (string) curl_getinfo($ch, CURLINFO_EFFECTIVE_URL) ?: $current;
                $error = (string) curl_error($ch);

                if ($ok === false) {
                    throw new BizException('媒体下载失败：' . ($error !== '' ? $error : '网络错误'));
                }

                if (in_array($status, [301, 302, 303, 307, 308], true)) {
                    if ($location === '' || $redirect >= 3) {
                        throw new BizException('媒体下载跳转次数过多');
                    }
                    $current = $this->resolveRedirectUrl($finalUrl, $location);
                    if (ftruncate($handle, 0) === false || rewind($handle) === false) {
                        throw new BizException('媒体临时文件重置失败');
                    }
                    continue;
                }

                if ($status < 200 || $status >= 300) {
                    throw new BizException('媒体下载失败：HTTP ' . $status);
                }

                $downloaded = true;
                break;
            }
        } finally {
            fclose($handle);
            if (!$downloaded) {
                @unlink($tmp);
            }
        }

        try {
            $size = (int) filesize($tmp);
            if ($size <= 0) {
                throw new BizException('下载内容为空');
            }
            if ($size > $maxSize) {
                throw new BizException('媒体文件超过大小限制');
            }

            $extension = strtolower((string) pathinfo((string) parse_url($finalUrl, PHP_URL_PATH), PATHINFO_EXTENSION));
            if (!in_array($extension, (array) $config['extensions'], true)) {
                $mime = strtolower(trim(explode(';', $contentType)[0]));
                $extension = $this->extensionFromMime($mime, $config);
                if ($extension === '') {
                    throw new BizException('无法识别媒体类型');
                }
            }

            return $this->storeFromTempFile($tmp, 'download.' . $extension, $mediaType, $namespace);
        } finally {
            @unlink($tmp);
        }
    }

    /**
     * 图片落盘后的统一后处理（压缩 + 预生成缩略图）
     *
     * 只有配置了 `compress` 的命名空间（当前为 `reviews.image`）才压缩并预生成缩略图；
     * `products` 保持原有行为（仅预生成缩略图），其余命名空间不做处理。
     * 失败一律静默：压缩不改变上传成功与否，最坏情况保留原图。
     *
     * @param string $path      落盘后的绝对路径
     * @param string $url       对外 URL（缩略图按它推导缓存目录）
     * @param string $extension 扩展名
     * @param array  $config    命名空间下的 image 配置
     * @param string $namespace 命名空间
     * @return array{width?:int,height?:int,size?:int} 需要覆盖到响应里的 meta 字段
     */
    private function finalizeImage(string $path, string $url, string $extension, array $config, string $namespace): array
    {
        $compress = $config['compress'] ?? null;
        if (is_array($compress) && $compress !== []) {
            $optimized = $this->optimizeReviewImage($path, $extension, $compress);
            $presets   = isset($compress['presets']) && is_array($compress['presets']) ? $compress['presets'] : null;
            // 压缩后立即预生成列表缩略图，避免首次访问在 API 内同步生成
            (new ThumbnailService())->generatePresets($url, $presets);

            return $optimized ?? [];
        }

        if ($namespace === 'products') {
            (new ThumbnailService())->generatePresets($url);
        }

        return [];
    }

    /**
     * 评论图片服务端压缩（就地重编码，格式与扩展名不变）
     *
     * 规则：
     * - 像素超过 ThumbnailService::MAX_SOURCE_PIXELS、或超出当前 memory_limit 预算直接跳过（OOM 保护）；
     * - 最长边按 compress.max_width / max_height 等比缩放，不放大；
     * - JPEG 先按 EXIF Orientation 纠正方向，再按纠正后的宽高算目标尺寸；
     * - 按原格式写回：jpg/webp 用 quality，png 用压缩级别 9；PNG/WebP 保留透明通道；
     * - 尺寸已达标、体积小于 min_bytes、且无需纠正方向时跳过（避免小图二次损失）；
     * - 任何失败保留原文件并返回 null，只写 warning 日志（不记录用户完整路径）。
     *
     * @param string $path      落盘后的绝对路径
     * @param string $extension 扩展名（决定写回格式）
     * @param array  $config    `reviews.image.compress`
     * @return array{width:int,height:int,size:int}|null null = 跳过或失败
     */
    private function optimizeReviewImage(string $path, string $extension, array $config): ?array
    {
        if (!is_file($path) || !ThumbnailService::gdReady()) {
            return null;
        }

        $info = @getimagesize($path);
        if (!$info) {
            return null;
        }
        $type   = (int) ($info[2] ?? 0);
        $width  = (int) $info[0];
        $height = (int) $info[1];
        if ($width <= 0 || $height <= 0 || $width * $height > ThumbnailService::MAX_SOURCE_PIXELS) {
            return null;
        }

        $maxWidth  = (int) ($config['max_width'] ?? 0);
        $maxHeight = (int) ($config['max_height'] ?? 0);
        $quality   = min(max((int) ($config['quality'] ?? 82), 1), 100);
        $minBytes  = (int) ($config['min_bytes'] ?? 0);
        $originalSize = (int) @filesize($path);

        $orientation = $this->exifOrientation($path, $type);
        $needRotate  = $orientation > 1;
        // 5/6/7/8 为 90/270 旋转，纠正后宽高互换
        $rotated     = in_array($orientation, [5, 6, 7, 8], true);
        $visualWidth  = $rotated ? $height : $width;
        $visualHeight = $rotated ? $width : $height;
        $needResize   = ($maxWidth > 0 && $visualWidth > $maxWidth) || ($maxHeight > 0 && $visualHeight > $maxHeight);

        if (!$needResize && !$needRotate && $minBytes > 0 && $originalSize < $minBytes) {
            return null;
        }

        // 像素数达标但当前 memory_limit 不足时同样跳过，避免 GD 解码直接 OOM 致命错误
        if (!ThumbnailService::canDecodePixels($width * $height)) {
            Log::warning('[review-image] 压缩跳过：内存预算不足 file=' . basename($path) . ' pixels=' . ($width * $height));

            return null;
        }

        $image = ThumbnailService::read($path, $type);
        if ($image === null) {
            Log::warning('[review-image] 压缩跳过：无法解码或格式不支持 file=' . basename($path) . ' ext=' . $extension);

            return null;
        }

        $image = $this->rotateImage($image, $orientation, $type);
        $sourceWidth  = imagesx($image);
        $sourceHeight = imagesy($image);

        // 等比缩放且不放大
        $scale = 1.0;
        if ($maxWidth > 0) {
            $scale = min($scale, $maxWidth / $sourceWidth);
        }
        if ($maxHeight > 0) {
            $scale = min($scale, $maxHeight / $sourceHeight);
        }
        $targetWidth  = $scale < 1.0 ? max(1, (int) round($sourceWidth * $scale)) : $sourceWidth;
        $targetHeight = $scale < 1.0 ? max(1, (int) round($sourceHeight * $scale)) : $sourceHeight;

        $canvas = imagecreatetruecolor($targetWidth, $targetHeight);
        if (!$canvas) {
            imagedestroy($image);

            return null;
        }
        if (in_array($type, [IMAGETYPE_PNG, IMAGETYPE_WEBP], true)) {
            // PNG/WebP 保留透明：先铺透明底再重采样
            imagealphablending($canvas, false);
            imagesavealpha($canvas, true);
            imagefilledrectangle($canvas, 0, 0, $targetWidth - 1, $targetHeight - 1, imagecolorallocatealpha($canvas, 255, 255, 255, 127));
            imagealphablending($canvas, true);
        }
        imagecopyresampled($canvas, $image, 0, 0, 0, 0, $targetWidth, $targetHeight, $sourceWidth, $sourceHeight);
        imagedestroy($image);

        // 先写临时文件再原子替换，写盘失败时原文件不受影响
        $tmpPath = $path . '.opt';
        $written = $this->writeImage($canvas, $tmpPath, $extension, $quality);
        imagedestroy($canvas);
        if (!$written) {
            @unlink($tmpPath);
            Log::warning('[review-image] 压缩写盘失败 file=' . basename($path) . ' ext=' . $extension);

            return null;
        }

        $newSize = (int) @filesize($tmpPath);
        if ($newSize <= 0) {
            @unlink($tmpPath);

            return null;
        }
        // 既没缩放也没旋转、结果反而更大时放弃重编码，保留原图
        if ($newSize >= $originalSize && !$needResize && !$needRotate) {
            @unlink($tmpPath);

            return null;
        }
        if (!@rename($tmpPath, $path)) {
            @unlink($tmpPath);
            Log::warning('[review-image] 压缩替换原文件失败 file=' . basename($path));

            return null;
        }

        return ['width' => $targetWidth, 'height' => $targetHeight, 'size' => $newSize];
    }

    /**
     * 读取 EXIF Orientation（仅 JPEG；缺失或无 exif 扩展时返回 1）
     */
    private function exifOrientation(string $path, int $type): int
    {
        if ($type !== IMAGETYPE_JPEG || !function_exists('exif_read_data')) {
            return 1;
        }
        $exif = @exif_read_data($path);
        if (!is_array($exif) || empty($exif['Orientation'])) {
            return 1;
        }
        $orientation = (int) $exif['Orientation'];

        return $orientation >= 1 && $orientation <= 8 ? $orientation : 1;
    }

    /**
     * 按 EXIF Orientation 纠正方向（1 原样返回）
     *
     * 3 = 180°；6 = 顺时针 90°；8 = 逆时针 90°；5（transpose）/ 7（transverse）为镜像变体（少见）。
     * 5/7 必须「先按 -90 旋转、再按 5 翻水平 / 7 翻垂直」才能得到各自的镜像方向
     * （+90 配翻垂直只会退化成 5 的结果，实测 GD 逐像素核对）。
     *
     * @param \GdImage $image
     * @return \GdImage
     */
    private function rotateImage($image, int $orientation, int $type)
    {
        if ($orientation < 2 || $orientation > 8) {
            return $image;
        }

        $alpha = in_array($type, [IMAGETYPE_PNG, IMAGETYPE_WEBP], true);
        if ($alpha) {
            imagesavealpha($image, true);
            imagealphablending($image, false);
        }

        if ($orientation === 2) {
            @imageflip($image, IMG_FLIP_HORIZONTAL);

            return $image;
        }
        if ($orientation === 4) {
            @imageflip($image, IMG_FLIP_VERTICAL);

            return $image;
        }

        $angle = match ($orientation) {
            3       => 180,
            5, 6, 7 => -90,
            default => 90,
        };
        $background = $alpha
            ? imagecolorallocatealpha($image, 255, 255, 255, 127)
            : imagecolorallocate($image, 255, 255, 255);
        $rotated = imagerotate($image, $angle, $background === false ? 0 : $background);
        if ($rotated === false) {
            return $image;
        }
        imagedestroy($image);
        if ($alpha) {
            imagesavealpha($rotated, true);
            imagealphablending($rotated, false);
        }
        if ($orientation === 5) {
            @imageflip($rotated, IMG_FLIP_HORIZONTAL);
        } elseif ($orientation === 7) {
            @imageflip($rotated, IMG_FLIP_VERTICAL);
        }

        return $rotated;
    }

    /**
     * 按原扩展名写回（png 用压缩级别 9）
     *
     * @param \GdImage $image
     */
    private function writeImage($image, string $path, string $extension, int $quality): bool
    {
        return match (strtolower($extension)) {
            'jpg', 'jpeg' => @imagejpeg($image, $path, $quality),
            'png'         => @imagepng($image, $path, 9),
            'webp'        => function_exists('imagewebp') ? @imagewebp($image, $path, $quality) : false,
            default       => false,
        };
    }

    /**
     * 读取并校验命名空间/媒体类型配置
     *
     * @param string $namespace 资源命名空间
     * @param string $mediaType image | video
     * @return array
     */
    private function mediaConfig(string $namespace, string $mediaType): array
    {
        if (!in_array($mediaType, ['image', 'video'], true)) {
            throw new BizException('媒体类型无效');
        }
        if (!in_array($namespace, ['products', 'brands', 'pages', 'merchants', 'reviews'], true)) {
            throw new BizException('媒体资源类型无效');
        }

        $namespaceConfig = config('media.' . $namespace);
        $key = $mediaType === 'image' ? 'image' : 'video';
        if (!is_array($namespaceConfig) || !isset($namespaceConfig[$key])) {
            throw new BizException('媒体资源类型无效');
        }

        return (array) $namespaceConfig[$key];
    }

    /**
     * 校验大小与扩展名
     *
     * @param int   $size      字节数
     * @param string $extension 扩展名
     * @param array $config     媒体配置
     * @param bool  $isImage    是否图片
     * @return void
     */
    private function assertMediaSizeAndExtension(int $size, string $extension, array $config, bool $isImage): void
    {
        $maxSize = (int) ($config['max_size'] ?? 0);
        $maxMb = $maxSize > 0 ? (int) ceil($maxSize / 1024 / 1024) : 0;
        $label = $isImage ? '图片' : '视频';
        $extensions = implode('、', (array) ($config['extensions'] ?? []));

        if ($size <= 0 || ($maxSize > 0 && $size > $maxSize) || !in_array($extension, (array) ($config['extensions'] ?? []), true)) {
            throw new BizException($label . '必须是 ' . $maxMb . 'MB 以内的 ' . $extensions . ' 文件');
        }
    }

    /**
     * 按 MIME 推导扩展名
     *
     * @param string $mime   MIME
     * @param array  $config 媒体配置
     * @return string
     */
    private function extensionFromMime(string $mime, array $config): string
    {
        $map = [
            'image/jpeg' => 'jpg',
            'image/png'  => 'png',
            'image/webp' => 'webp',
            'video/mp4'  => 'mp4',
            'video/webm' => 'webm',
        ];
        $extension = $map[strtolower($mime)] ?? '';
        $allowed = (array) ($config['extensions'] ?? []);

        return in_array($extension, $allowed, true) ? $extension : '';
    }

    /**
     * 校验远程 URL（协议、DNS、私网地址）
     *
     * @param string $url 远程地址
     * @return void
     */
    private function assertSafeRemoteUrl(string $url): void
    {
        $parts = parse_url($url);
        if (!is_array($parts) || !in_array(strtolower((string) ($parts['scheme'] ?? '')), ['http', 'https'], true) || empty($parts['host'])) {
            throw new BizException('媒体地址协议不受支持');
        }

        $host = strtolower((string) $parts['host']);
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            $this->assertPublicIp($host);
            return;
        }

        $ips = gethostbynamel($host) ?: [];
        $records = @dns_get_record($host, DNS_AAAA) ?: [];
        foreach ($records as $record) {
            if (!empty($record['ipv6'])) {
                $ips[] = $record['ipv6'];
            }
        }
        if (!$ips) {
            throw new BizException('媒体地址域名解析失败');
        }

        foreach ($ips as $ip) {
            $this->assertPublicIp((string) $ip);
        }
    }

    /**
     * 拒绝私有/环回/保留地址
     *
     * @param string $ip IP 地址
     * @return void
     */
    private function assertPublicIp(string $ip): void
    {
        $valid = filter_var(
            $ip,
            FILTER_VALIDATE_IP,
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
        );
        if ($valid === false) {
            throw new BizException('媒体地址不允许指向内网');
        }

        if (str_starts_with($ip, '127.')
            || str_starts_with($ip, '10.')
            || str_starts_with($ip, '192.168.')
            || str_starts_with($ip, '169.254.')
            || str_starts_with($ip, '0.')
            || str_starts_with($ip, '::1')
            || str_starts_with($ip, 'fc')
            || str_starts_with($ip, 'fd')
            || str_starts_with($ip, 'fe80')) {
            throw new BizException('媒体地址不允许指向内网');
        }

        if (preg_match('/^172\.(1[6-9]|2[0-9]|3[0-1])\./', $ip)) {
            throw new BizException('媒体地址不允许指向内网');
        }
    }

    /**
     * 解析跳转地址
     *
     * @param string $baseUrl  当前地址
     * @param string $location Location 头
     * @return string
     */
    private function resolveRedirectUrl(string $baseUrl, string $location): string
    {
        if (preg_match('#^https?://#i', $location)) {
            return $location;
        }

        $parts = parse_url($baseUrl);
        if (!is_array($parts) || empty($parts['host'])) {
            throw new BizException('媒体跳转地址无效');
        }

        $scheme = strtolower((string) ($parts['scheme'] ?? 'http'));
        $host = (string) $parts['host'];
        $port = isset($parts['port']) ? ':' . (int) $parts['port'] : '';

        if (str_starts_with($location, '//')) {
            return $scheme . ':' . $location;
        }
        if (str_starts_with($location, '/')) {
            return $scheme . '://' . $host . $port . $location;
        }

        $directory = rtrim(dirname((string) ($parts['path'] ?? '/')), '/');
        return $scheme . '://' . $host . $port . $directory . '/' . $location;
    }

    private function hasVideoContainerSignature(string $path, string $extension): bool
    {
        $handle = @fopen($path, 'rb');
        if (!$handle) {
            return false;
        }
        $header = (string) fread($handle, 64);
        fclose($handle);

        if ($extension === 'webm') {
            return strncmp($header, "\x1A\x45\xDF\xA3", 4) === 0;
        }

        // ISO Base Media files contain an "ftyp" box near the beginning.
        return strpos($header, 'ftyp') !== false;
    }
}
