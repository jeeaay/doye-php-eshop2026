<?php
declare(strict_types=1);

namespace app\common\command;

use app\common\enum\AdminRole;
use app\common\enum\OrderStatus;
use app\common\exception\BizException;
use app\common\service\ReviewService;
use app\common\support\AppContext;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\facade\Db;

/**
 * 评论系统自测（事务内造数，结束时整体回滚，不污染演示库）
 *
 * 覆盖：提交资格（未送达 / 取消 / 非本人）、创建待审核、重复提交、
 * 审核通过后统计与列表、状态切换、图片/视频地址白名单、投票新增/取消/切换、
 * 商户数据范围（非超管只读自己商户）。
 *
 * 输出契约：每行 PASS|FAIL <check> : <detail>，末行 ALL PASSED / FAILED，失败退出码 1。
 */
class ReviewSelftest extends Command
{
    /** @var array<string,bool> 各项校验结果 */
    private array $results = [];

    /** @var array<string,int> 固定数据（商户/商品/用户/订单商品行） */
    private array $fixture = [];

    /** @var array<string,int> 校验过程中产生的评论 ID */
    private array $state = [];

    private ReviewService $service;

    /** 合法的评论图片地址（与 ReviewService::IMAGE_PATTERN 一致） */
    private const VALID_IMAGE = '/uploads/reviews/images/202601/0123456789abcdef0123456789abcdef.jpg';

    private const INVALID_IMAGE = 'https://evil.example.com/uploads/reviews/images/202601/0123456789abcdef0123456789abcdef.jpg';

    /** 合法的评论视频地址（与 ReviewService::VIDEO_PATTERN 一致） */
    private const VALID_VIDEO = '/uploads/reviews/videos/202601/0123456789abcdef0123456789abcdef.mp4';

    private const INVALID_VIDEO = 'https://evil.example.com/uploads/reviews/videos/202601/0123456789abcdef0123456789abcdef.mp4';

    protected function configure(): void
    {
        $this->setName('review:selftest')
            ->setDescription('校验评论系统：资格/提交/审核/投票/商户范围（事务内回滚）');
    }

    protected function execute(Input $input, Output $output): void
    {
        AppContext::clear();
        $this->service = new ReviewService();
        $this->results = [];
        $this->state   = [];

        Db::startTrans();
        try {
            $this->seedFixtures();
            $this->runChecks($output);
        } catch (\Throwable $e) {
            $this->results['selftest.bootstrap'] = false;
            $output->writeln('<error>ABORTED</error> ' . $e->getMessage());
        } finally {
            Db::rollback();
            AppContext::clear();
        }

        $failed = array_keys(array_filter($this->results, static fn (bool $ok): bool => !$ok));
        if ($failed) {
            $output->writeln('<error>FAILED: ' . implode(', ', $failed) . '</error>');
            exit(1);
        }

        $output->writeln('<info>ALL PASSED</info>');
    }

    // ------------------------------------------------------------------
    // 校验流程
    // ------------------------------------------------------------------

    private function runChecks(Output $output): void
    {
        $f = $this->fixture;

        // 1. 资格：已送达订单可见，未送达 / 取消 / 非本人被拒
        $this->check($output, 'eligible.list_delivered', function () use ($f): string {
            $list = $this->service->eligible($f['product'], $f['buyer']);
            $ids  = array_column($list, 'order_item_id');
            sort($ids);
            $expected = [$f['item_main'], $f['item_images']];
            sort($expected);
            $this->assertThat($ids === $expected, '可用订单商品应只有 2 条，实际 [' . implode(',', $ids) . ']');
            $this->assertThat(($list[0]['order_no'] ?? '') !== '', 'order_no 不应为空');
            $this->assertThat(($list[0]['sku_name'] ?? '') === 'Default', 'sku_name 应取快照 spec_name');
            return 'items=[' . implode(',', $ids) . ']';
        });

        $this->check($output, 'eligible.reject_shipping', function () use ($f): string {
            $this->expectBiz(fn () => $this->service->create($f['buyer'], [
                'order_item_id' => $f['item_shipping'],
                'rating'        => 5,
                'content'       => 'Shipping order should not be reviewable.',
            ]), '送达');
            return 'shipping order rejected';
        });

        $this->check($output, 'eligible.reject_cancelled', function () use ($f): string {
            $this->expectBiz(fn () => $this->service->create($f['buyer'], [
                'order_item_id' => $f['item_cancelled'],
                'rating'        => 5,
                'content'       => 'Cancelled order should not be reviewable.',
            ]), '送达');
            return 'cancelled order rejected';
        });

        $this->check($output, 'eligible.reject_not_owner', function () use ($f): string {
            $this->expectBiz(fn () => $this->service->create($f['stranger'], [
                'order_item_id' => $f['item_main'],
                'rating'        => 5,
                'content'       => 'Stranger must not review someone else order.',
            ]), '不属于');
            return 'foreign order item rejected';
        });

        // 2. 写入校验
        $this->check($output, 'create.reject_short_content', function () use ($f): string {
            $this->expectBiz(fn () => $this->service->create($f['buyer'], [
                'order_item_id' => $f['item_main'],
                'rating'        => 5,
                'content'       => 'short',
            ]), '至少');
            return 'short content rejected';
        });

        $this->check($output, 'create.reject_invalid_image', function () use ($f): string {
            $this->expectBiz(fn () => $this->service->create($f['buyer'], [
                'order_item_id' => $f['item_main'],
                'rating'        => 5,
                'content'       => 'Content long enough for the review.',
                'images'        => [self::INVALID_IMAGE],
            ]), '本站');
            return 'external image rejected';
        });

        $this->check($output, 'create.reject_too_many_images', function () use ($f): string {
            $images = [];
            for ($i = 0; $i < ReviewService::MAX_IMAGES + 1; $i++) {
                $images[] = '/uploads/reviews/images/202601/' . md5('img' . $i) . '.jpg';
            }
            $this->expectBiz(fn () => $this->service->create($f['buyer'], [
                'order_item_id' => $f['item_main'],
                'rating'        => 5,
                'content'       => 'Content long enough for the review.',
                'images'        => $images,
            ]), '最多');
            return 'more than ' . ReviewService::MAX_IMAGES . ' images rejected';
        });

        $this->check($output, 'create.reject_invalid_video', function () use ($f): string {
            $this->expectBiz(fn () => $this->service->create($f['buyer'], [
                'order_item_id' => $f['item_main'],
                'rating'        => 5,
                'content'       => 'Content long enough for the review.',
                'videos'        => [self::INVALID_VIDEO],
            ]), '本站');
            return 'external video rejected';
        });

        $this->check($output, 'create.reject_too_many_videos', function () use ($f): string {
            $videos = [];
            for ($i = 0; $i < ReviewService::MAX_VIDEOS + 1; $i++) {
                $videos[] = '/uploads/reviews/videos/202601/' . md5('vid' . $i) . '.mp4';
            }
            $this->expectBiz(fn () => $this->service->create($f['buyer'], [
                'order_item_id' => $f['item_main'],
                'rating'        => 5,
                'content'       => 'Content long enough for the review.',
                'videos'        => $videos,
            ]), '最多');
            return 'more than ' . ReviewService::MAX_VIDEOS . ' videos rejected';
        });

        // 3. 创建 → 待审核
        $this->check($output, 'create.pending', function () use ($f): string {
            $result = $this->service->create($f['buyer'], [
                'order_item_id' => $f['item_main'],
                'rating'        => 5,
                'title'         => 'Excellent item',
                'content'       => 'This product works exactly as described. Very happy with it.',
            ]);
            $this->assertThat((int) $result['status'] === ReviewService::STATUS_PENDING, '默认应为待审核');

            $row = Db::name('product_review')->where('id', (int) $result['id'])->find();
            $this->assertThat((bool) $row, '评论未落库');
            $this->assertThat((int) $row['merchant_id'] === $f['merchant'], 'merchant_id 应从商品复制');
            $this->assertThat((int) $row['user_id'] === $f['buyer'], 'user_id 不匹配');
            $this->assertThat((int) $row['order_id'] === $f['order_main'], 'order_id 不匹配');
            $this->assertThat((int) $row['is_verified'] === 1, '已购标识应为 1');
            $this->assertThat((int) $row['status'] === ReviewService::STATUS_PENDING, 'DB 状态应为待审核');

            $this->state['review_main'] = (int) $result['id'];
            return 'id=' . $result['id'] . ' status=pending';
        });

        $this->check($output, 'create.duplicate_rejected', function () use ($f): string {
            $this->expectBiz(fn () => $this->service->create($f['buyer'], [
                'order_item_id' => $f['item_main'],
                'rating'        => 4,
                'content'       => 'Second review on the same order item.',
            ]), '已评价');
            return 'duplicate order item rejected';
        });

        $this->check($output, 'eligible.after_create', function () use ($f): string {
            $list = $this->service->eligible($f['product'], $f['buyer']);
            $ids  = array_column($list, 'order_item_id');
            $this->assertThat($ids === [$f['item_images']], '已评价的订单商品应从资格列表消失');
            return 'remaining=[' . implode(',', $ids) . ']';
        });

        // 4. 待审核不在前台出现
        $this->check($output, 'front.hidden_pending', function () use ($f): string {
            $summary = $this->service->summary($f['product']);
            $this->assertThat((int) $summary['count'] === 0, '待审核不应计入统计');
            $list = $this->service->listApproved($f['product'], [], 1, ReviewService::PAGE_SIZE);
            $this->assertThat((int) $list['total'] === 0, '待审核不应出现在列表');
            return 'summary.count=0 list.total=0';
        });

        // 4.1 可见性：作者本人能看到自己的待审核，他人 / 未登录看不到
        $this->check($output, 'visibility.owner_pending', function () use ($f): string {
            $data = $this->service->listApproved($f['product'], [], 1, ReviewService::PAGE_SIZE, $f['buyer']);
            $this->assertThat((int) $data['total'] === 1, '作者应看到自己的待审核评论 total=1，实际 ' . $data['total']);
            $this->assertThat((int) ($data['list'][0]['id'] ?? 0) === $this->state['review_main'], '作者看到的是错误的评论');

            // 「我的评价」同样包含待审核（status=0），不只是已通过
            $mine = $this->service->myReviews($f['buyer'], 1, 20);
            $mineIds = array_map(static fn (array $row): int => (int) $row['id'], $mine['list']);
            $this->assertThat(in_array($this->state['review_main'], $mineIds, true), '我的评价应包含作者自己的待审核评论');
            $this->assertThat((int) $mine['total'] === 1, '我的评价 total 应为 1（仅待审核），实际 ' . $mine['total']);

            return 'owner sees pending id=' . $this->state['review_main'] . ' mine.total=' . $mine['total'];
        });

        $this->check($output, 'visibility.other_hidden', function () use ($f): string {
            $data = $this->service->listApproved($f['product'], [], 1, ReviewService::PAGE_SIZE, $f['stranger']);
            $this->assertThat((int) $data['total'] === 0, '其他用户不应看到别人的待审核评论，实际 ' . $data['total']);
            return 'other viewer total=0';
        });

        $this->check($output, 'visibility.anonymous_hidden', function () use ($f): string {
            $data = $this->service->listApproved($f['product'], [], 1, 5, null);
            $this->assertThat((int) $data['total'] === 0, '未登录不应看到待审核评论，实际 ' . $data['total']);
            return 'anonymous viewer total=0';
        });

        $this->check($output, 'vote.reject_pending', function () use ($f): string {
            $this->expectBiz(fn () => $this->service->vote(
                $f['voter'],
                $this->state['review_main'],
                1
            ), '不可投票');
            return 'pending review not votable';
        });

        // 5. 审核通过后的统计与列表
        $this->check($output, 'admin.approve', function (): string {
            $affected = $this->service->adminUpdateStatus([$this->state['review_main']], ReviewService::STATUS_APPROVED);
            $this->assertThat($affected === 1, '受影响行数应为 1，实际 ' . $affected);
            return 'affected=1';
        });

        $this->check($output, 'summary.approved', function () use ($f): string {
            $summary = $this->service->summary($f['product']);
            $this->assertThat((int) $summary['count'] === 1, 'count 应为 1');
            $this->assertThat(abs((float) $summary['avg'] - 5.0) < 0.001, 'avg 应为 5.0，实际 ' . $summary['avg']);
            $this->assertThat((int) $summary['distribution'][5] === 1, '5 星分布应为 1');
            $this->assertThat((int) $summary['distribution'][4] === 0, '4 星分布应为 0');
            return 'count=1 avg=' . $summary['avg'];
        });

        $this->check($output, 'front.list_approved', function () use ($f): string {
            $data = $this->service->listApproved($f['product'], [], 1, ReviewService::PAGE_SIZE);
            $this->assertThat((int) $data['total'] === 1, 'total 应为 1');
            $item = $data['list'][0] ?? [];
            $this->assertThat(($item['title'] ?? '') === 'Excellent item', '标题不匹配');
            $this->assertThat((int) ($item['is_verified'] ?? 0) === 1, '已购标识应为 1');
            $this->assertThat((int) ($item['my_vote'] ?? -1) === 0, '未登录 my_vote 应为 0');
            // 作者名掩码：无昵称走邮箱整体掩码（不保留域名），dave@example.com → da***om
            $this->assertThat(($item['author'] ?? '') === 'da***om', '作者应掩码为 da***om，实际 ' . ($item['author'] ?? ''));
            $this->assertThat(strpos((string) ($item['author'] ?? ''), '@') === false, '作者名不得保留邮箱域名/原始邮箱');
            $this->assertThat(($item['videos'] ?? null) === [], '无视频评论应输出空数组 videos，实际 ' . json_encode($item['videos'] ?? 'ABSENT'));
            return 'author=' . $item['author'];
        });

        $this->check($output, 'front.size_clamp', function () use ($f): string {
            $data = $this->service->listApproved($f['product'], [], 1, 999);
            $this->assertThat((int) $data['size'] === ReviewService::MAX_PAGE_SIZE, 'size 应收敛到 20，实际 ' . $data['size']);
            return 'size=' . $data['size'];
        });

        // 6. 第二条评论：带图 + 带视频 + 匿名
        $this->check($output, 'create.with_image', function () use ($f): string {
            $result = $this->service->create($f['buyer'], [
                'order_item_id' => $f['item_images'],
                'rating'        => 4,
                'title'         => 'With image attached',
                'content'       => 'Adding a photo to show how it looks in real life.',
                'images'        => [self::VALID_IMAGE],
                'videos'        => [self::VALID_VIDEO],
                'is_anonymous'  => 1,
            ]);
            $this->state['review_image'] = (int) $result['id'];

            $row = Db::name('product_review')->where('id', (int) $result['id'])->find();
            $images = json_decode((string) ($row['images_json'] ?? '[]'), true);
            $videos = json_decode((string) ($row['videos_json'] ?? '[]'), true);
            $this->assertThat(is_array($images) && $images === [self::VALID_IMAGE], '图片未按入参保存');
            $this->assertThat(is_array($videos) && $videos === [self::VALID_VIDEO], '视频未按入参保存');
            $this->assertThat((int) $row['is_anonymous'] === 1, '匿名标识应为 1');
            return 'id=' . $result['id'] . ' images=1 videos=1';
        });

        // 6.1 待审核 + 媒体：作者 media=1 命中自己的待审核媒体；他人 / 未登录不命中；统计不变
        $this->check($output, 'visibility.media_pending', function () use ($f): string {
            $owned = $this->service->listApproved($f['product'], ['media' => 1], 1, ReviewService::PAGE_SIZE, $f['buyer']);
            $this->assertThat((int) $owned['total'] === 1, '作者 media=1 应命中自己的待审核媒体评论，实际 ' . $owned['total']);
            $this->assertThat((int) ($owned['list'][0]['id'] ?? 0) === $this->state['review_image'], 'media=1 命中了错误的评论');
            $this->assertThat(($owned['list'][0]['videos'] ?? []) === [self::VALID_VIDEO], '待审核评论应带出 videos');

            $others = $this->service->listApproved($f['product'], ['media' => 1], 1, ReviewService::PAGE_SIZE, $f['stranger']);
            $this->assertThat((int) $others['total'] === 0, '他人 media=1 不应命中别人的待审核媒体，实际 ' . $others['total']);

            $anon = $this->service->listApproved($f['product'], ['media' => 1], 1, ReviewService::PAGE_SIZE, null);
            $this->assertThat((int) $anon['total'] === 0, '未登录 media=1 不应命中待审核媒体，实际 ' . $anon['total']);
            return 'owner media=1 total=1, others/anon=0';
        });

        $this->check($output, 'summary.excludes_pending', function () use ($f): string {
            $summary = $this->service->summary($f['product']);
            $this->assertThat((int) $summary['count'] === 1, '存在待审核时统计仍应只算已通过 1 条，实际 ' . $summary['count']);
            $this->assertThat(abs((float) $summary['avg'] - 5.0) < 0.001, '统计均分只算已通过，应为 5.0，实际 ' . $summary['avg']);
            $owner = $this->service->listApproved($f['product'], [], 1, ReviewService::PAGE_SIZE, $f['buyer']);
            $this->assertThat((int) $owner['total'] === 2, '作者视角列表应含 1 条待审核共 2 条，实际 ' . $owner['total']);
            return 'summary.count=1 owner.total=2';
        });

        $this->check($output, 'admin.approve_second', function (): string {
            $affected = $this->service->adminUpdateStatus([$this->state['review_image']], ReviewService::STATUS_APPROVED);
            $this->assertThat($affected === 1, '受影响行数应为 1');
            return 'affected=1';
        });

        $this->check($output, 'summary.two_reviews', function () use ($f): string {
            $summary = $this->service->summary($f['product']);
            $this->assertThat((int) $summary['count'] === 2, 'count 应为 2');
            $this->assertThat(abs((float) $summary['avg'] - 4.5) < 0.001, 'avg 应为 4.5，实际 ' . $summary['avg']);
            $this->assertThat((int) $summary['distribution'][5] === 1 && (int) $summary['distribution'][4] === 1, '星级分布应为 5:1 / 4:1');
            return 'count=2 avg=' . $summary['avg'];
        });

        $this->check($output, 'front.media_filter', function () use ($f): string {
            $data = $this->service->listApproved($f['product'], ['media' => 1], 1, ReviewService::PAGE_SIZE);
            $this->assertThat((int) $data['total'] === 1, '带图筛选应只剩 1 条');
            $this->assertThat((int) ($data['list'][0]['id'] ?? 0) === $this->state['review_image'], '带图筛选命中了错误评论');
            return 'total=1';
        });

        $this->check($output, 'front.rating_filter', function () use ($f): string {
            $data = $this->service->listApproved($f['product'], ['rating' => 4], 1, ReviewService::PAGE_SIZE);
            $this->assertThat((int) $data['total'] === 1, '4 星筛选应只剩 1 条');
            $data = $this->service->listApproved($f['product'], ['rating' => 5], 1, ReviewService::PAGE_SIZE);
            $this->assertThat((int) $data['total'] === 1, '5 星筛选应只剩 1 条');
            return 'rating filter ok';
        });

        $this->check($output, 'front.keyword_filter', function () use ($f): string {
            $data = $this->service->listApproved($f['product'], ['keyword' => 'image attached'], 1, ReviewService::PAGE_SIZE);
            $this->assertThat((int) $data['total'] === 1, '关键词筛选应只剩 1 条');
            $data = $this->service->listApproved($f['product'], ['keyword' => '%'], 1, ReviewService::PAGE_SIZE);
            $this->assertThat((int) $data['total'] === 0, 'LIKE 通配符应被转义');
            return 'keyword filter ok';
        });

        $this->check($output, 'front.anonymous', function () use ($f): string {
            $data = $this->service->listApproved($f['product'], [], 1, ReviewService::PAGE_SIZE);
            $anonymous = null;
            foreach ($data['list'] as $item) {
                if ((int) $item['id'] === $this->state['review_image']) {
                    $anonymous = $item;
                }
            }
            $this->assertThat($anonymous !== null, '未找到匿名评论');
            $this->assertThat($anonymous['author'] === 'Anonymous', '匿名作者应显示 Anonymous，实际 ' . $anonymous['author']);
            $this->assertThat($anonymous['avatar'] === '', '匿名评论不应返回头像');
            $this->assertThat(($anonymous['videos'] ?? []) === [self::VALID_VIDEO], '条目应输出 videos 字段，实际 ' . json_encode($anonymous['videos'] ?? 'ABSENT'));
            return 'author=Anonymous';
        });

        $this->check($output, 'front.pagination', function () use ($f): string {
            $page1 = $this->service->listApproved($f['product'], [], 1, 1);
            $this->assertThat(count($page1['list']) === 1, '第 1 页应返回 1 条');
            $this->assertThat($page1['hasMore'] === true, '第 1 页 hasMore 应为 true');
            $page2 = $this->service->listApproved($f['product'], [], 2, 1);
            $this->assertThat($page2['hasMore'] === false, '第 2 页 hasMore 应为 false');
            $this->assertThat((int) $page1['list'][0]['id'] !== (int) $page2['list'][0]['id'], '两页不应返回同一条');
            return 'page1.hasMore=1 page2.hasMore=0';
        });

        // 7. 状态切换：隐藏 / 拒绝后前台不可见
        $this->check($output, 'status.hidden', function () use ($f): string {
            $this->service->adminUpdateStatus([$this->state['review_image']], ReviewService::STATUS_HIDDEN);
            $data = $this->service->listApproved($f['product'], [], 1, ReviewService::PAGE_SIZE);
            $this->assertThat((int) $data['total'] === 1, '隐藏后列表应只剩 1 条');
            $this->assertThat((int) $this->service->summary($f['product'])['count'] === 1, '隐藏后统计应为 1');
            return 'hidden filtered';
        });

        $this->check($output, 'status.rejected', function () use ($f): string {
            $this->service->adminUpdateStatus([$this->state['review_image']], ReviewService::STATUS_REJECTED);
            $data = $this->service->listApproved($f['product'], [], 1, ReviewService::PAGE_SIZE);
            $this->assertThat((int) $data['total'] === 1, '拒绝后列表应只剩 1 条');
            return 'rejected filtered';
        });

        // 7.1 我的评价：拒绝 / 隐藏永不出现在前台列表（仅 status in 0,1）
        $this->check($output, 'mine.excludes_rejected', function () use ($f): string {
            $mine = $this->service->myReviews($f['buyer'], 1, 20);
            $ids  = array_map(static fn (array $row): int => (int) $row['id'], $mine['list']);
            $this->assertThat(!in_array($this->state['review_image'], $ids, true), '已拒绝的评论不应出现在我的评价');
            $this->assertThat(in_array($this->state['review_main'], $ids, true), '已通过的评论应出现在我的评价');

            // 隐藏状态同样排除
            $this->service->adminUpdateStatus([$this->state['review_image']], ReviewService::STATUS_HIDDEN);
            $hidden = $this->service->myReviews($f['buyer'], 1, 20);
            $hiddenIds = array_map(static fn (array $row): int => (int) $row['id'], $hidden['list']);
            $this->assertThat(!in_array($this->state['review_image'], $hiddenIds, true), '已隐藏的评论不应出现在我的评价');

            // 还原为已拒绝，交给后续 status.restored 恢复为已通过
            $this->service->adminUpdateStatus([$this->state['review_image']], ReviewService::STATUS_REJECTED);
            return 'mine.total=' . $mine['total'] . ' rejected/hidden excluded';
        });

        $this->check($output, 'status.restored', function () use ($f): string {
            $this->service->adminUpdateStatus([$this->state['review_image']], ReviewService::STATUS_APPROVED);
            $data = $this->service->listApproved($f['product'], [], 1, ReviewService::PAGE_SIZE);
            $this->assertThat((int) $data['total'] === 2, '恢复通过后列表应为 2 条');
            return 'restored visible';
        });

        // 8. 投票：新增 / 取消 / 切换 / 计数不为负
        $this->check($output, 'vote.add', function () use ($f): string {
            $result = $this->service->vote($f['voter'], $this->state['review_main'], 1);
            $this->assertThat((int) $result['vote'] === 1, '返回值 vote 应为 1');
            $this->assertThat((int) $result['helpful_yes'] === 1, 'helpful_yes 应为 1');
            $this->assertThat((int) $result['helpful_no'] === 0, 'helpful_no 应为 0');
            $this->assertThat(Db::name('product_review_vote')->where('review_id', $this->state['review_main'])->count() === 1, '投票记录应为 1 条');
            return 'yes=1 no=0';
        });

        $this->check($output, 'vote.toggle_off', function () use ($f): string {
            $result = $this->service->vote($f['voter'], $this->state['review_main'], 1);
            $this->assertThat((int) $result['vote'] === 0, '重复点击应取消投票');
            $this->assertThat((int) $result['helpful_yes'] === 0, '取消后 helpful_yes 应为 0');
            $this->assertThat(Db::name('product_review_vote')->where('review_id', $this->state['review_main'])->count() === 0, '取消后投票记录应为 0');
            return 'cancelled';
        });

        $this->check($output, 'vote.switch', function () use ($f): string {
            $this->service->vote($f['voter'], $this->state['review_main'], 1);
            $result = $this->service->vote($f['voter'], $this->state['review_main'], 2);
            $this->assertThat((int) $result['vote'] === 2, '切换后 vote 应为 2');
            $this->assertThat((int) $result['helpful_yes'] === 0, '切换后 helpful_yes 应为 0');
            $this->assertThat((int) $result['helpful_no'] === 1, '切换后 helpful_no 应为 1');
            $vote = Db::name('product_review_vote')->where('review_id', $this->state['review_main'])->value('vote');
            $this->assertThat((int) $vote === 2, '投票表应只剩一条 vote=2');
            return 'yes=0 no=1';
        });

        $this->check($output, 'vote.my_vote', function () use ($f): string {
            $data = $this->service->listApproved($f['product'], [], 1, ReviewService::PAGE_SIZE, $f['voter']);
            $mine = null;
            foreach ($data['list'] as $item) {
                if ((int) $item['id'] === $this->state['review_main']) {
                    $mine = $item;
                }
            }
            $this->assertThat($mine !== null && (int) $mine['my_vote'] === 2, '登录用户应看到 my_vote=2');
            return 'my_vote=2';
        });

        $this->check($output, 'vote.no_negative', function () use ($f): string {
            $reviewId = $this->state['review_image'];
            // 模拟脏数据：计数已是 0，但投票表里还有一条「有用」
            Db::name('product_review')->where('id', $reviewId)->update(['helpful_yes' => 0, 'helpful_no' => 0]);
            Db::name('product_review_vote')->insert([
                'review_id'   => $reviewId,
                'user_id'     => $f['voter'],
                'vote'        => 1,
                'create_time' => date('Y-m-d H:i:s'),
            ]);

            $result = $this->service->vote($f['voter'], $reviewId, 1);
            $this->assertThat((int) $result['helpful_yes'] === 0, '计数不得为负，实际 ' . $result['helpful_yes']);
            $row = Db::name('product_review')->where('id', $reviewId)->find();
            $this->assertThat((int) $row['helpful_yes'] >= 0, 'DB 计数出现负数');
            return 'helpful_yes clamped to 0';
        });

        // 9. 后台回复
        $this->check($output, 'admin.reply', function () use ($f): string {
            AppContext::setAdminRole(AdminRole::SUPER);
            $detail = $this->service->adminReply($this->state['review_main'], 'Thanks for your feedback.');
            $this->assertThat(($detail['admin_reply'] ?? '') === 'Thanks for your feedback.', '后台回复未保存');
            $this->assertThat(($detail['replied_at'] ?? '') !== '', '回复时间未写入');

            $data = $this->service->listApproved($f['product'], [], 1, ReviewService::PAGE_SIZE);
            $found = '';
            foreach ($data['list'] as $item) {
                if ((int) $item['id'] === $this->state['review_main']) {
                    $found = (string) $item['admin_reply'];
                }
            }
            $this->assertThat($found === 'Thanks for your feedback.', '前台未显示后台回复');
            return 'reply visible';
        });

        $this->check($output, 'admin.reply_empty', function (): string {
            $this->expectBiz(fn () => $this->service->adminReply($this->state['review_main'], '   '), '回复');
            return 'empty reply rejected';
        });

        // 10. 商户数据范围（另一商户的评论只对超管可见）
        $this->check($output, 'scope.create_foreign', function () use ($f): string {
            AppContext::clear();
            $result = $this->service->create($f['buyer'], [
                'order_item_id' => $f['item_scope'],
                'rating'        => 3,
                'content'       => 'Bought from another merchant, average quality.',
            ]);
            $this->state['review_scope'] = (int) $result['id'];
            $this->assertThat((int) $result['status'] === ReviewService::STATUS_PENDING, '另一商户评论也应为待审核');
            return 'id=' . $result['id'];
        });

        $this->check($output, 'scope.super_list', function () use ($f): string {
            AppContext::setAdminRole(AdminRole::SUPER);
            $this->service->adminUpdateStatus([$this->state['review_scope']], ReviewService::STATUS_APPROVED);

            // 断言按商品过滤的结果而非全库总数：自测命令可能在已有评论的库上执行
            $own = $this->service->adminList(['product_id' => $f['product']], 1, 50);
            $this->assertThat((int) $own['total'] === 2, '超管按本店商品应看到 2 条评论，实际 ' . $own['total']);
            $this->assertThat((int) $own['page_size'] === 50, 'page_size 应回传请求值，实际 ' . $own['page_size']);

            $other = $this->service->adminList(['product_id' => $f['other_product']], 1, 50);
            $this->assertThat((int) $other['total'] === 1, '超管应能看到他店商品 1 条评论，实际 ' . $other['total']);

            $first = $own['list'][0];
            $this->assertThat(isset($first['product_title'], $first['order_no'], $first['status_label']), '后台列表缺少展示字段');
            return 'own=2 other=1';
        });

        $this->check($output, 'scope.merchant_admin_list', function () use ($f): string {
            AppContext::setAdminRole(AdminRole::MERCHANT_ADMIN);
            AppContext::setMerchantIds([$f['merchant']]);
            $data = $this->service->adminList(['product_id' => $f['product']], 1, 50);
            $this->assertThat((int) $data['total'] === 2, '商户管理员应只看到本店 2 条，实际 ' . $data['total']);
            $productIds = array_column($data['list'], 'product_id');
            $this->assertThat(!in_array($f['other_product'], $productIds, true), '列表包含了他店商品评论');

            $foreign = $this->service->adminList(['product_id' => $f['other_product']], 1, 50);
            $this->assertThat((int) $foreign['total'] === 0, '商户管理员不应看到他店商品评论，实际 ' . $foreign['total']);
            return 'total=2 foreign=0';
        });

        // 10.1 后台列表筛选：状态 / 星级 / 关键词 / 时间范围（超管 + 本店商品口径）
        $this->check($output, 'admin.filters', function () use ($f): string {
            AppContext::setAdminRole(AdminRole::SUPER);
            $scope = ['product_id' => $f['product']];

            $approved = $this->service->adminList($scope + ['status' => ReviewService::STATUS_APPROVED], 1, 50);
            $this->assertThat((int) $approved['total'] === 2, 'status=1 应命中 2 条，实际 ' . $approved['total']);
            $pending = $this->service->adminList($scope + ['status' => ReviewService::STATUS_PENDING], 1, 50);
            $this->assertThat((int) $pending['total'] === 0, 'status=0 应命中 0 条，实际 ' . $pending['total']);

            $rated = $this->service->adminList($scope + ['rating' => 5], 1, 50);
            $this->assertThat((int) $rated['total'] === 1, 'rating=5 应命中 1 条，实际 ' . $rated['total']);

            $keywordTitle = $this->service->adminList($scope + ['keyword' => 'Excellent item'], 1, 50);
            $this->assertThat((int) $keywordTitle['total'] === 1, '标题关键词应命中 1 条，实际 ' . $keywordTitle['total']);
            // 关键词要能命中「作者邮箱」：命中同一作者的 2 条评论（验证联表反查口径）
            $keywordAuthor = $this->service->adminList($scope + ['keyword' => 'dave@example.com'], 1, 50);
            $this->assertThat((int) $keywordAuthor['total'] === 2, '作者邮箱关键词应命中 2 条，实际 ' . $keywordAuthor['total']);
            $keywordWildcard = $this->service->adminList($scope + ['keyword' => '%'], 1, 50);
            $this->assertThat((int) $keywordWildcard['total'] === 0, 'LIKE 通配符应被转义，实际 ' . $keywordWildcard['total']);

            $inRange = $this->service->adminList($scope + ['start_date' => '2000-01-01', 'end_date' => date('Y-m-d')], 1, 50);
            $this->assertThat((int) $inRange['total'] === 2, '时间范围内应命中 2 条，实际 ' . $inRange['total']);
            $future = $this->service->adminList($scope + ['start_date' => date('Y-m-d', strtotime('+1 day'))], 1, 50);
            $this->assertThat((int) $future['total'] === 0, '未来时间范围应命中 0 条，实际 ' . $future['total']);

            // 恢复商户上下文，后续 scope.merchant_admin_write 仍按「商户管理员」断言
            AppContext::setAdminRole(AdminRole::MERCHANT_ADMIN);
            AppContext::setMerchantIds([$f['merchant']]);
            return 'status/rating/keyword/date ok';
        });

        $this->check($output, 'scope.merchant_admin_write', function (): string {
            $this->expectBiz(fn () => $this->service->adminUpdateStatus(
                [$this->state['review_scope']],
                ReviewService::STATUS_HIDDEN
            ), '无权');
            $this->expectBiz(fn () => $this->service->adminDelete([$this->state['review_scope']]), '无权');
            return 'foreign write rejected';
        });

        $this->check($output, 'summary.other_product', function () use ($f): string {
            AppContext::clear();
            $summary = $this->service->summary($f['other_product']);
            $this->assertThat((int) $summary['count'] === 1, '另一商品统计应为 1');
            $this->assertThat(abs((float) $summary['avg'] - 3.0) < 0.001, '另一商品 avg 应为 3.0');
            return 'count=1 avg=3.0';
        });

        // 11. 删除（硬删除 + 投票级联）
        $this->check($output, 'admin.delete', function () use ($f): string {
            AppContext::setAdminRole(AdminRole::SUPER);
            $reviewId = $this->state['review_image'];
            Db::name('product_review_vote')->insert([
                'review_id'   => $reviewId,
                'user_id'     => $f['stranger'],
                'vote'        => 2,
                'create_time' => date('Y-m-d H:i:s'),
            ]);

            $deleted = $this->service->adminDelete([$reviewId]);
            $this->assertThat($deleted === 1, '删除条数应为 1，实际 ' . $deleted);
            $this->assertThat(Db::name('product_review')->where('id', $reviewId)->find() === null, '评论行未被硬删除');
            $this->assertThat(Db::name('product_review_vote')->where('review_id', $reviewId)->count() === 0, '投票未级联删除');

            $data = $this->service->listApproved($f['product'], [], 1, ReviewService::PAGE_SIZE);
            $this->assertThat((int) $data['total'] === 1, '删除后前台应只剩 1 条');
            return 'deleted=1 votes=0';
        });

        $this->check($output, 'admin.detail_missing', function (): string {
            $this->expectBiz(fn () => $this->service->adminDetail($this->state['review_image']), '不存在');
            return 'missing detail rejected';
        });

        // 12. 读取时过滤非本站图片（历史脏数据）
        $this->check($output, 'front.image_whitelist', function () use ($f): string {
            AppContext::clear();
            Db::name('product_review')->insert([
                'product_id'    => $f['product'],
                'merchant_id'   => $f['merchant'],
                'user_id'       => $f['buyer'],
                'order_id'      => $f['order_images'],
                'order_item_id' => $f['item_images'],
                'rating'        => 3,
                'title'         => 'Legacy dirty image',
                'content'       => 'This row stores an external image address on purpose.',
                'images_json'   => json_encode([self::INVALID_IMAGE, self::VALID_IMAGE]),
                'is_anonymous'  => 0,
                'is_verified'   => 1,
                'status'        => ReviewService::STATUS_APPROVED,
                'helpful_yes'   => 0,
                'helpful_no'    => 0,
                'create_time'   => date('Y-m-d H:i:s'),
                'update_time'   => date('Y-m-d H:i:s'),
            ]);

            $data = $this->service->listApproved($f['product'], ['media' => 1], 1, ReviewService::PAGE_SIZE);
            $this->assertThat((int) $data['total'] === 1, '带图筛选应命中 1 条脏数据行');
            $images = $data['list'][0]['images'];
            $this->assertThat($images === [self::VALID_IMAGE], '非本站图片应被过滤，实际 ' . json_encode($images));
            return 'images=[' . implode(',', $images) . ']';
        });

        // 12.1 读取时过滤非本站视频 + media=1 的「有图或有视频」语义
        $this->check($output, 'front.video_whitelist', function () use ($f): string {
            AppContext::clear();
            $legacyId = (int) Db::name('product_review')->insertGetId([
                'product_id'    => $f['product'],
                'merchant_id'   => $f['merchant'],
                'user_id'       => $f['buyer'],
                'order_id'      => $f['order_images'],
                'order_item_id' => $f['item_shipping'],
                'rating'        => 3,
                'title'         => 'Legacy dirty video',
                'content'       => 'This row stores an external video address on purpose.',
                'images_json'   => json_encode([]),
                'videos_json'   => json_encode([self::INVALID_VIDEO, self::VALID_VIDEO]),
                'is_anonymous'  => 0,
                'is_verified'   => 1,
                'status'        => ReviewService::STATUS_APPROVED,
                'helpful_yes'   => 0,
                'helpful_no'    => 0,
                'create_time'   => date('Y-m-d H:i:s'),
                'update_time'   => date('Y-m-d H:i:s'),
            ]);

            // 有视频、无图片的评论也必须被 media=1 命中（旧实现在此漏掉）
            $data = $this->service->listApproved($f['product'], ['media' => 1], 1, ReviewService::PAGE_SIZE);
            $this->assertThat((int) $data['total'] === 2, 'media=1 应命中脏图片行 + 脏视频行共 2 条，实际 ' . $data['total']);

            $videoRow = null;
            foreach ($data['list'] as $item) {
                if ((int) $item['id'] === $legacyId) {
                    $videoRow = $item;
                }
            }
            $this->assertThat($videoRow !== null, 'media=1 未命中仅有视频的评论');
            $this->assertThat(($videoRow['videos'] ?? []) === [self::VALID_VIDEO], '非本站视频应被过滤，实际 ' . json_encode($videoRow['videos'] ?? 'ABSENT'));
            $this->assertThat(($videoRow['images'] ?? null) === [], '无图片时应输出空数组 images');
            return 'videos=[' . implode(',', $videoRow['videos']) . ']';
        });

        // 12.2 作者名掩码：昵称优先、邮箱整体掩码、短名分级、匿名仍 Anonymous
        $this->check($output, 'front.author_mask', function () use ($f): string {
            AppContext::clear();

            // 昵称优先于邮箱：voter 的 nickname=Voter（5 位）→ Vo***er，而非邮箱掩码 vo***om
            $rowId = $this->insert('product_review', [
                'product_id'    => $f['product'],
                'merchant_id'   => $f['merchant'],
                'user_id'       => $f['voter'],
                'order_id'      => $f['order_nick'],
                'order_item_id' => $f['item_nick'],
                'rating'        => 4,
                'title'         => 'Nickname masking',
                'content'       => 'This row verifies the nickname masking branch.',
                'images_json'   => json_encode([]),
                'is_anonymous'  => 0,
                'is_verified'   => 1,
                'status'        => ReviewService::STATUS_APPROVED,
                'helpful_yes'   => 0,
                'helpful_no'    => 0,
                'create_time'   => date('Y-m-d H:i:s'),
                'update_time'   => date('Y-m-d H:i:s'),
            ]);

            $data = $this->service->listApproved($f['product'], [], 1, ReviewService::MAX_PAGE_SIZE);
            $nickRow = null;
            foreach ($data['list'] as $item) {
                if ((int) $item['id'] === $rowId) {
                    $nickRow = $item;
                }
            }
            $this->assertThat($nickRow !== null, '未找到刚插入的昵称评论');
            $this->assertThat($nickRow['author'] === 'Vo***er', '昵称应掩码为 Vo***er（昵称优先于邮箱），实际 ' . $nickRow['author']);

            // 删除后不影响后续断言
            Db::name('product_review')->where('id', $rowId)->delete();

            // 唯一实现的分级分支（反射直调，避免为 3/4/≤2 位昵称各造一条评论）
            $maskMethod = new \ReflectionMethod(ReviewService::class, 'maskVisibleName');
            $maskMethod->setAccessible(true);
            $mask = static fn (string $value): string => (string) $maskMethod->invoke(new ReviewService(), $value);
            $this->assertThat($mask('Johnny') === 'Jo***ny', '长度>=5 应保留首2+末2，实际 ' . $mask('Johnny'));
            $this->assertThat($mask('Dave') === 'D***e', '长度 4 应保留首1+末1，实际 ' . $mask('Dave'));
            $this->assertThat($mask('Jo') === '***', '长度 2 应整体掩码，实际 ' . $mask('Jo'));
            $this->assertThat($mask('') === 'Customer', '空名应回退 Customer，实际 ' . $mask(''));
            $this->assertThat($mask('dave@example.com') === 'da***om', '邮箱应整体掩码为 da***om，实际 ' . $mask('dave@example.com'));
            $this->assertThat(strpos($mask('dave@example.com'), '@') === false, '邮箱掩码不得保留域名');

            $nameMethod = new \ReflectionMethod(ReviewService::class, 'displayName');
            $nameMethod->setAccessible(true);
            $display = static fn (array $user): string => (string) $nameMethod->invoke(new ReviewService(), $user);
            $this->assertThat($display(['nickname' => 'Dave', 'email' => 'dave@example.com']) === 'D***e', '有昵称时应走昵称掩码');
            $this->assertThat($display(['nickname' => '', 'email' => 'dave@example.com']) === 'da***om', '无昵称时应走邮箱掩码');
            $this->assertThat($display(['nickname' => '', 'email' => '']) === 'Customer', '无昵称无邮箱应回退 Customer');
            return 'author=Vo***er mask branches ok';
        });
    }

    // ------------------------------------------------------------------
    // 固定数据
    // ------------------------------------------------------------------

    private function seedFixtures(): void
    {
        $now = date('Y-m-d H:i:s');
        $tag = bin2hex(random_bytes(4));

        $merchant = $this->insert('merchant', [
            'name'        => '__review_selftest_' . $tag,
            'status'      => 1,
            'create_time' => $now,
            'update_time' => $now,
        ]);
        $otherMerchant = $this->insert('merchant', [
            'name'        => '__review_selftest_other_' . $tag,
            'status'      => 1,
            'create_time' => $now,
            'update_time' => $now,
        ]);
        $category = $this->insert('category', [
            'parent_id' => 0,
            'name'      => '__review_selftest_' . $tag,
            'sort'      => 0,
        ]);

        $product = $this->insert('product', [
            'merchant_id' => $merchant,
            'category_id' => $category,
            'title'       => '__review_selftest_product_' . $tag,
            'main_image'  => '/uploads/products/images/202601/selftest.jpg',
            'images_json' => json_encode([]),
            'status'      => 1,
            'sort'        => 0,
            'create_time' => $now,
            'update_time' => $now,
        ]);
        $otherProduct = $this->insert('product', [
            'merchant_id' => $otherMerchant,
            'category_id' => $category,
            'title'       => '__review_selftest_other_product_' . $tag,
            'main_image'  => '/uploads/products/images/202601/selftest-other.jpg',
            'images_json' => json_encode([]),
            'status'      => 1,
            'sort'        => 0,
            'create_time' => $now,
            'update_time' => $now,
        ]);
        $sku = $this->insert('product_sku', [
            'product_id'       => $product,
            'spec_name'        => 'Default',
            'spec_values_json' => json_encode(['Size' => 'M']),
            'price'            => '19.90',
            'stock'            => 100,
            'status'           => 1,
        ]);

        $buyer = $this->insert('user', [
            'openid'      => 'sft_buyer_' . $tag,
            'email'       => 'dave@example.com',
            'nickname'    => '',
            'avatar'      => '',
            'create_time' => $now,
            'update_time' => $now,
        ]);
        $voter = $this->insert('user', [
            'openid'      => 'sft_voter_' . $tag,
            'email'       => 'voter@example.com',
            'nickname'    => 'Voter',
            'avatar'      => '/uploads/avatars/202601/voter.jpg',
            'create_time' => $now,
            'update_time' => $now,
        ]);
        $stranger = $this->insert('user', [
            'openid'      => 'sft_stranger_' . $tag,
            'email'       => 'stranger@example.com',
            'nickname'    => '',
            'avatar'      => '',
            'create_time' => $now,
            'update_time' => $now,
        ]);

        $pay = $this->insert('order_pay', [
            'user_id'         => $buyer,
            'total_amount'    => '19.90',
            'discount_amount' => 0,
            'pay_method'      => 'wechat_jsapi',
            'channel'         => 'wechat',
            'pay_status'      => 1,
            'charge_currency' => 'USD',
            'create_time'     => $now,
        ]);

        $main = $this->createOrderItem($buyer, $pay, $merchant, $product, $sku, OrderStatus::DELIVERED, 'main' . $tag, $now);
        $images = $this->createOrderItem($buyer, $pay, $merchant, $product, $sku, OrderStatus::DELIVERED, 'img' . $tag, $now);
        $shipping = $this->createOrderItem($buyer, $pay, $merchant, $product, $sku, OrderStatus::SHIPPING, 'ship' . $tag, $now);
        $cancelled = $this->createOrderItem($buyer, $pay, $merchant, $product, $sku, OrderStatus::CANCELLED, 'cancel' . $tag, $now);
        $scope = $this->createOrderItem($buyer, $pay, $otherMerchant, $otherProduct, $sku, OrderStatus::DELIVERED, 'scope' . $tag, $now);
        // 仅用于「作者名掩码」校验：voter 有昵称（nickname 优先于 email），独立订单商品避免与其它用例抢 uk_order_item
        $voterPay = $this->insert('order_pay', [
            'user_id'         => $voter,
            'total_amount'    => '19.90',
            'discount_amount' => 0,
            'pay_method'      => 'wechat_jsapi',
            'channel'         => 'wechat',
            'pay_status'      => 1,
            'charge_currency' => 'USD',
            'create_time'     => $now,
        ]);
        $nick = $this->createOrderItem($voter, $voterPay, $merchant, $product, $sku, OrderStatus::DELIVERED, 'nick' . $tag, $now);

        $this->fixture = [
            'merchant'       => $merchant,
            'other_merchant' => $otherMerchant,
            'product'        => $product,
            'other_product'  => $otherProduct,
            'buyer'          => $buyer,
            'voter'          => $voter,
            'stranger'       => $stranger,
            'order_main'     => $main['order_id'],
            'order_images'   => $images['order_id'],
            'item_main'      => $main['item_id'],
            'item_images'    => $images['item_id'],
            'item_shipping'  => $shipping['item_id'],
            'item_cancelled' => $cancelled['item_id'],
            'item_scope'     => $scope['item_id'],
            'order_nick'     => $nick['order_id'],
            'item_nick'      => $nick['item_id'],
        ];
    }

    /**
     * 建一条订单 + 订单商品行
     *
     * @return array{order_id:int,item_id:int}
     */
    private function createOrderItem(
        int $userId,
        int $payId,
        int $merchantId,
        int $productId,
        int $skuId,
        int $status,
        string $suffix,
        string $now
    ): array {
        $orderId = $this->insert('order', [
            'order_no'              => 'SFT' . date('His') . strtoupper(substr($suffix, 0, 8)) . random_int(100, 999),
            'pay_id'                => $payId,
            'user_id'               => $userId,
            'merchant_id'           => $merchantId,
            'status'                => $status,
            'total_amount'          => '19.90',
            'discount_amount'       => 0,
            'item_count'            => 1,
            'settle_status'         => 0,
            'charge_currency'       => 'USD',
            'display_currency'      => 'USD',
            'display_rate'          => 1,
            'display_total_amount'  => '19.90',
            'create_time'           => $now,
            'update_time'           => $now,
        ]);

        $itemId = $this->insert('order_item', [
            'order_id'          => $orderId,
            'sku_id'            => $skuId,
            'product_id'        => $productId,
            'sku_snapshot_json' => json_encode([
                'title'      => '__review_selftest_product',
                'spec_name'  => 'Default',
                'main_image' => '/uploads/products/images/202601/selftest.jpg',
                'price'      => '19.90',
            ]),
            'quantity'          => 1,
            'unit_price'        => '19.90',
            'total_price'       => '19.90',
        ]);

        return ['order_id' => $orderId, 'item_id' => $itemId];
    }

    private function insert(string $table, array $data): int
    {
        return (int) Db::name($table)->insertGetId($data);
    }

    // ------------------------------------------------------------------
    // 断言辅助
    // ------------------------------------------------------------------

    private function check(Output $output, string $key, callable $fn): void
    {
        try {
            $detail = (string) $fn();
            $this->results[$key] = true;
            $output->writeln('<info>PASS</info> ' . $key . ': ' . $detail);
        } catch (\Throwable $e) {
            $this->results[$key] = false;
            $output->writeln('<error>FAIL</error> ' . $key . ': ' . $e->getMessage());
        }
    }

    private function assertThat(bool $condition, string $message): void
    {
        if (!$condition) {
            throw new \RuntimeException($message);
        }
    }

    private function expectBiz(callable $fn, string $needle): void
    {
        try {
            $fn();
        } catch (BizException $e) {
            if ($needle !== '' && !str_contains($e->getMessage(), $needle)) {
                throw new \RuntimeException('错误文案不含「' . $needle . '」：' . $e->getMessage());
            }
            return;
        }

        throw new \RuntimeException('预期抛出业务错误，但调用成功了');
    }
}
