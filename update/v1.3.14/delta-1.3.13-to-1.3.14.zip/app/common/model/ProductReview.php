<?php
declare(strict_types=1);

namespace app\common\model;

use think\model\concern\SoftDelete;

/**
 * 商品评论模型
 *
 * 带 merchant_id（商品归属快照）故继承 MerchantModel：后台非超管读写自动按商户收敛；
 * 前台 AppContext 未设置管理员角色，scope 不生效，读路径显式限定可见集合
 * （`status=1`，登录作者额外可见自己的 `status=0`，见 ReviewService::listApproved）。
 *
 * 状态：0 待审核 / 1 已通过 / 2 已拒绝 / 3 已隐藏；
 * 后台「删除」为硬删除（连带投票），避免软删除行占用 uk_order_item。
 */
class ProductReview extends MerchantModel
{
    use SoftDelete;

    protected $name = 'product_review';
    protected $autoWriteTimestamp = 'datetime';
    protected $deleteTime = 'delete_time';
    protected $json = ['images_json', 'videos_json'];

    /**
     * 评论用户
     *
     * @return \think\model\relation\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * 评论商品
     *
     * @return \think\model\relation\BelongsTo
     */
    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    /**
     * 有用/无用投票记录
     *
     * @return \think\model\relation\HasMany
     */
    public function votes()
    {
        return $this->hasMany(ProductReviewVote::class, 'review_id');
    }
}
