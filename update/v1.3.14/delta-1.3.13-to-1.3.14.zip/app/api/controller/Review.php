<?php
declare(strict_types=1);

namespace app\api\controller;

use app\BaseController;
use app\common\exception\BizException;
use app\common\lib\SiteAuth;
use app\common\service\MediaUploadService;
use app\common\service\ReviewService;
use app\common\support\AppContext;

/**
 * 商品评论前台接口
 *
 * 公开（RateLimit）：list / summary —— list 可选解析 Bearer token：既用于返回 my_vote，
 * 也用于放宽可见集合（登录作者可见自己 status=0 的待审核评论）；
 * 登录（UserAuth + RateLimit）：eligible / create / upload / helpful。
 * 校验与事务全部在 ReviewService，控制器只做参数整形与响应封装。
 */
class Review extends BaseController
{
    /**
     * 评论列表（已通过 + 登录作者自己的待审核）
     *
     * 可见集合、total / hasMore 与筛选叠加以 ReviewService::listApproved() 为准；
     * 拒绝 / 隐藏的评论在任何登录态下都不返回。
     *
     * @return \think\Response
     */
    public function list()
    {
        try {
            $productId = (int) $this->request->get('product_id', 0);
            if ($productId <= 0) {
                return $this->error(40001, '参数错误');
            }

            $filters = [
                'rating'  => (int) $this->request->get('rating', 0),
                'media'   => (int) $this->request->get('media', 0),
                'keyword' => trim((string) $this->request->get('keyword', '')),
            ];
            $page = max(1, (int) $this->request->get('page', 1));
            $size = (int) $this->request->get('size', ReviewService::PAGE_SIZE);

            $data = (new ReviewService())->listApproved(
                $productId,
                $filters,
                $page,
                $size,
                $this->optionalViewerId()
            );

            return $this->success($data);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    /**
     * 评论统计
     *
     * @return \think\Response
     */
    public function summary()
    {
        $productId = (int) $this->request->get('product_id', 0);
        if ($productId <= 0) {
            return $this->error(40001, '参数错误');
        }

        return $this->success((new ReviewService())->summary($productId));
    }

    /**
     * 当前用户可评价的订单商品
     *
     * @return \think\Response
     */
    public function eligible()
    {
        if (!$this->requireReviewUser()) {
            return $this->unauthorized();
        }

        try {
            $productId = (int) $this->request->get('product_id', 0);
            if ($productId <= 0) {
                return $this->error(40001, '参数错误');
            }

            $list = (new ReviewService())->eligible($productId, (int) AppContext::getUserId());

            return $this->success(['list' => $list]);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    /**
     * 我的评价（账户中心）
     *
     * @return \think\Response
     */
    public function mine()
    {
        if (!$this->requireReviewUser()) {
            return $this->unauthorized();
        }

        try {
            $page = max(1, (int) $this->request->get('page', 1));
            $size = (int) $this->request->get('size', 10);

            return $this->success(
                (new ReviewService())->myReviews((int) AppContext::getUserId(), $page, $size)
            );
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    /**
     * 提交评论（默认进入待审核）
     *
     * @return \think\Response
     */
    public function create()
    {
        if (!$this->requireReviewUser()) {
            return $this->unauthorized();
        }

        try {
            $data   = $this->request->post();
            $result = (new ReviewService())->create((int) AppContext::getUserId(), $data);

            return $this->success($result, '评论已提交，等待审核');
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    /**
     * 上传评论图片（multipart file）
     *
     * @return \think\Response
     */
    public function upload()
    {
        // 路由组已挂 UserAuth；此处再断言一次，避免默认控制器调度绕过路由中间件
        if (!$this->requireReviewUser()) {
            return $this->unauthorized();
        }

        try {
            $file = $this->request->file('file');
            $meta = (new MediaUploadService())->upload($file, 'image', 'reviews');

            // width/height/size 为服务端压缩后的落盘结果（未压缩时即原图尺寸）
            return $this->success([
                'url'    => (string) $meta['url'],
                'size'   => (int) ($meta['size'] ?? 0),
                'mime'   => (string) ($meta['mime'] ?? ''),
                'width'  => (int) ($meta['width'] ?? 0),
                'height' => (int) ($meta['height'] ?? 0),
            ]);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    /**
     * 上传评论视频（multipart file）
     *
     * 与 upload() 同构，走 MediaUploadService 的 video 分支（容器签名校验），
     * 命名空间 reviews 的规格见 config/media.php（50MB、mp4/webm）。
     *
     * @return \think\Response
     */
    public function uploadVideo()
    {
        if (!$this->requireReviewUser()) {
            return $this->unauthorized();
        }

        try {
            $file = $this->request->file('file');
            $meta = (new MediaUploadService())->upload($file, 'video', 'reviews');

            return $this->success([
                'url'  => (string) $meta['url'],
                'size' => (int) ($meta['size'] ?? 0),
                'mime' => (string) ($meta['mime'] ?? ''),
            ]);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    /**
     * 有用 / 无用投票
     *
     * @return \think\Response
     */
    public function helpful()
    {
        if (!$this->requireReviewUser()) {
            return $this->unauthorized();
        }

        try {
            $reviewId = (int) $this->request->param('review_id', 0);
            $vote     = (int) $this->request->param('vote', 0);
            if ($reviewId <= 0) {
                return $this->error(40001, '参数错误');
            }

            $result = (new ReviewService())->vote((int) AppContext::getUserId(), $reviewId, $vote);

            return $this->success($result);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    /**
     * 登录态断言（默认控制器调度可绕过路由中间件，写路径必须自带兜底）
     *
     * @return bool
     */
    private function requireReviewUser(): bool
    {
        return (int) AppContext::getUserId() > 0;
    }

    /**
     * 未登录响应
     *
     * @return \think\response\Json
     */
    private function unauthorized()
    {
        return json(['code' => 401, 'message' => '请先登录', 'data' => null], 401);
    }

    /**
     * 公开接口的可选登录态：无 token / token 失效都不报错，只影响 my_vote
     *
     * @return int|null
     */
    private function optionalViewerId(): ?int
    {
        $header = (string) $this->request->header('authorization', '');
        if (stripos($header, 'Bearer ') !== 0) {
            return null;
        }

        $token = trim(substr($header, 7));
        if ($token === '') {
            return null;
        }

        try {
            $user = SiteAuth::userFromToken($token);
            return $user ? (int) $user->id : null;
        } catch (\Throwable $e) {
            return null;
        }
    }
}
