<?php
use think\migration\Migrator;

/**
 * 商品评论增加视频
 *
 * videos_json：视频地址数组，最多 2 个；结构与 images_json 对称
 * （`/uploads/reviews/videos/YYYYMM/<32hex>.mp4|webm`，由 ReviewService::VIDEO_PATTERN 收敛）。
 *
 * - 历史行保持 NULL，读取侧视为 []，旧逻辑完全不变；
 * - 只向前：不做历史回填，回退功能只需回退代码（列保留 NULL 无副作用）。
 */
class AddProductReviewVideos extends Migrator
{
    /**
     * @return void
     */
    public function change()
    {
        $this->table('product_review')
            ->addColumn('videos_json', 'json', [
                'null'    => true,
                'after'   => 'images_json',
                'comment' => '视频地址数组，最多 2 个',
            ])
            ->update();
    }
}
