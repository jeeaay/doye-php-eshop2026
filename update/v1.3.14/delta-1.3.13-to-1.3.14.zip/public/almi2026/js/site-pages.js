/*
 * 前台页面逻辑（Alpine 组件）
 *
 * 全部对接 PHP 后台已有接口（见 store.js 顶部映射表）：
 *  商品详情  -> 服务端渲染 + 本文件的 SKU 选择/加购
 *  登录      -> /api/site/auth/*
 *  结算      -> /api/order/checkout + /api/order/pay
 *  心愿单    -> localStorage（后台无收藏表，见 todo.md）
 */
(function () {
  function productData() {
    var el = document.querySelector('main[data-product]');
    if (!el) { return null; }
    try { return JSON.parse(el.dataset.product); } catch (e) { return null; }
  }

  /* ---------------- 商品详情 ---------------- */
  window.productDetail = function () {
    var product = productData() || { skus: [] };
    var skus = product.skus || [];

    return {
      quantity: 1,
      skus: skus,
      selectedSkuId: skus.length ? skus[0].id : 0,
      detailsOpen: true,
      specsOpen: false,
      shippingOpen: false,
      reviewsOpen: false,
      adding: false,
      added: false,

      init() {},

      get selectedSku() {
        var id = this.selectedSkuId;
        return this.skus.find(function (s) { return String(s.id) === String(id); }) || null;
      },
      get inStock() {
        var sku = this.selectedSku;
        return !sku || sku.stock > 0;
      },
      selectSku(id) {
        this.selectedSkuId = id;
        this.revealGalleryImage();
      },
      // 桌面端把当前 SKU 关联的展示大图滚入可视区域；窄屏不滚，避免把用户带离规格选项。
      revealGalleryImage() {
        var sku = this.selectedSku;
        var image = sku && sku.image;
        if (!image) { return; }
        if (!window.matchMedia || !window.matchMedia('(min-width: 768px)').matches) { return; }
        var nodes = document.querySelectorAll('.product-gallery__image');
        for (var i = 0; i < nodes.length; i++) {
          var src = nodes[i].getAttribute('src') || '';
          if (src === image || src.indexOf(image) !== -1) {
            if (nodes[i].scrollIntoView) {
              nodes[i].scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
            return;
          }
        }
      },
      priceOf(id) {
        var sku = this.skus.find(function (s) { return String(s.id) === String(id); });
        return sku ? sku.price : '';
      },
      async addToCart() {
        if (!this.selectedSkuId) { return; }
        this.adding = true;
        try {
          await StoreCart.add(this.selectedSkuId, this.quantity);
          this.added = true;
          StoreUI.toast('Added to basket', 'success');
          setTimeout(() => { this.added = false; }, 2000);
        } catch (e) {
          StoreUI.toast(e.message, 'error');
        } finally {
          this.adding = false;
        }
      },
      async buyNow() {
        if (!this.selectedSkuId) { return; }
        try {
          await StoreCart.add(this.selectedSkuId, this.quantity);
          window.location.href = '/checkout';
        } catch (e) {
          StoreUI.toast(e.message, 'error');
        }
      },
      toggle() {}
    };
  };

  window.wishlistButton = function () {
    var product = productData();
    return {
      active: false,
      init() {
        if (product) { this.active = StoreWishlist.has(product.id); }
      },
      toggle() {
        if (!product) { return; }
        this.active = StoreWishlist.toggle({
          id: product.id,
          name: product.name,
          price: StoreAPI.currency() + product.price,
          image: product.image,
          url: product.url
        });
        StoreUI.toast(this.active ? 'Added to wishlist' : 'Removed from wishlist', 'info');
      }
    };
  };

  /* ---------------- 商品评论 ---------------- */
  window.productReviews = function () {
    function escapeHtml(value) {
      return String(value == null ? '' : value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
    }

    return {
      productId: 0,
      pageSize: 5,
      page: 1,
      total: 0,
      hasMore: false,
      loading: false,
      _seq: 0,
      filters: { rating: '', media: false, keyword: '' },

      // 写评论面板
      panelOpen: false,
      formOpen: false,
      eligible: [],
      selectedOrderItemId: 0,
      rating: 0,
      title: '',
      content: '',
      images: [],
      videos: [],
      anonymous: false,
      uploading: false,
      uploadingVideo: false,
      submitting: false,
      submitted: false,
      formError: '',
      notice: '',

      // 媒体条 / Lightbox
      mediaItems: [],
      lightboxOpen: false,
      lightboxIndex: 0,
      lightboxItems: [],

      labels: {},
      urls: {},

      init() {
        var ds = this.$root.dataset;
        this.productId = parseInt(ds.reviewProduct, 10) || 0;
        this.pageSize = parseInt(ds.reviewPageSize, 10) || 5;
        this.total = parseInt(ds.reviewTotal, 10) || 0;
        this.hasMore = ds.reviewHasMore === '1';

        this.urls = {
          star: ds.starUrl || '',
          thumbUp: ds.thumbUpUrl || '',
          thumbDown: ds.thumbDownUrl || ''
        };
        this.labels = {
          verified: ds.labelVerified || '',
          helpful: ds.labelHelpful || '',
          yes: ds.labelYes || '',
          no: ds.labelNo || '',
          reply: ds.labelReply || '',
          empty: ds.labelEmpty || '',
          emptyFiltered: ds.labelEmptyFiltered || '',
          mediaTitle: ds.labelMediaTitle || '',
          close: ds.labelClose || '',
          prev: ds.labelPrev || '',
          next: ds.labelNext || '',
          error: ds.msgError || '',
          uploadFailed: ds.msgUploadFailed || '',
          uploadVideoFailed: ds.msgUploadVideoFailed || '',
          maxImages: ds.msgMaxImages || '',
          maxVideos: ds.msgMaxVideos || '',
          videoTooLarge: ds.msgVideoTooLarge || '',
          videoTypeInvalid: ds.msgVideoTypeInvalid || '',
          ratingRequired: ds.msgRatingRequired || '',
          pending: ds.msgPending || '',
          noEligible: ds.msgNoEligible || ''
        };

        this.syncFooter();
        this.loadMedia();

        // 登录用户的列表由服务端 SSR 只含已通过评论（服务端看不到登录态），
        // 这里带 token 重拉第 1 页覆盖 SSR，让作者看到自己那条待审核评论；
        // 未登录不发额外请求（fetchList 内部有 _seq 竞态保护）。
        // 首屏刷新是增强项：静默执行，token 过期 / 网络失败时保留 SSR 列表，不弹 toast。
        if (StoreAuth.isLoggedIn()) {
          this.fetchList(true, true);
        }
      },

      /* ---- 列表 / 筛选 / 加载更多 ---- */

      listEl() { return this.$root.querySelector('.review-list'); },
      emptyEl() { return this.$root.querySelector('.review-empty'); },
      moreEl() { return this.$root.querySelector('.review-more'); },

      hasActiveFilters() {
        return !!(this.filters.rating || this.filters.media || this.filters.keyword);
      },

      syncFooter() {
        var list = this.listEl();
        var count = list ? list.querySelectorAll('.review-item').length : 0;
        var empty = this.emptyEl();
        if (empty) {
          if (count === 0) {
            empty.textContent = this.hasActiveFilters() ? this.labels.emptyFiltered : this.labels.empty;
            empty.hidden = false;
          } else {
            empty.hidden = true;
          }
        }
        var more = this.moreEl();
        if (more) { more.hidden = !(this.hasMore && count > 0); }
      },

      // reset=true 时为第 1 页（覆盖列表）；silent=true 时失败不弹 toast（首屏刷新用）
      async fetchList(reset, silent) {
        var seq = this._seq = this._seq + 1;
        this.loading = true;
        var nextPage = reset ? 1 : this.page + 1;
        var query = new URLSearchParams();
        query.set('product_id', String(this.productId));
        query.set('page', String(nextPage));
        query.set('size', String(this.pageSize));
        if (this.filters.rating) { query.set('rating', String(this.filters.rating)); }
        if (this.filters.media) { query.set('media', '1'); }
        if (this.filters.keyword) { query.set('keyword', this.filters.keyword); }

        try {
          var data = await StoreAPI.get('/api/review/list?' + query.toString());
          if (seq !== this._seq) { return; }
          var html = (data.list || []).map(this.itemHtml, this).join('');
          var list = this.listEl();
          if (list) {
            if (reset) {
              list.innerHTML = html;
            } else {
              list.insertAdjacentHTML('beforeend', html);
            }
          }
          this.page = parseInt(data.page, 10) || nextPage;
          this.total = parseInt(data.total, 10) || 0;
          this.hasMore = !!data.hasMore;
          this.syncFooter();
        } catch (e) {
          if (seq !== this._seq) { return; }
          // 首屏静默刷新失败（含 token 过期）保留 SSR 列表；用户主动操作才提示
          if (!silent) {
            StoreUI.toast(e.message || this.labels.error, 'error');
          }
        } finally {
          if (seq === this._seq) { this.loading = false; }
        }
      },

      applyFilters() { return this.fetchList(true); },

      loadMore() {
        if (!this.hasMore || this.loading) { return; }
        return this.fetchList(false);
      },

      starsHtml(rating) {
        var out = '';
        for (var n = 1; n <= 5; n++) {
          out += '<img src="' + escapeHtml(this.urls.star) + '" width="12" height="12" alt="" class="star'
            + (n <= rating ? '' : ' star--empty') + '">';
        }
        return out;
      },

      /* ---- 媒体条 / Lightbox ---- */

      // 媒体条与分页列表解耦：只取前 20 条「有图或有视频」的评论，视频在前、图片在后
      async loadMedia() {
        if (!this.productId) { return; }
        var query = new URLSearchParams();
        query.set('product_id', String(this.productId));
        query.set('media', '1');
        query.set('size', '20');
        query.set('page', '1');

        try {
          var data = await StoreAPI.get('/api/review/list?' + query.toString());
          var rows = (data && data.list) || [];
          var items = [];
          var i;
          var j;
          for (i = 0; i < rows.length; i++) {
            var vids = rows[i].videos || [];
            for (j = 0; j < vids.length; j++) {
              items.push({ type: 'video', url: vids[j], thumb: '', key: 'v' + rows[i].id + '-' + j });
            }
          }
          for (i = 0; i < rows.length; i++) {
            var imgs = rows[i].images || [];
            // image_thumbs 由服务端压缩任务下发（与 images 等长）；缺失或生成失败时回退原图
            var thumbs = rows[i].image_thumbs || [];
            for (j = 0; j < imgs.length; j++) {
              items.push({ type: 'image', url: imgs[j], thumb: thumbs[j] || '', key: 'i' + rows[i].id + '-' + j });
            }
          }
          this.mediaItems = items;
        } catch (e) {
          // 媒体条是增强项：失败静默，不影响评论列表与写评价
          this.mediaItems = [];
        }
      },

      // 从评论条目 DOM 读取该评论自己的媒体组（SSR 与 JS 渲染同一套契约）
      mediaFromItem(reviewEl) {
        var nodes = reviewEl ? reviewEl.querySelectorAll('[data-review-media]') : [];
        var out = [];
        for (var i = 0; i < nodes.length; i++) {
          var full = nodes[i].dataset.src || '';
          out.push({
            type: nodes[i].dataset.reviewMedia || 'image',
            url: full,
            thumb: nodes[i].dataset.thumb || full,
            key: 'r' + i
          });
        }
        return out;
      },

      get lightboxItem() {
        return this.lightboxItems[this.lightboxIndex] || null;
      },

      get lightboxCounter() {
        if (!this.lightboxItems.length) { return ''; }
        return (this.lightboxIndex + 1) + ' / ' + this.lightboxItems.length;
      },

      openLightbox(idx) {
        this.lightboxItems = this.mediaItems.slice();
        this.openLightboxAt(idx);
      },

      openLightboxAt(idx) {
        if (!this.lightboxItems.length) { return; }
        this.pauseLightboxVideo();
        this.lightboxIndex = Math.max(0, Math.min(idx, this.lightboxItems.length - 1));
        this.lightboxOpen = true;
      },

      closeLightbox() {
        this.pauseLightboxVideo();
        this.lightboxOpen = false;
      },

      prevMedia() { this.stepLightbox(-1); },
      nextMedia() { this.stepLightbox(1); },

      // 键盘统一入口：只在 Lightbox 打开时接管按键，关闭时不干扰页面滚动
      onLightboxKey(event, action) {
        if (!this.lightboxOpen) { return; }
        if (event && typeof event.preventDefault === 'function') { event.preventDefault(); }
        if (action === 'escape') { this.closeLightbox(); return; }
        this.stepLightbox(action === 1 ? 1 : -1);
      },

      stepLightbox(delta) {
        var total = this.lightboxItems.length;
        if (!this.lightboxOpen || total < 2) { return; }
        this.pauseLightboxVideo();
        this.lightboxIndex = (this.lightboxIndex + delta + total) % total;
      },

      pauseLightboxVideo() {
        var video = this.$refs ? this.$refs.lightboxVideo : null;
        if (video && typeof video.pause === 'function') { video.pause(); }
      },

      itemHtml(item) {
        var esc = escapeHtml;
        var rating = parseInt(item.rating, 10) || 0;
        var html = '<article class="review-item" data-review-id="' + esc(item.id) + '">';

        html += '<div class="review-meta"><div class="reviewer-info"><strong>' + esc(item.author) + '</strong>';
        if (parseInt(item.is_verified, 10) === 1) {
          html += '<span class="verified-buyer">' + esc(this.labels.verified) + '</span>';
        }
        html += '</div><span class="review-date">' + esc(String(item.create_time || '').slice(0, 10)) + '</span></div>';

        html += '<div class="review-content"><div class="stars" role="img" aria-label="' + rating + ' / 5">'
          + this.starsHtml(rating) + '</div>';
        if (item.title) { html += '<h4>' + esc(item.title) + '</h4>'; }
        html += '<p>' + esc(item.content) + '</p>';
        var videos = item.videos || [];
        if (videos.length) {
          html += '<div class="review-images review-images--video">';
          for (var v = 0; v < videos.length; v++) {
            html += '<button type="button" class="review-media-thumb is-video" data-review-media="video" data-src="'
              + esc(videos[v]) + '">'
              + '<video src="' + esc(videos[v]) + '" preload="metadata" muted playsinline></video>'
              + '<span class="review-media-thumb__play" aria-hidden="true">&#9654;</span></button>';
          }
          html += '</div>';
        }
        if (item.images && item.images.length) {
          // image_thumbs 与服务端压缩任务配套：src 用列表缩略图，data-src/href 保留原图给 Lightbox 与新窗口
          var thumbs = item.image_thumbs || [];
          html += '<div class="review-images">';
          for (var i = 0; i < item.images.length; i++) {
            var full = item.images[i];
            var thumb = thumbs[i] || full;
            // 保留 <a href> 作为无 JS 兜底；有 JS 时由 onListClick 拦截后打开 Lightbox
            html += '<a href="' + esc(full) + '" target="_blank" rel="noopener"'
              + ' data-review-media="image" data-src="' + esc(full) + '" data-thumb="' + esc(thumb) + '">'
              + '<img src="' + esc(thumb) + '" alt="" loading="lazy" decoding="async"></a>';
          }
          html += '</div>';
        }
        html += '</div>';

        if (item.admin_reply) {
          html += '<div class="review-reply"><strong>' + esc(this.labels.reply) + '</strong><p>'
            + esc(item.admin_reply) + '</p></div>';
        }

        var myVote = parseInt(item.my_vote, 10) || 0;
        html += '<div class="review-actions"><span>' + esc(this.labels.helpful) + '</span>'
          + '<button type="button" data-review-vote="1" aria-label="' + esc(this.labels.yes) + '"'
          + (myVote === 1 ? ' class="is-active"' : '') + '>'
          + '<img src="' + esc(this.urls.thumbUp) + '" width="14" height="14" alt=""> '
          + '<span data-vote-count="1">' + (parseInt(item.helpful_yes, 10) || 0) + '</span></button>'
          + '<button type="button" data-review-vote="2" aria-label="' + esc(this.labels.no) + '"'
          + (myVote === 2 ? ' class="is-active"' : '') + '>'
          + '<img src="' + esc(this.urls.thumbDown) + '" width="14" height="14" alt=""> '
          + '<span data-vote-count="2">' + (parseInt(item.helpful_no, 10) || 0) + '</span></button>'
          + '</div>';

        return html + '</article>';
      },

      /* ---- 有用 / 无用投票 ---- */

      onListClick(event) {
        // 先处理媒体点击（图片/视频缩略图 → 该评论自己的媒体组 Lightbox）
        var media = event.target.closest('[data-review-media]');
        if (media) {
          event.preventDefault();
          var reviewEl = media.closest('[data-review-id]');
          this.lightboxItems = this.mediaFromItem(reviewEl);
          var idx = 0;
          if (reviewEl) {
            var nodes = reviewEl.querySelectorAll('[data-review-media]');
            for (var n = 0; n < nodes.length; n++) {
              if (nodes[n] === media) { idx = n; break; }
            }
          }
          this.openLightboxAt(idx);
          return;
        }

        var button = event.target.closest('[data-review-vote]');
        if (!button) { return; }
        var item = button.closest('[data-review-id]');
        if (item) { this.vote(item, button); }
      },

      async vote(item, button) {
        if (!StoreAuth.isLoggedIn()) { this.gotoLogin(); return; }
        var reviewId = parseInt(item.dataset.reviewId, 10) || 0;
        var vote = parseInt(button.dataset.reviewVote, 10) || 0;
        if (!reviewId || !vote) { return; }

        button.disabled = true;
        try {
          var data = await StoreAPI.post('/api/review/helpful', { review_id: reviewId, vote: vote });
          var buttons = item.querySelectorAll('[data-review-vote]');
          for (var i = 0; i < buttons.length; i++) {
            var self = buttons[i];
            var type = parseInt(self.dataset.reviewVote, 10);
            self.classList.toggle('is-active', parseInt(data.vote, 10) === type);
            var counter = self.querySelector('[data-vote-count]');
            if (counter) {
              counter.textContent = String(type === 1 ? data.helpful_yes : data.helpful_no);
            }
          }
        } catch (e) {
          if (e.message === 'Please sign in first') { this.gotoLogin(); return; }
          StoreUI.toast(e.message || this.labels.error, 'error');
        } finally {
          button.disabled = false;
        }
      },

      /* ---- 写评论 ---- */

      gotoLogin() {
        var redirect = encodeURIComponent(window.location.pathname + window.location.search);
        window.location.href = '/login?redirect=' + redirect;
      },

      async openForm() {
        if (!StoreAuth.isLoggedIn()) { this.gotoLogin(); return; }
        if (this.panelOpen && (this.formOpen || this.notice)) { return; }

        this.formError = '';
        this.notice = '';
        this.panelOpen = true;

        try {
          var data = await StoreAPI.get('/api/review/eligible?product_id=' + this.productId);
          var list = (data && data.list) || [];
          this.eligible = list;
          if (!list.length) {
            this.formOpen = false;
            this.notice = this.labels.noEligible;
            return;
          }
          this.selectedOrderItemId = parseInt(list[0].order_item_id, 10) || 0;
          this.formOpen = true;
        } catch (e) {
          if (e.message === 'Please sign in first') { this.gotoLogin(); return; }
          this.panelOpen = false;
          StoreUI.toast(e.message || this.labels.error, 'error');
        }
      },

      closeForm() {
        this.formOpen = false;
        this.formError = '';
        if (!this.submitted) { this.panelOpen = false; }
      },

      async upload(event) {
        var input = event.target;
        var files = Array.prototype.slice.call(input.files || []);
        input.value = '';
        if (!files.length || !this.formOpen) { return; }
        if (!StoreAuth.isLoggedIn()) { this.gotoLogin(); return; }

        var room = 6 - this.images.length;
        if (room <= 0) { StoreUI.toast(this.labels.maxImages, 'error'); return; }
        if (files.length > room) {
          files = files.slice(0, room);
          StoreUI.toast(this.labels.maxImages, 'error');
        }

        this.uploading = true;
        for (var i = 0; i < files.length; i++) {
          try {
            var url = await this.uploadOne(files[i], 'image');
            if (url) { this.images.push(url); }
          } catch (e) {
            if (e.message === 'Please sign in first') { this.gotoLogin(); break; }
            StoreUI.toast(e.message || this.labels.uploadFailed, 'error');
          }
        }
        this.uploading = false;
      },

      // 视频上传：最多 2 个、单个 ≤50MB、mp4/webm（前端先拦，服务端再校验一次）
      async uploadVideo(event) {
        var input = event.target;
        var files = Array.prototype.slice.call(input.files || []);
        input.value = '';
        if (!files.length || !this.formOpen) { return; }
        if (!StoreAuth.isLoggedIn()) { this.gotoLogin(); return; }

        var maxVideos = 2;
        var maxBytes = 50 * 1024 * 1024;
        var room = maxVideos - this.videos.length;
        if (room <= 0) { StoreUI.toast(this.labels.maxVideos, 'error'); return; }
        if (files.length > room) {
          files = files.slice(0, room);
          StoreUI.toast(this.labels.maxVideos, 'error');
        }

        this.uploadingVideo = true;
        for (var i = 0; i < files.length; i++) {
          if (files[i].size > maxBytes) {
            StoreUI.toast(this.labels.videoTooLarge, 'error');
            continue;
          }
          // accept 属性只是提示，真正的扩展名校验在这里（.mov/.avi 等由服务端再兜一次）
          if (!/\.(mp4|webm)$/i.test(String(files[i].name || ''))) {
            StoreUI.toast(this.labels.videoTypeInvalid || this.labels.uploadVideoFailed, 'error');
            continue;
          }
          try {
            var url = await this.uploadOne(files[i], 'video');
            if (url) { this.videos.push(url); }
          } catch (e) {
            if (e.message === 'Please sign in first') { this.gotoLogin(); break; }
            StoreUI.toast(e.message || this.labels.uploadVideoFailed, 'error');
          }
        }
        this.uploadingVideo = false;
      },

      async uploadOne(file, type) {
        var isVideo = type === 'video';
        var body = new FormData();
        body.append('file', file);

        var res = await fetch(isVideo ? '/api/review/upload-video' : '/api/review/upload', {
          method: 'POST',
          headers: StoreAPI.headers(),
          credentials: 'same-origin',
          body: body
        });

        var payload = null;
        try { payload = await res.json(); } catch (e) { payload = null; }
        if (res.status === 413) {
          // PHP upload_max_filesize / post_max_size 或 nginx client_max_body_size 拦截
          throw new Error(isVideo ? (this.labels.videoTooLarge || this.labels.uploadVideoFailed) : this.labels.uploadFailed);
        }
        if (res.status === 401 || (payload && payload.code === 401)) {
          StoreAPI.setToken('');
          StoreAuth.emit(false);
          throw new Error('Please sign in first');
        }
        if (!payload || payload.code !== 0) {
          var fallback = isVideo ? this.labels.uploadVideoFailed : this.labels.uploadFailed;
          throw new Error((payload && payload.message) || fallback);
        }
        return payload.data && payload.data.url ? payload.data.url : '';
      },

      async submit() {
        if (this.submitting || this.submitted) { return; }
        this.formError = '';

        if (!this.rating) { this.formError = this.labels.ratingRequired; return; }
        if (!this.selectedOrderItemId) { this.formError = this.labels.noEligible; return; }

        this.submitting = true;
        try {
          await StoreAPI.post('/api/review/create', {
            order_item_id: this.selectedOrderItemId,
            rating: this.rating,
            title: this.title,
            content: this.content,
            images: this.images,
            videos: this.videos,
            is_anonymous: this.anonymous ? 1 : 0
          });

          this.submitted = true;
          this.formOpen = false;
          this.notice = this.labels.pending;
          this.title = '';
          this.content = '';
          this.images = [];
          this.videos = [];
          this.rating = 0;
          this.anonymous = false;
        } catch (e) {
          if (e.message === 'Please sign in first') { this.gotoLogin(); return; }
          this.formError = e.message || this.labels.error;
        } finally {
          this.submitting = false;
        }
      }
    };
  };

  /* ---------------- 登录 ---------------- */
  window.loginPage = function () {
    return {
      step: 'email',
      email: '',
      code: '',
      error: '',
      sending: false,
      verifying: false,
      countdown: 0,
      _timer: null,

      init() {
        var params = new URLSearchParams(window.location.search);
        var email = params.get('email');
        if (email) { this.email = email; }
        if (StoreAuth.isLoggedIn()) { window.location.href = this.redirectTo(); }
      },

      redirectTo() {
        var params = new URLSearchParams(window.location.search);
        return params.get('redirect') || '/account';
      },

      startCountdown() {
        this.countdown = 60;
        clearInterval(this._timer);
        this._timer = setInterval(() => {
          this.countdown -= 1;
          if (this.countdown <= 0) { clearInterval(this._timer); }
        }, 1000);
      },

      async sendCode() {
        this.error = '';
        if (!this.email) { this.error = 'Please enter your email'; return; }
        this.sending = true;
        try {
          var res = await StoreAuth.sendCode(this.email);
          this.step = 'code';
          this.startCountdown();
          if (res && res.dev_code) {
            this.code = res.dev_code;
            StoreUI.toast('Dev mode code: ' + res.dev_code, 'info');
          } else {
            StoreUI.toast('Verification code sent', 'success');
          }
        } catch (e) {
          this.error = e.message;
        } finally {
          this.sending = false;
        }
      },

      async verifyCode() {
        this.error = '';
        if (this.code.length !== 6) { this.error = 'Enter the 6-digit code'; return; }
        this.verifying = true;
        try {
          await StoreAuth.verifyCode(this.email, this.code);
          window.location.href = this.redirectTo();
        } catch (e) {
          this.error = e.message;
        } finally {
          this.verifying = false;
        }
      }
    };
  };

  /* ---------------- 页脚 newsletter 快捷登录 ---------------- */
  window.newsletterAuth = function () {
    return {
      open: false,
      email: '',
      code: '',
      error: '',
      sending: false,
      verifying: false,
      countdown: 0,
      _timer: null,

      openFromForm(e) {
        var form = (e && e.target) || document.getElementById('newsletter-form');
        var input = form ? form.querySelector('input[name="email"]') : null;
        if (StoreAuth.isLoggedIn()) {
          StoreUI.toast("You're already signed in", 'info');
          return;
        }
        var email = input ? String(input.value || '').trim() : '';
        if (!email) {
          if (input) { input.focus(); }
          StoreUI.toast('Please enter your email', 'error');
          return;
        }
        this.email = email;
        this.code = '';
        this.error = '';
        this.open = true;
        this.sendCode();
      },

      close() {
        this.open = false;
        this.error = '';
        this.code = '';
        clearInterval(this._timer);
        this.countdown = 0;
      },

      startCountdown() {
        this.countdown = 60;
        clearInterval(this._timer);
        this._timer = setInterval(() => {
          this.countdown -= 1;
          if (this.countdown <= 0) { clearInterval(this._timer); }
        }, 1000);
      },

      async sendCode() {
        if (this.sending) { return; }
        this.error = '';
        this.sending = true;
        try {
          var res = await StoreAuth.sendCode(this.email);
          this.startCountdown();
          if (res && res.dev_code) {
            this.code = res.dev_code;
            StoreUI.toast('Dev mode code: ' + res.dev_code, 'info');
          } else {
            StoreUI.toast('Verification code sent', 'success');
          }
        } catch (e) {
          this.error = e.message;
        } finally {
          this.sending = false;
        }
      },

      async verify() {
        this.error = '';
        if (this.code.length !== 6) { this.error = 'Enter the 6-digit code'; return; }
        this.verifying = true;
        try {
          // 内含游客购物车合并 + 登录态事件通知
          await StoreAuth.verifyCode(this.email, this.code);
          var email = this.email;
          try {
            await StoreAPI.post('/api/site/subscribe', { email: email });
          } catch (err) {
            if (window.console) { console.warn('newsletter subscribe failed', err); }
          }
          this.close();
          StoreUI.toast('Signed in. Welcome, ' + email, 'success');
        } catch (e) {
          this.error = e.message;
        } finally {
          this.verifying = false;
        }
      }
    };
  };

  /* ---------------- 结算 ---------------- */
  window.checkoutAuth = function () {
    return {
      isLoggedIn: false,
      email: '',
      code: '',
      authStep: 1,
      authError: '',
      sending: false,
      verifying: false,
      countdown: 0,
      _timer: null,

      addresses: [],
      loadingAddresses: true,
      selectedAddressId: 0,
      showAddForm: false,
      newAddress: { name: '', phone: '', address_detail: '', country: '', is_default: false },
      addressError: '',
      savingAddress: false,

      submitting: false,
      payChannel: 'paypal',
      channels: [],
      toast: { visible: false, message: '', type: 'info' },
      _toastTimer: null,

      async init() {
        this.isLoggedIn = StoreAuth.isLoggedIn();
        if (this.isLoggedIn) {
          await Promise.all([this.fetchAddresses(), this.fetchChannels()]);
        } else {
          this.loadingAddresses = false;
        }
        // 未登录也挂载：游客车条目与金额展示在订单摘要中
        CartPage.mount(this);
      },

      async fetchChannels() {
        try {
          var list = await StoreOrders.channels();
          this.channels = (list || []).map(function (c) { return { code: c.code, name: c.name }; });
          if (this.channels.length) { this.payChannel = this.channels[0].code; }
        } catch (e) { /* 渠道接口不可用时保留下单，支付页会提示 */ }
      },

      async fetchAddresses() {
        this.loadingAddresses = true;
        try {
          var list = await StoreAddress.list();
          this.addresses = (list || []).map(function (a) {
            return {
              id: a.id,
              name: a.name,
              phone: a.phone,
              street: a.address_detail,
              country: a.country || '',
              is_default: !!Number(a.is_default)
            };
          });
          var def = this.addresses.find(function (a) { return a.is_default; });
          if (def) { this.selectedAddressId = def.id; }
          else if (this.addresses.length) { this.selectedAddressId = this.addresses[0].id; }
          if (!this.addresses.length) { this.showAddForm = true; }
        } catch (e) {
          this.authError = e.message;
        } finally {
          this.loadingAddresses = false;
        }
      },

      formatCity(addr) { return addr.city || ''; },

      selectedAddress() {
        var id = this.selectedAddressId;
        return this.addresses.find(function (a) { return String(a.id) === String(id); }) || null;
      },

      formatSelectedAddress() {
        var a = this.selectedAddress();
        if (!a) { return ''; }
        return [a.name, a.street, a.phone].filter(Boolean).join(', ');
      },

      async saveNewAddress() {
        this.addressError = '';
        var f = this.newAddress;
        if (!f.name || !f.street) { this.addressError = 'Name and address are required'; return; }
        this.savingAddress = true;
        try {
          await StoreAddress.add({
            name: f.name,
            phone: f.phone || '',
            address_detail: f.street,
            country: f.country || '',
            is_default: f.is_default ? 1 : 0
          });
          this.showAddForm = false;
          this.newAddress = { name: '', phone: '', address_detail: '', country: '', is_default: false };
          await this.fetchAddresses();
          StoreUI.toast('Address saved', 'success');
        } catch (e) {
          this.addressError = e.message;
        } finally {
          this.savingAddress = false;
        }
      },

      async sendCode() {
        this.authError = '';
        this.sending = true;
        try {
          var res = await StoreAuth.sendCode(this.email);
          this.authStep = 2;
          this.startCountdown();
          if (res && res.dev_code) {
            this.code = res.dev_code;
            StoreUI.toast('Dev mode code: ' + res.dev_code, 'info');
          }
        } catch (e) {
          this.authError = e.message;
        } finally {
          this.sending = false;
        }
      },

      startCountdown() {
        this.countdown = 60;
        clearInterval(this._timer);
        this._timer = setInterval(() => {
          this.countdown -= 1;
          if (this.countdown <= 0) { clearInterval(this._timer); }
        }, 1000);
      },

      async verifyCode() {
        this.authError = '';
        this.verifying = true;
        try {
          // verifyCode 内部会合并游客车，成功后服务端购物车即包含本地条目
          await StoreAuth.verifyCode(this.email, this.code);
          this.isLoggedIn = true;
          await Promise.all([this.fetchAddresses(), this.fetchChannels()]);
          CartPage.mount(this);
        } catch (e) {
          this.authError = e.message;
        } finally {
          this.verifying = false;
        }
      },

      async submitOrder() {
        var items = CartPage.selectedItems();
        if (!items.length) { StoreUI.toast('Your basket is empty', 'error'); return; }
        if (!this.selectedAddressId) { StoreUI.toast('Please choose a delivery address', 'error'); return; }
        this.submitting = true;
        try {
          var order = await StoreOrders.checkout({
            items: items,
            address_id: this.selectedAddressId,
            remark: '',
            pay_channel: this.payChannel
          });
          var pay = await StoreOrders.pay(order.order_pay_id, this.payChannel);
          if (pay && pay.type === 'redirect' && pay.url) {
            window.location.href = pay.url;
            return;
          }
          if (pay && pay.h5_url) { window.location.href = pay.h5_url; return; }
          window.location.href = '/order-success?pay_id=' + encodeURIComponent(order.order_pay_id);
        } catch (e) {
          StoreUI.toast(e.message, 'error');
        } finally {
          this.submitting = false;
        }
      },

      showToast(message, type) {
        this.toast = { visible: true, message: message, type: type || 'info' };
        clearTimeout(this._toastTimer);
        this._toastTimer = setTimeout(() => { this.toast.visible = false; }, 3000);
      },
      hideToast() { this.toast.visible = false; }
    };
  };

  /* ---------------- 心愿单 ---------------- */
  window.wishlistApp = function () {
    return {
      items: [],
      loading: false,
      error: '',
      init() {
        this.items = StoreWishlist.items().map(function (i) {
          return { product: { id: i.id, name: i.name, amount: i.price, image: i.image, url: i.url } };
        });
      },
      formatPrice(v) { return v || ''; },
      removeWishlist(id) {
        StoreWishlist.remove(id);
        this.items = this.items.filter(function (i) { return String(i.product.id) !== String(id); });
      },
      addToCart(id) {
        StoreUI.toast('Choose options on the product page', 'info');
        window.location.href = '/products/' + id;
      }
    };
  };

  /* ---------------- 我的评价（账户中心，只读） ---------------- */
  // 数据源：GET /api/review/mine（UserAuth），服务端只返回「待审核 + 已通过」（status in 0,1）。
  // 页面不展示审核状态（无徽标），status / status_label 仍由接口下发但这里不使用。
  // 渲染走 Alpine 模板，不拼 innerHTML。
  window.accountReviews = function () {
    return {
      loading: true,
      loadingMore: false,
      error: '',
      items: [],
      page: 0,
      size: 10,
      total: 0,
      hasMore: false,
      starUrl: '',
      _seq: 0,

      init() {
        var ds = this.$root.dataset || {};
        this.starUrl = ds.starUrl || '';
        if (!StoreAuth.isLoggedIn()) { this.gotoLogin(); return; }
        this.load(true);
      },

      gotoLogin() {
        var target = window.location.pathname + window.location.search;
        window.location.href = '/login?redirect=' + encodeURIComponent(target);
      },

      productUrl(item) {
        return '/products/' + (parseInt(item.product_id, 10) || 0);
      },

      formatDate(value) {
        return String(value || '').slice(0, 10);
      },

      loadMore() {
        if (!this.hasMore || this.loading || this.loadingMore) { return; }
        return this.load(false);
      },

      // 追加时按 id 去重：翻页期间新增评价不会让同一条出现两次
      merge(rows) {
        var seen = {};
        var merged = [];
        var i;
        var list = this.items.concat(rows);
        for (i = 0; i < list.length; i++) {
          var row = list[i];
          if (!row) { continue; }
          var id = row.id;
          // 没有 id 的条目无法去重，保留而不是丢弃，避免静默少显示
          if (id == null) { merged.push(row); continue; }
          if (seen[id]) { continue; }
          seen[id] = true;
          merged.push(row);
        }
        return merged;
      },

      async load(reset) {
        var seq = this._seq = this._seq + 1;
        var nextPage = reset ? 1 : this.page + 1;
        if (reset) {
          this.loading = true;
          this.error = '';
        } else {
          this.loadingMore = true;
        }

        try {
          var data = await StoreAPI.get('/api/review/mine?page=' + nextPage + '&size=' + this.size);
          if (seq !== this._seq) { return; }
          var rows = (data && data.list) || [];
          // 兜底：服务端已按 status in (0,1) 过滤，这里再滤一次防止拒绝/隐藏的评论漏到前台（幂等）。
          rows = rows.filter(function (row) {
            var status = parseInt(row && row.status, 10);
            return status === 0 || status === 1;
          });
          if (reset) { this.items = []; }
          this.items = this.merge(rows);
          this.page = parseInt(data && data.page, 10) || nextPage;
          this.total = parseInt(data && data.total, 10) || 0;
          this.hasMore = !!(data && data.hasMore);
        } catch (e) {
          if (seq !== this._seq) { return; }
          var message = (e && e.message) || 'Unable to load your reviews.';
          // StoreAPI 遇 401 已清 token 并广播登出，这里直接回登录页
          if (message === 'Please sign in first') { this.gotoLogin(); return; }
          if (reset) {
            this.error = message;
          } else {
            StoreUI.toast(message, 'error');
          }
        } finally {
          if (seq === this._seq) {
            this.loading = false;
            this.loadingMore = false;
          }
        }
      }
    };
  };

  /* ---------------- 退出登录 ---------------- */
  window.logoutPage = function () {
    return {
      countdown: 3,
      init() {
        StoreAuth.logout().then(() => {
          var timer = setInterval(() => {
            this.countdown -= 1;
            if (this.countdown <= 0) {
              clearInterval(timer);
              window.location.href = '/';
            }
          }, 1000);
        });
      }
    };
  };
})();