<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\model\Category;
use app\common\model\HomeProduct;
use app\common\model\Product;

/**
 * 前台站点数据组装
 *
 * 把 PHP 后台的数据结构（Product / ProductSku / HomeOps / Category）
 * 转换成原 Go 站点模板需要的字段，尽量保持模板层无需改动：
 *   Name / Price / Images[].Full / Images[].Thumb / Brief / Description / URL / SeoDesc ...
 */
class StorefrontService
{
    /** 排序方式 -> order 片段 */
    private const SORTS = [
        // 最新品：优先发布时间，未设置发布时间时回退创建时间
        'newest'     => ['raw' => 'COALESCE(product.published_at, product.create_time) DESC, product.id DESC'],
        'price-asc'  => ['price' => 'asc'],
        'price-desc' => ['price' => 'desc'],
        'popular'    => ['sort' => 'desc', 'id' => 'desc'],
        // 首页 Latest Arrivals：按后台排序权重倒序
        'sort-desc'  => ['sort' => 'desc', 'id' => 'desc'],
    ];

    public function brand(): array
    {
        $brand = (array) site_config('brand', []);
        $currency = display_currency();
        return [
            'name'     => (string) ($brand['name'] ?? 'Store'),
            'suffix'   => (string) ($brand['suffix'] ?? ''),
            'logo'     => (string) ($brand['logo_text'] ?? ($brand['name'] ?? 'Store')),
            'tagline'  => (string) ($brand['tagline'] ?? ''),
            'currency' => (string) ($currency['symbol'] ?? '$'),
            'code'     => (string) ($currency['code'] ?? 'USD'),
        ];
    }

    /**
     * 顶部导航（与原 Go 主题一致）
     */
    public function nav(): array
    {
        return [
            ['key' => 'home',     'label' => site_lang('nav.home'),     'url' => localized_url('/')],
            ['key' => 'products', 'label' => site_lang('nav.products'), 'url' => localized_url('/products')],
            ['key' => 'service',  'label' => site_lang('nav.service'),  'url' => localized_url('/service')],
            ['key' => 'about',    'label' => site_lang('nav.about'),    'url' => localized_url('/about')],
            ['key' => 'contact',  'label' => site_lang('nav.contact'),  'url' => localized_url('/contact')],
        ];
    }

    public function footerNav(): array
    {
        return [
            'company'  => [
                ['label' => site_lang('footer.about'), 'url' => localized_url('/about')],
                ['label' => site_lang('footer.products'), 'url' => localized_url('/products')],
                ['label' => site_lang('footer.contact'), 'url' => localized_url('/contact')],
            ],
            'policies' => [
                ['label' => site_lang('footer.shipping'), 'url' => localized_url('/shipping')],
                ['label' => site_lang('footer.returns'), 'url' => localized_url('/returns')],
                ['label' => site_lang('footer.terms'), 'url' => localized_url('/terms')],
            ],
            'privacy'  => [
                ['label' => site_lang('footer.privacy'), 'url' => localized_url('/privacy')],
                ['label' => site_lang('footer.cookies'), 'url' => localized_url('/cookies')],
            ],
        ];
    }

    /**
     * 分类（一级 + 子级，带在售商品数）
     */
    public function categories(): array
    {
        $rows = Category::order('sort', 'asc')->order('id', 'asc')->select();
        $counts = [];
        foreach (
            Product::where('status', 1)->whereNull('delete_time')
                ->field('category_id, COUNT(*) AS cnt')->group('category_id')->select() as $row
        ) {
            $counts[(int) $row->category_id] = (int) $row->cnt;
        }

        $translations = (new TranslationService())->categoryMap(array_map(
            static fn ($row) => (int) $row->id,
            $rows->all()
        ));
        $nameOf = static function ($row) use ($translations): string {
            $translated = trim((string) ($translations[(int) $row->id]['name'] ?? ''));
            return $translated !== '' ? $translated : (string) $row->name;
        };

        $childrenOf = [];
        foreach ($rows as $row) {
            $childrenOf[(int) $row->parent_id][] = $row;
        }

        $tree = [];
        foreach ($childrenOf[0] ?? [] as $parent) {
            $children = [];
            $total = $counts[(int) $parent->id] ?? 0;
            foreach ($childrenOf[(int) $parent->id] ?? [] as $child) {
                $cnt = $counts[(int) $child->id] ?? 0;
                $total += $cnt;
                $children[] = [
                    'id'          => (int) $child->id,
                    'name'        => $nameOf($child),
                    'count'       => $cnt,
                    'custom_path' => (string) ($child->custom_path ?? ''),
                    'url'         => localized_url(storefront_category_url($child)),
                ];
            }
            // 没有任何在售商品的一级分类（含子分类汇总）不出现在导航 / 页脚
            if ($total <= 0) {
                continue;
            }
            $tree[] = [
                'id'          => (int) $parent->id,
                'name'        => $nameOf($parent),
                'count'       => $total,
                'custom_path' => (string) ($parent->custom_path ?? ''),
                'url'         => localized_url(storefront_category_url($parent)),
                'children'    => $children,
            ];
        }
        return $tree;
    }

    /**
     * 首个在售商品的 URL（原 Go 主题用 FirstProductSlug 做 CTA 链接）
     */
    public function firstProductUrl(): string
    {
        $first = Product::where('status', 1)->whereNull('delete_time')->order('sort', 'desc')->order('id', 'asc')->find();
        return $first ? localized_url(storefront_product_url($first)) : localized_url('/products');
    }

    /**
     * 商品列表
     *
     * @return array{list: array, total: int, page: int, size: int, hasMore: bool}
     */
    public function productCards(int $page = 1, int $size = 12, int $categoryId = 0, string $keyword = '', string $sort = 'newest'): array
    {
        $query = Product::with([
            'skus',
            'translations' => fn ($q) => $q->where('lang_code', $this->locale())->where('status', 1),
        ])->where('status', 1)->whereNull('delete_time');

        if ($categoryId > 0) {
            $ids = [$categoryId];
            foreach (Category::where('parent_id', $categoryId)->column('id') as $childId) {
                $ids[] = (int) $childId;
            }
            $query->whereIn('category_id', $ids);
        }
        if ($keyword !== '') {
            $like = '%' . $keyword . '%';
            $query->where(function ($q) use ($like) {
                $q->whereLike('title', $like)->whereOr('subtitle', 'like', $like);
            });
        }

        $order = self::SORTS[$sort] ?? self::SORTS['newest'];
        if (isset($order['price'])) {
            // 以最低 SKU 价格排序：PHP 后台价格在 SKU 上，这里用子查询排序
            $query->orderRaw(
                '(SELECT MIN(price) FROM product_sku WHERE product_sku.product_id = product.id) ' .
                ($order['price'] === 'asc' ? 'ASC' : 'DESC')
            );
        } elseif (isset($order['raw'])) {
            $query->orderRaw($order['raw']);
        } else {
            foreach ($order as $field => $direction) {
                $query->order($field, $direction);
            }
        }

        $pager = $query->paginate(['list_rows' => $size, 'page' => $page]);

        $list = [];
        foreach ($pager->items() as $product) {
            $list[] = $this->card($product, $this->translationOf($product));
        }

        return [
            'list'    => $list,
            'total'   => (int) $pager->total(),
            'page'    => (int) $pager->currentPage(),
            'size'    => (int) $pager->listRows(),
            'hasMore' => (bool) $pager->hasMore(),
        ];
    }

    /**
     * 专题商品：按给定 ID 顺序返回商品卡片
     *
     * 只输出在售且未软删的商品；顺序由后台专题的商品排序决定，
     * 缺失/下架商品直接跳过，不影响其余商品。
     *
     * @param array<int,int> $ids 商品 ID（有序）
     * @return array<int,array<string,mixed>>
     */
    public function topicProducts(array $ids): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn (int $id): bool => $id > 0)));
        if ($ids === []) {
            return [];
        }

        $products = Product::with([
            'skus',
            'translations' => fn ($q) => $q->where('lang_code', $this->locale())->where('status', 1),
        ])->whereIn('id', $ids)
            ->where('status', 1)
            ->whereNull('delete_time')
            ->select();

        $map = [];
        foreach ($products as $product) {
            $map[(int) $product->id] = $product;
        }

        $cards = [];
        foreach ($ids as $id) {
            if (!isset($map[$id])) {
                continue;
            }
            $product = $map[$id];
            $cards[] = $this->card($product, $this->translationOf($product));
        }

        return $cards;
    }

    /**
     * 首页「Trending Now」推荐商品
     *
     * 数据来自后台「推荐位设置 → 推荐商品」（home_product，status=1），
     * 按商品自身排序权重倒序（sort DESC, id DESC）取前 N 个；
     * 已下架/删除的商品自动跳过。
     */
    public function recommendedCards(int $size = 4): array
    {
        if ($size <= 0) {
            return [];
        }

        $rows = HomeProduct::where('status', 1)
            ->order('sort', 'asc')
            ->order('id', 'asc')
            ->limit(200)
            ->select();

        $ids = [];
        foreach ($rows as $row) {
            $id = (int) $row->product_id;
            if ($id > 0 && !in_array($id, $ids, true)) {
                $ids[] = $id;
            }
        }
        if ($ids === []) {
            return [];
        }

        $products = Product::with([
            'skus',
            'translations' => fn ($q) => $q->where('lang_code', $this->locale())->where('status', 1),
        ])->whereIn('id', $ids)
            ->where('status', 1)
            ->whereNull('delete_time')
            ->order('sort', 'desc')
            ->order('id', 'desc')
            ->limit($size)
            ->select();

        $cards = [];
        foreach ($products as $product) {
            $cards[] = $this->card($product, $this->translationOf($product));
        }

        return $cards;
    }

    /**
     * 商品详情页「相关产品」：同分类（含子分类）优先，不足时用最新在售商品补齐
     *
     * 口径与列表页一致（productCards）：仅 status=1、未软删，排除当前商品；
     * 同分类按 sort DESC, id DESC，补齐按 create_time DESC, id DESC。
     *
     * @param int $productId 当前商品 ID（排除）
     * @param int $categoryId 当前商品分类 ID（0 表示无分类，直接走最新补齐）
     * @param int $limit 最多返回条数
     * @return array<int, array<string, mixed>>
     */
    public function relatedProducts(int $productId, int $categoryId, int $limit = 4): array
    {
        if ($limit <= 0) {
            return [];
        }

        $with = [
            'skus',
            'translations' => fn ($q) => $q->where('lang_code', $this->locale())->where('status', 1),
        ];

        $rows = [];
        $excludeIds = [$productId];

        if ($categoryId > 0) {
            $categoryIds = [$categoryId];
            foreach (Category::where('parent_id', $categoryId)->column('id') as $childId) {
                $categoryIds[] = (int) $childId;
            }

            $picked = Product::with($with)
                ->where('status', 1)->whereNull('delete_time')
                ->whereNotIn('id', $excludeIds)
                ->whereIn('category_id', $categoryIds)
                ->order('sort', 'desc')->order('id', 'desc')
                ->limit($limit)
                ->select();

            foreach ($picked as $product) {
                $rows[] = $product;
                $excludeIds[] = (int) $product->id;
            }
        }

        $remain = $limit - count($rows);
        if ($remain > 0) {
            $latest = Product::with($with)
                ->where('status', 1)->whereNull('delete_time')
                ->whereNotIn('id', $excludeIds)
                ->order('create_time', 'desc')->order('id', 'desc')
                ->limit($remain)
                ->select();

            foreach ($latest as $product) {
                $rows[] = $product;
            }
        }

        $list = [];
        foreach ($rows as $product) {
            $list[] = $this->card($product, $this->translationOf($product));
        }
        return $list;
    }

    /**
     * 商品详情（前台展示结构）
     */
    public function product(int $id): ?array
    {
        $product = Product::with([
            'skus',
            'merchant',
            'category',
            'translations' => fn ($q) => $q->where('lang_code', $this->locale())->where('status', 1),
        ])->where('status', 1)->find($id);
        if (!$product) {
            return null;
        }

        $translation = $this->translationOf($product);
        $card = $this->card($product, $translation);

        $baseSpecs = $this->baseSpecs($product);
        $translatedSpecs = (array) ($translation['specs_json'] ?? []);
        $specs = (new TranslationService())->mergeSpecs($baseSpecs, $translatedSpecs);
        $valueMap = (new TranslationService())->valueMap($baseSpecs, $translatedSpecs);

        $categoryName = $product->category ? (string) $product->category->name : '';
        $categoryCustomPath = $product->category ? trim((string) ($product->category->custom_path ?? '')) : '';
        if ($product->category) {
            $categoryTranslation = (new TranslationService())->categoryMap([(int) $product->category->id]);
            $translatedName = trim((string) ($categoryTranslation[(int) $product->category->id]['name'] ?? ''));
            if ($translatedName !== '') {
                $categoryName = $translatedName;
            }
        }

        $skus = [];
        foreach ($product->skus as $sku) {
            if ((int) $sku->status !== 1) {
                continue;
            }
            $values = (new TranslationService())->translateSkuValues(
                (array) $sku->spec_values_json,
                $valueMap
            );
            $skus[] = [
                'id'        => (int) $sku->id,
                'spec_name' => implode(' / ', array_values($values)) ?: (string) $sku->spec_name,
                'price'     => money($sku->price),
                // 划线原价：空（或 0）表示不展示；是否展示由展示层判断 original_price > price
                'original_price' => (float) ($sku->original_price ?? 0) > 0 ? money($sku->original_price) : '',
                'stock'     => (int) $sku->stock,
                'code'      => (string) ($sku->sku_code ?? ''),
                'values'    => $values,
                // 规格值关联的展示图片：按「基准规格名 + SKU 原始值」查找，避免译文键错位
                'image'     => $this->skuSpecImage($baseSpecs, (array) $sku->spec_values_json),
            ];
        }

        return array_merge($card, [
            'description' => $this->mergedDetailHtml($product, $translation),
            'category'    => $categoryName,
            'category_id' => (int) $product->category_id,
            'category_custom_path' => $categoryCustomPath,
            'category_url' => localized_url(storefront_category_url([
                'id'          => (int) $product->category_id,
                'custom_path' => $categoryCustomPath,
            ])),
            'merchant'    => $product->merchant ? (string) $product->merchant->name : '',
            'skus'        => $skus,
            'specs'       => $specs,
            'has_stock'   => (bool) array_filter($skus, static fn ($s) => $s['stock'] > 0),
            'seo_title'   => $this->seoValue($product, $translation, 'seo_title'),
            'seo_description' => $this->seoValue($product, $translation, 'seo_description'),
            'seo_keywords'    => (string) ($product->seo_keywords ?? ''),
            'tags'            => array_values(array_map('strval', (array) ($product->tags_json ?? []))),
            // 海外仓（ShippingEtaService 白名单值）；空数组 = 国内直发
            'warehouses'      => array_values((array) ($product->warehouses_json ?? [])),
            'published_at'    => $product->published_at ? (string) $product->published_at : '',
            'seo_noindex'     => (int) ($product->seo_noindex ?? 0),
            // 商品视频：后台/管理 API 已写入，详情页用 gallery 混排渲染
            'video_url'       => trim((string) ($product->video_url ?? '')),
            'video_cover'     => trim((string) ($product->video_cover ?? '')),
            'gallery'         => $this->gallery($product, (array) ($card['images'] ?? [])),
        ]);
    }

    /**
     * 商品详情富文本：译文优先；译文缺图而基准语种有图时，回补缺失的图片标签
     *
     * @param Product $product 商品
     * @param array<string,mixed>|null $translation 当前语种译文
     */
    private function mergedDetailHtml(Product $product, ?array $translation): string
    {
        $base = (string) ($product->detail_html ?? '');
        $html = (string) ($translation['detail_html'] ?? $base);
        if ($html === '' || $html === $base || stripos($base, '<img') === false) {
            return $html;
        }

        preg_match_all('/<img\b[^>]*>/i', $base, $matches);
        $missing = '';
        foreach ($matches[0] ?? [] as $tag) {
            // 标签本身或其 src 已存在于译文中则认为未丢失
            preg_match('/src\s*=\s*"([^"]*)"/i', $tag, $src);
            $src = (string) ($src[1] ?? '');
            if (stripos($html, $tag) !== false || ($src !== '' && stripos($html, $src) !== false)) {
                continue;
            }
            $missing .= $tag;
        }
        return $missing !== '' ? $html . $missing : $html;
    }

    /**
     * 取 SEO 字段：当前语种译文优先，其次基准语种主表
     *
     * @param Product $product 商品
     * @param array<string,mixed>|null $translation 当前语种译文
     * @param string $field 字段名
     * @return string
     */
    private function seoValue(Product $product, ?array $translation, string $field): string
    {
        $value = trim((string) ($translation[$field] ?? ''));
        if ($value !== '') {
            return $value;
        }
        return trim((string) ($product->{$field} ?? ''));
    }

    /**
     * 首页运营位（复用后台 HomeOpsService 的聚合结果）
     */
    public function homeOps(): array
    {
        $ops = (new HomeOpsService())->aggregate();

        $ids = array_map(static fn ($row) => (int) $row['id'], (array) ($ops['categories'] ?? []));
        $translations = (new TranslationService())->categoryMap($ids);
        foreach ($ops['categories'] as &$category) {
            $translated = trim((string) ($translations[(int) $category['id']]['name'] ?? ''));
            if ($translated !== '') {
                $category['name'] = $translated;
            }
        }
        unset($category);

        return $ops;
    }

    // ------------------------------------------------------------------

    /**
     * 列表卡片结构
     */
    private function card(Product $product, ?array $translation = null): array
    {
        $prices = [];
        foreach ($product->skus as $sku) {
            if ((int) $sku->status === 1) {
                $prices[] = (float) $sku->price;
            }
        }
        $min = $prices ? min($prices) : 0.0;
        $max = $prices ? max($prices) : 0.0;

        $images = $this->images($product);

        $name = trim((string) ($translation['title'] ?? ''));
        $brief = trim((string) ($translation['subtitle'] ?? ''));

        return [
            'id'         => (int) $product->id,
            'url'        => localized_url(storefront_product_url($product)),
            'custom_path'      => (string) ($product->custom_path ?? ''),
            'custom_path_root' => (int) ($product->custom_path_root ?? 0),
            'name'       => $name !== '' ? $name : (string) $product->title,
            'brief'      => $brief !== '' ? $brief : (string) ($product->subtitle ?? ''),
            'price'      => money($min),
            'price_max'  => money($max),
            'has_range'  => $max > $min,
            'images'     => $images,
            'image'      => $images[0]['thumb'] ?? '',
            'sku_count'  => count($prices),
            'created_at' => (string) ($product->create_time ?? ''),
        ];
    }

    /**
     * 商品图片：main_image + images_json（PHP 后台只存原图，没有缩略图）
     */
    private function images(Product $product): array
    {
        $urls = [];
        if (!empty($product->main_image)) {
            $urls[] = (string) $product->main_image;
        }
        $extra = $product->images_json;
        $extra = is_array($extra) ? $extra : (array) json_decode((string) $extra, true);
        foreach ($extra as $url) {
            $url = is_string($url) ? trim($url) : '';
            if ($url !== '' && !in_array($url, $urls, true)) {
                $urls[] = $url;
            }
        }

        $images = [];
        foreach ($urls as $url) {
            $images[] = [
                'full'  => $url,
                // 列表/卡片使用缩略图，详情页仍用 full
                'thumb' => ThumbnailService::url($url, ThumbnailService::PRODUCT_CARD_WIDTH),
            ];
        }
        return $images;
    }

    /**
     * 详情页媒体序列：图片原顺序排列，视频插在第一张图之后；无图时视频单独成项
     *
     * @param Product $product 商品
     * @param array<int, array{full:string, thumb:string}> $images 已组装的展示图
     * @return array<int, array<string, string>>
     */
    private function gallery(Product $product, array $images): array
    {
        $items = [];
        foreach ($images as $image) {
            $items[] = [
                'type'  => 'image',
                'full'  => (string) ($image['full'] ?? ''),
                'thumb' => (string) ($image['thumb'] ?? ''),
            ];
        }

        $videoUrl = trim((string) ($product->video_url ?? ''));
        if ($videoUrl !== '') {
            $video = [
                'type'  => 'video',
                'url'   => $videoUrl,
                'cover' => trim((string) ($product->video_cover ?? '')),
            ];
            if ($items === []) {
                $items[] = $video;
            } else {
                array_splice($items, 1, 0, [$video]);
            }
        }

        return $items;
    }

    /**
     * 规格维度：优先 specs_json，其次由 SKU 的 spec_values_json 反推（英文基准）
     *
     * 可选 `value_images`（规格值 => 展示图片 URL）按 values 顺序过滤后透传；无有效关联时不输出该字段。
     */
    private function baseSpecs(Product $product): array
    {
        $specs = [];
        $raw = $product->specs_json;
        $raw = is_array($raw) ? $raw : (array) json_decode((string) $raw, true);
        foreach ($raw as $spec) {
            $name = trim((string) ($spec['name'] ?? ''));
            $values = [];
            foreach ((array) ($spec['values'] ?? []) as $value) {
                $value = trim((string) $value);
                if ($value !== '' && !in_array($value, $values, true)) {
                    $values[] = $value;
                }
            }
            if ($name !== '' && $values) {
                $item = ['name' => $name, 'values' => $values];
                $valueImages = $this->filterValueImages($spec['value_images'] ?? [], $values);
                if ($valueImages) {
                    $item['value_images'] = $valueImages;
                }
                $specs[] = $item;
            }
        }
        if ($specs) {
            return $specs;
        }

        $legacy = [];
        foreach ($product->skus as $sku) {
            foreach ((array) $sku->spec_values_json as $name => $value) {
                $legacy[(string) $name][(string) $value] = true;
            }
        }
        foreach ($legacy as $name => $values) {
            $specs[] = ['name' => (string) $name, 'values' => array_map('strval', array_keys($values))];
        }
        return $specs;
    }

    /**
     * 规格值关联图片过滤：只保留 values 内的键与非空 URL，按 values 顺序重建
     *
     * @param mixed $raw 原始 `value_images`（数组或 JSON 字符串）
     * @param array<int,string> $values 当前规格值（原顺序）
     * @return array<string,string> 无有效关联时返回空数组
     */
    private function filterValueImages($raw, array $values): array
    {
        if (is_string($raw)) {
            $raw = json_decode($raw, true);
        }
        if (!is_array($raw)) {
            return [];
        }
        $images = [];
        foreach ($values as $value) {
            $candidate = $raw[$value] ?? null;
            if (!is_scalar($candidate)) {
                continue;
            }
            $url = trim((string) $candidate);
            if ($url !== '') {
                $images[$value] = $url;
            }
        }
        return $images;
    }

    /**
     * SKU 关联图：按基准规格顺序，取第一个有 `value_images[原始值]` 的图
     *
     * 必须用 SKU 的原始规格值查找——多语言翻译后规格名/值键会变化，
     * 用译文键会查不到基准规格上的图片。
     *
     * @param array<int,array<string,mixed>> $baseSpecs 基准规格
     * @param array<string,mixed> $rawValues SKU 原始 spec_values_json
     * @return string 无关联时返回空字符串
     */
    private function skuSpecImage(array $baseSpecs, array $rawValues): string
    {
        foreach ($baseSpecs as $spec) {
            $name = (string) ($spec['name'] ?? '');
            if ($name === '' || !array_key_exists($name, $rawValues)) {
                continue;
            }
            $images = $spec['value_images'] ?? [];
            if (!is_array($images) || !is_scalar($rawValues[$name])) {
                continue;
            }
            $candidate = $images[(string) $rawValues[$name]] ?? null;
            if (!is_scalar($candidate)) {
                continue;
            }
            $image = trim((string) $candidate);
            if ($image !== '') {
                return $image;
            }
        }
        return '';
    }

    /**
     * 当前语种
     */
    private function locale(): string
    {
        return (new TranslationService())->locale();
    }

    /**
     * 取预加载的翻译行（数组）
     *
     * @return array<string,mixed>|null
     */
    private function translationOf(Product $product): ?array
    {
        $translation = $product->translations ?? null;
        if ($translation instanceof \think\Collection) {
            $translation = $translation->first();
        }
        if (is_object($translation)) {
            $translation = $translation->toArray();
        }
        return is_array($translation) ? $translation : null;
    }
}