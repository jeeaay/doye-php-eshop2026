<?php
declare(strict_types=1);

namespace app\common\service\update;

use app\common\exception\BizException;

/**
 * 数据库迁移执行器
 *
 * 优先独立进程（`php think migrate:run`）：不污染当前请求状态，迁移失败也不会把
 * 当前请求搞崩。共享主机禁用 exec / proc_open 时回退到进程内 `think\Console::call()`。
 * 两者都不可用 → 抛 BizException，由上层把步骤标记为失败并提示手工执行。
 *
 * 迁移**只向前**，回滚不涉及数据库结构（design.md §9）。
 */
class UpdateMigrator
{
    /** 探针结果缓存（同一请求内只探测一次） */
    private static ?string $cliBinaryCache = null;

    private static bool $cliProbed = false;

    private string $root;

    public function __construct(string $root)
    {
        $this->root = rtrim(str_replace('\\', '/', $root), '/');
    }

    /**
     * 执行迁移
     *
     * @return array{ok:bool,output:string,mode:string} mode 为 exec 或 console
     * @throws BizException 两种执行方式都不可用，或进程内执行抛错
     */
    public function run(): array
    {
        if ($this->execAvailable()) {
            $binary = $this->resolveCliBinary();
            if ($binary !== null) {
                return $this->runByExec($binary);
            }
        }

        // 没有可信的 CLI 二进制（典型：容器里 PHP_BINARY 是 php-fpm）→ 进程内执行，
        // 依赖提前注册好 console 服务；think-migration 的迁移是幂等的，重复执行安全。
        return $this->runByConsole();
    }

    // ------------------------------------------------------------------
    // 执行方式
    // ------------------------------------------------------------------

    private function runByExec(string $binary): array
    {
        $think = $this->root . '/think';
        if (!is_file($think)) {
            throw new BizException("找不到命令行入口 think：{$think}，无法执行数据库迁移");
        }

        $command = escapeshellarg($binary) . ' ' . escapeshellarg($think) . ' migrate:run 2>&1';

        $output = [];
        $code   = 1;
        try {
            @exec($command, $output, $code);
        } catch (\Throwable $e) {
            // 少数环境 exec 存在但被 suhosin/policy 拦住
            $output = [$e->getMessage()];
            $code   = 1;
        }

        $text = trim(implode(PHP_EOL, array_map('strval', (array) $output)));

        return ['ok' => $code === 0, 'output' => $text, 'mode' => 'exec'];
    }

    private function runByConsole(): array
    {
        if (!class_exists(\think\Console::class)) {
            throw new BizException('服务器禁用了命令执行，请手工执行 php think migrate:run');
        }

        try {
            $console = new \think\Console(app());
            /** @var \think\console\Output $output */
            $output = $console->call('migrate:run');
            $text   = method_exists($output, 'fetch') ? trim((string) $output->fetch()) : '';

            return ['ok' => true, 'output' => $text, 'mode' => 'console'];
        } catch (\think\console\exception\CommandNotFoundException $e) {
            // 进程内没有注册 migrate:run（console 服务未加载）→ 与「禁用命令执行」同等处理
            throw new BizException('服务器禁用了命令执行，请手工执行 php think migrate:run');
        } catch (\Throwable $e) {
            throw new BizException('数据库迁移执行失败：' . $e->getMessage());
        }
    }

    /**
     * exec 是否可用（存在且未被 disable_functions 禁用）
     */
    private function execAvailable(): bool
    {
        if (!function_exists('exec')) {
            return false;
        }

        $disabled = (string) ini_get('disable_functions');
        if (trim($disabled) === '') {
            return true;
        }

        $list = array_map('trim', explode(',', $disabled));
        return !in_array('exec', $list, true);
    }

    /**
     * 解析一个**真正的 CLI** PHP 二进制
     *
     * 不能直接用 PHP_BINARY：FPM 环境下它是 php-fpm，`php-fpm think migrate:run`
     * 只会打印 FPM 的 usage（容器镜像里很常见）。
     *
     * 顺序：配置/环境变量 → CLI SAPI 时用 PHP_BINARY → PHP_BINDIR/php →
     *       php-fpm 同级的 php → PATH 里的 php。每个候选都要用 `-r` 探针验证。
     */
    private function resolveCliBinary(): ?string
    {
        if (self::$cliProbed) {
            return self::$cliBinaryCache;
        }
        self::$cliProbed = true;

        // 1. 显式配置优先（容器 / 自定义安装路径）
        $explicit = trim((string) config('update.php_cli', ''));
        if ($explicit === '') {
            $explicit = trim((string) (getenv('UPDATE_PHP_CLI') ?: ''));
        }
        if ($explicit !== '') {
            if (!$this->isCliBinary($explicit)) {
                throw new BizException(
                    "config/update.php 的 php_cli / 环境变量 UPDATE_PHP_CLI 指向的不是可用的 PHP CLI：{$explicit}"
                );
            }
            return self::$cliBinaryCache = $explicit;
        }

        // 2. 本身就是 CLI SAPI → PHP_BINARY 可信
        if (in_array(PHP_SAPI, ['cli', 'phpdbg'], true) && $this->isCliBinary(PHP_BINARY)) {
            return self::$cliBinaryCache = PHP_BINARY;
        }

        // 3. 常见位置 + PATH 扫描
        $candidates = [
            PHP_BINDIR . '/php',
            dirname(PHP_BINARY) . '/php',
            '/usr/local/bin/php',
            '/usr/bin/php',
            '/opt/homebrew/bin/php',
        ];
        foreach (explode(PATH_SEPARATOR, (string) getenv('PATH')) as $dir) {
            $dir = trim($dir);
            if ($dir !== '') {
                $candidates[] = rtrim($dir, '/\\') . '/php' . (DIRECTORY_SEPARATOR === '\\' ? '.exe' : '');
            }
        }

        foreach (array_unique($candidates) as $bin) {
            if (!is_file($bin)) {
                continue;
            }
            // 名字里带 fpm 的直接跳过，连探针都不用跑
            if (stripos(basename($bin), 'fpm') !== false) {
                continue;
            }
            if ($this->isCliBinary($bin)) {
                return self::$cliBinaryCache = $bin;
            }
        }

        return self::$cliBinaryCache = null;
    }

    /**
     * 探针：真正执行一次 `-r`，能输出标记才算 CLI
     *
     * php-fpm 不认 `-r`，会打印 usage 并以非 0 退出，正好被排除。
     */
    private function isCliBinary(string $bin): bool
    {
        // 用纯数字标记：避免 Windows 下 escapeshellarg 把引号吃掉导致 PHP 解析成常量
        $cmd = escapeshellarg($bin) . ' -r ' . escapeshellarg('echo 987654321;');

        $output = [];
        $code   = 1;
        try {
            @exec($cmd, $output, $code);
        } catch (\Throwable $e) {
            return false;
        }

        return $code === 0 && in_array('987654321', array_map('trim', (array) $output), true);
    }
}