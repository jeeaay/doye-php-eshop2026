<?php
declare(strict_types=1);

namespace app\api\controller;

use app\BaseController;
use app\common\exception\BizException;
use app\common\model\ProductSku;
use app\common\service\ShippingEtaService;

class Shipping extends BaseController
{
    /** 单次请求最多计算的 SKU 数量 */
    private const MAX_SKUS = 50;

    /**
     * POST /api/shipping/eta —— 结算页配送时效（公开、只读）
     *
     * 入参 { country, sku_ids[] }，返回 { country, items: [{ sku_id, eta_text }] }。
     * 规则只在 ShippingEtaService 计算，前端只按文案分组展示，不自行推导仓库覆盖表。
     */
    public function eta()
    {
        $rawIds = $this->request->post('sku_ids', []);
        if (!is_array($rawIds)) {
            return $this->error(40001, '参数错误');
        }

        // 只保留正整数并去重
        $ids = [];
        foreach ($rawIds as $rawId) {
            $id = (int) $rawId;
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }
        $ids = array_values($ids);
        if (count($ids) > self::MAX_SKUS) {
            return $this->error(40001, '参数错误');
        }

        try {
            $service = new ShippingEtaService();
            $country = $service->normalize((string) $this->request->post('country', '')) ?? $service->defaultCountry();
            if (!$ids) {
                return $this->success(['country' => $country, 'items' => []]);
            }

            $skus = ProductSku::with('product')->whereIn('id', $ids)->select();

            $items = [];
            foreach ($skus as $sku) {
                $product = $sku->product;
                if (!$product) {
                    continue;
                }
                $items[] = [
                    'sku_id'   => (int) $sku->id,
                    'eta_text' => $service->textForCountry((array) $product->warehouses_json, $country),
                ];
            }

            return $this->success(['country' => $country, 'items' => $items]);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }
}
