<?php
declare(strict_types=1);

namespace app\controller;

/**
 * 结算页（eshop2026 主题的独立 checkout 页面）
 *
 * 迁移自 eshop2026/pages/checkout.html：地址选择、新增地址、金额汇总、下单与支付
 * 全部由 site-pages.js 的 checkoutAuth() 调 PHP 后台接口完成。
 */
class Checkout extends SiteBase
{
    public function index()
    {
        $brand = $this->store->brand();
        $shipping = new \app\common\service\ShippingEtaService();

        return $this->render('checkout', [
            'nav_active' => '',
            'page_title' => 'Checkout - ' . $brand['name'],
            'channels'   => $this->enabledChannels(),
            // 新增地址表单的国家下拉：与商品详情页同一份数据（仅国际版）
            'ship_to_groups' => is_domestic_edition() ? [] : $shipping->countries(),
            // 前端请求配送时效时的兜底国家（未选择地址 / 地址无国家）
            'default_ship_country' => $shipping->defaultCountry(),
            'domestic_edition'     => is_domestic_edition(),
        ]);
    }

    private function enabledChannels(): array
    {
        try {
            return (new \app\common\lib\payment\PaymentGatewayFactory())::enabledChannels();
        } catch (\Throwable $e) {
            return [];
        }
    }
}