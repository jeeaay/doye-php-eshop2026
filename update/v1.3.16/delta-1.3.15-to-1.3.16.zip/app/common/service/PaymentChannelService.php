<?php
declare (strict_types = 1);

namespace app\common\service;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\lib\payment\PaymentChannelCatalog;
use app\common\lib\payment\PaymentConfigCipher;
use app\common\lib\payment\PaymentGatewayFactory;
use app\common\model\PaymentChannel;
use app\common\support\AppContext;

class PaymentChannelService
{
    public function adminList(string $baseUrl = ''): array
    {
        $this->assertSuper();
        $channels = [];
        foreach (PaymentChannelCatalog::definitions() as $code => $definition) {
            $record = PaymentChannel::where('code', $code)->find();
            $testConfig = $record ? PaymentGatewayFactory::mergedConfig($code, true) : [];
            $liveConfig = $record ? PaymentGatewayFactory::mergedConfig($code, false) : [];
            $testMissing = PaymentChannelCatalog::missingRequired($code, $testConfig);
            $liveMissing = PaymentChannelCatalog::missingRequired($code, $liveConfig);
            $channels[] = [
                'code'            => $code,
                'name'            => $definition['name'],
                'short_name'      => $definition['short_name'],
                'color'           => $definition['color'],
                'description'     => $definition['description'],
                'enabled'         => $record && $record->isEnabled() ? 1 : 0,
                'test_mode'       => $record && $record->isTestMode() ? 1 : 0,
                'test_fields'     => PaymentChannelCatalog::adminFields($code, $testConfig),
                'live_fields'     => PaymentChannelCatalog::adminFields($code, $liveConfig),
                'test_configured' => $testMissing === [],
                'live_configured' => $liveMissing === [],
                'test_missing'    => $testMissing,
                'live_missing'    => $liveMissing,
                'urls'            => self::displayUrls($code, $baseUrl),
            ];
        }
        return $channels;
    }

    private static function displayUrls(string $code, string $baseUrl): array
    {
        $webhookChannels = [PaymentChannelCatalog::STRIPE, PaymentChannelCatalog::PAYPAL];
        $labels = [
            'notify_url'  => in_array($code, $webhookChannels, true) ? 'Webhook 地址' : '异步回调地址',
            'return_url'  => '支付完成回跳',
            'success_url' => '支付成功回跳',
            'cancel_url'  => '取消支付回跳',
        ];
        $urls = [];
        foreach (PaymentChannelCatalog::autoUrls($code, $baseUrl) as $key => $value) {
            $urls[] = ['label' => $labels[$key] ?? $key, 'value' => $value];
        }
        return $urls;
    }

    /**
     * Save the credentials for the environment selected by the test_mode
     * switch. The other environment's row is left untouched.
     */
    public function save(string $code, array $data): PaymentChannel
    {
        $this->assertSuper();
        $definition = PaymentChannelCatalog::definition($code);
        $record = PaymentGatewayFactory::record($code);

        $enabled = (int) ($data['enabled'] ?? 0) === 1;
        $testMode = (int) ($data['test_mode'] ?? 0) === 1;
        $existing = PaymentGatewayFactory::mergedConfig($code, $testMode);
        $config = PaymentChannelCatalog::validateAndMerge($code, $data, $existing, $enabled);

        $record->name = $definition['name'];
        $record->enabled = $enabled ? 1 : 0;
        $record->test_mode = $testMode ? 1 : 0;
        $column = PaymentGatewayFactory::envColumn($testMode);
        $record->$column = PaymentConfigCipher::encrypt($config);
        $record->save();
        return $record;
    }

    public function toggle(string $code, string $field, bool $value): void
    {
        $this->assertSuper();
        if (!in_array($field, ['enabled', 'test_mode'], true)) {
            throw new BizException('不支持的切换项');
        }
        $record = PaymentGatewayFactory::record($code);
        if ($field === 'test_mode') {
            if ($record->isEnabled()) {
                $this->assertEnvConfigured($code, $value, '切换环境前请先填写');
            }
            $record->test_mode = $value ? 1 : 0;
        } elseif ($value) {
            $this->assertEnvConfigured($code, $record->isTestMode(), '启用' . PaymentChannelCatalog::label($code) . '前请先填写');
            $record->enabled = 1;
        } else {
            $record->enabled = 0;
        }
        $record->save();
    }

    public function test(string $code, ?bool $testMode = null): string
    {
        $this->assertSuper();
        $testMode = $testMode ?? PaymentGatewayFactory::record($code)->isTestMode();
        $config = PaymentGatewayFactory::configFor($code, false, $testMode);
        return PaymentGatewayFactory::make($code)->testConnection($config);
    }

    private function assertEnvConfigured(string $code, bool $testMode, string $prefix): void
    {
        $config = PaymentGatewayFactory::mergedConfig($code, $testMode);
        $missing = PaymentChannelCatalog::missingRequired($code, $config);
        if ($missing) {
            throw new BizException($prefix . ($testMode ? '测试/沙箱' : '正式') . '环境配置：' . implode('、', $missing));
        }
    }

    private function assertSuper(): void
    {
        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            throw new BizException('仅平台管理员可管理支付通道');
        }
    }
}