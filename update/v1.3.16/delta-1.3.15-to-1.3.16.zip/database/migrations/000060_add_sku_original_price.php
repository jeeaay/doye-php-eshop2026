<?php
use think\migration\Migrator;

/**
 * SKU 增加划线原价
 *
 * - original_price：展示用划线价（基准币种 USD），可空；空表示不展示
 * - 不做「必须大于售价」的强校验，展示层只在 original_price > price 时渲染划线样式
 * - 只向前：历史行保持 NULL，回退功能只需回退代码（列保留 NULL 无副作用）
 */
class AddSkuOriginalPrice extends Migrator
{
    /**
     * @return void
     */
    public function change()
    {
        $this->table('product_sku')
            ->addColumn('original_price', 'decimal', [
                'precision' => 10,
                'scale'     => 2,
                'null'      => true,
                'after'     => 'price',
                'comment'   => '划线原价（USD）；空=不展示，仅 original_price > price 时前台显示',
            ])
            ->update();
    }
}
