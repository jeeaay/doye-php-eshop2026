# 更新日志

本文件的版本号与根目录 `version.json` 的 `version` 字段保持一致（不带 `v` 前缀）；
git tag 带 `v` 前缀（如 `v1.0.0`）。发布端 `release:build` 生成的增量包只包含
两个 tag 之间的文件变化，因此**每个版本必须对应一个 tag**。

---

## v1.1.9 — 2026-11-06

重整后台系统与安全菜单结构，完善多语言（默认语种/模板源语言）与货币汇率管理。

### 后台菜单

- 「系统与安全」新增可折叠三级菜单「多语种设置」，其下包含多语言管理、货币与汇率、模板翻译；侧边栏与面包屑同步支持三级层级。
- 新增「AI配置」二级菜单；「更新设置」从站点设置中独立为二级菜单；站点版本切换并入「站点设置」。
- 移除「多货币展示」入口（货币与汇率页面已覆盖该能力）。

### 多语言管理

- 支持将任一已启用语种「设为默认」：默认语种即模板源语言，列表中置顶显示，始终启用且不可删除。
- 全局基准语种 `base_locale()` 改为读取 `language.is_default`，商品/页面/模板翻译、Sitemap、前台语言前缀等统一以默认语种为准。
- 移除「常用语言」快捷选择（常用语种已由数据库迁移初始化）。
- 删除与网站语言重复的「默认语种」设置项（`i18n.default_locale`），默认语种只在该页面维护。

### 模板翻译

- 目标语言复用「多语言管理」中启用的语种，并自动排除默认语种；页面展示模板源语言提示。
- 语种代码统一归一化，英语统一为 `en`（`gb` / `uk` / `en-gb` / `en-uk` / `eng` 自动纠正），覆盖保存、读取、查找与翻译入队/执行。
- 目标语言下拉与输入框样式与全局表单统一。

### 货币与汇率

- 重做汇率表格样式，基准结算币种（USD）高亮显示，不可停用、不可修改。
- 新增币种支持常用币种预设、初始汇率与符号格式配置；未填初始汇率的币种默认停用。
- 修复页面报错 `Undefined array key "sort"`。

### 模板管理

- 「文件列表」不再直接打开 JSON 接口，改为页面内弹层表格（文件路径、语种、MD5、修改时间、扫描时间）。

### 升级说明

- 无新增迁移，`db_version` 保持 `20261105112800`。
- 数据库若残留 `i18n.default_locale` 覆盖值可忽略：该配置已无读取点，默认语种以 `language.is_default` 为准。

## v1.1.8 — 2026-11-05

修复后台「模板管理」「模板翻译」页面无法正常使用的问题。

### 修复内容

- 模板管理页误用 `{include file="layout/base" /}`，导致布局中的 `{block name="content"}{/block}` 原样输出、页面重复嵌套 `<html>` 结构——改为项目统一的 `{extend name="layout/base" /}` + 块替换写法。
- 模板翻译页视图文件缺失，访问 `/admin/template-translate` 报 `template not exists`——补全该页面（模板选择、目标语言勾选、基准文件列表、单文件与批量入队）。
- 模板翻译控制器缺少 `TranslationJobService` 的命名空间导入，调用重试时会因类不存在而失败。

### 无模板站点

- 模板管理页与模板翻译页在 `templates/` 为空时显示空状态提示，不再报错；模板设为「无」时正常提示纯 API 站模式。

### 升级说明

- 无新增迁移，`db_version` 保持 `20261105112800`。

## v1.1.7 — 2026-11-05

前台视图改造为多模板可切换架构，支持 AI 队列翻译模板文字。

### 多模板系统

- 前台视图从 `app/view/site` 迁移为模板目录结构：`templates/{模板名}/` 存放模板 HTML 与 `inc`、`layout` 子目录，静态资源按模板分目录存放于 `public/{模板名}/`（js / css / img）。
- 多语言模板目录：`templates/{模板名}/{语种}/`（如 `templates/almi2026/ru/`），未翻译的页面自动回退基准模板。
- 当前前台商城界面作为首个模板 `almi2026` 完整迁移，模板内静态资源引用统一改用 `{:template_asset()}`。
- 站点设置「基础信息」新增模板选择；模板可选「无」，此时前台访问返回 404，适用于纯 API 站（只提供后台与 API、无网页界面）场景。
- 新增迁移 `000040_create_template_file`：`template_file` 表记录模板文件的修改时间与 MD5，用于检测模板更改与翻译状态。

### 模板管理（后台）

- 新增「模板管理」页面：列出已发现模板，标记已修改（MD5 变化）与已翻译的文件。
- 新增管理 API：`/admin-api/v1/templates*`、`/admin-api/v1/template-translations*`。
- 后台菜单「系统与安全 → 站点版本」移入站点设置。

### AI 模板翻译

- 翻译前先分离 HTML：可翻译文本替换为占位符，`script/style/code`、ThinkPHP 与 PHP 标签受保护不参与翻译，完成后回写并创建/修改对应语种模板文件。
- 模板翻译与商品内容翻译共用同一计划任务（`translate:work`）与同一 Redis 队列，通过分布式锁保证全局串行，共享 AI 流量限制与日预算。
- 支持手动对单个文件入队翻译，或后台批量自动翻译。

### 升级说明

- 新增迁移 `000040_create_template_file`，`db_version` 更新为 `20261105112800`。
- 无破坏性数据库变更，可直接在线升级；升级后默认使用 `almi2026` 模板，前台界面保持不变。
- 必须先经过 v1.1.6（可写目录白名单登记），在线更新链会自动按序执行，无需手工干预。

## v1.1.6 — 2026-11-05

发布准备：登记可写目录白名单，无功能变化。

### 内部变更

- `config/update.php` 的 `manage_roots` 新增 `templates` 与 `public/almi2026`，为下一版本随包分发多模板系统做准备（本版本不分发模板文件，避免旧版本白名单校验拒绝增量包）。

### 升级说明

- 无数据库迁移，`db_version` 保持 `20261103150000`，可直接在线升级。

## v1.1.4 — 2026-11-04

修复前台模板中历史遗留的 GBK 乱码（主题迁移时期编码往返损坏导致字符被吞），涉及商品详情页与首页。

### 修复内容

- 商品详情页数量步进器：减号 `−` 显示为 `鈭?` 并吞掉 `</button>` 的 `<`，导致标签未闭合——改用 HTML 实体 `&minus;`。
- 商品详情页演示商品卡标题：`™` 显示为 `鈩?` 并吞掉后续空格——改用 `&trade;`。
- 商品详情页演示商品卡价格：`£` 显示为 `拢`——改用 `&pound;`。
- 首页使命文案：破折号 `—` 显示为 `鈥攕`——改用 `&mdash;`。
- 首页首访领券弹窗脚本注释：整块中文注释乱码、换行符被吞——按原意重写并恢复块结构。

## v1.1.3 — 2026-11-04

商品支持自定义访问路径（Slug）：填写后全站链接、SEO canonical、sitemap 自动改用自定义路径，旧数字链接继续可用。

### 商品自定义路径

- 后台商品编辑页「高级」标签新增「访问路径（Slug）」区块：`custom_path` 与「注册为顶级路径」`custom_path_root`。
- 两种访问形态：`/products/laser-cutter.html`（默认），开启顶级路径后同时可用 `/laser-cutter/`（含尾斜杠）。
- 全站单一 slug、全局唯一（跨商户，应用层校验 + 数据库唯一索引双重拦截）；留空则前台沿用 `/products/{id}`。
- 旧数字路径 `/products/{id}`、`/product/{id}` 保持 200 可用，canonical 指向自定义路径（不做 301）。
- 路由解析 Redis 优先（`product:route:{path}`）+ MySQL 兜底；保存、删除、上下架即时失效缓存。
- 归一化与校验：格式 `[a-z0-9\-]+(\.html)?`、长度 ≤190、折叠大小写与多余连字符；不能是纯数字
  （含 `123.html`，会与商品 ID 路径冲突）；不能命中系统保留路径（`products`、`cart`、`sitemap.xml` 等）
  或与 8 个内置页面 / 内容单页 slug 重名。
- 首页 Banner 商品 CTA、商品列表卡片、sitemap.xml、详情页 canonical / hreflang 全部改用自定义路径。

### 管理 API / 文档

- `POST/PUT /admin-api/v1/products` 支持 `custom_path`、`custom_path_root` 字段，`GET /products/:id` 返回同字段。
- 同步更新 `docs/admin-api.md` 与 `public/admin-api/openapi.yaml`（字段含机器可读 `pattern` 约束）。

### 升级说明

- 新增迁移 `000039_add_product_custom_path`，`db_version` 更新为 `20261103150000`。
- 无破坏性数据库变更，可直接在线升级。
- 未填写自定义路径的商品行为完全不变（继续使用数字路径）。

---

## v1.1.0 — 2026-11-02

初步功能计划完成里程碑：商品管理升级为标签式编辑，并补齐商品级 SEO 能力。

### 商品管理

- 后台商品新建/编辑页改为标签式布局：**商品内容**（默认）、**多语言**、**高级**。
- 启用多语言后显示「多语言」标签，原页面底部的多语种编辑区整体移入该标签。
- 新增「高级」标签：SEO 标题、SEO 描述、SEO 关键词、Tags、发布时间、搜索索引（`noindex`）。
- `product` 表新增 `seo_title`、`seo_description`、`seo_keywords`、`tags_json`、`published_at`、`seo_noindex`（迁移 `000038`）。
- 标签支持数组或逗号分隔字符串，保存时自动去重、去空并限制数量。

### 前台 SEO

- 商品详情页 `<title>` 按「商品名称 - 副标题 - SEO 标题」拼接，缺失项自动省略。
- 商品详情页输出 SEO `description` 与 `keywords`；关键词为空时回退 Tags。
- `noindex` 商品输出 `robots` meta，并从 `sitemap.xml` 排除。
- 多语种下 SEO 字段优先取当前语种译文，缺失时回退主表。

### 管理 API / 文档

- 商品管理 API 直接支持新增字段（保存与详情）。
- 同步更新 `docs/admin-api.md` 与 `public/admin-api/openapi.yaml`。

### 升级说明

- 新增迁移 `000038_add_product_seo_fields`，`db_version` 更新为 `20261102143000`。
- 无破坏性数据库变更，可直接在线升级。
- 本版本作为初步功能计划完成的里程碑版本。

---

## v1.0.9 — 2026-11-02

修复 PHP 8.5 下命令行迁移/Worker 被废弃提示中断的问题。

### 修复

- `AppService` 在 CLI 与生产模式（`APP_DEBUG=false`）忽略 `E_DEPRECATED` / `E_USER_DEPRECATED`：
  PHP 8.5 起 `curl_close`、`$http_response_header` 等会触发废弃提示，
  ThinkPHP 默认把 `E_ALL` 转成异常，导致 `php think migrate:run` 直接中断。
- 覆盖 `migrate:run`、`translate:work`、`currency:sync` 等 CLI 命令，以及生产环境 HTTP 请求；
  开发模式（`APP_DEBUG=true`）仍保留废弃提示。
- 该问题会导致 1.0.6 → 1.0.7 升级时数据库迁移没有完成，
  随后切换站点版本报 `Table 'xxx.language' doesn't exist`。

### 升级说明

- 无新增迁移，`db_version` 保持 `20261102103000`。
- 升级到 1.0.9 后，更新器在迁移步骤会自动应用此修复。
- 如果当前已经在 1.0.8 且缺少 `language` / `currency` 表，升级后仍需执行一次：
  ```bash
  php think migrate:run
  ```
  以补齐 1.0.7 的 `000033`–`000037`。
- 临时绕过方式（未升级时）：使用 PHP 8.2/8.3/8.4 CLI，或用
  `runtime/migrate-safe.php` 在 CLI 中临时忽略废弃提示后执行迁移。

---

## v1.0.8 — 2026-11-02

修复 1.0.6 → 1.0.7 升级后「站点版本」页面无法选择版本的问题，并兼容历史数据。

### 修复

- 修复 `.edition-modal-mask` 的 `display:flex` 覆盖 HTML `hidden`：升级后进入页面会直接弹出「切换站点版本」，遮罩挡住版本卡片，且无法关闭。
- 弹窗支持「取消」、点击遮罩、`Esc` 关闭。
- 未初始化（没有 `site.edition`）时不再默认锁死为国际版：
  - 页面显示「未初始化」提示；
  - 两张版本卡片均可选择，按钮文字为「使用国内版（CNY）」「使用国际版（USD）」；
  - 根据已启用支付渠道给出建议：微信/支付宝 → 国内版，Stripe/PayPal → 国际版。
- 1.0.6 及更早版本升级的站点，即使已有历史订单，也允许**一次性**选择历史数据所属版本。
- 首次选择按版本回填历史订单/支付单币种：
  - 国内版：`charge_currency=CNY`，同时回填 `display_currency=CNY`、`display_rate=1`、`display_total_amount=total_amount`；
  - 国际版：`charge_currency=USD`。
- 初始化完成后恢复原有守卫：有历史订单时禁止再次切换。
- 首次选择不再被「当前版本默认 international」短路，确保设置真正写入数据库。

### 文档

- 更新 `README.md`、`docs/site-edition-mode.md`、`docs/i18n-multicurrency-checklist.md`、`docs/admin-api.md`、`public/admin-api/openapi.yaml`。
- 补充未初始化、历史订单回填、弹窗关闭与验证步骤。

### 升级说明

- 无新增迁移，保持 `db_version=20261102103000`。
- 升级后请先进入 `/admin/edition` 完成版本选择，再处理新订单。

---

## v1.0.7 — 2026-11-02

多语种、多货币展示、AI 翻译与站点版本切换。

### 多语言

- 新增 `language` 表与 `product/category/brand/page_translation` 四张翻译副表；主表保留基准语言，其他语种按 `(实体 id, lang_code)` 关联。
- 预置 10 种语种：`en`、`zh`、`ru`、`fr`、`ar`、`ja`、`it`、`de`、`pt`、`es`。
- 语言 URL：默认语种无前缀，其他语种 `/ru/...`、`/zh/...`；首次访问按 `Accept-Language` 302 到对应前缀，爬虫不跳转。
- 前台逐字段回退基准语言；商品/分类/品牌/单页标题、详情、规格与 SKU 文案均支持翻译。
- 新增 10 份静态文案语言包 `app/lang/{locale}/site.php`。
- 商品编辑页新增语种标签、发布状态、人工校对标记与「清空回退基准语言」。

### AI 翻译

- 新增 OpenAI 兼容 Provider，后台填写 `base_url` / `api_key` / `model`。
- 新增 `translation_job` 任务表、`translate:work` worker、`translate:backfill` 批量补全。
- 支持入队去重、`source_hash` 跳过、指数退避、失败转 `dead`、人工重试、日预算与成本估算。
- 商品保存可自动入队；AI 结果默认自动发布，HTML 统一走白名单过滤。
- 后台商品页「AI 翻译」按钮与商品列表「批量补全翻译」入口。

### 多货币展示

- 新增 `currency` 与 `currency_rate_log` 表；订单/支付/退款/结算仍只使用基准币种。
- 新增 `currency:sync` 每日汇率同步（`open.er-api.com` 主、`fawazahmed0` 备）与 `currency:selftest`。
- 汇率异常检测：无效值或单日变动超过阈值（默认 10%）拒绝更新、保留旧值并告警，不做上下限钳制。
- 前台按展示币种输出参考价；JPY 等零小数币种正确取整。
- 后台新增「财务 → 货币与汇率」页与管理 API。

### 订单与支付

- 订单新增 `display_currency/display_rate/display_total_amount/display_rate_at` 展示快照。
- 订单/支付单新增 `charge_currency`，记录金额所属币种（国际版 USD、国内版 CNY）。
- 结算页显示「基准币种实付 + ≈ 本币参考价」，并明确提示实际扣款币种与发卡行换汇费。
- Stripe / PayPal 固定 USD；微信支付 / 支付宝保留 CNY；支付渠道按站点版本过滤。
- 支付回调金额校验按 `order_pay.charge_currency` 比对。

### 站点版本

- 新增「系统与安全 → 站点版本」（`/admin/edition`），支持国内版 / 国际版两套独立部署。
- 国内版：中文基准 + CNY + 小程序 + 微信/支付宝，关闭多语言/多货币/汇率同步。
- 国际版：英文基准 + USD + 独立站 + 多语言/多货币 + Stripe/PayPal。
- 切换需勾选备份确认并输入 `SWITCH`；有历史订单时禁止直接切换。
- 新增 `GET/PUT /admin-api/v1/edition`。

### SEO / RTL

- 输出 canonical、全部启用语种 `hreflang` 与 `x-default`。
- 新增 `/sitemap.xml`，包含商品、分类、单页与政策页，并带全部语种备选。
- 阿拉伯语 `dir="rtl"` 基础样式。

### 数据库与升级

- 新增迁移 `000033`–`000037`：翻译表、币种表、翻译任务表、订单展示快照、订单/支付币种。
- 迁移均为新增表/新增列，非破坏性；升级后执行 `php think migrate:run`。
- 默认仍为国际版、多语言/多货币开关关闭；需要在后台按部署形态开启。
- 生产环境请配置 CA（`curl.cainfo` / `CURL_CA_BUNDLE`），否则 AI 与汇率 HTTPS 请求会失败。
- AI 翻译需要常驻 `php think translate:work`；汇率同步建议每日 cron `php think currency:sync`。

### 文档

- 新增 `docs/i18n-multicurrency.md`、`docs/i18n-multicurrency-checklist.md`、`docs/site-edition-mode.md`。
- 同步 `docs/admin-api.md` 与 `public/admin-api/openapi.yaml`。

---

## v1.0.6 — 2026-10-30

安全防护与后台菜单整合。

### 安全防护（新增）

- IP 黑白名单：支持单个 IP、CIDR、`192.168.1.*` 通配；手动 / 探针自动 / UA 自动三种来源，支持过期时间、命中次数、启停。
- 客户端真实 IP：默认取 `REMOTE_ADDR`；开启「信任反向代理请求头」且来源命中可信代理地址后，按可编辑的「可信请求头」顺序读取（默认 `CF-Connecting-IP` / `X-Real-IP` / `X-Forwarded-For`，后台可自行增删、调整优先级）。
- 探针自动加黑：内置 `.env`、`.git`、`phpmyadmin`、`wp-login.php`、备份/配置文件等特征，叠加后台自定义规则（精确 / 前缀 / 包含 / 正则）；同一 IP 在统计窗口内达到阈值后自动封禁。恶意 UA（sqlmap、nikto、curl 等）可直接封禁，默认关闭。
- 拦截日志：记录黑名单命中、探针扫描、恶意 UA 与自动封禁；支持筛选、清理与按天保留。
- 后台入口：系统设置 → 安全设置（`/admin/security`），含 6 个标签；仅平台超管可见。
- 管理 API：`/admin-api/v1/security/*`（概览 / 设置 / 黑白名单 / 探针规则 / 拦截日志 / 缓存刷新）。
- 运行时缓存全部走 Redis：设置 10 分钟、规则合并为 1 个 key（120 秒）、表就绪标记 1 小时；正常请求不查数据库，后台写操作后立即失效。
- 应急命令：`php think security:unblock --list` / `php think security:unblock 1.2.3.4`。
- 新增迁移 `000032_create_security_tables.php`：`security_ip_rule`、`security_path_rule`、`security_event`（仅新增表，非破坏性）。
- 新增设置分组 `security.*`（`config/setting.php`），并新增 `config/security.php` 代码级规则（内置探针特征、放行前缀、默认请求头）。
- 客户端 IP 解析统一供审计日志、限流、管理员登录、留言与请求日志使用（`client_ip()`）。

### 后台菜单整合

- 左侧菜单从 20 个平铺入口改为 6 个一级分组：工作台、商品与内容、交易与营销、财务、客户与账号、系统与安全。
- 单开手风琴：当前页所在分组自动展开，展开状态写入 `localStorage`；分组内有当前页时一级菜单显示高亮条。
- 账户设置 / 密钥管理移入右上角头像下拉，并补充「退出登录」。
- 顶部标题改为面包屑（如「交易与营销 / 订单管理」）。
- 菜单改为配置驱动：新增 `config/admin_menu.php`，新增页面只需登记一条，`layout/base.html` 自动按角色过滤渲染。
- `config/update.php` 的可写白名单新增 `public/admin-api`，为后续版本随包更新管理 API 文档做准备（本版暂不分发该文件，避免旧版本白名单校验拒绝整个增量包）。

### 升级说明

- 升级后请到「系统设置 → 安全设置」确认开关：默认启用总开关（仅拦截黑名单）、探针自动封禁与恶意 UA 封禁默认关闭。
- 反向代理 / CDN 场景请先填写「可信代理地址」，再开启「信任反向代理请求头」。
- 菜单调整不涉及路由与业务接口；如出现问题可单独回退 `app/admin/view/layout/base.html`、`app/admin/controller/AdminBaseController.php`、`config/admin_menu.php`。

---

## v1.0.5 — 2026-10-29

升级流程对 PHP 废弃告警免疫。

- `UpdateService` 在 check / plan / runNextStep / retry / rollback 期间临时忽略 `E_DEPRECATED` / `E_USER_DEPRECATED`，其余错误仍交给框架处理（非废弃告警照常抛出）。
- 目的：避免「客户端代码比修复版本旧」时被废弃 API 卡死——例如 1.0.2 的 `HttpClient` 在下载 1.0.3 的包时先触发 `$http_response_header` 废弃，导致永远升不上去。
- 已用模拟 ThinkPHP 处理器验证：废弃告警被吞掉、`E_USER_WARNING` 仍然抛异常。

---

## v1.0.4 — 2026-10-29

修复容器 / FPM 环境下数据库迁移执行失败。

- `UpdateMigrator` 不再直接使用 `PHP_BINARY`：FPM 环境下它是 `php-fpm`，执行 `php-fpm think migrate:run` 只会打印 FPM 的 usage，导致步骤失败。
- 新增 CLI 二进制探测：显式配置（`config/update.php` 的 `php_cli` 或环境变量 `UPDATE_PHP_CLI`）→ CLI SAPI 时用 `PHP_BINARY` → `PHP_BINDIR/php` → `php-fpm` 同级的 `php` → PATH 扫描；每个候选都用 `-r` 探针验证，名字含 `fpm` 的直接跳过。
- 探测不到可信 CLI 时自动回退到进程内 `think\Console::call('migrate:run')`（迁移幂等，重复执行安全）。

---

## v1.0.3 — 2026-10-29

兼容 PHP 8.5：`$http_response_header` 已被废弃。

- 无 curl 时的 stream 兜底分支改用 `http_get_last_response_headers()`（PHP 8.5+），旧版本才回退到局部变量；涉及 `HttpClient::downloadByStream()`、`HttpClient::streamRequest()` 与 `release:verify`。
- 说明：ThinkPHP 会把 deprecation 抛成 `ErrorException`，所以在 PHP 8.5 上任何一处废弃 API 都会让「检查更新」直接失败。

---

## v1.0.2 — 2026-10-29

兼容 PHP 8.5：移除已废弃的 `curl_close()`；本地测试源改为显式开关。

- 移除 `app/` 下全部 `curl_close($ch)` 调用（PHP 8.0 起为空操作，8.5 起废弃）。ThinkPHP 的错误处理器会把 deprecation 转成 `ErrorException`，在 PHP 8.5 上会让「检查更新」直接失败：`Gitee/GitHub：Function curl_close() is deprecated`。
- `LocalSource` 不再由 `app_debug` 推导可用性，改为显式开关（环境变量 `UPDATE_LOCAL_SOURCE=1` 或 `config/update.php` 的 `sources.local.enabled`），避免生产站点误读本地路径、并在错误信息里暴露服务器绝对路径。
- `release:build` 默认生成 `update/` 兼容镜像，兼容仍使用旧地址（`/raw/main/update/update.json`）的 v1.0.0 站点；`--no-legacy-mirror` 可关闭。

---

## v1.0.1 — 2026-10-29

后台更新入口合并进系统设置，并统一后台滚动条样式。

- 后台更新页并入「系统设置 → 更新设置」（`/admin/system?tab=update`）：版本卡片、步骤进度、冲突清单、重试 / 回滚与历史记录都在设置页内完成；左侧菜单去掉独立的「系统更新」，旧地址 `/admin/update` 直接跳转到该标签。
- 新增页面接口 `GET /admin/update/overview`：更新面板首屏数据（当前版本、检查结果、历史、未完成批次）按需加载，避免打开设置页就被分发源超时拖慢；管理 API `/admin-api/v1/updates/*` 保持不变。
- 统一后台滚动条样式（`public/static/css/style.css`）：Windows 传统滚动条改为 8px 细条、圆角滑块、透明轨道，深色侧边栏使用浅色滑块；`.page-content` 加 `scrollbar-gutter: stable`，滚动条出现 / 消失时内容不再横向跳动。
- 梳理发布流程文档：`update/` 是独立分发仓库（仓库根 = 该目录），`release:build --push` 只推分发分支，不推源码提交与 tag；首个 tag 没有上一版，基线只能手工部署。

---

## v1.0.0 — 2026-10-28

基线版本：引入在线增量更新。

- 新增根目录 `version.json` 作为版本唯一来源（`version` / `released_at` / `db_version` / `php_min`）。
- 新增 `config/update.php`（技术参数：分发源 URL 模板、验签公钥、超时、可写目录白名单、保护路径）。
- 新增 `config/site.php` 的 `update` 分组与后台「系统设置 → 系统更新」（源优先级、仓库坐标、分支、备份份数、维护窗口、私有仓库 token）。
- 新增 `site_update` / `site_update_step` 两张表（更新批次与步骤状态），对应迁移 `000031_create_site_update.php`。
- 新增 `release:build` / `release:verify` / `release:keygen` / `update:selftest` 命令。
- `composer.lock` 纳入版本库，用于可靠判断依赖（`vendor`）是否变更。