<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\lib\RedisCache;
use app\common\model\Language;

/**
 * 语种注册表读取（带缓存）
 */
class LanguageService
{
    /**
     * 常用语种预设：code => [英文名, 原生名, 国旗]
     * 供「多语言管理」添加语种与「模板翻译」选择目标语言时快速填写
     */
    public const COMMON = [
        'en' => ['English',    'English',   '🇬🇧'],
        'zh' => ['Chinese',    '中文',       '🇨🇳'],
        'es' => ['Spanish',    'Español',   '🇪🇸'],
        'fr' => ['French',     'Français',  '🇫🇷'],
        'de' => ['German',     'Deutsch',   '🇩🇪'],
        'it' => ['Italian',    'Italiano',  '🇮🇹'],
        'pt' => ['Portuguese', 'Português', '🇵🇹'],
        'ru' => ['Russian',    'Русский',   '🇷🇺'],
        'ja' => ['Japanese',   '日本語',     '🇯🇵'],
        'ar' => ['Arabic',     'العربية',   '🇸🇦'],
    ];

    private const CACHE_KEY = 'site:languages';
    private const CACHE_TTL = 600;

    /**
     * 语言代码别名归一化，英语统一使用 en
     *
     * @param string $code 语言代码
     * @return string
     */
    public static function normalizeCode(string $code): string
    {
        $code = strtolower(trim(str_replace('_', '-', $code)));

        return match ($code) {
            'gb', 'uk', 'en-gb', 'en-uk', 'eng' => 'en',
            default => $code,
        };
    }

    /**
     * 启用的语种列表
     *
     * @return array<int,array<string,mixed>>
     */
    public function enabled(): array
    {
        $rows = RedisCache::remember(self::CACHE_KEY, self::CACHE_TTL, static function (): array {
            try {
                return Language::enabled()->toArray();
            } catch (\Throwable $e) {
                return [];
            }
        });

        // 历史数据兼容：英语统一显示为 en，避免出现 GB / UK 等别名
        $rows = array_map(static function ($row): array {
            $row = (array) $row;
            $row['code'] = self::normalizeCode((string) ($row['code'] ?? ''));
            return $row;
        }, $rows);

        if (is_domestic_edition()) {
            $base = base_locale();
            $filtered = array_values(array_filter($rows, static function ($row) use ($base): bool {
                return strtolower((string) ($row['code'] ?? '')) === $base;
            }));
            if ($filtered) {
                return $filtered;
            }
        }

        return $rows;
    }

    /**
     * 按 code 查找启用语种（大小写不敏感）
     *
     * @param string $code 语言短码
     * @return array<string,mixed>|null
     */
    public function find(string $code): ?array
    {
        $code = self::normalizeCode($code);
        if ($code === '') {
            return null;
        }
        foreach ($this->enabled() as $language) {
            if (strtolower((string) $language['code']) === $code) {
                return $language;
            }
        }
        return null;
    }

    /**
     * 默认语种
     *
     * @return array<string,mixed>
     */
    public function default(): array
    {
        $base = base_locale();
        foreach ($this->enabled() as $language) {
            if (strtolower((string) $language['code']) === $base) {
                return $language;
            }
        }
        foreach ($this->enabled() as $language) {
            if ((int) ($language['is_default'] ?? 0) === 1) {
                return $language;
            }
        }
        $all = $this->enabled();
        return $all[0] ?? [
            'code'             => $base,
            'name'             => $base === 'zh' ? '中文' : '英语',
            'native_name'      => $base === 'zh' ? '中文' : 'English',
            'direction'        => 'ltr',
            'default_currency' => base_currency_code(),
            'is_default'       => 1,
            'status'           => 1,
        ];
    }

    /**
     * 清除缓存（后台保存语种后调用）
     */
    public function flush(): void
    {
        RedisCache::forget(self::CACHE_KEY);
    }
}