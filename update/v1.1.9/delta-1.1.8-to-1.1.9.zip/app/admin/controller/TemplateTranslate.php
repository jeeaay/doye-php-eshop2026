<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\service\LanguageService;
use app\common\service\TemplateManager;
use app\common\service\TranslationJobService;
use app\common\support\AppContext;
use think\facade\View;

/**
 * 模板翻译管理（平台超管专用）
 *
 * AI 翻译模板 HTML 中的硬编码文字。依赖 TemplateTranslationService（Phase 4 实现）。
 */
class TemplateTranslate extends AdminBaseController
{
    public function index()
    {
        $this->assertSuper();
        $this->assignActiveMenu('template-translate');

        $manager = new TemplateManager();
        $templates = $manager->listTemplates();

        // 统计每个模板的翻译状态
        $templateStats = [];
        foreach ($templates as $tpl) {
            $templateStats[$tpl['name']] = [
                'base_files' => array_filter($tpl['langs'], fn($l) => $l === 'base') ? $tpl['files'] : 0,
                'langs'      => array_values(array_filter($tpl['langs'], fn($l) => $l !== 'base')),
            ];
        }

        // 网站已启用的语言列表（来自数据库 language 表）
        $siteLanguages = [];
        $defaultLanguage = [
            'code'        => base_locale(),
            'name'        => base_locale(),
            'native_name' => base_locale(),
        ];
        try {
            $service = new LanguageService();
            $siteLanguages = $service->enabled();
            $defaultLanguage = $service->default();
        } catch (\Throwable $e) {
            $siteLanguages = [];
        }

        // 默认语种即模板源语言，不再作为翻译目标
        $defaultCode = strtolower((string) ($defaultLanguage['code'] ?? base_locale()));
        $siteLanguages = array_values(array_filter($siteLanguages, static function ($language) use ($defaultCode): bool {
            return strtolower((string) ($language['code'] ?? '')) !== $defaultCode;
        }));

        // 常用语言预设
        $commonLanguages = LanguageService::COMMON;

        View::assign([
            'templates'          => $templates,
            'templateStats'      => $templateStats,
            'templateStatsJson'  => json_encode($templateStats, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'siteLanguages'      => $siteLanguages,
            'siteLanguagesJson'  => json_encode($siteLanguages, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'defaultLanguage'    => $defaultLanguage,
            'commonLanguages'    => $commonLanguages,
            'commonLanguagesJson'=> json_encode($commonLanguages, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ]);

        return View::fetch();
    }

    /**
     * 发起单个文件翻译（AJAX）
     */
    public function enqueue()
    {
        try {
            $this->assertSuper();
            $input = $this->request->post();
            $template = trim((string) ($input['template'] ?? ''));
            $path = trim((string) ($input['path'] ?? ''));
            $targetLang = LanguageService::normalizeCode((string) ($input['target_lang'] ?? ''));

            if ($template === '' || $path === '' || $targetLang === '') {
                throw new BizException('参数不完整');
            }
            if ($targetLang === strtolower(base_locale())) {
                throw new BizException('默认语种即模板源语言，无需翻译');
            }

            $jobIds = (new \app\common\service\TemplateTranslationService())->enqueue($template, $path, $targetLang);
            if ($jobIds === []) {
                return json(['code' => 0, 'message' => '无需翻译（已是最新或无可翻译文本）', 'data' => null]);
            }
            return json(['code' => 0, 'message' => '翻译任务已入队', 'data' => ['job_ids' => $jobIds]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 批量翻译所有修改过的文件（AJAX）
     */
    public function enqueueModified()
    {
        try {
            $this->assertSuper();
            $input = $this->request->post();
            $template = trim((string) ($input['template'] ?? ''));
            $langs = $input['langs'] ?? [];
            if (is_string($langs)) {
                $langs = array_values(array_filter(array_map('trim', explode(',', $langs))));
            }
            $langs = array_values(array_filter(array_map(static function ($code) {
                return LanguageService::normalizeCode((string) $code);
            }, (array) $langs), static function ($code) {
                return $code !== strtolower(base_locale());
            }));

            $result = (new \app\common\service\TemplateTranslationService())->enqueueModified(
                $template,
                array_values((array) $langs)
            );

            return json(['code' => 0, 'message' => '批量入队完成', 'data' => $result]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 重试失败的翻译任务（AJAX）
     */
    public function retry()
    {
        try {
            $this->assertSuper();
            $jobId = (int) $this->request->post('id', 0);
            if ($jobId <= 0) {
                throw new BizException('参数不完整');
            }
            (new TranslationJobService())->retry($jobId);
            return json(['code' => 0, 'message' => '任务已重新入队', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    private function assertSuper(): void
    {
        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            throw new BizException('仅平台超级管理员可访问');
        }
    }
}
