<?php

/**
 * 系统设置字段注册表
 *
 * 后台「系统设置」页面的结构来源：分组 -> 字段 -> 控件定义。
 * 字段的「值」统一通过 site_config($key) 读取（数据库 setting 表覆盖 config/site.php 的默认值），
 * 因此新增一个设置项只需在此登记，不需要写数据库迁移。
 *
 * 字段可用属性：
 *   label       控件标签
 *   type        text / textarea / number / bool / select / password / readonly
 *   placeholder 输入提示
 *   help        字段下方的说明文字
 *   options     type=select 时的可选值 ['value' => '显示文案']
 *   secret      true 表示敏感项（后台不回显已保存的值，留空表示不修改）
 *   rows        type=textarea 时的行数
 */
return [
    'groups' => [
        'basic' => [
            'title'  => '基础信息',
            'desc'   => '站点名称、货币与公告条等全局展示信息',
            'fields' => [
                'brand.name'      => ['label' => '站点名称', 'type' => 'text', 'placeholder' => 'Almi'],
                'brand.logo_text' => ['label' => 'Logo 文字', 'type' => 'text', 'placeholder' => 'Almi'],
                'brand.tagline'   => ['label' => '站点标语', 'type' => 'text', 'placeholder' => 'Smart, durable tools for an organised home'],
                'announcement'    => ['label' => '顶部公告条', 'type' => 'text', 'placeholder' => 'FREE DELIVERY ON ORDERS OF £80 OR MORE'],
                'currency.code'   => ['label' => '货币代码', 'type' => 'text', 'placeholder' => 'GBP'],
                'currency.symbol' => ['label' => '货币符号', 'type' => 'text', 'placeholder' => '£'],
                'region_label'    => ['label' => '地区选择器文案', 'type' => 'text', 'placeholder' => 'United Kingdom / GBP'],
            ],
        ],

        'seo' => [
            'title'  => '首页 SEO',
            'desc'   => '首页的标题、描述与关键词，直接影响搜索引擎收录与广告落地页质量',
            'fields' => [
                'seo.title'       => ['label' => '首页标题', 'type' => 'text', 'placeholder' => 'Almi — Smart, durable tools for an organised home'],
                'seo.description' => ['label' => '首页描述', 'type' => 'textarea', 'rows' => 3],
                'seo.keywords'    => ['label' => '首页关键词', 'type' => 'textarea', 'rows' => 2, 'help' => '多个关键词用英文逗号分隔'],
            ],
        ],

        'contact' => [
            'title'  => '联系方式',
            'desc'   => '页脚与联系页展示的客服信息',
            'fields' => [
                'contact.email'   => ['label' => '客服邮箱', 'type' => 'text', 'placeholder' => 'service@example.com'],
                'contact.support' => ['label' => '支持邮箱', 'type' => 'text', 'placeholder' => 'service@example.com'],
                'contact.phone'   => ['label' => '联系电话', 'type' => 'text'],
                'contact.hours'   => ['label' => '服务时间', 'type' => 'text', 'placeholder' => 'Mon - Fri: 9:00 AM - 6:00 PM (GMT)'],
                'contact.address' => ['label' => '公司地址', 'type' => 'text'],
                'contact.country' => ['label' => '所在国家/地区', 'type' => 'text'],
            ],
        ],

        'shipping' => [
            'title'  => '配送说明',
            'desc'   => '免运费文案，展示在商品页与购物车页',
            'fields' => [
                'shipping.free_shipping_text' => ['label' => '免运费短文案', 'type' => 'text'],
                'shipping.free_shipping_note' => ['label' => '免运费说明', 'type' => 'textarea', 'rows' => 2],
            ],
        ],

        'mail' => [
            'title'  => '邮件服务',
            'desc'   => '用于发送登录验证码、订单通知等邮件。关闭后系统只写日志不发信。',
            'fields' => [
                'mail.enabled'         => ['label' => '启用邮件发送', 'type' => 'bool'],
                'mail.from'            => ['label' => '发件人邮箱', 'type' => 'text', 'placeholder' => 'no-reply@example.com'],
                'mail.from_name'       => ['label' => '发件人名称', 'type' => 'text', 'placeholder' => 'Almi'],
                'mail.notify_to'       => ['label' => '客服通知收件邮箱', 'type' => 'text', 'help' => '留言、下单等事件的通知接收地址'],
                'mail.smtp.host'       => ['label' => 'SMTP 服务器', 'type' => 'text', 'placeholder' => 'smtp.example.com'],
                'mail.smtp.port'       => ['label' => 'SMTP 端口', 'type' => 'number', 'placeholder' => '465'],
                'mail.smtp.encryption' => [
                    'label'   => '加密方式',
                    'type'    => 'select',
                    'options' => ['ssl' => 'SSL（465）', 'tls' => 'STARTTLS（587）', 'none' => '不加密（25）'],
                ],
                'mail.smtp.username'   => ['label' => 'SMTP 账号', 'type' => 'text'],
                'mail.smtp.password'   => ['label' => 'SMTP 密码/授权码', 'type' => 'password', 'secret' => true, 'help' => '留空表示不修改已保存的密码'],
            ],
        ],

        'social' => [
            'title'  => '社交链接',
            'desc'   => '页脚社交图标跳转地址，留空则不显示该图标',
            'fields' => [
                'social.facebook'  => ['label' => 'Facebook', 'type' => 'text'],
                'social.instagram' => ['label' => 'Instagram', 'type' => 'text'],
                'social.twitter'   => ['label' => 'X / Twitter', 'type' => 'text'],
                'social.pinterest' => ['label' => 'Pinterest', 'type' => 'text'],
                'social.tiktok'    => ['label' => 'TikTok', 'type' => 'text'],
            ],
        ],

        'advanced' => [
            'title'  => '其他设置',
            'desc'   => '列表分页、登录安全等进阶参数。后续新增的能力也会归入本组。',
            'fields' => [
                'per_page'          => ['label' => '商品列表每页数量', 'type' => 'number', 'placeholder' => '24'],
                'auth.dev_show_code' => [
                    'label' => '开发模式：回显登录验证码',
                    'type'  => 'bool',
                    'help'  => '生产环境必须关闭，否则前台登录接口会直接返回验证码',
                ],
                'theme'             => ['label' => '前台主题目录', 'type' => 'readonly', 'help' => '主题切换尚未开放，需在代码中调整'],
            ],
        ],

        'update' => [
            'title'  => '更新设置',
            'desc'   => '在线增量更新的开关。检查版本、执行升级与查看历史在本标签下方；仓库地址、分发分支与技术参数（公钥、可写目录、超时）固定写在 config/update.php，后台不可修改。',
            'fields' => [
                'update.enabled'             => ['label' => '启用在线更新', 'type' => 'bool'],
                'update.backup_keep'         => ['label' => '备份保留批次', 'type' => 'number', 'placeholder' => '3'],
                'update.maintenance_enabled' => [
                    'label' => '升级期间开启维护窗口',
                    'type'  => 'bool',
                    'help'  => '安装期间前台返回 503，后台与管理 API 放行',
                ],
            ],
        ],
    ],
];
