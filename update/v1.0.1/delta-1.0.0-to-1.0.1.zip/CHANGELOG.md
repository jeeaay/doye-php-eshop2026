# 更新日志

本文件的版本号与根目录 `version.json` 的 `version` 字段保持一致（不带 `v` 前缀）；
git tag 带 `v` 前缀（如 `v1.0.0`）。发布端 `release:build` 生成的增量包只包含
两个 tag 之间的文件变化，因此**每个版本必须对应一个 tag**。

---

## v1.0.1 — 2026-10-29

后台更新入口合并进系统设置，并统一后台滚动条样式。

- 后台更新页并入「系统设置 → 更新设置」（`/admin/system?tab=update`）：版本卡片、步骤进度、冲突清单、重试 / 回滚与历史记录都在设置页内完成；左侧菜单去掉独立的「系统更新」，旧地址 `/admin/update` 直接跳转到该标签。
- 新增页面接口 `GET /admin/update/overview`：更新面板首屏数据（当前版本、检查结果、历史、未完成批次）按需加载，避免打开设置页就被分发源超时拖慢；管理 API `/admin-api/v1/updates/*` 保持不变。
- 统一后台滚动条样式（`public/static/css/style.css`）：Windows 传统滚动条改为 8px 细条、圆角滑块、透明轨道，深色侧边栏使用浅色滑块；`.page-content` 加 `scrollbar-gutter: stable`，滚动条出现 / 消失时内容不再横向跳动。
- 梳理发布流程文档：`update/` 是独立分发仓库（仓库根 = 该目录），`release:build --push` 只推分发分支，不推源码提交与 tag；首个 tag 没有上一版，基线只能手工部署。

---

## v1.0.0 — 2026-10-28

基线版本：引入在线增量更新。

- 新增根目录 `version.json` 作为版本唯一来源（`version` / `released_at` / `db_version` / `php_min`）。
- 新增 `config/update.php`（技术参数：分发源 URL 模板、验签公钥、超时、可写目录白名单、保护路径）。
- 新增 `config/site.php` 的 `update` 分组与后台「系统设置 → 系统更新」（源优先级、仓库坐标、分支、备份份数、维护窗口、私有仓库 token）。
- 新增 `site_update` / `site_update_step` 两张表（更新批次与步骤状态），对应迁移 `000031_create_site_update.php`。
- 新增 `release:build` / `release:verify` / `release:keygen` / `update:selftest` 命令。
- `composer.lock` 纳入版本库，用于可靠判断依赖（`vendor`）是否变更。