<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\exception\BizException;
use app\common\model\SiteUpdate;
use app\common\model\SiteUpdateStep;
use app\common\release\ManifestSigner;
use app\common\service\update\SourceFactory;
use app\common\service\update\UpdateInstaller;
use app\common\service\update\UpdateMigrator;
use app\common\service\update\UpdatePackage;
use app\common\service\update\UpdateSourceInterface;
use app\common\support\AppContext;
use think\facade\Cache;
use think\facade\Db;
use think\facade\Log;

/**
 * 在线增量更新编排服务（唯一入口）
 *
 * 后台页面（/admin/update）与管理 API（/admin-api/v1/updates/*）都只能调用这里，
 * 不允许任何一方自己下载、解压或写文件（AGENTS.md 强制成对 + design.md §1）。
 *
 * 生命周期：
 *   check()        只读：拉清单 → 验签 → 定位链 → 给出可更新性（带 10 分钟缓存）
 *   plan()         只读 + 落库：强刷清单 → 探测资产 → 校验磁盘/权限/能力 → 建批次
 *   runNextStep()  一次请求只做一步：下载 → 验哈希 → 解压 → 备份 → 覆盖 → 迁移 → 清缓存 → 写版本
 *   retry()        回滚失败步 → 重跑同一步（幂等）
 *   rollback()     整批倒序还原文件 + version.json
 *
 * 并发：`runtime/update/.lock` 的 flock 非阻塞独占；拿不到直接报「另一个更新任务正在执行」。
 * 维护窗口：执行期间维护 `runtime/update/applying.lock`（由 P4 的中间件读取）。
 */
class UpdateService
{
    /** 并发锁（相对项目根） */
    private const LOCK_REL = 'runtime/update/.lock';

    /** 维护窗口标记（相对项目根） */
    private const APPLYING_REL = 'runtime/update/applying.lock';

    /** 清单缓存键前缀（后接当前版本） */
    private const MANIFEST_CACHE_PREFIX = 'update:manifest:';

    /** 单步预算里 vendor 包的保守占用（10MB） */
    private const VENDOR_RESERVE = 10485760;

    /** 磁盘安全余量（32MB） */
    private const DISK_RESERVE = 33554432;

    private string $root;

    private UpdatePackage $package;

    private UpdateInstaller $installer;

    /** @var resource|null flock 句柄 */
    private $lockHandle = null;

    /**
     * @param string|null $root 项目根目录，默认取 app()->getRootPath()
     */
    public function __construct(?string $root = null)
    {
        $root = $root ?? (string) app()->getRootPath();
        $this->root      = rtrim(str_replace('\\', '/', $root), '/');
        $this->package   = new UpdatePackage();
        $this->installer = new UpdateInstaller($this->root);
    }

    // ==================================================================
    // 查询
    // ==================================================================

    /**
     * 当前版本（读 version.json；文件缺失或解析失败返回 null）
     *
     * @return array<string,mixed>|null
     */
    public function currentVersion(): ?array
    {
        $path = $this->root . '/version.json';
        if (!is_file($path)) {
            return null;
        }
        $raw = @file_get_contents($path);
        if ($raw === false) {
            return null;
        }
        $data = json_decode(ltrim($raw, "\xEF\xBB\xBF"), true);
        if (!is_array($data) || trim((string) ($data['version'] ?? '')) === '') {
            return null;
        }
        return $data;
    }

    /**
     * 检查更新（只读，带缓存）
     *
     * blocked_reason 取值：
     *   disabled / unknown_version / network / signature / broken_chain /
     *   php_too_old / db_breaking / up_to_date / null（可更新）
     *
     * @param bool $refresh true 时跳过缓存，强制回源
     * @return array<string,mixed>
     */
    public function check(bool $refresh = false): array
    {
        $versionData = $this->currentVersion();
        $current     = $versionData !== null ? trim((string) ($versionData['version'] ?? '')) : '';

        $result = [
            'current'          => $current,
            'latest'           => $current,
            'update_available' => false,
            'php_ok'           => true,
            'total_size'       => 0,
            'steps'            => [],
            'source'           => null,
            'checked_at'       => date('Y-m-d H:i:s'),
            'blocked_reason'   => null,
            'message'          => '',
        ];

        if (!(bool) site_config('update.enabled', true)) {
            return array_merge($result, [
                'blocked_reason' => 'disabled',
                'message'        => '站点已关闭在线更新，如需升级请在「系统设置 → 更新设置」中开启',
            ]);
        }

        if ($current === '') {
            return array_merge($result, [
                'blocked_reason' => 'unknown_version',
                'message'        => '未找到有效的 version.json，可能是手工部署的站点；请按 README 手工升级，或先写入当前版本号',
            ]);
        }

        try {
            $loaded = $this->loadManifest($refresh);
        } catch (BizException $e) {
            return array_merge($result, [
                'blocked_reason' => $this->isSignatureFailure($e) ? 'signature' : 'network',
                'message'        => $e->getMessage(),
            ]);
        } catch (\Throwable $e) {
            return array_merge($result, [
                'blocked_reason' => 'network',
                'message'        => '检查更新失败：' . $e->getMessage(),
            ]);
        }

        $manifest = $loaded['manifest'];
        $latest   = trim((string) ($manifest['latest'] ?? ''));
        $phpMin   = trim((string) ($manifest['php_min'] ?? '0.0.0'));
        $result['latest'] = $latest;
        $result['source'] = $loaded['source'] !== '' ? $loaded['source'] : null;

        $phpOk = version_compare(PHP_VERSION, $phpMin, '>=');
        $result['php_ok'] = $phpOk;
        if (!$phpOk) {
            return array_merge($result, [
                'blocked_reason' => 'php_too_old',
                'message'        => "新版本要求 PHP {$phpMin} 或更高，当前 " . PHP_VERSION . '，请先升级 PHP 再更新',
            ]);
        }

        try {
            $chain = $this->package->chainFor($manifest, $current);
        } catch (BizException $e) {
            return array_merge($result, [
                'blocked_reason' => 'broken_chain',
                'message'        => $e->getMessage(),
            ]);
        }

        if ($chain === []) {
            return array_merge($result, [
                'blocked_reason' => 'up_to_date',
                'message'        => "当前已是最新版本（{$current}）",
            ]);
        }

        foreach ($chain as $step) {
            if (!empty($step['db_breaking'])) {
                return array_merge($result, [
                    'blocked_reason' => 'db_breaking',
                    'message'        => '版本 ' . (string) ($step['to'] ?? '') . ' 含数据库结构变更（不可回滚），不支持一键升级：'
                        . '请先备份数据库，再按 README 手工升级并执行 php think migrate:run',
                ]);
            }
        }

        $steps = [];
        $total = 0;
        foreach ($chain as $index => $step) {
            $size = (int) ($step['asset_size'] ?? 0);
            if (!empty($step['need_vendor'])) {
                $size += (int) ($step['vendor_size'] ?? 0);
            }
            $steps[] = [
                'seq'  => $index + 1,
                'from' => (string) ($step['from'] ?? ''),
                'to'   => (string) ($step['to'] ?? ''),
                'size' => $size,
            ];
            $total += $size;
        }

        return array_merge($result, [
            'update_available' => true,
            'total_size'       => $total,
            'steps'            => $steps,
            'blocked_reason'   => null,
            'message'          => '发现 ' . count($steps) . ' 个待安装版本',
        ]);
    }

    /**
     * 更新历史（分页，id 倒序）
     *
     * @return array{list:array,total:int,page:int,page_size:int}
     */
    public function history(int $page, int $pageSize): array
    {
        $page     = max(1, $page);
        $pageSize = min(100, max(1, $pageSize));

        $total = (int) SiteUpdate::count();
        $rows  = SiteUpdate::order('id', 'desc')->page($page, $pageSize)->select();

        $list = [];
        foreach ($rows as $row) {
            /** @var SiteUpdate $row */
            $list[] = $this->batchRow($row);
        }

        return ['list' => $list, 'total' => $total, 'page' => $page, 'page_size' => $pageSize];
    }

    /**
     * 批次详情（含步骤列表）
     *
     * @return array{batch:array,steps:array}
     */
    public function batchDetail(int $batchId): array
    {
        $batch = $this->findBatch($batchId);
        $rows  = SiteUpdateStep::where('batch_id', $batchId)->order('seq', 'asc')->select();

        $steps = [];
        foreach ($rows as $row) {
            /** @var SiteUpdateStep $row */
            $steps[] = [
                'id'           => (int) $row->id,
                'seq'          => (int) $row->seq,
                'from_version' => (string) $row->from_version,
                'to_version'   => (string) $row->to_version,
                'asset'        => $row->asset === null ? null : (string) $row->asset,
                'ops_asset'    => $row->ops_asset === null ? null : (string) $row->ops_asset,
                'status'       => (string) $row->status,
                'ops_total'    => (int) $row->ops_total,
                'ops_applied'  => (int) $row->ops_applied,
                'conflicts'    => (int) $row->conflicts,
                'backup_path'  => $row->backup_path === null ? null : (string) $row->backup_path,
                'message'      => $row->message === null ? null : (string) $row->message,
                'started_at'   => $row->started_at === null ? null : (string) $row->started_at,
                'finished_at'  => $row->finished_at === null ? null : (string) $row->finished_at,
            ];
        }

        return ['batch' => $this->batchRow($batch), 'steps' => $steps];
    }

    // ==================================================================
    // 规划
    // ==================================================================

    /**
     * 规划升级：强刷清单 + 只读校验 + 建批次与步骤
     *
     * 本方法**不修改项目目录**（只写数据库）。全程持有与 step 相同的 flock：
     * 否则两个浏览器同时规划会各建一个批次，随后交错执行（第二个批次的 from_version
     * 已经不是磁盘上的版本），属于破坏性写入。
     *
     * @return array{batch_id:int,from:string,to:string,steps:array,total_size:int,source:string}
     * @throws BizException 版本未知、链断、资产缺失、磁盘不足、目录不可写、能力缺失、db_breaking
     */
    public function plan(): array
    {
        $this->acquireLock();
        try {
            return $this->doPlan();
        } finally {
            $this->releaseLock();
        }
    }

    /**
     * plan() 的主体（调用方已持有 flock）
     *
     * @return array{batch_id:int,from:string,to:string,steps:array,total_size:int,source:string}
     * @throws BizException
     */
    private function doPlan(): array
    {
        if (!(bool) site_config('update.enabled', true)) {
            throw new BizException('站点已关闭在线更新，无法规划升级；如需升级请在「系统设置 → 更新设置」中开启');
        }

        $versionData = $this->currentVersion();
        if ($versionData === null) {
            throw new BizException('未找到有效的 version.json，无法规划升级；请先手工部署到支持在线更新的版本');
        }
        $current = trim((string) $versionData['version']);

        // 0. 已有未完成批次时拒绝重复规划，避免两个批次交叉执行
        //    failed 也要先重试或回滚：它可能已经写入了部分文件，直接规划会让新批次从错误的起点开始
        $pending = SiteUpdate::whereIn('status', [
            SiteUpdate::STATUS_PLANNED,
            SiteUpdate::STATUS_RUNNING,
            SiteUpdate::STATUS_FAILED,
        ])
            ->order('id', 'desc')
            ->find();
        if ($pending !== null) {
            throw new BizException(
                '已有未完成的更新批次（' . (string) $pending->from_version . ' → ' . (string) $pending->to_version
                . '，状态：' . $this->statusLabel((string) $pending->status) . '），请先完成该批次或回滚后再重新规划'
            );
        }

        // 1. 强刷清单（不复用缓存，避免拿过期计划去下载已下架的资产）
        $loaded   = $this->loadManifest(true);
        $manifest = $loaded['manifest'];
        $latest   = trim((string) ($manifest['latest'] ?? ''));
        $phpMin   = trim((string) ($manifest['php_min'] ?? '0.0.0'));

        if ($latest === '') {
            throw new BizException('更新清单缺少 latest 字段，已中止');
        }
        if (!version_compare(PHP_VERSION, $phpMin, '>=')) {
            throw new BizException("新版本要求 PHP {$phpMin} 或更高，当前 " . PHP_VERSION . '，请先升级 PHP');
        }

        $chain = $this->package->chainFor($manifest, $current);
        if ($chain === []) {
            throw new BizException("当前已是最新版本（{$current}），无需升级");
        }

        foreach ($chain as $step) {
            if (!empty($step['db_breaking'])) {
                throw new BizException(
                    '版本 ' . (string) ($step['to'] ?? '') . ' 含数据库结构变更（迁移不可回滚），不支持一键升级。'
                    . '请先备份数据库，再按 README 手工覆盖代码并执行 php think migrate:run'
                );
            }

            // 清单字段完整性：缺字段就现在报错，不要等下载到一半才发现
            $toVersion = (string) ($step['to'] ?? '');
            foreach (['asset' => '增量包', 'ops_asset' => '操作清单', 'asset_sha256' => '增量包 sha256'] as $field => $label) {
                if (trim((string) ($step[$field] ?? '')) === '') {
                    throw new BizException("版本 {$toVersion} 的清单缺少{$label}（{$field}），请重新执行 release:build 发布");
                }
            }
            if (!empty($step['need_vendor'])) {
                if (trim((string) ($step['vendor_asset'] ?? '')) === ''
                    || trim((string) ($step['vendor_sha256'] ?? '')) === '') {
                    throw new BizException("版本 {$toVersion} 标记了依赖变更（need_vendor）但清单缺少 vendor_asset / vendor_sha256，请重新构建 vendor 包");
                }
            }
        }

        // 2. 运行环境能力
        if (!class_exists(\ZipArchive::class)) {
            throw new BizException('服务器缺少 zip 扩展，无法解压增量包；请安装 ext-zip 或联系主机商');
        }
        if (ManifestSigner::defaultAlgo() === '') {
            throw new BizException('服务器缺少 sodium / openssl 扩展，无法校验更新包签名，已中止');
        }

        // 3. 资产可下载性（任一缺失即中止，避免执行到一半才发现）
        $this->assertAssetsAvailable($chain, $loaded['source']);

        // 4. 磁盘与目录
        $totalSize = 0;
        $deltaSize = 0;
        foreach ($chain as $step) {
            $totalSize += (int) ($step['asset_size'] ?? 0) + (int) ($step['vendor_size'] ?? 0);
            $deltaSize += (int) ($step['delta_bytes'] ?? 0);
        }
        $this->assertDiskSpace($totalSize, $deltaSize, $chain);
        $this->assertWritable();

        // 5. 落库：一个批次 + n 条 pending 步骤
        //    用事务包住：任一条步骤写失败时不能留下一个「永远 blocked 的 planned 批次」
        $batchNo = SiteUpdate::batchNo();

        $stepRows = [];
        $steps    = [];
        foreach ($chain as $index => $step) {
            $seq = $index + 1;
            $size = $this->chainStepSize($step);

            $stepRows[] = [
                'seq'          => $seq,
                'from_version' => (string) ($step['from'] ?? ''),
                'to_version'   => (string) ($step['to'] ?? ''),
                'asset'        => (string) ($step['asset'] ?? ''),
                'ops_asset'    => (string) ($step['ops_asset'] ?? ''),
                'asset_sha256' => (string) ($step['asset_sha256'] ?? ''),
                'status'       => SiteUpdateStep::STATUS_PENDING,
                'ops_total'    => (int) ($step['ops_count'] ?? 0),
                'ops_applied'  => 0,
                'conflicts'    => 0,
                'backup_path'  => null,
                'message'      => null,
            ];

            $steps[] = [
                'seq'  => $seq,
                'from' => (string) ($step['from'] ?? ''),
                'to'   => (string) ($step['to'] ?? ''),
                'size' => $size,
            ];
        }

        $batchId = 0;
        Db::transaction(function () use (
            $batchNo,
            $current,
            $latest,
            $totalSize,
            $loaded,
            $stepRows,
            &$batchId
        ): void {
            $batch = new SiteUpdate();
            $batch->save([
                'batch_no'      => $batchNo,
                'from_version'  => $current,
                'to_version'    => $latest,
                'status'        => SiteUpdate::STATUS_PLANNED,
                'current_step'  => 0,
                'total_steps'   => count($stepRows),
                'total_size'    => $totalSize,
                'source'        => $loaded['source'],
                'has_conflicts' => 0,
                'migrated'      => 0,
                'message'       => null,
                'operator_id'   => AppContext::getAdminId(),
                'operator_name' => AppContext::getAdminUsername() !== '' ? AppContext::getAdminUsername() : null,
            ]);

            $batchId = (int) $batch->id;

            foreach ($stepRows as $row) {
                $row['batch_id'] = $batchId;

                $step = new SiteUpdateStep();
                $step->save($row);
            }
        });

        return [
            'batch_id'   => $batchId,
            'from'       => $current,
            'to'         => $latest,
            'steps'      => $steps,
            'total_size' => $totalSize,
            'source'     => $loaded['source'],
        ];
    }

    /**
     * 单个链步骤需要的下载字节数（增量包 + 依赖包）
     *
     * @param array<string,mixed> $step
     */
    private function chainStepSize(array $step): int
    {
        return (int) ($step['asset_size'] ?? 0) + (int) ($step['vendor_size'] ?? 0);
    }

    // ==================================================================
    // 执行
    // ==================================================================

    /**
     * 执行该批次的下一个 pending 步骤（一次请求一步）
     *
     * @return array{done:bool,step:array,batch:array,message:string}
     * @throws BizException 锁占用、状态不允许、下载/校验/解压/迁移失败
     */
    public function runNextStep(int $batchId): array
    {
        return $this->executeNextStep($batchId, false);
    }

    /**
     * 重试：先回滚失败的步骤，再重跑同一步
     *
     * @return array 同 runNextStep()
     * @throws BizException
     */
    public function retry(int $batchId): array
    {
        $this->acquireLock();
        try {
            $batch = $this->findBatch($batchId);
            $status = (string) $batch->status;
            if (!in_array($status, [
                SiteUpdate::STATUS_PLANNED,
                SiteUpdate::STATUS_FAILED,
                SiteUpdate::STATUS_RUNNING,
            ], true)) {
                throw new BizException('该批次当前状态为「' . $this->statusLabel($status) . '」，不能重试');
            }

            $step = SiteUpdateStep::where('batch_id', $batchId)
                ->whereIn('status', [SiteUpdateStep::STATUS_FAILED, SiteUpdateStep::STATUS_RUNNING])
                ->order('seq', 'asc')
                ->find();

            if ($step !== null) {
                /** @var SiteUpdateStep $step */
                $this->installer->restoreStep($batchId, (int) $step->seq);
                $step->save([
                    'status'      => SiteUpdateStep::STATUS_PENDING,
                    'message'     => null,
                    'conflicts'   => 0,
                    'ops_applied' => 0,
                    'started_at'  => null,
                    'finished_at' => null,
                ]);
            }

            $batch->save(['status' => SiteUpdate::STATUS_PLANNED, 'message' => null]);
        } finally {
            $this->releaseLock();
        }

        return $this->executeNextStep($batchId, true);
    }

    /**
     * 整批回滚：按 seq 倒序还原所有已执行步骤 + version.json
     *
     * @return array{restored_files:int,version:string,migrated:bool}
     * @throws BizException 批次不存在或状态不允许
     */
    public function rollback(int $batchId): array
    {
        $this->acquireLock();
        try {
            $batch  = $this->findBatch($batchId);
            $status = (string) $batch->status;

            if (!in_array($status, [
                SiteUpdate::STATUS_SUCCESS,
                SiteUpdate::STATUS_FAILED,
                SiteUpdate::STATUS_RUNNING,
            ], true)) {
                throw new BizException('该批次当前状态为「' . $this->statusLabel($status) . '」，不能回滚');
            }

            $restored = 0;
            $rows = SiteUpdateStep::where('batch_id', $batchId)
                ->where('status', '<>', SiteUpdateStep::STATUS_PENDING)
                ->order('seq', 'desc')
                ->select();

            // 回滚前先确认备份还在：backup_keep 会清理老批次，清理后再点回滚
            // 曾经会「报告成功但文件与版本号都没动」，属于静默的数据不一致。
            $this->assertRollbackBackupsPresent($batch, $rows);

            foreach ($rows as $row) {
                /** @var SiteUpdateStep $row */
                $restored += $this->installer->restoreStep($batchId, (int) $row->seq);
            }

            $this->installer->restoreVersionBackup((string) $batch->batch_no);

            $message = '已回滚到 ' . (string) $batch->from_version;
            if ((int) $batch->migrated === 1) {
                $message .= '；数据库结构未回滚（迁移只能向前），请按需手工处理';
            }
            $batch->save([
                'status'          => SiteUpdate::STATUS_ROLLED_BACK,
                'rolled_back_at'  => date('Y-m-d H:i:s'),
                'message'         => $message,
            ]);

            $this->removeApplyingLock();

            return [
                'restored_files' => $restored,
                'version'        => (string) $batch->from_version,
                'migrated'       => (int) $batch->migrated === 1,
            ];
        } finally {
            $this->releaseLock();
        }
    }

    /**
     * 回滚前确认备份完整
     *
     * - 只要有一步是 success，就必须有该步的 manifest（文件原件）和批次级 version.json；
     * - 只在失败于下载/校验阶段的批次没有备份，此时本来就没有文件/版本需要还原。
     *
     * @param SiteUpdate       $batch
     * @param iterable<SiteUpdateStep> $rows
     * @throws BizException 备份被清理或不完整
     */
    private function assertRollbackBackupsPresent(SiteUpdate $batch, iterable $rows): void
    {
        $batchNo = (string) $batch->batch_no;
        $missing = [];
        $applied = false;

        foreach ($rows as $row) {
            $status = (string) $row->status;
            $started = $status === SiteUpdateStep::STATUS_SUCCESS
                || ($row->backup_path !== null && (string) $row->backup_path !== '');

            // 失败步也可能已经写了一半文件：只要落过 backup_path，就必须有 manifest 才能还原
            if ($started && !$this->installer->stepBackupExists($batchNo, (int) $row->seq)) {
                $missing[] = '第 ' . (int) $row->seq . ' 步的文件备份';
            }

            if ($status === SiteUpdateStep::STATUS_SUCCESS) {
                $applied = true;
            }
        }

        if ($applied && !$this->installer->versionBackupExists($batchNo)) {
            $missing[] = 'version.json 备份';
        }

        if ($missing !== []) {
            throw new BizException(
                '本批次无法自动回滚：' . implode('、', $missing)
                . ' 已不存在（通常是被 update.backup_keep 清理或磁盘被清理）。'
                . '请从更早的备份手工恢复，或按 README 手工重新部署代码并核对 version.json'
            );
        }
    }

    // ==================================================================
    // 执行主体
    // ==================================================================

    /**
     * @param bool $fromRetry 由 retry() 调用时允许对 failed 批次继续
     * @return array{done:bool,step:array,batch:array,message:string}
     */
    private function executeNextStep(int $batchId, bool $fromRetry): array
    {
        $this->acquireLock();

        /** @var SiteUpdate|null $batch */
        $batch = null;
        /** @var SiteUpdateStep|null $step */
        $step = null;

        $seq   = 0;
        $from  = '';
        $to    = '';
        $executing = false;

        try {
            $batch  = $this->findBatch($batchId);
            $status = (string) $batch->status;

            // 状态机：planned / running 可续跑；failed 只允许 retry() 进入
            if (!in_array($status, [SiteUpdate::STATUS_PLANNED, SiteUpdate::STATUS_RUNNING], true)
                && !($status === SiteUpdate::STATUS_FAILED && $fromRetry)) {
                throw new BizException('该批次当前状态为「' . $this->statusLabel($status) . '」，不能执行下一步');
            }

            $step = SiteUpdateStep::where('batch_id', $batchId)
                ->where('status', SiteUpdateStep::STATUS_PENDING)
                ->order('seq', 'asc')
                ->find();
            if ($step === null) {
                throw new BizException('没有待执行步骤：该批次可能已全部完成，请刷新后查看');
            }

            /** @var SiteUpdateStep $step */
            $batchNo = (string) $batch->batch_no;
            $seq     = (int) $step->seq;
            $from    = (string) $step->from_version;
            $to      = (string) $step->to_version;

            // 起点不变量：磁盘上的版本必须正好是这一步的 from（正常续跑）或 to
            // （上次已写完 version.json、但收尾落库失败）。其它情况说明批次已过期：
            // 例如另一个批次先跑完了，继续执行会把新代码写回旧内容（降级），必须拒绝。
            // 放在 $executing = true 之前：这种拒绝不改变批次状态，用户仍可重试/回滚。
            $this->assertStepOrigin($from, $to, $seq);

            $executing = true;

            // 维护窗口标记 + 步骤置 running
            $this->writeApplyingLock($batchNo);
            $step->save([
                'status'     => SiteUpdateStep::STATUS_RUNNING,
                'started_at' => date('Y-m-d H:i:s'),
                'message'    => null,
            ]);
            $batch->save(['status' => SiteUpdate::STATUS_RUNNING, 'current_step' => $seq, 'message' => null]);

            // 1. 清单（每次执行都重新验签：资产的 sha256 必须来自签名清单）
            $loaded   = $this->loadManifest(false);
            $manifest = $loaded['manifest'];
            $entry    = $this->manifestStep($manifest, $from, (string) $step->asset);
            if ($entry === null) {
                throw new BizException('更新清单与批次不一致（找不到 ' . $from . ' 起的步骤），请重新检查更新并规划');
            }
            if ((string) ($entry['to'] ?? '') !== $to) {
                throw new BizException('更新清单已变化（' . $from . ' → ' . (string) ($entry['to'] ?? '?') . '），请重新检查更新并规划');
            }

            // 2. 下载 + 校验哈希
            $batchDir = $this->abs('runtime/update/' . $batchNo);
            self::ensureDir($batchDir);

            $assetName = (string) ($entry['asset'] ?? $step->asset);
            UpdatePackage::assertSafeAssetName($assetName);
            $assetPath = $batchDir . '/' . $assetName;
            $source    = $this->downloadAsset(
                $assetName,
                $to,
                $assetPath,
                (string) ($entry['asset_sha256'] ?? ''),
                $seq,
                $from,
                $to,
                '增量包'
            );
            if ($source !== '' && $source !== (string) $batch->source) {
                $batch->save(['source' => $source]);
            }

            $opsName = (string) ($entry['ops_asset'] ?? $step->ops_asset);
            UpdatePackage::assertSafeAssetName($opsName);
            $opsPath = $batchDir . '/' . $opsName;
            $this->downloadAsset(
                $opsName,
                $to,
                $opsPath,
                (string) ($entry['ops_sha256'] ?? ''),
                $seq,
                $from,
                $to,
                '操作清单'
            );

            $doc = $this->package->parseOps($opsPath);
            $ops = (array) $doc['ops'];
            foreach ($ops as $op) {
                $path = (string) ($op['path'] ?? '');
                $this->package->assertSafePath($path);
                $this->package->assertWithinRoots($path);
            }

            // 3. 解压到暂存目录
            $stageDir = $this->abs('runtime/update/stage/' . $batchNo . '/' . $seq);
            if (is_dir($stageDir)) {
                UpdateInstaller::removeTree($stageDir);
            }
            self::ensureDir($stageDir);
            $this->package->extractZip($assetPath, $stageDir);

            // 4. 备份 + 应用（冲突不阻断，备份后覆盖）
            if (!is_file($this->abs('runtime/update/backup/' . $batchNo . '/version.json'))) {
                $this->installer->saveVersionBackup($batchNo);
            }
            $backupRel = $this->installer->backupStep($batchNo, $seq, $ops);
            $applied   = $this->installer->applyOps($stageDir, $ops, $batchNo, $seq);
            $conflicts = (array) $applied['conflicts'];

            $step->save([
                'backup_path' => $backupRel,
                'ops_total'   => count($ops),
                'ops_applied' => (int) $applied['applied'],
                'conflicts'   => count($conflicts),
            ]);
            if ($conflicts !== []) {
                $batch->save(['has_conflicts' => 1]);
            }

            // 5. 依赖包（composer.* 变更时才有）
            if (!empty($entry['need_vendor'])) {
                $vendorAsset = (string) ($entry['vendor_asset'] ?? '');
                if ($vendorAsset === '') {
                    throw new BizException('该版本更新了依赖，但清单未提供依赖包；请手工执行 composer install');
                }
                UpdatePackage::assertSafeAssetName($vendorAsset);
                $vendorPath = $batchDir . '/' . $vendorAsset;
                $this->downloadAsset(
                    $vendorAsset,
                    $to,
                    $vendorPath,
                    (string) ($entry['vendor_sha256'] ?? ''),
                    $seq,
                    $from,
                    $to,
                    '依赖包'
                );
                $this->installer->switchVendor($vendorPath, $batchNo, $seq);
            }

            // 6. 数据库迁移（只向前）
            $migration = (new UpdateMigrator($this->root))->run();
            if (!$migration['ok']) {
                throw new BizException(
                    "第 {$seq} 步（{$from} → {$to}）数据库迁移失败：" . $this->shortenOutput((string) $migration['output'])
                );
            }
            $batch->save(['migrated' => 1]);

            // 7. 清缓存（失败不阻断：清不掉最多是脏缓存，不能因此判失败）
            $this->clearRuntimeCaches();

            // 8. 写版本（原子写，任何中断都停在合法版本上）
            $this->installer->writeVersion([
                'version'     => $to,
                'released_at' => date('c'),
                'db_version'  => (string) ($entry['db_version'] ?? ''),
                'php_min'     => (string) ($manifest['php_min'] ?? '8.0.0'),
            ]);

            // 9. 收尾：步骤成功 → 批次进度
            $conflictNote = $this->conflictNote($conflicts);
            $step->save([
                'status'      => SiteUpdateStep::STATUS_SUCCESS,
                'finished_at' => date('Y-m-d H:i:s'),
                'message'     => $conflictNote,
            ]);

            $successCount = (int) SiteUpdateStep::where('batch_id', $batchId)
                ->where('status', SiteUpdateStep::STATUS_SUCCESS)
                ->count();
            $totalSteps = (int) $batch->total_steps;
            $done       = $totalSteps > 0 && $successCount >= $totalSteps;

            if ($done) {
                $batch->save([
                    'status'       => SiteUpdate::STATUS_SUCCESS,
                    'current_step' => $totalSteps,
                    'finished_at'  => date('Y-m-d H:i:s'),
                    'message'      => $conflictNote,
                ]);

                // 备份保留 N 批；当前批次永远保留
                $keep = (int) site_config('update.backup_keep', (int) config('update.backup_keep', 3));
                $this->installer->cleanup($batchNo, $keep > 0 ? $keep : 3);

                // 整批成功后清理本批的下载包与暂存目录（失败时保留现场供排查/重试）
                if (is_dir($stageDir)) {
                    UpdateInstaller::removeTree($stageDir);
                }
                $stageRoot = $this->abs('runtime/update/stage/' . $batchNo);
                if (is_dir($stageRoot)) {
                    UpdateInstaller::removeTree($stageRoot);
                }
                $packageDir = $this->abs('runtime/update/' . $batchNo);
                if (is_dir($packageDir)) {
                    UpdateInstaller::removeTree($packageDir);
                }
            } else {
                $batch->save(['current_step' => $seq]);
            }

            $this->removeApplyingLock();

            return [
                'done'    => $done,
                'step'    => [
                    'seq'       => $seq,
                    'from'      => $from,
                    'to'        => $to,
                    'status'    => SiteUpdateStep::STATUS_SUCCESS,
                    'ops_total' => count($ops),
                    'conflicts' => count($conflicts),
                ],
                'batch'   => [
                    'status'       => (string) $batch->status,
                    'progress'     => $successCount,
                    'total_steps'  => $totalSteps,
                    'current_step' => (int) $step->seq,
                ],
                'message' => $done
                    ? "全部步骤已完成，当前版本 {$to}"
                    : "第 {$seq} 步（{$from} → {$to}）已完成",
            ];
        } catch (\Throwable $e) {
            $message = $this->friendlyMessage($e, $seq, $from, $to);

            // 只有真正开始执行某一步时才把批次落成 failed，避免「无待执行步骤」把已完成的批次改坏
            if ($executing && $batch instanceof SiteUpdate) {
                try {
                    if ($step instanceof SiteUpdateStep) {
                        $step->save([
                            'status'      => SiteUpdateStep::STATUS_FAILED,
                            'finished_at' => date('Y-m-d H:i:s'),
                            'message'     => $message,
                        ]);
                    }
                    $batch->save([
                        'status'  => SiteUpdate::STATUS_FAILED,
                        'message' => $message,
                    ]);
                } catch (\Throwable $ignored) {
                    // 状态落库失败不能覆盖原始错误
                }
            }

            $this->removeApplyingLock();

            // 面向运营：只抛一层可读消息，绝不带堆栈
            throw $e instanceof BizException ? new BizException($message) : new BizException($message, 0, $e);
        } finally {
            $this->releaseLock();
        }
    }

    // ==================================================================
    // 清单与资产
    // ==================================================================

    /**
     * 取清单（缓存优先，始终验签）
     *
     * @return array{manifest:array,raw:string,signature:string,source:string}
     * @throws BizException 源不可达或验签失败
     */
    private function loadManifest(bool $refresh): array
    {
        $versionData = $this->currentVersion();
        $current     = $versionData !== null ? trim((string) ($versionData['version'] ?? '')) : '';

        if (!$refresh) {
            $cached = $this->readManifestCache($current);
            if ($cached !== null) {
                return $cached;
            }
        }

        $loaded = $this->fetchManifestFromSources();

        // fail-closed：验签不通过就不写缓存、不进入后续流程
        $this->package->verifyManifest(
            (array) $loaded['manifest'],
            (string) $loaded['raw'],
            (string) $loaded['signature']
        );

        $this->writeManifestCache($current, $loaded);

        return $loaded;
    }

    /**
     * 按站点设置的源顺序逐个尝试，全部失败则抛出聚合错误
     *
     * @return array{manifest:array,raw:string,signature:string,source:string}
     * @throws BizException
     */
    private function fetchManifestFromSources(): array
    {
        $errors = [];
        $tried  = [];

        foreach (SourceFactory::ordered() as $source) {
            $label   = $this->sourceLabel($source->name());
            $tried[] = $label;

            try {
                $data = $source->fetchManifest();
                return [
                    'manifest'  => (array) ($data['manifest'] ?? []),
                    'raw'       => (string) ($data['manifest_raw'] ?? ''),
                    'signature' => (string) ($data['signature'] ?? ''),
                    'source'    => (string) ($data['source'] ?? $source->name()),
                ];
            } catch (BizException $e) {
                $errors[] = $label . '：' . $e->getMessage();
            } catch (\Throwable $e) {
                $errors[] = $label . '：' . $e->getMessage();
            }
        }

        throw new BizException(
            '无法获取更新清单（已尝试 ' . implode('、', $tried) . '）：' . implode('；', $errors)
        );
    }

    /**
     * 读缓存并重新验签（不做信任传递）
     *
     * @return array{manifest:array,raw:string,signature:string,source:string}|null
     */
    private function readManifestCache(string $current): ?array
    {
        $key = self::MANIFEST_CACHE_PREFIX . ($current !== '' ? $current : 'unknown');

        try {
            $cached = Cache::get($key);
        } catch (\Throwable $e) {
            return null;
        }
        if (!is_array($cached) || !isset($cached['manifest_raw'], $cached['signature'])) {
            return null;
        }

        try {
            $manifest = $this->package->parseManifest((string) $cached['manifest_raw']);
            $this->package->verifyManifest($manifest, (string) $cached['manifest_raw'], (string) $cached['signature']);
        } catch (\Throwable $e) {
            // 缓存被污染 / 签名不匹配 → 丢弃后回源
            try {
                Cache::delete($key);
            } catch (\Throwable $ignored) {
            }
            return null;
        }

        return [
            'manifest'  => $manifest,
            'raw'       => (string) $cached['manifest_raw'],
            'signature' => (string) $cached['signature'],
            'source'    => (string) ($cached['source'] ?? ''),
        ];
    }

    /**
     * @param array{manifest:array,raw:string,signature:string,source:string} $loaded
     */
    private function writeManifestCache(string $current, array $loaded): void
    {
        $ttl = (int) config('update.cache_ttl', 600);
        if ($ttl <= 0) {
            return;
        }

        try {
            Cache::set(self::MANIFEST_CACHE_PREFIX . ($current !== '' ? $current : 'unknown'), [
                'manifest_raw' => (string) $loaded['raw'],
                'signature'    => (string) $loaded['signature'],
                'source'       => (string) $loaded['source'],
                'fetched_at'   => time(),
            ], $ttl);
        } catch (\Throwable $e) {
            // 缓存不可用不影响主流程
            Log::warning('更新清单写入缓存失败：' . $e->getMessage());
        }
    }

    /**
     * 在清单里定位本步对应的条目
     *
     * @param array<string,mixed> $manifest
     * @return array<string,mixed>|null
     */
    private function manifestStep(array $manifest, string $from, string $asset): ?array
    {
        foreach ((array) ($manifest['steps'] ?? []) as $step) {
            if (!is_array($step)) {
                continue;
            }
            if ((string) ($step['from'] ?? '') === $from) {
                return $step;
            }
        }
        if ($asset !== '') {
            foreach ((array) ($manifest['steps'] ?? []) as $step) {
                if (is_array($step) && (string) ($step['asset'] ?? '') === $asset) {
                    return $step;
                }
            }
        }
        return null;
    }

    /**
     * 校验「磁盘上的版本」与待执行步骤的起点一致
     *
     * @param string $from 本步升级前版本
     * @param string $to   本步目标版本
     * @param int    $seq  步骤序号（仅用于错误文案）
     * @throws BizException 版本未知，或既不是 from 也不是 to
     */
    private function assertStepOrigin(string $from, string $to, int $seq): void
    {
        $versionData = $this->currentVersion();
        $current     = $versionData !== null ? trim((string) ($versionData['version'] ?? '')) : '';

        if ($current === $from || $current === $to) {
            return;
        }

        throw new BizException(
            '第 ' . $seq . ' 步（' . $from . ' → ' . $to . '）与站点当前版本 '
            . ($current !== '' ? $current : '未知（缺少 version.json）')
            . ' 不一致，已中止本步；请刷新页面，确认没有其它批次在执行，然后重新检查更新'
        );
    }

    /**
     * 下载资产并按清单里的 sha256 校验（逐源尝试，失败聚合）
     *
     * @return string 实际生效的源标识
     * @throws BizException
     */
    private function downloadAsset(
        string $assetName,
        string $version,
        string $dest,
        string $expectedSha256,
        int $seq,
        string $from,
        string $to,
        string $kind = '增量包'
    ): string {
        $prefix = "第 {$seq} 步（{$from} → {$to}）{$kind}";

        // fail-closed：清单里没有哈希就不装（否则「验签清单缺字段」会变成跳过完整性校验）
        if (trim($expectedSha256) === '') {
            throw new BizException($prefix . '在清单中缺少 sha256，拒绝安装未经哈希校验的资产');
        }

        $errors = [];

        self::ensureDir(dirname($dest));

        foreach (SourceFactory::ordered() as $source) {
            $tmp = $dest . '.download';
            @unlink($tmp);

            try {
                $source->fetchAsset($assetName, $version, $tmp);
            } catch (\Throwable $e) {
                @unlink($tmp);
                $errors[] = $this->sourceLabel($source->name()) . ' ' . $this->shortReason($e->getMessage());
                continue;
            }

            $actual = @hash_file('sha256', $tmp);
            if ($actual === false || !hash_equals(strtolower($expectedSha256), strtolower((string) $actual))) {
                @unlink($tmp);
                $errors[] = $this->sourceLabel($source->name()) . ' 校验失败';
                continue;
            }

            if (is_file($dest)) {
                @unlink($dest);
            }
            if (!@rename($tmp, $dest)) {
                @unlink($tmp);
                $errors[] = $this->sourceLabel($source->name()) . ' 保存失败';
                continue;
            }

            return $source->name();
        }

        throw new BizException($prefix . '下载失败：' . implode('、', $errors));
    }

    /**
     * 规划阶段探测所有资产是否存在（HEAD）
     *
     * @param array<int,array<string,mixed>> $chain
     * @throws BizException 任一资产在所有源上都不可用
     */
    private function assertAssetsAvailable(array $chain, string $preferred): void
    {
        $sources = SourceFactory::ordered();
        if ($preferred !== '') {
            usort($sources, static function (UpdateSourceInterface $a, UpdateSourceInterface $b) use ($preferred): int {
                return ($a->name() === $preferred ? 0 : 1) <=> ($b->name() === $preferred ? 0 : 1);
            });
        }

        $missing = [];

        foreach ($chain as $step) {
            $version = (string) ($step['to'] ?? '');
            $assets  = [];
            if (!empty($step['asset'])) {
                $assets[] = (string) $step['asset'];
            }
            if (!empty($step['ops_asset'])) {
                $assets[] = (string) $step['ops_asset'];
            }
            if (!empty($step['need_vendor']) && !empty($step['vendor_asset'])) {
                $assets[] = (string) $step['vendor_asset'];
            }

            foreach ($assets as $asset) {
                UpdatePackage::assertSafeAssetName($asset);

                $detail = [];
                $found  = false;
                foreach ($sources as $source) {
                    try {
                        $head = $source->headAsset($asset, $version);
                        $status = (int) ($head['status'] ?? 0);
                        if ($status === 200 || $status === 302) {
                            $found = true;
                            break;
                        }
                        $detail[] = $this->sourceLabel($source->name()) . ': ' . ($status > 0 ? (string) $status : '不可达');
                    } catch (BizException $e) {
                        $detail[] = $this->sourceLabel($source->name()) . ': ' . $this->shortReason($e->getMessage());
                    }
                }

                if (!$found) {
                    $missing[] = $asset . '（' . implode(' / ', $detail) . '）';
                }
            }
        }

        if ($missing !== []) {
            throw new BizException('更新包在分发源上不可用，已中止（未改动任何文件）：' . implode('；', $missing));
        }
    }

    /**
     * 磁盘空间：sum(asset + delta + vendor 预留) × 3 + 32MB
     *
     * @param array<int,array<string,mixed>> $chain
     * @throws BizException
     */
    private function assertDiskSpace(int $assetBytes, int $deltaBytes, array $chain): void
    {
        $needVendor = false;
        foreach ($chain as $step) {
            if (!empty($step['need_vendor'])) {
                $needVendor = true;
                break;
            }
        }

        $needed = ($assetBytes + $deltaBytes + ($needVendor ? self::VENDOR_RESERVE : 0)) * 3 + self::DISK_RESERVE;
        $free   = @disk_free_space($this->root);
        if ($free === false) {
            // 部分虚拟主机限制该函数，拿不到就不阻塞
            return;
        }
        if ($free < $needed) {
            throw new BizException(sprintf(
                '磁盘空间不足：升级需要约 %s，当前可用 %s，请清理后再试',
                $this->humanBytes($needed),
                $this->humanBytes((int) $free)
            ));
        }
    }

    /**
     * 目标目录可写性
     *
     * @throws BizException
     */
    private function assertWritable(): void
    {
        $targets = [
            '项目根目录' => $this->root,
            'app'        => $this->root . '/app',
            'config'     => $this->root . '/config',
            'route'      => $this->root . '/route',
            'database'   => $this->root . '/database',
            'public'     => $this->root . '/public',
            'runtime'    => $this->root . '/runtime',
        ];

        foreach ($targets as $label => $dir) {
            if (!is_dir($dir)) {
                continue;
            }
            if (!is_writable($dir)) {
                throw new BizException("{$label} 目录不可写，升级无法进行：请检查目录权限（Web 用户需要写权限）");
            }
        }
    }

    /**
     * 清缓存：框架缓存 + 编译模板（不动 runtime/update）
     */
    private function clearRuntimeCaches(): void
    {
        try {
            Cache::clear();
        } catch (\Throwable $e) {
            Log::warning('更新后清理框架缓存失败：' . $e->getMessage());
        }

        foreach (['runtime/temp', 'runtime/cache'] as $rel) {
            $dir = $this->abs($rel);
            if (!is_dir($dir)) {
                continue;
            }
            foreach (scandir($dir) ?: [] as $item) {
                if ($item === '.' || $item === '..') {
                    continue;
                }
                UpdateInstaller::removeTree($dir . '/' . $item);
            }
        }
    }

    // ==================================================================
    // 锁与状态文件
    // ==================================================================

    /**
     * 非阻塞独占锁（flock），拿不到直接失败
     *
     * @throws BizException
     */
    private function acquireLock(): void
    {
        $path = $this->abs(self::LOCK_REL);
        self::ensureDir(dirname($path));

        $handle = @fopen($path, 'c+');
        if ($handle === false) {
            throw new BizException('无法创建更新锁文件 runtime/update/.lock，请检查 runtime 目录写权限');
        }
        if (!flock($handle, LOCK_EX | LOCK_NB)) {
            fclose($handle);
            throw new BizException('另一个更新任务正在执行，请稍后重试');
        }

        $this->lockHandle = $handle;
    }

    private function releaseLock(): void
    {
        if (is_resource($this->lockHandle)) {
            flock($this->lockHandle, LOCK_UN);
            fclose($this->lockHandle);
        }
        $this->lockHandle = null;
    }

    private function writeApplyingLock(string $batchNo): void
    {
        $path = $this->abs(self::APPLYING_REL);
        self::ensureDir(dirname($path));
        @file_put_contents($path, $batchNo);
    }

    private function removeApplyingLock(): void
    {
        $path = $this->abs(self::APPLYING_REL);
        if (is_file($path)) {
            @unlink($path);
        }
    }

    // ==================================================================
    // 内部工具
    // ==================================================================

    private function findBatch(int $batchId): SiteUpdate
    {
        $batch = SiteUpdate::find($batchId);
        if (!$batch) {
            throw new BizException('更新批次不存在');
        }
        return $batch;
    }

    /**
     * @return array<string,mixed>
     */
    private function batchRow(SiteUpdate $batch): array
    {
        return [
            'id'              => (int) $batch->id,
            'batch_no'        => (string) $batch->batch_no,
            'from_version'    => (string) $batch->from_version,
            'to_version'      => (string) $batch->to_version,
            'status'          => (string) $batch->status,
            'current_step'    => (int) $batch->current_step,
            'total_steps'     => (int) $batch->total_steps,
            'total_size'      => (int) $batch->total_size,
            'source'          => $batch->source === null ? null : (string) $batch->source,
            'has_conflicts'   => (int) $batch->has_conflicts === 1,
            'migrated'        => (int) $batch->migrated === 1,
            'message'         => $batch->message === null ? null : (string) $batch->message,
            'operator_id'     => $batch->operator_id === null ? null : (int) $batch->operator_id,
            'operator_name'   => $batch->operator_name === null ? null : (string) $batch->operator_name,
            'created_at'      => $batch->created_at === null ? null : (string) $batch->created_at,
            'finished_at'     => $batch->finished_at === null ? null : (string) $batch->finished_at,
            'rolled_back_at'  => $batch->rolled_back_at === null ? null : (string) $batch->rolled_back_at,
        ];
    }

    private function statusLabel(string $status): string
    {
        return match ($status) {
            SiteUpdate::STATUS_PLANNED     => '已规划待执行',
            SiteUpdate::STATUS_RUNNING     => '执行中',
            SiteUpdate::STATUS_SUCCESS     => '已完成',
            SiteUpdate::STATUS_FAILED      => '已失败',
            SiteUpdate::STATUS_ROLLED_BACK => '已回滚',
            default                       => $status,
        };
    }

    private function isSignatureFailure(BizException $e): bool
    {
        return str_starts_with($e->getMessage(), 'update.json 签名校验失败');
    }

    /**
     * 冲突摘要（写入 site_update_step.message）
     *
     * AC6 要求「冲突清单里列出该路径」：step 只存计数不够，把前 20 个路径写进 message，
     * 完整清单仍在备份目录的 manifest.json 里（不新增列，避免为此单独加迁移）。
     *
     * @param array<int, array<string,?string>> $conflicts
     */
    private function conflictNote(array $conflicts): ?string
    {
        if ($conflicts === []) {
            return null;
        }

        $paths = [];
        foreach ($conflicts as $item) {
            $path = trim((string) ($item['path'] ?? ''));
            if ($path !== '' && !in_array($path, $paths, true)) {
                $paths[] = $path;
            }
        }

        $note = '本地改动冲突 ' . count($conflicts) . ' 个文件（已备份后覆盖）';
        if ($paths === []) {
            return $note;
        }

        $shown = array_slice($paths, 0, 20);
        $note .= '：' . implode('、', $shown);
        if (count($paths) > count($shown)) {
            $note .= ' 等（完整清单见备份目录 manifest.json）';
        }

        return $note;
    }

    /**
     * 把底层异常整理成面向运营的一句话（带步骤上下文，不带堆栈）
     */
    private function friendlyMessage(\Throwable $e, int $seq, string $from, string $to): string
    {
        $raw = trim($e->getMessage());
        if ($raw === '') {
            $raw = '未知错误';
        }
        if ($seq <= 0) {
            return '更新执行失败：' . $raw;
        }

        $prefix = "第 {$seq} 步（{$from} → {$to}）";
        if (str_starts_with($raw, $prefix)) {
            return $raw;
        }
        return $prefix . '执行失败：' . $raw;
    }

    /**
     * 源错误 → 短原因（用于「Gitee 超时、GitHub 404」式的聚合消息）
     */
    private function shortReason(string $message): string
    {
        if (preg_match('/timeout|timed out|超时/i', $message) === 1) {
            return '超时';
        }
        if (preg_match('/HTTP\s+(\d{3})/', $message, $m) === 1) {
            return 'HTTP ' . $m[1];
        }
        if (preg_match('/签名|SHA-256|校验/i', $message) === 1) {
            return '校验失败';
        }
        if (preg_match('/未配置/', $message) === 1) {
            return '分发地址未配置';
        }
        if (preg_match('/curl|connect|连接|不可达|DNS/i', $message) === 1) {
            return '不可达';
        }

        $text = trim((string) preg_replace('/\s+/', ' ', $message));
        return mb_strlen($text) > 60 ? mb_substr($text, 0, 60) . '…' : ($text !== '' ? $text : '不可达');
    }

    private function sourceLabel(string $name): string
    {
        return match ($name) {
            'gitee'  => 'Gitee',
            'github' => 'GitHub',
            'local'  => '本地源',
            default  => $name,
        };
    }

    private function shortenOutput(string $output): string
    {
        $output = trim((string) preg_replace('/\s+/', ' ', $output));
        if ($output === '') {
            return '命令没有输出，请登录服务器手工执行 php think migrate:run 查看原因';
        }
        return mb_strlen($output) > 300 ? mb_substr($output, 0, 300) . '…' : $output;
    }

    private function humanBytes(int $bytes): string
    {
        if ($bytes < 1024) {
            return $bytes . ' B';
        }
        $units = ['KB', 'MB', 'GB'];
        $value = $bytes / 1024;
        foreach ($units as $unit) {
            if ($value < 1024 || $unit === 'GB') {
                return number_format($value, $value < 10 ? 2 : 1) . ' ' . $unit;
            }
            $value /= 1024;
        }
        return $bytes . ' B';
    }

    private function abs(string $relative): string
    {
        return $this->root . '/' . ltrim(str_replace('\\', '/', $relative), '/');
    }

    private static function ensureDir(string $dir): void
    {
        if (is_dir($dir)) {
            return;
        }
        if (!@mkdir($dir, 0775, true) && !is_dir($dir)) {
            throw new BizException("无法创建目录：{$dir}");
        }
    }
}