<?php
declare(strict_types=1);

namespace app\common\service\update;

use app\common\exception\BizException;

/**
 * 基于 HTTP 分发的更新源基类
 *
 * 分发模型（见 config/update.php 的 distribution）：
 *   清单   {raw}/update.json
 *   签名   {raw}/update.json.sig
 *   资产   {raw}/v{version}/{asset}
 *
 * 仓库为公开仓库，raw 直链免鉴权，因此 Gitee / GitHub 两个适配器只剩「源名」不同，
 * 拉清单 + 拉签名、下载、HEAD 探测、文件名安全校验全部收敛在这里。
 */
abstract class HttpSource implements UpdateSourceInterface
{
    protected HttpClient $client;

    /** UpdatePackage 复用（清单解析 + 资产名校验） */
    protected UpdatePackage $package;

    public function __construct(?HttpClient $client = null, ?UpdatePackage $package = null)
    {
        $this->client  = $client ?? new HttpClient();
        $this->package = $package ?? new UpdatePackage();
    }

    /**
     * 清单与签名所在的 raw 目录（不含文件名）
     */
    protected function rawBase(): string
    {
        return $this->buildRawBase();
    }

    /**
     * 资产目录：{raw}/v{version}
     */
    protected function assetBase(string $version): string
    {
        return $this->rawBase() . '/v' . $version;
    }

    public function fetchManifest(): array
    {
        $rawUrl = $this->rawBase() . '/update.json';
        $sigUrl = $this->rawBase() . '/update.json.sig';

        $raw = $this->client->get($rawUrl);
        if (trim($raw) === '') {
            throw new BizException("{$this->label()} 返回的 update.json 为空：{$rawUrl}");
        }

        try {
            $signature = $this->client->get($sigUrl);
        } catch (BizException $e) {
            throw new BizException("{$this->label()} 缺少清单签名（update.json.sig）：" . $e->getMessage());
        }
        if (trim($signature) === '') {
            throw new BizException("{$this->label()} 的 update.json.sig 为空，无法验签");
        }

        return [
            'manifest'     => $this->package->parseManifest($raw),
            'manifest_raw' => $raw,
            'signature'    => $signature,
            'source'       => $this->name(),
        ];
    }

    public function fetchAsset(string $assetName, string $version, string $dest): void
    {
        UpdatePackage::assertSafeAssetName($assetName);
        $this->client->download($this->assetBase($version) . '/' . $assetName, $dest);
    }

    public function headAsset(string $assetName, string $version): array
    {
        UpdatePackage::assertSafeAssetName($assetName);
        return $this->client->head($this->assetBase($version) . '/' . $assetName);
    }

    // ------------------------------------------------------------------
    // 公共工具
    // ------------------------------------------------------------------

    protected function label(): string
    {
        return match ($this->name()) {
            'gitee'  => 'Gitee',
            'github' => 'GitHub',
            default  => $this->name(),
        };
    }

    /**
     * 取 config/update.php 里该源的仓库坐标
     */
    protected function repo(): string
    {
        $repo = trim((string) config('update.distribution.sources.' . $this->name() . '.repo', ''));
        if ($repo === '') {
            throw new BizException(
                "缺少分发源配置 update.distribution.sources.{$this->name()}.repo，请检查 config/update.php"
            );
        }
        return $repo;
    }

    protected function branch(): string
    {
        $branch = trim((string) config('update.distribution.branch', 'main'));
        return $branch !== '' ? $branch : 'main';
    }

    /**
     * 分发目录（仓库内，默认 update）
     */
    protected function dir(): string
    {
        $dir = trim(str_replace('\\', '/', (string) config('update.distribution.dir', 'update')), '/');
        return $dir !== '' ? $dir : 'update';
    }

    /**
     * 用 config('update.distribution.sources.<name>.raw') 模板拼 raw 根地址
     *
     * raw 地址就是分发仓库的根目录（update/ 本身是仓库根），
     * 地址是硬编码的（后台不可改），模板为空只可能是部署时漏了配置，直接报错不猜。
     */
    protected function buildRawBase(): string
    {
        $key      = 'update.distribution.sources.' . $this->name() . '.raw';
        $template = trim((string) config($key, ''));
        if ($template === '') {
            throw new BizException("缺少分发地址配置 {$key}，请检查 config/update.php");
        }
        return rtrim(strtr($template, [
            '{repo}'   => $this->repo(),
            '{branch}' => $this->branch(),
            '{dir}'    => $this->dir(),
        ]), '/');
    }
}