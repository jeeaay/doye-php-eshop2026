<?php
declare(strict_types=1);

namespace app\common\command;

use app\common\exception\BizException;
use app\common\release\DeltaBuilder;
use app\common\release\ManifestSigner;
use think\console\Command;
use think\console\Input;
use think\console\input\Argument as InputArgument;
use think\console\input\Option;
use think\console\Output;

/**
 * 构建版本增量发布包（发布端，仅维护者机器执行）
 *
 *   php think release:build --version=1.2.0
 *   php think release:build --version=1.2.0 --push     # 在 update/ 独立仓库里提交并推送到两个远端
 *
 * 产物（默认写入 update/；该目录是一个独立的 git 仓库，远端根目录就是它）：
 *   update/v{to}/delta-{from}-to-{to}.zip    只含本版变动的 add/modify 文件
 *   update/v{to}/delta-{from}-to-{to}.json   逐文件 before/after sha256 + 删除清单
 *   update/v{to}/vendor-{to}.zip             仅当 composer.json / composer.lock 变动时
 *   update/update.json                       累积的版本链（按版本升序）
 *   update/update.json.sig                   Ed25519 分离签名
 *
 * 地址、分支、分发目录全部取自 config/update.php 的 distribution 分组（唯一来源，后台不可改）。
 * 所有内容取自 tag 树（不读工作区），并要求工作区干净，保证同一个 tag 永远产出同一个包。
 * 本命令**只产出增量包**，不产出全量包：首次部署 / 灾难恢复请手工 git clone + composer install。
 *
 * --push 的边界（本项目不是开源项目）：公开仓库里**只有 update/**，
 * 源码仓库的提交与 tag 一律不推送；推送只发生在 update/ 这个独立仓库内。
 */
class ReleaseBuild extends Command
{
    /** 默认私钥位置（与 release:keygen 保持一致） */
    private const DEFAULT_KEY_PATH = 'runtime/release-signing.key';

    /** --force-push：远端历史被重建时覆盖分发分支 */
    private bool $pushForce = false;

    protected function configure(): void
    {
        $this->setName('release:build')
            ->addArgument('version', InputArgument::OPTIONAL, '版本号（不带 v；等同 --version=）', '')
            ->addOption('ver', null, Option::VALUE_OPTIONAL, '版本号（不带 v，必须与 version.json 一致）；入口会把 --version= 改写成它', '')
            ->addOption('git-dir', null, Option::VALUE_OPTIONAL, 'git 工作副本根目录（默认项目根；自测时可指向临时仓库）', '')
            ->addOption('manifest-dir', null, Option::VALUE_OPTIONAL, '清单目录（相对 git 根，默认取 config/update.php 的 distribution.dir）', '')
            ->addOption('out', null, Option::VALUE_OPTIONAL, '产物目录（相对 git 根，默认 {manifest-dir}/v{version}）', '')
            ->addOption('key', null, Option::VALUE_OPTIONAL, '清单签名私钥文件（默认 runtime/release-signing.key）', '')
            ->addOption('skip-vendor', null, Option::VALUE_NONE, '即使 composer.* 变更也不构建 vendor 包')
            ->addOption('db-breaking', null, Option::VALUE_NONE, '标记本版本含破坏性数据库迁移（站点会拒绝一键升级）')
            ->addOption('dry-run', null, Option::VALUE_NONE, '只计算变更与体积，不写任何文件')
            ->addOption('push', null, Option::VALUE_NONE, '在 update/ 这个独立仓库里提交并推送到 config/update.php 配置的远端（不推源码、不推 tag）')
            ->addOption('force-push', null, Option::VALUE_NONE, '推送时对分发分支使用 --force（远端历史被重建时使用）')
            ->setDescription('构建增量发布包、签发 update.json，可选直接推送（仅维护者机器）');
    }

    protected function execute(Input $input, Output $output): int
    {
        try {
            return $this->build($input, $output);
        } catch (BizException $e) {
            $output->writeln('<error>' . $e->getMessage() . '</error>');
            return 1;
        }
    }

    // ------------------------------------------------------------------
    // 主流程
    // ------------------------------------------------------------------

    private function build(Input $input, Output $output): int
    {
        $version = $this->versionOption($input);
        if ($version === '') {
            throw new BizException('必须用 --version 指定版本号（不带 v，例如 --version=1.2.0；也可写作位置参数）');
        }
        if (!preg_match('/^\d+\.\d+\.\d+([.-][0-9A-Za-z.-]+)?$/', $version)) {
            throw new BizException("版本号格式不正确：{$version}（应形如 1.2.0）");
        }

        $projectRoot = $this->projectRoot();
        $repoRoot    = $this->absolutePath((string) $input->getOption('git-dir'), $projectRoot);

        // 分发目录：默认取硬编码配置（update），--manifest-dir 仅用于自测指向临时目录
        $configDir   = $this->distributionDir();
        $manifestOpt = trim(str_replace('\\', '/', (string) $input->getOption('manifest-dir')), '/');
        $manifestRel = $manifestOpt !== '' ? $manifestOpt : $configDir;
        $manifestDir = $this->absolutePath($manifestRel, $repoRoot);

        $outOpt = trim(str_replace('\\', '/', (string) $input->getOption('out')), '/');
        $outDir = $this->absolutePath($outOpt !== '' ? $outOpt : $manifestRel . '/v' . $version, $repoRoot);

        $dryRun = (bool) $input->getOption('dry-run');
        $push   = (bool) $input->getOption('push');
        $tag    = 'v' . $version;

        $this->pushForce = (bool) $input->getOption('force-push');

        // --push 只允许写正式分发目录：临时目录里的产物推上去会让站点端永远拿不到清单
        if ($push && $manifestRel !== trim($configDir, '/')) {
            throw new BizException(sprintf(
                '--push 只能用于正式分发目录 %s/（当前 --manifest-dir=%s）；自测请去掉 --push',
                $configDir,
                $manifestRel
            ));
        }

        // 1. 版本一致性 + tag + 工作区
        $meta = $this->readVersionFile($repoRoot);
        if ((string) ($meta['version'] ?? '') !== $version) {
            throw new BizException(sprintf(
                'version.json 的版本是 %s，与 --version=%s 不一致；请先更新并提交 version.json',
                (string) ($meta['version'] ?? '(缺失)'),
                $version
            ));
        }

        $builder = new DeltaBuilder($repoRoot);
        if (!$builder->tagExists($tag)) {
            throw new BizException(
                "tag {$tag} 不存在。请先提交本次版本并打 tag：" . PHP_EOL
                . "    git tag -a {$tag} -m \"{$version}\""
            );
        }
        if (!$builder->isClean()) {
            throw new BizException(
                '工作区不干净，增量包必须与 tag 严格一致，请先提交或 stash：' . PHP_EOL . $builder->dirtyStatus()
            );
        }

        // 2. 上一个版本
        $prevTag = $builder->prevTag($tag);
        if ($prevTag === '') {
            $output->writeln('<error>首个版本无法生成增量包，首次部署请手工 clone 并 composer install</error>');
            return 1;
        }
        $prevVersion = $this->tagToVersion($prevTag);

        // 3. 变更清单（只保留站点端白名单内、可安装的路径；其余回报给维护者）
        $skipped = [];
        $ops     = $builder->filterPaths($builder->diffOps($prevTag, $tag), $skipped);
        if ($ops === []) {
            $output->writeln("<info>无代码变更，跳过（{$prevVersion} → {$version}）</info>");
            $this->printSkipped($output, $skipped);
            return 0;
        }

        $stat = $this->summarize($ops);
        $needVendor = $builder->needVendor($prevTag, $tag);

        if ($dryRun) {
            $output->writeln('<info>[dry-run] 不写任何文件' . ($push ? '，--push 已忽略' : '') . '</info>');
            $output->writeln("  仓库      ：{$repoRoot}");
            $output->writeln("  版本      ：{$prevVersion} → {$version}（tag {$prevTag} → {$tag}）");
            $output->writeln('  变更操作  ：' . $stat['total'] . ' 条（新增 ' . $stat['add'] . ' / 修改 ' . $stat['modify'] . ' / 删除 ' . $stat['delete'] . '）');
            $output->writeln('  涉及文件  ：' . $stat['files'] . ' 个（删除条目不入包）');
            $output->writeln('  原始体积  ：' . $this->humanBytes($stat['bytes']));
            $output->writeln('  依赖变更  ：' . ($needVendor ? '是（需构建 vendor 包）' : '否'));
            $output->writeln('  产物目录  ：' . $this->relativeTo($outDir, $repoRoot));
            $output->writeln('  清单目录  ：' . $this->relativeTo($manifestDir, $repoRoot));
            $output->writeln('  预计包大小：' . $this->humanBytes($stat['bytes']) . ' 以内（zip 压缩后通常更小）');
            if ($push) {
                $output->writeln('  推送目标  ：' . implode(' + ', $this->distributionOrder())
                    . '（分支 ' . $this->branch() . '，仓库根 = ' . trim($manifestRel, '/') . '/）');
                $output->writeln('  推送方式  ：在 ' . trim($manifestRel, '/') . '/ 这个独立仓库里 commit 后 push，只推分发内容，不推源码与 tag');
            }
            $this->printSkipped($output, $this->printableSkipped($output, $skipped, $manifestRel));
            return 0;
        }

        // 4. 产出 delta zip + ops json
        DeltaBuilder::ensureDir($outDir);
        $assetName = "delta-{$prevVersion}-to-{$version}.zip";
        $opsName   = "delta-{$prevVersion}-to-{$version}.json";
        $assetPath = $outDir . '/' . $assetName;
        $opsPath   = $outDir . '/' . $opsName;

        $builder->buildDeltaZip($ops, $assetPath, $tag);

        // 5. vendor 包（只有真的产出 vendor zip，清单里的 need_vendor 才为真，
        //    否则站点端会去下载一个不存在的资产）
        $vendorAsset  = null;
        $vendorSha    = null;
        $vendorSize   = 0;
        if ($needVendor) {
            if ((bool) $input->getOption('skip-vendor')) {
                $output->writeln('<comment>composer.json / composer.lock 有变更，但指定了 --skip-vendor：本次不产出 vendor 包，'
                    . '清单会标记 need_vendor=false，站点依赖需你手工处理</comment>');
            } else {
                $vendorName = "vendor-{$version}.zip";
                $vendorPath = $outDir . '/' . $vendorName;
                $this->buildVendorZip($builder, $tag, $version, $vendorPath, $output);
                $vendorAsset = $vendorName;
                $vendorHash  = hash_file('sha256', $vendorPath);
                $vendorSha   = $vendorHash === false ? null : $vendorHash;
                $vendorSize  = (int) filesize($vendorPath);
            }
        }
        $publishedVendor = $vendorAsset !== null;

        $opsJson = $this->encodeJson([
            'schema'      => 1,
            'from'        => $prevVersion,
            'to'          => $version,
            'php_min'     => (string) ($meta['php_min'] ?? '8.0.0'),
            'db_version'  => (string) ($meta['db_version'] ?? ''),
            'need_vendor' => $publishedVendor,
            'ops'         => $ops,
        ]);
        $this->atomicWrite($opsPath, $opsJson);

        // 6. 更新 {manifest-dir}/update.json 并签名
        $manifestPath = $manifestDir . '/update.json';
        $signPath     = $manifestDir . '/update.json.sig';
        $manifest     = $this->loadManifest($manifestPath);

        $assetSha = hash_file('sha256', $assetPath);
        $opsSha   = hash_file('sha256', $opsPath);
        if ($assetSha === false || $opsSha === false) {
            throw new BizException('计算产物 sha256 失败');
        }

        $step = [
            'from'          => $prevVersion,
            'to'            => $version,
            'asset'         => $assetName,
            'asset_size'    => (int) filesize($assetPath),
            'asset_sha256'  => $assetSha,
            'ops_asset'     => $opsName,
            'ops_sha256'    => $opsSha,
            'ops_count'     => count($ops),
            'delta_bytes'   => (int) filesize($opsPath),
            'need_vendor'   => $publishedVendor,
            'vendor_asset'  => $vendorAsset,
            'vendor_sha256' => $vendorSha,
            'vendor_size'   => $vendorSize,
            'db_version'    => (string) ($meta['db_version'] ?? ''),
            'db_breaking'   => (bool) $input->getOption('db-breaking'),
            'notes_url'     => $this->notesUrl($version),
        ];

        $manifest['schema']    = 1;
        $manifest['latest']    = $version;
        $manifest['php_min']   = (string) ($meta['php_min'] ?? '8.0.0');
        $manifest['signed_at'] = date('c');
        $manifest['steps']     = $this->mergeSteps((array) ($manifest['steps'] ?? []), $step, $prevVersion);

        $manifestJson = $this->encodeJson($manifest);
        $this->atomicWrite($manifestPath, $manifestJson);

        $signer = new ManifestSigner();
        $signer->loadSecretKey($this->keyPath((string) $input->getOption('key')));
        $signature = $signer->sign($manifestJson);
        $this->atomicWrite($signPath, $signature . "\n");

        $this->assertSignatureMatches($manifestJson, $signature, $output);

        // 7. 输出
        $output->writeln('<info>构建完成</info>');
        $output->writeln("  变更    ：{$stat['total']} 条（新增 {$stat['add']} / 修改 {$stat['modify']} / 删除 {$stat['delete']}）");
        $output->writeln('  产物目录：' . $this->relativeTo($outDir, $repoRoot));
        $output->writeln('  清单    ：' . $this->relativeTo($manifestPath, $repoRoot)
            . PHP_EOL . '  签名    ：' . $this->relativeTo($signPath, $repoRoot));
        $this->printSkipped($output, $this->printableSkipped($output, $skipped, $manifestRel));
        $output->writeln('');
        $this->printDistribution($output, $manifestRel, $version, [
            $assetName   => (int) filesize($assetPath),
            $opsName     => (int) filesize($opsPath),
            $vendorAsset => $vendorSize,
        ], [
            $assetName   => $assetSha,
            $opsName     => $opsSha,
            $vendorAsset => $vendorSha,
        ]);

        // 8. 可选：提交分发目录并推送到各远端
        if (!$push) {
            return 0;
        }

        return $this->pushToRemotes($output, $repoRoot, $manifestRel, $version);
    }

    // ------------------------------------------------------------------
    // 推送
    // ------------------------------------------------------------------

    /**
     * 在分发的独立仓库（update/.git）里提交并推送到各远端
     *
     * 边界（本项目不是开源项目）：
     * - 公开仓库的根目录就是 update/，远端只会出现增量包与清单；
     * - 只推送依赖目录自身的历史，**绝不**推送源码仓库的提交与 tag。
     */
    private function pushToRemotes(Output $output, string $repoRoot, string $manifestRel, string $version): int
    {
        $distRoot = $this->absolutePath($manifestRel, $repoRoot);
        if (!is_dir($distRoot . '/.git')) {
            throw new BizException(
                "分发目录 {$manifestRel}/ 还不是独立 git 仓库：请先在该目录执行 git init -b main 并添加远端"
            );
        }

        $builder = new DeltaBuilder($distRoot);
        $branch  = $this->branch();
        $tag     = 'v' . $version;
        $force   = (bool) $this->pushForce;

        // 防御：确认 git 根目录就是分发目录，避免误把源码仓库推上去
        [$topCode, $topLevel] = $builder->gitSafe(['rev-parse', '--show-toplevel']);
        if ($topCode !== 0
            || $this->normalizePath($topLevel) !== $this->normalizePath($distRoot)) {
            throw new BizException(
                "分发目录 {$manifestRel}/ 的 git 根目录异常（" . trim($topLevel) . '），已中止推送'
            );
        }

        $output->writeln('');
        $output->writeln("<info>提交并推送分发仓库 {$manifestRel}/</info>");

        // 1. 暂存并提交（只作用于分发仓库，与源码仓库无关）
        $builder->git(['add', '-A']);
        [$staged] = $builder->gitSafe(['diff', '--cached', '--quiet']);
        if ($staged === 0) {
            $output->writeln('  <comment>分发目录没有变化，跳过 commit</comment>');
        } else {
            $builder->git(['commit', '-m', 'release: ' . $tag]);
            $output->writeln('  已提交：release: ' . $tag);
        }

        [$headCode, $headSha] = $builder->gitSafe(['rev-parse', '--short', 'HEAD']);
        $headSha = $headCode === 0 ? trim($headSha) : '(无提交)';

        // 2. 逐源推送（只推分发分支，不推 tag）
        $failed = [];
        foreach ($this->distributionOrder() as $name) {
            $pushUrl = trim((string) config('update.distribution.sources.' . $name . '.push', ''));

            [$code] = $builder->gitSafe(['remote', 'get-url', $name]);
            if ($code !== 0) {
                if ($pushUrl === '') {
                    $failed[$name] = '配置缺少 update.distribution.sources.' . $name . '.push，无法自动添加远端';
                    $output->writeln("  <error>{$name}：{$failed[$name]}</error>");
                    continue;
                }
                $builder->git(['remote', 'add', $name, $pushUrl]);
                $output->writeln("  {$name}：已添加远端 {$pushUrl}");
            }

            $errors  = [];
            $refspec = 'HEAD:refs/heads/' . $branch;
            if (!$this->pushRef($builder, $name, $refspec, $errors, $force)) {
                $errors[] = '分支 ' . $branch . ' 推送失败';
            }

            if ($errors === []) {
                $output->writeln("  <info>{$name}：推送成功（{$branch} @ {$headSha}）</info>");
                continue;
            }

            $failed[$name] = implode('；', $errors);
            $output->writeln("  <error>{$name}：推送失败</error> " . $this->shorten(implode(' / ', $errors), 400));
        }

        // 3. 汇总
        $output->writeln('');
        $ok = array_values(array_diff(array_map('strval', $this->distributionOrder()), array_keys($failed)));
        $output->writeln('推送结果：成功 ' . ($ok === [] ? '（无）' : implode('、', $ok))
            . ' / 失败 ' . ($failed === [] ? '（无）' : implode('、', array_keys($failed))));

        if ($failed !== []) {
            $output->writeln('<error>部分远端推送失败，命令以非零码退出；已成功的远端不会回滚</error>');
            foreach ($failed as $name => $reason) {
                $output->writeln('  - ' . $name . '：' . $reason);
            }
            if (!$force) {
                $output->writeln('<comment>若远端历史被重建（例如刚清空仓库），可加 --force-push 重新覆盖分发分支。</comment>');
            }
            return 1;
        }

        $output->writeln('<comment>远端只包含分发目录内容；源码仓库的提交与 tag 均未推送。</comment>');
        return 0;
    }

    /**
     * 单个 refspec 推送（失败只记录，不抛异常，保证两个远端都尝试一遍）
     *
     * @param array<int, string> $errors
     */
    private function pushRef(DeltaBuilder $builder, string $remote, string $refspec, array &$errors, bool $force = false): bool
    {
        $args = ['push', $remote, $refspec];
        if ($force) {
            $args = ['push', '--force', $remote, $refspec];
        }
        [$code, $stdout, $stderr] = $builder->gitSafe($args);
        if ($code === 0) {
            return true;
        }

        $detail = trim($stderr !== '' ? $stderr : $stdout);
        if ($detail !== '') {
            $errors[] = $refspec . ' → ' . $this->shorten($detail, 300);
        }
        return false;
    }

    // ------------------------------------------------------------------
    // 构建辅助
    // ------------------------------------------------------------------

    /**
     * 过滤掉分发目录自身的变更（update/）
     *
     * 分发目录里的历史产物天然不在站点可写白名单内，每次发版的 diff 都会带上它们，
     * 逐条打印只会变成噪音；这里静默跳过并给一句说明。
     *
     * @param array<int, string> $skipped
     * @return array<int, string>
     */
    private function printableSkipped(Output $output, array $skipped, string $manifestRel): array
    {
        $prefix   = trim($manifestRel, '/') . '/';
        $filtered = array_values(array_filter(
            $skipped,
            static fn ($path): bool => !str_starts_with((string) $path, $prefix)
        ));

        if (count($filtered) !== count($skipped)) {
            $output->writeln('<comment>提示：分发目录 ' . trim($manifestRel, '/') . '/ 里的历史产物按设计不入增量包，已静默跳过。</comment>');
        }

        return $filtered;
    }

    /**
     * 读取版本号（--ver= 优先，其次位置参数）
     */
    private function versionOption(Input $input): string
    {
        $version = trim((string) $input->getOption('ver'));
        if ($version === '') {
            $version = trim((string) $input->getArgument('version'));
        }
        return $version;
    }

    /**
     * 打印「未纳入增量包」的变更
     *
     * 这些路径不在站点端的可写白名单内（config/update.php），站点会拒收包含它们的包，
     * 所以构建时剔除。维护者需要知道哪些改动不会随增量分发（通常只有开发文档/仓库元数据）。
     *
     * @param array<int, string> $skipped
     */
    private function printSkipped(Output $output, array $skipped): void
    {
        if ($skipped === []) {
            return;
        }

        $output->writeln('<comment>以下变更不在站点可写白名单内，已排除（不随增量包分发）：</comment>');
        foreach ($skipped as $path) {
            $output->writeln('  - ' . $path);
        }
        $output->writeln('  说明：只分发 config/update.php 的 manage_roots / root_files 内的文件；'
            . '要分发请改该白名单（站点端同一份清单，不要另写数组）。');
    }

    /**
     * 读取 version.json（版本唯一来源）
     *
     * @return array<string, mixed>
     */
    private function readVersionFile(string $repoRoot): array
    {
        $path = $repoRoot . '/version.json';
        if (!is_file($path)) {
            throw new BizException("缺少 {$path}，无法确定版本与 db_version");
        }
        $data = json_decode(ltrim((string) file_get_contents($path), "\xEF\xBB\xBF"), true);
        if (!is_array($data)) {
            throw new BizException("version.json 不是合法 JSON：{$path}");
        }
        return $data;
    }

    /**
     * @param array<int, array<string, mixed>> $ops
     * @return array{add: int, modify: int, delete: int, files: int, total: int, bytes: int}
     */
    private function summarize(array $ops): array
    {
        $stat = ['add' => 0, 'modify' => 0, 'delete' => 0, 'files' => 0, 'total' => count($ops), 'bytes' => 0];
        foreach ($ops as $op) {
            $type = (string) ($op['op'] ?? '');
            if (isset($stat[$type])) {
                $stat[$type]++;
            }
            if ($type !== 'delete') {
                $stat['files']++;
                $stat['bytes'] += (int) ($op['size'] ?? 0);
            }
        }
        return $stat;
    }

    /**
     * 合并 steps：同一 from 覆盖，按 to 升序排列
     *
     * @param array<int, mixed>       $steps
     * @param array<string, mixed>    $step
     * @return array<int, mixed>
     */
    private function mergeSteps(array $steps, array $step, string $prevVersion): array
    {
        $merged = [];
        foreach ($steps as $existing) {
            if (!is_array($existing)) {
                continue;
            }
            // 同一 from 的旧记录被新构建覆盖，避免链上出现分叉
            if ((string) ($existing['from'] ?? '') === $prevVersion) {
                continue;
            }
            $merged[] = $existing;
        }
        $merged[] = $step;

        usort($merged, static function ($a, $b): int {
            return version_compare((string) ($a['to'] ?? '0'), (string) ($b['to'] ?? '0'));
        });

        return array_values($merged);
    }

    /**
     * @return array<string, mixed>
     */
    private function loadManifest(string $path): array
    {
        if (!is_file($path)) {
            return ['schema' => 1, 'latest' => '', 'php_min' => '8.0.0', 'signed_at' => '', 'steps' => []];
        }
        $raw  = ltrim((string) file_get_contents($path), "\xEF\xBB\xBF");
        $data = json_decode($raw, true);
        if (!is_array($data)) {
            throw new BizException("update.json 解析失败（{$path}），请修复或删除后重新构建");
        }
        if (!isset($data['steps']) || !is_array($data['steps'])) {
            $data['steps'] = [];
        }
        return $data;
    }

    /**
     * 构建 vendor-{to}.zip：在临时目录按 tag 里的 composer.* 安装依赖后整目录打包
     */
    private function buildVendorZip(DeltaBuilder $builder, string $tag, string $version, string $zipPath, Output $output): void
    {
        $composer = $this->findComposer();
        if ($composer === '') {
            throw new BizException(
                '未找到 composer 命令，无法构建 vendor 包。' . PHP_EOL
                . '请安装 Composer 后重试，或加 --skip-vendor 手动处理站点依赖。'
            );
        }

        $tmp = rtrim(str_replace('\\', '/', (string) $this->app->getRuntimePath()), '/')
            . '/release/vendor-' . $version . '-' . bin2hex(random_bytes(4));
        DeltaBuilder::ensureDir($tmp);

        try {
            foreach (['composer.json', 'composer.lock'] as $file) {
                try {
                    $content = $builder->fileAt($tag, $file);
                } catch (BizException $e) {
                    if ($file === 'composer.json') {
                        throw $e; // 没有 composer.json 就没有依赖可装
                    }
                    $content = null; // composer.lock 未入库时允许缺席
                }
                if ($content !== null) {
                    file_put_contents($tmp . '/' . $file, $content);
                }
            }

            $output->writeln('<comment>正在临时目录执行 composer install（--no-dev）…</comment>');
            $this->runProcess(
                $composer . ' install --no-dev --optimize-autoloader --no-interaction --working-dir='
                . escapeshellarg($tmp),
                'composer install 失败'
            );

            if (!is_dir($tmp . '/vendor')) {
                throw new BizException('composer install 未产出 vendor 目录');
            }

            $count = $this->zipDirectory($tmp . '/vendor', 'vendor', $zipPath);
            $output->writeln("  已打包 vendor 文件 {$count} 个 → {$zipPath}");
        } finally {
            self::removeTree($tmp);
        }
    }

    /**
     * 把 $sourceDir 下的文件按 $prefix 前缀写入 zip（条目字母序，保证可复现）
     *
     * @return int 写入的文件数
     */
    private function zipDirectory(string $sourceDir, string $prefix, string $zipPath): int
    {
        $sourceDir = rtrim(str_replace('\\', '/', $sourceDir), '/');
        $entries   = [];
        $iterator  = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($sourceDir, \FilesystemIterator::SKIP_DOTS)
        );
        foreach ($iterator as $file) {
            /** @var \SplFileInfo $file */
            if (!$file->isFile()) {
                continue;
            }
            $abs = str_replace('\\', '/', $file->getPathname());
            $rel = ltrim(substr($abs, strlen($sourceDir)), '/');
            if ($rel === '') {
                continue;
            }
            $entries[$prefix . '/' . $rel] = $abs;
        }
        ksort($entries, SORT_STRING);

        if (is_file($zipPath)) {
            @unlink($zipPath);
        }
        DeltaBuilder::ensureDir(dirname($zipPath));

        $zip = new \ZipArchive();
        if ($zip->open($zipPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
            throw new BizException("无法创建 vendor 包：{$zipPath}");
        }
        try {
            foreach ($entries as $local => $abs) {
                if (!$zip->addFile($abs, $local)) {
                    throw new BizException("写入 vendor 包条目失败：{$local}");
                }
            }
        } finally {
            $zip->close();
        }

        return count($entries);
    }

    /**
     * 签名自检：用 config/update.php 的公钥验一遍刚写出的清单
     */
    private function assertSignatureMatches(string $manifestJson, string $signature, Output $output): void
    {
        if (trim((string) config('update.public_key')) === '') {
            $output->writeln('<comment>警告：config/update.php 的 public_key 为空，本次无法自检签名；站点端在公钥填入前无法验签。</comment>');
            return;
        }

        if (!(new ManifestSigner())->verify($manifestJson, $signature)) {
            throw new BizException('签名自检失败：config/update.php 的 public_key 与当前私钥不匹配，站点端会拒绝这份清单');
        }
        $output->writeln('  签名自检：通过（与 config/update.php 的公钥匹配）');
    }

    // ------------------------------------------------------------------
    // 分发坐标（全部来自 config/update.php）
    // ------------------------------------------------------------------

    /**
     * 分发目录（默认 update）
     */
    private function distributionDir(): string
    {
        $dir = trim(str_replace('\\', '/', (string) config('update.distribution.dir', 'update')), '/');
        return $dir !== '' ? $dir : 'update';
    }

    /**
     * 分发分支（默认 main）
     */
    private function branch(): string
    {
        $branch = trim((string) config('update.distribution.branch', 'main'));
        return $branch !== '' ? $branch : 'main';
    }

    /**
     * 源优先级（默认 gitee → github）
     *
     * @return string[]
     */
    private function distributionOrder(): array
    {
        $order = [];
        foreach ((array) config('update.distribution.order', ['gitee', 'github']) as $name) {
            $name = strtolower(trim((string) $name));
            if ($name !== '' && !in_array($name, $order, true)) {
                $order[] = $name;
            }
        }
        return $order !== [] ? $order : ['gitee', 'github'];
    }

    /**
     * 按模板拼出某源的 raw 目录（缺配置返回空串，不抛异常，仅用于打印）
     */
    private function rawBaseFor(string $name): string
    {
        $template = trim((string) config('update.distribution.sources.' . $name . '.raw', ''));
        $repo     = trim((string) config('update.distribution.sources.' . $name . '.repo', ''));
        if ($template === '' || $repo === '') {
            return '';
        }
        return rtrim(strtr($template, [
            '{repo}'   => $repo,
            '{branch}' => $this->branch(),
            '{dir}'    => $this->distributionDir(),
        ]), '/');
    }

    /**
     * 生成 CHANGELOG 锚点地址（第一个配了仓库坐标的源的网页地址）
     */
    private function notesUrl(string $version): ?string
    {
        foreach ($this->distributionOrder() as $name) {
            $repo = trim((string) config('update.distribution.sources.' . $name . '.repo', ''));
            if ($repo === '') {
                continue;
            }
            $host = match ($name) {
                'gitee'  => 'https://gitee.com',
                'github' => 'https://github.com',
                default  => '',
            };
            if ($host === '') {
                continue;
            }
            return $host . '/' . $repo . '/blob/' . $this->branch() . '/CHANGELOG.md#' . str_replace('.', '', $version);
        }
        return null;
    }

    /**
     * 打印分发地址与产物清单
     *
     * @param array<string, int>          $sizes 文件名 → 字节数（0 表示未产出）
     * @param array<string, string|null>  $shas  文件名 → sha256
     */
    private function printDistribution(Output $output, string $manifestRel, string $version, array $sizes, array $shas): void
    {
        $output->writeln('分发地址（站点端按 config/update.php 的 distribution.order 依次尝试，仓库地址硬编码不可改）：');
        foreach ($this->distributionOrder() as $name) {
            $base = $this->rawBaseFor($name);
            if ($base === '') {
                $output->writeln("  <comment>{$name}：未配置 repo / raw，跳过</comment>");
                continue;
            }
            $output->writeln(sprintf('  %-6s 清单：%s/update.json', $name, $base));
            $output->writeln(sprintf('  %-6s 资产：%s/v%s/', $name, $base, $version));
        }
        $output->writeln('');

        foreach ($sizes as $name => $size) {
            if ($name === '' || $size === 0) {
                continue;
            }
            $output->writeln(sprintf(
                '  %-34s %10s  sha256=%s',
                $this->relativePathOfAsset($manifestRel, $version, $name),
                $this->humanBytes($size),
                (string) ($shas[$name] ?? '')
            ));
        }

        $tag = 'v' . $version;
        $output->writeln('');
        $output->writeln("产物已写入 {$manifestRel}/v{$version}/，清单已签发（{$manifestRel}/update.json + update.json.sig）。");
        $output->writeln('下一步（任选其一）：');
        $output->writeln("  自动：php think release:build --version={$this->tagToVersion($tag)} --push"
            . '（在 ' . trim($manifestRel, '/') . '/ 独立仓库里提交并推送到 '
            . implode(' + ', $this->distributionOrder()) . '；tag 需提前手动打好，且不会推送 tag）');
        $output->writeln('  手工：cd ' . trim($manifestRel, '/') . ' && git add -A && git commit -m "release: '
            . $tag . '" && git push gitee HEAD:' . $this->branch() . ' && git push github HEAD:' . $this->branch());
    }

    /**
     * 产物在仓库内的相对路径（仅用于打印）
     */
    private function relativePathOfAsset(string $manifestRel, string $version, string $asset): string
    {
        return $manifestRel . '/v' . $version . '/' . $asset;
    }

    // ------------------------------------------------------------------
    // 通用工具
    // ------------------------------------------------------------------

    private function projectRoot(): string
    {
        return rtrim(str_replace('\\', '/', (string) $this->app->getRootPath()), '/');
    }

    /**
     * 相对路径按 git 工作副本根解析；已是绝对路径（含盘符）则原样返回
     */
    private function absolutePath(string $path, string $base): string
    {
        $path = trim(str_replace('\\', '/', $path));
        if ($path === '') {
            return $base;
        }
        if (preg_match('#^[A-Za-z]:/#', $path) || str_starts_with($path, '/')) {
            return rtrim($path, '/');
        }
        return rtrim($base . '/' . ltrim($path, '/'), '/');
    }

    /**
     * 绝对路径 → 相对 $base 的展示路径
     */
    private function relativeTo(string $abs, string $base): string
    {
        $abs    = rtrim(str_replace('\\', '/', $abs), '/');
        $prefix = rtrim(str_replace('\\', '/', $base), '/') . '/';
        return str_starts_with($abs, $prefix) ? substr($abs, strlen($prefix)) : $abs;
    }

    /**
     * 统一路径形态（斜杠、大小写无关的比较交给调用方），用于校验 git 根目录
     */
    private function normalizePath(string $path): string
    {
        $path = str_replace('\\', '/', trim($path));
        $path = (string) realpath($path);
        return rtrim(str_replace('\\', '/', $path), '/');
    }

    private function keyPath(string $option): string
    {
        $path = trim($option);
        if ($path === '') {
            return $this->projectRoot() . '/' . self::DEFAULT_KEY_PATH;
        }
        return $this->absolutePath($path, $this->projectRoot());
    }

    /**
     * tag → 版本号（去掉前缀 v）
     */
    private function tagToVersion(string $tag): string
    {
        $tag = trim($tag);
        return str_starts_with($tag, 'v') ? substr($tag, 1) : $tag;
    }

    /**
     * @param array<string, mixed> $data
     */
    private function encodeJson(array $data): string
    {
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($json === false) {
            throw new BizException('JSON 编码失败：' . json_last_error_msg());
        }
        return $json . "\n";
    }

    /**
     * 临时文件 + rename，避免半截文件被站点读到
     */
    private function atomicWrite(string $path, string $bytes): void
    {
        DeltaBuilder::ensureDir(dirname($path));
        $tmp = $path . '.tmp' . bin2hex(random_bytes(4));
        if (file_put_contents($tmp, $bytes) === false) {
            throw new BizException("写入失败：{$tmp}");
        }
        if (!@rename($tmp, $path)) {
            @unlink($tmp);
            throw new BizException("无法替换目标文件：{$path}");
        }
    }

    /**
     * 定位 composer 命令
     *
     * 优先「PHP_BINARY + 同目录 composer.phar」——phpstudy / Windows 官方安装器都是这个布局，
     * 且不经过 .bat，参数与路径转义最稳；其次才回退到 PATH 里的 composer。
     *
     * 注意：Windows 上**不能**把命令名写成 escapeshellarg('composer')（即 "composer"），
     * 那样 composer.bat 里的 %~dp0 会失效，它会跑到当前目录找 composer.phar 而报
     * 「Could not open input file: .\composer.phar」。所以这里用 call + 不加引号的命令名。
     *
     * @return string 可直接拼进命令行前缀；找不到返回空串
     */
    private function findComposer(): string
    {
        $phar = str_replace('\\', '/', dirname(PHP_BINARY)) . '/composer.phar';
        if (is_file($phar)) {
            return escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg($phar);
        }

        $candidates = DIRECTORY_SEPARATOR === '\\'
            ? ['call composer --version' => 'call composer', 'composer --version' => 'composer']
            : ['composer --version' => 'composer'];

        foreach ($candidates as $probe => $command) {
            [$code] = $this->runProcess($probe, '', false);
            if ($code === 0) {
                return $command;
            }
        }

        return '';
    }

    /**
     * 同步执行外部命令
     *
     * @return array{0: int, 1: string, 2: string}
     */
    private function runProcess(string $command, string $errorMessage = '', bool $throwOnError = true): array
    {
        $descriptors = [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
        $process = @proc_open($command, $descriptors, $pipes);
        if (!is_resource($process)) {
            if ($throwOnError) {
                throw new BizException(($errorMessage !== '' ? $errorMessage . '：' : '') . "无法启动命令 {$command}");
            }
            return [-1, '', '无法启动进程'];
        }
        fclose($pipes[0]);
        $stdout = (string) stream_get_contents($pipes[1]);
        $stderr = (string) stream_get_contents($pipes[2]);
        fclose($pipes[1]);
        fclose($pipes[2]);
        $code = (int) proc_close($process);

        if ($throwOnError && $code !== 0) {
            throw new BizException(
                ($errorMessage !== '' ? $errorMessage . '：' : "命令执行失败（exit {$code}）：") . PHP_EOL
                . trim($stdout . PHP_EOL . $stderr)
            );
        }

        return [$code, $stdout, trim($stderr)];
    }

    private function shorten(string $text, int $limit = 200): string
    {
        $text = trim((string) preg_replace('/\s+/', ' ', $text));
        return mb_strlen($text) > $limit ? mb_substr($text, 0, $limit) . '…' : $text;
    }

    private function humanBytes(int $bytes): string
    {
        if ($bytes < 1024) {
            return $bytes . ' B';
        }
        $units = ['KB', 'MB', 'GB'];
        $value = $bytes / 1024;
        foreach ($units as $unit) {
            if ($value < 1024 || $unit === 'GB') {
                return number_format($value, $value < 10 ? 2 : 1) . ' ' . $unit;
            }
            $value /= 1024;
        }
        return $bytes . ' B';
    }

    /**
     * 递归删除目录（Windows 下 git / composer 产物可能是只读）
     */
    public static function removeTree(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }
        foreach (new \DirectoryIterator($dir) as $file) {
            if ($file->isDot()) {
                continue;
            }
            $path = $file->getPathname();
            @chmod($path, 0666);
            if ($file->isDir() && !$file->isLink()) {
                self::removeTree($path);
            } else {
                @unlink($path);
            }
        }
        @chmod($dir, 0777);
        @rmdir($dir);
    }
}