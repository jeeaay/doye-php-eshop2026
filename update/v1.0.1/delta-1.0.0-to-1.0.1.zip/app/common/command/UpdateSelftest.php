<?php
declare(strict_types=1);

namespace app\common\command;

use app\common\exception\BizException;
use app\common\model\SiteUpdate;
use app\common\model\SiteUpdateStep;
use app\common\release\DeltaBuilder;
use app\common\release\ManifestSigner;
use app\common\service\UpdateService;
use app\common\service\update\UpdatePackage;
use app\common\support\AppContext;
use think\console\Command;
use think\console\Input;
use think\console\input\Option;
use think\console\Output;
use think\facade\Cache;
use think\facade\Config;

/**
 * 在线增量更新端到端自测（AC1–AC13）
 *
 *   php think update:selftest [--all] [--keep] [--only=AC1,AC4] [--force]
 *
 * 目标：在**不依赖外网、不污染项目源码、不改真实数据库结构**的前提下机器验证
 * 发布端构建 + 站点端升级链的核心行为。
 *
 * 夹具（全部在 runtime/selftest/ 下，取用时才创建）：
 *
 *   runtime/selftest/upstream/     临时 git 仓库（三个 tag，覆盖 add/modify/delete/rename）
 *   runtime/selftest/key           临时签名私钥（release:keygen 生成）
 *   runtime/selftest/dist/         release:build 产物 + LocalSource 目录结构
 *                                  （{base}/update.json + {base}/v{version}/{asset}）
 *   runtime/selftest/dist-xxx      用例专用清单变体（只保留单步 / 篡改 / vendor / 断链）
 *   runtime/selftest/snapshot/     v0.0.1 的工作树快照（含假 think 与旧 vendor）
 *   runtime/selftest/site/         沙箱站点根，每个用例前重建
 *
 * 关键隔离手段：
 *  - 站点端一律 `new UpdateService(runtime/selftest/site)`，绝不使用默认项目根；
 *  - 沙箱里的 `think` 是假入口（只往 migrate.log 追加参数），迁移分支被真实走通但不跑真迁移；
 *  - Gitee/GitHub 源的 raw 模板在自测内被置空 → 立即失败且**不发起任何网络请求**；
 *  - `update.cache_ttl = 0` 关闭清单缓存，且启动时清掉已知缓存键，避免用例互相污染；
 *  - `release:build` 的清单目录用 `--manifest-dir` 指到夹具目录，项目根的 `update/` 保持原样
 *    （仍然会备份 / 还原，避免任何情况下污染正式分发目录）。
 *
 * 注意：站点端每完成一步都会 `Cache::clear()`（见 UpdateService），因此本命令在开发机上
 * 也会清空框架 file 缓存 —— 与真实升级的行为一致，不影响源码与数据库结构。
 *
 * 数据库只写入 operator_name = 'update:selftest' 的批次，结束时按该标记删除（不 truncate）。
 */
class UpdateSelftest extends Command
{
    /** 自测批次的操作人标记（清理依据） */
    private const OPERATOR = 'update:selftest';

    /** 夹具版本号 */
    private const V1 = '0.0.1';
    private const V2 = '0.0.2';
    private const V3 = '0.0.3';

    /** release:build 的清单文件（相对项目根的分发目录），自测必须还原 */
    private const MANIFEST_FILES = ['update.json', 'update.json.sig'];

    /** 用例注册表（顺序即执行顺序；skip 表示本命令不覆盖） */
    private const CASES = [
        'AC1'  => ['title' => '构建正确性', 'method' => 'caseAc1'],
        'AC2'  => ['title' => '单步升级 0.0.1→0.0.2', 'method' => 'caseAc2'],
        'AC3'  => ['title' => '批量升级 0.0.1→0.0.3', 'method' => 'caseAc3'],
        'AC4'  => ['title' => '篡改拒绝', 'method' => 'caseAc4'],
        'AC5'  => ['title' => '中断续跑', 'method' => 'caseAc5'],
        'AC6'  => ['title' => '本地改动冲突', 'method' => 'caseAc6'],
        'AC7'  => ['title' => '整批回滚', 'method' => 'caseAc7'],
        'AC8'  => ['title' => 'Gitee 不可达切 GitHub', 'skip' => 'P3 已用真实网络覆盖，本命令不依赖外网'],
        'AC9'  => ['title' => '删除语义', 'method' => 'caseAc9'],
        'AC10' => ['title' => 'vendor 分支', 'method' => 'caseAc10'],
        'AC11' => ['title' => '权限与审计', 'skip' => '由 P4 权限/审计冒烟覆盖（需 HTTP 登录态与管理 API Key）'],
        'AC12' => ['title' => '断链拒绝', 'method' => 'caseAc12'],
        'AC13' => ['title' => '并发锁', 'method' => 'caseAc13'],
    ];

    /** 项目根（正斜杠、无尾部斜杠） */
    private string $projectRoot = '';

    /** 夹具根 runtime/selftest */
    private string $sandbox = '';

    /** 临时 git 仓库 */
    private string $upstream = '';

    /** 发布产物 + LocalSource 根 */
    private string $dist = '';

    /** v0.0.1 站点快照 */
    private string $snapshot = '';

    /** 沙箱站点根 */
    private string $site = '';

    /** 临时签名私钥路径 */
    private string $keyPath = '';

    private string $publicKey = '';

    private string $secretKey = '';

    /** 是否保留现场 */
    private bool $keep = false;

    /** --only 过滤（空数组表示全部） */
    private array $only = [];

    /** 清单变体：名称 → 目录 */
    private array $variants = [];

    /** 项目根 update/update.json / update.json.sig 的原始字节（null 表示原本不存在） */
    private array $rootManifestBackup = [];

    /** 项目根分发目录名（取 config/update.php 的 distribution.dir） */
    private string $manifestDir = 'update';

    /** 自测开始前项目根分发目录是否已存在（不存在则结束时删掉，不留未跟踪目录） */
    private bool $manifestDirExisted = false;

    /** 用例结果：code → ['status','title','detail'] */
    private array $results = [];

    /** 是否有失败 */
    private bool $failed = false;

    /** 失败现场提示 */
    private array $failHints = [];

    /** 迁移是否走 exec（决定是否断言 migrate.log） */
    private bool $execMode = true;

    // ==================================================================
    // 命令定义
    // ==================================================================

    protected function configure(): void
    {
        $this->setName('update:selftest')
            ->addOption('all', null, Option::VALUE_NONE, '执行全部用例（默认行为，保留该参数以兼容文档）')
            ->addOption('keep', null, Option::VALUE_NONE, '保留 runtime/selftest 现场便于排查')
            ->addOption('only', null, Option::VALUE_REQUIRED, '只跑指定用例，逗号分隔，例如 --only=AC1,AC4', '')
            ->addOption('force', null, Option::VALUE_NONE, '在非调试环境强制执行（默认拒绝）')
            ->setDescription('在线增量更新端到端自测（AC1–AC13）');
    }

    protected function execute(Input $input, Output $output): int
    {
        $this->projectRoot = rtrim(str_replace('\\', '/', (string) $this->app->getRootPath()), '/');
        $this->sandbox     = $this->projectRoot . '/runtime/selftest';
        $this->upstream    = $this->sandbox . '/upstream';
        $this->dist        = $this->sandbox . '/dist';
        $this->snapshot    = $this->sandbox . '/snapshot';
        $this->site        = $this->sandbox . '/site';
        $this->keyPath     = $this->sandbox . '/key';

        $this->keep       = (bool) $input->getOption('keep');
        $this->only       = $this->parseOnly((string) $input->getOption('only'));
        $this->execMode   = $this->execAvailable();
        $this->manifestDir = trim(str_replace('\\', '/', (string) config('update.distribution.dir', 'update')), '/') ?: 'update';

        // 安全阀：非调试环境一律拒绝，避免在真实站点上跑破坏性用例
        if (!$this->app->isDebug() && !$input->getOption('force')) {
            $output->writeln('自测命令只能在开发环境运行（app_debug 未开启）；确需强制执行请加 --force', Output::OUTPUT_RAW);
            return 2;
        }

        $this->writeln('在线增量更新自测（update:selftest）');
        $this->writeln('  项目根：' . $this->projectRoot);
        $this->writeln('  夹具  ：' . $this->relative($this->sandbox));
        if ($this->only !== []) {
            $this->writeln('  只跑  ：' . implode('、', array_keys($this->only)));
        }
        $this->writeln('');

        $this->backupRootManifest();
        AppContext::setAdminId(null);
        AppContext::setAdminUsername(self::OPERATOR);

        try {
            $this->prepareFixture();
        } catch (\Throwable $e) {
            $this->writeln('夹具准备失败：' . $e->getMessage());
            $this->failed = true;
            $this->cleanup();
            return 1;
        }

        try {
            $this->runCases();
        } finally {
            $this->cleanup();
        }

        return $this->summary();
    }

    // ==================================================================
    // 夹具
    // ==================================================================

    /**
     * 准备上游仓库 / 密钥 / 增量包 / 站点快照 / 清单变体
     */
    private function prepareFixture(): void
    {
        if (is_dir($this->sandbox) && !$this->removeTreeWithRetry($this->sandbox)) {
            throw new \RuntimeException('无法清空旧夹具目录（可能仍被占用）：' . $this->relative($this->sandbox));
        }
        $this->ensureDir($this->sandbox);

        $this->assertEnvironment();
        $this->clearUpdateCacheKeys();
        $this->applyRuntimeConfig();

        $this->buildUpstreamRepo();
        $this->generateKey();
        $this->buildReleases();
        $this->assembleDist();
        $this->buildSiteSnapshot();
        $this->createVariants();

        $this->writeln('夹具就绪：3 个 tag / 2 个增量包 / 1 份站点快照 / 4 个清单变体');
        $this->writeln('');
    }

    /**
     * 运行环境前置检查（缺能力直接给出人话）
     */
    private function assertEnvironment(): void
    {
        if (!class_exists(\ZipArchive::class)) {
            throw new \RuntimeException('缺少 zip 扩展（ext-zip），无法构建与解压增量包');
        }
        if (ManifestSigner::defaultAlgo() === '') {
            throw new \RuntimeException('缺少 sodium / openssl 扩展，无法签名与验签');
        }
        [$code, , $stderr] = (new DeltaBuilder($this->projectRoot))->gitSafe(['--version']);
        if ($code !== 0) {
            throw new \RuntimeException('git 不可用：' . $stderr);
        }
    }

    /**
     * 运行时配置：本地源 + 公钥 + 断网 + 关缓存（不改 config/update.php）
     */
    private function applyRuntimeConfig(): void
    {
        $this->setUpdateConfig(['cache_ttl' => 0]);

        // 把两个外网源的 raw 模板置空：HttpSource 会在拼 URL 前就抛出配置错误，
        // 因此自测不会发起任何网络请求（也不会因为超时拖慢用例）。
        $this->setUpdateConfig([
            'sources'      => [
                'local' => ['base' => 'runtime/selftest/dist'],
            ],
            'distribution' => [
                'sources' => [
                    'gitee'  => ['raw' => ''],
                    'github' => ['raw' => ''],
                ],
            ],
        ]);
    }

    /**
     * 覆盖 config/update.php 中若干键（只改运行期内存配置，不落盘）
     *
     * 注意 ThinkPHP 8 的 Config::set() 第一个参数是「整段配置数组」，不能直接写点路径。
     *
     * @param array<string,mixed> $values
     */
    private function setUpdateConfig(array $values): void
    {
        $current = (array) Config::get('update');
        Config::set(array_replace_recursive($current, $values), 'update');
    }

    /**
     * 清掉可能残留的清单缓存键（cache_ttl=0 只挡住写入，不挡读取）
     */
    private function clearUpdateCacheKeys(): void
    {
        foreach ([self::V1, self::V2, self::V3, 'unknown'] as $version) {
            try {
                Cache::delete('update:manifest:' . $version);
            } catch (\Throwable $e) {
                // 缓存不可用不影响自测
            }
        }
    }

    /**
     * 构造临时 git 仓库：v0.0.1 → v0.0.2（改/删/增/改名）→ v0.0.3
     */
    private function buildUpstreamRepo(): void
    {
        $this->ensureDir($this->upstream);
        $git = new DeltaBuilder($this->upstream);

        $git->git(['init']);
        $git->git(['config', 'user.email', 'selftest@local']);
        $git->git(['config', 'user.name', 'Update Selftest']);
        $git->git(['config', 'core.autocrlf', 'false']);
        $git->git(['config', 'commit.gpgsign', 'false']);

        // ---- v0.0.1：基线 ----
        $this->writeUpstream('app/demo.txt', "v1\n");
        $this->writeUpstream('app/gone.txt', "bye\n");
        $this->writeUpstream('app/keep.txt', "keep-original\n");
        // 站点不可写的路径：构建时必须被 filterPaths 剔除，否则站点整包拒绝（回归用）
        $this->writeUpstream('README.md', "readme v1\n");
        $this->writeUpstream('public/admin-api/openapi.yaml', "openapi: 3.0.0\n");
        $this->writeVersionFile($this->upstream, self::V1);
        $this->commitTag($git, self::V1);

        // ---- v0.0.2：改 demo、删 gone、增 new、keep → keep2（重命名降级为 delete+add）----
        $this->writeUpstream('app/demo.txt', "v2\n");
        @unlink($this->upstream . '/app/gone.txt');
        $this->writeUpstream('app/new.txt', "new2\n");
        @unlink($this->upstream . '/app/keep.txt');
        $this->writeUpstream('app/keep2.txt', "keep-original\n");
        $this->writeUpstream('README.md', "readme v2\n");
        $this->writeUpstream('public/admin-api/openapi.yaml', "openapi: 3.0.1\n");
        $this->writeVersionFile($this->upstream, self::V2);
        $this->commitTag($git, self::V2);

        // ---- v0.0.3：再改 demo、增 new3 ----
        $this->writeUpstream('app/demo.txt', "v3\n");
        $this->writeUpstream('app/new3.txt', "new3\n");
        $this->writeVersionFile($this->upstream, self::V3);
        $this->commitTag($git, self::V3);
    }

    private function commitTag(DeltaBuilder $git, string $version): void
    {
        $git->git(['add', '-A']);
        $git->git(['commit', '-m', 'release v' . $version]);
        // tag 带 v 前缀，版本号不带（与 release:build 的约定一致）
        $git->git(['tag', 'v' . $version]);
    }

    private function writeUpstream(string $rel, string $content): void
    {
        $this->writeFile($this->upstream . '/' . $rel, $content);
    }

    /**
     * 版本文件必须与 tag 内容一致（release:build 读工作区的 version.json 并校验）
     */
    private function writeVersionFile(string $root, string $version): void
    {
        $json = json_encode([
            'version'     => $version,
            'released_at' => date('c'),
            'db_version'  => '20261028100000',
            'php_min'     => '8.0.0',
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        $this->writeFile($root . '/version.json', $json . "\n");
    }

    /**
     * 生成临时密钥（走真实的 release:keygen，顺便覆盖该命令）
     */
    private function generateKey(): void
    {
        $this->runReleaseCommand(
            ReleaseKeygen::class,
            'release:keygen',
            ['--out=' . $this->relative($this->keyPath)]
        );

        if (!is_file($this->keyPath)) {
            throw new \RuntimeException('release:keygen 未生成私钥：' . $this->keyPath);
        }

        $secret = trim((string) file_get_contents($this->keyPath));
        $secret = preg_replace('/^secret:/', '', $secret) ?? $secret;

        $this->secretKey = trim($secret);
        $this->publicKey = ManifestSigner::derivePublicKey($this->secretKey);
        $this->setUpdateConfig(['public_key' => $this->publicKey]);
    }

    /**
     * 为 0.0.2 / 0.0.3 各构建一次增量包（走真实的 release:build）
     */
    private function buildReleases(): void
    {
        $git = new DeltaBuilder($this->upstream);

        foreach ([self::V2, self::V3] as $version) {
            // release:build 读工作区的 version.json，且要求工作区干净 → 必须先切到对应 tag
            $git->git(['checkout', 'v' . $version]);
            $this->runReleaseCommand(ReleaseBuild::class, 'release:build', [
                '--ver=' . $version,
                '--git-dir=' . $this->upstream,
                // 清单写进夹具目录（正式环境是项目根的 update/），产物按版本分子目录
                '--manifest-dir=' . $this->dist,
                '--out=' . $this->dist . '/v' . $version,
                '--key=' . $this->keyPath,
                '--skip-vendor',
            ]);
        }

        $git->git(['checkout', 'v' . self::V1]);
    }

    /**
     * 校验夹具里的清单与资产目录结构（{base}/update.json + {base}/v{version}/{asset}）
     *
     * 新的分发模型下 release:build 直接把清单写进 --manifest-dir、资产写进 --out，
     * 这里只做结构校验，不再搬运文件。
     */
    private function assembleDist(): void
    {
        $manifestPath = $this->dist . '/update.json';
        $sigPath      = $this->dist . '/update.json.sig';
        if (!is_file($manifestPath) || !is_file($sigPath)) {
            throw new \RuntimeException('release:build 未在清单目录生成 update.json / update.json.sig');
        }

        $manifest = $this->readJson($manifestPath);
        $steps    = (array) ($manifest['steps'] ?? []);
        if (count($steps) !== 2) {
            throw new \RuntimeException('清单应有 2 条步骤，实际 ' . count($steps) . ' 条');
        }

        foreach ($steps as $step) {
            $to = (string) ($step['to'] ?? '');
            foreach (['asset', 'ops_asset'] as $field) {
                $asset = (string) ($step[$field] ?? '');
                if ($asset === '') {
                    throw new \RuntimeException('清单步骤缺少 ' . $field . '：' . $to);
                }
                $target = $this->dist . '/v' . $to . '/' . $asset;
                if (!is_file($target)) {
                    throw new \RuntimeException('增量资产缺失：' . $this->relative($target));
                }
            }
        }
    }

    /**
     * v0.0.1 的站点快照：工作树内容 + 假 think + 旧 vendor
     */
    private function buildSiteSnapshot(): void
    {
        $this->ensureDir($this->snapshot);

        $archive = $this->sandbox . '/v0.0.1.zip';
        $bytes   = (new DeltaBuilder($this->upstream))->git(['archive', '--format=zip', 'v' . self::V1]);
        $this->writeFile($archive, $bytes);

        $zip = new \ZipArchive();
        if ($zip->open($archive) !== true) {
            throw new \RuntimeException('无法打开 v0.0.1 归档包：' . $archive);
        }
        $ok = $zip->extractTo($this->snapshot);
        $zip->close();
        @unlink($archive);
        if (!$ok) {
            throw new \RuntimeException('解压 v0.0.1 归档失败');
        }

        if (!is_file($this->snapshot . '/app/demo.txt') || !is_file($this->snapshot . '/version.json')) {
            throw new \RuntimeException('v0.0.1 快照内容不完整（缺少 app/demo.txt 或 version.json）');
        }

        // 假的 think：把调用参数追加到 migrate.log，绝不真的跑迁移
        $this->writeFile($this->snapshot . '/think', <<<'PHP'
<?php

$log = __DIR__ . '/migrate.log';
@file_put_contents($log, implode(' ', array_slice($argv, 1)) . PHP_EOL, FILE_APPEND);
exit(0);
PHP);

        // 旧 vendor（AC10 校验「已备份」）
        $this->writeFile($this->snapshot . '/vendor/autoload.php', "<?php\n// OLD-VENDOR 0.0.1\n");
        $this->ensureDir($this->snapshot . '/runtime/update');
    }

    /**
     * 清单变体：
     *   v002   只保留 0.0.1→0.0.2（单步场景）
     *   tamper 改了包内一个字节（哈希不再匹配）
     *   vendor 补 vendor 包并改写 need_vendor
     *   broken 删掉 0.0.1 起步的步骤（断链）
     */
    private function createVariants(): void
    {
        $this->variants['full'] = $this->dist;

        $this->variants['v002'] = $this->cloneDist('dist-v002', static function (array $manifest): array {
            $steps = [];
            foreach ((array) ($manifest['steps'] ?? []) as $step) {
                if ((string) ($step['from'] ?? '') === self::V1) {
                    $steps[] = $step;
                }
            }
            $manifest['latest'] = self::V2;
            $manifest['steps']  = $steps;
            return $manifest;
        });

        // AC4：改一个字节后重新打包（清单里的 asset_sha256 仍是旧包的）
        $this->variants['tamper'] = $this->cloneDist('dist-tamper', null, $this->variants['v002']);
        $this->tamperZip($this->variants['tamper'] . '/v' . self::V2 . '/delta-' . self::V1 . '-to-' . self::V2 . '.zip');

        // AC10：补一个 vendor 包，并在清单里打开 need_vendor
        $vendorDir = $this->cloneDist('dist-vendor', null, $this->variants['v002']);
        $vendorZip = $vendorDir . '/v' . self::V2 . '/vendor-' . self::V2 . '.zip';
        $this->buildVendorZip($vendorZip);
        $vendorSha  = (string) hash_file('sha256', $vendorZip);
        $vendorSize = (int) filesize($vendorZip);

        $this->rewriteManifest($vendorDir, static function (array $manifest) use ($vendorSha, $vendorSize): array {
            foreach ((array) $manifest['steps'] as $index => $step) {
                if ((string) ($step['from'] ?? '') !== self::V1) {
                    continue;
                }
                $manifest['steps'][$index]['need_vendor']   = true;
                $manifest['steps'][$index]['vendor_asset']  = 'vendor-' . self::V2 . '.zip';
                $manifest['steps'][$index]['vendor_sha256'] = $vendorSha;
                $manifest['steps'][$index]['vendor_size']   = $vendorSize;
            }
            return $manifest;
        });
        $this->variants['vendor'] = $vendorDir;

        // AC12：断链
        $this->variants['broken'] = $this->cloneDist('dist-broken', static function (array $manifest): array {
            $steps = [];
            foreach ((array) ($manifest['steps'] ?? []) as $step) {
                if ((string) ($step['from'] ?? '') !== self::V1) {
                    $steps[] = $step;
                }
            }
            $manifest['steps'] = $steps;
            return $manifest;
        });
    }

    /**
     * @param callable|null $mutate 需要改写清单时传入（会自动重新签名）
     */
    private function cloneDist(string $name, ?callable $mutate = null, ?string $source = null): string
    {
        $dir = $this->sandbox . '/' . $name;
        $this->copyTree($source ?? $this->dist, $dir);
        if ($mutate !== null) {
            $this->rewriteManifest($dir, $mutate);
        }
        return $dir;
    }

    /**
     * 改写清单并重新签名（签名后写入的是同一份字节，保证站点端验签通过）
     */
    private function rewriteManifest(string $dir, callable $mutate): void
    {
        $manifest = $mutate($this->readJson($dir . '/update.json'));
        $json     = $this->encodeJson($manifest);

        $this->writeFile($dir . '/update.json', $json);
        $this->writeFile($dir . '/update.json.sig', $this->signBytes($json) . "\n");
    }

    /**
     * 篡改 zip：翻转 app/demo.txt 的一个字节后重新打包
     */
    private function tamperZip(string $zipPath): void
    {
        if (!is_file($zipPath)) {
            throw new \RuntimeException('待篡改的增量包不存在：' . $zipPath);
        }

        $zip = new \ZipArchive();
        if ($zip->open($zipPath) !== true) {
            throw new \RuntimeException('无法打开增量包：' . $zipPath);
        }
        $entries = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            if (!is_array($stat)) {
                continue;
            }
            $name = (string) ($stat['name'] ?? '');
            $body = $zip->getFromIndex($i);
            if ($name !== '' && $body !== false) {
                $entries[$name] = $body;
            }
        }
        $zip->close();

        if (!isset($entries['app/demo.txt'])) {
            throw new \RuntimeException('增量包内没有 app/demo.txt，无法构造篡改用例');
        }
        $body = $entries['app/demo.txt'];
        $body[0] = chr(ord($body[0]) ^ 0x01);
        $entries['app/demo.txt'] = $body;

        @unlink($zipPath);
        $new = new \ZipArchive();
        if ($new->open($zipPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
            throw new \RuntimeException('无法重写增量包：' . $zipPath);
        }
        foreach ($entries as $name => $content) {
            $new->addFromString($name, $content);
        }
        $new->close();
    }

    /**
     * 造一个只含 vendor/autoload.php 的依赖包
     */
    private function buildVendorZip(string $zipPath): void
    {
        $this->ensureDir(dirname($zipPath));
        @unlink($zipPath);

        $zip = new \ZipArchive();
        if ($zip->open($zipPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
            throw new \RuntimeException('无法创建 vendor 包：' . $zipPath);
        }
        $zip->addFromString('vendor/autoload.php', "<?php\n// NEW-VENDOR 0.0.2\n");
        $zip->close();
    }

    // ==================================================================
    // 用例执行
    // ==================================================================

    private function runCases(): void
    {
        foreach (self::CASES as $code => $meta) {
            if ($this->only !== [] && !isset($this->only[$code])) {
                $this->record($code, 'SKIP', (string) $meta['title'], '本次未选中（--only）');
                continue;
            }
            if (isset($meta['skip'])) {
                $this->record($code, 'SKIP', (string) $meta['title'], (string) $meta['skip']);
                continue;
            }

            try {
                $detail = (string) $this->{(string) $meta['method']}();
                $this->record($code, 'PASS', (string) $meta['title'], $detail);
            } catch (\Throwable $e) {
                $this->failed = true;
                $this->record($code, 'FAIL', (string) $meta['title'], $this->shorten($e->getMessage()));
                $this->failHints[] = $code . ' 现场：' . $this->relative($this->site)
                    . '（清单源：' . $this->relative((string) Config::get('update.sources.local.base')) . '）';
            } finally {
                $this->purgeBatches();
            }
        }
    }

    // ------------------------------------------------------------------
    // AC1 构建正确性
    // ------------------------------------------------------------------

    private function caseAc1(): string
    {
        $opsPath = $this->dist . '/v' . self::V2 . '/delta-' . self::V1 . '-to-' . self::V2 . '.json';
        if (!is_file($opsPath)) {
            throw new \RuntimeException('缺少操作清单：' . $this->relative($opsPath));
        }
        $doc = $this->readJson($opsPath);
        $ops = (array) ($doc['ops'] ?? []);

        $byPath = [];
        foreach ($ops as $op) {
            $byPath[(string) ($op['path'] ?? '')] = $op;
        }

        $this->must(count($ops) === 5, '操作条数应为 5（改 1 / 增 2 / 删 2），实际 ' . count($ops));

        foreach ([
            ['app/demo.txt', 'modify'],
            ['app/new.txt', 'add'],
            ['app/keep2.txt', 'add'],
            ['app/gone.txt', 'delete'],
            ['app/keep.txt', 'delete'],
        ] as [$path, $op]) {
            $this->must(isset($byPath[$path]), '操作清单缺少路径：' . $path);
            $this->must(
                (string) $byPath[$path]['op'] === $op,
                $path . ' 的操作类型应为 ' . $op . '，实际 ' . (string) $byPath[$path]['op']
            );
        }

        // zip 内容 = 3 个新增/修改文件
        $zipPath = $this->dist . '/v' . self::V2 . '/delta-' . self::V1 . '-to-' . self::V2 . '.zip';
        $entries = $this->zipEntries($zipPath);
        sort($entries, SORT_STRING);
        $expected = ['app/demo.txt', 'app/keep2.txt', 'app/new.txt'];
        $this->must($entries === $expected, '增量包内容应为 ' . implode('、', $expected) . '，实际 ' . implode('、', $entries));

        // 白名单回归（CRITICAL）：delta 里只要有一条路径站点写不了，站点会在写入前整包拒绝。
        // 构建器的 filterPaths 必须与站点端共用 config/update.php 的同一份白名单。
        $this->must(!isset($byPath['README.md']), 'README.md 不在站点可写白名单内，不应进入增量包');
        $this->must(
            !isset($byPath['public/admin-api/openapi.yaml']),
            'public/admin-api/** 不在站点可写白名单内，不应进入增量包'
        );
        $package = new UpdatePackage();
        foreach ($ops as $op) {
            $path = (string) ($op['path'] ?? '');
            try {
                $package->assertSafePath($path);
                $package->assertWithinRoots($path);
            } catch (BizException $e) {
                $this->must(false, '增量包包含站点拒绝写入的路径：' . $path . '（' . $e->getMessage() . '）');
            }
        }

        // before / after 必须与 git show 一致
        $git = new DeltaBuilder($this->upstream);
        foreach ($ops as $op) {
            $path   = (string) ($op['path'] ?? '');
            $before = $op['before'] ?? null;
            $after  = $op['after'] ?? null;

            if ($before !== null) {
                $actual = hash('sha256', $git->fileAt('v' . self::V1, $path));
                $this->must(
                    $actual === (string) $before,
                    $path . ' 的 before 与实际不符：清单 ' . substr((string) $before, 0, 12) . ' / git ' . substr($actual, 0, 12)
                );
            } else {
                $this->must(
                    (string) ($op['op'] ?? '') === 'add',
                    $path . ' 的 before 为空但不是 add 操作'
                );
            }

            if ($after !== null) {
                $actual = hash('sha256', $git->fileAt('v' . self::V2, $path));
                $this->must(
                    $actual === (string) $after,
                    $path . ' 的 after 与实际不符：清单 ' . substr((string) $after, 0, 12) . ' / git ' . substr($actual, 0, 12)
                );
            } else {
                $this->must(
                    (string) ($op['op'] ?? '') === 'delete',
                    $path . ' 的 after 为空但不是 delete 操作'
                );
            }
        }

        return count($entries) . ' 个文件 / ' . count($ops) . ' 条 ops';
    }

    // ------------------------------------------------------------------
    // AC2 单步升级
    // ------------------------------------------------------------------

    private function caseAc2(): string
    {
        $this->resetSite();
        $this->useVariant('v002');

        $service = $this->service();
        $plan    = $service->plan();
        $this->must(count((array) $plan['steps']) === 1, '单步场景规划出 ' . count((array) $plan['steps']) . ' 步，期望 1 步');

        $result = $service->runNextStep((int) $plan['batch_id']);
        $this->must($result['done'] === true, '第一步执行后批次应完成，实际 done=' . var_export($result['done'], true));

        $this->must($this->siteVersion() === self::V2, 'version.json 应为 ' . self::V2 . '，实际 ' . $this->siteVersion());
        $this->must($this->siteTrim('app/demo.txt') === 'v2', 'app/demo.txt 内容应为 v2，实际 ' . $this->siteTrim('app/demo.txt'));
        $this->must(is_file($this->site . '/app/new.txt'), 'app/new.txt 应已写入');
        $this->must(!is_file($this->site . '/app/gone.txt'), 'app/gone.txt 应已删除');

        $migrateLines = $this->migrateLogLines();
        if ($this->execMode) {
            $this->must(count($migrateLines) === 1, '迁移应执行 1 次，migrate.log 实际 ' . count($migrateLines) . ' 行');
        }

        $detail = $service->batchDetail((int) $plan['batch_id']);
        $this->must((string) $detail['batch']['status'] === SiteUpdate::STATUS_SUCCESS,
            '批次状态应为 success，实际 ' . (string) $detail['batch']['status']);
        $this->must(!is_file($this->site . '/runtime/update/applying.lock'), '维护窗口标记 applying.lock 应已清除');

        return '版本 0.0.2 / 迁移 ' . ($this->execMode ? count($migrateLines) . ' 次' : '走 console 兜底');
    }

    // ------------------------------------------------------------------
    // AC3 批量升级
    // ------------------------------------------------------------------

    private function caseAc3(): string
    {
        $this->resetSite();
        $this->useVariant('full');

        $service = $this->service();
        $plan    = $service->plan();
        $steps   = (array) $plan['steps'];
        $this->must(count($steps) === 2, '0.0.1→0.0.3 链上应有 2 步，实际 ' . count($steps));

        $first = $service->runNextStep((int) $plan['batch_id']);
        $this->must($first['done'] === false, '第 1 步后批次不应结束');
        $this->must($this->siteVersion() === self::V2, '第 1 步后版本应为 0.0.2，实际 ' . $this->siteVersion());

        $second = $service->runNextStep((int) $plan['batch_id']);
        $this->must($second['done'] === true, '第 2 步后批次应完成');

        $this->must($this->siteVersion() === self::V3, '最终版本应为 0.0.3，实际 ' . $this->siteVersion());
        $this->must($this->siteTrim('app/demo.txt') === 'v3', 'app/demo.txt 应为 v3，实际 ' . $this->siteTrim('app/demo.txt'));
        $this->must(is_file($this->site . '/app/new3.txt'), 'app/new3.txt 应已写入');

        $detail = $service->batchDetail((int) $plan['batch_id']);
        $this->must(count((array) $detail['steps']) === 2, '步骤记录应为 2 条');
        foreach ((array) $detail['steps'] as $step) {
            $this->must((string) $step['status'] === SiteUpdateStep::STATUS_SUCCESS,
                '第 ' . $step['seq'] . ' 步状态应为 success，实际 ' . (string) $step['status']);
        }
        $this->must((string) $detail['batch']['status'] === SiteUpdate::STATUS_SUCCESS, '批次状态应为 success');

        return '2 步全部 success（0.0.1 → 0.0.3）';
    }

    // ------------------------------------------------------------------
    // AC4 篡改拒绝
    // ------------------------------------------------------------------

    private function caseAc4(): string
    {
        $this->resetSite();
        $this->useVariant('tamper');

        $before = $this->siteDigest();

        $service = $this->service();
        $plan    = $service->plan();

        $this->expectFailure(
            static fn () => $service->runNextStep((int) $plan['batch_id']),
            '校验',
            '第 1 步（0.0.1 → 0.0.2）增量包下载失败'
        );

        $after = $this->siteDigest();
        $this->must($before === $after, '站点文件应逐字节不变，但检测到 ' . $this->diffDigest($before, $after) . ' 处变化');

        $detail = $service->batchDetail((int) $plan['batch_id']);
        $this->must((string) $detail['batch']['status'] === SiteUpdate::STATUS_FAILED,
            '批次状态应为 failed，实际 ' . (string) $detail['batch']['status']);
        $this->must((string) $detail['steps'][0]['status'] === SiteUpdateStep::STATUS_FAILED,
            '步骤状态应为 failed，实际 ' . (string) $detail['steps'][0]['status']);
        $this->must(!is_file($this->site . '/runtime/update/applying.lock'), 'applying.lock 应已清除');

        return '站点文件零改动（' . count($before) . ' 个文件摘要一致）';
    }

    // ------------------------------------------------------------------
    // AC5 中断续跑
    // ------------------------------------------------------------------

    private function caseAc5(): string
    {
        $this->resetSite();
        $this->useVariant('full');

        $service = $this->service();
        $plan    = $service->plan();
        $batchId = (int) $plan['batch_id'];

        $service->runNextStep($batchId);

        $step1         = $this->stepRow($batchId, 1);
        $startedBefore = (string) $step1->started_at;
        $this->must($startedBefore !== '', '第 1 步应记录 started_at');
        $this->must((string) $step1->status === SiteUpdateStep::STATUS_SUCCESS, '第 1 步应为 success');

        // 模拟「关掉浏览器后重新进入」：第 1 步 success、第 2 步仍 pending
        $step2 = $this->stepRow($batchId, 2);
        $this->must((string) $step2->status === SiteUpdateStep::STATUS_PENDING, '第 2 步应仍为 pending');

        $second = $service->runNextStep($batchId);
        $this->must($second['done'] === true, '续跑后批次应完成');
        $this->must((int) $second['step']['seq'] === 2, '续跑执行的第几步应为 2，实际 ' . (int) $second['step']['seq']);

        $step1After = $this->stepRow($batchId, 1);
        $this->must((string) $step1After->started_at === $startedBefore,
            '第 1 步不应被重跑：started_at 由 ' . $startedBefore . ' 变成 ' . (string) $step1After->started_at);
        $this->must($this->siteVersion() === self::V3, '最终版本应为 0.0.3，实际 ' . $this->siteVersion());

        return '只跑第 2 步，第 1 步 started_at 未变';
    }

    // ------------------------------------------------------------------
    // AC6 本地改动冲突
    // ------------------------------------------------------------------

    private function caseAc6(): string
    {
        $this->resetSite();
        $this->useVariant('v002');

        $this->writeFile($this->site . '/app/demo.txt', "local-edit\n");

        $service = $this->service();
        $plan    = $service->plan();
        $service->runNextStep((int) $plan['batch_id']);

        $this->must($this->siteTrim('app/demo.txt') === 'v2',
            '站点改过的文件应被新版覆盖为 v2，实际 ' . $this->siteTrim('app/demo.txt'));

        $detail = $service->batchDetail((int) $plan['batch_id']);
        $step   = (array) $detail['steps'][0];
        $this->must((int) $step['conflicts'] === 1, '冲突计数应为 1，实际 ' . (int) $step['conflicts']);
        $this->must($detail['batch']['has_conflicts'] === true, '批次 has_conflicts 应为真');

        $backupDir = (string) $step['backup_path'];
        $this->must($backupDir !== '', '步骤应记录备份路径');
        $backupFile = $this->site . '/' . $backupDir . '/app/demo.txt';
        $this->must(is_file($backupFile), '备份目录应能找到被覆盖的原件：' . $this->relative($backupFile));
        $this->must(trim((string) file_get_contents($backupFile)) === 'local-edit',
            '备份原件内容应为 local-edit，实际 ' . trim((string) file_get_contents($backupFile)));

        return '冲突 1 个，备份含原件';
    }

    // ------------------------------------------------------------------
    // AC7 整批回滚
    // ------------------------------------------------------------------

    private function caseAc7(): string
    {
        $this->resetSite();
        $this->useVariant('v002');

        $before = $this->siteDigest();

        $service = $this->service();
        $plan    = $service->plan();
        $service->runNextStep((int) $plan['batch_id']);
        $this->must($this->siteVersion() === self::V2, '升级后版本应为 0.0.2');

        $rollback = $service->rollback((int) $plan['batch_id']);
        $this->must((int) $rollback['restored_files'] > 0, '回滚应还原至少 1 个文件');

        $this->must($this->siteVersion() === self::V1, '回滚后版本应为 0.0.1，实际 ' . $this->siteVersion());
        $after = $this->siteDigest();
        $this->must($before === $after, '回滚后站点文件应与升级前一致，差异：' . $this->diffDigest($before, $after));

        $detail = $service->batchDetail((int) $plan['batch_id']);
        $this->must((string) $detail['batch']['status'] === SiteUpdate::STATUS_ROLLED_BACK,
            '批次状态应为 rolled_back，实际 ' . (string) $detail['batch']['status']);

        return '还原 ' . (int) $rollback['restored_files'] . ' 个文件，版本回到 0.0.1';
    }

    // ------------------------------------------------------------------
    // AC9 删除语义
    // ------------------------------------------------------------------

    private function caseAc9(): string
    {
        $this->resetSite();
        $this->useVariant('v002');

        $service = $this->service();
        $plan    = $service->plan();
        $service->runNextStep((int) $plan['batch_id']);

        foreach (['app/gone.txt', 'app/keep.txt'] as $path) {
            $this->must(!is_file($this->site . '/' . $path), '升级后 ' . $path . ' 应不存在');
        }

        $detail    = $service->batchDetail((int) $plan['batch_id']);
        $backupDir = (string) $detail['steps'][0]['backup_path'];
        $this->must($backupDir !== '', '步骤应记录备份路径');

        $this->must(is_file($this->site . '/' . $backupDir . '/app/gone.txt'), 'app/gone.txt 应已进入备份目录');
        $this->must(is_file($this->site . '/' . $backupDir . '/app/keep.txt'), 'app/keep.txt（重命名源）应已进入备份目录');
        $this->must(trim((string) file_get_contents($this->site . '/' . $backupDir . '/app/gone.txt')) === 'bye',
            '备份的 app/gone.txt 内容应为 bye');

        return '2 个删除文件均已备份';
    }

    // ------------------------------------------------------------------
    // AC10 vendor 分支
    // ------------------------------------------------------------------

    private function caseAc10(): string
    {
        $this->resetSite();
        $this->useVariant('vendor');

        // 清单层：need_vendor 与 vendor_sha256 必须与真实资产一致
        $manifest = $this->readJson($this->variants['vendor'] . '/update.json');
        $step     = (array) $manifest['steps'][0];
        $this->must(!empty($step['need_vendor']), '清单步骤的 need_vendor 应为 true');
        $vendorAsset = (string) ($step['vendor_asset'] ?? '');
        $this->must($vendorAsset === 'vendor-' . self::V2 . '.zip', 'vendor_asset 应为 vendor-' . self::V2 . '.zip，实际 ' . $vendorAsset);
        $vendorPath = $this->variants['vendor'] . '/v' . self::V2 . '/' . $vendorAsset;
        $this->must(is_file($vendorPath), 'vendor 包应存在：' . $this->relative($vendorPath));
        $this->must((string) ($step['vendor_sha256'] ?? '') === (string) hash_file('sha256', $vendorPath), 'vendor_sha256 应与资产一致');

        $this->must(
            str_contains($this->siteRead('vendor/autoload.php'), 'OLD-VENDOR'),
            '升级前 vendor/autoload.php 应为旧版'
        );

        $service = $this->service();
        $plan    = $service->plan();
        $service->runNextStep((int) $plan['batch_id']);

        $newVendor = $this->siteRead('vendor/autoload.php');
        $this->must(str_contains($newVendor, 'NEW-VENDOR'), '升级后 vendor/autoload.php 应来自 vendor 包，实际：' . $this->shorten($newVendor));

        $detail    = $service->batchDetail((int) $plan['batch_id']);
        $backupDir = (string) $detail['steps'][0]['backup_path'];
        $oldVendor = $this->site . '/' . $backupDir . '/vendor/autoload.php';
        $this->must(is_file($oldVendor), '旧 vendor 应已整体备份到 ' . $this->relative($oldVendor));
        $this->must(str_contains((string) file_get_contents($oldVendor), 'OLD-VENDOR'), '备份的 vendor 应为旧版内容');

        return 'vendor 已替换且旧目录已备份';
    }

    // ------------------------------------------------------------------
    // AC12 断链拒绝
    // ------------------------------------------------------------------

    private function caseAc12(): string
    {
        $this->resetSite();
        $this->useVariant('broken');

        $service = $this->service();

        $check = $service->check();
        $this->must((string) $check['blocked_reason'] === 'broken_chain',
            'check() 的 blocked_reason 应为 broken_chain，实际 ' . (string) $check['blocked_reason']);
        $message = (string) $check['message'];
        $this->must(preg_match('/[\x{4e00}-\x{9fa5}]/u', $message) === 1, '阻断提示应为中文，实际：' . $message);
        $this->must(str_contains($message, '手工部署'), '阻断提示应引导手工部署，实际：' . $message);

        $planMessage = $this->expectFailure(
            static fn () => $service->plan(),
            '手工部署',
            'plan() 应拒绝断链清单：' . $message
        );

        $this->must($this->siteVersion() === self::V1, '规划失败后版本应保持 0.0.1');
        $this->must($this->countBatches() === 0, '规划失败不应产生批次记录');

        return 'check/plan 均拒绝，提示「' . $this->shorten($planMessage, 40) . '」';
    }

    // ------------------------------------------------------------------
    // AC13 并发锁
    // ------------------------------------------------------------------

    private function caseAc13(): string
    {
        $this->resetSite();
        $this->useVariant('v002');

        $service = $this->service();
        $plan    = $service->plan();
        $batchId = (int) $plan['batch_id'];

        $lockPath = $this->site . '/runtime/update/.lock';
        $this->ensureDir(dirname($lockPath));

        $holder = $this->startLockHolder($lockPath, 8);
        try {
            $this->expectFailure(
                static fn () => $service->runNextStep($batchId),
                '另一个更新任务正在执行',
                '并发时应拿不到文件锁'
            );
        } finally {
            $this->stopLockHolder($holder);
        }

        // 子进程退出后由 OS 释放锁；给 12 秒（子进程最多 sleep 8 秒）
        $this->must($this->waitLockFree($lockPath, 12000), '持锁进程退出后锁应可再次获取，但 12 秒内仍被占用');

        $result = $service->runNextStep($batchId);
        $this->must($result['done'] === true, '释放锁后应能正常完成升级');
        $this->must($this->siteVersion() === self::V2, '释放锁后版本应升到 0.0.2');

        return '第二个任务被拒绝，释放后正常完成';
    }

    // ==================================================================
    // 站点沙箱
    // ==================================================================

    /**
     * 重建沙箱站点（从 v0.0.1 快照复制，避免用例互相污染）
     */
    private function resetSite(): void
    {
        if (is_dir($this->site) && !$this->removeTreeWithRetry($this->site)) {
            throw new \RuntimeException(
                '无法重建沙箱站点：旧目录仍被占用（' . $this->relative($this->site) . '），残留：' . $this->leftovers($this->site)
            );
        }
        $this->copyTree($this->snapshot, $this->site);
        $this->ensureDir($this->site . '/runtime/update');

        // 上一个用例可能留下未完成批次（例如 AC13 的 planned），先清干净再规划
        $this->purgeBatches();
    }

    private function service(): UpdateService
    {
        return new UpdateService($this->site);
    }

    /**
     * 切换本地源到某个清单变体
     */
    private function useVariant(string $name): void
    {
        if (!isset($this->variants[$name])) {
            throw new \RuntimeException('未知的清单变体：' . $name);
        }
        $this->setUpdateConfig([
            'sources' => ['local' => ['base' => 'runtime/selftest/' . basename($this->variants[$name])]],
        ]);
    }

    private function siteVersion(): string
    {
        $data = json_decode($this->siteRead('version.json'), true);
        return is_array($data) ? trim((string) ($data['version'] ?? '')) : '';
    }

    private function siteRead(string $rel): string
    {
        $path = $this->site . '/' . ltrim(str_replace('\\', '/', $rel), '/');
        if (!is_file($path)) {
            return '';
        }
        return (string) file_get_contents($path);
    }

    private function siteTrim(string $rel): string
    {
        return trim($this->siteRead($rel));
    }

    /**
     * @return string[] 假 think 记录到的迁移调用
     */
    private function migrateLogLines(): array
    {
        $raw = $this->siteRead('migrate.log');
        if (trim($raw) === '') {
            return [];
        }
        return array_values(array_filter(array_map('trim', preg_split('/\r?\n/', $raw) ?: []), static fn ($l) => $l !== ''));
    }

    // ==================================================================
    // 断言与工具
    // ==================================================================

    private function must(bool $condition, string $message): void
    {
        if (!$condition) {
            throw new \RuntimeException($message);
        }
    }

    /**
     * 断言操作必须失败，并返回异常消息
     */
    private function expectFailure(callable $action, string $contains, string $label): string
    {
        try {
            $action();
        } catch (\Throwable $e) {
            $message = trim($e->getMessage());
            $this->must($message !== '', $label . '：异常消息为空');
            $this->must(
                $contains === '' || str_contains($message, $contains),
                $label . '：异常消息未包含「' . $contains . '」，实际：' . $message
            );
            return $message;
        }

        throw new \RuntimeException($label . '：预期抛出异常，但操作成功了');
    }

    /**
     * 沙箱站点内容摘要（跳过 runtime/ 与 migrate.log，后者是测试插桩产物）
     *
     * @return array<string,string>
     */
    private function siteDigest(): array
    {
        return $this->digest($this->site, ['runtime', 'migrate.log']);
    }

    /**
     * 目录内容摘要（相对路径 → sha256），默认跳过 runtime
     *
     * @param array<int,string> $skipDirs
     * @return array<string,string>
     */
    private function digest(string $root, array $skipDirs = ['runtime']): array
    {
        $root = rtrim(str_replace('\\', '/', $root), '/');
        $map  = [];
        if (!is_dir($root)) {
            return $map;
        }

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($iterator as $file) {
            /** @var \SplFileInfo $file */
            if (!$file->isFile()) {
                continue;
            }
            $abs = str_replace('\\', '/', $file->getPathname());
            $rel = ltrim(substr($abs, strlen($root)), '/');

            $skip = false;
            foreach ($skipDirs as $dir) {
                if ($rel === $dir || str_starts_with($rel, $dir . '/')) {
                    $skip = true;
                    break;
                }
            }
            if ($skip) {
                continue;
            }

            $map[$rel] = (string) hash_file('sha256', $abs);
        }

        ksort($map);
        return $map;
    }

    /**
     * @param array<string,string> $before
     * @param array<string,string> $after
     */
    private function diffDigest(array $before, array $after): string
    {
        $changed = [];
        foreach ($before as $path => $hash) {
            if (!array_key_exists($path, $after)) {
                $changed[] = $path . '(丢失)';
            } elseif ($after[$path] !== $hash) {
                $changed[] = $path . '(内容变化)';
            }
        }
        foreach ($after as $path => $hash) {
            if (!array_key_exists($path, $before)) {
                $changed[] = $path . '(新增)';
            }
        }
        return $changed === [] ? '0' : implode('、', $changed);
    }

    /**
     * 读取 zip 条目名
     *
     * @return string[]
     */
    private function zipEntries(string $zipPath): array
    {
        if (!is_file($zipPath)) {
            throw new \RuntimeException('增量包不存在：' . $this->relative($zipPath));
        }
        $zip = new \ZipArchive();
        if ($zip->open($zipPath) !== true) {
            throw new \RuntimeException('无法打开增量包：' . $this->relative($zipPath));
        }
        $names = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            if (!is_array($stat)) {
                continue;
            }
            $name = rtrim((string) ($stat['name'] ?? ''), '/');
            if ($name !== '') {
                $names[] = $name;
            }
        }
        $zip->close();
        return $names;
    }

    /**
     * @return array<string,mixed>
     */
    private function readJson(string $path): array
    {
        if (!is_file($path)) {
            throw new \RuntimeException('文件不存在：' . $this->relative($path));
        }
        $data = json_decode(ltrim((string) file_get_contents($path), "\xEF\xBB\xBF"), true);
        if (!is_array($data)) {
            throw new \RuntimeException('不是合法 JSON：' . $this->relative($path));
        }
        return $data;
    }

    /**
     * @param array<string,mixed> $data
     */
    private function encodeJson(array $data): string
    {
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($json === false) {
            throw new \RuntimeException('JSON 编码失败：' . json_last_error_msg());
        }
        return $json . "\n";
    }

    private function signBytes(string $bytes): string
    {
        $signer = new ManifestSigner($this->publicKey, $this->secretKey);
        return $signer->sign($bytes);
    }

    /**
     * 在进程内执行 release:* 命令（返回它的输出，失败抛异常）
     */
    private function runReleaseCommand(string $class, string $name, array $options): string
    {
        /** @var Command $command */
        $command = new $class();
        $command->setConsole($this->getConsole());
        $command->setApp($this->app);

        $output = new Output('buffer');
        $code   = $command->run(new Input(array_merge([$name], $options)), $output);
        $text   = trim((string) $output->fetch());

        if ($code !== 0) {
            throw new \RuntimeException($name . ' 执行失败（exit ' . $code . '）：' . PHP_EOL . $text);
        }
        return $text;
    }

    // ------------------------------------------------------------------
    // 并发锁辅助
    // ------------------------------------------------------------------

    /**
     * 启动一个独立进程持有 flock（跨进程才是真实并发场景）
     *
     * @return array{proc:resource,pipes:array}
     */
    private function startLockHolder(string $lockPath, int $seconds): array
    {
        $script = $this->sandbox . '/lock-holder.php';
        if (!is_file($script)) {
            $this->writeFile($script, <<<'PHP'
<?php

$path    = $argv[1] ?? '';
$seconds = (int) ($argv[2] ?? 5);

$handle = @fopen($path, 'c+');
if ($handle === false) {
    fwrite(STDERR, 'open lock failed');
    exit(2);
}
if (!flock($handle, LOCK_EX | LOCK_NB)) {
    fwrite(STDERR, 'flock failed');
    exit(3);
}

echo "LOCKED\n";
fflush(STDOUT);

sleep($seconds);

flock($handle, LOCK_UN);
fclose($handle);
exit(0);
PHP);
        }

        $command = escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg($script) . ' '
            . escapeshellarg($lockPath) . ' ' . $seconds;

        $descriptors = [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
        // bypass_shell：让子进程就是 php.exe 本身（而不是 cmd.exe 的孙进程），
        // 否则 Windows 上 proc_terminate() 只杀掉 cmd.exe，持锁的 php 仍在跑。
        $options = DIRECTORY_SEPARATOR === '\\' ? ['bypass_shell' => true] : [];
        $process = @proc_open($command, $descriptors, $pipes, $this->projectRoot, null, $options);
        if (!is_resource($process)) {
            throw new \RuntimeException('无法启动持锁进程');
        }

        fclose($pipes[0]);
        stream_set_blocking($pipes[1], true);
        stream_set_blocking($pipes[2], true);

        $line = fgets($pipes[1]);
        if (trim((string) $line) !== 'LOCKED') {
            $stderr = (string) stream_get_contents($pipes[2]);
            $this->stopLockHolder(['proc' => $process, 'pipes' => $pipes]);
            throw new \RuntimeException('持锁进程未获得锁：' . trim($stderr));
        }

        return ['proc' => $process, 'pipes' => $pipes];
    }

    /**
     * @param array{proc:resource,pipes:array} $holder
     */
    private function stopLockHolder(array $holder): void
    {
        $process = $holder['proc'];
        if (!is_resource($process)) {
            return;
        }
        @proc_terminate($process);
        foreach ((array) $holder['pipes'] as $pipe) {
            if (is_resource($pipe)) {
                @fclose($pipe);
            }
        }
        @proc_close($process);
    }

    /**
     * 等待锁可被获取（子进程退出后 OS 会释放）
     */
    private function waitLockFree(string $path, int $timeoutMs = 5000): bool
    {
        $deadline = microtime(true) + $timeoutMs / 1000;
        while (microtime(true) < $deadline) {
            $handle = @fopen($path, 'c+');
            if ($handle !== false) {
                $acquired = flock($handle, LOCK_EX | LOCK_NB);
                if ($acquired) {
                    flock($handle, LOCK_UN);
                    fclose($handle);
                    return true;
                }
                fclose($handle);
            }
            usleep(100000);
        }
        return false;
    }

    private function execAvailable(): bool
    {
        if (!function_exists('exec')) {
            return false;
        }
        $disabled = (string) ini_get('disable_functions');
        if (trim($disabled) === '') {
            return true;
        }
        return !in_array('exec', array_map('trim', explode(',', $disabled)), true);
    }

    // ------------------------------------------------------------------
    // 数据库
    // ------------------------------------------------------------------

    /**
     * 删除本命令创建的批次（只按 operator_name 删除，绝不清表）
     */
    private function purgeBatches(): int
    {
        try {
            $ids = (array) SiteUpdate::where('operator_name', self::OPERATOR)->column('id');
        } catch (\Throwable $e) {
            return 0;
        }
        if ($ids === []) {
            return 0;
        }

        SiteUpdateStep::whereIn('batch_id', $ids)->delete();
        SiteUpdate::whereIn('id', $ids)->delete();

        return count($ids);
    }

    private function countBatches(): int
    {
        try {
            return (int) SiteUpdate::where('operator_name', self::OPERATOR)->count();
        } catch (\Throwable $e) {
            return 0;
        }
    }

    private function stepRow(int $batchId, int $seq): SiteUpdateStep
    {
        $row = SiteUpdateStep::where('batch_id', $batchId)->where('seq', $seq)->find();
        if (!$row instanceof SiteUpdateStep) {
            throw new \RuntimeException('找不到步骤记录：batch=' . $batchId . ' seq=' . $seq);
        }
        return $row;
    }

    // ------------------------------------------------------------------
    // 项目根清单保护
    // ------------------------------------------------------------------

    private function backupRootManifest(): void
    {
        $dir = $this->projectRoot . '/' . $this->manifestDir;
        $this->manifestDirExisted = is_dir($dir);

        foreach (self::MANIFEST_FILES as $file) {
            $path = $dir . '/' . $file;
            $this->rootManifestBackup[$file] = is_file($path) ? (string) file_get_contents($path) : null;
        }
    }

    /**
     * 还原项目根分发目录里的 update.json / .sig
     *
     * 若自测开始前该目录并不存在（正式产物还没生成），结束时把整个目录删掉；
     * 但**绝不删除独立分发仓库**（存在 .git 时一律保留）。
     */
    private function restoreRootManifest(): void
    {
        $dir = $this->projectRoot . '/' . $this->manifestDir;

        foreach ($this->rootManifestBackup as $file => $bytes) {
            $path = $dir . '/' . $file;
            if ($bytes === null) {
                if (is_file($path)) {
                    @unlink($path);
                }
                continue;
            }
            $this->ensureDir($dir);
            @file_put_contents($path, $bytes);
        }

        if (!$this->manifestDirExisted && is_dir($dir) && !is_dir($dir . '/.git')) {
            $this->removeTree($dir);
        }
    }

    // ------------------------------------------------------------------
    // 收尾与输出
    // ------------------------------------------------------------------

    private function cleanup(): void
    {
        // 1. 删掉本命令写入的批次（按 operator_name 过滤，不 truncate）
        $this->purgeBatches();

        // 2. 还原项目根清单（release:build 的副作用）
        $this->restoreRootManifest();

        // 3. 项目根的维护标记：本命令从不创建，若存在说明另有更新在跑，只提示不动它
        $projectApplying = $this->projectRoot . '/runtime/update/applying.lock';
        if (is_file($projectApplying)) {
            $this->writeln('提示：项目根存在 runtime/update/applying.lock（非本命令创建），未做处理');
        }

        // 4. 沙箱现场
        if (!$this->keep && !$this->failed) {
            if (is_dir($this->sandbox) && !$this->removeTreeWithRetry($this->sandbox)) {
                $this->writeln('警告：未能完全清理 ' . $this->relative($this->sandbox) . '（文件被占用，请稍后手工删除）');
            }
            return;
        }

        $this->writeln('');
        $this->writeln('现场已保留：' . $this->relative($this->sandbox) . '（--keep 或存在失败用例）');
        if (is_dir($this->sandbox)) {
            foreach (['upstream', 'dist', 'snapshot', 'site'] as $name) {
                if (is_dir($this->sandbox . '/' . $name)) {
                    $this->writeln('  ' . $this->relative($this->sandbox . '/' . $name));
                }
            }
        }
        foreach ($this->failHints as $hint) {
            $this->writeln('  ' . $hint);
        }
    }

    private function summary(): int
    {
        $pass = 0;
        $fail = 0;
        $skip = 0;
        foreach ($this->results as $result) {
            switch ($result['status']) {
                case 'PASS':
                    $pass++;
                    break;
                case 'FAIL':
                    $fail++;
                    break;
                default:
                    $skip++;
                    break;
            }
        }

        $this->writeln('');
        $this->writeln('结果：PASS ' . $pass . ' / FAIL ' . $fail . ' / SKIP ' . $skip);

        return $fail > 0 ? 1 : 0;
    }

    private function record(string $code, string $status, string $title, string $detail): void
    {
        $this->results[$code] = ['status' => $status, 'title' => $title, 'detail' => $detail];

        if ($status === 'FAIL') {
            $text = $title . '：' . $detail;
        } elseif ($detail !== '') {
            $text = $title . '（' . $detail . '）';
        } else {
            $text = $title;
        }

        $this->writeln(sprintf('[%s] %-5s %s', $code, $status, $text));
    }

    private function writeln(string $text): void
    {
        $this->output->writeln($text, Output::OUTPUT_RAW);
    }

    private function shorten(string $text, int $limit = 160): string
    {
        $text = trim((string) preg_replace('/\s+/', ' ', $text));
        return mb_strlen($text) > $limit ? mb_substr($text, 0, $limit) . '…' : $text;
    }

    private function relative(string $absolute): string
    {
        $abs    = str_replace('\\', '/', $absolute);
        $prefix = $this->projectRoot . '/';
        if (str_starts_with($abs, $prefix)) {
            return substr($abs, strlen($prefix));
        }
        return $abs;
    }

    /**
     * @return array<string,bool>
     */
    private function parseOnly(string $raw): array
    {
        $raw = trim($raw);
        if ($raw === '') {
            return [];
        }

        $only = [];
        foreach (explode(',', $raw) as $item) {
            $item = strtoupper(trim($item));
            if ($item === '') {
                continue;
            }
            $only[$item] = true;
        }
        return $only;
    }

    // ------------------------------------------------------------------
    // 文件系统
    // ------------------------------------------------------------------

    private function ensureDir(string $dir): void
    {
        if (is_dir($dir)) {
            return;
        }
        if (!@mkdir($dir, 0775, true) && !is_dir($dir)) {
            throw new \RuntimeException('无法创建目录：' . $dir);
        }
    }

    private function writeFile(string $path, string $bytes): void
    {
        $this->ensureDir(dirname($path));
        if (@file_put_contents($path, $bytes) === false) {
            throw new \RuntimeException('写入失败：' . $path);
        }
    }

    private function copyTree(string $source, string $target): void
    {
        $source = rtrim(str_replace('\\', '/', $source), '/');
        $target = rtrim(str_replace('\\', '/', $target), '/');
        if (!is_dir($source)) {
            throw new \RuntimeException('复制源不是目录：' . $source);
        }
        $this->ensureDir($target);

        foreach (scandir($source) ?: [] as $name) {
            if ($name === '.' || $name === '..') {
                continue;
            }
            $from = $source . '/' . $name;
            $to   = $target . '/' . $name;
            if (is_dir($from)) {
                $this->copyTree($from, $to);
                continue;
            }
            if (!@copy($from, $to)) {
                throw new \RuntimeException('复制文件失败：' . $from . ' → ' . $to);
            }
        }
    }

    private function removeTree(string $path): void
    {
        if (is_file($path) || is_link($path)) {
            @chmod($path, 0666);
            @unlink($path);
            return;
        }
        if (!is_dir($path)) {
            return;
        }
        foreach (scandir($path) ?: [] as $name) {
            if ($name === '.' || $name === '..') {
                continue;
            }
            $this->removeTree($path . '/' . $name);
        }
        @chmod($path, 0777);
        @rmdir($path);
    }

    /**
     * 带重试的递归删除
     *
     * Windows 上新写入的 zip 偶尔会被杀软/索引服务短暂占用（delete pending），
     * 因此这里给到 ~6 秒的退避重试，仍失败才报错。
     */
    private function removeTreeWithRetry(string $path, int $attempts = 20, int $sleepMs = 300): bool
    {
        for ($i = 0; $i < $attempts; $i++) {
            $this->removeTree($path);
            if (!file_exists($path)) {
                return true;
            }
            usleep($sleepMs * 1000);
        }

        return !file_exists($path);
    }

    /**
     * 残留路径列表（删除失败时用于定位被占用的文件）
     */
    private function leftovers(string $root): string
    {
        $root = rtrim(str_replace('\\', '/', $root), '/');
        if (!is_dir($root)) {
            return '(目录已不存在)';
        }

        $paths = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($iterator as $file) {
            /** @var \SplFileInfo $file */
            $paths[] = ltrim(substr(str_replace('\\', '/', $file->getPathname()), strlen($root)), '/');
            if (count($paths) >= 10) {
                break;
            }
        }

        return $paths === [] ? '(空目录)' : implode('、', $paths);
    }
}