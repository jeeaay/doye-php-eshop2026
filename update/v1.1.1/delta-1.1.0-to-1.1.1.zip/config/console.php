<?php
// +----------------------------------------------------------------------
// | 控制台配置
// +----------------------------------------------------------------------
return [
    // 指令定义
    'commands' => [
        'model:check' => \app\common\command\ModelCheck::class,
        'redis:test' => \app\common\command\RedisTest::class,
        'delay:consume' => \app\common\command\DelayConsume::class,
        'translate:work' => \app\common\command\TranslateWork::class,
        'translation:queuetest' => \app\common\command\TranslationQueueTest::class,
        'translation:aitest' => \app\common\command\TranslationAiTest::class,
        'translation:fakeapi' => \app\common\command\TranslationFakeApi::class,
        'translate:backfill' => \app\common\command\TranslateBackfill::class,
        'currency:sync' => \app\common\command\CurrencySync::class,
        'currency:selftest' => \app\common\command\CurrencySelftest::class,
        'stock:deduct' => \app\common\command\StockDeduct::class,
        'stock:test' => \app\common\command\StockTest::class,
        'order:delaytest' => \app\common\command\OrderDelayTest::class,
        'payment:idemtest' => \app\common\command\PaymentIdemTest::class,
        'product:media-cleanup' => \app\common\command\ProductMediaCleanup::class,
        'security:unblock' => \app\common\command\SecurityUnblock::class,
        'product:roundtrip' => \app\common\command\ProductRoundTripTest::class,
        'scope:write-check' => \app\common\command\ScopeWriteCheck::class,
        // 发布端（维护者机器，仅 CLI）
        'release:build' => \app\common\command\ReleaseBuild::class,
        'release:verify' => \app\common\command\ReleaseVerify::class,
        'release:keygen' => \app\common\command\ReleaseKeygen::class,
        // 站点端自测
        'update:selftest' => \app\common\command\UpdateSelftest::class,
    ],
];
