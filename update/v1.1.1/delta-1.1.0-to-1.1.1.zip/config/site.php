<?php

/**
 * 前台站点配置（eshop2026 主题 / Almi）
 *
 * 说明：PHP 后台（B2C 多商户）面向微信小程序，没有「站点设置」表。
 * 独立站的站点级参数先落在本配置文件里，后续应迁移到 setting 表 + 后台设置界面（见 todo.md）。
 */
return [
    'brand' => [
        'name'      => 'Almi',
        'suffix'    => '',
        'logo_text' => 'Almi',
        'tagline'   => 'Smart, durable tools for an organised home',
    ],

    // 站点版本：international（国际版，USD/英语基准）或 domestic（国内版，CNY/中文基准）
    'site' => [
        'edition' => 'international',
    ],

    // 货币：USD 为定价与收款基准；其他币种只做前台展示（见 currency 表）
    'currency' => [
        'code'            => 'USD',
        'symbol'          => '$',
        'enabled'         => false,
        'provider'        => 'open.er-api',
        'sync_time'       => '00:10',
        'default_code'    => 'USD',
        'sanity_percent'  => 10,
        'alert_email'     => '',
    ],

    // 多语言（语种清单在 language 表；这里只放行为开关）
    'i18n' => [
        'enabled'                => false,
        'default_locale'         => 'en',
        'auto_detect'            => true,
        'auto_publish_ai'        => true,
        'auto_translate_on_save' => false,
        'fallback_to_base'       => true,
    ],

    // AI 翻译（OpenAI 兼容协议；密钥在后台填写）
    'translation' => [
        'base_url'         => '',
        'api_key'          => '',
        'model'            => '',
        'temperature'      => 0.3,
        'thinking'         => 'enabled',
        'reasoning_effort' => 'low',
        'timeout'          => 120,
        'max_chars'        => 6000,
        'daily_budget'     => 5,
        'price_per_1k'     => 0.002,
        'concurrency'      => 1,
    ],

    // 顶部公告条
    'announcement' => 'FREE DELIVERY ON ORDERS OF $80 OR MORE',

    // 地区选择器文案
    'region_label' => 'United States / USD',

    // 首页 SEO（后台「系统设置 → 首页 SEO」可覆盖）
    'seo' => [
        'title'       => '',
        'description' => '',
        'keywords'    => '',
    ],

    'contact' => [
        'email'   => 'service@almi.co.uk',
        'support' => 'service@almi.co.uk',
        'phone'   => '',
        'address' => 'Almi House, 1 Example Way',
        'country' => 'United Kingdom',
        'hours'   => 'Mon - Fri: 9:00 AM - 6:00 PM (GMT)',
    ],

    'shipping' => [
        'free_shipping_text' => 'Free delivery on orders of $80 or more',
        'free_shipping_note' => 'Free delivery on all orders over $80.',
    ],

    // 前台登录（邮箱验证码）
    'auth' => [
        'code_ttl'        => 600,
        'resend_interval' => 60,
        'max_attempts'    => 5,
        // 开发模式：不发真实邮件，验证码回显 + 写日志；生产必须置 false
        'dev_show_code'   => true,
    ],

    // 邮件服务（后台「系统设置 → 邮件服务」维护）
    'mail' => [
        'enabled'   => false,
        'from'      => 'no-reply@almi.co.uk',
        'from_name' => 'Almi',
        'notify_to' => 'service@almi.co.uk',
        'smtp'      => [
            'host'       => '',
            'port'       => 465,
            'encryption' => 'ssl',
            'username'   => '',
            'password'   => '',
        ],
    ],

    // 系统更新（后台「系统设置 → 系统更新」维护）
    // 仓库地址、分发分支与分发目录固定写在 config/update.php（站点端与后台都不可改）
    'update' => [
        'enabled'             => true,
        'backup_keep'         => 3,
        // 安装期间前台返回 503，后台与管理 API 放行
        'maintenance_enabled' => true,
    ],

    // 商品列表每页数量（主题在服务端一次性渲染）
    'per_page' => 24,

    // 主题目录（public 下的静态资源目录）
    'theme' => 'eshop2026',
];