<?php
declare(strict_types=1);

namespace app\common\lib\translation;

use app\common\lib\RedisCache;

/**
 * AI 翻译 Redis 队列
 *
 * 数据库 translation_job 仍是任务状态/成本/错误的事实来源；
 * Redis 只负责「就绪 / 延迟 / 处理中」的调度。
 *
 * 单消费者场景下使用 ZSET + LIST + Lua，保证：
 * - 同一个 job id 只会在 ready 中出现一次；
 * - 出队与写入 processing 原子完成；
 * - 失败任务可延迟重试；
 * - 进程崩溃后 processing 可恢复。
 */
class TranslationQueue
{
    public const READY_KEY      = 'translation:queue:ready';
    public const DELAYED_KEY    = 'translation:queue:delayed';
    public const PROCESSING_KEY = 'translation:queue:processing';

    private const PUSH_LUA = <<<'LUA'
redis.call('ZREM', KEYS[2], ARGV[1])
redis.call('LREM', KEYS[3], 0, ARGV[1])
redis.call('ZADD', KEYS[1], ARGV[2], ARGV[1])
return 1
LUA;

    private const POP_LUA = <<<'LUA'
local r = redis.call('ZRANGE', KEYS[1], 0, 0)
if #r == 0 then return false end
redis.call('ZREM', KEYS[1], r[1])
redis.call('LREM', KEYS[2], 0, r[1])
redis.call('RPUSH', KEYS[2], r[1])
return r[1]
LUA;

    private const ACK_LUA = <<<'LUA'
redis.call('ZREM', KEYS[1], ARGV[1])
redis.call('ZREM', KEYS[2], ARGV[1])
redis.call('LREM', KEYS[3], 0, ARGV[1])
return 1
LUA;

    private const DELAY_LUA = <<<'LUA'
redis.call('ZREM', KEYS[1], ARGV[1])
redis.call('LREM', KEYS[3], 0, ARGV[1])
redis.call('ZADD', KEYS[2], ARGV[2], ARGV[1])
return 1
LUA;

    private const DUE_LUA = <<<'LUA'
return redis.call('ZRANGEBYSCORE', KEYS[1], '-inf', ARGV[1], 'LIMIT', 0, ARGV[2])
LUA;

    /**
     * 入队（就绪）
     *
     * 同一 job id 重复 push 只会更新 score，不会产生重复任务。
     */
    public static function push(int $jobId, int $priority = 1): void
    {
        if ($jobId <= 0) {
            return;
        }
        self::eval(
            self::PUSH_LUA,
            [self::READY_KEY, self::DELAYED_KEY, self::PROCESSING_KEY],
            [$jobId, self::score($priority)]
        );
    }

    /**
     * 原子出队：ready -> processing
     */
    public static function pop(): ?int
    {
        $result = self::eval(
            self::POP_LUA,
            [self::READY_KEY, self::PROCESSING_KEY],
            []
        );

        return $result === null || $result === false || $result === '' ? null : (int) $result;
    }

    /**
     * 完成任务/放弃任务：清掉 ready、delayed、processing
     */
    public static function ack(int $jobId): void
    {
        if ($jobId <= 0) {
            return;
        }
        self::eval(
            self::ACK_LUA,
            [self::READY_KEY, self::DELAYED_KEY, self::PROCESSING_KEY],
            [$jobId]
        );
    }

    /**
     * 失败重试：移出 ready/processing，写入 delayed
     */
    public static function delay(int $jobId, int $runAt): void
    {
        if ($jobId <= 0) {
            return;
        }
        self::eval(
            self::DELAY_LUA,
            [self::READY_KEY, self::DELAYED_KEY, self::PROCESSING_KEY],
            [$jobId, max(0, $runAt)]
        );
    }

    /**
     * 到期的延迟任务 id（只读；worker 取到后按数据库状态重新 push 或 ack）
     *
     * @return int[]
     */
    public static function dueDelayed(int $limit = 50): array
    {
        $limit = max(1, min(500, $limit));
        $ids   = self::eval(
            self::DUE_LUA,
            [self::DELAYED_KEY],
            [time(), $limit]
        );

        if (!is_array($ids)) {
            return [];
        }

        return array_values(array_filter(array_map('intval', $ids), static fn (int $id): bool => $id > 0));
    }

    /**
     * processing 中残留的任务 id
     *
     * @return int[]
     */
    public static function processingIds(): array
    {
        $ids = RedisCache::client()->lrange(self::PROCESSING_KEY, 0, -1);
        if (!is_array($ids)) {
            return [];
        }

        return array_values(array_filter(array_map('intval', $ids), static fn (int $id): bool => $id > 0));
    }

    /**
     * 队列总深度（就绪 + 延迟 + 处理中）
     */
    public static function pendingCount(): int
    {
        $client = RedisCache::client();

        return (int) $client->zcard(self::READY_KEY)
            + (int) $client->zcard(self::DELAYED_KEY)
            + (int) $client->llen(self::PROCESSING_KEY);
    }

    /**
     * 清空队列（仅供测试/排障，不删除数据库任务）
     */
    public static function reset(): void
    {
        RedisCache::client()->del([
            self::READY_KEY,
            self::DELAYED_KEY,
            self::PROCESSING_KEY,
        ]);
    }

    /**
     * 优先级 + 入队毫秒；分数越小越优先。
     *
     * 1e14 的优先级步长远大于毫秒时间戳（约 1.7e12），
     * 因此高优先级始终先出队，同优先级按入队时间 FIFO。
     */
    private static function score(int $priority): string
    {
        $priority = max(0, min(10, $priority));
        $ms       = (int) floor(microtime(true) * 1000);

        return (string) ((10 - $priority) * 100000000000000 + $ms);
    }

    /**
     * Predis eval 包装：keys 在前，args 在后。
     *
     * @param string[] $keys
     * @param array<int,int|string> $args
     * @return mixed
     */
    private static function eval(string $script, array $keys, array $args)
    {
        $params = array_merge([$script, count($keys)], $keys, $args);

        return RedisCache::client()->eval(...$params);
    }
}