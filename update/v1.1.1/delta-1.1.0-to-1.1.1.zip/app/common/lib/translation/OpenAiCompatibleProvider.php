<?php
declare(strict_types=1);

namespace app\common\lib\translation;

use RuntimeException;

/**
 * OpenAI 兼容协议的翻译提供者
 *
 * 后台只需填写 base_url / api_key / model，即可对接 DeepSeek、OpenAI、通义等兼容端点。
 */
class OpenAiCompatibleProvider implements TranslationProviderInterface
{
    private const LANG_NAMES = [
        'en' => 'English',
        'zh' => 'Simplified Chinese',
        'ru' => 'Russian',
        'fr' => 'French',
        'ar' => 'Arabic',
        'ja' => 'Japanese',
        'it' => 'Italian',
        'de' => 'German',
        'pt' => 'Portuguese',
        'es' => 'Spanish',
    ];

    /**
     * @param array<string,mixed> $config translation.* 配置
     */
    public function __construct(private array $config)
    {
    }

    /**
     * @inheritDoc
     */
    public function translate(array $fields, string $sourceLang, string $targetLang, array $options = []): array
    {
        $baseUrl = trim((string) ($this->config['base_url'] ?? ''));
        $apiKey = trim((string) ($this->config['api_key'] ?? ''));
        $model = trim((string) ($this->config['model'] ?? ''));
        if ($baseUrl === '' || $apiKey === '' || $model === '') {
            throw new RuntimeException('AI 翻译未配置：请填写接口地址、API Key 与模型 ID');
        }

        $source = self::LANG_NAMES[strtolower($sourceLang)] ?? $sourceLang;
        $target = self::LANG_NAMES[strtolower($targetLang)] ?? $targetLang;

        $system = "You are a professional e-commerce translator. Translate the JSON values from {$source} to {$target}.\n"
            . "Rules:\n"
            . "- Return ONLY a valid JSON object with exactly the same keys and structure as the input.\n"
            . "- Translate human-readable text; keep HTML tags and attributes, URLs, numbers, units, SKU codes and {{placeholders}} unchanged.\n"
            . "- Do not add explanations, marketing claims or content not present in the source.\n"
            . "- Keep brand names and product codes untranslated unless they are ordinary words.\n"
            . "- For arrays, keep the same order and the same number of items.\n"
            . "- Empty strings stay empty.";

        $body = [
            'model'    => $model,
            'messages' => [
                ['role' => 'system', 'content' => $system],
                ['role' => 'user', 'content' => json_encode($fields, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)],
            ],
            'stream'   => false,
        ];

        $thinking = strtolower(trim((string) ($this->config['thinking'] ?? 'enabled')));
        if ($thinking === 'disabled') {
            // 关闭思考模式时才使用 temperature
            $body['temperature'] = (float) ($this->config['temperature'] ?? 0.3);
            $body['thinking'] = ['type' => 'disabled'];
        } else {
            // DeepSeek 思考模式：默认开启，低强度；temperature 不生效，不发送
            $body['thinking'] = ['type' => 'enabled'];
            $body['reasoning_effort'] = in_array(
                (string) ($this->config['reasoning_effort'] ?? 'low'),
                ['low', 'high', 'max'],
                true
            ) ? (string) ($this->config['reasoning_effort'] ?? 'low') : 'low';
        }

        $url = $this->endpoint($baseUrl);
        $payload = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $timeout = max(10, (int) ($options['timeout'] ?? $this->config['timeout'] ?? 120));

        $ch = curl_init($url);
        \app\common\lib\CurlTls::apply($ch);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Bearer ' . $apiKey,
                'Content-Type: application/json',
                'Accept: application/json',
            ],
        ]);
        $response = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($response === false || $error !== '') {
            throw new RuntimeException('AI 接口请求失败：' . ($error !== '' ? $error : '未知网络错误'));
        }
        if ($status < 200 || $status >= 300) {
            throw new RuntimeException('AI 接口返回 HTTP ' . $status . '：' . mb_substr((string) $response, 0, 300));
        }

        $data = json_decode((string) $response, true);
        if (!is_array($data)) {
            throw new RuntimeException('AI 接口返回的不是 JSON');
        }

        $choice  = (array) ($data['choices'][0] ?? []);
        $message = (array) ($choice['message'] ?? []);
        $content = (string) ($message['content'] ?? '');
        $reasoning = (string) ($message['reasoning_content'] ?? '');
        $finish  = (string) ($choice['finish_reason'] ?? '');

        if ($finish === 'length') {
            throw new RuntimeException('AI 输出被截断（finish_reason=length），请缩短字段或提高 max_tokens');
        }
        if ($finish === 'content_filter') {
            throw new RuntimeException('AI 输出被内容安全策略拦截（finish_reason=content_filter）');
        }

        // 优先正文 content；仅当正文为空时才回退 reasoning_content
        $candidate = $content !== '' ? $content : $reasoning;
        $candidate = $this->stripThinking($candidate);

        $translated = $this->decodeJsonObject($candidate);
        if (!is_array($translated) && $content !== '' && $reasoning !== '') {
            // 少数兼容端点会把最终 JSON 放在 reasoning_content
            $translated = $this->decodeJsonObject($this->stripThinking($reasoning));
        }
        if (!is_array($translated)) {
            throw new RuntimeException('AI 返回内容无法解析为 JSON 对象');
        }

        $usage = (array) ($data['usage'] ?? []);
        return [
            'fields' => $translated,
            'usage'  => [
                'prompt_tokens'     => (int) ($usage['prompt_tokens'] ?? 0),
                'completion_tokens' => (int) ($usage['completion_tokens'] ?? 0),
            ],
            'raw'    => $candidate,
        ];
    }

    /**
     * 拼接 /chat/completions 地址
     */
    private function endpoint(string $baseUrl): string
    {
        $baseUrl = rtrim($baseUrl, '/');
        if (str_ends_with($baseUrl, '/chat/completions')) {
            return $baseUrl;
        }
        if (preg_match('~/v\d+$~i', $baseUrl)) {
            return $baseUrl . '/chat/completions';
        }
        return $baseUrl . '/v1/chat/completions';
    }

    /**
     * 去掉模型可能带出的思考包裹标签
     */
    private function stripThinking(string $content): string
    {
        $text = preg_replace('/<think(?:ing)?>.*?<\/think(?:ing)?>/is', '', $content) ?? $content;
        $text = preg_replace('/<analysis>.*?<\/analysis>/is', '', $text) ?? $text;

        return trim($text);
    }

    /**
     * 从模型输出里提取 JSON
     *
     * 兼容：
     * - 纯 JSON
     * - ```json ... ``` 代码块
     * - 前后有说明文字
     * - 思维链里出现花括号
     *
     * @return array<string,mixed>|null
     */
    private function decodeJsonObject(string $content): ?array
    {
        $text = trim($content);
        if ($text === '') {
            return null;
        }

        $decoded = json_decode($text, true);
        if (is_array($decoded)) {
            return $decoded;
        }

        if (preg_match('/```(?:json)?\s*(\{.*\})\s*```/is', $text, $m) === 1) {
            $decoded = json_decode(trim($m[1]), true);
            if (is_array($decoded)) {
                return $decoded;
            }
        }

        // 从每个 “{” 开始做字符串/转义感知的平衡括号扫描
        $len = strlen($text);
        for ($start = 0; $start < $len; $start++) {
            if ($text[$start] !== '{') {
                continue;
            }
            $end = $this->findJsonEnd($text, $start);
            if ($end === null) {
                continue;
            }
            $decoded = json_decode(substr($text, $start, $end - $start + 1), true);
            if (is_array($decoded)) {
                return $decoded;
            }
        }

        return null;
    }

    /**
     * 找到与起始 “{” 匹配的 “}”，跳过字符串内的花括号与转义字符
     */
    private function findJsonEnd(string $text, int $start): ?int
    {
        $depth = 0;
        $inString = false;
        $escaped = false;
        $len = strlen($text);

        for ($i = $start; $i < $len; $i++) {
            $char = $text[$i];

            if ($inString) {
                if ($escaped) {
                    $escaped = false;
                } elseif ($char === '\\') {
                    $escaped = true;
                } elseif ($char === '"') {
                    $inString = false;
                }
                continue;
            }

            if ($char === '"') {
                $inString = true;
                continue;
            }
            if ($char === '{') {
                $depth++;
                continue;
            }
            if ($char === '}') {
                $depth--;
                if ($depth === 0) {
                    return $i;
                }
            }
        }

        return null;
    }
}