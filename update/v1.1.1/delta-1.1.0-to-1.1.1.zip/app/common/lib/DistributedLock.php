<?php

namespace app\common\lib;

class DistributedLock
{
    private const UNLOCK_LUA = "if redis.call('get',KEYS[1])==ARGV[1] then return redis.call('del',KEYS[1]) else return 0 end";
    private const RENEW_LUA  = "if redis.call('get',KEYS[1])==ARGV[1] then return redis.call('expire',KEYS[1],ARGV[2]) else return 0 end";

    public static function lock(string $key, int $ttl, ?string $token = null): ?string
    {
        $token = $token ?: bin2hex(random_bytes(8));
        $res = RedisCache::client()->set('lock:' . $key, $token, 'EX', $ttl, 'NX');
        return $res !== null ? $token : null;
    }

    public static function unlock(string $key, string $token): bool
    {
        $r = RedisCache::client()->eval(self::UNLOCK_LUA, 1, 'lock:' . $key, $token);
        return (int)$r === 1;
    }

    /**
     * 续期：只有仍持有同一 token 时才延长，避免误续别人的锁。
     */
    public static function renew(string $key, string $token, int $ttl): bool
    {
        $r = RedisCache::client()->eval(self::RENEW_LUA, 1, 'lock:' . $key, $token, $ttl);
        return (int)$r === 1;
    }
}
