<?php

namespace app\common\command;

use app\common\lib\translation\OpenAiCompatibleProvider;
use think\console\Command;
use think\console\Input;
use think\console\Output;

/**
 * AI 翻译 Provider 冒烟测试（客户端部分）：
 * 需要 先 用 php think translation:fakeapi 启动本地假端点（见该命令）。
 * 不访问真实 AI 服务，不写数据库。
 */
class TranslationAiTest extends Command
{
    private const PORT = 8931;

    protected function configure(): void
    {
        $this->setName('translation:aitest')->setDescription('Verify AI translation provider request body & response parsing (needs translation:fakeapi running)');
    }

    protected function execute(Input $input, Output $output): void
    {
        $base = [
            'base_url'         => 'http://127.0.0.1:' . self::PORT . '/v1',
            'api_key'          => 'sk-test',
            'model'            => 'deepseek-flash',
            'temperature'      => 0.3,
            'thinking'         => 'enabled',
            'reasoning_effort' => 'low',
            'timeout'          => 15,
        ];

        // 用例 1：默认低思考 + 非流式，无 temperature
        $result = $this->call($base, ['title' => 'Test product'], 'thinking_low');
        $req = $this->lastRequest();
        $this->assert($output, 'body.thinking.type=enabled', ($req['thinking']['type'] ?? '') === 'enabled');
        $this->assert($output, 'body.reasoning_effort=low', ($req['reasoning_effort'] ?? '') === 'low');
        $this->assert($output, 'body.stream=false', ($req['stream'] ?? true) === false);
        $this->assert($output, 'body 无 temperature', !array_key_exists('temperature', $req));
        $this->assert($output, 'content 解析', ($result['fields']['title'] ?? '') === 'Produit test');
        $this->assert($output, 'usage 记录', ($result['usage']['completion_tokens'] ?? 0) === 20);

        // 用例 2：只有 reasoning_content（含 think 标签与花括号文本）
        $result = $this->call($base, ['title' => 'Test'], 'reasoning_only');
        $this->assert($output, 'reasoning_only 回退解析', ($result['fields']['title'] ?? '') === 'Produit test');

        // 用例 3：finish_reason=length 必须抛异常
        $threw = false;
        try {
            $this->call($base, ['title' => 'Long content here'], 'finish_length');
        } catch (\RuntimeException $e) {
            $threw = str_contains($e->getMessage(), '截断');
        }
        $this->assert($output, 'finish_reason=length 抛错', $threw);

        // 用例 4：thinking=disabled -> temperature + thinking disabled
        $disabled = $base;
        $disabled['thinking'] = 'disabled';
        $this->call($disabled, ['title' => 'Test'], 'thinking_low');
        $req = $this->lastRequest();
        $this->assert($output, 'disabled.thinking.type=disabled', ($req['thinking']['type'] ?? '') === 'disabled');
        $this->assert($output, 'disabled 有 temperature', isset($req['temperature']));
        $this->assert($output, 'disabled 无 reasoning_effort', !array_key_exists('reasoning_effort', $req));

        $output->writeln('<info>translation AI provider OK</info>');
    }

    private function call(array $config, array $fields, string $case): array
    {
        // 假端点按 model 字段分支返回不同用例响应
        $config['model'] = $case;
        $provider = new OpenAiCompatibleProvider($config);

        return $provider->translate($fields, 'en', 'fr');
    }

    private function lastRequest(): array
    {
        $file = runtime_path() . 'translation-ai-last-request.json';

        return (array) json_decode((string) file_get_contents($file), true);
    }

    private function assert(Output $output, string $name, bool $ok): void
    {
        $output->writeln($ok ? "<info>ok: {$name}</info>" : "<error>FAIL: {$name}</error>");
    }
}
