<?php
declare(strict_types=1);

namespace app\common\command;

use app\common\lib\DistributedLock;
use app\common\lib\translation\TranslationQueue;
use app\common\model\TranslationJob;
use app\common\service\TranslationJobService;
use think\console\Command;
use think\console\Input;
use think\console\input\Option;
use think\console\Output;

/**
 * AI 翻译 worker
 *
 * 单消费者：同一时间只允许一个进程处理任务。
 * 队列：Redis ZSET(ready) + ZSET(delayed) + LIST(processing)。
 *
 * 用法：
 *   php think translate:work --once          # 只处理一个任务
 *   php think translate:work --sleep=3       # 常驻
 *   php think translate:work --limit=20      # 最多处理 20 个
 */
class TranslateWork extends Command
{
    private const LOCK_KEY = 'translate:worker';
    private const LOCK_TTL = 1800;

    protected function configure(): void
    {
        $this->setName('translate:work')
            ->setDescription('Consume AI translation jobs from Redis (single consumer)')
            ->addOption('once', null, Option::VALUE_NONE, '只处理一个任务后退出')
            ->addOption('limit', null, Option::VALUE_REQUIRED, '本次最多处理任务数，0 表示不限制', '0')
            ->addOption('sleep', null, Option::VALUE_REQUIRED, '队列为空时的休眠秒数', '3');
    }

    protected function execute(Input $input, Output $output): void
    {
        $service = new TranslationJobService();
        $queue   = new TranslationQueue();
        $once    = (bool) $input->getOption('once');
        $limit   = max(0, (int) $input->getOption('limit'));
        $sleep   = max(1, (int) $input->getOption('sleep'));
        $processed = 0;

        $token = DistributedLock::lock(self::LOCK_KEY, self::LOCK_TTL);
        if ($token === null) {
            $output->writeln('<comment>另一个 translate:work 正在运行，当前进程退出</comment>');
            return;
        }

        try {
            $recovered = $service->recoverQueue();
            $output->writeln(sprintf(
                'queue=%d recovered=%d reset=%d',
                $queue->pendingCount(),
                $recovered['queued'],
                $recovered['reset']
            ));

            while (true) {
                if ($limit > 0 && $processed >= $limit) {
                    break;
                }

                if ($service->isBudgetExceeded()) {
                    $output->writeln('<comment>今日 AI 翻译预算已用完，暂停消费</comment>');
                    if ($once) {
                        break;
                    }
                    sleep(60);
                    continue;
                }

                // 延迟重试到期后回到 ready
                $this->promoteDelayed($queue);

                $jobId = $queue->pop();
                if ($jobId === null) {
                    if ($once) {
                        break;
                    }
                    sleep($sleep);
                    continue;
                }

                // 长任务运行前续期，避免单任务执行期间锁过期
                if (!DistributedLock::renew(self::LOCK_KEY, $token, self::LOCK_TTL)) {
                    $output->writeln('<error>worker 锁已失效，当前进程退出，任务留在 processing 等待恢复</error>');
                    break;
                }

                $job = $service->claimById($jobId);
                if (!$job) {
                    // 任务已被处理、取消或状态不一致，清掉队列残留
                    $queue->ack($jobId);
                    continue;
                }

                try {
                    $service->run($job);
                    $queue->ack($jobId);
                    $processed++;
                    $output->writeln('done: #' . $job->id . ' ' . $job->entity_type . '#' . $job->entity_id . ' -> ' . $job->target_lang);
                } catch (\Throwable $e) {
                    $failed = $service->fail($job, $e);
                    $processed++;
                    $output->writeln(
                        '<error>failed: #' . $job->id . ' ' . $e->getMessage()
                        . ' status=' . $failed['status']
                        . ($failed['next_retry_at'] ? ' retry_at=' . $failed['next_retry_at'] : '')
                        . '</error>'
                    );
                }

                DistributedLock::renew(self::LOCK_KEY, $token, self::LOCK_TTL);

                if ($once) {
                    break;
                }
            }
        } finally {
            DistributedLock::unlock(self::LOCK_KEY, $token);
        }

        $output->writeln('done, processed ' . $processed . ' job(s)');
    }

    /**
     * 把到期的延迟任务按数据库优先级重新放回 ready
     */
    private function promoteDelayed(TranslationQueue $queue): void
    {
        foreach ($queue->dueDelayed(50) as $id) {
            $job = TranslationJob::find($id);
            if ($job && $job->status === TranslationJob::STATUS_PENDING) {
                $queue->push($id, (int) $job->priority);
            } else {
                $queue->ack($id);
            }
        }
    }
}
