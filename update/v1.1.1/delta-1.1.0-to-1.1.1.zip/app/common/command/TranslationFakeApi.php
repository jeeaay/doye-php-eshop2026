<?php

namespace app\common\command;

use think\console\Command;
use think\console\Input;
use think\console\Output;

/**
 * 本地假 OpenAI 兼容端点（仅测试用）：
 *   php think translation:fakeapi
 * 然后另开进程运行 php think translation:aitest，完成后 Ctrl+C 结束本命令。
 *
 * 按请求体里的 model 字段分支返回不同用例响应，并把收到的请求体
 * 写到 runtime/translation-ai-last-request.json 供断言。
 */
class TranslationFakeApi extends Command
{
    private const PORT = 8931;

    protected function configure(): void
    {
        $this->setName('translation:fakeapi')->setDescription('Start local fake OpenAI-compatible endpoint on 127.0.0.1:' . self::PORT . ' (for translation:aitest)');
    }

    protected function execute(Input $input, Output $output): void
    {
        $runtimeDir = runtime_path();
        $routerFile = $runtimeDir . 'translation-ai-fake-router.php';
        file_put_contents($routerFile, <<<'PHP'
<?php
$body = json_decode((string) file_get_contents('php://input'), true) ?: [];
$case = (string) ($body['model'] ?? 'thinking_low');
file_put_contents(__DIR__ . '/translation-ai-last-request.json', json_encode($body));

$finish = 'stop';
$content = json_encode(['title' => 'Produit test', 'description' => 'Bonjour'], JSON_UNESCAPED_UNICODE);
$reasoning = '';
if ($case === 'reasoning_only') {
    $content = '';
    $reasoning = "思考一下。<think>内部标签</think>{oops braced text} 最终结果：\n{\"title\": \"Produit test\", \"description\": \"Bonjour\"}";
} elseif ($case === 'finish_length') {
    $finish = 'length';
    $content = '{"title": "Truncat';
}
header('Content-Type: application/json');
echo json_encode([
    'choices' => [[
        'message' => array_filter([
            'role' => 'assistant',
            'content' => $content,
            'reasoning_content' => $reasoning,
        ], static fn ($v) => $v !== ''),
        'finish_reason' => $finish,
    ]],
    'usage' => ['prompt_tokens' => 10, 'completion_tokens' => 20],
]);
PHP);

        $output->writeln('fake endpoint: http://127.0.0.1:' . self::PORT . '/v1/chat/completions');
        passthru('"' . PHP_BINARY . '" -S 127.0.0.1:' . self::PORT . ' "' . $routerFile . '"');
    }
}
