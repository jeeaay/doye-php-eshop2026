<?php

namespace app\common\command;

use app\common\lib\DistributedLock;
use app\common\lib\translation\TranslationQueue;
use think\console\Command;
use think\console\Input;
use think\console\Output;

/**
 * 翻译 Redis 队列冒烟测试（不写数据库）
 */
class TranslationQueueTest extends Command
{
    protected function configure(): void
    {
        $this->setName('translation:queuetest')->setDescription('Verify translation Redis queue (push/pop/priority/delay/ack)');
    }

    protected function execute(Input $input, Output $output): void
    {
        TranslationQueue::reset();

        TranslationQueue::push(101, 1);
        TranslationQueue::push(102, 10);
        TranslationQueue::push(103, 5);
        TranslationQueue::push(102, 10); // 重复 push 只更新 score

        $order = [];
        while ($id = TranslationQueue::pop()) {
            $order[] = $id;
        }
        $output->writeln('pop order: ' . implode(',', $order));
        $okOrder = $order === [102, 103, 101];
        $output->writeln('priority+FIFO: ' . ($okOrder ? 'ok' : 'FAIL') . ' processing=' . implode(',', TranslationQueue::processingIds()));

        // ack 清理 processing
        foreach ($order as $id) {
            TranslationQueue::ack($id);
        }
        $output->writeln('after ack: pending=' . TranslationQueue::pendingCount() . ' processing=' . count(TranslationQueue::processingIds()));

        // 延迟与到期
        TranslationQueue::delay(201, time() - 1);
        TranslationQueue::delay(202, time() + 60);
        $due = TranslationQueue::dueDelayed(10);
        $output->writeln('due delayed: ' . implode(',', $due) . ' (expect 201)');
        $okDue = $due === [201];
        TranslationQueue::ack(201);
        TranslationQueue::ack(202);
        $output->writeln('delay/due: ' . ($okDue ? 'ok' : 'FAIL') . ' pending=' . TranslationQueue::pendingCount());

        // 锁续期
        $token = DistributedLock::lock('translation:queuetest', 5);
        $renew = $token ? DistributedLock::renew('translation:queuetest', $token, 5) : false;
        $wrongRenew = DistributedLock::renew('translation:queuetest', 'badtoken', 5);
        $unlock = $token ? DistributedLock::unlock('translation:queuetest', $token) : false;
        $output->writeln('lock renew: ' . ($renew ? 'ok' : 'FAIL') . ' wrong-token=' . ($wrongRenew ? 'ok(UNEXPECTED)' : 'blocked(expected)') . ' unlock=' . ($unlock ? 'ok' : 'FAIL'));

        TranslationQueue::reset();
        $output->writeln('<info>translation queue OK</info>');
    }
}
