(() => {
    if (typeof Swal === 'undefined') {
        console.error('SweetAlert2 not loaded');
        return;
    }

    const SwalWithDefaults = (config) => Swal.mixin({
        confirmButtonColor: '#1677FF',
        cancelButtonColor: '#d9d9d9',
        ...config,
    });

    const AdminToast = {
        success(msg) {
            SwalWithDefaults({
                toast: true,
                position: 'top-end',
                icon: 'success',
                title: msg,
                showConfirmButton: false,
                timer: 2500,
                timerProgressBar: true,
            }).fire();
        },
        error(msg) {
            SwalWithDefaults({
                toast: true,
                position: 'top-end',
                icon: 'error',
                title: msg,
                showConfirmButton: true,
                timer: 5000,
                timerProgressBar: true,
            }).fire();
        },
    };

    const AdminAjax = {
        async post(url, data) {
            const body = data instanceof FormData ? data : new URLSearchParams(data);
            const resp = await fetch(url, {
                method: 'POST',
                body,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    ...(data instanceof FormData ? {} : { 'Content-Type': 'application/x-www-form-urlencoded' }),
                },
            });
            const text = await resp.text();
            let result;
            try {
                result = JSON.parse(text);
            } catch {
                throw new Error('服务器返回格式异常');
            }
            if (!resp.ok) {
                throw new Error(result.message || `请求失败（${resp.status}）`);
            }
            if (result.code !== 0) {
                throw new Error(result.message || '操作失败');
            }
            return result;
        },
    };

    const AdminConfirm = {
        async ask({ title, text, confirmText, danger }) {
            const result = await SwalWithDefaults({
                title: title || '确认操作',
                text: text || '',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: confirmText || '确认',
                cancelButtonText: '取消',
                reverseButtons: true,
                confirmButtonColor: danger ? '#CF1322' : '#1677FF',
            }).fire();
            return result.isConfirmed;
        },
        async show({ title, text, confirmText, onConfirm }) {
            if (await this.ask({ title, text, confirmText }) && typeof onConfirm === 'function') {
                try {
                    await onConfirm();
                } catch (e) {
                    AdminToast.error(e.message);
                }
            }
        },
    };

    const AdminModal = {
        async form({ title, html, confirmText, width, onOpen, onConfirm }) {
            const result = await SwalWithDefaults({
                title: title || '',
                html: html,
                width: width || '560px',
                showCancelButton: true,
                confirmButtonText: confirmText || '保存',
                cancelButtonText: '取消',
                reverseButtons: true,
                focusConfirm: false,
                didOpen: (modal) => {
                    if (typeof onOpen === 'function') onOpen(modal);
                },
                preConfirm: async () => {
                    if (typeof onConfirm !== 'function') return true;
                    try {
                        const ok = await onConfirm(Swal.getPopup());
                        return ok !== false;
                    } catch (e) {
                        AdminToast.error(e.message || '操作失败');
                        Swal.showValidationMessage(e.message);
                        return false;
                    }
                },
            }).fire();
            return result;
        },
    };

    window.AdminToast = AdminToast;
    window.AdminAjax = AdminAjax;
    window.AdminConfirm = AdminConfirm;
    window.AdminModal = AdminModal;
})();
