<?php
use think\migration\Migrator;

/**
 * 分类增加 SEO 与自定义访问路径字段
 *
 * - short_title   : 短标题（栏目封面页副标题）
 * - custom_path   : 自定义访问路径（归一化后全局唯一），NULL=未设置
 * - seo_title     : 栏目封面页 SEO 标题
 * - description   : 栏目描述
 * - seo_keywords  : 栏目 SEO 关键词
 *
 * 唯一性约束：custom_path 跨 category / product / page 全局唯一。
 */
class AddCategorySeoAndSlug extends Migrator
{
    public function change()
    {
        $this->table('category')
            ->addColumn('short_title', 'string', [
                'limit'   => 128,
                'null'    => true,
                'default' => null,
                'comment' => '短标题（栏目封面页副标题）',
                'after'   => 'name',
            ])
            ->addColumn('custom_path', 'string', [
                'limit'   => 191,
                'null'    => true,
                'default' => null,
                'comment' => '自定义访问路径（归一化，全局唯一），NULL=未设置',
                'after'   => 'short_title',
            ])
            ->addColumn('seo_title', 'string', [
                'limit'   => 255,
                'null'    => true,
                'default' => null,
                'comment' => 'SEO 标题',
                'after'   => 'custom_path',
            ])
            ->addColumn('description', 'text', [
                'null'    => true,
                'default' => null,
                'comment' => '栏目描述',
                'after'   => 'seo_title',
            ])
            ->addColumn('seo_keywords', 'string', [
                'limit'   => 255,
                'null'    => true,
                'default' => null,
                'comment' => 'SEO 关键词',
                'after'   => 'description',
            ])
            ->addIndex(['custom_path'], ['unique' => true, 'name' => 'uk_category_custom_path'])
            ->update();
    }
}
