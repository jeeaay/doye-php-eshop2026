<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\model\Category;
use think\facade\View;
use app\common\service\AdminCrudService;
use app\common\exception\BizException;

class Categories extends AdminBaseController
{
    public function index()
    {
        $this->assignActiveMenu('categories');

        $parents = Category::where('parent_id', 0)
            ->order('sort', 'asc')
            ->order('id', 'asc')
            ->select();

        $tree = [];
        foreach ($parents as $parent) {
            $children = Category::where('parent_id', $parent->id)
                ->order('sort', 'asc')
                ->order('id', 'asc')
                ->select()
                ->toArray();
            $tree[] = $this->buildCategoryNode($parent->toArray(), $children);
        }

        View::assign('categories', $tree);
        return View::fetch();
    }

    public function detail()
    {
        $id = (int) $this->request->param('id', 0);
        $category = $id > 0 ? Category::find($id) : null;
        if (!$category) {
            return json(['code' => 1, 'message' => '分类不存在', 'data' => null]);
        }
        return json([
            'code'    => 0,
            'message' => '',
            'data'    => [
                'id'           => (int) $category->id,
                'parent_id'    => (int) $category->parent_id,
                'name'         => $category->name,
                'short_title'  => (string) ($category->short_title ?? ''),
                'custom_path'  => (string) ($category->custom_path ?? ''),
                'seo_title'    => (string) ($category->seo_title ?? ''),
                'description'  => (string) ($category->description ?? ''),
                'seo_keywords' => (string) ($category->seo_keywords ?? ''),
                'sort'         => (int) $category->sort,
            ],
        ]);
    }

    public function save()
    {
        try {
            $id = $this->request->post('id') ? (int) $this->request->post('id') : null;
            (new AdminCrudService())->saveCategory($this->request->post(), $id);
            return json(['code' => 0, 'message' => '分类已保存', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    public function delete()
    {
        try {
            (new AdminCrudService())->deleteCategory((int) $this->request->post('id'));
            return json(['code' => 0, 'message' => '分类已删除', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 构建分类节点（包含所有新字段）
     */
    private function buildCategoryNode(array $node, array $children = []): array
    {
        return [
            'id'           => (int) $node['id'],
            'parent_id'    => (int) ($node['parent_id'] ?? 0),
            'name'         => $node['name'],
            'short_title'  => (string) ($node['short_title'] ?? ''),
            'custom_path'  => (string) ($node['custom_path'] ?? ''),
            'seo_title'    => (string) ($node['seo_title'] ?? ''),
            'description'  => (string) ($node['description'] ?? ''),
            'seo_keywords' => (string) ($node['seo_keywords'] ?? ''),
            'sort'         => (int) $node['sort'],
            'status'       => 1,
            'children'     => $children,
        ];
    }
}
