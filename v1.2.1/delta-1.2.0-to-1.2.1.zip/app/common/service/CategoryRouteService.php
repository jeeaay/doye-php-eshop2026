<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\exception\BizException;
use app\common\lib\RedisCache;
use app\common\model\Category;
use app\common\model\Page;
use app\common\model\Product;
use think\facade\Db;

/**
 * 分类自定义访问路径服务
 *
 * 职责：
 *   - normalize()：把用户输入归一化为可存储 / 可访问的路径标识
 *   - validate() ：格式、保留字、全局唯一校验（category + product + page 三者互斥）
 *   - resolve()   ：前台路径 → 分类 ID（Redis 优先，MySQL 兜底）
 *
 * 复用 ProductRouteService 的归一化逻辑。
 */
class CategoryRouteService
{
    /** 路由缓存 key 前缀 */
    private const CACHE_PREFIX = 'category:route:';

    /** 路由缓存 TTL（秒） */
    private const CACHE_TTL = 60;

    /** 路径最大长度（与 varchar(191) 对齐，留出余量） */
    private const MAX_LENGTH = 190;

    /**
     * 系统保留路径（与前台静态路由冲突）
     */
    private const RESERVED_PATHS = [
        'products', 'product', 'cart', 'checkout', 'login', 'account',
        'order-success', 'about', 'service', 'contact', 'sitemap', 'sitemap.xml',
        'admin', 'api', 'index', 'home',
    ];

    /**
     * 归一化用户输入的访问路径
     *
     * 规则：小写、去首尾斜杠与空白、空格/下划线转连字符、剔除非法字符、
     * 合并连续连字符。保留 .html 后缀（若用户输入了）。
     *
     * @param string $input 原始输入
     * @return string 归一化后的路径标识（不含首尾 /）
     */
    public function normalize(string $input): string
    {
        return (new ProductRouteService())->normalize($input);
    }

    /**
     * 校验分类访问路径
     *
     * @param string   $path            归一化后的路径标识（空串表示不设置，直接放行）
     * @param int|null $exceptCategoryId 排除自身的分类 ID（编辑场景）
     * @throws BizException 校验不通过
     */
    public function validate(string $path, ?int $exceptCategoryId = null): void
    {
        if ($path === '') {
            return;
        }

        if (mb_strlen($path) > self::MAX_LENGTH) {
            throw new BizException('访问路径不能超过 ' . self::MAX_LENGTH . ' 个字符');
        }

        if (!preg_match('/^[a-z0-9\-]+(\.html)?$/', $path)) {
            throw new BizException('访问路径格式无效：仅支持小写字母、数字和连字符，可选 .html 后缀');
        }

        if (preg_match('/^\d+(\.html)?$/', $path)) {
            throw new BizException('访问路径不能是纯数字（会与分类 ID 路径冲突），请加入字母或连字符');
        }

        $base = $this->basePath($path);

        // 保留字
        foreach ([$base, $path] as $candidate) {
            if (in_array($candidate, self::RESERVED_PATHS, true)) {
                throw new BizException('访问路径「' . $candidate . '」为系统保留路径，请更换');
            }
        }

        // 与 CMS 单页冲突
        if (Page::where('slug', $base)->find()) {
            throw new BizException('访问路径「' . $base . '」已被内容单页占用，请更换');
        }

        // 与分类自身冲突
        $categoryQuery = Db::name('category')->where('custom_path', $path);
        if ($exceptCategoryId) {
            $categoryQuery->where('id', '<>', $exceptCategoryId);
        }
        if ($categoryQuery->value('id')) {
            throw new BizException('访问路径「' . $path . '」已被其他分类使用，请更换');
        }

        // 与商品冲突（必须用原生查询，包含软删记录）
        $productQuery = Db::name('product')->where('custom_path', $path);
        if ($productQuery->value('id')) {
            throw new BizException('访问路径「' . $path . '」已被商品使用，请更换');
        }
    }

    /**
     * 解析前台路径 → 分类 ID
     *
     * @param string $path URL 路径段（匹配时已剥离 .html 后缀）
     * @return int|null 分类 ID；未命中返回 null
     */
    public function resolve(string $path): ?int
    {
        $path = strtolower(trim($path));
        if ($path === '') {
            return null;
        }

        $base = $this->basePath($path);
        $candidates = array_values(array_unique($base !== '' ? [$base, $base . '.html'] : [$path]));

        foreach ($candidates as $candidate) {
            $categoryId = RedisCache::remember(
                self::CACHE_PREFIX . $candidate,
                self::CACHE_TTL,
                function () use ($candidate): ?int {
                    $category = Category::where('custom_path', $candidate)->find();
                    return $category ? (int) $category->id : null;
                }
            );
            if ($categoryId !== null && (int) $categoryId > 0) {
                return (int) $categoryId;
            }
        }

        return null;
    }

    /**
     * 失效路径缓存（保存 / 删除分类时调用）
     *
     * @param string|null ...$paths 需要失效的路径
     */
    public function forgetRouteCache(?string ...$paths): void
    {
        foreach ($paths as $path) {
            $path = strtolower(trim((string) $path));
            if ($path === '') {
                continue;
            }
            $variants = array_unique([$path, $this->basePath($path)]);
            foreach ($variants as $variant) {
                if ($variant === '') {
                    continue;
                }
                RedisCache::forget(self::CACHE_PREFIX . $variant);
            }
        }
    }

    /**
     * 取不带 .html 后缀的基础路径
     */
    private function basePath(string $path): string
    {
        return preg_replace('/\.html$/', '', $path) ?? $path;
    }
}
