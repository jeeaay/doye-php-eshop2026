<?php
declare(strict_types=1);

namespace app\controller;

use app\common\model\Category as CategoryModel;
use app\common\service\CategoryRouteService;

/**
 * 栏目封面页（分类列表）
 *
 * 支持两种寻址：
 *   - /category/{id}、/categories/{id}：数字 ID
 *   - /{custom_path}：自定义访问路径（需写入 category.custom_path）
 *   - /products?category_id={id}：商品列表页按分类过滤（已有）
 *
 * title 拼接规则：栏目名 - 短标题 - SEO标题；缺失的部分自动省略。
 */
class Category extends SiteBase
{
    /**
     * 分类封面页
     *
     * @param string $param URL 参数（数字 ID 或自定义路径段）
     */
    public function detail($param = '')
    {
        $param = trim((string) $param);
        if ($param === '' || $param === '0') {
            return $this->notFound('Category not found');
        }

        if (ctype_digit($param)) {
            $category = CategoryModel::find((int) $param);
        } else {
            $categoryId = (new CategoryRouteService())->resolve($param);
            $category = $categoryId !== null ? CategoryModel::find($categoryId) : null;
        }

        if (!$category) {
            return $this->notFound('Category not found');
        }

        $categoryId = (int) $category->id;
        $brand = $this->store->brand();

        // 栏目名（优先取翻译，回退原表）
        $name = (string) $category->name;
        $shortTitle = trim((string) ($category->short_title ?? ''));
        $seoTitle = trim((string) ($category->seo_title ?? ''));
        $description = trim((string) ($category->description ?? ''));
        $seoKeywords = trim((string) ($category->seo_keywords ?? ''));

        // title 拼接：栏目名 - 短标题 - SEO标题，空值跳过
        $titleParts = array_filter([$name, $shortTitle, $seoTitle], static fn (string $part): bool => $part !== '');
        $pageTitle = implode(' - ', $titleParts);
        if ($pageTitle === '') {
            $pageTitle = $name . ' - ' . $brand['name'];
        }

        $sort = (string) $this->request->get('sort', 'newest');
        if (!in_array($sort, ['newest', 'price-asc', 'price-desc', 'popular'], true)) {
            $sort = 'newest';
        }

        $result = $this->store->productCards(1, 120, $categoryId, '', $sort);

        // canonical URL
        $canonicalPath = '/category/' . $categoryId;
        if (!empty($category->custom_path)) {
            $canonicalPath = '/' . $category->custom_path;
        }

        return $this->render('products', [
            'nav_active'      => 'products',
            'page_title'      => $pageTitle,
            'meta_desc'       => $description !== '' ? $description : '',
            'meta_keys'       => $seoKeywords,
            'products'        => $result['list'],
            'total'           => $result['total'],
            'sort'            => $sort,
            'page_size'       => (int) site_config('per_page', 24),
            'categories'      => $this->store->categories(),
            'active_category' => $categoryId,
            'category_info'   => [
                'id'          => $categoryId,
                'name'        => $name,
                'short_title' => $shortTitle,
                'description' => $description,
            ],
            'canonical_url'  => $this->canonicalUrl($canonicalPath),
            'hreflang_links' => $this->hreflangLinks($canonicalPath),
        ]);
    }
}
