<?php
use think\migration\Migrator;

/**
 * 创建模板文件元数据表 template_file
 *
 * 用于追踪模板文件的 md5、修改时间、翻译状态，
 * 支撑后台模板管理界面和 AI 翻译变更检测。
 */
class CreateTemplateFile extends Migrator
{
    public function change()
    {
        $table = $this->table('template_file', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '模板文件元数据（多模板、多语言追踪）',
        ]);
        $table->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('template', 'string', ['limit' => 64, 'null' => false, 'comment' => '模板名，如 almi2026'])
            ->addColumn('lang', 'string', ['limit' => 16, 'null' => false, 'default' => 'base', 'comment' => 'base 表示源文件，ru/zh 表示翻译版本'])
            ->addColumn('path', 'string', ['limit' => 512, 'null' => false, 'comment' => '相对路径，如 index.html 或 layout/base.html'])
            ->addColumn('md5_hash', 'char', ['limit' => 32, 'null' => false, 'default' => '', 'comment' => '当前文件内容 md5'])
            ->addColumn('file_mtime', 'datetime', ['null' => true, 'comment' => '文件系统修改时间'])
            ->addColumn('last_scanned', 'datetime', ['null' => true, 'comment' => '最后一次扫描时间'])
            ->addColumn('source_hash', 'char', ['limit' => 32, 'null' => false, 'default' => '', 'comment' => '翻译版本对应的 base md5，判断翻译是否过期'])
            ->addColumn('translated_at', 'datetime', ['null' => true, 'comment' => '最后翻译完成时间'])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addIndex(['template', 'lang', 'path'], ['unique' => true, 'name' => 'uk_tpl_lang_path'])
            ->addIndex(['template'], ['name' => 'idx_tpl'])
            ->addIndex(['md5_hash'], ['name' => 'idx_md5'])
            ->create();
    }
}
