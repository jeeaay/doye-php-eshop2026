<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\service\TemplateTranslationService;
use app\common\service\TranslationJobService;

/**
 * Admin API：模板翻译
 */
class TemplateTranslation extends ApiBaseController
{
    /**
     * POST /admin-api/v1/template-translations/enqueue
     *
     * body: {template, path, target_lang}
     */
    public function enqueue()
    {
        return $this->run(function () {
            $this->assertSuper();
            $template = (string) $this->input('template', '');
            $path = (string) $this->input('path', '');
            $targetLang = (string) $this->input('target_lang', '');

            if ($template === '' || $path === '' || $targetLang === '') {
                throw new \app\common\exception\BizException('参数不完整');
            }

            $jobIds = (new TemplateTranslationService())->enqueue($template, $path, $targetLang);
            if ($jobIds === []) {
                return null;
            }
            return ['job_ids' => $jobIds];
        }, '翻译任务已入队');
    }

    /**
     * POST /admin-api/v1/template-translations/backfill
     *
     * 批量入队修改过的模板文件翻译
     * body: {template, langs: []}
     */
    public function backfill()
    {
        return $this->run(function () {
            $this->assertSuper();
            $template = (string) $this->input('template', '');
            $langs = $this->input('langs', []);
            if (is_string($langs)) {
                $langs = array_values(array_filter(array_map('trim', explode(',', $langs))));
            }

            return (new TemplateTranslationService())->enqueueModified(
                $template,
                array_values((array) $langs)
            );
        }, '批量入队完成');
    }
}
