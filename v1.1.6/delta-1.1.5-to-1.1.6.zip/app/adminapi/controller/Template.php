<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\model\TemplateFile;
use app\common\service\SettingService;
use app\common\service\TemplateManager;

/**
 * Admin API：模板管理
 */
class Template extends ApiBaseController
{
    /**
     * GET /admin-api/v1/templates
     */
    public function index()
    {
        return $this->run(function () {
            $this->assertSuper();
            $manager = new TemplateManager();
            $active = $manager->activeTemplate();
            $templates = $manager->listTemplates();

            foreach ($templates as &$tpl) {
                $tpl['is_active'] = $tpl['name'] === $active;
                $tpl['db_files'] = TemplateFile::where('template', $tpl['name'])->where('lang', 'base')->count();
                $tpl['translation_count'] = TemplateFile::where('template', $tpl['name'])->where('lang', '<>', 'base')->count();
            }
            unset($tpl);

            return [
                'active_template' => $active,
                'templates'       => $templates,
            ];
        });
    }

    /**
     * POST /admin-api/v1/templates/scan
     */
    public function scan()
    {
        return $this->run(function () {
            $this->assertSuper();
            $template = (string) $this->input('template', '');
            $manager = new TemplateManager();
            return $manager->scan($template !== '' ? $template : null);
        }, '扫描完成');
    }

    /**
     * POST /admin-api/v1/templates/active
     */
    public function setActive()
    {
        return $this->run(function () {
            $this->assertSuper();
            $template = (string) $this->input('template', '');
            $manager = new TemplateManager();

            if ($template !== 'none' && !$manager->templateExists($template)) {
                throw new \app\common\exception\BizException("模板不存在：{$template}");
            }

            (new SettingService())->save('basic', ['site.template' => $template]);

            // 清理 runtime
            $runtime = app()->getRuntimePath();
            foreach (['temp', 'cache'] as $dir) {
                $path = $runtime . $dir;
                if (is_dir($path)) {
                    array_map('unlink', glob($path . DIRECTORY_SEPARATOR . '*.php') ?: []);
                }
            }

            return null;
        });
    }

    /**
     * GET /admin-api/v1/templates/:name/files
     */
    public function files()
    {
        return $this->run(function () {
            $this->assertSuper();
            $name = (string) $this->request->param('name', '');
            $lang = (string) $this->request->param('lang', '');

            $query = TemplateFile::where('template', $name);
            if ($lang !== '') {
                $query->where('lang', $lang);
            }
            $query->order('path', 'asc')->order('lang', 'asc');

            [$page, $size] = $this->pageParams();
            $pager = $query->paginate($size, false, ['page' => $page]);

            return $this->pagePayload($pager->items()->toArray(), $pager, $page, $size);
        });
    }

    /**
     * GET /admin-api/v1/templates/:name/file-content
     */
    public function fileContent()
    {
        return $this->run(function () {
            $this->assertSuper();
            $name = (string) $this->request->param('name', '');
            $path = (string) $this->request->param('path', '');
            $lang = (string) $this->request->param('lang', 'base');

            if ($name === '' || $path === '') {
                throw new \app\common\exception\BizException('参数不完整');
            }

            $manager = new TemplateManager();
            $content = $manager->fileContent($name, $path, $lang);
            if ($content === null) {
                throw new \app\common\exception\BizException('文件不存在');
            }

            return ['content' => $content];
        });
    }
}
