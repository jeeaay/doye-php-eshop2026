<?php
// 应用公共文件
declare(strict_types=1);

if (!function_exists('h')) {
    /**
     * HTML 转义输出（模板中使用 {:h($var)}）
     */
    function h($value): string
    {
        if (is_array($value) || is_object($value)) {
            return '';
        }
        return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

if (!function_exists('site_config')) {
    /**
     * 读取前台站点配置：site_config('brand.name', 'DepthX')
     *
     * 取值优先级：数据库 setting 表（后台「系统设置」写入的覆盖值）
     *           > config/site.php（默认值）。
     * 合并结果在单次请求内缓存，实际读取逻辑见 SettingService::mergedConfig()。
     */
    function site_config(?string $key = null, $default = null)
    {
        $config = \app\common\service\SettingService::mergedConfig();
        if ($key === null || $key === '') {
            return $config;
        }
        $value = $config;
        foreach (explode('.', $key) as $segment) {
            if (!is_array($value) || !array_key_exists($segment, $value)) {
                return $default;
            }
            $value = $value[$segment];
        }
        return $value;
    }
}

if (!function_exists('money')) {
    /**
     * 金额格式化（PHP 后台价格为 decimal(10,2)，没有分单位）
     */
    function money($amount, int $decimals = 2): string
    {
        return number_format((float) $amount, $decimals, '.', '');
    }
}

if (!function_exists('theme_asset')) {
    /**
     * 主题静态资源 URL（旧版兼容）
     * 已废弃，请使用 template_asset()
     */
    function theme_asset(string $path = ''): string
    {
        return template_asset($path);
    }
}

if (!function_exists('template_asset')) {
    /**
     * 模板静态资源 URL
     *
     * 读取当前启用的模板名（site.template），拼出 /{template}/xxx 路径。
     * 模板中使用：{:template_asset('css/app.css')}
     */
    function template_asset(string $path = ''): string
    {
        $template = (string) site_config('site.template', 'almi2026');
        if ($template === '' || $template === 'none') {
            return '';
        }
        return '/' . $template . '/' . ltrim($path, '/');
    }
}

if (!function_exists('storefront_product_url')) {
    /**
     * 前台商品详情 URL。
     *
     * 商品设置了 custom_path 时优先返回自定义路径：
     *   - 未开启根级：/products/{custom_path}
     *   - 开启根级  ：/{custom_path}（省略 .html 后缀）
     * 否则回落 /products/{id}（数字路径始终可用，不做 301）。
     *
     * @param int|string|array|object $product 商品 ID，或含 custom_path / custom_path_root 的商品数据
     */
    function storefront_product_url($product): string
    {
        $id = 0;
        $customPath = '';
        $isRoot = false;

        if (is_object($product)) {
            $id = (int) ($product->id ?? 0);
            $customPath = trim((string) ($product->custom_path ?? ''));
            $isRoot = (int) ($product->custom_path_root ?? 0) === 1;
        } elseif (is_array($product)) {
            $id = (int) ($product['id'] ?? 0);
            $customPath = trim((string) ($product['custom_path'] ?? ''));
            $isRoot = (int) ($product['custom_path_root'] ?? 0) === 1;
        } else {
            $id = (int) $product;
        }

        if ($customPath !== '') {
            if ($isRoot) {
                return '/' . (preg_replace('/\.html$/', '', $customPath) ?: $customPath);
            }
            return '/products/' . $customPath;
        }

        return '/products/' . $id;
    }
}

if (!function_exists('client_ip')) {
    /**
     * 客户端真实 IP（遵循后台「系统设置 → 安全设置」的可信代理配置）
     *
     * 默认取 REMOTE_ADDR；开启「信任反向代理请求头」且代理地址命中
     * 可信代理列表时，才采信 CF-Connecting-IP / X-Real-IP / X-Forwarded-For。
     * 与安全防护拦截使用同一解析结果，避免审计日志、限流与封禁口径不一致。
     */
    function client_ip(): string
    {
        try {
            return \app\common\service\SecurityService::clientIp();
        } catch (\Throwable $e) {
            return '';
        }
    }
}

if (!function_exists('site_edition')) {
    /**
     * 当前站点版本：international / domestic
     */
    function site_edition(): string
    {
        $edition = strtolower(trim((string) site_config('site.edition', 'international')));
        return in_array($edition, ['international', 'domestic'], true) ? $edition : 'international';
    }
}

if (!function_exists('is_domestic_edition')) {
    function is_domestic_edition(): bool
    {
        return site_edition() === 'domestic';
    }
}

if (!function_exists('base_locale')) {
    /**
     * 基准语言：国内版中文，国际版英文
     */
    function base_locale(): string
    {
        return is_domestic_edition() ? 'zh' : 'en';
    }
}

if (!function_exists('base_currency_code')) {
    /**
     * 基准币种：国内版 CNY，国际版 USD
     */
    function base_currency_code(): string
    {
        return is_domestic_edition() ? 'CNY' : 'USD';
    }
}

if (!function_exists('current_locale')) {
    /**
     * 当前请求的语种短码（en / ru / zh ...）
     */
    function current_locale(): string
    {
        return \app\common\support\LocaleContext::localeCode();
    }
}

if (!function_exists('display_currency')) {
    /**
     * 当前展示币种（数组：code / symbol / decimals / rate ...）
     *
     * @return array<string,mixed>
     */
    function display_currency(): array
    {
        return \app\common\support\LocaleContext::currency();
    }
}

if (!function_exists('format_money')) {
    /**
     * 把 USD 金额换算成当前展示币种并格式化
     *
     * 仅用于前台展示；订单、支付、退款、结算一律使用 USD 原值。
     */
    function format_money($usd, ?array $currency = null): string
    {
        return (new \app\common\service\PricingService())->format($usd, $currency);
    }
}

if (!function_exists('localized_url')) {
    /**
     * 生成带语种前缀的站内 URL
     *
     * 默认语种不带前缀：/products/1
     * 其他语种带前缀：/ru/products/1
     */
    function localized_url(string $path, ?string $locale = null): string
    {
        $path = '/' . ltrim($path, '/');
        $locale = strtolower(trim($locale ?? current_locale()));

        try {
            $default = strtolower((string) ((new \app\common\service\LanguageService())->default()['code'] ?? 'en'));
        } catch (\Throwable $e) {
            $default = 'en';
        }

        if ($locale === '' || $locale === $default) {
            return $path;
        }

        return '/' . $locale . ($path === '/' ? '/' : $path);
    }
}

if (!function_exists('site_lang')) {
    /**
     * 读取前台静态文案（app/lang/{locale}/site.php）
     *
     * 译文缺失时回退英文；再缺则返回 key，便于发现未翻译项。
     *
     * @param string $key 文案键，如 nav.home
     * @param array<string,string> $replace 占位符替换，{name} => value
     */
    function site_lang(string $key, array $replace = []): string
    {
        static $packs = [];

        $load = static function (string $code) use (&$packs): array {
            $code = preg_replace('/[^a-z\-]/i', '', strtolower($code)) ?: 'en';
            if (isset($packs[$code])) {
                return $packs[$code];
            }

            $file = app()->getBasePath() . 'lang' . DIRECTORY_SEPARATOR . $code . DIRECTORY_SEPARATOR . 'site.php';
            if (!is_file($file)) {
                $file = app()->getBasePath() . 'lang' . DIRECTORY_SEPARATOR . 'en' . DIRECTORY_SEPARATOR . 'site.php';
            }

            return $packs[$code] = is_file($file) ? (array) require $file : [];
        };

        $locale = current_locale();
        $value = $load($locale)[$key] ?? $load('en')[$key] ?? $key;

        if (is_array($replace) && $replace) {
            foreach ($replace as $name => $replacement) {
                $value = str_replace('{' . $name . '}', (string) $replacement, $value);
            }
        }

        return (string) $value;
    }
}