<?php
declare(strict_types=1);

namespace app\controller;

use app\BaseController;
use app\common\service\CurrencyService;
use app\common\service\LanguageService;
use app\common\service\PricingService;
use app\common\service\StorefrontService;
use app\common\service\TemplateManager;
use app\common\support\LocaleContext;
use think\facade\View;

/**
 * 前台页面基类：统一注入品牌、导航、页脚、公告等公共数据
 *
 * 多模板支持：
 *   - 通过 site.template 配置选择模板
 *   - 模板文件位于 templates/{template}/
 *   - 静态资源位于 public/{template}/
 *   - locale 优先查找 templates/{template}/{locale}/ 子目录
 */
abstract class SiteBase extends BaseController
{
    protected StorefrontService $store;
    protected TemplateManager $templates;

    protected function initialize()
    {
        $this->store = new StorefrontService();
        $this->templates = new TemplateManager();
    }

    /**
     * 渲染模板视图
     *
     * @param string $template 视图名（不含后缀），如 "index" 或 "layout/base"
     * @param array $vars 额外变量
     */
    protected function render(string $template, array $vars = [])
    {
        $tmpl = $this->templates->activeTemplate();

        // 无模板场景或模板不存在
        if ($tmpl === 'none') {
            return $this->noTemplate();
        }

        $locale = LocaleContext::localeCode();
        $viewFile = $template . '.html';

        // 解析视图路径
        $viewPath = $this->templates->resolveView($tmpl, $viewFile, $locale);
        if (!$viewPath) {
            // 视图文件不存在（该模板可能还没迁移完整）
            return $this->notFound('Template view not found: ' . $template);
        }

        $common = $this->commonVars();
        $vars['template_name'] = $tmpl;
        $vars['template_url'] = '/' . $tmpl;

        return View::fetch($viewPath, array_merge($common, $vars));
    }

    /**
     * commonVars 保持不变，后续需要时在这里注入 template_url 等
     */
    protected function commonVars(array $extra = []): array
    {
        $brand = $this->store->brand();
        $categories = $this->store->categories();
        $locale = LocaleContext::locale();
        $baseCurrency = (new CurrencyService())->base();
        $path = '/' . ltrim((string) $this->request->pathinfo(), '/');

        return array_merge([
            'brand'              => $brand,
            'nav'                => $this->store->nav(),
            'categories'         => array_slice($categories, 0, 8),
            'footer_collections' => array_slice($categories, 0, 8),
            'footer'             => $this->store->footerNav(),
            'contact'            => (array) site_config('contact', []),
            'shipping'           => (array) site_config('shipping', []),
            'announcement'       => (string) site_config('announcement', ''),
            'region_label'       => (string) site_config('region_label', ''),
            'keyword'            => (string) $this->request->get('keyword', ''),
            'nav_active'         => '',
            'page_title'         => $brand['name'],
            'meta_desc'          => '',
            'meta_keys'          => '',
            'meta_robots'        => '',
            'locale_code'        => (string) ($locale['code'] ?? 'en'),
            'locale_dir'         => (string) ($locale['direction'] ?? 'ltr'),
            'locale'             => $locale,
            'display_currency'   => LocaleContext::currency(),
            'display_rate'       => (new PricingService())->displayRate(LocaleContext::currency()),
            'base_currency'      => $baseCurrency,
            'base_currency_code' => base_currency_code(),
            'site_edition'       => site_edition(),
            'canonical_url'      => $this->canonicalUrl($path),
            'hreflang_links'     => $this->hreflangLinks($path),
            'language_options'   => (!is_domestic_edition() && (bool) site_config('i18n.enabled', false)) ? $this->languageOptions($path) : [],
            'currency_options'   => (!is_domestic_edition() && (bool) site_config('currency.enabled', false)) ? $this->currencyOptions($path) : [],
        ], $extra);
    }

    /**
     * 当前页面的 canonical 绝对地址
     */
    protected function canonicalUrl(string $path): string
    {
        $query = $this->request->get();
        unset($query['lang'], $query['currency']);
        $suffix = $query ? '?' . http_build_query($query) : '';
        return $this->request->domain() . localized_url($path) . $suffix;
    }

    /**
     * hreflang 备选链接（含 x-default）
     *
     * @return array<int,array{hreflang:string,url:string}>
     */
    protected function hreflangLinks(string $path): array
    {
        $domain = $this->request->domain();
        $default = (new LanguageService())->default();
        $defaultCode = strtolower((string) ($default['code'] ?? 'en'));

        if (!(bool) site_config('i18n.enabled', false)) {
            return [[
                'hreflang' => 'x-default',
                'url'      => $domain . localized_url($path, $defaultCode),
            ]];
        }

        $links = [];
        foreach ((new LanguageService())->enabled() as $language) {
            $code = strtolower((string) $language['code']);
            $links[] = [
                'hreflang' => $code,
                'url'      => $domain . localized_url($path, $code),
            ];
        }
        $links[] = [
            'hreflang' => 'x-default',
            'url'      => $domain . localized_url($path, $defaultCode),
        ];
        return $links;
    }

    /**
     * 语言切换器选项（保留当前路径与查询参数）
     *
     * @param string $path 已剥离语言前缀的当前路径
     * @return array<int,array<string,mixed>>
     */
    private function languageOptions(string $path): array
    {
        $query = $this->request->get();
        unset($query['lang'], $query['currency']);
        $suffix = $query ? '?' . http_build_query($query) : '';
        $current = current_locale();

        $options = [];
        foreach ((new LanguageService())->enabled() as $language) {
            $options[] = [
                'code'        => (string) $language['code'],
                'name'        => (string) $language['name'],
                'native_name' => (string) $language['native_name'],
                'url'         => localized_url($path, (string) $language['code']) . $suffix,
                'active'      => strtolower((string) $language['code']) === $current,
            ];
        }

        return $options;
    }

    /**
     * 展示币种切换器选项（保留当前路径与查询参数）
     *
     * @param string $path 已剥离语言前缀的当前路径
     * @return array<int,array<string,mixed>>
     */
    private function currencyOptions(string $path): array
    {
        $query = $this->request->get();
        unset($query['lang'], $query['currency']);
        $current = strtoupper((string) (LocaleContext::currency()['code'] ?? 'USD'));
        $baseUrl = localized_url($path);

        $options = [];
        foreach ((new CurrencyService())->enabled() as $currency) {
            $params = $query;
            $params['currency'] = (string) $currency['code'];
            $symbol = (string) $currency['symbol'];
            $options[] = [
                'code'   => (string) $currency['code'],
                'symbol' => $symbol,
                'label'  => ($symbol === '' || strcasecmp($symbol, (string) $currency['code']) === 0)
                    ? (string) $currency['code']
                    : (string) $currency['code'] . ' ' . $symbol,
                'url'    => $baseUrl . '?' . http_build_query($params),
                'active' => strtoupper((string) $currency['code']) === $current,
            ];
        }

        return $options;
    }

    /**
     * 无前台模板场景（纯 API 站）——所有前台请求返回 404
     */
    protected function noTemplate()
    {
        return response('', 404)->contentType('text/html');
    }

    /**
     * 404 页面（带 404 状态码）
     *
     * 注意：此方法可能在模板切换失败时被调用，
     * 此时 template 配置仍为 none，但需要渲染错误页面。
     * 如果 template 正常，会优先使用模板中的 error.html。
     */
    protected function notFound(string $message = 'Page not found')
    {
        $tmpl = $this->templates->activeTemplate();
        if ($tmpl !== 'none') {
            $locale = LocaleContext::localeCode();
            $viewPath = $this->templates->resolveView($tmpl, 'error.html', $locale);
            if ($viewPath) {
                $html = View::fetch($viewPath, array_merge($this->commonVars(), [
                    'nav_active' => '',
                    'page_title' => 'Page not found',
                    'message'    => $message,
                    'template_name' => $tmpl,
                    'template_url'  => '/' . $tmpl,
                ]));
                return response($html, 404)->contentType('text/html');
            }
        }

        // 没有可用模板时返回最简 404
        return response($message, 404)->contentType('text/html');
    }
}
