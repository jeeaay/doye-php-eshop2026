<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\model\TemplateFile;
use app\common\service\SettingService;
use app\common\service\TemplateManager;
use app\common\support\AppContext;
use think\facade\View;

/**
 * 模板管理（平台超管专用）
 *
 * 模板列表、文件扫描、切换模板、查看文件内容。
 */
class Template extends AdminBaseController
{
    /**
     * 模板管理首页
     */
    public function index()
    {
        $this->assertSuper();
        $this->assignActiveMenu('template');

        $manager = new TemplateManager();
        $activeTemplate = $manager->activeTemplate();
        $templates = $manager->listTemplates();

        // 从数据库补充文件状态
        foreach ($templates as &$tpl) {
            $files = TemplateFile::where('template', $tpl['name'])->where('lang', 'base')->count();
            $tpl['db_files'] = (int) $files;
            $tpl['is_active'] = $tpl['name'] === $activeTemplate;
            // 统计翻译版本
            $tpl['translation_count'] = TemplateFile::where('template', $tpl['name'])->where('lang', '<>', 'base')->count();
        }
        unset($tpl);

        View::assign([
            'templates'      => $templates,
            'active_template' => $activeTemplate,
            'scan_dir'       => $manager->templatesRootPath(),
        ]);

        return View::fetch();
    }

    /**
     * 触发扫描（AJAX）
     */
    public function scan()
    {
        try {
            $this->assertSuper();
            $template = trim((string) $this->request->post('template', ''));
            $manager = new TemplateManager();
            $result = $manager->scan($template !== '' ? $template : null);
            return json(['code' => 0, 'message' => '扫描完成', 'data' => $result]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 切换当前模板（AJAX）
     */
    public function setActive()
    {
        try {
            $this->assertSuper();
            $template = trim((string) $this->request->post('template', ''));
            $manager = new TemplateManager();

            if ($template !== 'none' && !$manager->templateExists($template)) {
                throw new BizException("模板不存在：{$template}");
            }

            (new SettingService())->save('basic', [
                'site.template' => $template,
            ]);

            // 清理 runtime 缓存，确保立即生效
            $this->clearRuntime();

            $label = $template === 'none' ? '无前台模板（纯 API 站）' : $template;
            return json(['code' => 0, 'message' => "已切换到 {$label}", 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 模板文件列表（AJAX，供前端拉取）
     */
    public function files()
    {
        try {
            $this->assertSuper();
            $template = trim((string) $this->request->get('template', ''));
            if ($template === '') {
                throw new BizException('请选择模板');
            }

            $lang = trim((string) $this->request->get('lang', 'base'));
            $query = TemplateFile::where('template', $template);
            if ($lang !== '') {
                $query->where('lang', $lang);
            }
            $list = $query->order('path', 'asc')->select();

            return json(['code' => 0, 'message' => '', 'data' => $list]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 查看单个文件内容（AJAX）
     */
    public function fileContent()
    {
        try {
            $this->assertSuper();
            $template = trim((string) $this->request->get('template', ''));
            $path = trim((string) $this->request->get('path', ''));
            $lang = trim((string) $this->request->get('lang', 'base'));

            if ($template === '' || $path === '') {
                throw new BizException('参数不完整');
            }

            $manager = new TemplateManager();
            $content = $manager->fileContent($template, $path, $lang);
            if ($content === null) {
                throw new BizException('文件不存在');
            }

            return json(['code' => 0, 'message' => '', 'data' => ['content' => $content]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 仅平台超管可访问
     */
    private function assertSuper(): void
    {
        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            throw new BizException('仅平台超级管理员可访问');
        }
    }

    /**
     * 清理 runtime 目录下的编译缓存
     */
    private function clearRuntime(): void
    {
        $runtime = app()->getRuntimePath();
        foreach (['temp', 'cache'] as $dir) {
            $path = $runtime . $dir;
            if (is_dir($path)) {
                array_map('unlink', glob($path . DIRECTORY_SEPARATOR . '*.php') ?: []);
            }
        }
    }
}
