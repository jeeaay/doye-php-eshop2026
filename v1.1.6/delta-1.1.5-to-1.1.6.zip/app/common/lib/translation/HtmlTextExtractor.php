<?php
declare(strict_types=1);

namespace app\common\lib\translation;

/**
 * HTML 文本提取器
 *
 * 从 HTML 模板中提取可翻译的纯文本节点，保护：
 *   - HTML 标签和属性
 *   - ThinkPHP/PHP 标签
 *   - script/style/code 块
 *   - URL、邮箱、纯数字
 *
 * 使用 [[TPLN:N]] 占位符替换可翻译文本，AI 翻译完成后还原。
 */
class HtmlTextExtractor
{
    private const PH_PREFIX = '[[TPLN:';
    private const PH_SUFFIX = ']]';
    private const PROT_PREFIX = '[[PROT:';
    private const PROT_SUFFIX = ']]';

    /**
     * 提取可翻译文本节点
     *
     * @return array{normalized:string, texts:array<int,string>, placeholders:array<string,string>}
     */
    public function extract(string $html): array
    {
        // Step 1: 保护不可翻译的块
        [$html, $protectedBlocks] = $this->protectBlocks($html);

        // Step 2: 分离 HTML 标签和纯文本
        $parts = preg_split('/(<[^>]*>)/', $html) ?: [$html];

        $texts = [];
        $placeholders = [];
        $counter = 0;
        $result = '';

        foreach ($parts as $part) {
            if ($this->isHtmlTag($part)) {
                $result .= $part;
            } else {
                $extracted = $this->processText($part, $counter, $texts, $placeholders);
                $result .= $extracted;
            }
        }

        // Step 3: 还原保护块
        $result = $this->restoreBlocks($result, $protectedBlocks);

        return [
            'normalized'   => $result,
            'texts'        => array_values(array_unique($texts)),
            'placeholders' => $placeholders,
        ];
    }

    /**
     * 基于占位符映射和翻译结果重建 HTML
     *
     * @param array<string,string> $placeholderMap 原始文本 => 占位符
     * @param array<string,string> $translations 原始文本 => 译文
     */
    public function rebuild(string $normalized, array $placeholderMap, array $translations): string
    {
        $phToTranslated = [];
        foreach ($placeholderMap as $original => $placeholder) {
            $phToTranslated[$placeholder] = $translations[$original] ?? $original;
        }

        $result = $normalized;
        foreach ($phToTranslated as $ph => $translated) {
            $result = str_replace($ph, $translated, $result);
        }

        return $result;
    }

    /**
     * 保护 script/style/code 块、ThinkPHP/PHP 标签
     *
     * @return array{0:string,1:array<int,string>}
     */
    private function protectBlocks(string $html): array
    {
        $protected = [];

        // script/style/code/pre 块
        foreach (['script', 'style', 'code', 'pre'] as $tag) {
            $pattern = '/<' . $tag . '\b[^>]*>.*?<\/' . $tag . '>/is';
            $html = preg_replace_callback($pattern, function (array $m) use (&$protected): string {
                $protected[] = $m[0];
                return self::PROT_PREFIX . (count($protected) - 1) . self::PROT_SUFFIX;
            }, $html) ?: $html;
        }

        // ThinkPHP 标签
        $html = preg_replace_callback('/\{[^}]+\}/', function (array $m) use (&$protected): string {
            $protected[] = $m[0];
            return self::PROT_PREFIX . (count($protected) - 1) . self::PROT_SUFFIX;
        }, $html) ?: $html;

        // PHP 标签
        $html = preg_replace_callback('/<\?php.*?\?>/is', function (array $m) use (&$protected): string {
            $protected[] = $m[0];
            return self::PROT_PREFIX . (count($protected) - 1) . self::PROT_SUFFIX;
        }, $html) ?: $html;

        return [$html, $protected];
    }

    /**
     * 还原保护块
     *
     * @param array<int,string> $protected
     */
    private function restoreBlocks(string $html, array $protected): string
    {
        return preg_replace_callback(
            '/\[\[PROT:(\d+)\]\]/',
            function (array $m) use ($protected): string {
                $index = (int) $m[1];
                return $protected[$index] ?? $m[0];
            },
            $html
        ) ?: $html;
    }

    /**
     * 处理一个纯文本段
     *
     * @param array<int,string> $texts
     * @param array<string,string> $placeholders
     */
    private function processText(string $segment, int &$counter, array &$texts, array &$placeholders): string
    {
        if (!$this->containsReadableText($segment) || $this->isPhpOnly($segment)) {
            return $segment;
        }

        $phpTagPattern = '/(\{\:[^}]+\}|\{\$[^}]+\}|\{[a-z]+\}|\{\/[a-z]+\})/';
        $parts = preg_split($phpTagPattern, $segment, -1, PREG_SPLIT_DELIM_CAPTURE);

        if ($parts === false || count($parts) <= 1) {
            $trimmed = trim($segment);
            if ($trimmed !== '' && $this->shouldTranslate($trimmed)) {
                return $this->makePlaceholder($trimmed, $counter, $texts, $placeholders);
            }
            return $segment;
        }

        $result = '';
        foreach ($parts as $part) {
            if (preg_match($phpTagPattern, $part)) {
                $result .= $part;
            } else {
                $trimmed = trim($part);
                if ($trimmed !== '' && $this->shouldTranslate($trimmed)) {
                    $result .= $this->makePlaceholder($trimmed, $counter, $texts, $placeholders);
                } else {
                    $result .= $part;
                }
            }
        }

        return $result;
    }

    /**
     * 为文本创建占位符并登记
     *
     * @param array<int,string> $texts
     * @param array<string,string> $placeholders
     */
    private function makePlaceholder(string $text, int &$counter, array &$texts, array &$placeholders): string
    {
        $ph = self::PH_PREFIX . $counter . self::PH_SUFFIX;
        $texts[] = $text;
        $placeholders[$text] = $ph;
        $counter++;
        return $ph;
    }

    private function containsReadableText(string $text): bool
    {
        $stripped = preg_replace('/[\s\d\p{P}]+/u', '', $text);
        return $stripped !== '';
    }

    private function isPhpOnly(string $text): bool
    {
        return (bool) preg_match('/^\{.+\}$/', trim($text));
    }

    private function shouldTranslate(string $text): bool
    {
        $t = trim($text);
        if (mb_strlen($t) < 2) return false;
        if (preg_match('/^https?:\/\//i', $t)) return false;
        if (preg_match('/^[\w.+-]+@[\w-]+\.[\w.-]+$/', $t)) return false;
        if (preg_match('/^[\d\s\-\.:\/]+$/', $t)) return false;
        if (preg_match('/^[\s\p{P}]+$/u', $t)) return false;
        if (preg_match('/^(&\w+;)+$/', $t)) return false;
        if (str_contains($t, '<') || str_contains($t, '>')) return false;
        return true;
    }

    private function isHtmlTag(string $part): bool
    {
        return str_starts_with($part, '<') && str_ends_with($part, '>');
    }
}
