<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\lib\translation\HtmlTextExtractor;
use app\common\lib\translation\OpenAiCompatibleProvider;
use app\common\model\TemplateFile;
use app\common\model\TranslationJob;
use app\common\support\AppContext;
use think\facade\Db;
use think\facade\Log;

/**
 * 模板翻译服务
 *
 * 核心流程：
 *   1. HtmlTextExtractor 从模板 HTML 提取纯文本节点
 *   2. 文本列表通过 AI provider 翻译
 *   3. 翻译结果还原回 HTML，写入目标语言目录
 *   4. 更新 template_file 表
 */
class TemplateTranslationService
{
    private TemplateManager $templates;
    private HtmlTextExtractor $extractor;

    public function __construct()
    {
        $this->templates = new TemplateManager();
        $this->extractor = new HtmlTextExtractor();
    }

    /**
     * 入队一个模板文件的翻译任务
     *
     * @param string $template 模板名
     * @param string $path 相对路径，如 index.html
     * @param string $targetLang 目标语言代码（ru/zh 等）
     * @param bool $force 强制入队（即使已是最新）
     * @return array<int,int> 新建的 job id
     */
    public function enqueue(string $template, string $path, string $targetLang, bool $force = false): array
    {
        $targetLang = strtolower(trim($targetLang));
        if ($targetLang === '' || $targetLang === base_locale()) {
            return [];
        }

        // 读取源文件
        $sourceHtml = $this->templates->fileContent($template, $path, 'base');
        if ($sourceHtml === null) {
            Log::warning("TemplateTranslation: source not found: {$template}/{$path}");
            return [];
        }

        // 提取文本节点
        $extract = $this->extractor->extract($sourceHtml);
        $texts = array_values(array_unique(array_filter($extract['texts'])));

        // 没有可翻译文本 → 跳过
        if ($texts === []) {
            Log::info("TemplateTranslation: no translatable text: {$template}/{$path}");
            return [];
        }

        // 检查是否已有未完成的任务
        $exists = TranslationJob::where('entity_type', 'template_file')
            ->where('entity_id', 0)
            ->where('source_lang', base_locale())
            ->where('target_lang', $targetLang)
            ->whereJsonContains('fields_json->template', $template)
            ->whereJsonContains('fields_json->path', $path)
            ->whereIn('status', [TranslationJob::STATUS_PENDING, TranslationJob::STATUS_RUNNING])
            ->find();

        if ($exists) {
            return [(int) $exists->id];
        }

        // 检查目标文件是否已是最新
        if (!$force) {
            $targetFile = TemplateFile::where('template', $template)
                ->where('lang', $targetLang)
                ->where('path', $path)
                ->find();

            $baseMd5 = $this->templates->fileMd5(
                $this->templates->absPath($template, $path, 'base') ?? ''
            );
            if ($targetFile && (string) $targetFile->source_hash === $baseMd5) {
                Log::info("TemplateTranslation: already up-to-date: {$template}/{$path} -> {$targetLang}");
                return [];
            }
        }

        // 创建翻译任务
        $sourceHash = md5(json_encode([
            'template' => $template,
            'path'     => $path,
            'texts'    => $texts,
        ], JSON_UNESCAPED_UNICODE));

        $job = new TranslationJob();
        $job->entity_type = 'template_file';
        $job->entity_id = 0;
        $job->source_lang = base_locale();
        $job->target_lang = $targetLang;
        $job->fields_json = [
            'template' => $template,
            'path'     => $path,
            'source'   => [
                'template'        => $template,
                'path'            => $path,
                'source_html'     => $extract['normalized'],
                'texts'           => $texts,
                'placeholders'    => $extract['placeholders'],
                'base_md5'        => $this->templates->fileMd5(
                    $this->templates->absPath($template, $path, 'base') ?? ''
                ),
                'source_hash'     => $sourceHash,
            ],
        ];
        $job->status = TranslationJob::STATUS_PENDING;
        $job->priority = 10; // 模板翻译优先级高于批量实体翻译
        $job->attempts = 0;
        $job->max_attempts = 3;
        $job->created_by = (int) (AppContext::getAdminId() ?? 0);
        $job->save();

        // 推入 Redis 队列
        try {
            \app\common\lib\translation\TranslationQueue::push((int) $job->id, 10);
        } catch (\Throwable $e) {
            Log::error("TemplateTranslation queue push failed: {$e->getMessage()}");
        }

        return [(int) $job->id];
    }

    /**
     * 批量入队：扫描指定模板的修改过的文件
     *
     * @param string $template 模板名，空表示全部
     * @param array<int,string> $targetLangs 目标语言列表
     * @return array{files:int,jobs:int}
     */
    public function enqueueModified(string $template = '', array $targetLangs = []): array
    {
        $manager = new TemplateManager();
        $manager->scan($template !== '' ? $template : null);

        $files = 0;
        $jobs = 0;

        $query = TemplateFile::where('lang', 'base');
        if ($template !== '') {
            $query->where('template', $template);
        }

        foreach ($query->select() as $file) {
            $files++;
            if ($targetLangs === []) {
                // 自动扫描已有翻译目录
                $langs = $this->detectTargetLangs((string) $file->template);
            } else {
                $langs = $targetLangs;
            }

            foreach ($langs as $lang) {
                $jobs += count($this->enqueue((string) $file->template, (string) $file->path, $lang));
            }
        }

        return ['files' => $files, 'jobs' => $jobs];
    }

    /**
     * 执行一个 template_file 类型的翻译任务
     *
     * 由 TranslationJobService::run() 在 entity_type = template_file 时调用。
     *
     * @throws \Throwable
     */
    public function runJob(TranslationJob $job): void
    {
        $fields = (array) $job->fields_json;
        $source = (array) ($fields['source'] ?? []);
        $template = (string) ($fields['template'] ?? '');
        $path = (string) ($fields['path'] ?? '');
        $targetLang = (string) $job->target_lang;

        if ($template === '' || $path === '' || !isset($source['texts'])) {
            throw new \RuntimeException('任务字段不完整');
        }

        $texts = (array) $source['texts'];
        $normalizedHtml = (string) ($source['source_html'] ?? '');
        $placeholders = (array) ($source['placeholders'] ?? []);
        $baseMd5 = (string) ($source['base_md5'] ?? '');

        if ($texts === []) {
            // 没有可翻译文本，直接标记完成
            $job->status = TranslationJob::STATUS_DONE;
            $job->finished_at = date('Y-m-d H:i:s');
            $job->save();
            return;
        }

        // 调用 AI
        $provider = new OpenAiCompatibleProvider((new TranslationJobService())->config());
        $textsAsKeys = [];
        foreach ($texts as $t) {
            $textsAsKeys[$t] = '';
        }

        $result = $provider->translate($textsAsKeys, base_locale(), $targetLang);
        $translatedTexts = (array) ($result['fields'] ?? []);

        // 验证：原文存在但译文为空 → 视为失败
        foreach ($texts as $original) {
            if (!array_key_exists($original, $translatedTexts) || trim((string) $translatedTexts[$original]) === '') {
                // 允许原文保留（AI 可能认为无需翻译）
                $translatedTexts[$original] = $original;
            }
        }

        // 重建 HTML
        $html = $this->extractor->rebuild($normalizedHtml, $placeholders, $translatedTexts);

        // 写入目标语言目录
        $written = $this->templates->writeFile($template, $path, $targetLang, $html);
        if (!$written) {
            throw new \RuntimeException('写入目标文件失败：' . $template . '/' . $targetLang . '/' . $path);
        }

        // 更新 template_file 表
        $absPath = $this->templates->absPath($template, $path, $targetLang) ?? '';
        $md5 = $this->templates->fileMd5($absPath);
        $mtime = $this->templates->fileMtime($absPath);
        $now = date('Y-m-d H:i:s');

        $existing = TemplateFile::where('template', $template)
            ->where('lang', $targetLang)
            ->where('path', $path)
            ->find();

        if ($existing) {
            $existing->md5_hash = $md5;
            $existing->file_mtime = $mtime;
            $existing->source_hash = $baseMd5;
            $existing->translated_at = $now;
            $existing->last_scanned = $now;
            $existing->update_time = $now;
            $existing->save();
        } else {
            $row = new TemplateFile();
            $row->template = $template;
            $row->lang = $targetLang;
            $row->path = $path;
            $row->md5_hash = $md5;
            $row->file_mtime = $mtime;
            $row->source_hash = $baseMd5;
            $row->translated_at = $now;
            $row->last_scanned = $now;
            $row->create_time = $now;
            $row->update_time = $now;
            $row->save();
        }

        // 更新任务状态
        $tokens = $result['usage'] ?? [];
        $price = (float) ((new TranslationJobService())->config()['price_per_1k'] ?? 0.002);
        $cost = (($tokens['prompt_tokens'] ?? 0) + ($tokens['completion_tokens'] ?? 0)) / 1000 * $price;

        $job->status = TranslationJob::STATUS_DONE;
        $job->provider = 'openai-compatible';
        $job->model = (string) ((new TranslationJobService())->config()['model'] ?? '');
        $job->input_chars = mb_strlen(json_encode($texts, JSON_UNESCAPED_UNICODE) ?: '');
        $job->output_chars = mb_strlen(json_encode($translatedTexts, JSON_UNESCAPED_UNICODE) ?: '');
        $job->cost = round($cost, 6);
        $job->error = null;
        $job->finished_at = $now;
        $job->save();

        Log::info("TemplateTranslation done: {$template}/{$path} -> {$targetLang}, cost={$cost}");
    }

    /**
     * 检测模板有哪些目标语言目录
     *
     * @return array<int,string>
     */
    private function detectTargetLangs(string $template): array
    {
        $root = $this->templates->templatesRootPath() . $template;
        if (!is_dir($root)) {
            return [];
        }

        $langs = [];
        foreach (glob($root . DIRECTORY_SEPARATOR . '*', GLOB_ONLYDIR) as $dir) {
            $code = basename($dir);
            if (preg_match('/^[a-z]{2,5}(-[a-z]{2,4})?$/', $code) && $code !== 'base') {
                $langs[] = $code;
            }
        }

        // 同时考虑已启用的语种
        foreach ((new LanguageService())->targetLocales() as $code) {
            if (!in_array($code, $langs, true)) {
                $langs[] = $code;
            }
        }

        return $langs;
    }
}
