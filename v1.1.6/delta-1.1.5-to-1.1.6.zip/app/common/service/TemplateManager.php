<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\model\TemplateFile;

/**
 * 模板管理器：模板发现、路径解析、文件扫描
 *
 * 模板根目录：templates/
 * 静态资源目录：public/{template}/
 */
class TemplateManager
{
    /** 模板根目录相对项目根的路径 */
    private const TEMPLATES_DIR = 'templates';

    /** 模板支持的文件后缀 */
    private const SUFFIX = '.html';

    /**
     * 项目根目录
     */
    public function root(): string
    {
        return app()->getBasePath() . '..' . DIRECTORY_SEPARATOR;
    }

    /**
     * 模板源文件根目录绝对路径
     */
    public function templatesRootPath(): string
    {
        return $this->root() . self::TEMPLATES_DIR . DIRECTORY_SEPARATOR;
    }

    /**
     * 模板静态资源根目录绝对路径（public 下）
     */
    public function publicRootPath(string $template): string
    {
        return $this->root() . 'public' . DIRECTORY_SEPARATOR . $template . DIRECTORY_SEPARATOR;
    }

    /**
     * 当前启用的模板名（含校验）
     */
    public function activeTemplate(): string
    {
        $name = strtolower(trim((string) site_config('site.template', 'almi2026')));
        if ($name === '' || $name === 'none') {
            return 'none';
        }
        if (!$this->templateExists($name)) {
            return 'none';  // 配置了不存在的模板，降级为无
        }
        return $name;
    }

    /**
     * 是否无前台模板
     */
    public function isNoTemplate(): bool
    {
        return $this->activeTemplate() === 'none';
    }

    /**
     * 检查模板是否存在（磁盘上有目录且至少有一个 html 文件）
     */
    public function templateExists(string $template): bool
    {
        if ($template === '' || $template === 'none') {
            return false;
        }
        $path = $this->templatesRootPath() . $template;
        if (!is_dir($path)) {
            return false;
        }
        // 至少有一个 .html 文件
        return (bool) glob($path . DIRECTORY_SEPARATOR . '*.html')
            || is_dir($path . DIRECTORY_SEPARATOR . 'layout');
    }

    /**
     * 扫描磁盘，返回所有可用模板
     *
     * @return array<int, array{name:string, files:int, langs:array<int,string>}>
     */
    public function listTemplates(): array
    {
        $root = $this->templatesRootPath();
        if (!is_dir($root)) {
            return [];
        }

        $templates = [];
        foreach (glob($root . '*', GLOB_ONLYDIR) as $dir) {
            $name = basename($dir);
            if ($name === '' || $name[0] === '.') {
                continue;
            }

            $langs = ['base'];
            foreach (glob($dir . DIRECTORY_SEPARATOR . '*', GLOB_ONLYDIR) as $subDir) {
                $langCode = basename($subDir);
                // 排除模板内部结构目录
                if (in_array($langCode, ['layout', 'inc', 'partials', 'components', 'includes'], true)) {
                    continue;
                }
                if ($this->isValidLangCode($langCode)) {
                    $langs[] = $langCode;
                }
            }

            $fileCount = count($this->scanHtmlFiles($dir));

            $templates[] = [
                'name'  => $name,
                'files' => $fileCount,
                'langs' => array_values(array_unique($langs)),
            ];
        }

        usort($templates, static fn (array $a, array $b) => strcmp($a['name'], $b['name']));
        return $templates;
    }

    /**
     * 解析视图文件的绝对路径
     *
     * 查找顺序：templates/{template}/{locale}/{view}
     *         → templates/{template}/{view}
     *
     * @param string $view 视图名，如 "index.html" 或 "layout/base.html"
     * @return string|null 绝对路径，找不到返回 null
     */
    public function resolveView(string $template, string $view, string $locale = ''): ?string
    {
        if ($template === '' || $template === 'none') {
            return null;
        }

        $root = $this->templatesRootPath() . $template . DIRECTORY_SEPARATOR;
        $view = ltrim($view, '/\\');

        // 1. 优先：语言子目录
        $locale = strtolower(trim($locale));
        if ($locale !== '' && $this->isValidLangCode($locale)) {
            $localePath = $root . $locale . DIRECTORY_SEPARATOR . $view;
            if (is_file($localePath)) {
                return $localePath;
            }
        }

        // 2. 回退：直接在模板根下
        $fallback = $root . $view;
        if (is_file($fallback)) {
            return $fallback;
        }

        return null;
    }

    /**
     * 获取文件内容
     */
    public function fileContent(string $template, string $path, string $lang = 'base'): ?string
    {
        $absPath = $this->absPath($template, $path, $lang);
        if ($absPath === null) {
            return null;
        }
        return file_get_contents($absPath) ?: null;
    }

    /**
     * 计算文件 md5
     */
    public function fileMd5(string $absPath): string
    {
        if (!is_file($absPath)) {
            return '';
        }
        return md5_file($absPath) ?: '';
    }

    /**
     * 文件最后修改时间
     */
    public function fileMtime(string $absPath): ?string
    {
        if (!is_file($absPath)) {
            return null;
        }
        $ts = filemtime($absPath);
        return $ts ? date('Y-m-d H:i:s', $ts) : null;
    }

    /**
     * 扫描模板目录，更新 database 中的 template_file 表
     *
     * @param string|null $template 指定模板名，null 扫描全部
     * @return array{scanned:int, added:int, updated:int, removed:int}
     */
    public function scan(?string $template = null): array
    {
        $now = date('Y-m-d H:i:s');
        $scanned = 0;
        $added = 0;
        $updated = 0;
        $removed = 0;

        $templates = $template ? [$template] : array_column($this->listTemplates(), 'name');

        foreach ($templates as $tplName) {
            $root = $this->templatesRootPath() . $tplName;
            if (!is_dir($root)) {
                continue;
            }

            // 扫描 base 文件（直接在模板根下和 layout/ 等子目录）
            $baseFiles = $this->scanHtmlFiles($root);
            foreach ($baseFiles as $filePath) {
                $relPath = $this->relativePath($root, $filePath);
                $scanned++;
                $hash = $this->fileMd5($filePath);
                $mtime = $this->fileMtime($filePath);

                $existing = TemplateFile::where('template', $tplName)
                    ->where('lang', 'base')
                    ->where('path', $relPath)
                    ->find();

                if ($existing) {
                    if ((string) $existing->md5_hash !== $hash) {
                        $updated++;
                    }
                    $existing->md5_hash = $hash;
                    $existing->file_mtime = $mtime;
                    $existing->last_scanned = $now;
                    $existing->update_time = $now;
                    $existing->save();
                } else {
                    $added++;
                    $row = new TemplateFile();
                    $row->template = $tplName;
                    $row->lang = 'base';
                    $row->path = $relPath;
                    $row->md5_hash = $hash;
                    $row->file_mtime = $mtime;
                    $row->last_scanned = $now;
                    $row->create_time = $now;
                    $row->update_time = $now;
                    $row->save();
                }
            }

            // 扫描语言子目录
            foreach (glob($root . DIRECTORY_SEPARATOR . '*', GLOB_ONLYDIR) as $subDir) {
                $langCode = basename($subDir);
                if (!$this->isValidLangCode($langCode)) {
                    continue;
                }
                $subFiles = $this->scanHtmlFiles($subDir);
                foreach ($subFiles as $filePath) {
                    $relPath = $this->relativePath($subDir, $filePath);
                    $scanned++;
                    $hash = $this->fileMd5($filePath);
                    $mtime = $this->fileMtime($filePath);

                    // 查找对应的 base 版本 md5
                    $baseFile = TemplateFile::where('template', $tplName)
                        ->where('lang', 'base')
                        ->where('path', $relPath)
                        ->find();
                    $sourceHash = $baseFile ? (string) $baseFile->md5_hash : '';

                    $existing = TemplateFile::where('template', $tplName)
                        ->where('lang', $langCode)
                        ->where('path', $relPath)
                        ->find();

                    if ($existing) {
                        if ((string) $existing->md5_hash !== $hash) {
                            $updated++;
                        }
                        $existing->md5_hash = $hash;
                        $existing->file_mtime = $mtime;
                        $existing->source_hash = $sourceHash;
                        $existing->last_scanned = $now;
                        $existing->update_time = $now;
                        $existing->save();
                    } else {
                        $added++;
                        $row = new TemplateFile();
                        $row->template = $tplName;
                        $row->lang = $langCode;
                        $row->path = $relPath;
                        $row->md5_hash = $hash;
                        $row->file_mtime = $mtime;
                        $row->source_hash = $sourceHash;
                        $row->last_scanned = $now;
                        $row->create_time = $now;
                        $row->update_time = $now;
                        $row->save();
                    }
                }
            }
        }

        return [
            'scanned' => $scanned,
            'added'   => $added,
            'updated' => $updated,
            'removed' => $removed,
        ];
    }

    /**
     * 扫描目录下所有 html 文件（递归）
     *
     * @return array<int,string>
     */
    private function scanHtmlFiles(string $dir): array
    {
        $files = [];
        if (!is_dir($dir)) {
            return $files;
        }

        // 顶层 html
        foreach (glob($dir . DIRECTORY_SEPARATOR . '*.html') as $f) {
            if (is_file($f)) {
                $files[] = $f;
            }
        }

        // layout/ inc/ 等子目录
        foreach (glob($dir . DIRECTORY_SEPARATOR . '*', GLOB_ONLYDIR) as $sub) {
            foreach ($this->scanHtmlFiles($sub) as $f) {
                $files[] = $f;
            }
        }

        return $files;
    }

    /**
     * 获取绝对路径，校验目录穿越
     */
    public function absPath(string $template, string $path, string $lang = 'base'): ?string
    {
        if ($this->isPathTraversal($path)) {
            return null;
        }
        if ($template === '' || $template === 'none') {
            return null;
        }
        if ($this->isPathTraversal($template)) {
            return null;
        }

        $root = $this->templatesRootPath() . $template . DIRECTORY_SEPARATOR;
        $langDir = $lang !== 'base' && $this->isValidLangCode($lang) ? $lang . DIRECTORY_SEPARATOR : '';
        $absPath = $root . $langDir . ltrim($path, '/\\');

        // 再次校验：确保路径仍在模板根下
        $realpath = realpath(dirname($absPath));
        if ($realpath === false || !str_starts_with($realpath, realpath($root))) {
            return null;
        }

        return $absPath;
    }

    /**
     * 写入文件（自动创建目录）
     */
    public function writeFile(string $template, string $path, string $lang, string $content): bool
    {
        $absPath = $this->absPath($template, $path, $lang);
        if ($absPath === null) {
            return false;
        }

        $dir = dirname($absPath);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        return (bool) file_put_contents($absPath, $content);
    }

    /**
     * 从完整路径计算相对于 $root 的相对路径
     */
    private function relativePath(string $root, string $fullPath): string
    {
        $root = rtrim($root, '/\\') . DIRECTORY_SEPARATOR;
        $rel = str_replace($root, '', $fullPath);
        return str_replace('\\', '/', $rel);
    }

    /**
     * 路径穿越检查
     */
    private function isPathTraversal(string $path): bool
    {
        return str_contains($path, '..') || str_contains($path, "\0");
    }

    /**
     * 校验语言代码（仅允许字母+短横线）
     */
    private function isValidLangCode(string $code): bool
    {
        return (bool) preg_match('/^[a-z]{2,5}(-[a-z]{2,4})?$/', strtolower($code));
    }
}
