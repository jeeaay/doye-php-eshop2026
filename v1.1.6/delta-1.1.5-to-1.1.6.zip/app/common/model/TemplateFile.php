<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 模板文件元数据
 *
 * 追踪模板文件的 md5、修改时间、翻译状态，
 * 支撑后台模板管理界面和 AI 翻译变更检测。
 */
class TemplateFile extends BaseModel
{
    protected $name = 'template_file';

    protected $autoWriteTimestamp = 'datetime';

    /**
     * base 表示源文件；其他为语言代码（ru/zh 等）
     */
    public const LANG_BASE = 'base';
}
