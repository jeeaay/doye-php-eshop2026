/*
 * 前台页面逻辑（Alpine 组件）
 *
 * 全部对接 PHP 后台已有接口（见 store.js 顶部映射表）：
 *  商品详情  -> 服务端渲染 + 本文件的 SKU 选择/加购
 *  登录      -> /api/site/auth/*
 *  结算      -> /api/order/checkout + /api/order/pay
 *  心愿单    -> localStorage（后台无收藏表，见 todo.md）
 */
(function () {
  function productData() {
    var el = document.querySelector('main[data-product]');
    if (!el) { return null; }
    try { return JSON.parse(el.dataset.product); } catch (e) { return null; }
  }

  /* ---------------- 商品详情 ---------------- */
  window.productDetail = function () {
    var product = productData() || { skus: [] };
    var skus = product.skus || [];

    return {
      quantity: 1,
      skus: skus,
      selectedSkuId: skus.length ? skus[0].id : 0,
      detailsOpen: true,
      specsOpen: false,
      shippingOpen: false,
      reviewsOpen: false,
      adding: false,
      added: false,

      init() {},

      get selectedSku() {
        var id = this.selectedSkuId;
        return this.skus.find(function (s) { return String(s.id) === String(id); }) || null;
      },
      get inStock() {
        var sku = this.selectedSku;
        return !sku || sku.stock > 0;
      },
      selectSku(id) {
        this.selectedSkuId = id;
      },
      priceOf(id) {
        var sku = this.skus.find(function (s) { return String(s.id) === String(id); });
        return sku ? sku.price : '';
      },
      async addToCart() {
        if (!this.selectedSkuId) { return; }
        this.adding = true;
        try {
          await StoreCart.add(this.selectedSkuId, this.quantity);
          this.added = true;
          StoreUI.toast('Added to basket', 'success');
          setTimeout(() => { this.added = false; }, 2000);
        } catch (e) {
          if (e.message !== 'Please sign in first') { StoreUI.toast(e.message, 'error'); }
        } finally {
          this.adding = false;
        }
      },
      async buyNow() {
        if (!this.selectedSkuId) { return; }
        try {
          await StoreCart.add(this.selectedSkuId, this.quantity);
          window.location.href = '/checkout';
        } catch (e) {
          if (e.message !== 'Please sign in first') { StoreUI.toast(e.message, 'error'); }
        }
      },
      toggle() {}
    };
  };

  window.wishlistButton = function () {
    var product = productData();
    return {
      active: false,
      init() {
        if (product) { this.active = StoreWishlist.has(product.id); }
      },
      toggle() {
        if (!product) { return; }
        this.active = StoreWishlist.toggle({
          id: product.id,
          name: product.name,
          price: StoreAPI.currency() + product.price,
          image: product.image,
          url: product.url
        });
        StoreUI.toast(this.active ? 'Added to wishlist' : 'Removed from wishlist', 'info');
      }
    };
  };

  /* ---------------- 登录 ---------------- */
  window.loginPage = function () {
    return {
      step: 'email',
      email: '',
      code: '',
      error: '',
      sending: false,
      verifying: false,
      countdown: 0,
      _timer: null,

      init() {
        var params = new URLSearchParams(window.location.search);
        var email = params.get('email');
        if (email) { this.email = email; }
        if (StoreAuth.isLoggedIn()) { window.location.href = this.redirectTo(); }
      },

      redirectTo() {
        var params = new URLSearchParams(window.location.search);
        return params.get('redirect') || '/account';
      },

      startCountdown() {
        this.countdown = 60;
        clearInterval(this._timer);
        this._timer = setInterval(() => {
          this.countdown -= 1;
          if (this.countdown <= 0) { clearInterval(this._timer); }
        }, 1000);
      },

      async sendCode() {
        this.error = '';
        if (!this.email) { this.error = 'Please enter your email'; return; }
        this.sending = true;
        try {
          var res = await StoreAuth.sendCode(this.email);
          this.step = 'code';
          this.startCountdown();
          if (res && res.dev_code) {
            this.code = res.dev_code;
            StoreUI.toast('Dev mode code: ' + res.dev_code, 'info');
          } else {
            StoreUI.toast('Verification code sent', 'success');
          }
        } catch (e) {
          this.error = e.message;
        } finally {
          this.sending = false;
        }
      },

      async verifyCode() {
        this.error = '';
        if (this.code.length !== 6) { this.error = 'Enter the 6-digit code'; return; }
        this.verifying = true;
        try {
          await StoreAuth.verifyCode(this.email, this.code);
          window.location.href = this.redirectTo();
        } catch (e) {
          this.error = e.message;
        } finally {
          this.verifying = false;
        }
      }
    };
  };

  /* ---------------- 结算 ---------------- */
  window.checkoutAuth = function () {
    return {
      isLoggedIn: false,
      email: '',
      code: '',
      authStep: 1,
      authError: '',
      sending: false,
      verifying: false,
      countdown: 0,
      _timer: null,

      addresses: [],
      loadingAddresses: true,
      selectedAddressId: 0,
      showAddForm: false,
      newAddress: { name: '', phone: '', address_detail: '', is_default: false },
      addressError: '',
      savingAddress: false,

      submitting: false,
      payChannel: 'paypal',
      channels: [],
      toast: { visible: false, message: '', type: 'info' },
      _toastTimer: null,

      async init() {
        this.isLoggedIn = StoreAuth.isLoggedIn();
        if (!this.isLoggedIn) {
          this.loadingAddresses = false;
          this.renderGuestNotice();
          return;
        }
        await Promise.all([this.fetchAddresses(), this.fetchChannels()]);
        CartPage.mount(this);
      },

      renderGuestNotice() {
        var host = document.getElementById('cart-items');
        if (host) {
          host.innerHTML = '<p class="cart-empty-hint">Please sign in to check out.</p>';
        }
      },

      async fetchChannels() {
        try {
          var list = await StoreOrders.channels();
          this.channels = (list || []).map(function (c) { return { code: c.code, name: c.name }; });
          if (this.channels.length) { this.payChannel = this.channels[0].code; }
        } catch (e) { /* 渠道接口不可用时保留下单，支付页会提示 */ }
      },

      async fetchAddresses() {
        this.loadingAddresses = true;
        try {
          var list = await StoreAddress.list();
          this.addresses = (list || []).map(function (a) {
            return {
              id: a.id,
              name: a.name,
              phone: a.phone,
              street: a.address_detail,
              is_default: !!Number(a.is_default)
            };
          });
          var def = this.addresses.find(function (a) { return a.is_default; });
          if (def) { this.selectedAddressId = def.id; }
          else if (this.addresses.length) { this.selectedAddressId = this.addresses[0].id; }
          if (!this.addresses.length) { this.showAddForm = true; }
        } catch (e) {
          this.authError = e.message;
        } finally {
          this.loadingAddresses = false;
        }
      },

      formatCity(addr) { return addr.city || ''; },

      selectedAddress() {
        var id = this.selectedAddressId;
        return this.addresses.find(function (a) { return String(a.id) === String(id); }) || null;
      },

      formatSelectedAddress() {
        var a = this.selectedAddress();
        if (!a) { return ''; }
        return [a.name, a.street, a.phone].filter(Boolean).join(', ');
      },

      async saveNewAddress() {
        this.addressError = '';
        var f = this.newAddress;
        if (!f.name || !f.street) { this.addressError = 'Name and address are required'; return; }
        this.savingAddress = true;
        try {
          await StoreAddress.add({
            name: f.name,
            phone: f.phone || '',
            address_detail: f.street,
            is_default: f.is_default ? 1 : 0
          });
          this.showAddForm = false;
          this.newAddress = { name: '', phone: '', address_detail: '', is_default: false };
          await this.fetchAddresses();
          StoreUI.toast('Address saved', 'success');
        } catch (e) {
          this.addressError = e.message;
        } finally {
          this.savingAddress = false;
        }
      },

      async sendCode() {
        this.authError = '';
        this.sending = true;
        try {
          var res = await StoreAuth.sendCode(this.email);
          this.authStep = 2;
          this.startCountdown();
          if (res && res.dev_code) {
            this.code = res.dev_code;
            StoreUI.toast('Dev mode code: ' + res.dev_code, 'info');
          }
        } catch (e) {
          this.authError = e.message;
        } finally {
          this.sending = false;
        }
      },

      startCountdown() {
        this.countdown = 60;
        clearInterval(this._timer);
        this._timer = setInterval(() => {
          this.countdown -= 1;
          if (this.countdown <= 0) { clearInterval(this._timer); }
        }, 1000);
      },

      async verifyCode() {
        this.authError = '';
        this.verifying = true;
        try {
          await StoreAuth.verifyCode(this.email, this.code);
          this.isLoggedIn = true;
          await this.fetchAddresses();
          CartPage.mount(this);
        } catch (e) {
          this.authError = e.message;
        } finally {
          this.verifying = false;
        }
      },

      async submitOrder() {
        var items = CartPage.selectedItems();
        if (!items.length) { StoreUI.toast('Your basket is empty', 'error'); return; }
        if (!this.selectedAddressId) { StoreUI.toast('Please choose a delivery address', 'error'); return; }
        this.submitting = true;
        try {
          var order = await StoreOrders.checkout({
            items: items,
            address_id: this.selectedAddressId,
            remark: '',
            pay_channel: this.payChannel
          });
          var pay = await StoreOrders.pay(order.order_pay_id, this.payChannel);
          if (pay && pay.type === 'redirect' && pay.url) {
            window.location.href = pay.url;
            return;
          }
          if (pay && pay.h5_url) { window.location.href = pay.h5_url; return; }
          window.location.href = '/order-success?pay_id=' + encodeURIComponent(order.order_pay_id);
        } catch (e) {
          StoreUI.toast(e.message, 'error');
        } finally {
          this.submitting = false;
        }
      },

      showToast(message, type) {
        this.toast = { visible: true, message: message, type: type || 'info' };
        clearTimeout(this._toastTimer);
        this._toastTimer = setTimeout(() => { this.toast.visible = false; }, 3000);
      },
      hideToast() { this.toast.visible = false; }
    };
  };

  /* ---------------- 心愿单 ---------------- */
  window.wishlistApp = function () {
    return {
      items: [],
      loading: false,
      error: '',
      init() {
        this.items = StoreWishlist.items().map(function (i) {
          return { product: { id: i.id, name: i.name, amount: i.price, image: i.image, url: i.url } };
        });
      },
      formatPrice(v) { return v || ''; },
      removeWishlist(id) {
        StoreWishlist.remove(id);
        this.items = this.items.filter(function (i) { return String(i.product.id) !== String(id); });
      },
      addToCart(id) {
        StoreUI.toast('Choose options on the product page', 'info');
        window.location.href = '/products/' + id;
      }
    };
  };

  /* ---------------- 退出登录 ---------------- */
  window.logoutPage = function () {
    return {
      countdown: 3,
      init() {
        StoreAuth.logout().then(() => {
          var timer = setInterval(() => {
            this.countdown -= 1;
            if (this.countdown <= 0) {
              clearInterval(timer);
              window.location.href = '/';
            }
          }, 1000);
        });
      }
    };
  };
})();