/*
 * 购物车页面渲染（cart.html / checkout.html 共用）
 *
 * 数据源：GET /api/cart/list -> { groups: [{ merchant, items: [...] }] }
 * PHP 后台购物车是「用户 + SKU」模型，条目 id 为 cart_item.id，数量修改用 /api/cart/update。
 */
var CartPage = (function () {
  var state = {
    groups: [],
    items: [],
    scope: null,
    loading: true
  };

  function currency() { return StoreAPI.currency(); }

  function money(value) {
    return currency() + (parseFloat(value || 0)).toFixed(2);
  }

  function host() {
    return document.querySelector('.cart-items-list') || document.getElementById('cart-items');
  }

  function subtotal() {
    return state.items.reduce(function (sum, item) {
      return sum + (item.selected ? parseFloat(item.price) * item.quantity : 0);
    }, 0);
  }

  function renderItems() {
    var el = host();
    if (!el) { return; }
    if (!state.items.length) {
      el.innerHTML = '<p class="cart-empty-hint" style="padding:32px 0;">Your basket is empty. '
        + '<a href="/products">Continue shopping</a></p>';
      return;
    }

    el.innerHTML = state.items.map(function (item) {
      return ''
        + '<div class="cart-item" data-id="' + item.id + '" style="display:flex;gap:16px;padding:16px 0;border-bottom:1px solid #eee;align-items:center;">'
        + '  <div class="cart-item__media" style="width:88px;flex:0 0 88px;">'
        + (item.main_image ? '<img src="' + item.main_image + '" alt="" style="width:88px;height:88px;object-fit:cover;">' : '')
        + '  </div>'
        + '  <div class="cart-item__body" style="flex:1;">'
        + '    <p class="cart-item__title" style="margin:0 0 4px;font-weight:600;">' + escapeHtml(item.product_title) + '</p>'
        + '    <p class="cart-item__spec" style="margin:0;color:#777;font-size:13px;">' + escapeHtml(item.spec_name || '') + '</p>'
        + '  </div>'
        + '  <div class="cart-item__qty" style="display:flex;align-items:center;gap:6px;">'
        + '    <button type="button" class="qty-btn" data-action="dec" aria-label="Decrease">&minus;</button>'
        + '    <input type="number" class="qty-input" value="' + item.quantity + '" min="1" style="width:52px;text-align:center;">'
        + '    <button type="button" class="qty-btn" data-action="inc" aria-label="Increase">+</button>'
        + '  </div>'
        + '  <div class="cart-item__price" style="width:90px;text-align:right;">' + money(parseFloat(item.price) * item.quantity) + '</div>'
        + '  <button type="button" class="btn-link" data-action="remove" style="color:#b3261e;">Remove</button>'
        + '</div>';
    }).join('');

    bindItems(el);
    updateTotals();
  }

  function bindItems(el) {
    el.querySelectorAll('.cart-item').forEach(function (row) {
      var id = parseInt(row.dataset.id, 10);
      var input = row.querySelector('.qty-input');

      row.querySelector('[data-action="dec"]').addEventListener('click', function () {
        var item = find(id);
        if (item && item.quantity > 1) { updateQty(id, item.quantity - 1); }
      });
      row.querySelector('[data-action="inc"]').addEventListener('click', function () {
        var item = find(id);
        if (item) { updateQty(id, item.quantity + 1); }
      });
      input.addEventListener('change', function () {
        var qty = Math.max(1, parseInt(input.value, 10) || 1);
        updateQty(id, qty);
      });
      row.querySelector('[data-action="remove"]').addEventListener('click', function () {
        remove(id);
      });
    });
  }

  function find(id) {
    return state.items.find(function (i) { return String(i.id) === String(id); });
  }

  async function updateQty(id, quantity) {
    try {
      await StoreCart.update(id, { quantity: quantity });
      var item = find(id);
      if (item) { item.quantity = quantity; }
      renderItems();
    } catch (e) {
      StoreUI.toast(e.message, 'error');
    }
  }

  async function remove(id) {
    try {
      await StoreCart.remove([id]);
      state.items = state.items.filter(function (i) { return String(i.id) !== String(id); });
      renderItems();
    } catch (e) {
      StoreUI.toast(e.message, 'error');
    }
  }

  function updateTotals() {
    var goods = subtotal();
    ['cart-subtotal', 'cart-total', 'cart-payable'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) { el.textContent = money(goods); }
    });

    var empty = document.querySelector('.empty-cart');
    var layout = document.querySelector('.cart-layout');
    if (empty && layout) {
      var isEmpty = state.items.length === 0;
      empty.style.display = isEmpty ? '' : 'none';
      layout.style.display = isEmpty ? 'none' : '';
    }
  }

  function escapeHtml(str) {
    return String(str || '').replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  async function load() {
    state.loading = true;
    try {
      var data = await StoreCart.list();
      state.groups = (data && data.groups) || [];
      state.items = [];
      state.groups.forEach(function (group) {
        (group.items || []).forEach(function (item) {
          state.items.push({
            id: item.id,
            sku_id: item.sku_id,
            product_title: item.product_title,
            spec_name: item.spec_name,
            price: item.price,
            quantity: parseInt(item.quantity, 10) || 1,
            main_image: item.main_image,
            stock: item.stock,
            selected: !!Number(item.selected)
          });
        });
      });
    } catch (e) {
      /* 未登录时静默展示空购物车 */
      state.items = [];
    } finally {
      state.loading = false;
      renderItems();
      StoreCart.notify();
    }
  }

  return {
    mount: function (scope) {
      state.scope = scope;
      load();
    },
    reload: load,
    selectedItems: function () {
      return state.items
        .filter(function (i) { return i.selected; })
        .map(function (i) { return { sku_id: i.sku_id, quantity: i.quantity }; });
    },
    items: function () { return state.items; }
  };
})();

window.CartPage = CartPage;

document.addEventListener('DOMContentLoaded', function () {
  var isCheckout = document.querySelector('main[data-checkout]');
  if (!isCheckout && (document.querySelector('.cart-items-list') || document.getElementById('cart-items'))) {
    CartPage.mount(null);
  }
});