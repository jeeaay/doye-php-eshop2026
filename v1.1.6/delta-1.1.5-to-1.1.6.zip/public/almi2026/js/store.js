/*
 * 独立站前台 API 客户端
 *
 * 对应关系（原 Go 商城 -> PHP 后台）：
 *   GET  /api/auth/me                 -> GET  /api/site/auth/me
 *   POST /api/auth/send-code          -> POST /api/site/auth/send-code
 *   POST /api/auth/verify-code        -> POST /api/site/auth/verify-code
 *   POST /api/auth/sign-out           -> POST /api/site/auth/sign-out
 *   POST /api/cart/add   (product)    -> POST /api/cart/add   (sku_id)
 *   GET  /api/cart/:cart_id           -> GET  /api/cart/list
 *   POST /api/cart/sync               -> POST /api/cart/update | /api/cart/remove
 *   GET  /api/orders                  -> GET  /api/order/list
 *   GET  /api/addresses               -> GET  /api/user/address/list
 * 统一响应包：{ code: 0, message: 'ok', data: ... }
 */
(function () {
  var TOKEN_KEY = 'site_token';

  var StoreAPI = {
    currency: function () {
      return (document.body && document.body.dataset && document.body.dataset.currency) || '$';
    },

    token: function () {
      return localStorage.getItem(TOKEN_KEY) || '';
    },

    setToken: function (token) {
      if (token) {
        localStorage.setItem(TOKEN_KEY, token);
      } else {
        localStorage.removeItem(TOKEN_KEY);
      }
    },

    headers: function (extra) {
      var headers = { Accept: 'application/json' };
      var token = StoreAPI.token();
      if (token) {
        headers.Authorization = 'Bearer ' + token;
      }
      return Object.assign(headers, extra || {});
    },

    request: async function (path, options) {
      options = options || {};
      var init = {
        method: options.method || 'GET',
        headers: StoreAPI.headers(options.body ? { 'Content-Type': 'application/json' } : {}),
        credentials: 'same-origin'
      };
      if (options.body) {
        init.body = JSON.stringify(options.body);
      }

      var res = await fetch(path, init);
      var payload = null;
      try {
        payload = await res.json();
      } catch (e) {
        throw new Error('Server response error');
      }

      if (payload.code === 401 || res.status === 401) {
        StoreAPI.setToken('');
        StoreAuth.emit(false);
        throw new Error('Please sign in first');
      }
      if (payload.code !== 0) {
        throw new Error(payload.message || 'Request failed');
      }
      return payload.data;
    },

    get: function (path) {
      return StoreAPI.request(path, { method: 'GET' });
    },

    post: function (path, body) {
      return StoreAPI.request(path, { method: 'POST', body: body || {} });
    }
  };

  var StoreAuth = {
    _listeners: [],
    _loggedIn: null,

    isLoggedIn: function () {
      return !!StoreAPI.token();
    },

    onChange: function (fn) {
      StoreAuth._listeners.push(fn);
      if (StoreAuth._loggedIn !== null) {
        fn({ loggedIn: StoreAuth._loggedIn });
      }
    },

    emit: function (loggedIn) {
      StoreAuth._loggedIn = loggedIn;
      StoreAuth._listeners.forEach(function (fn) {
        try { fn({ loggedIn: loggedIn }); } catch (e) { /* ignore */ }
      });
      window.dispatchEvent(new CustomEvent('site-auth-changed', { detail: { loggedIn: loggedIn } }));
    },

    /** 校验本地 token 是否仍然有效 */
    check: async function () {
      if (!StoreAPI.token()) {
        StoreAuth.emit(false);
        return null;
      }
      try {
        var user = await StoreAPI.get('/api/site/auth/me');
        StoreAuth.emit(true);
        return user;
      } catch (e) {
        StoreAPI.setToken('');
        StoreAuth.emit(false);
        return null;
      }
    },

    sendCode: function (email) {
      return StoreAPI.post('/api/site/auth/send-code', { email: email });
    },

    verifyCode: async function (email, code) {
      var data = await StoreAPI.post('/api/site/auth/verify-code', { email: email, code: code });
      StoreAPI.setToken(data.token);
      StoreAuth.emit(true);
      return data.user;
    },

    logout: async function () {
      try {
        await StoreAPI.post('/api/site/auth/sign-out', {});
      } catch (e) { /* ignore */ }
      StoreAPI.setToken('');
      StoreAuth.emit(false);
    }
  };

  var StoreCart = {
    /** 购物车商品件数（顶部角标） */
    count: async function () {
      if (!StoreAuth.isLoggedIn()) {
        return 0;
      }
      try {
        var data = await StoreAPI.get('/api/cart/list');
        var total = 0;
        (data.groups || []).forEach(function (group) {
          (group.items || []).forEach(function (item) { total += parseInt(item.quantity, 10) || 0; });
        });
        return total;
      } catch (e) {
        return 0;
      }
    },

    list: async function () {
      if (!StoreAuth.isLoggedIn()) {
        return { groups: [] };
      }
      return StoreAPI.get('/api/cart/list');
    },

    add: async function (skuId, quantity) {
      if (!StoreAuth.isLoggedIn()) {
        var redirect = encodeURIComponent(window.location.pathname + window.location.search);
        window.location.href = '/login?redirect=' + redirect;
        throw new Error('Please sign in first');
      }
      await StoreAPI.post('/api/cart/add', { sku_id: skuId, quantity: quantity || 1 });
      StoreCart.notify();
    },

    update: async function (id, payload) {
      await StoreAPI.post('/api/cart/update', Object.assign({ id: id }, payload));
      StoreCart.notify();
    },

    remove: async function (ids) {
      await StoreAPI.post('/api/cart/remove', { ids: ids });
      StoreCart.notify();
    },

    notify: async function () {
      var count = await StoreCart.count();
      window.dispatchEvent(new CustomEvent('cart-updated', { detail: { count: count } }));
    }
  };

  var StoreOrders = {
    list: function (page, status) {
      return StoreAPI.get('/api/order/list?page=' + (page || 1) + '&status=' + encodeURIComponent(status || 'all'));
    },
    detail: function (id) {
      return StoreAPI.get('/api/order/detail?id=' + id);
    },
    confirm: function (orderId) {
      return StoreAPI.post('/api/order/confirm', { order_id: orderId });
    },
    cancel: function (payId) {
      return StoreAPI.post('/api/order/cancel', { order_pay_id: payId });
    },
    checkout: function (payload) {
      return StoreAPI.post('/api/order/checkout', payload);
    },
    pay: function (payId, channel) {
      return StoreAPI.post('/api/order/pay', { order_pay_id: payId, channel: channel });
    },
    paymentStatus: function (payId) {
      return StoreAPI.get('/api/payment/status?order_pay_id=' + payId);
    },
    channels: function () {
      return StoreAPI.get('/api/payment/channels');
    }
  };

  var StoreAddress = {
    list: function () {
      return StoreAPI.get('/api/user/address/list');
    },
    add: function (payload) {
      return StoreAPI.post('/api/user/address/add', payload);
    },
    update: function (payload) {
      return StoreAPI.post('/api/user/address/update', payload);
    },
    remove: function (id) {
      return StoreAPI.post('/api/user/address/delete', { id: id });
    }
  };

  var StoreUser = {
    profile: function () {
      return StoreAPI.get('/api/user/profile');
    },
    update: function (payload) {
      return StoreAPI.post('/api/user/update', payload);
    }
  };

  var StoreUI = {
    money: function (value) {
      var num = parseFloat(value || 0);
      return StoreAPI.currency() + num.toFixed(2);
    },
    toast: function (message, type) {
      var host = document.getElementById('site-toast');
      if (!host) {
        host = document.createElement('div');
        host.id = 'site-toast';
        host.className = 'site-toast';
        document.body.appendChild(host);
      }
      host.textContent = message;
      host.dataset.type = type || 'info';
      host.classList.add('is-visible');
      clearTimeout(host._timer);
      host._timer = setTimeout(function () { host.classList.remove('is-visible'); }, 3000);
    }
  };

  window.StoreAPI = StoreAPI;
  window.StoreAuth = StoreAuth;
  window.StoreCart = StoreCart;
  window.StoreOrders = StoreOrders;
  window.StoreAddress = StoreAddress;
  window.StoreUser = StoreUser;
  window.StoreUI = StoreUI;
})();