/*
 * 心愿单（浏览器本地存储）
 *
 * 注意：PHP 后台没有 wishlist / 收藏表，原 Go 主题的 wishlist.js 走的是后端接口。
 * 这里降级为 localStorage 实现，只保证前台 UI 可用，不落库、不跨设备同步 —— 见 todo.md「心愿单」。
 */
var StoreWishlist = (function () {
  var KEY = 'site_wishlist';

  function read() {
    try {
      var items = JSON.parse(localStorage.getItem(KEY));
      return Array.isArray(items) ? items : [];
    } catch (e) {
      return [];
    }
  }

  function write(items) {
    localStorage.setItem(KEY, JSON.stringify(items));
    window.dispatchEvent(new CustomEvent('wishlist-updated', { detail: { count: items.length } }));
  }

  return {
    items: read,
    count: function () { return read().length; },
    has: function (id) {
      id = String(id);
      return read().some(function (i) { return String(i.id) === id; });
    },
    add: function (item) {
      var items = read();
      if (!items.some(function (i) { return String(i.id) === String(item.id); })) {
        items.push({
          id: item.id,
          name: item.name || '',
          price: item.price || '',
          image: item.image || '',
          url: item.url || ('/products/' + item.id)
        });
        write(items);
      }
      return items.length;
    },
    remove: function (id) {
      id = String(id);
      write(read().filter(function (i) { return String(i.id) !== id; }));
      return read().length;
    },
    toggle: function (item) {
      if (StoreWishlist.has(item.id)) {
        StoreWishlist.remove(item.id);
        return false;
      }
      StoreWishlist.add(item);
      return true;
    },
    clear: function () { write([]); }
  };
})();

window.StoreWishlist = StoreWishlist;