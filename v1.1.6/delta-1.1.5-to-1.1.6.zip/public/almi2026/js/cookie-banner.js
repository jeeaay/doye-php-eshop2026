/* Cookie 同意横幅（替代原 Go 主题的 layouts/cookie_banner.html + 内联脚本） */
(function () {
  var KEY = 'site_cookie_consent';

  function applyConsent(granted) {
    if (typeof window.gtag === 'function') {
      window.gtag('consent', 'update', {
        ad_storage: granted ? 'granted' : 'denied',
        ad_user_data: granted ? 'granted' : 'denied',
        ad_personalization: granted ? 'granted' : 'denied'
      });
    }
  }

  function show() {
    var el = document.getElementById('cookie-banner');
    if (el) { el.hidden = false; }
  }

  function hide() {
    var el = document.getElementById('cookie-banner');
    if (el) { el.hidden = true; }
  }

  document.addEventListener('DOMContentLoaded', function () {
    var saved = localStorage.getItem(KEY);
    if (!saved) {
      show();
    } else {
      applyConsent(saved === 'granted');
    }

    document.querySelectorAll('[data-cookie-action]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var granted = btn.dataset.cookieAction === 'accept';
        localStorage.setItem(KEY, granted ? 'granted' : 'denied');
        applyConsent(granted);
        hide();
      });
    });
  });

  window.SiteCookieConsent = {
    open: function () { show(); },
    reset: function () { localStorage.removeItem(KEY); show(); }
  };
})();