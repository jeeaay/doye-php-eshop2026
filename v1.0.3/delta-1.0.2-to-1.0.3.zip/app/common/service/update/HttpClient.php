<?php
declare(strict_types=1);

namespace app\common\service\update;

use app\common\exception\BizException;

/**
 * 更新源 HTTP 客户端
 *
 * 站点端访问 Gitee / GitHub 的唯一出口，统一处理：
 * - 优先 curl（可用时），否则回退 allow_url_fopen 的 stream wrapper；
 * - 单次请求超时取 config('update.timeout')，统一 User-Agent；
 * - 跟随 302（两个平台 Release 资产都会 302 到 CDN）；
 * - CA 证书兜底探测（Windows 无 curl.cainfo 时找 Git for Windows 自带的 ca-bundle）；
 * - 下载先写 `<dest>.part` 再 rename，避免半截文件被解压。
 *
 * 安全约定：**绝不关闭 TLS 校验**。探测不到 CA 时不设置 CAINFO（交给系统默认），
 * 而不是 `CURLOPT_SSL_VERIFYPEER = false`。
 *
 * 所有失败统一抛 BizException，消息里带 URL 与 HTTP 状态码，便于运营定位。
 */
class HttpClient
{
    /** 更新器 UA（部分 CDN 对空 UA 会返回 403） */
    private const USER_AGENT = 'doyecart-updater/1.0';

    /** 最大重定向次数 */
    private const MAX_REDIRECTS = 5;

    /** 下载超时下限（秒）：资产可能有十几 MB，8 秒会必然超时 */
    private const DOWNLOAD_TIMEOUT_FLOOR = 300;

    /** 单次请求超时（秒） */
    private int $timeout;

    /** 探测到的 CA 证书文件（null 表示使用系统默认） */
    private ?string $caBundle;

    /** 当前环境是否有 curl 扩展 */
    private bool $hasCurl;

    /**
     * @param int|null $timeout 超时秒数；null 取 config('update.timeout', 8)
     */
    public function __construct(?int $timeout = null)
    {
        $configured = (int) config('update.timeout', 8);
        $this->timeout = $timeout !== null && $timeout > 0 ? $timeout : ($configured > 0 ? $configured : 8);
        $this->hasCurl = function_exists('curl_init');
        $this->caBundle = self::detectCaBundle();
    }

    /**
     * GET 文本内容（清单、签名等小文件）
     *
     * @param string $url     完整地址
     * @param array  $options 支持 headers => string[]（每行形如 "Authorization: Bearer xxx"）
     * @return string 响应体
     * @throws BizException 网络失败或 HTTP >= 400
     */
    public function get(string $url, array $options = []): string
    {
        $headers = $this->buildHeaders($options);
        $u       = self::safeUrl($url);

        if ($this->hasCurl) {
            $ch = curl_init($url);
            if ($ch === false) {
                throw new BizException("请求更新源失败：{$u}（curl 初始化失败）");
            }
            $opts = [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS      => self::MAX_REDIRECTS,
                CURLOPT_CONNECTTIMEOUT => $this->timeout,
                CURLOPT_TIMEOUT        => $this->timeout,
                CURLOPT_USERAGENT      => self::USER_AGENT,
                CURLOPT_HTTPHEADER     => $headers,
                CURLOPT_ENCODING       => '',
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
            ];
            if ($this->caBundle !== null) {
                $opts[CURLOPT_CAINFO] = $this->caBundle;
            }
            curl_setopt_array($ch, $opts);

            $body   = curl_exec($ch);
            $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            $error  = (string) curl_error($ch);

            if ($body === false) {
                throw new BizException("请求更新源失败：{$u}（" . ($error !== '' ? $error : 'curl 执行失败') . '）');
            }
            if ($status >= 400) {
                throw new BizException("请求更新源失败：{$u}（HTTP {$status}）");
            }

            return (string) $body;
        }

        [$body, $status, $error] = $this->streamRequest($url, 'GET', $headers);
        if ($body === null) {
            throw new BizException("请求更新源失败：{$u}（{$error}）");
        }
        if ($status >= 400) {
            throw new BizException("请求更新源失败：{$u}（HTTP {$status}）");
        }

        return $body;
    }

    /**
     * HEAD 探测资产是否存在
     *
     * @param string $url     完整地址
     * @param array  $options 支持 headers
     * @return array{status:int,length:?int}
     * @throws BizException 网络失败（HTTP 4xx/5xx 不抛，交给调用方判断）
     */
    public function head(string $url, array $options = []): array
    {
        $headers = $this->buildHeaders($options);
        $u       = self::safeUrl($url);

        if ($this->hasCurl) {
            $ch = curl_init($url);
            if ($ch === false) {
                throw new BizException("探测更新源失败：{$u}（curl 初始化失败）");
            }
            $opts = [
                CURLOPT_NOBODY         => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS      => self::MAX_REDIRECTS,
                CURLOPT_CONNECTTIMEOUT => $this->timeout,
                CURLOPT_TIMEOUT        => $this->timeout,
                CURLOPT_USERAGENT      => self::USER_AGENT,
                CURLOPT_HTTPHEADER     => $headers,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
            ];
            if ($this->caBundle !== null) {
                $opts[CURLOPT_CAINFO] = $this->caBundle;
            }
            curl_setopt_array($ch, $opts);

            $ok     = curl_exec($ch);
            $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            $length = (int) curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
            $error  = (string) curl_error($ch);

            if ($ok === false) {
                throw new BizException("探测更新源失败：{$u}（" . ($error !== '' ? $error : 'curl 执行失败') . '）');
            }

            return ['status' => $status, 'length' => $length >= 0 ? $length : null];
        }

        [$body, $status, $error, $responseHeaders] = $this->streamRequest($url, 'HEAD', $headers, true);
        if ($body === null && $status === 0) {
            throw new BizException("探测更新源失败：{$u}（{$error}）");
        }

        $length = null;
        foreach ($responseHeaders as $line) {
            if (stripos($line, 'content-length:') === 0) {
                $length = (int) trim(substr($line, strlen('content-length:')));
            }
        }

        return ['status' => $status, 'length' => $length];
    }

    /**
     * 下载资产到本地文件（先写 .part 再 rename）
     *
     * @param string $url     完整地址
     * @param string $dest    目标文件（目录不存在会自动创建）
     * @param array  $options 支持 headers
     * @return void
     * @throws BizException 网络失败、HTTP >= 400 或写盘失败
     */
    public function download(string $url, string $dest, array $options = []): void
    {
        $dir = dirname($dest);
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
            throw new BizException("下载失败：无法创建目录 {$dir}");
        }

        $part = $dest . '.part';
        @unlink($part);
        $headers = $this->buildHeaders($options);
        $u       = self::safeUrl($url);

        try {
            if ($this->hasCurl) {
                $this->downloadByCurl($url, $part, $headers);
            } else {
                $this->downloadByStream($url, $part, $headers);
            }
        } catch (BizException $e) {
            @unlink($part);
            throw $e;
        }

        if (!is_file($part) || (int) filesize($part) === 0) {
            @unlink($part);
            throw new BizException("下载更新资产失败：{$u}（响应内容为空）");
        }
        if (is_file($dest)) {
            @unlink($dest);
        }
        if (!@rename($part, $dest)) {
            @unlink($part);
            throw new BizException("下载更新资产失败：{$u}（无法写入 {$dest}）");
        }
    }

    // ------------------------------------------------------------------
    // 传输实现
    // ------------------------------------------------------------------

    /**
     * @param string[] $headers
     */
    private function downloadByCurl(string $url, string $part, array $headers): void
    {
        $u = self::safeUrl($url);

        $handle = @fopen($part, 'wb');
        if ($handle === false) {
            throw new BizException("下载失败：无法写入 {$part}");
        }

        $ch = curl_init($url);
        if ($ch === false) {
            fclose($handle);
            throw new BizException("下载更新资产失败：{$u}（curl 初始化失败）");
        }

        $opts = [
            CURLOPT_FILE           => $handle,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => self::MAX_REDIRECTS,
            CURLOPT_CONNECTTIMEOUT => $this->timeout,
            CURLOPT_TIMEOUT        => max($this->timeout, self::DOWNLOAD_TIMEOUT_FLOOR),
            CURLOPT_USERAGENT      => self::USER_AGENT,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ];
        if ($this->caBundle !== null) {
            $opts[CURLOPT_CAINFO] = $this->caBundle;
        }
        curl_setopt_array($ch, $opts);

        $ok     = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $error  = (string) curl_error($ch);
        fclose($handle);

        if ($ok === false) {
            throw new BizException("下载更新资产失败：{$u}（" . ($error !== '' ? $error : 'curl 执行失败') . '）');
        }
        if ($status >= 400) {
            throw new BizException("下载更新资产失败：{$u}（HTTP {$status}）");
        }
    }

    /**
     * @param string[] $headers
     */
    private function downloadByStream(string $url, string $part, array $headers): void
    {
        $this->assertUrlFopen();
        $u = self::safeUrl($url);

        $context = $this->streamContext('GET', $headers);
        $remote  = @fopen($url, 'rb', false, $context);
        if ($remote === false) {
            throw new BizException("下载更新资产失败：{$u}（无法建立连接）");
        }
        // PHP 8.5 起 $http_response_header 废弃，改用 http_get_last_response_headers()；
        // 旧版本（<8.5）没有该函数，才回退到作用域内的响应头变量。
        $raw    = function_exists('http_get_last_response_headers')
            ? (array) (http_get_last_response_headers() ?? [])
            : (isset($http_response_header) ? (array) $http_response_header : []);
        $status = $this->statusFromHeaders($raw);
        if ($status >= 400) {
            fclose($remote);
            throw new BizException("下载更新资产失败：{$u}（HTTP {$status}）");
        }

        $local = @fopen($part, 'wb');
        if ($local === false) {
            fclose($remote);
            throw new BizException("下载失败：无法写入 {$part}");
        }
        $copied = @stream_copy_to_stream($remote, $local);
        fclose($remote);
        fclose($local);

        if ($copied === false) {
            throw new BizException("下载更新资产失败：{$u}（读取响应体失败）");
        }
    }

    /**
     * stream wrapper 请求，返回 [body|null, status, error, headers]
     *
     * @param string[] $headers
     * @return array{0:?string,1:int,2:string,3:string[]}
     */
    private function streamRequest(string $url, string $method, array $headers, bool $allowEmptyBody = false): array
    {
        $this->assertUrlFopen();

        $context = $this->streamContext($method, $headers);
        $body    = @file_get_contents($url, false, $context);
        // 同 downloadByStream：PHP 8.5 用新函数取响应头，旧版本回退到局部变量
        $raw     = function_exists('http_get_last_response_headers')
            ? (array) (http_get_last_response_headers() ?? [])
            : (isset($http_response_header) ? (array) $http_response_header : []);
        $status  = $this->statusFromHeaders($raw);
        $error   = error_get_last()['message'] ?? '无法建立连接';

        if ($body === false && !$allowEmptyBody) {
            return [null, $status, $error, $raw];
        }

        return [$body === false ? null : (string) $body, $status, $error, $raw];
    }

    /**
     * @param string[] $headers
     * @return resource
     */
    private function streamContext(string $method, array $headers)
    {
        $ssl = ['verify_peer' => true, 'verify_peer_name' => true];
        if ($this->caBundle !== null) {
            $ssl['cafile'] = $this->caBundle;
        }

        return stream_context_create([
            'http' => [
                'method'          => $method,
                'header'          => implode("\r\n", $headers),
                'timeout'         => $method === 'GET' ? max($this->timeout, self::DOWNLOAD_TIMEOUT_FLOOR) : $this->timeout,
                'follow_location' => 1,
                'max_redirects'   => self::MAX_REDIRECTS,
                'ignore_errors'   => true,
                'user_agent'      => self::USER_AGENT,
            ],
            'ssl'  => $ssl,
        ]);
    }

    /**
     * @param string[] $raw 响应头（重定向时会有多段，取最后一段的状态行）
     */
    private function statusFromHeaders(array $raw): int
    {
        $status = 0;
        foreach ($raw as $line) {
            if (preg_match('#^HTTP/\d(?:\.\d)?\s+(\d{3})#', (string) $line, $m)) {
                $status = (int) $m[1];
            }
        }
        return $status;
    }

    /**
     * 日志 / 异常里展示的 URL：把令牌类查询参数打码
     *
     * 异常消息会写进 site_update.message 并显示在后台，绝不能让 access_token 落库。
     */
    private static function safeUrl(string $url): string
    {
        return (string) preg_replace(
            '/([?&](?:access_token|token|private_token|access_key)=)[^&#]*/i',
            '$1***',
            $url
        );
    }

    private function assertUrlFopen(): void
    {
        if (!filter_var((string) ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOLEAN)) {
            throw new BizException('服务器既没有 curl 扩展，也禁用了 allow_url_fopen，无法访问更新源');
        }
    }

    /**
     * @param array $options
     * @return string[]
     */
    private function buildHeaders(array $options): array
    {
        $headers = [
            'User-Agent: ' . self::USER_AGENT,
            'Accept: application/json, application/octet-stream, text/plain, */*',
        ];
        foreach ((array) ($options['headers'] ?? []) as $line) {
            $line = trim((string) $line);
            if ($line !== '') {
                $headers[] = $line;
            }
        }
        return $headers;
    }

    // ------------------------------------------------------------------
    // CA 探测
    // ------------------------------------------------------------------

    /**
     * 探测可用的 CA 证书包
     *
     * 不探测到就返回 null（使用系统/curl 默认），**绝不**因此关闭校验。
     */
    private static function detectCaBundle(): ?string
    {
        foreach (['curl.cainfo', 'openssl.cafile'] as $iniKey) {
            $value = trim((string) ini_get($iniKey));
            if ($value !== '' && is_file($value)) {
                return str_replace('\\', '/', $value);
            }
        }

        $candidates = [];
        if (DIRECTORY_SEPARATOR === '\\') {
            // Windows 上 PHP 官方包不带 CA，Git for Windows 的这份最可靠
            $roots = array_filter([
                getenv('ProgramFiles') ?: 'C:/Program Files',
                getenv('ProgramW6432') ?: '',
                getenv('ProgramFiles(x86)') ?: 'C:/Program Files (x86)',
            ]);
            foreach ($roots as $root) {
                $root = str_replace('\\', '/', rtrim($root, '/\\'));
                $candidates[] = $root . '/Git/mingw64/etc/ssl/certs/ca-bundle.crt';
                $candidates[] = $root . '/Git/mingw64/ssl/certs/ca-bundle.crt';
                $candidates[] = $root . '/Git/usr/ssl/certs/ca-bundle.crt';
            }
        } else {
            $candidates = [
                '/etc/ssl/certs/ca-certificates.crt',
                '/etc/pki/tls/certs/ca-bundle.crt',
                '/etc/ssl/cert.pem',
            ];
        }

        foreach ($candidates as $path) {
            if (is_file($path)) {
                return $path;
            }
        }

        return null;
    }
}