<?php
use think\migration\Migrator;

/**
 * 商品排序权重查询的复合索引
 *
 * 首页 Latest Arrivals / 商品列表接口已统一按「排序权重倒序」取数：
 *   product: WHERE status=1 [AND ...] ORDER BY sort DESC, id DESC
 * 原先 product 只有 merchant_id/status 与 category_id 等单列索引，
 * 排序阶段需要文件排序；补 (status, sort) 后 InnoDB 倒序扫描即可直接返回
 * （二级索引尾部隐含主键 id，同时满足 sort DESC, id DESC）。
 *
 * home_product 同理：`WHERE status=1 ORDER BY sort ASC, id ASC` 用于首页推荐位，
 * 原先 status / sort 是两个独立索引，补 (status, sort) 走一个索引完成过滤与排序。
 */
class AddProductSortIndexes extends Migrator
{
    /**
     * 执行迁移
     *
     * @return void
     */
    public function up()
    {
        $this->table('product')
            ->addIndex(['status', 'sort'], ['name' => 'idx_status_sort'])
            ->update();

        $this->table('home_product')
            ->addIndex(['status', 'sort'], ['name' => 'idx_status_sort'])
            ->update();
    }

    /**
     * 回滚：删除复合索引
     *
     * @return void
     */
    public function down()
    {
        $this->table('product')
            ->removeIndexByName('idx_status_sort')
            ->update();

        $this->table('home_product')
            ->removeIndexByName('idx_status_sort')
            ->update();
    }
}
