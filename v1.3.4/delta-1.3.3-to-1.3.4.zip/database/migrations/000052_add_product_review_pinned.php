<?php
use think\migration\Migrator;

/**
 * product_review 增加「置顶」能力
 *
 * 首页精选评论（.home-testimonial）只展示 置顶 + 已通过 + 未删除 的评论：
 * - is_pinned=1 表示置顶，后台「评论管理」可单条设置/取消；
 * - pinned_at 记录置顶时间，首页按此倒序展示，取消置顶时清空；
 * - idx_pinned_status(is_pinned, status, pinned_at) 覆盖首页
 *   `WHERE is_pinned=1 AND status=1 ORDER BY pinned_at DESC, id DESC` 的过滤与排序
 *   （InnoDB 二级索引尾部隐含主键 id，倒序扫描即可满足 pinned_at + id 排序）。
 *
 * tinyinteger 不传 limit：写成 tinyint(1) 会被 PDO 当布尔返回，
 * 与 status 等数值列混用时容易出现 1/0 误读。
 */
class AddProductReviewPinned extends Migrator
{
    /**
     * 执行迁移
     *
     * @return void
     */
    public function up()
    {
        $this->table('product_review')
            ->addColumn('is_pinned', 'tinyinteger', ['default' => 0, 'after' => 'status',
                'comment' => '1=置顶（首页精选评论区展示）'])
            ->addColumn('pinned_at', 'datetime', ['null' => true, 'after' => 'is_pinned',
                'comment' => '置顶时间，首页按此倒序'])
            ->addIndex(['is_pinned', 'status', 'pinned_at'], ['name' => 'idx_pinned_status'])
            ->update();
    }

    /**
     * 回滚：删除置顶字段与索引
     *
     * @return void
     */
    public function down()
    {
        $this->table('product_review')
            ->removeIndexByName('idx_pinned_status')
            ->removeColumn('is_pinned')
            ->removeColumn('pinned_at')
            ->update();
    }
}
