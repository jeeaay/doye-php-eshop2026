<?php
declare(strict_types=1);

namespace app\controller;

use app\common\model\Product;
use app\common\service\CouponService;
use app\common\service\ReviewService;
use app\common\service\ThumbnailService;

/**
 * 首页（eshop2026 主题）
 *
 * 迁移自 eshop/www/template/eshop2026/pages/index.html：
 * 版式与文案保持不变；「Latest Arrivals」（前 8 个）与「Trending Now」（其余）取自商品表，
 * 首屏 Banner 取自后台「推荐位设置 → Banner 广告」，每条启用 Banner 是一张幻灯片，
 * 启用两条及以上时首屏轮播展示（文案随图切换）。
 */
class Index extends SiteBase
{
    public function index()
    {
        $brand = $this->store->brand();

        // Latest Arrivals 按后台「排序」权重倒序（权重相同按 ID 倒序）
        $result = $this->store->productCards(1, 24, 0, '', 'sort-desc');
        $all = $result['list'];

        // Trending Now 右侧展示「推荐商品」中排序最大的 4 个，未配置时回退到后续商品
        $recommended = $this->store->recommendedCards(4);

        $ops = $this->store->homeOps();

        $heroes = [];
        foreach ($ops['banners'] ?? [] as $banner) {
            $ctaUrl = $this->resolveLink((string) ($banner['link_type'] ?? 'none'), (string) ($banner['link_target'] ?? ''));
            $image  = (string) $banner['image'];
            // 按视口断点生成中心裁剪图（保留中间、裁掉左右），交给 <img srcset> 自动选择
            $sources = ThumbnailService::bannerSources($image);
            $srcset  = [];
            foreach ($sources as $width => $sourceUrl) {
                $srcset[] = $sourceUrl . ' ' . $width . 'w';
            }
            $heroes[] = [
                'image'    => ThumbnailService::bannerFallback($sources, $image),
                'srcset'   => implode(', ', $srcset),
                'title'    => (string) $banner['title'],
                'lead'     => (string) $banner['subtitle'],
                'cta_url'  => $ctaUrl,
                'cta_text' => $ctaUrl !== '' ? site_lang('home.learn_more') : '',
            ];
        }
        if ($heroes === []) {
            $heroes[] = [
                'image'    => '',
                'srcset'   => '',
                'title'    => site_lang('home.hero_title'),
                'lead'     => site_lang('home.hero_lead'),
                'cta_text' => site_lang('home.hero_cta'),
                'cta_url'  => '/products',
            ];
        }

        return $this->render('index', [
            'nav_active'    => 'home',
            // 首页 SEO 优先取后台「系统设置 → 首页 SEO」，未配置时回退品牌默认文案
            'page_title'    => (string) site_config('seo.title', '') ?: 'Home - ' . $brand['name'],
            'meta_desc'     => (string) site_config('seo.description', '') ?: $brand['tagline'],
            'meta_keys'     => (string) site_config('seo.keywords', ''),
            'products_top'  => array_slice($all, 0, 8),
            'products_rest' => $recommended !== [] ? $recommended : array_slice($all, 8, 4),
            'total'         => $result['total'],
            'heroes'        => $heroes,
            'notices'       => $ops['notices'] ?? [],
            // 精选评论：后台「评论管理」中置顶的已通过评论（作者名已脱敏）
            'testimonials'  => (new ReviewService())->pinnedForHome(),
            'flash_promotions' => (new CouponService())->activePlatformPromotions(),
        ]);
    }

    private function resolveLink(string $type, string $target): string
    {
        $target = trim($target);
        return match ($type) {
            'product'  => $this->productLink($target),
            'category' => ctype_digit($target) ? '/products?category_id=' . (int) $target : '',
            'page', 'topic' => $target !== '' ? '/' . ltrim($target, '/') : '',
            default    => '',
        };
    }

    /**
     * Banner 商品链接：带自定义访问路径的商品优先生成 slug URL
     */
    private function productLink(string $target): string
    {
        if (!ctype_digit($target)) {
            return '';
        }
        $product = Product::where('status', 1)->whereNull('delete_time')->find((int) $target);
        return $product ? storefront_product_url($product) : '';
    }
}