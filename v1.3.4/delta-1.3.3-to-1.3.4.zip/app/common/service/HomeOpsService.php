<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\exception\BizException;
use app\common\model\Category;
use app\common\model\HomeBanner;
use app\common\model\HomeCategory;
use app\common\model\HomeNotice;
use app\common\model\HomeProduct;
use app\common\model\HomeTopic;
use app\common\model\Product;

class HomeOpsService
{
    private const LINK_TYPES = ['none', 'page', 'product', 'category', 'topic'];

    private function validateLinkType(?string $type): string
    {
        $type = $type ?? 'none';
        if (!in_array($type, self::LINK_TYPES, true)) {
            throw new BizException('跳转类型无效');
        }
        return $type;
    }

    private function validateImage(?string $url, string $label): ?string
    {
        $url = trim((string) $url);
        if ($url === '') {
            return null;
        }
        if (!preg_match('~^/uploads/products/images/\d{6}/[a-f0-9]{32}\.(jpg|jpeg|png|webp)$~', $url)
            && !preg_match('~^/static/img/.+$~', $url)) {
            throw new BizException($label . ' 图片地址无效，请重新上传');
        }
        return $url;
    }

    public function aggregate(): array
    {
        $banners = [];
        foreach (HomeBanner::where('status', 1)->order('sort', 'asc')->order('id', 'asc')->select() as $banner) {
            $banners[] = [
                'id'          => (int) $banner->id,
                'image'       => $banner->image,
                'title'       => $banner->title ?? '',
                'subtitle'    => $banner->subtitle ?? '',
                'link_type'   => $banner->link_type ?? 'none',
                'link_target' => $banner->link_target ?? '',
            ];
        }

        $categories = [];
        foreach (HomeCategory::where('status', 1)->order('sort', 'asc')->order('id', 'asc')->select() as $hc) {
            $cat = Category::find($hc->category_id);
            if (!$cat) {
                continue;
            }
            $categories[] = [
                'id'       => (int) $cat->id,
                'name'     => $cat->name,
                'icon'     => $hc->icon ?? '',
            ];
        }

        $notices = [];
        $now = date('Y-m-d H:i:s');
        $noticeQuery = HomeNotice::where('status', 1)
            ->where(function ($q) use ($now) {
                $q->whereNull('start_time')->whereOr('start_time', '<=', $now);
            })
            ->where(function ($q) use ($now) {
                $q->whereNull('end_time')->whereOr('end_time', '>=', $now);
            });
        foreach ($noticeQuery->order('sort', 'asc')->order('id', 'asc')->select() as $notice) {
            $notices[] = [
                'id'          => (int) $notice->id,
                'title'       => $notice->title,
                'summary'     => $notice->summary ?? '',
                'link_type'   => $notice->link_type ?? 'none',
                'link_target' => $notice->link_target ?? '',
            ];
        }

        $topics = [];
        foreach (HomeTopic::where('status', 1)->order('sort', 'asc')->order('id', 'asc')->select() as $topic) {
            $topics[] = [
                'id'          => (int) $topic->id,
                'image'       => $topic->image,
                'title'       => $topic->title,
                'description' => $topic->description ?? '',
                'link_type'   => $topic->link_type ?? 'none',
                'link_target' => $topic->link_target ?? '',
            ];
        }

        $products = [];
        $productIds = [];
        foreach (HomeProduct::where('status', 1)->order('sort', 'asc')->order('id', 'asc')->column('product_id') as $pid) {
            $pid = (int) $pid;
            if ($pid > 0 && !in_array($pid, $productIds, true)) {
                $productIds[] = $pid;
            }
        }
        if ($productIds) {
            // 与首页 Trending Now 保持一致：推荐态商品按商品自身排序权重倒序
            $rows = Product::with(['skus'])
                ->whereIn('id', $productIds)
                ->where('status', 1)
                ->order('sort', 'desc')
                ->order('id', 'desc')
                ->select();
            foreach ($rows as $product) {
                $prices = [];
                foreach ($product->skus as $sku) {
                    $prices[] = (float) $sku->price;
                }
                $products[] = [
                    'id'         => (int) $product->id,
                    'title'      => $product->title,
                    'main_image' => $product->main_image ?? '',
                    'price_min'  => $prices ? number_format(min($prices), 2, '.', '') : '0.00',
                ];
            }
        }

        return [
            'banners'      => $banners,
            'categories'   => $categories,
            'notices'      => $notices,
            'topics'       => $topics,
            'products'     => $products,
            // 首页精选评论（后台置顶、作者名已脱敏），与 Web 首页 .home-testimonial 同源
            'testimonials' => (new ReviewService())->pinnedForHome(),
        ];
    }

    public function listBanners(): array
    {
        return HomeBanner::order('sort', 'asc')->order('id', 'asc')->select()->toArray();
    }

    public function saveBanner(array $data, ?int $id): HomeBanner
    {
        $image = $this->validateImage($data['image'] ?? null, 'Banner 图片');
        if (!$image) {
            throw new BizException('Banner 图片不能为空');
        }
        $linkType = $this->validateLinkType($data['link_type'] ?? null);
        $banner = $id ? HomeBanner::find($id) : new HomeBanner();
        if (!$banner) {
            throw new BizException('Banner 不存在');
        }
        $banner->image = $image;
        $banner->title = trim((string) ($data['title'] ?? '')) ?: null;
        $banner->subtitle = trim((string) ($data['subtitle'] ?? '')) ?: null;
        $banner->link_type = $linkType;
        $banner->link_target = trim((string) ($data['link_target'] ?? '')) ?: null;
        $banner->sort = (int) ($data['sort'] ?? 0);
        $banner->status = isset($data['status']) ? (int) $data['status'] : 1;
        $banner->save();
        return $banner;
    }

    public function deleteBanner(int $id): void
    {
        $banner = HomeBanner::find($id);
        if (!$banner) {
            throw new BizException('Banner 不存在');
        }
        $banner->delete();
    }

    public function toggleBanner(int $id, int $status): void
    {
        $banner = HomeBanner::find($id);
        if (!$banner) {
            throw new BizException('Banner 不存在');
        }
        $banner->status = $status ? 1 : 0;
        $banner->save();
    }

    public function listHomeCategories(): array
    {
        $rows = HomeCategory::with('category')->order('sort', 'asc')->order('id', 'asc')->select();
        $list = [];
        foreach ($rows as $row) {
            $list[] = [
                'id'           => (int) $row->id,
                'category_id'  => (int) $row->category_id,
                'category_name'=> $row->category?->name ?? '(已删除)',
                'icon'         => $row->icon ?? '',
                'sort'         => (int) $row->sort,
                'status'       => (int) $row->status,
            ];
        }
        return $list;
    }

    public function saveHomeCategory(array $data, ?int $id): HomeCategory
    {
        $categoryId = (int) ($data['category_id'] ?? 0);
        if ($categoryId <= 0 || !Category::find($categoryId)) {
            throw new BizException('请选择有效的分类');
        }
        $icon = trim((string) ($data['icon'] ?? ''));
        $hc = $id ? HomeCategory::find($id) : new HomeCategory();
        if (!$hc) {
            throw new BizException('首页分类配置不存在');
        }
        if (!$id && HomeCategory::where('category_id', $categoryId)->find()) {
            throw new BizException('该分类已在首页展示，不能重复添加');
        }
        $hc->category_id = $categoryId;
        $hc->icon = $icon ?: null;
        $hc->sort = (int) ($data['sort'] ?? 0);
        $hc->status = isset($data['status']) ? (int) $data['status'] : 1;
        $hc->save();
        return $hc;
    }

    public function deleteHomeCategory(int $id): void
    {
        $hc = HomeCategory::find($id);
        if (!$hc) {
            throw new BizException('首页分类配置不存在');
        }
        $hc->delete();
    }

    public function toggleHomeCategory(int $id, int $status): void
    {
        $hc = HomeCategory::find($id);
        if (!$hc) {
            throw new BizException('首页分类配置不存在');
        }
        $hc->status = $status ? 1 : 0;
        $hc->save();
    }

    public function listNotices(): array
    {
        return HomeNotice::order('sort', 'asc')->order('id', 'asc')->select()->toArray();
    }

    public function saveNotice(array $data, ?int $id): HomeNotice
    {
        $title = trim((string) ($data['title'] ?? ''));
        if ($title === '') {
            throw new BizException('公告标题不能为空');
        }
        $linkType = $this->validateLinkType($data['link_type'] ?? null);
        $notice = $id ? HomeNotice::find($id) : new HomeNotice();
        if (!$notice) {
            throw new BizException('公告不存在');
        }
        $notice->title = $title;
        $notice->summary = trim((string) ($data['summary'] ?? '')) ?: null;
        $notice->link_type = $linkType;
        $notice->link_target = trim((string) ($data['link_target'] ?? '')) ?: null;
        $notice->start_time = trim((string) ($data['start_time'] ?? '')) ?: null;
        $notice->end_time = trim((string) ($data['end_time'] ?? '')) ?: null;
        if ($notice->start_time && $notice->end_time && $notice->start_time > $notice->end_time) {
            throw new BizException('开始时间不能晚于结束时间');
        }
        $notice->sort = (int) ($data['sort'] ?? 0);
        $notice->status = isset($data['status']) ? (int) $data['status'] : 1;
        $notice->save();
        return $notice;
    }

    public function deleteNotice(int $id): void
    {
        $notice = HomeNotice::find($id);
        if (!$notice) {
            throw new BizException('公告不存在');
        }
        $notice->delete();
    }

    public function toggleNotice(int $id, int $status): void
    {
        $notice = HomeNotice::find($id);
        if (!$notice) {
            throw new BizException('公告不存在');
        }
        $notice->status = $status ? 1 : 0;
        $notice->save();
    }

    public function listTopics(): array
    {
        return HomeTopic::order('sort', 'asc')->order('id', 'asc')->select()->toArray();
    }

    public function saveTopic(array $data, ?int $id): HomeTopic
    {
        $image = $this->validateImage($data['image'] ?? null, '专题图片');
        if (!$image) {
            throw new BizException('专题图片不能为空');
        }
        $title = trim((string) ($data['title'] ?? ''));
        if ($title === '') {
            throw new BizException('专题标题不能为空');
        }
        $linkType = $this->validateLinkType($data['link_type'] ?? null);
        $topic = $id ? HomeTopic::find($id) : new HomeTopic();
        if (!$topic) {
            throw new BizException('专题不存在');
        }
        $topic->image = $image;
        $topic->title = $title;
        $topic->description = trim((string) ($data['description'] ?? '')) ?: null;
        $topic->link_type = $linkType;
        $topic->link_target = trim((string) ($data['link_target'] ?? '')) ?: null;
        $topic->sort = (int) ($data['sort'] ?? 0);
        $topic->status = isset($data['status']) ? (int) $data['status'] : 1;
        $topic->save();
        return $topic;
    }

    public function deleteTopic(int $id): void
    {
        $topic = HomeTopic::find($id);
        if (!$topic) {
            throw new BizException('专题不存在');
        }
        $topic->delete();
    }

    public function toggleTopic(int $id, int $status): void
    {
        $topic = HomeTopic::find($id);
        if (!$topic) {
            throw new BizException('专题不存在');
        }
        $topic->status = $status ? 1 : 0;
        $topic->save();
    }

    public function listHomeProducts(): array
    {
        $rows = HomeProduct::with('product')->order('sort', 'asc')->order('id', 'asc')->select();
        $list = [];
        foreach ($rows as $row) {
            $p = $row->product;
            $list[] = [
                'id'           => (int) $row->id,
                'product_id'   => (int) $row->product_id,
                'product_title'=> $p?->title ?? '(已删除)',
                'sort'         => (int) $row->sort,
                'status'       => (int) $row->status,
            ];
        }
        return $list;
    }

    public function saveHomeProduct(array $data, ?int $id): HomeProduct
    {
        $productId = (int) ($data['product_id'] ?? 0);
        if ($productId <= 0 || !Product::find($productId)) {
            throw new BizException('请选择有效的商品');
        }
        $hp = $id ? HomeProduct::find($id) : new HomeProduct();
        if (!$hp) {
            throw new BizException('推荐商品配置不存在');
        }
        if (!$id && HomeProduct::where('product_id', $productId)->find()) {
            throw new BizException('该商品已在首页推荐，不能重复添加');
        }
        $hp->product_id = $productId;
        $hp->sort = (int) ($data['sort'] ?? 0);
        $hp->status = isset($data['status']) ? (int) $data['status'] : 1;
        $hp->save();
        return $hp;
    }

    public function deleteHomeProduct(int $id): void
    {
        $hp = HomeProduct::find($id);
        if (!$hp) {
            throw new BizException('推荐商品配置不存在');
        }
        $hp->delete();
    }

    public function toggleHomeProduct(int $id, int $status): void
    {
        $hp = HomeProduct::find($id);
        if (!$hp) {
            throw new BizException('推荐商品配置不存在');
        }
        $hp->status = $status ? 1 : 0;
        $hp->save();
    }
}
