<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\enum\OrderStatus;
use app\common\exception\BizException;
use app\common\model\ProductReview;
use app\common\model\ProductReviewVote;
use app\common\support\AppContext;
use think\db\exception\PDOException;
use think\facade\Db;

/**
 * 商品评论服务
 *
 * 前台读（summary / listApproved）、提交资格（eligible / create）、投票（vote）
 * 与后台管理（adminList / adminDetail / adminUpdateStatus / adminReply / adminDelete）
 * 的全部校验、事务与数据范围都收敛在这里；控制器只做参数整形与响应封装。
 *
 * 口径约定：
 * - 前台只读路径统一 `status = 1 AND delete_time IS NULL`；
 * - 作者名脱敏，永不返回原始邮箱；
 * - 图片只认本站 `/uploads/reviews/images/YYYYMM/<32hex>.<ext>`；
 * - 提交后默认待审核，`site_config('review.auto_approve', false)` 可放开（首版不暴露设置页）。
 */
final class ReviewService
{
    /** 待审核 */
    public const STATUS_PENDING = 0;

    /** 已通过（前台可见） */
    public const STATUS_APPROVED = 1;

    /** 已拒绝 */
    public const STATUS_REJECTED = 2;

    /** 已隐藏 */
    public const STATUS_HIDDEN = 3;

    /** 状态 => 展示名 */
    public const STATUS_LABELS = [
        self::STATUS_PENDING  => '待审核',
        self::STATUS_APPROVED => '已通过',
        self::STATUS_REJECTED => '已拒绝',
        self::STATUS_HIDDEN   => '已隐藏',
    ];

    /** 单条评论最多图片数 */
    public const MAX_IMAGES = 6;

    /** 前台默认每页条数 */
    public const PAGE_SIZE = 5;

    /** 前台每页上限（防止 size 越界） */
    public const MAX_PAGE_SIZE = 20;

    /** 正文最短长度 */
    public const MIN_CONTENT = 10;

    /** 正文最长长度 */
    public const MAX_CONTENT = 2000;

    /** 标题最长长度 */
    public const MAX_TITLE = 120;

    /** 后台回复最长长度 */
    public const MAX_REPLY = 2000;

    /** 批量操作上限 */
    public const MAX_BATCH = 200;

    /** 评论图片只允许本站上传路径 */
    public const IMAGE_PATTERN = '#^/uploads/reviews/images/\d{6}/[a-f0-9]{32}\.(jpg|jpeg|png|webp)$#';

    // ------------------------------------------------------------------
    // 前台：统计与列表
    // ------------------------------------------------------------------

    /**
     * 商品评论统计（仅已通过 + 未删除）
     *
     * @param int $productId 商品 ID
     * @return array{count:int,avg:float,distribution:array<int,int>}
     */
    public function summary(int $productId): array
    {
        $distribution = [5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0];
        if ($productId <= 0) {
            return ['count' => 0, 'avg' => 0.0, 'distribution' => $distribution];
        }

        $row = Db::name('product_review')
            ->where('product_id', $productId)
            ->where('status', self::STATUS_APPROVED)
            ->whereNull('delete_time')
            ->field(
                'COUNT(*) AS total, AVG(rating) AS avg_rating,'
                . ' SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END) AS r5,'
                . ' SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END) AS r4,'
                . ' SUM(CASE WHEN rating = 3 THEN 1 ELSE 0 END) AS r3,'
                . ' SUM(CASE WHEN rating = 2 THEN 1 ELSE 0 END) AS r2,'
                . ' SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END) AS r1'
            )
            ->find();

        $count = (int) ($row['total'] ?? 0);
        if ($count > 0) {
            $distribution = [
                5 => (int) ($row['r5'] ?? 0),
                4 => (int) ($row['r4'] ?? 0),
                3 => (int) ($row['r3'] ?? 0),
                2 => (int) ($row['r2'] ?? 0),
                1 => (int) ($row['r1'] ?? 0),
            ];
        }

        return [
            'count'        => $count,
            'avg'          => $count > 0 ? round((float) ($row['avg_rating'] ?? 0), 1) : 0.0,
            'distribution' => $distribution,
        ];
    }

    /**
     * 前台评论列表（仅已通过）
     *
     * @param int      $productId 商品 ID
     * @param array    $filters   支持 rating(1-5) / media(1) / keyword
     * @param int      $page      页码
     * @param int      $size      每页条数（收敛 1-20，默认 5）
     * @param int|null $viewerId  当前登录用户，用于返回 my_vote
     * @return array{list:array,total:int,page:int,size:int,hasMore:bool}
     */
    public function listApproved(
        int $productId,
        array $filters = [],
        int $page = 1,
        int $size = self::PAGE_SIZE,
        ?int $viewerId = null
    ): array {
        $page = max(1, $page);
        $size = $this->clampSize($size);

        if ($productId <= 0) {
            return ['list' => [], 'total' => 0, 'page' => $page, 'size' => $size, 'hasMore' => false];
        }

        $query = ProductReview::where('product_id', $productId)
            ->where('status', self::STATUS_APPROVED);

        $rating = (int) ($filters['rating'] ?? 0);
        if ($rating >= 1 && $rating <= 5) {
            $query->where('rating', $rating);
        }

        if (!empty($filters['media'])) {
            $query->whereNotNull('images_json')->whereRaw('JSON_LENGTH(images_json) > 0');
        }

        $keyword = trim((string) ($filters['keyword'] ?? ''));
        if ($keyword !== '') {
            $like = '%' . $this->escapeLike($keyword) . '%';
            $query->where(function ($q) use ($like) {
                $q->whereLike('title', $like)->whereOr('content', 'like', $like);
            });
        }

        $pager = $query->order('create_time', 'desc')->order('id', 'desc')->paginate([
            'list_rows' => $size,
            'page'      => $page,
        ]);

        $total = (int) $pager->total();

        return [
            'list'    => $this->formatPublicList($pager->items(), $viewerId),
            'total'   => $total,
            'page'    => $page,
            'size'    => $size,
            'hasMore' => $page * $size < $total,
        ];
    }

    // ------------------------------------------------------------------
    // 前台：首页精选评论
    // ------------------------------------------------------------------

    /**
     * 首页精选评论（.home-testimonial）
     *
     * 取所有「置顶 + 已通过 + 未删除」的评论，按置顶时间倒序。
     * 作者名脱敏：匿名评论显示 Anonymous；有昵称保留首字符，否则邮箱脱敏。
     *
     * @return array<int,array{id:int,content:string,author:string}>
     */
    public function pinnedForHome(): array
    {
        $rows = ProductReview::where('status', self::STATUS_APPROVED)
            ->where('is_pinned', 1)
            ->order('pinned_at', 'desc')
            ->order('id', 'desc')
            ->select();

        if ($rows->isEmpty()) {
            return [];
        }

        $users = $this->userMap($rows->column('user_id'));

        $list = [];
        foreach ($rows as $review) {
            $user = $users[(int) $review->user_id] ?? [];
            $list[] = [
                'id'      => (int) $review->id,
                'content' => trim((string) $review->content),
                'author'  => (int) $review->is_anonymous === 1
                    ? 'Anonymous'
                    : $this->maskedDisplayName($user),
            ];
        }

        return $list;
    }

    // ------------------------------------------------------------------
    // 前台：资格 / 提交 / 投票
    // ------------------------------------------------------------------

    /**
     * 当前用户可评价的订单商品（已送达及以上状态、尚未评论）
     *
     * @param int $productId 商品 ID
     * @param int $userId    用户 ID
     * @return array<int,array{order_item_id:int,order_no:string,sku_name:string,received_at:string}>
     */
    public function eligible(int $productId, int $userId): array
    {
        if ($userId <= 0) {
            throw new BizException('请先登录');
        }
        if ($productId <= 0) {
            return [];
        }

        $orders = Db::name('order')
            ->where('user_id', $userId)
            ->where('status', '>=', OrderStatus::DELIVERED)
            ->where('status', '<=', OrderStatus::SETTLED)
            ->whereNull('delete_time')
            ->field('id, order_no, deliver_at, confirm_at, update_time')
            ->select()
            ->toArray();

        if (empty($orders)) {
            return [];
        }

        $orderMap = [];
        foreach ($orders as $order) {
            $orderMap[(int) $order['id']] = $order;
        }

        $items = Db::name('order_item')
            ->whereIn('order_id', array_keys($orderMap))
            ->where('product_id', $productId)
            ->order('id', 'desc')
            ->select()
            ->toArray();

        if (empty($items)) {
            return [];
        }

        $itemIds = array_map(static fn($item): int => (int) $item['id'], $items);
        $reviewed = array_map('intval', Db::name('product_review')
            ->whereIn('order_item_id', $itemIds)
            ->column('order_item_id'));

        $list = [];
        foreach ($items as $item) {
            if (in_array((int) $item['id'], $reviewed, true)) {
                continue;
            }
            $order = $orderMap[(int) $item['order_id']] ?? [];
            $snapshot = $item['sku_snapshot_json'] ?? [];
            if (is_string($snapshot)) {
                $snapshot = (array) json_decode($snapshot, true);
            }

            $list[] = [
                'order_item_id' => (int) $item['id'],
                'order_no'      => (string) ($order['order_no'] ?? ''),
                'sku_name'      => (string) ($snapshot['spec_name'] ?? $snapshot['title'] ?? ''),
                'received_at'   => (string) ($order['deliver_at'] ?? $order['confirm_at'] ?? $order['update_time'] ?? ''),
            ];
        }

        return $list;
    }

    /**
     * 提交评论：校验订单商品归属与状态，写库后默认为待审核
     *
     * @param int   $userId 用户 ID
     * @param array $data   order_item_id / rating / title / content / images / is_anonymous
     * @return array{id:int,status:int,status_label:string,auto_approved:bool}
     */
    public function create(int $userId, array $data): array
    {
        if ($userId <= 0) {
            throw new BizException('请先登录');
        }

        $orderItemId = (int) ($data['order_item_id'] ?? 0);
        if ($orderItemId <= 0) {
            throw new BizException('请选择要评价的订单商品');
        }

        $rating = (int) ($data['rating'] ?? 0);
        if ($rating < 1 || $rating > 5) {
            throw new BizException('请选择 1-5 星评分');
        }

        if (isset($data['title']) && !is_scalar($data['title'])) {
            throw new BizException('标题格式不正确');
        }
        if (isset($data['content']) && !is_scalar($data['content'])) {
            throw new BizException('评论内容格式不正确');
        }

        $title = $this->plainText($data['title'] ?? '');
        if (mb_strlen($title) > self::MAX_TITLE) {
            throw new BizException('标题不能超过 ' . self::MAX_TITLE . ' 个字');
        }

        $content = $this->plainText($data['content'] ?? '');
        $length  = mb_strlen($content);
        if ($length < self::MIN_CONTENT) {
            throw new BizException('评论内容至少 ' . self::MIN_CONTENT . ' 个字');
        }
        if ($length > self::MAX_CONTENT) {
            throw new BizException('评论内容不能超过 ' . self::MAX_CONTENT . ' 个字');
        }

        $images      = $this->normalizeImages($data['images'] ?? []);
        $isAnonymous = !empty($data['is_anonymous']) ? 1 : 0;
        $autoApprove = (bool) site_config('review.auto_approve', false);
        $status      = $autoApprove ? self::STATUS_APPROVED : self::STATUS_PENDING;

        Db::startTrans();
        try {
            $context = $this->loadOrderItemContext($orderItemId);
            if ((int) $context['user_id'] !== $userId) {
                throw new BizException('该订单商品不属于当前用户');
            }
            // 唯一键口径：连软删除行一起查（uk_order_item 建在真实表上）
            if (Db::name('product_review')->where('order_item_id', $orderItemId)->value('id')) {
                throw new BizException('该订单商品已评价');
            }

            $review = new ProductReview();
            $review->product_id    = (int) $context['product_id'];
            $review->merchant_id   = (int) $context['merchant_id'];
            $review->user_id       = $userId;
            $review->order_id      = (int) $context['order_id'];
            $review->order_item_id = $orderItemId;
            $review->rating        = $rating;
            $review->title         = $title !== '' ? $title : null;
            $review->content       = $content;
            $review->images_json   = $images;
            $review->is_anonymous  = $isAnonymous;
            $review->is_verified   = 1;
            $review->status        = $status;
            $review->helpful_yes   = 0;
            $review->helpful_no    = 0;
            $review->save();

            $reviewId = (int) $review->id;
            Db::commit();
        } catch (\Throwable $e) {
            Db::rollback();
            if ($this->isDuplicateEntry($e)) {
                throw new BizException('该订单商品已评价');
            }
            throw $e;
        }

        return [
            'id'            => $reviewId,
            'status'        => $status,
            'status_label'  => self::STATUS_LABELS[$status] ?? '',
            'auto_approved' => $autoApprove,
        ];
    }

    /**
     * 有用 / 无用投票
     *
     * 同一用户同一评论只保留一票：无记录 → 新增；同票 → 取消；异票 → 切换。
     * 计数在同一事务内按行锁后的真实值重算，任何分支都不会出现负数。
     *
     * @param int $userId   用户 ID
     * @param int $reviewId 评论 ID
     * @param int $vote     1 有用 / 2 无用
     * @return array{review_id:int,vote:int,helpful_yes:int,helpful_no:int}
     */
    public function vote(int $userId, int $reviewId, int $vote): array
    {
        if ($userId <= 0) {
            throw new BizException('请先登录');
        }
        if (!in_array($vote, [1, 2], true)) {
            throw new BizException('投票类型不合法');
        }

        $resultVote = 0;
        $yes        = 0;
        $no         = 0;

        Db::startTrans();
        try {
            $review = ProductReview::where('id', $reviewId)->lock(true)->find();
            if (!$review || (int) $review->status !== self::STATUS_APPROVED) {
                throw new BizException('评论不存在或不可投票');
            }

            $yes = (int) $review->helpful_yes;
            $no  = (int) $review->helpful_no;

            $existing = ProductReviewVote::where('review_id', $reviewId)
                ->where('user_id', $userId)
                ->lock(true)
                ->find();

            if (!$existing) {
                $row = new ProductReviewVote();
                $row->review_id = $reviewId;
                $row->user_id   = $userId;
                $row->vote      = $vote;
                $row->save();
                if ($vote === 1) {
                    $yes++;
                } else {
                    $no++;
                }
                $resultVote = $vote;
            } elseif ((int) $existing->vote === $vote) {
                $existing->delete();
                if ($vote === 1) {
                    $yes = max(0, $yes - 1);
                } else {
                    $no = max(0, $no - 1);
                }
                $resultVote = 0;
            } else {
                $existing->vote = $vote;
                $existing->save();
                if ($vote === 1) {
                    $no  = max(0, $no - 1);
                    $yes++;
                } else {
                    $yes = max(0, $yes - 1);
                    $no++;
                }
                $resultVote = $vote;
            }

            ProductReview::where('id', $reviewId)->update([
                'helpful_yes' => $yes,
                'helpful_no'  => $no,
                'update_time' => date('Y-m-d H:i:s'),
            ]);

            Db::commit();
        } catch (\Throwable $e) {
            Db::rollback();
            throw $e;
        }

        return [
            'review_id'   => $reviewId,
            'vote'        => $resultVote,
            'helpful_yes' => $yes,
            'helpful_no'  => $no,
        ];
    }

    // ------------------------------------------------------------------
    // 后台
    // ------------------------------------------------------------------

    /**
     * 后台评论列表
     *
     * 非超管依赖 MerchantModel 自动按 merchant_id 收敛；关键词覆盖
     * 评论内容/标题、作者昵称/邮箱、商品名、订单号（通过反向查 ID 实现，避免 join 歧义）。
     *
     * @param array $filters 支持 keyword / status / rating / product_id / start_date / end_date
     * @param int   $page    页码
     * @param int   $size    每页数量
     * @return array{list:array,total:int,page:int,page_size:int}
     */
    public function adminList(array $filters = [], int $page = 1, int $size = 20): array
    {
        $page = max(1, $page);
        $size = min(max($size, 1), 100);

        $query = ProductReview::order('id', 'desc');

        $status = $filters['status'] ?? '';
        if ($status !== '' && $status !== null) {
            $query->where('status', (int) $status);
        }

        $rating = (int) ($filters['rating'] ?? 0);
        if ($rating >= 1 && $rating <= 5) {
            $query->where('rating', $rating);
        }

        $productId = (int) ($filters['product_id'] ?? 0);
        if ($productId > 0) {
            $query->where('product_id', $productId);
        }

        $keyword = trim((string) ($filters['keyword'] ?? ''));
        if ($keyword !== '') {
            $like       = '%' . $this->escapeLike($keyword) . '%';
            $productIds = Db::name('product')->whereLike('title', $like)->column('id');
            $userIds    = Db::name('user')->where(function ($q) use ($like) {
                $q->whereLike('nickname', $like)->whereOr('email', 'like', $like);
            })->column('id');
            $orderIds   = Db::name('order')->whereLike('order_no', $like)->column('id');

            $query->where(function ($q) use ($like, $productIds, $userIds, $orderIds) {
                $q->whereLike('title', $like)->whereOr('content', 'like', $like);
                if (!empty($productIds)) {
                    $q->whereOr('product_id', 'in', $productIds);
                }
                if (!empty($userIds)) {
                    $q->whereOr('user_id', 'in', $userIds);
                }
                if (!empty($orderIds)) {
                    $q->whereOr('order_id', 'in', $orderIds);
                }
            });
        }

        $startDate = $this->normalizeDate($filters['start_date'] ?? '');
        if ($startDate !== '') {
            $query->where('create_time', '>=', $startDate . ' 00:00:00');
        }
        $endDate = $this->normalizeDate($filters['end_date'] ?? '');
        if ($endDate !== '') {
            $query->where('create_time', '<=', $endDate . ' 23:59:59');
        }

        $pager = $query->paginate(['list_rows' => $size, 'page' => $page]);
        $rows  = $pager->items();
        $total = (int) $pager->total();

        return [
            'list'      => $this->formatAdminList($rows),
            'total'     => $total,
            'page'      => $page,
            'page_size' => $size,
        ];
    }

    /**
     * 后台评论详情
     *
     * @param int $id 评论 ID
     * @return array
     * @throws BizException 不存在或不在当前账号数据范围
     */
    public function adminDetail(int $id): array
    {
        $review = ProductReview::find($id);
        if (!$review) {
            throw new BizException('评论不存在或无权操作');
        }
        $list = $this->formatAdminList([$review]);
        return $list[0];
    }

    /**
     * 批量修改状态（只接受 1 通过 / 2 拒绝 / 3 隐藏）
     *
     * @param array $ids    评论 ID
     * @param int   $status 目标状态
     * @return int 受影响条数
     * @throws BizException 参数非法 / 有不在数据范围内的 ID
     */
    public function adminUpdateStatus(array $ids, int $status): int
    {
        if (!in_array($status, [self::STATUS_APPROVED, self::STATUS_REJECTED, self::STATUS_HIDDEN], true)) {
            throw new BizException('状态不合法');
        }

        $ids = $this->normalizeIds($ids);
        if (empty($ids)) {
            throw new BizException('请选择评论');
        }

        $existing = ProductReview::whereIn('id', $ids)->column('id');
        if (count($existing) !== count($ids)) {
            throw new BizException('评论不存在或无权操作');
        }

        return (int) ProductReview::whereIn('id', $ids)->update([
            'status'      => $status,
            'update_time' => date('Y-m-d H:i:s'),
        ]);
    }

    /**
     * 批量设置/取消置顶
     *
     * 首页精选评论只展示已通过审核的评论，因此置顶目标必须是「已通过」，
     * 避免后台置顶了待审核评论却在前台看不到。
     *
     * @param array $ids    评论 ID
     * @param bool  $pinned true=置顶 false=取消置顶
     * @return int 受影响条数
     * @throws BizException
     */
    public function adminSetPinned(array $ids, bool $pinned): int
    {
        $ids = $this->normalizeIds($ids);
        if (empty($ids)) {
            throw new BizException('请选择评论');
        }

        $statuses = ProductReview::whereIn('id', $ids)->column('status', 'id');
        if (count($statuses) !== count($ids)) {
            throw new BizException('评论不存在或无权操作');
        }
        if ($pinned) {
            foreach ($statuses as $status) {
                if ((int) $status !== self::STATUS_APPROVED) {
                    throw new BizException('仅已通过的评论可以置顶');
                }
            }
        }

        $now = date('Y-m-d H:i:s');

        return (int) ProductReview::whereIn('id', $ids)->update([
            'is_pinned'   => $pinned ? 1 : 0,
            'pinned_at'   => $pinned ? $now : null,
            'update_time' => $now,
        ]);
    }

    /**
     * 后台回复
     *
     * @param int    $id    评论 ID
     * @param string $reply 回复内容
     * @return array 更新后的后台详情
     * @throws BizException
     */
    public function adminReply(int $id, string $reply): array
    {
        $reply = $this->plainText($reply);
        if ($reply === '') {
            throw new BizException('请填写回复内容');
        }
        if (mb_strlen($reply) > self::MAX_REPLY) {
            throw new BizException('回复不能超过 ' . self::MAX_REPLY . ' 个字');
        }

        $review = ProductReview::find($id);
        if (!$review) {
            throw new BizException('评论不存在或无权操作');
        }

        $now = date('Y-m-d H:i:s');
        ProductReview::where('id', $id)->update([
            'admin_reply' => $reply,
            'replied_by'  => AppContext::getAdminId(),
            'replied_at'  => $now,
            'update_time' => $now,
        ]);

        return $this->adminDetail($id);
    }

    /**
     * 批量删除（硬删除评论及其投票，返回条数）
     *
     * @param array $ids 评论 ID
     * @return int 删除条数
     * @throws BizException
     */
    public function adminDelete(array $ids): int
    {
        $ids = $this->normalizeIds($ids);
        if (empty($ids)) {
            throw new BizException('请选择评论');
        }

        $existing = ProductReview::whereIn('id', $ids)->column('id');
        if (count($existing) !== count($ids)) {
            throw new BizException('评论不存在或无权操作');
        }

        Db::startTrans();
        try {
            $deleted = (int) Db::name('product_review')->whereIn('id', $existing)->delete();
            Db::name('product_review_vote')->whereIn('review_id', $existing)->delete();
            Db::commit();
        } catch (\Throwable $e) {
            Db::rollback();
            throw $e;
        }

        return $deleted;
    }

    // ------------------------------------------------------------------
    // 内部：校验与格式化
    // ------------------------------------------------------------------

    /**
     * 读取订单商品上下文并校验订单状态
     *
     * 状态范围 DELIVERED(3) ~ SETTLED(6)，排除取消/退款；
     * merchant_id 取商品的当前归属（客观事实，故用原生查询绕过 MerchantScope）。
     *
     * @param int $orderItemId 订单商品行 ID
     * @return array{order_id:int,user_id:int,product_id:int,merchant_id:int}
     * @throws BizException
     */
    private function loadOrderItemContext(int $orderItemId): array
    {
        $item = Db::name('order_item')->where('id', $orderItemId)->find();
        if (!$item) {
            throw new BizException('订单商品不存在');
        }

        $order = Db::name('order')
            ->where('id', (int) $item['order_id'])
            ->whereNull('delete_time')
            ->find();
        if (!$order) {
            throw new BizException('订单不存在');
        }

        $status = (int) $order['status'];
        if ($status < OrderStatus::DELIVERED || $status > OrderStatus::SETTLED) {
            throw new BizException('订单送达或完成后才能评价');
        }

        $productId = (int) $item['product_id'];
        $product   = Db::name('product')
            ->where('id', $productId)
            ->whereNull('delete_time')
            ->field('id, merchant_id')
            ->find();
        if (!$product) {
            throw new BizException('商品不存在或已下架');
        }

        return [
            'order_id'    => (int) $order['id'],
            'user_id'     => (int) $order['user_id'],
            'product_id'  => $productId,
            'merchant_id' => (int) $product['merchant_id'],
        ];
    }

    /**
     * 前台列表项格式化（批量取作者与投票，避免逐行查库）
     *
     * @param array    $rows     评论模型
     * @param int|null $viewerId 当前用户 ID
     * @return array<int,array>
     */
    private function formatPublicList(array $rows, ?int $viewerId): array
    {
        if (empty($rows)) {
            return [];
        }

        $userIds   = [];
        $reviewIds = [];
        foreach ($rows as $review) {
            $userIds[]   = (int) $review->user_id;
            $reviewIds[] = (int) $review->id;
        }
        $users = $this->userMap($userIds);

        $votes = [];
        if ($viewerId !== null && $viewerId > 0) {
            $votes = ProductReviewVote::where('user_id', $viewerId)
                ->whereIn('review_id', $reviewIds)
                ->column('vote', 'review_id');
        }

        $list = [];
        foreach ($rows as $review) {
            $anonymous = (int) $review->is_anonymous === 1;
            $user      = $users[(int) $review->user_id] ?? [];

            $list[] = [
                'id'           => (int) $review->id,
                'rating'       => (int) $review->rating,
                'title'        => (string) ($review->title ?? ''),
                'content'      => (string) $review->content,
                'images'       => $this->validImages($review->images_json),
                'author'       => $anonymous ? 'Anonymous' : $this->displayName($user),
                'avatar'       => $anonymous ? '' : (string) ($user['avatar'] ?? ''),
                'is_anonymous' => $anonymous ? 1 : 0,
                'is_verified'  => (int) $review->is_verified === 1 ? 1 : 0,
                'create_time'  => (string) ($review->create_time ?? ''),
                'admin_reply'  => (string) ($review->admin_reply ?? ''),
                'replied_at'   => (string) ($review->replied_at ?? ''),
                'helpful_yes'  => (int) $review->helpful_yes,
                'helpful_no'   => (int) $review->helpful_no,
                'my_vote'      => isset($votes[(int) $review->id]) ? (int) $votes[(int) $review->id] : 0,
            ];
        }

        return $list;
    }

    /**
     * 后台列表项格式化
     *
     * @param array $rows 评论模型
     * @return array<int,array>
     */
    private function formatAdminList(array $rows): array
    {
        if (empty($rows)) {
            return [];
        }

        $userIds    = [];
        $productIds = [];
        $orderIds   = [];
        foreach ($rows as $review) {
            $userIds[]    = (int) $review->user_id;
            $productIds[] = (int) $review->product_id;
            $orderIds[]   = (int) $review->order_id;
        }

        $users    = $this->userMap($userIds);
        $products = $this->productMap($productIds);
        $orderNos = empty($orderIds)
            ? []
            : Db::name('order')->whereIn('id', $orderIds)->column('order_no', 'id');

        $list = [];
        foreach ($rows as $review) {
            $user    = $users[(int) $review->user_id] ?? [];
            $product = $products[(int) $review->product_id] ?? [];
            $status  = (int) $review->status;

            $list[] = [
                'id'            => (int) $review->id,
                'product_id'    => (int) $review->product_id,
                'product_title' => (string) ($product['title'] ?? ''),
                'product_image' => (string) ($product['main_image'] ?? ''),
                'merchant_id'   => $review->merchant_id === null ? null : (int) $review->merchant_id,
                'user_id'       => (int) $review->user_id,
                'user_nickname' => (string) ($user['nickname'] ?? ''),
                'user_email'    => (string) ($user['email'] ?? ''),
                'order_id'      => (int) $review->order_id,
                'order_no'      => (string) ($orderNos[(int) $review->order_id] ?? ''),
                'order_item_id' => (int) $review->order_item_id,
                'rating'        => (int) $review->rating,
                'title'         => (string) ($review->title ?? ''),
                'content'       => (string) $review->content,
                'images'        => $this->validImages($review->images_json),
                'is_anonymous'  => (int) $review->is_anonymous,
                'is_verified'   => (int) $review->is_verified,
                'status'        => $status,
                'status_label'  => self::STATUS_LABELS[$status] ?? '',
                'is_pinned'     => (int) $review->is_pinned,
                'pinned_at'     => (string) ($review->pinned_at ?? ''),
                'helpful_yes'   => (int) $review->helpful_yes,
                'helpful_no'    => (int) $review->helpful_no,
                'admin_reply'   => (string) ($review->admin_reply ?? ''),
                'replied_by'    => $review->replied_by === null ? null : (int) $review->replied_by,
                'replied_at'    => (string) ($review->replied_at ?? ''),
                'create_time'   => (string) ($review->create_time ?? ''),
                'update_time'   => (string) ($review->update_time ?? ''),
            ];
        }

        return $list;
    }

    /**
     * 批量取用户信息（id => nickname/email/avatar）
     *
     * @param array $userIds 用户 ID
     * @return array<int,array>
     */
    private function userMap(array $userIds): array
    {
        $ids = [];
        foreach ($userIds as $userId) {
            if ((int) $userId > 0) {
                $ids[(int) $userId] = (int) $userId;
            }
        }
        if (empty($ids)) {
            return [];
        }

        $map = [];
        foreach (Db::name('user')->whereIn('id', array_values($ids))->field('id, nickname, email, avatar')->select() as $row) {
            $map[(int) $row['id']] = $row;
        }
        return $map;
    }

    /**
     * 批量取商品标题与主图（不过滤软删除，历史评论仍可展示商品信息）
     *
     * @param array $productIds 商品 ID
     * @return array<int,array>
     */
    private function productMap(array $productIds): array
    {
        $ids = [];
        foreach ($productIds as $productId) {
            if ((int) $productId > 0) {
                $ids[(int) $productId] = (int) $productId;
            }
        }
        if (empty($ids)) {
            return [];
        }

        $map = [];
        foreach (Db::name('product')->whereIn('id', array_values($ids))->field('id, title, main_image')->select() as $row) {
            $map[(int) $row['id']] = $row;
        }
        return $map;
    }

    /**
     * 作者展示名：匿名由调用方处理；有昵称用昵称，否则邮箱脱敏
     *
     * @param array $user 用户行
     * @return string
     */
    private function displayName(array $user): string
    {
        $nickname = trim((string) ($user['nickname'] ?? ''));
        if ($nickname !== '') {
            return $nickname;
        }
        $email = trim((string) ($user['email'] ?? ''));
        if ($email === '' || !str_contains($email, '@')) {
            return 'Customer';
        }
        [$local, $domain] = explode('@', $email, 2);
        $first = mb_substr($local, 0, 1);
        return ($first !== '' ? $first : '*') . '***@' . $domain;
    }

    /**
     * 公开场景作者名脱敏：有昵称保留首字符，否则邮箱本地部分与域名都脱敏
     *
     * @param array $user 用户行（nickname / email）
     * @return string
     */
    private function maskedDisplayName(array $user): string
    {
        $nickname = trim((string) ($user['nickname'] ?? ''));
        if ($nickname !== '') {
            return $this->maskToken($nickname);
        }

        $email = trim((string) ($user['email'] ?? ''));
        if ($email === '' || !str_contains($email, '@')) {
            return 'Customer';
        }

        [$local, $domain] = explode('@', $email, 2);

        return $this->maskToken($local) . '@' . $this->maskDomain($domain);
    }

    /**
     * 保留首字符，其余用 *** 代替（单字符整体隐藏）
     *
     * @param string $value 待脱敏片段
     * @return string
     */
    private function maskToken(string $value): string
    {
        $value = trim($value);
        if ($value === '' || mb_strlen($value) < 2) {
            return '***';
        }

        return mb_substr($value, 0, 1) . '***';
    }

    /**
     * 邮箱域名脱敏：主机名保留首字符，顶级域保留
     *
     * @param string $domain 域名（如 gmail.com）
     * @return string
     */
    private function maskDomain(string $domain): string
    {
        $parts = explode('.', $domain);
        $tld   = count($parts) > 1 ? array_pop($parts) : '';
        $host  = implode('.', $parts) ?: $domain;

        return $this->maskToken($host) . ($tld !== '' ? '.' . $tld : '');
    }

    /**
     * 只保留本站评论图片地址（历史脏数据在这里被过滤掉）
     *
     * @param mixed $images 模型 images_json
     * @return array<int,string>
     */
    private function validImages($images): array
    {
        if (is_string($images)) {
            $images = json_decode($images, true);
        }
        if (!is_array($images)) {
            return [];
        }

        $out = [];
        foreach ($images as $image) {
            if (!is_string($image) || !preg_match(self::IMAGE_PATTERN, $image)) {
                continue;
            }
            if (!in_array($image, $out, true)) {
                $out[] = $image;
            }
            if (count($out) >= self::MAX_IMAGES) {
                break;
            }
        }
        return $out;
    }

    /**
     * 图片入参校验与去重
     *
     * @param mixed $images 提交的图片数组（也接受 JSON 字符串）
     * @return array<int,string>
     * @throws BizException
     */
    private function normalizeImages($images): array
    {
        if ($images === null || $images === '') {
            return [];
        }
        if (is_string($images)) {
            $decoded = json_decode($images, true);
            if (!is_array($decoded)) {
                throw new BizException('图片格式不正确');
            }
            $images = $decoded;
        }
        if (!is_array($images)) {
            throw new BizException('图片格式不正确');
        }

        $out = [];
        foreach ($images as $image) {
            if (!is_string($image)) {
                throw new BizException('图片地址不合法');
            }
            $image = trim($image);
            if ($image === '') {
                continue;
            }
            if (!preg_match(self::IMAGE_PATTERN, $image)) {
                throw new BizException('图片必须是本站上传的评论图片');
            }
            if (!in_array($image, $out, true)) {
                $out[] = $image;
            }
        }

        if (count($out) > self::MAX_IMAGES) {
            throw new BizException('最多上传 ' . self::MAX_IMAGES . ' 张图片');
        }

        return $out;
    }

    /**
     * 去标签后的纯文本（展示时仍由模板 / 前端转义）
     *
     * @param mixed $value 原始输入
     * @return string
     */
    private function plainText($value): string
    {
        if (is_array($value) || is_object($value)) {
            return '';
        }
        return trim(strip_tags((string) $value));
    }

    /**
     * 每页条数收敛到 1-20
     *
     * @param int $size 请求值
     * @return int
     */
    private function clampSize(int $size): int
    {
        if ($size <= 0) {
            return self::PAGE_SIZE;
        }
        return min($size, self::MAX_PAGE_SIZE);
    }

    /**
     * LIKE 通配符转义（配合绑定参数，防止 % _ 干扰筛选）
     *
     * @param string $keyword 关键词
     * @return string
     */
    private function escapeLike(string $keyword): string
    {
        return str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $keyword);
    }

    /**
     * 批量 ID 去重与上限校验
     *
     * @param array $ids 原始 ID 列表
     * @return array<int,int>
     * @throws BizException
     */
    private function normalizeIds(array $ids): array
    {
        $out = [];
        foreach ($ids as $id) {
            $id = (int) $id;
            if ($id > 0) {
                $out[$id] = $id;
            }
        }
        $out = array_values($out);
        if (count($out) > self::MAX_BATCH) {
            throw new BizException('单次最多操作 ' . self::MAX_BATCH . ' 条评论');
        }
        return $out;
    }

    /**
     * 日期筛选项归一化（仅接受 Y-m-d）
     *
     * @param mixed $value 日期字符串
     * @return string 合法时返回 Y-m-d，否则空串
     */
    private function normalizeDate($value): string
    {
        $value = trim((string) $value);
        if ($value === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
            return '';
        }
        return strtotime($value) === false ? '' : $value;
    }

    /**
     * 是否为唯一键冲突
     *
     * @param \Throwable $e 异常
     * @return bool
     */
    private function isDuplicateEntry(\Throwable $e): bool
    {
        if (!($e instanceof PDOException) && !($e instanceof \PDOException)) {
            return false;
        }
        return str_contains($e->getMessage(), 'Duplicate entry')
            || str_contains($e->getMessage(), '1062');
    }
}
