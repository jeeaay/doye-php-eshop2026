<?php
declare (strict_types = 1);

namespace app;

use think\Service;

/**
 * 应用服务类
 */
class AppService extends Service
{
    public function register()
    {
        // 服务注册
    }

    public function boot()
    {
        // 多应用解析会把第一段 URL 当作应用名，语言前缀必须在它之前剥离
        $this->app->event->listen('HttpRun', function () {
            $this->app->middleware->unshift(\app\common\middleware\LocalePrefix::class);
        });
    }
}
