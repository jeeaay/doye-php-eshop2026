<?php
declare(strict_types=1);

namespace app\common\middleware;

use app\common\service\CurrencyService;
use app\common\service\LanguageService;
use app\common\support\LocaleContext;
use think\facade\Cookie;
use think\Request;
use think\Response;

/**
 * 前台 / API 的语言与展示币种引导
 *
 * 这个中间件被 unshift 到全局队列最前面，原因是 think-multi-app 会把 URL 第一段
 * 当作应用名：/ru/products 会被解析成 app=ru 而 404。所以必须在 MultiApp 之前
 * 剥离语言前缀，并同时完成语言/币种解析。
 *
 * 语言优先级：URL 前缀 > ?lang= > Cookie site_locale > Accept-Language > 默认
 * 币种优先级：?currency= > Cookie site_currency > 语种 default_currency > USD
 *
 * 自动跳转只针对首次访问的前台 HTML 请求；爬虫、API、后台、非 GET 一律不跳。
 */
class LocalePrefix
{
    private const COOKIE_TTL = 31536000; // 1 年

    /** 常见爬虫 UA，命中则不自动跳转 */
    private const BOT_PATTERN = '/bot|spider|crawl|slurp|bingpreview|google-inspectiontool|gptbot|claudebot|perplexitybot|applebot|yandex|baidu/i';

    /**
     * @param Request $request
     * @param \Closure $next
     * @return Response
     */
    public function handle(Request $request, \Closure $next)
    {
        $path = trim((string) $request->pathinfo(), '/');
        $segments = $path === '' ? [] : explode('/', $path);
        $first = strtolower((string) ($segments[0] ?? ''));
        $second = strtolower((string) ($segments[1] ?? ''));
        $isApi = $first === 'api';
        $isAdmin = in_array($first, ['admin', 'admin-api'], true);

        // 多语言关闭或国内版：只写入默认上下文，保持单语行为
        if (is_domestic_edition() || !(bool) site_config('i18n.enabled', false)) {
            LocaleContext::setLocale($this->defaultLanguage());
            LocaleContext::setCurrency($this->baseCurrency());
            return $next($request);
        }

        $languages = new LanguageService();
        $currencies = new CurrencyService();
        $defaultLanguage = $languages->default();

        // 1) 剥离语言前缀（在 MultiApp 之前）
        $prefixed = null;
        if (preg_match('/^[a-z]{2}$/', $first)
            && !in_array($second, ['admin', 'admin-api', 'api'], true)) {
            $prefixed = $languages->find($first);
            if ($prefixed) {
                LocaleContext::setPrefix($first);
                array_shift($segments);
                $path = implode('/', $segments);
                $request->setPathinfo($path);
            }
        }

        // 2) 语言解析
        $language = $prefixed
            ?? $this->fromQuery($request, $languages)
            ?? $this->fromCookie($request, $languages)
            ?? $this->fromBrowser($request, $languages)
            ?? $defaultLanguage;
        LocaleContext::setLocale($language);

        // 3) 展示币种
        $currency = $this->resolveCurrency($request, $currencies, $language);
        LocaleContext::setCurrency($currency);

        // 4) 让 ?lang / ?currency 选择在后续请求中保持
        if ($prefixed === null && $request->get('lang', '') !== '') {
            Cookie::set('site_locale', (string) $language['code'], self::COOKIE_TTL);
        }
        if ($request->get('currency', '') !== '') {
            Cookie::set('site_currency', (string) $currency['code'], self::COOKIE_TTL);
        }

        // 5) 首次访问自动跳转（仅前台、非爬虫、无 Cookie）
        if (!$isApi && !$isAdmin
            && $prefixed === null
            && $request->get('lang', '') === ''
            && $request->cookie('site_locale', '') === ''
            && (int) ($language['is_default'] ?? 0) !== 1
            && $this->shouldRedirect($request)) {
            $target = '/' . strtolower((string) $language['code']) . ($path === '' ? '/' : '/' . $path);
            Cookie::set('site_locale', (string) $language['code'], self::COOKIE_TTL);
            return redirect($target)->header(['Vary' => 'Accept-Language, Cookie']);
        }

        $response = $next($request);

        // 根路径内容随语言变化，声明 Vary 避免 CDN 串语种
        if (!$isApi && !$isAdmin && $path === '') {
            $response->header(['Vary' => 'Accept-Language, Cookie']);
        }

        return $response;
    }

    /**
     * 查询参数 ?lang=
     */
    private function fromQuery(Request $request, LanguageService $languages): ?array
    {
        $code = trim((string) $request->get('lang', ''));
        return $code !== '' ? $languages->find($code) : null;
    }

    /**
     * Cookie site_locale
     */
    private function fromCookie(Request $request, LanguageService $languages): ?array
    {
        $code = trim((string) $request->cookie('site_locale', ''));
        return $code !== '' ? $languages->find($code) : null;
    }

    /**
     * Accept-Language：按 q 权重排序后，依次匹配完整标签与主语言
     */
    private function fromBrowser(Request $request, LanguageService $languages): ?array
    {
        if (!(bool) site_config('i18n.auto_detect', true)) {
            return null;
        }

        $header = (string) $request->header('accept-language', '');
        if ($header === '') {
            return null;
        }

        $prefs = [];
        foreach (explode(',', $header) as $part) {
            $pieces = explode(';q=', trim($part));
            $tag = strtolower(trim($pieces[0] ?? ''));
            if ($tag === '') {
                continue;
            }
            $prefs[$tag] = isset($pieces[1]) ? (float) $pieces[1] : 1.0;
        }
        arsort($prefs);

        foreach (array_keys($prefs) as $tag) {
            $candidates = [$tag];
            if (str_contains($tag, '-')) {
                $candidates[] = explode('-', $tag)[0];
            }
            foreach ($candidates as $candidate) {
                $language = $languages->find($candidate);
                if ($language) {
                    return $language;
                }
            }
        }

        return null;
    }

    /**
     * 展示币种解析
     *
     * @param array<string,mixed> $language
     * @return array<string,mixed>
     */
    private function resolveCurrency(Request $request, CurrencyService $currencies, array $language): array
    {
        if (!(bool) site_config('currency.enabled', false)) {
            return $currencies->base();
        }

        $query = trim((string) $request->get('currency', ''));
        if ($query !== '' && ($found = $currencies->find($query))) {
            return $found;
        }

        $cookie = trim((string) $request->cookie('site_currency', ''));
        if ($cookie !== '' && ($found = $currencies->find($cookie))) {
            return $found;
        }

        $default = (string) ($language['default_currency'] ?? '');
        return $default !== '' ? ($currencies->find($default) ?? $currencies->base()) : $currencies->base();
    }

    /**
     * 是否允许自动跳转：仅 GET/HEAD 的 HTML 请求，且不是爬虫
     */
    private function shouldRedirect(Request $request): bool
    {
        if (!$request->isGet() && !$request->isHead()) {
            return false;
        }
        if (!str_contains(strtolower((string) $request->header('accept', '')), 'text/html')) {
            return false;
        }
        $ua = (string) $request->header('user-agent', '');
        return $ua === '' || preg_match(self::BOT_PATTERN, $ua) !== 1;
    }

    /**
     * @return array<string,mixed>
     */
    private function defaultLanguage(): array
    {
        try {
            return (new LanguageService())->default();
        } catch (\Throwable $e) {
            $code = base_locale();
            return [
                'code'             => $code,
                'name'             => $code === 'zh' ? '中文' : '英语',
                'native_name'      => $code === 'zh' ? '中文' : 'English',
                'direction'        => 'ltr',
                'default_currency' => base_currency_code(),
                'is_default'       => 1,
                'status'           => 1,
            ];
        }
    }

    /**
     * @return array<string,mixed>
     */
    private function baseCurrency(): array
    {
        try {
            return (new CurrencyService())->base();
        } catch (\Throwable $e) {
            $code = base_currency_code();
            $isCny = $code === 'CNY';
            return [
                'code'            => $code,
                'name'            => $isCny ? '人民币' : '美元',
                'symbol'          => $isCny ? '¥' : '$',
                'decimals'        => 2,
                'symbol_position' => 'before',
                'symbol_space'    => 0,
                'is_base'         => 1,
                'rate'            => 1,
                'rate_override'   => null,
                'status'          => 1,
            ];
        }
    }
}