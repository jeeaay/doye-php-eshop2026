<?php
declare(strict_types=1);

namespace app\common\command;

use app\common\service\TranslationJobService;
use think\console\Command;
use think\console\Input;
use think\console\input\Option;
use think\console\Output;

/**
 * AI 翻译 worker
 *
 * 用法：
 *   php think translate:work --once
 *   php think translate:work --sleep=3
 *   php think translate:work --limit=20 --once
 */
class TranslateWork extends Command
{
    protected function configure(): void
    {
        $this->setName('translate:work')
            ->setDescription('Consume AI translation jobs')
            ->addOption('once', null, Option::VALUE_NONE, '只处理一轮')
            ->addOption('limit', null, Option::VALUE_REQUIRED, '本次最多处理任务数', '0')
            ->addOption('sleep', null, Option::VALUE_REQUIRED, '队列为空时的休眠秒数', '3');
    }

    protected function execute(Input $input, Output $output): void
    {
        $service = new TranslationJobService();
        $once = (bool) $input->getOption('once');
        $limit = max(0, (int) $input->getOption('limit'));
        $sleep = max(1, (int) $input->getOption('sleep'));
        $processed = 0;

        while (true) {
            if ($limit > 0 && $processed >= $limit) {
                break;
            }

            if ($service->isBudgetExceeded()) {
                $output->writeln('<comment>今日 AI 翻译预算已用完，暂停消费</comment>');
                if ($once) {
                    break;
                }
                sleep(60);
                continue;
            }

            $job = $service->claim();
            if (!$job) {
                if ($once) {
                    break;
                }
                sleep($sleep);
                continue;
            }

            try {
                $service->run($job);
                $processed++;
                $output->writeln('done: #' . $job->id . ' ' . $job->entity_type . '#' . $job->entity_id . ' -> ' . $job->target_lang);
            } catch (\Throwable $e) {
                $service->fail($job, $e);
                $output->writeln('<error>failed: #' . $job->id . ' ' . $e->getMessage() . '</error>');
            }
        }

        $output->writeln('done, processed ' . $processed . ' job(s)');
    }
}