<?php
declare(strict_types=1);

namespace app\common\command;

use app\common\service\TranslationJobService;
use think\console\Command;
use think\console\Input;
use think\console\input\Option;
use think\console\Output;

/**
 * 批量补全缺失翻译
 *
 * 用法：
 *   php think translate:backfill --type=all --limit=100
 *   php think translate:backfill --type=product --lang=ru,fr --force
 */
class TranslateBackfill extends Command
{
    protected function configure(): void
    {
        $this->setName('translate:backfill')
            ->setDescription('Enqueue missing translations')
            ->addOption('type', null, Option::VALUE_REQUIRED, 'product|category|brand|page|all', 'all')
            ->addOption('lang', null, Option::VALUE_REQUIRED, '目标语种，逗号分隔；留空表示全部启用语种', '')
            ->addOption('limit', null, Option::VALUE_REQUIRED, '每类实体最多处理数量', '100')
            ->addOption('force', null, Option::VALUE_NONE, '忽略 source_hash，强制重新翻译');
    }

    protected function execute(Input $input, Output $output): void
    {
        $type = (string) $input->getOption('type');
        if (!in_array($type, ['product', 'category', 'brand', 'page', 'all'], true)) {
            $output->writeln('<error>type 只能是 product|category|brand|page|all</error>');
            return;
        }

        $langOption = trim((string) $input->getOption('lang'));
        $locales = $langOption === '' ? [] : array_values(array_filter(array_map('trim', explode(',', $langOption))));
        $limit = max(1, (int) $input->getOption('limit'));
        $force = (bool) $input->getOption('force');

        $service = new TranslationJobService();
        $result = $service->enqueueMissing($type, $locales, $limit, $force);
        $output->writeln(sprintf('entities=%d jobs=%d', $result['entities'], $result['jobs']));
    }
}