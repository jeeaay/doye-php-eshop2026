<?php
declare(strict_types=1);

namespace app\common\command;

use app\common\exception\BizException;
use app\common\service\CurrencyService;
use think\console\Command;
use think\console\Input;
use think\console\input\Option;
use think\console\Output;

/**
 * 汇率同步
 *
 * 用法：
 *   php think currency:sync
 *   php think currency:sync --currency=EUR
 *   php think currency:sync --dry-run
 */
class CurrencySync extends Command
{
    protected function configure(): void
    {
        $this->setName('currency:sync')
            ->setDescription('Sync display currency rates from free providers')
            ->addOption('currency', null, Option::VALUE_REQUIRED, '只同步指定币种，如 EUR', '')
            ->addOption('dry-run', null, Option::VALUE_NONE, '只拉取并校验，不写库');
    }

    protected function execute(Input $input, Output $output): void
    {
        $service = new CurrencyService();
        $dryRun = (bool) $input->getOption('dry-run');
        $code = strtoupper(trim((string) $input->getOption('currency')));

        try {
            if ($code !== '') {
                $result = $service->syncOne($code, $dryRun);
                $output->writeln(sprintf(
                    '%s status=%s rate=%s source=%s%s',
                    $code,
                    $result['status'],
                    $result['rate'],
                    $result['source'] ?? '',
                    $result['message'] !== '' ? ' message=' . $result['message'] : ''
                ));
                return;
            }

            $result = $service->syncAll($dryRun);
            $output->writeln(sprintf(
                'source=%s updated=%d rejected=%d%s',
                $result['source'],
                $result['updated'],
                $result['rejected'],
                $dryRun ? ' (dry-run)' : ''
            ));
            foreach ($result['alerts'] as $alert) {
                $output->writeln('<comment>' . $alert . '</comment>');
            }
        } catch (BizException $e) {
            $output->writeln('<error>' . $e->getMessage() . '</error>');
        } catch (\Throwable $e) {
            $output->writeln('<error>汇率同步失败：' . $e->getMessage() . '</error>');
        }
    }
}