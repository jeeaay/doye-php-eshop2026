<?php
declare(strict_types=1);

namespace app\common\command;

use app\common\service\PricingService;
use think\console\Command;
use think\console\Input;
use think\console\Output;

/**
 * 展示价换算自测（不依赖数据库）
 */
class CurrencySelftest extends Command
{
    protected function configure(): void
    {
        $this->setName('currency:selftest')->setDescription('Verify display price rounding');
    }

    protected function execute(Input $input, Output $output): void
    {
        $pricing = new PricingService();
        $usd = ['code' => 'USD', 'symbol' => '$', 'decimals' => 2, 'symbol_position' => 'before', 'symbol_space' => 0, 'is_base' => 1, 'rate' => 1, 'rate_override' => null];
        $eur = ['code' => 'EUR', 'symbol' => '€', 'decimals' => 2, 'symbol_position' => 'before', 'symbol_space' => 0, 'is_base' => 0, 'rate' => 0.895934, 'rate_override' => null];
        $jpy = ['code' => 'JPY', 'symbol' => '¥', 'decimals' => 0, 'symbol_position' => 'before', 'symbol_space' => 0, 'is_base' => 0, 'rate' => 157.881601, 'rate_override' => null];
        $eurOverride = array_merge($eur, ['rate_override' => 0.9]);

        $cases = [
            ['USD 19.99', $pricing->convert('19.99', $usd), '19.99'],
            ['EUR 19.99', $pricing->convert('19.99', $eur), '17.91'],
            ['EUR override', $pricing->convert('19.99', $eurOverride), '17.99'],
            ['JPY 19.99', $pricing->convert('19.99', $jpy), '3156'],
            ['format EUR', $pricing->formatAmount('17.91', $eur), '€17.91'],
            ['format JPY', $pricing->formatAmount('3156', $jpy), '¥3,156'],
        ];

        $failed = 0;
        foreach ($cases as [$name, $actual, $expected]) {
            $ok = $actual === $expected;
            $output->writeln(($ok ? 'PASS' : 'FAIL') . ' ' . $name . ' => ' . $actual . ' (expected ' . $expected . ')');
            if (!$ok) {
                $failed++;
            }
        }

        $output->writeln($failed === 0 ? 'ALL PASSED' : 'FAILED');
        if ($failed > 0) {
            exit(1);
        }
    }
}