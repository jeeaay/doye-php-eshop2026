<?php
declare (strict_types = 1);

namespace app\common\model;

class Category extends BaseModel
{
    protected $name = 'category';
    protected $autoWriteTimestamp = false;

    public function parent()
    {
        return $this->belongsTo(Category::class, 'parent_id');
    }

    public function children()
    {
        return $this->hasMany(Category::class, 'parent_id');
    }

    public function products()
    {
        return $this->hasMany(Product::class);
    }

    /**
     * 分类翻译
     *
     * @return \think\model\relation\HasMany
     */
    public function translations()
    {
        return $this->hasMany(CategoryTranslation::class, 'category_id');
    }
}
