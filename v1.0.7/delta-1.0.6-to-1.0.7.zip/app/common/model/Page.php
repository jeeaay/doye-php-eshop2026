<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 站点单页模型（CMS）
 *
 * 属于平台级内容，不带商户维度，因此直接继承 BaseModel 而非 MerchantModel。
 */
class Page extends BaseModel
{
    protected $name = 'page';

    protected $autoWriteTimestamp = 'datetime';

    /**
     * 单页翻译
     *
     * @return \think\model\relation\HasMany
     */
    public function translations()
    {
        return $this->hasMany(PageTranslation::class, 'page_id');
    }
}
