<?php
declare (strict_types = 1);

namespace app\common\model;

use think\model\concern\SoftDelete;

class Product extends MerchantModel
{
    use SoftDelete;

    protected $name = 'product';
    protected $autoWriteTimestamp = 'datetime';
    protected $deleteTime = 'delete_time';
    protected $json = ['images_json', 'video_meta_json', 'specs_json'];

    public function merchant()
    {
        return $this->belongsTo(Merchant::class);
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function skus()
    {
        return $this->hasMany(ProductSku::class);
    }

    /**
     * 关联品牌（可为空，表示无品牌）
     *
     * @return \think\model\relation\BelongsTo
     */
    public function brand()
    {
        return $this->belongsTo(Brand::class);
    }

    /**
     * 翻译（按语种取一行）
     *
     * @return \think\model\relation\HasMany
     */
    public function translations()
    {
        return $this->hasMany(ProductTranslation::class, 'product_id');
    }
}
