<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * AI 翻译任务
 */
class TranslationJob extends BaseModel
{
    protected $name = 'translation_job';
    protected $autoWriteTimestamp = 'datetime';
    protected $json = ['fields_json'];
    protected $jsonAssoc = true;

    public const STATUS_PENDING = 'pending';
    public const STATUS_RUNNING = 'running';
    public const STATUS_DONE = 'done';
    public const STATUS_FAILED = 'failed';
    public const STATUS_DEAD = 'dead';
    public const STATUS_SKIPPED = 'skipped';
}