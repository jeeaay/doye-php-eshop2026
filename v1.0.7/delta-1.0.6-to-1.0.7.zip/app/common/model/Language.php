<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 语种注册表
 */
class Language extends BaseModel
{
    protected $name = 'language';
    protected $autoWriteTimestamp = 'datetime';

    /**
     * 当前启用的语种（按 sort 排序）
     *
     * @return \think\Collection
     */
    public static function enabled()
    {
        return self::where('status', 1)->order('sort')->order('id')->select();
    }

    /**
     * 默认语种（en）
     *
     * @return Language|null
     */
    public static function fallback(): ?self
    {
        return self::where('is_default', 1)->find();
    }
}