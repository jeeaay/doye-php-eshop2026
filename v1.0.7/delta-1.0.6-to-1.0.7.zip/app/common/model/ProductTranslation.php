<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 商品翻译（每个商品每个语种一行）
 */
class ProductTranslation extends BaseModel
{
    protected $name = 'product_translation';
    protected $autoWriteTimestamp = 'datetime';
    protected $json = ['specs_json'];
    protected $jsonAssoc = true;

    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }
}