<?php
declare (strict_types = 1);

namespace app\common\model;

/**
 * 品牌模型
 *
 * 继承 MerchantModel 以复用 MerchantScope：非超管查询时自动按 merchant_id 过滤，
 * 天然实现「同商户全部成员可见」。写权限（创建者/商户管理员/超管）由服务层显式判定。
 */
class Brand extends MerchantModel
{
    protected $name = 'brand';
    protected $autoWriteTimestamp = 'datetime';

    /**
     * 归属商户
     *
     * @return \think\model\relation\BelongsTo
     */
    public function merchant()
    {
        return $this->belongsTo(Merchant::class);
    }

    /**
     * 创建者（后台账号）
     *
     * @return \think\model\relation\BelongsTo
     */
    public function creator()
    {
        return $this->belongsTo(Admin::class, 'creator_id');
    }

    /**
     * 品牌下的商品
     *
     * @return \think\model\relation\HasMany
     */
    public function products()
    {
        return $this->hasMany(Product::class);
    }

    /**
     * 品牌翻译
     *
     * @return \think\model\relation\HasMany
     */
    public function translations()
    {
        return $this->hasMany(BrandTranslation::class, 'brand_id');
    }
}
