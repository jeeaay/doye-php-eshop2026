<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 单页翻译
 */
class PageTranslation extends BaseModel
{
    protected $name = 'page_translation';
    protected $autoWriteTimestamp = 'datetime';

    public function page()
    {
        return $this->belongsTo(Page::class, 'page_id');
    }
}