<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 品牌翻译
 */
class BrandTranslation extends BaseModel
{
    protected $name = 'brand_translation';
    protected $autoWriteTimestamp = 'datetime';

    public function brand()
    {
        return $this->belongsTo(Brand::class, 'brand_id');
    }
}