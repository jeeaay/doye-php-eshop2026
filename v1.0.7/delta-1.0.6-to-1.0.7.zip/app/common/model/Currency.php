<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 展示币种（只影响前台参考价，订单/支付/结算始终 USD）
 */
class Currency extends BaseModel
{
    protected $name = 'currency';
    protected $autoWriteTimestamp = 'datetime';

    /**
     * 当前启用的展示币种
     *
     * @return \think\Collection
     */
    public static function enabled()
    {
        return self::where('status', 1)->order('sort')->order('id')->select();
    }

    /**
     * 基准币种（USD）
     *
     * @return Currency|null
     */
    public static function base(): ?self
    {
        return self::where('is_base', 1)->find();
    }

    /**
     * 实际使用的展示汇率：人工覆盖优先
     *
     * @return string
     */
    public function effectiveRate(): string
    {
        if ((int) $this->is_base === 1) {
            return '1';
        }
        $rate = $this->rate_override ?? $this->rate;
        return (string) $rate;
    }
}