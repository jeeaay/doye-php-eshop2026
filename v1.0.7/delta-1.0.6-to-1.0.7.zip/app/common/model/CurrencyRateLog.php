<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 汇率同步历史
 */
class CurrencyRateLog extends BaseModel
{
    protected $name = 'currency_rate_log';
    protected $autoWriteTimestamp = 'datetime';
    protected $updateTime = false;
}