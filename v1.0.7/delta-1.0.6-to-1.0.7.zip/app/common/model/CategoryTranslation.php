<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 分类翻译
 */
class CategoryTranslation extends BaseModel
{
    protected $name = 'category_translation';
    protected $autoWriteTimestamp = 'datetime';

    public function category()
    {
        return $this->belongsTo(Category::class, 'category_id');
    }
}