<?php
declare(strict_types=1);

namespace app\common\support;

/**
 * 当前请求的语言 / 展示币种上下文
 *
 * 由 Locale 中间件写入，Service / 模板 / 控制器只读。
 * 使用数组而不是模型，便于直接缓存与跨层传递。
 */
class LocaleContext
{
    /** @var array<string,mixed>|null */
    private static ?array $locale = null;

    /** @var array<string,mixed>|null */
    private static ?array $currency = null;

    /** @var string 原始 URL 上的语言前缀（已被提前剥离） */
    private static string $prefix = '';

    public static function setPrefix(string $prefix): void
    {
        self::$prefix = strtolower(trim($prefix));
    }

    public static function prefix(): string
    {
        return self::$prefix;
    }

    /**
     * @param array<string,mixed> $locale
     */
    public static function setLocale(array $locale): void
    {
        self::$locale = $locale;
    }

    /**
     * @return array<string,mixed>
     */
    public static function locale(): array
    {
        return self::$locale ?? self::fallbackLocale();
    }

    public static function localeCode(): string
    {
        return (string) (self::locale()['code'] ?? 'en');
    }

    /**
     * @param array<string,mixed> $currency
     */
    public static function setCurrency(array $currency): void
    {
        self::$currency = $currency;
    }

    /**
     * @return array<string,mixed>
     */
    public static function currency(): array
    {
        return self::$currency ?? self::fallbackCurrency();
    }

    public static function currencyCode(): string
    {
        return (string) (self::currency()['code'] ?? 'USD');
    }

    /**
     * 重置（测试 / 命令行复用进程时使用）
     */
    public static function reset(): void
    {
        self::$locale = null;
        self::$currency = null;
        self::$prefix = '';
    }

    /**
     * @return array<string,mixed>
     */
    private static function fallbackLocale(): array
    {
        $code = function_exists('base_locale') ? base_locale() : 'en';
        return [
            'code'             => $code,
            'name'             => $code === 'zh' ? '中文' : '英语',
            'native_name'      => $code === 'zh' ? '中文' : 'English',
            'direction'        => 'ltr',
            'default_currency' => $code === 'zh' ? 'CNY' : 'USD',
            'is_default'       => 1,
            'status'           => 1,
        ];
    }

    /**
     * @return array<string,mixed>
     */
    private static function fallbackCurrency(): array
    {
        $code = function_exists('base_currency_code') ? base_currency_code() : 'USD';
        $isCny = $code === 'CNY';
        return [
            'code'            => $code,
            'name'            => $isCny ? '人民币' : '美元',
            'symbol'          => $isCny ? '¥' : '$',
            'decimals'        => 2,
            'symbol_position' => 'before',
            'symbol_space'    => 0,
            'is_base'         => 1,
            'rate'            => 1,
            'rate_override'   => null,
            'status'          => 1,
        ];
    }
}