<?php
declare(strict_types=1);

namespace app\common\lib\translation;

use RuntimeException;

/**
 * OpenAI 兼容协议的翻译提供者
 *
 * 后台只需填写 base_url / api_key / model，即可对接 DeepSeek、OpenAI、通义等兼容端点。
 */
class OpenAiCompatibleProvider implements TranslationProviderInterface
{
    private const LANG_NAMES = [
        'en' => 'English',
        'zh' => 'Simplified Chinese',
        'ru' => 'Russian',
        'fr' => 'French',
        'ar' => 'Arabic',
        'ja' => 'Japanese',
        'it' => 'Italian',
        'de' => 'German',
        'pt' => 'Portuguese',
        'es' => 'Spanish',
    ];

    /**
     * @param array<string,mixed> $config translation.* 配置
     */
    public function __construct(private array $config)
    {
    }

    /**
     * @inheritDoc
     */
    public function translate(array $fields, string $sourceLang, string $targetLang, array $options = []): array
    {
        $baseUrl = trim((string) ($this->config['base_url'] ?? ''));
        $apiKey = trim((string) ($this->config['api_key'] ?? ''));
        $model = trim((string) ($this->config['model'] ?? ''));
        if ($baseUrl === '' || $apiKey === '' || $model === '') {
            throw new RuntimeException('AI 翻译未配置：请填写接口地址、API Key 与模型 ID');
        }

        $source = self::LANG_NAMES[strtolower($sourceLang)] ?? $sourceLang;
        $target = self::LANG_NAMES[strtolower($targetLang)] ?? $targetLang;

        $system = "You are a professional e-commerce translator. Translate the JSON values from {$source} to {$target}.\n"
            . "Rules:\n"
            . "- Return ONLY a valid JSON object with exactly the same keys and structure as the input.\n"
            . "- Translate human-readable text; keep HTML tags and attributes, URLs, numbers, units, SKU codes and {{placeholders}} unchanged.\n"
            . "- Do not add explanations, marketing claims or content not present in the source.\n"
            . "- Keep brand names and product codes untranslated unless they are ordinary words.\n"
            . "- For arrays, keep the same order and the same number of items.\n"
            . "- Empty strings stay empty.";

        $body = [
            'model'       => $model,
            'temperature' => (float) ($this->config['temperature'] ?? 0.3),
            'messages'    => [
                ['role' => 'system', 'content' => $system],
                ['role' => 'user', 'content' => json_encode($fields, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)],
            ],
        ];

        $url = $this->endpoint($baseUrl);
        $payload = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $timeout = max(10, (int) ($options['timeout'] ?? 60));

        $ch = curl_init($url);
        \app\common\lib\CurlTls::apply($ch);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Bearer ' . $apiKey,
                'Content-Type: application/json',
                'Accept: application/json',
            ],
        ]);
        $response = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($response === false || $error !== '') {
            throw new RuntimeException('AI 接口请求失败：' . ($error !== '' ? $error : '未知网络错误'));
        }
        if ($status < 200 || $status >= 300) {
            throw new RuntimeException('AI 接口返回 HTTP ' . $status . '：' . mb_substr((string) $response, 0, 300));
        }

        $data = json_decode((string) $response, true);
        if (!is_array($data)) {
            throw new RuntimeException('AI 接口返回的不是 JSON');
        }
        $content = (string) ($data['choices'][0]['message']['content'] ?? '');
        if ($content === '') {
            throw new RuntimeException('AI 接口未返回翻译内容');
        }

        $translated = $this->decodeJsonObject($content);
        if (!is_array($translated)) {
            throw new RuntimeException('AI 返回内容无法解析为 JSON 对象');
        }

        $usage = (array) ($data['usage'] ?? []);
        return [
            'fields' => $translated,
            'usage'  => [
                'prompt_tokens'     => (int) ($usage['prompt_tokens'] ?? 0),
                'completion_tokens' => (int) ($usage['completion_tokens'] ?? 0),
            ],
            'raw'    => $content,
        ];
    }

    /**
     * 拼接 /chat/completions 地址
     */
    private function endpoint(string $baseUrl): string
    {
        $baseUrl = rtrim($baseUrl, '/');
        if (str_ends_with($baseUrl, '/chat/completions')) {
            return $baseUrl;
        }
        if (preg_match('~/v\d+$~i', $baseUrl)) {
            return $baseUrl . '/chat/completions';
        }
        return $baseUrl . '/v1/chat/completions';
    }

    /**
     * 从模型输出里提取 JSON（兼容 ```json 代码块与前后说明）
     *
     * @return array<string,mixed>|null
     */
    private function decodeJsonObject(string $content): ?array
    {
        $text = trim($content);
        $text = preg_replace('/^```(?:json)?\s*/i', '', $text) ?? $text;
        $text = preg_replace('/\s*```$/', '', $text) ?? $text;

        $start = strpos($text, '{');
        $end = strrpos($text, '}');
        if ($start === false || $end === false || $end <= $start) {
            return null;
        }

        $json = substr($text, $start, $end - $start + 1);
        $decoded = json_decode($json, true);
        return is_array($decoded) ? $decoded : null;
    }
}