<?php
declare(strict_types=1);

namespace app\common\lib\translation;

/**
 * 翻译提供者接口
 */
interface TranslationProviderInterface
{
    /**
     * 翻译一组字段
     *
     * @param array<string,mixed> $fields 源字段（键名必须原样返回）
     * @param string $sourceLang 源语言
     * @param string $targetLang 目标语言
     * @param array<string,mixed> $options 额外参数
     * @return array{fields:array<string,mixed>,usage:array<string,int>,raw:string}
     */
    public function translate(array $fields, string $sourceLang, string $targetLang, array $options = []): array;
}