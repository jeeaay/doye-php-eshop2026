<?php
declare (strict_types = 1);

namespace app\common\lib\payment;

use app\common\exception\BizException;

class PaymentHttpClient
{
    /**
     * @return array{status:int, body:string, json:?array, headers:array<string,string>}
     */
    public static function request(
        string $method,
        string $url,
        array $headers = [],
        ?string $body = null,
        int $timeout = 30
    ): array {
        $ch = curl_init($url);
        \app\common\lib\CurlTls::apply($ch);
        $headerLines = [];
        foreach ($headers as $name => $value) {
            $headerLines[] = $name . ': ' . $value;
        }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST  => strtoupper($method),
            CURLOPT_HTTPHEADER     => $headerLines,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_HEADER         => true,
            CURLOPT_FOLLOWLOCATION => false,
        ]);
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }
        $response = curl_exec($ch);
        if ($response === false) {
            $error = curl_error($ch);
            throw new BizException('支付网关连接失败: ' . $error);
        }
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $headerSize = (int) curl_getinfo($ch, CURLINFO_HEADER_SIZE);

        $rawHeaders = substr($response, 0, $headerSize);
        $responseBody = substr($response, $headerSize);
        $parsedHeaders = [];
        foreach (preg_split('/\r?\n/', $rawHeaders) ?: [] as $line) {
            if (str_contains($line, ':')) {
                [$name, $value] = explode(':', $line, 2);
                $parsedHeaders[strtolower(trim($name))] = trim($value);
            }
        }
        $json = json_decode($responseBody, true);

        return [
            'status'  => $status,
            'body'    => $responseBody,
            'json'    => is_array($json) ? $json : null,
            'headers' => $parsedHeaders,
        ];
    }

    public static function assertSuccess(array $response, string $gateway): array
    {
        if ($response['status'] >= 200 && $response['status'] < 300) {
            return is_array($response['json']) ? $response['json'] : [];
        }
        $data = is_array($response['json']) ? $response['json'] : [];
        $message = (string) (
            $data['error']['message']
            ?? $data['message']
            ?? $data['error_description']
            ?? $data['error']
            ?? ('HTTP ' . $response['status'])
        );
        throw new BizException($gateway . '请求失败: ' . mb_substr($message, 0, 200));
    }
}