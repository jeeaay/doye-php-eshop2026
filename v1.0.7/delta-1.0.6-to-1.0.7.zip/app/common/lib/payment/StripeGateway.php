<?php
declare (strict_types = 1);

namespace app\common\lib\payment;

use app\common\exception\BizException;
use app\common\model\OrderPay;

class StripeGateway implements PaymentGatewayInterface
{
    private const API_BASE = 'https://api.stripe.com';

    public function createPayment(OrderPay $pay, array $config, array $context): array
    {
        $this->assertConfig($config);
        $currency = 'usd';
        $amount = (int) round((float) $pay->total_amount * 100);
        if ($amount <= 0) {
            throw new BizException('Stripe 支付金额无效');
        }
        $successQuery = ['order_pay_id' => (string) $pay->id];
        if (!str_contains((string) $config['success_url'], '{CHECKOUT_SESSION_ID}')) {
            $successQuery['session_id'] = '{CHECKOUT_SESSION_ID}';
        }
        $successUrl = $this->appendQuery((string) $config['success_url'], $successQuery);
        $body = http_build_query([
            'mode'                => 'payment',
            'success_url'         => $successUrl,
            'cancel_url'          => (string) $config['cancel_url'],
            'client_reference_id' => (string) $pay->id,
            'metadata'            => ['order_pay_id' => (string) $pay->id],
            'line_items'          => [[
                'quantity'   => 1,
                'price_data' => [
                    'currency'     => $currency,
                    'unit_amount'  => $amount,
                    'product_data' => ['name' => mb_substr('订单支付 ' . $pay->id, 0, 120)],
                ],
            ]],
        ], '', '&', PHP_QUERY_RFC3986);

        $response = PaymentHttpClient::request('POST', self::API_BASE . '/v1/checkout/sessions', [
            'Authorization' => 'Bearer ' . $config['secret_key'],
            'Content-Type'  => 'application/x-www-form-urlencoded',
            'Accept'        => 'application/json',
            'User-Agent'    => 'b2cshop/1.0',
        ], $body);
        $session = PaymentHttpClient::assertSuccess($response, 'Stripe');
        $url = (string) ($session['url'] ?? '');
        if ($url === '') {
            throw new BizException('Stripe 未返回支付跳转地址');
        }
        return [
            'type'       => 'redirect',
            'url'        => $url,
            'session_id' => (string) ($session['id'] ?? ''),
            'trade_no'   => (string) ($session['id'] ?? ''),
        ];
    }

    public function verifyNotify(array $headers, string $rawBody, array $config): array
    {
        $this->assertConfig($config);
        $headers = array_change_key_case($headers, CASE_LOWER);
        $signatureHeader = (string) ($headers['stripe-signature'] ?? '');
        if ($signatureHeader === '') {
            throw new BizException('Stripe webhook 缺少签名');
        }
        $timestamp = null;
        $signatures = [];
        foreach (explode(',', $signatureHeader) as $part) {
            $pair = explode('=', trim($part), 2);
            if (count($pair) !== 2) {
                continue;
            }
            if ($pair[0] === 't') {
                $timestamp = (int) $pair[1];
            } elseif ($pair[0] === 'v1') {
                $signatures[] = $pair[1];
            }
        }
        if (!$timestamp || !$signatures) {
            throw new BizException('Stripe webhook 签名格式无效');
        }
        if (abs(time() - $timestamp) > 300) {
            throw new BizException('Stripe webhook 时间戳超出允许范围');
        }
        $expected = hash_hmac('sha256', $timestamp . '.' . $rawBody, (string) $config['webhook_secret']);
        $verified = false;
        foreach ($signatures as $signature) {
            if (hash_equals($expected, $signature)) {
                $verified = true;
                break;
            }
        }
        if (!$verified) {
            throw new BizException('Stripe webhook 验签失败');
        }

        $event = json_decode($rawBody, true);
        if (!is_array($event)) {
            throw new BizException('Stripe webhook 数据无效');
        }
        $type = (string) ($event['type'] ?? '');
        if (!in_array($type, ['checkout.session.completed', 'checkout.session.async_payment_succeeded'], true)) {
            return ['ignored' => true, 'raw' => $event];
        }
        $session = $event['data']['object'] ?? [];
        if (!is_array($session)) {
            throw new BizException('Stripe webhook 缺少 session 数据');
        }
        $paymentStatus = (string) ($session['payment_status'] ?? '');
        if (!in_array($paymentStatus, ['paid', 'no_payment_required'], true)) {
            return ['ignored' => true, 'raw' => $event];
        }
        $outTradeNo = (string) ($session['client_reference_id'] ?? '');
        if ($outTradeNo === '') {
            $outTradeNo = (string) ($session['metadata']['order_pay_id'] ?? '');
        }
        return [
            'out_trade_no' => $outTradeNo,
            'trade_no'     => (string) ($session['payment_intent'] ?? $session['id'] ?? ''),
            'amount_minor' => isset($session['amount_total']) ? (int) $session['amount_total'] : null,
            'currency'     => isset($session['currency']) ? strtoupper((string) $session['currency']) : null,
            'paid_at'      => null,
            'raw'          => $event,
        ];
    }

    public function testConnection(array $config): string
    {
        $this->assertConfig($config);
        $response = PaymentHttpClient::request('GET', self::API_BASE . '/v1/balance', [
            'Authorization' => 'Bearer ' . $config['secret_key'],
            'Accept'        => 'application/json',
            'User-Agent'    => 'b2cshop/1.0',
        ]);
        PaymentHttpClient::assertSuccess($response, 'Stripe');
        $mode = str_starts_with((string) $config['secret_key'], 'sk_live_') ? 'live' : 'test';
        return 'Stripe 连接成功，当前密钥类型：' . $mode;
    }

    private function assertConfig(array $config): void
    {
        foreach (['secret_key', 'webhook_secret', 'success_url', 'cancel_url'] as $key) {
            if (trim((string) ($config[$key] ?? '')) === '') {
                throw new BizException('Stripe 配置不完整：' . $key);
            }
        }
    }

    private function appendQuery(string $url, array $query): string
    {
        $separator = str_contains($url, '?') ? '&' : '?';
        return $url . $separator . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
    }
}