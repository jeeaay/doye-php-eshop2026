<?php
declare (strict_types = 1);

namespace app\common\lib\payment;

use app\common\exception\BizException;
use app\common\model\OrderPay;

class PaypalGateway implements PaymentGatewayInterface
{
    private const LIVE_BASE = 'https://api-m.paypal.com';
    private const SANDBOX_BASE = 'https://api-m.sandbox.paypal.com';

    public function createPayment(OrderPay $pay, array $config, array $context): array
    {
        $this->assertConfig($config);
        $currency = 'USD';
        $body = [
            'intent'         => 'CAPTURE',
            'purchase_units' => [[
                'reference_id' => (string) $pay->id,
                'custom_id'    => (string) $pay->id,
                'description'  => mb_substr('订单支付 ' . $pay->id, 0, 127),
                'amount'       => [
                    'currency_code' => $currency,
                    'value'         => number_format((float) $pay->total_amount, 2, '.', ''),
                ],
            ]],
            'application_context' => [
                'brand_name'  => 'B2C Shop',
                'user_action' => 'PAY_NOW',
                'return_url'  => (string) $config['return_url'],
                'cancel_url'  => (string) $config['cancel_url'],
            ],
        ];
        $response = $this->request($config, 'POST', '/v2/checkout/orders', $body);
        $order = PaymentHttpClient::assertSuccess($response, 'PayPal');
        $approveUrl = '';
        foreach ((array) ($order['links'] ?? []) as $link) {
            if (($link['rel'] ?? '') === 'approve') {
                $approveUrl = (string) ($link['href'] ?? '');
                break;
            }
        }
        if ($approveUrl === '') {
            throw new BizException('PayPal 未返回 approve 链接');
        }
        $orderId = (string) ($order['id'] ?? '');
        return [
            'type'     => 'redirect',
            'url'      => $approveUrl,
            'order_id' => $orderId,
            'trade_no' => $orderId,
        ];
    }

    public function verifyNotify(array $headers, string $rawBody, array $config): array
    {
        $this->assertConfig($config);
        $headers = array_change_key_case($headers, CASE_LOWER);
        $event = json_decode($rawBody, true);
        if (!is_array($event)) {
            throw new BizException('PayPal webhook 数据无效');
        }
        $verification = $this->request($config, 'POST', '/v1/notifications/verify-webhook-signature', [
            'auth_algo'         => (string) ($headers['paypal-auth-algo'] ?? ''),
            'cert_url'          => (string) ($headers['paypal-cert-url'] ?? ''),
            'transmission_id'   => (string) ($headers['paypal-transmission-id'] ?? ''),
            'transmission_sig'  => (string) ($headers['paypal-transmission-sig'] ?? ''),
            'transmission_time' => (string) ($headers['paypal-transmission-time'] ?? ''),
            'webhook_id'        => (string) $config['webhook_id'],
            'webhook_event'     => $event,
        ]);
        $verified = $this->requestJson($verification, 'PayPal');
        if (($verified['verification_status'] ?? '') !== 'SUCCESS') {
            throw new BizException('PayPal webhook 验签失败');
        }

        $type = (string) ($event['type'] ?? '');
        $resource = $event['resource'] ?? [];
        if (!is_array($resource)) {
            return ['ignored' => true, 'raw' => $event];
        }

        if ($type === 'CHECKOUT.ORDER.APPROVED') {
            $paypalOrderId = (string) ($resource['id'] ?? '');
            if ($paypalOrderId === '') {
                throw new BizException('PayPal webhook 缺少订单号');
            }
            $capture = $this->captureOrder($config, $paypalOrderId);
            return $this->normalizeCapture($capture, $event, $paypalOrderId);
        }

        if ($type === 'PAYMENT.CAPTURE.COMPLETED') {
            $customId = (string) ($resource['custom_id'] ?? '');
            $orderId = (string) ($resource['supplementary_data']['related_ids']['order_id'] ?? '');
            $amount = $resource['amount'] ?? [];
            if ($customId === '' && $orderId === '') {
                return ['ignored' => true, 'raw' => $event];
            }
            return [
                'out_trade_no' => $customId,
                'trade_no'     => $orderId !== '' ? $orderId : (string) ($resource['id'] ?? ''),
                'amount_minor' => isset($amount['value']) ? (int) round((float) $amount['value'] * 100) : null,
                'currency'     => isset($amount['currency_code']) ? (string) $amount['currency_code'] : null,
                'paid_at'      => isset($resource['create_time']) ? (string) $resource['create_time'] : null,
                'raw'          => $event,
            ];
        }

        return ['ignored' => true, 'raw' => $event];
    }

    public function testConnection(array $config): string
    {
        $this->assertConfig($config);
        $token = $this->accessToken($config);
        if ($token === '') {
            throw new BizException('PayPal 未返回 access token');
        }
        return 'PayPal 连接成功，环境：' . (!empty($config['_test_mode']) ? 'sandbox' : 'live');
    }

    private function normalizeCapture(array $capture, array $event, string $paypalOrderId): array
    {
        $unit = $capture['purchase_units'][0] ?? [];
        $cap = $unit['payments']['captures'][0] ?? [];
        if (($cap['status'] ?? '') !== 'COMPLETED') {
            throw new BizException('PayPal 订单未完成支付');
        }
        $amount = $cap['amount'] ?? [];
        $customId = (string) ($cap['custom_id'] ?? ($unit['custom_id'] ?? ''));
        return [
            'out_trade_no' => $customId,
            'trade_no'     => $paypalOrderId,
            'amount_minor' => isset($amount['value']) ? (int) round((float) $amount['value'] * 100) : null,
            'currency'     => isset($amount['currency_code']) ? (string) $amount['currency_code'] : null,
            'paid_at'      => isset($cap['create_time']) ? (string) $cap['create_time'] : null,
            'raw'          => $event,
        ];
    }

    private function captureOrder(array $config, string $paypalOrderId): array
    {
        $response = $this->request(
            $config,
            'POST',
            '/v2/checkout/orders/' . rawurlencode($paypalOrderId) . '/capture',
            new \stdClass(),
            ['PayPal-Request-Id' => 'capture-' . $paypalOrderId]
        );
        return $this->requestJson($response, 'PayPal');
    }

    private function accessToken(array $config): string
    {
        $response = PaymentHttpClient::request(
            'POST',
            $this->baseUrl($config) . '/v1/oauth2/token',
            [
                'Authorization' => 'Basic ' . base64_encode($config['client_id'] . ':' . $config['client_secret']),
                'Content-Type'  => 'application/x-www-form-urlencoded',
                'Accept'        => 'application/json',
                'User-Agent'    => 'b2cshop/1.0',
            ],
            'grant_type=client_credentials'
        );
        $data = PaymentHttpClient::assertSuccess($response, 'PayPal');
        return (string) ($data['access_token'] ?? '');
    }

    private function request(
        array $config,
        string $method,
        string $path,
        array|object|null $body = null,
        array $extraHeaders = []
    ): array {
        $token = $this->accessToken($config);
        $bodyString = $body === null ? null : (string) json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $headers = array_merge([
            'Authorization' => 'Bearer ' . $token,
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/json',
            'User-Agent'    => 'b2cshop/1.0',
        ], $extraHeaders);
        return PaymentHttpClient::request(
            $method,
            $this->baseUrl($config) . $path,
            $headers,
            $bodyString
        );
    }

    private function requestJson(array $response, string $gateway): array
    {
        return PaymentHttpClient::assertSuccess($response, $gateway);
    }

    private function baseUrl(array $config): string
    {
        return !empty($config['_test_mode']) ? self::SANDBOX_BASE : self::LIVE_BASE;
    }

    private function assertConfig(array $config): void
    {
        foreach (['client_id', 'client_secret', 'webhook_id', 'return_url', 'cancel_url'] as $key) {
            if (trim((string) ($config[$key] ?? '')) === '') {
                throw new BizException('PayPal 配置不完整：' . $key);
            }
        }
    }
}