<?php
declare (strict_types = 1);

namespace app\common\lib\payment;

use app\common\exception\BizException;
use app\common\model\PaymentChannel;
use think\facade\Config;

class PaymentGatewayFactory
{
    public static function make(string $channel): PaymentGatewayInterface
    {
        return match ($channel) {
            PaymentChannelCatalog::WECHAT => new WechatPayGateway(),
            PaymentChannelCatalog::ALIPAY => new AlipayGateway(),
            PaymentChannelCatalog::STRIPE => new StripeGateway(),
            PaymentChannelCatalog::PAYPAL => new PaypalGateway(),
            default => throw new BizException('不支持的支付通道: ' . $channel),
        };
    }

    public static function record(string $channel): PaymentChannel
    {
        PaymentChannelCatalog::definition($channel);
        $record = PaymentChannel::where('code', $channel)->find();
        if (!$record) {
            throw new BizException('支付通道尚未初始化，请先运行数据库迁移');
        }
        return $record;
    }

    /**
     * Read and decrypt the channel config for one environment.
     *
     * Set $requireEnabled=false for asynchronous callbacks so disabling a
     * channel does not drop callbacks for payments created while it was
     * enabled. $testMode defaults to the channel's current test_mode switch.
     */
    public static function configFor(
        string $channel,
        bool $requireEnabled = true,
        ?bool $testMode = null
    ): array {
        $record = self::record($channel);
        if ($requireEnabled && !$record->isEnabled()) {
            throw new BizException(PaymentChannelCatalog::label($channel) . '尚未启用');
        }
        $testMode = $testMode ?? $record->isTestMode();
        $column = self::envColumn($testMode);
        try {
            $config = PaymentConfigCipher::decrypt((string) ($record->$column ?? ''));
        } catch (\Throwable $e) {
            throw new BizException('支付配置无法解密，请重新保存该通道配置');
        }
        if ($channel === PaymentChannelCatalog::WECHAT && !$testMode) {
            $config = self::withWechatEnvFallback($config);
        }
        $config['_test_mode'] = $testMode ? 1 : 0;
        $config['_enabled'] = $record->isEnabled() ? 1 : 0;
        return $config;
    }

    /**
     * Stored config for one environment, with the legacy .env WeChat fallback
     * applied to the live environment only.
     *
     * Existing deployments keep their .env credentials working after the
     * upgrade; saving the channel from the admin page adopts the env values
     * into the encrypted database row, after which the database wins.
     */
    public static function mergedConfig(string $channel, bool $testMode): array
    {
        $record = self::record($channel);
        $column = self::envColumn($testMode);
        $config = PaymentConfigCipher::safeDecrypt($record->$column);
        if ($channel === PaymentChannelCatalog::WECHAT && !$testMode) {
            $config = self::withWechatEnvFallback($config);
        }
        return $config;
    }

    public static function envColumn(bool $testMode): string
    {
        return $testMode ? 'test_config_json' : 'live_config_json';
    }

    public static function enabledChannels(): array
    {
        $records = PaymentChannel::where('enabled', 1)->order('sort', 'asc')->select();
        $list = [];
        foreach ($records as $record) {
            if (!in_array((string) $record->code, PaymentChannelCatalog::codes(), true)) {
                continue;
            }
            $allowed = is_domestic_edition()
                ? [PaymentChannelCatalog::WECHAT, PaymentChannelCatalog::ALIPAY]
                : [PaymentChannelCatalog::STRIPE, PaymentChannelCatalog::PAYPAL];
            if (!in_array((string) $record->code, $allowed, true)) {
                continue;
            }
            $definition = PaymentChannelCatalog::definition((string) $record->code);
            $list[] = [
                'code'        => (string) $record->code,
                'name'        => (string) $record->name,
                'description' => $definition['description'],
                'test_mode'   => $record->isTestMode() ? 1 : 0,
            ];
        }
        return $list;
    }

    private static function withWechatEnvFallback(array $config): array
    {
        $appId = (string) Config::get('wechat.login.appid', '');
        $mchId = (string) Config::get('wechat.pay.mchid', '');
        $serialNo = (string) Config::get('wechat.pay.serial_no', '');
        $privateKeyPath = (string) Config::get('wechat.pay.private_key_path', '');
        $platformCertPath = (string) Config::get('wechat.pay.platform_cert_path', '');
        $notifyUrl = (string) Config::get('wechat.pay.notify_url', '');
        $apiV3Key = (string) Config::get('wechat.pay.api_v3_key', '');

        $fallback = [
            'app_id'        => $appId,
            'mch_id'        => $mchId,
            'serial_no'     => $serialNo,
            'private_key'   => $privateKeyPath !== '' && is_file($privateKeyPath) ? (string) file_get_contents($privateKeyPath) : '',
            'platform_cert' => $platformCertPath !== '' && is_file($platformCertPath) ? (string) file_get_contents($platformCertPath) : '',
            'notify_url'    => $notifyUrl,
            'api_v3_key'    => $apiV3Key,
        ];
        foreach ($fallback as $key => $value) {
            if (trim((string) ($config[$key] ?? '')) === '' && $value !== '') {
                $config[$key] = $value;
            }
        }
        return $config;
    }
}