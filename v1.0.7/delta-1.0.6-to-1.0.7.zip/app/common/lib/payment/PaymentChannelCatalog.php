<?php
declare (strict_types = 1);

namespace app\common\lib\payment;

use app\common\exception\BizException;

/**
 * Single source of truth for supported payment channels and their config
 * fields. The admin form is rendered from these definitions and saves are
 * validated against them.
 */
class PaymentChannelCatalog
{
    public const WECHAT = 'wechat';
    public const ALIPAY = 'alipay';
    public const STRIPE = 'stripe';
    public const PAYPAL = 'paypal';

    public static function codes(): array
    {
        return [self::WECHAT, self::ALIPAY, self::STRIPE, self::PAYPAL];
    }

    public static function definitions(): array
    {
        return [
            self::WECHAT => [
                'code'        => self::WECHAT,
                'name'        => '微信支付',
                'short_name'  => '微信',
                'color'       => '#07C160',
                'description' => '微信小程序 JSAPI 支付（APIv3），当前小程序使用此通道；微信无沙箱网关，测试环境可填相同商户配置用于联调。',
                'fields'      => [
                    ['key' => 'app_id', 'label' => '小程序 AppID', 'type' => 'text', 'required' => true, 'secret' => false, 'placeholder' => 'wx1234567890abcdef', 'help' => '与小程序登录使用同一个 AppID。'],
                    ['key' => 'mch_id', 'label' => '商户号 MchID', 'type' => 'text', 'required' => true, 'secret' => false, 'placeholder' => '1900000000', 'help' => '微信支付商户平台账号。'],
                    ['key' => 'serial_no', 'label' => '商户证书序列号', 'type' => 'text', 'required' => true, 'secret' => false, 'placeholder' => '45F59D...', 'help' => '商户 API 证书序列号。'],
                    ['key' => 'private_key', 'label' => '商户私钥', 'type' => 'textarea', 'required' => true, 'secret' => true, 'placeholder' => '-----BEGIN PRIVATE KEY-----', 'help' => 'apiclient_key.pem 内容，需包含完整 PEM。'],
                    ['key' => 'api_v3_key', 'label' => 'APIv3 密钥', 'type' => 'password', 'required' => true, 'secret' => true, 'placeholder' => '32 位 APIv3 密钥', 'help' => '用于解密回调 resource。'],
                    ['key' => 'platform_cert', 'label' => '微信平台证书', 'type' => 'textarea', 'required' => true, 'secret' => true, 'placeholder' => '-----BEGIN CERTIFICATE-----', 'help' => '用于回调验签，粘贴平台证书 PEM。'],
                    ['key' => 'notify_url', 'label' => '回调地址', 'type' => 'url', 'required' => true, 'secret' => false, 'placeholder' => 'https://example.com/api/payment/notify/wechat', 'help' => '必须是公网 HTTPS 地址。'],
                ],
            ],
            self::ALIPAY => [
                'code'        => self::ALIPAY,
                'name'        => '支付宝',
                'short_name'  => '支付宝',
                'color'       => '#1677FF',
                'description' => '支付宝电脑网站支付（alipay.trade.page.pay），测试模式使用沙箱网关。',
                'fields'      => [
                    ['key' => 'app_id', 'label' => '应用 AppID', 'type' => 'text', 'required' => true, 'secret' => false, 'placeholder' => '2021000000000000', 'help' => '开放平台应用 AppID。'],
                    ['key' => 'private_key', 'label' => '应用私钥', 'type' => 'textarea', 'required' => true, 'secret' => true, 'placeholder' => '-----BEGIN PRIVATE KEY-----', 'help' => '支持 PEM 或开放平台导出的原始密钥。'],
                    ['key' => 'alipay_public_key', 'label' => '支付宝公钥', 'type' => 'textarea', 'required' => true, 'secret' => true, 'placeholder' => '-----BEGIN PUBLIC KEY-----', 'help' => '用于回调验签，不是应用公钥。'],
                    ['key' => 'notify_url', 'label' => '异步回调地址', 'type' => 'url', 'required' => true, 'secret' => false, 'placeholder' => 'https://example.com/api/payment/notify/alipay', 'help' => '公网可达的 HTTPS 地址。'],
                    ['key' => 'return_url', 'label' => '同步跳转地址', 'type' => 'url', 'required' => false, 'secret' => false, 'placeholder' => 'https://example.com/pay/return', 'help' => '支付完成后浏览器跳转地址，可留空。'],
                    ['key' => 'gateway_url', 'label' => '自定义网关', 'type' => 'url', 'required' => false, 'secret' => false, 'placeholder' => '留空自动选择生产/沙箱', 'help' => '一般留空；测试模式自动使用 openapi.alipaydev.com。'],
                ],
            ],
            self::STRIPE => [
                'code'        => self::STRIPE,
                'name'        => 'Stripe',
                'short_name'  => 'Stripe',
                'color'       => '#635BFF',
                'description' => 'Stripe Checkout 跳转支付，支持测试密钥与 webhook 验签。',
                'fields'      => [
                    ['key' => 'publishable_key', 'label' => 'Publishable Key', 'type' => 'text', 'required' => false, 'secret' => false, 'placeholder' => 'pk_test_...', 'help' => '前端展示用，可留空。'],
                    ['key' => 'secret_key', 'label' => 'Secret Key', 'type' => 'password', 'required' => true, 'secret' => true, 'placeholder' => 'sk_test_...', 'help' => '仅服务端使用，测试模式请使用 sk_test_ 开头的密钥。'],
                    ['key' => 'webhook_secret', 'label' => 'Webhook Secret', 'type' => 'password', 'required' => true, 'secret' => true, 'placeholder' => 'whsec_...', 'help' => '用于校验 Stripe-Signature。'],
                    ['key' => 'success_url', 'label' => '支付成功跳转', 'type' => 'url', 'required' => true, 'secret' => false, 'placeholder' => 'https://example.com/pay/success', 'help' => '会自动附加 order_pay_id 与 session_id。'],
                    ['key' => 'cancel_url', 'label' => '取消跳转', 'type' => 'url', 'required' => true, 'secret' => false, 'placeholder' => 'https://example.com/pay/cancel', 'help' => '用户取消支付后的返回地址。'],
                ],
            ],
            self::PAYPAL => [
                'code'        => self::PAYPAL,
                'name'        => 'PayPal',
                'short_name'  => 'PayPal',
                'color'       => '#003087',
                'description' => 'PayPal Orders v2 跳转支付，测试模式使用 sandbox 环境。',
                'fields'      => [
                    ['key' => 'client_id', 'label' => 'Client ID', 'type' => 'text', 'required' => true, 'secret' => false, 'placeholder' => 'AY...', 'help' => 'REST App 的 Client ID。'],
                    ['key' => 'client_secret', 'label' => 'Client Secret', 'type' => 'password', 'required' => true, 'secret' => true, 'placeholder' => 'EL...', 'help' => 'REST App 的 Secret，仅服务端保存。'],
                    ['key' => 'webhook_id', 'label' => 'Webhook ID', 'type' => 'text', 'required' => true, 'secret' => false, 'placeholder' => 'WH-...', 'help' => '用于调用 PayPal 验签接口。'],
                    ['key' => 'return_url', 'label' => '支付成功跳转', 'type' => 'url', 'required' => true, 'secret' => false, 'placeholder' => 'https://example.com/pay/success', 'help' => 'PayPal approve 后返回地址。'],
                    ['key' => 'cancel_url', 'label' => '取消跳转', 'type' => 'url', 'required' => true, 'secret' => false, 'placeholder' => 'https://example.com/pay/cancel', 'help' => '用户取消后的返回地址。'],
                ],
            ],
        ];
    }

    public static function definition(string $code): array
    {
        $definitions = self::definitions();
        if (!isset($definitions[$code])) {
            throw new BizException('不支持的支付通道: ' . $code);
        }
        return $definitions[$code];
    }

    public static function fields(string $code): array
    {
        return self::definition($code)['fields'];
    }

    public static function label(string $code): string
    {
        return self::definition($code)['name'];
    }

    /**
     * Merge submitted values with the stored config, validate required and
     * URL fields, and return the config to encrypt.
     *
     * Secret fields left blank keep their existing value.
     */
    public static function validateAndMerge(string $code, array $input, array $existing, bool $enabled): array
    {
        $merged = [];
        $missing = [];
        foreach (self::fields($code) as $field) {
            $key = $field['key'];
            $submitted = array_key_exists($key, $input) ? $input[$key] : null;
            if (is_array($submitted) || is_object($submitted)) {
                throw new BizException($field['label'] . '格式无效');
            }
            if ($field['secret']) {
                $value = $submitted === null ? '' : trim((string) $submitted);
                if ($value === '') {
                    $value = (string) ($existing[$key] ?? '');
                }
            } else {
                $value = $submitted === null
                    ? (string) ($existing[$key] ?? ($field['default'] ?? ''))
                    : trim((string) $submitted);
            }

            if ($value !== '' && $field['type'] === 'url' && !self::isHttpUrl($value)) {
                throw new BizException($field['label'] . '必须是有效的 http(s) 地址');
            }
            if ($key === 'currency' && $value !== '') {
                $value = strtolower($value);
                if (!preg_match('/^[a-z]{3}$/', $value)) {
                    throw new BizException($field['label'] . '必须是三位币种代码');
                }
            }
            if ($enabled && $field['required'] && $value === '') {
                $missing[] = $field['label'];
            }
            $merged[$key] = $value;
        }
        if ($missing) {
            throw new BizException('启用' . self::label($code) . '前请填写：' . implode('、', $missing));
        }
        return $merged;
    }

    /**
     * Admin-safe representation: secret values are never returned to the
     * browser, only whether a value is already stored.
     */
    public static function adminFields(string $code, array $config): array
    {
        $fields = [];
        foreach (self::fields($code) as $field) {
            $value = (string) ($config[$field['key']] ?? ($field['default'] ?? ''));
            $field['value'] = $field['secret'] ? '' : $value;
            $field['has_value'] = $field['secret'] ? $value !== '' : false;
            $fields[] = $field;
        }
        return $fields;
    }

    public static function missingRequired(string $code, array $config): array
    {
        $missing = [];
        foreach (self::fields($code) as $field) {
            if ($field['required'] && trim((string) ($config[$field['key']] ?? '')) === '') {
                $missing[] = $field['label'];
            }
        }
        return $missing;
    }

    public static function isHttpUrl(string $value): bool
    {
        return filter_var($value, FILTER_VALIDATE_URL) !== false
            && preg_match('~^https?://~i', $value) === 1;
    }
}