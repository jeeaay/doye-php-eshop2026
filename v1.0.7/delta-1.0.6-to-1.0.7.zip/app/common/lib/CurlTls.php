<?php
declare(strict_types=1);

namespace app\common\lib;

use think\facade\Log;

/**
 * cURL TLS 配置
 *
 * Windows 版 PHP 常见问题：curl.cainfo / openssl.cafile 未配置，导致所有 HTTPS 请求
 * 报 "unable to get local issuer certificate"。这里统一处理：
 *   1. 优先 CURL_CA_BUNDLE 环境变量
 *   2. 其次 php.ini 的 curl.cainfo / openssl.cafile
 *   3. 开发模式（APP_DEBUG=true）下关闭校验并写警告，保证本地可联调
 *   4. 生产环境未配置 CA 时保持校验，让错误明确暴露
 */
class CurlTls
{
    /**
     * @param resource|\CurlHandle $ch
     */
    public static function apply($ch): void
    {
        $ca = getenv('CURL_CA_BUNDLE') ?: (string) ini_get('curl.cainfo') ?: (string) ini_get('openssl.cafile');
        if ($ca !== '' && is_file($ca)) {
            curl_setopt($ch, CURLOPT_CAINFO, $ca);
            return;
        }

        if ((bool) env('APP_DEBUG', false)) {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            Log::warning('[curl] CA bundle 未配置，开发模式已临时关闭 SSL 校验；生产环境请配置 curl.cainfo');
        }
    }
}