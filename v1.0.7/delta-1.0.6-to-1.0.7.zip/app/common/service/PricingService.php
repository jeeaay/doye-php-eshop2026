<?php
declare(strict_types=1);

namespace app\common\service;

/**
 * 展示价计算
 *
 * USD 是唯一事实来源：本服务只负责把 USD 金额换算成展示币种，
 * 不参与订单、支付、退款、结算。
 */
class PricingService
{
    /**
     * 展示汇率：人工覆盖优先
     *
     * @param array<string,mixed> $currency
     * @return string
     */
    public function displayRate(array $currency): string
    {
        if ((int) ($currency['is_base'] ?? 0) === 1) {
            return '1';
        }
        $rate = $currency['rate_override'] ?? $currency['rate'] ?? 1;
        return (string) $rate;
    }

    /**
     * USD → 展示币种金额（字符串，已按币种小数位取整）
     *
     * @param string|float $usd USD 金额
     * @param array<string,mixed> $currency 币种
     * @return string
     */
    public function convert($usd, array $currency): string
    {
        $amount = (string) $usd;
        if ((int) ($currency['is_base'] ?? 0) === 1) {
            return $this->round($amount, (int) ($currency['decimals'] ?? 2));
        }

        $rate = $this->displayRate($currency);
        if (!is_numeric($rate) || (float) $rate <= 0) {
            $rate = '1';
        }

        return $this->round(bcmul($amount, $rate, 6), (int) ($currency['decimals'] ?? 2));
    }

    /**
     * 换算并格式化，如 €17.91 / ¥3,156 / AED 13.45
     *
     * @param string|float $usd USD 金额
     * @param array<string,mixed>|null $currency 不传时取当前展示币种
     * @return string
     */
    public function format($usd, ?array $currency = null): string
    {
        $currency = $currency ?? \app\common\support\LocaleContext::currency();
        $value = $this->convert($usd, $currency);

        return $this->formatAmount($value, $currency);
    }

    /**
     * 格式化本币金额（不再换算）
     *
     * @param string|float $amount 本币金额
     * @param array<string,mixed> $currency
     * @return string
     */
    public function formatAmount($amount, array $currency): string
    {
        $decimals = (int) ($currency['decimals'] ?? 2);
        $text = number_format((float) $amount, $decimals, '.', ',');
        $symbol = (string) ($currency['symbol'] ?? '');
        $space = (int) ($currency['symbol_space'] ?? 0) === 1 ? ' ' : '';

        return ((string) ($currency['symbol_position'] ?? 'before') === 'after')
            ? $text . $space . $symbol
            : $symbol . $space . $text;
    }

    /**
     * 四舍五入到指定小数位（half-up，基于 bcmath 避免浮点误差）
     *
     * @param string $value
     * @param int $decimals
     * @return string
     */
    private function round(string $value, int $decimals): string
    {
        $decimals = max(0, $decimals);
        $half = '0.' . str_repeat('0', $decimals) . '5';

        return bcadd($value, $half, $decimals);
    }
}