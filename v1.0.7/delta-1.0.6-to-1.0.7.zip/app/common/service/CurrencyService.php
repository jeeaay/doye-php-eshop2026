<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\lib\Mailer;
use app\common\lib\RedisCache;
use app\common\model\Currency;
use app\common\model\CurrencyRateLog;
use think\facade\Log;

/**
 * 展示币种读取（带缓存）
 */
class CurrencyService
{
    private const CACHE_KEY = 'site:currencies';
    private const CACHE_TTL = 600;

    /**
     * 启用的展示币种
     *
     * @return array<int,array<string,mixed>>
     */
    public function enabled(): array
    {
        $rows = RedisCache::remember(self::CACHE_KEY, self::CACHE_TTL, static function (): array {
            try {
                return Currency::enabled()->toArray();
            } catch (\Throwable $e) {
                return [];
            }
        });

        if (is_domestic_edition()) {
            $base = base_currency_code();
            $filtered = array_values(array_filter($rows, static function ($row) use ($base): bool {
                return strtoupper((string) ($row['code'] ?? '')) === $base;
            }));
            if ($filtered) {
                return $filtered;
            }
        }

        return $rows;
    }

    /**
     * 按 code 查找启用币种（大小写不敏感）
     *
     * @param string $code ISO 4217
     * @return array<string,mixed>|null
     */
    public function find(string $code): ?array
    {
        $code = strtoupper(trim($code));
        if ($code === '') {
            return null;
        }
        foreach ($this->enabled() as $currency) {
            if (strtoupper((string) $currency['code']) === $code) {
                return $currency;
            }
        }
        return null;
    }

    /**
     * 基准币种（USD）
     *
     * @return array<string,mixed>
     */
    public function base(): array
    {
        $code = base_currency_code();
        $found = $this->find($code);
        if ($found) {
            return $found;
        }
        foreach ($this->enabled() as $currency) {
            if ((int) ($currency['is_base'] ?? 0) === 1) {
                return $currency;
            }
        }
        return $this->fallback();
    }

    /**
     * 语种对应的默认展示币种，找不到时回退 USD
     *
     * @param string $localeCode 语言短码
     * @return array<string,mixed>
     */
    public function forLocale(string $localeCode): array
    {
        $language = (new LanguageService())->find($localeCode);
        $code = (string) ($language['default_currency'] ?? '');
        return $code !== '' ? ($this->find($code) ?? $this->base()) : $this->base();
    }

    /**
     * 清除缓存（后台保存币种/汇率后调用）
     */
    public function flush(): void
    {
        RedisCache::forget(self::CACHE_KEY);
    }

    /**
     * 后台列表：全部币种（含停用）
     *
     * @return array<int,array<string,mixed>>
     */
    public function all(): array
    {
        $query = Currency::order('sort')->order('id');
        if (is_domestic_edition()) {
            $query->where('code', base_currency_code());
        }
        $rows = $query->select();
        $out = [];
        foreach ($rows as $row) {
            $out[] = $this->format($row);
        }
        return $out;
    }

    /**
     * 后台保存币种基础信息
     *
     * @param int $id
     * @param array<string,mixed> $data
     * @return array<string,mixed>
     */
    public function save(int $id, array $data): array
    {
        $currency = Currency::find($id);
        if (!$currency) {
            throw new \app\common\exception\BizException('币种不存在');
        }

        if (array_key_exists('name', $data)) {
            $name = trim((string) $data['name']);
            if ($name === '') {
                throw new \app\common\exception\BizException('币种名称不能为空');
            }
            $currency->name = mb_substr($name, 0, 64);
        }
        if (array_key_exists('symbol', $data)) {
            $currency->symbol = mb_substr(trim((string) $data['symbol']), 0, 8) ?: $currency->code;
        }
        if (array_key_exists('decimals', $data)) {
            $decimals = (int) $data['decimals'];
            if ($decimals < 0 || $decimals > 3) {
                throw new \app\common\exception\BizException('小数位只能是 0-3');
            }
            $currency->decimals = $decimals;
        }
        if (array_key_exists('symbol_position', $data)) {
            $currency->symbol_position = (string) $data['symbol_position'] === 'after' ? 'after' : 'before';
        }
        if (array_key_exists('symbol_space', $data)) {
            $currency->symbol_space = (int) $data['symbol_space'] === 1 ? 1 : 0;
        }
        if (array_key_exists('sort', $data)) {
            $currency->sort = (int) $data['sort'];
        }
        if (array_key_exists('status', $data) && (int) $currency->is_base !== 1) {
            $currency->status = (int) $data['status'] === 1 ? 1 : 0;
        }
        if (array_key_exists('rate_override', $data)) {
            $raw = $data['rate_override'];
            if ($raw === '' || $raw === null) {
                $currency->rate_override = null;
            } else {
                if (!is_numeric($raw) || (float) $raw <= 0) {
                    throw new \app\common\exception\BizException('人工汇率必须大于 0');
                }
                $currency->rate_override = number_format((float) $raw, 8, '.', '');
            }
        }

        $currency->save();

        if (array_key_exists('rate_override', $data) && $currency->rate_override !== null) {
            $this->recordLog(
                (string) $currency->code,
                (float) $currency->rate_override,
                (float) $currency->rate_override,
                (float) $currency->rate,
                'manual',
                '后台保存人工汇率'
            );
        }

        $this->flush();
        return $this->format($currency);
    }

    /**
     * 新增币种
     *
     * @param array<string,mixed> $data
     * @return array<string,mixed>
     */
    public function create(array $data): array
    {
        $code = strtoupper(trim((string) ($data['code'] ?? '')));
        if (!preg_match('/^[A-Z]{3}$/', $code)) {
            throw new \app\common\exception\BizException('币种代码必须是三位字母');
        }
        if (Currency::where('code', $code)->find()) {
            throw new \app\common\exception\BizException('币种已存在');
        }
        if (empty($data['name'])) {
            throw new \app\common\exception\BizException('币种名称不能为空');
        }

        $currency = new Currency();
        $currency->code = $code;
        $currency->name = mb_substr(trim((string) $data['name']), 0, 64);
        $currency->symbol = mb_substr(trim((string) ($data['symbol'] ?? $code)), 0, 8) ?: $code;
        $currency->decimals = max(0, min(3, (int) ($data['decimals'] ?? 2)));
        $currency->symbol_position = (string) ($data['symbol_position'] ?? 'before') === 'after' ? 'after' : 'before';
        $currency->symbol_space = (int) ($data['symbol_space'] ?? 0) === 1 ? 1 : 0;
        $currency->status = (int) ($data['status'] ?? 0) === 1 ? 1 : 0;
        $currency->is_base = 0;
        $currency->rate = 1;
        $currency->rate_override = null;
        $currency->rate_source = 'manual';
        $currency->rate_updated_at = date('Y-m-d H:i:s');
        $currency->rounding_mode = 'half_up';
        $currency->rounding_step = 0.01;
        $currency->sort = (int) ($data['sort'] ?? 0);
        $currency->save();

        $this->flush();
        return $this->format($currency);
    }

    /**
     * 删除币种
     */
    public function delete(int $id): void
    {
        $currency = Currency::find($id);
        if (!$currency) {
            throw new \app\common\exception\BizException('币种不存在');
        }
        if ((int) $currency->is_base === 1) {
            throw new \app\common\exception\BizException('基准币种不能删除');
        }
        $currency->delete();
        $this->flush();
    }

    /**
     * 设置/清除人工汇率
     *
     * @param float|null $rate null 表示清除
     * @return array<string,mixed>
     */
    public function setOverride(int $id, ?float $rate): array
    {
        $currency = Currency::find($id);
        if (!$currency) {
            throw new \app\common\exception\BizException('币种不存在');
        }
        if ((int) $currency->is_base === 1) {
            throw new \app\common\exception\BizException('基准币种汇率固定为 1');
        }
        if ($rate !== null && $rate <= 0) {
            throw new \app\common\exception\BizException('人工汇率必须大于 0');
        }

        $currency->rate_override = $rate !== null ? number_format($rate, 8, '.', '') : null;
        $currency->save();

        if ($rate !== null) {
            $this->recordLog($currency->code, $rate, $rate, (float) $currency->rate, 'manual', '人工覆盖汇率');
        }

        $this->flush();
        return $this->format($currency);
    }

    /**
     * 同步全部启用币种
     *
     * @return array{source:string,updated:int,rejected:int,alerts:array<int,string>}
     */
    public function syncAll(bool $dryRun = false): array
    {
        if (is_domestic_edition()) {
            return ['source' => 'disabled', 'updated' => 0, 'rejected' => 0, 'alerts' => []];
        }

        $feed = $this->fetchRates();
        $updated = 0;
        $rejected = 0;
        $alerts = [];

        foreach (Currency::where('status', 1)->order('sort')->select() as $currency) {
            if ((int) $currency->is_base === 1) {
                continue;
            }
            $result = $this->applyRate($currency, $feed, $dryRun);
            if ($result['status'] === 'accepted') {
                $updated++;
            } elseif ($result['status'] === 'rejected') {
                $rejected++;
                $alerts[] = $result['message'];
            }
        }

        if (!$dryRun) {
            $this->flush();
        }
        $this->sendAlert($alerts);

        return [
            'source'   => $feed['source'],
            'updated'  => $updated,
            'rejected' => $rejected,
            'alerts'   => $alerts,
        ];
    }

    /**
     * 同步单个币种
     *
     * @return array<string,mixed>
     */
    public function syncOne(string $code, bool $dryRun = false): array
    {
        if (is_domestic_edition()) {
            throw new \app\common\exception\BizException('国内版使用 CNY 结算，不需要汇率同步');
        }
        $code = strtoupper(trim($code));
        $currency = Currency::where('code', $code)->find();
        if (!$currency) {
            throw new \app\common\exception\BizException('币种不存在');
        }
        $feed = $this->fetchRates();
        $result = $this->applyRate($currency, $feed, $dryRun);
        if (!$dryRun) {
            $this->flush();
        }
        $result['source'] = $feed['source'];
        return $result;
    }

    /**
     * 汇率历史
     *
     * @return array<int,array<string,mixed>>
     */
    public function history(string $code, int $limit = 30): array
    {
        $limit = max(1, min(200, $limit));
        $rows = CurrencyRateLog::where('currency_code', strtoupper($code))
            ->order('id', 'desc')
            ->limit($limit)
            ->select();
        return $this->mapLogs($rows);
    }

    /**
     * 最近汇率日志（后台首页/抽屉）
     *
     * @return array<int,array<string,mixed>>
     */
    public function recentHistory(int $limit = 50): array
    {
        $limit = max(1, min(200, $limit));
        return $this->mapLogs(CurrencyRateLog::order('id', 'desc')->limit($limit)->select());
    }

    /**
     * 拉取汇率（主源失败自动切备用）
     *
     * @return array{rates:array<string,float>,source:string}
     */
    public function fetchRates(): array
    {
        $preferred = (string) site_config('currency.provider', 'open.er-api');
        $providers = array_values(array_unique(array_filter([
            $preferred,
            'open.er-api',
            'fawazahmed0',
        ])));

        $errors = [];
        foreach ($providers as $provider) {
            if (!in_array($provider, ['open.er-api', 'fawazahmed0'], true)) {
                continue;
            }
            try {
                return $this->fetchFrom($provider);
            } catch (\Throwable $e) {
                $errors[] = $provider . ': ' . $e->getMessage();
            }
        }
        throw new \app\common\exception\BizException('汇率接口不可用：' . implode('；', $errors));
    }

    /**
     * @return array{rates:array<string,float>,source:string}
     */
    private function fetchFrom(string $provider): array
    {
        if ($provider === 'fawazahmed0') {
            $url = 'https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json';
            $json = $this->httpGet($url);
            $data = json_decode($json, true);
            $rows = is_array($data['usd'] ?? null) ? $data['usd'] : [];
            $source = 'fawazahmed0';
        } else {
            $url = 'https://open.er-api.com/v6/latest/USD';
            $json = $this->httpGet($url);
            $data = json_decode($json, true);
            $rows = is_array($data['rates'] ?? null) ? $data['rates'] : [];
            $source = 'open.er-api';
        }

        if (!$rows) {
            throw new \RuntimeException('返回数据为空');
        }

        $rates = [];
        foreach ($rows as $code => $rate) {
            $code = strtoupper((string) $code);
            if (preg_match('/^[A-Z]{3}$/', $code) && is_numeric($rate)) {
                $rates[$code] = (float) $rate;
            }
        }
        if (!isset($rates['USD'])) {
            $rates['USD'] = 1.0;
        }

        return ['rates' => $rates, 'source' => $source];
    }

    /**
     * @param array{rates:array<string,float>,source:string} $feed
     * @return array{status:string,message:string,rate:string}
     */
    private function applyRate(Currency $currency, array $feed, bool $dryRun): array
    {
        $code = strtoupper((string) $currency->code);
        if ((int) $currency->is_base === 1) {
            return ['status' => 'accepted', 'message' => '', 'rate' => '1'];
        }

        $raw = $feed['rates'][$code] ?? null;
        $prev = (float) $currency->rate;
        if (!is_numeric($raw) || (float) $raw <= 0) {
            $message = $code . ' 汇率无效，已保留旧值';
            if (!$dryRun) {
                $this->recordLog($code, null, $prev, $prev, 'rejected', $message, $feed['source']);
            }
            return ['status' => 'rejected', 'message' => $message, 'rate' => (string) $prev];
        }

        $raw = (float) $raw;
        $change = $prev > 0 ? (($raw - $prev) / $prev) * 100 : 0.0;
        $threshold = (float) site_config('currency.sanity_percent', 10);
        if ($prev > 0 && $threshold > 0 && abs($change) > $threshold) {
            $message = sprintf('%s 单日变动 %.2f%% 超过阈值 %.2f%%，已保留旧值', $code, $change, $threshold);
            if (!$dryRun) {
                $this->recordLog($code, $raw, $prev, $prev, 'rejected', $message, $feed['source'], $change);
            }
            return ['status' => 'rejected', 'message' => $message, 'rate' => (string) $prev];
        }

        if (!$dryRun) {
            $currency->rate = number_format($raw, 8, '.', '');
            $currency->rate_source = $feed['source'];
            $currency->rate_updated_at = date('Y-m-d H:i:s');
            $currency->save();
            $this->recordLog($code, $raw, $raw, $prev, 'accepted', '', $feed['source'], $change);
        }

        return ['status' => 'accepted', 'message' => '', 'rate' => (string) $raw];
    }

    /**
     * 写入汇率历史（同一天同一币种同来源只保留一条）
     */
    private function recordLog(
        string $code,
        $raw,
        $applied,
        $prev,
        string $status,
        string $message = '',
        string $source = '',
        ?float $change = null
    ): void {
        $today = date('Y-m-d');
        $log = CurrencyRateLog::where('currency_code', $code)
            ->where('effective_date', $today)
            ->where('source', $source)
            ->where('status', $status)
            ->find();
        if (!$log) {
            $log = new CurrencyRateLog();
            $log->currency_code = $code;
            $log->effective_date = $today;
            $log->source = $source;
            $log->status = $status;
        }
        $log->raw_rate = $raw !== null ? number_format((float) $raw, 8, '.', '') : null;
        $log->applied_rate = number_format((float) $applied, 8, '.', '');
        $log->prev_rate = number_format((float) $prev, 8, '.', '');
        $log->change_percent = $change !== null ? number_format($change, 4, '.', '') : null;
        $log->message = $message !== '' ? mb_substr($message, 0, 255) : null;
        $log->save();
    }

    /**
     * 汇率异常告警（邮件未启用时只写日志）
     *
     * @param array<int,string> $alerts
     */
    private function sendAlert(array $alerts): void
    {
        if (!$alerts) {
            return;
        }
        $text = implode("\n", $alerts);
        Log::warning('[currency] ' . $text);

        $to = trim((string) site_config('currency.alert_email', ''));
        if ($to !== '' && filter_var($to, FILTER_VALIDATE_EMAIL)) {
            (new Mailer())->send($to, '汇率同步异常', "以下币种本次未更新：\n\n" . $text);
        }
    }

    /**
     * @return string
     */
    private function httpGet(string $url): string
    {
        $ch = curl_init($url);
        \app\common\lib\CurlTls::apply($ch);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTPHEADER     => ['Accept: application/json', 'User-Agent: doyecart/1.0'],
        ]);
        $body = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($body === false || $error !== '') {
            throw new \RuntimeException($error !== '' ? $error : '网络错误');
        }
        if ($status < 200 || $status >= 300) {
            throw new \RuntimeException('HTTP ' . $status);
        }
        return (string) $body;
    }

    /**
     * @param iterable $rows
     * @return array<int,array<string,mixed>>
     */
    private function mapLogs(iterable $rows): array
    {
        $out = [];
        foreach ($rows as $row) {
            $out[] = [
                'id'             => (int) $row->id,
                'currency_code'  => (string) $row->currency_code,
                'raw_rate'       => (string) ($row->raw_rate ?? ''),
                'applied_rate'   => (string) ($row->applied_rate ?? ''),
                'prev_rate'      => (string) ($row->prev_rate ?? ''),
                'change_percent' => (string) ($row->change_percent ?? ''),
                'status'         => (string) $row->status,
                'source'         => (string) ($row->source ?? ''),
                'effective_date' => $row->effective_date ? (string) $row->effective_date : '',
                'message'        => (string) ($row->message ?? ''),
                'create_time'    => (string) ($row->create_time ?? ''),
            ];
        }
        return $out;
    }

    /**
     * @return array<string,mixed>
     */
    private function format(Currency $currency): array
    {
        return [
            'id'              => (int) $currency->id,
            'code'            => (string) $currency->code,
            'name'            => (string) $currency->name,
            'symbol'          => (string) $currency->symbol,
            'decimals'        => (int) $currency->decimals,
            'symbol_position' => (string) $currency->symbol_position,
            'symbol_space'    => (int) $currency->symbol_space,
            'status'          => (int) $currency->status,
            'is_base'         => (int) $currency->is_base,
            'rate'            => (string) $currency->rate,
            'rate_override'   => $currency->rate_override !== null ? (string) $currency->rate_override : null,
            'effective_rate'  => $currency->effectiveRate(),
            'rate_source'     => (string) ($currency->rate_source ?? ''),
            'rate_updated_at' => $currency->rate_updated_at ? (string) $currency->rate_updated_at : '',
        ];
    }

    /**
     * @return array<string,mixed>
     */
    private function fallback(): array
    {
        $code = base_currency_code();
        $isCny = $code === 'CNY';
        return [
            'code'            => $code,
            'name'            => $isCny ? '人民币' : '美元',
            'symbol'          => $isCny ? '¥' : '$',
            'decimals'        => 2,
            'symbol_position' => 'before',
            'symbol_space'    => 0,
            'is_base'         => 1,
            'rate'            => 1,
            'rate_override'   => null,
            'status'          => 1,
        ];
    }
}