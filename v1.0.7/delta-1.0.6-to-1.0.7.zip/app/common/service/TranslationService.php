<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\model\BrandTranslation;
use app\common\model\CategoryTranslation;
use app\common\model\PageTranslation;
use app\common\model\ProductTranslation;
use app\common\model\Brand;
use app\common\model\Category;
use app\common\model\Page;
use app\common\model\Product;
use app\common\support\AppContext;
use app\common\support\LocaleContext;

/**
 * 翻译读取：译文优先，缺失逐字段回退英文主表
 *
 * 只读取 status=1 的译文；草稿不会出现在前台。
 * 列表场景用 *Map() 一次查完，避免 N+1。
 */
class TranslationService
{
    /**
     * 当前语种
     */
    public function locale(?string $locale = null): string
    {
        return strtolower(trim($locale ?? LocaleContext::localeCode()));
    }

    /**
     * 商品译文（按 product_id 索引）
     *
     * @param array<int,int> $ids
     * @return array<int,array<string,mixed>>
     */
    public function productMap(array $ids, ?string $locale = null): array
    {
        return $this->map(ProductTranslation::class, 'product_id', $ids, $locale);
    }

    /**
     * 分类译文（按 category_id 索引）
     *
     * @param array<int,int> $ids
     * @return array<int,array<string,mixed>>
     */
    public function categoryMap(array $ids, ?string $locale = null): array
    {
        return $this->map(CategoryTranslation::class, 'category_id', $ids, $locale);
    }

    /**
     * 品牌译文（按 brand_id 索引）
     *
     * @param array<int,int> $ids
     * @return array<int,array<string,mixed>>
     */
    public function brandMap(array $ids, ?string $locale = null): array
    {
        return $this->map(BrandTranslation::class, 'brand_id', $ids, $locale);
    }

    /**
     * 单页译文
     *
     * @return array<string,mixed>|null
     */
    public function page(int $id, ?string $locale = null): ?array
    {
        $locale = $this->locale($locale);
        if ($locale === '' || $locale === base_locale() || $id <= 0) {
            return null;
        }

        $row = PageTranslation::where('page_id', $id)
            ->where('lang_code', $locale)
            ->where('status', 1)
            ->find();

        return $row ? $row->toArray() : null;
    }

    /**
     * 合并一组标量字段（空译文不覆盖英文）
     *
     * @param array<string,mixed> $base
     * @param array<string,mixed>|null $tr
     * @param array<int,string> $fields
     * @return array<string,mixed>
     */
    public function mergeFields(array $base, ?array $tr, array $fields): array
    {
        if (!$tr) {
            return $base;
        }

        foreach ($fields as $field) {
            if (!array_key_exists($field, $tr)) {
                continue;
            }
            $value = $tr[$field];
            if (is_string($value) && trim($value) === '') {
                continue;
            }
            if ($value === null) {
                continue;
            }
            $base[$field] = $value;
        }

        return $base;
    }

    /**
     * 合并规格：与主表 specs 同序，逐项回退
     *
     * @param array<int,array{name:string,values:array<int,string>}> $baseSpecs
     * @param array<int,array{name?:string,values?:array<int,string>}> $trSpecs
     * @return array<int,array{name:string,values:array<int,string>}>
     */
    public function mergeSpecs(array $baseSpecs, array $trSpecs): array
    {
        if (!$trSpecs) {
            return $baseSpecs;
        }

        $out = [];
        foreach ($baseSpecs as $index => $spec) {
            $tr = is_array($trSpecs[$index] ?? null) ? $trSpecs[$index] : [];
            $name = trim((string) ($tr['name'] ?? ''));
            $name = $name !== '' ? $name : (string) $spec['name'];

            $trValues = is_array($tr['values'] ?? null) ? array_values($tr['values']) : [];
            $values = [];
            foreach (array_values((array) $spec['values']) as $i => $value) {
                $translated = trim((string) ($trValues[$i] ?? ''));
                $values[] = $translated !== '' ? $translated : (string) $value;
            }

            $out[] = ['name' => $name, 'values' => $values];
        }

        return $out;
    }

    /**
     * 原始规格值 => 译文值 的映射，用于 SKU 的 spec_name / values
     *
     * @param array<int,array{name:string,values:array<int,string>}> $baseSpecs
     * @param array<int,array{name?:string,values?:array<int,string>}> $trSpecs
     * @return array<string,array<string,string>> [规格名 => [原文 => 译文]]
     */
    public function valueMap(array $baseSpecs, array $trSpecs): array
    {
        $map = [];
        foreach ($baseSpecs as $index => $spec) {
            $tr = is_array($trSpecs[$index] ?? null) ? $trSpecs[$index] : [];
            $trValues = is_array($tr['values'] ?? null) ? array_values($tr['values']) : [];
            foreach (array_values((array) $spec['values']) as $i => $value) {
                $translated = trim((string) ($trValues[$i] ?? ''));
                if ($translated !== '') {
                    $map[(string) $spec['name']][(string) $value] = $translated;
                }
            }
        }

        return $map;
    }

    /**
     * 把 SKU 的规格键值替换为译文
     *
     * @param array<string,string> $values 原始 spec_values_json
     * @param array<string,array<string,string>> $valueMap
     * @return array<string,string>
     */
    public function translateSkuValues(array $values, array $valueMap): array
    {
        if (!$valueMap) {
            return $values;
        }

        $out = [];
        foreach ($values as $name => $value) {
            $out[$name] = $valueMap[(string) $name][(string) $value] ?? $value;
        }

        return $out;
    }

    /**
     * 清除某实体的译文缓存（后续接缓存时使用）
     */
    public function flush(string $type, int $id): void
    {
        if ($type === 'product') {
            \app\common\lib\RedisCache::forget('product:detail:public:' . $id);
        }
    }

    /**
     * 保存一组翻译（后台手工编辑 / AI 结果）
     *
     * 结构：{"ru": {"title": "...", "subtitle": "...", "detail_html": "...", "status": 1}, ...}
     * 不在这里开事务：调用方（saveProduct / 单独保存）负责事务边界。
     *
     * @param string $type product|category|brand|page
     * @param array<string,array<string,mixed>> $payload
     * @return int 实际写入的语种数
     */
    public function saveTranslations(string $type, int $id, array $payload): int
    {
        $map = [
            'product'  => [ProductTranslation::class, 'product_id'],
            'category' => [CategoryTranslation::class, 'category_id'],
            'brand'    => [BrandTranslation::class, 'brand_id'],
            'page'     => [PageTranslation::class, 'page_id'],
        ];
        if (!isset($map[$type]) || $id <= 0) {
            throw new \app\common\exception\BizException('翻译实体无效');
        }
        [$model, $foreignKey] = $map[$type];

        $languages = new LanguageService();
        $fields = $this->editableFields($type);
        $sourceHash = $this->sourceHash($type, $id);
        $saved = 0;

        foreach ($payload as $lang => $data) {
            $lang = strtolower(trim((string) $lang));
            if ($lang === '' || $lang === base_locale() || !is_array($data)) {
                continue;
            }
            $language = $languages->find($lang);
            if (!$language) {
                throw new \app\common\exception\BizException('语种未启用：' . $lang);
            }

            $values = $this->normalizeTranslationValues($type, $data, $fields);

            $row = $model::where($foreignKey, $id)->where('lang_code', $lang)->find();
            $isNew = !$row;
            if ($isNew) {
                $row = new $model();
                $row->{$foreignKey} = $id;
                $row->lang_code = $lang;
            }

            foreach ($values as $field => $value) {
                $row->{$field} = $value;
            }

            $source = array_key_exists('source', $data)
                ? ((string) $data['source'] === 'ai' ? 'ai' : 'manual')
                : ($isNew ? 'manual' : ((string) $row->source === 'ai' ? 'ai' : 'manual'));
            $row->source = $source;

            if (array_key_exists('status', $data)) {
                $row->status = (int) $data['status'] === 1 ? 1 : 0;
            } elseif ($isNew) {
                $row->status = 1;
            }
            $row->stale = 0;
            $row->source_hash = $sourceHash !== '' ? $sourceHash : null;
            $row->translated_at = date('Y-m-d H:i:s');
            if (!empty($data['reviewed'])) {
                $row->reviewed_by = (int) (AppContext::getAdminId() ?? 0) ?: null;
                $row->reviewed_at = date('Y-m-d H:i:s');
            }
            $row->save();
            $saved++;
        }

        if ($saved > 0) {
            $this->flush($type, $id);
        }

        return $saved;
    }

    /**
     * 发布某语种译文（不覆盖人工/AI 内容）
     *
     * @param string $type product|category|brand|page
     * @param string $lang
     */
    public function publish(string $type, int $id, string $lang): void
    {
        $map = [
            'product'  => [ProductTranslation::class, 'product_id'],
            'category' => [CategoryTranslation::class, 'category_id'],
            'brand'    => [BrandTranslation::class, 'brand_id'],
            'page'     => [PageTranslation::class, 'page_id'],
        ];
        if (!isset($map[$type])) {
            throw new \app\common\exception\BizException('翻译实体无效');
        }
        [$model, $foreignKey] = $map[$type];
        $row = $model::where($foreignKey, $id)->where('lang_code', strtolower($lang))->find();
        if (!$row) {
            throw new \app\common\exception\BizException('译文不存在');
        }
        $row->status = 1;
        $row->stale = 0;
        $row->save();
        $this->flush($type, $id);
    }

    /**
     * 当前启用的目标语种（不含基准 en）
     *
     * @return array<int,string>
     */
    public function targetLocales(): array
    {
        $locales = [];
        foreach ((new LanguageService())->enabled() as $language) {
            $code = strtolower((string) $language['code']);
            if ($code !== '' && $code !== base_locale()) {
                $locales[] = $code;
            }
        }
        return $locales;
    }

    /**
     * 读取实体英文源字段（AI 翻译入队时快照）
     *
     * @return array<string,mixed>|null
     */
    public function sourceData(string $type, int $id): ?array
    {
        if ($id <= 0) {
            return null;
        }

        return match ($type) {
            'product' => $this->productSource($id),
            'category' => $this->categorySource($id),
            'brand' => $this->brandSource($id),
            'page' => $this->pageSource($id),
            default => null,
        };
    }

    /**
     * 源内容摘要，用于避免重复翻译
     */
    public function sourceHash(string $type, int $id): string
    {
        $data = $this->sourceData($type, $id);
        return $data ? md5(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) : '';
    }

    /**
     * 已发布译文是否与当前源一致
     */
    public function isUpToDate(string $type, int $id, string $lang): bool
    {
        $map = [
            'product'  => [ProductTranslation::class, 'product_id'],
            'category' => [CategoryTranslation::class, 'category_id'],
            'brand'    => [BrandTranslation::class, 'brand_id'],
            'page'     => [PageTranslation::class, 'page_id'],
        ];
        if (!isset($map[$type])) {
            return false;
        }
        [$model, $foreignKey] = $map[$type];
        $row = $model::where($foreignKey, $id)->where('lang_code', strtolower($lang))->find();
        if (!$row || (int) $row->status !== 1) {
            return false;
        }
        $hash = $this->sourceHash($type, $id);
        return $hash !== '' && (string) $row->source_hash === $hash;
    }

    /**
     * @return array<string,mixed>|null
     */
    private function productSource(int $id): ?array
    {
        $product = Product::find($id);
        if (!$product) {
            return null;
        }
        $specs = $product->specs_json;
        $specs = is_array($specs) ? $specs : (array) json_decode((string) $specs, true);
        $detail = (string) ($product->detail_html ?? '');
        $subtitle = (string) ($product->subtitle ?? '');

        return [
            'title'           => (string) $product->title,
            'subtitle'        => $subtitle,
            'detail_html'     => $detail,
            'specs_json'      => $this->cleanSpecs($specs),
            'seo_title'       => (string) $product->title,
            'seo_description' => $subtitle !== '' ? $subtitle : mb_substr(trim(strip_tags($detail)), 0, 160),
        ];
    }

    /**
     * @return array<string,mixed>|null
     */
    private function categorySource(int $id): ?array
    {
        $category = Category::find($id);
        if (!$category) {
            return null;
        }
        return [
            'name'            => (string) $category->name,
            'description'     => '',
            'seo_title'       => (string) $category->name,
            'seo_description' => '',
        ];
    }

    /**
     * @return array<string,mixed>|null
     */
    private function brandSource(int $id): ?array
    {
        $brand = Brand::find($id);
        if (!$brand) {
            return null;
        }
        return [
            'name'        => (string) $brand->name,
            'slogan'      => (string) ($brand->slogan ?? ''),
            'short_intro' => (string) ($brand->short_intro ?? ''),
            'description' => (string) ($brand->description ?? ''),
        ];
    }

    /**
     * @return array<string,mixed>|null
     */
    private function pageSource(int $id): ?array
    {
        $page = Page::find($id);
        if (!$page) {
            return null;
        }
        return [
            'title'           => (string) $page->title,
            'content'         => (string) ($page->content ?? ''),
            'seo_title'       => (string) ($page->seo_title ?? ''),
            'seo_keywords'    => (string) ($page->seo_keywords ?? ''),
            'seo_description' => (string) ($page->seo_description ?? ''),
        ];
    }

    /**
     * @param array<int,mixed> $specs
     * @return array<int,array{name:string,values:array<int,string>}>
     */
    private function cleanSpecs(array $specs): array
    {
        $out = [];
        foreach ($specs as $spec) {
            if (!is_array($spec)) {
                continue;
            }
            $name = trim((string) ($spec['name'] ?? ''));
            $values = [];
            foreach ((array) ($spec['values'] ?? []) as $value) {
                $values[] = trim((string) $value);
            }
            $out[] = ['name' => $name, 'values' => $values];
        }
        return $out;
    }

    /**
     * 各实体的可编辑字段
     *
     * @return array<int,string>
     */
    private function editableFields(string $type): array
    {
        return match ($type) {
            'product'  => ['title', 'subtitle', 'detail_html', 'seo_title', 'seo_description', 'specs_json'],
            'category' => ['name', 'description', 'seo_title', 'seo_description'],
            'brand'    => ['name', 'slogan', 'short_intro', 'description'],
            'page'     => ['title', 'content', 'seo_title', 'seo_keywords', 'seo_description'],
            default    => [],
        };
    }

    /**
     * 过滤、校验并清洗提交的翻译字段
     *
     * @param array<string,string> $fields
     * @return array<string,mixed>
     */
    private function normalizeTranslationValues(string $type, array $data, array $fields): array
    {
        $limits = [
            'title' => 255, 'subtitle' => 255, 'seo_title' => 255, 'seo_description' => 512,
            'name' => 191, 'description' => 0, 'slogan' => 100, 'short_intro' => 200,
            'content' => 0, 'seo_keywords' => 255, 'detail_html' => 0,
        ];

        $values = [];
        foreach ($fields as $field) {
            if (!array_key_exists($field, $data)) {
                continue;
            }
            if ($field === 'specs_json') {
                $values[$field] = $this->normalizeSpecsPayload($data[$field]);
                continue;
            }

            $value = $data[$field];
            if (is_array($value) || is_object($value)) {
                throw new \app\common\exception\BizException('翻译字段格式无效：' . $field);
            }
            $value = trim((string) $value);
            if ($limit = (int) ($limits[$field] ?? 0)) {
                if (mb_strlen($value) > $limit) {
                    throw new \app\common\exception\BizException('翻译字段超出长度限制：' . $field);
                }
            }

            if (in_array($field, ['detail_html', 'content', 'description'], true)) {
                $value = $value !== '' ? (new AdminCrudService())->sanitizeRichText($value) : '';
            }

            $values[$field] = $value !== '' ? $value : null;
        }

        return $values;
    }

    /**
     * 规格翻译：与主表同序的 [{name, values[]}]
     *
     * @param mixed $raw
     * @return array<int,array{name:string,values:array<int,string>}>
     */
    private function normalizeSpecsPayload($raw): array
    {
        if (is_string($raw)) {
            $raw = json_decode($raw, true);
        }
        if (!is_array($raw)) {
            throw new \app\common\exception\BizException('规格翻译格式无效');
        }

        $specs = [];
        foreach ($raw as $spec) {
            if (!is_array($spec)) {
                continue;
            }
            $name = trim((string) ($spec['name'] ?? ''));
            $values = [];
            foreach ((array) ($spec['values'] ?? []) as $value) {
                $values[] = trim((string) $value);
            }
            $specs[] = ['name' => mb_substr($name, 0, 128), 'values' => $values];
        }

        return array_slice($specs, 0, 20);
    }

    /**
     * @param class-string $model
     * @param array<int,int> $ids
     * @return array<int,array<string,mixed>>
     */
    private function map(string $model, string $foreignKey, array $ids, ?string $locale): array
    {
        $locale = $this->locale($locale);
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
        if ($locale === '' || $locale === base_locale() || !$ids) {
            return [];
        }

        $rows = $model::whereIn($foreignKey, $ids)
            ->where('lang_code', $locale)
            ->where('status', 1)
            ->select();

        $out = [];
        foreach ($rows as $row) {
            $out[(int) $row->getAttr($foreignKey)] = $row->toArray();
        }

        return $out;
    }
}