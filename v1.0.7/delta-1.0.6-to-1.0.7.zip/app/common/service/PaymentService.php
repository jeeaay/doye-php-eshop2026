<?php
declare (strict_types = 1);

namespace app\common\service;

use app\common\enum\OrderStatus;
use app\common\enum\PayStatus;
use app\common\exception\BizException;
use app\common\lib\DistributedLock;
use app\common\lib\payment\PaymentChannelCatalog;
use app\common\lib\payment\PaymentGatewayFactory;
use app\common\lib\payment\WechatPayGateway;
use app\common\model\OrderPay;
use think\facade\Db;

class PaymentService
{
    /**
     * Backwards-compatible entry point used by the mini-program.
     */
    public function createJsapiOrder(int $orderPayId, string $openid): array
    {
        return $this->createPayment($orderPayId, PaymentChannelCatalog::WECHAT, ['openid' => $openid]);
    }

    /**
     * Create a payment for any enabled channel.
     *
     * @return array Channel client payload. WeChat returns JSAPI params;
     *               redirect gateways return type/url/trade_no.
     */
    public function createPayment(int $orderPayId, string $channel = PaymentChannelCatalog::WECHAT, array $context = []): array
    {
        $channel = strtolower(trim($channel)) ?: PaymentChannelCatalog::WECHAT;
        if (!in_array($channel, PaymentChannelCatalog::codes(), true)) {
            throw new BizException('不支持的支付方式');
        }
        $allowed = is_domestic_edition()
            ? [PaymentChannelCatalog::WECHAT, PaymentChannelCatalog::ALIPAY]
            : [PaymentChannelCatalog::STRIPE, PaymentChannelCatalog::PAYPAL];
        if (!in_array($channel, $allowed, true)) {
            throw new BizException('当前站点版本不支持该支付方式');
        }
        $pay = OrderPay::find($orderPayId);
        if (!$pay) {
            throw new BizException('支付单不存在');
        }
        if ((int) $pay->pay_status !== PayStatus::UNPAID) {
            throw new BizException('订单已支付或已退款');
        }
        if (isset($context['user_id']) && (int) $context['user_id'] > 0
            && (int) $pay->user_id !== (int) $context['user_id']) {
            throw new BizException('无权支付该订单');
        }

        $config = PaymentGatewayFactory::configFor($channel);
        $result = PaymentGatewayFactory::make($channel)->createPayment($pay, $config, $context);

        $pay->channel = $channel;
        $pay->is_test = (int) ($config['_test_mode'] ?? 0);
        if (!empty($result['trade_no'])) {
            $pay->trade_no = (string) $result['trade_no'];
        }
        $pay->save();

        return $result;
    }

    /**
     * Unified notification handler.
     *
     * Keep the legacy signature so `payment:idemtest` and existing callers
     * continue to work. $testMode is only for local CLI tests; HTTP callbacks
     * always verify signatures.
     */
    public function handleNotify(
        string $rawBody,
        array $headers,
        bool $testMode = false,
        string $channel = PaymentChannelCatalog::WECHAT
    ): string {
        $channel = strtolower(trim($channel)) ?: PaymentChannelCatalog::WECHAT;
        if (!in_array($channel, PaymentChannelCatalog::codes(), true)) {
            throw new BizException('不支持的支付回调通道');
        }

        if ($testMode) {
            $payload = json_decode($rawBody, true);
            if (!is_array($payload)) {
                throw new BizException('支付回调数据无效');
            }
            $normalized = [
                'out_trade_no' => (string) ($payload['out_trade_no'] ?? ''),
                'trade_no'     => (string) ($payload['transaction_id'] ?? $payload['trade_no'] ?? ('test_' . time())),
                'amount_minor' => isset($payload['amount_minor'])
                    ? (int) $payload['amount_minor']
                    : (isset($payload['total_amount']) ? (int) bcmul((string) $payload['total_amount'], '100', 0) : null),
                'currency'     => (string) ($payload['currency'] ?? 'CNY'),
            ];
        } else {
            $verified = $this->verifyNotifyWithConfig($channel, $headers, $rawBody);
            $normalized = $verified['normalized'];
        }

        if (!empty($normalized['ignored'])) {
            return $this->notifySuccess($channel);
        }

        $outTradeNo = (string) ($normalized['out_trade_no'] ?? '');
        $tradeNo = (string) ($normalized['trade_no'] ?? '');
        if ($outTradeNo === '' && $tradeNo !== '') {
            // PayPal capture callbacks only carry the gateway order id; we
            // stored it on the payment row when the order was created.
            $pay = OrderPay::where('channel', $channel)->where('trade_no', $tradeNo)->find();
            if ($pay) {
                $outTradeNo = (string) $pay->id;
            }
        }
        if ($outTradeNo === '') {
            throw new BizException('支付回调缺少订单号');
        }

        $this->markPaid(
            $outTradeNo,
            $tradeNo,
            $channel,
            isset($normalized['amount_minor']) ? (int) $normalized['amount_minor'] : null,
            isset($normalized['currency']) ? (string) $normalized['currency'] : null
        );

        return $this->notifySuccess($channel);
    }

    public function getStatus(int $orderPayId, int $userId): array
    {
        $pay = OrderPay::where('id', $orderPayId)->where('user_id', $userId)->find();
        if (!$pay) {
            throw new BizException('支付单不存在');
        }
        return [
            'order_pay_id' => (int) $pay->id,
            'pay_status'   => (int) $pay->pay_status,
            'status_label' => $this->payStatusLabel((int) $pay->pay_status),
            'channel'      => (string) ($pay->channel ?? PaymentChannelCatalog::WECHAT),
            'is_test'      => (int) ($pay->is_test ?? 0),
            'total_amount' => (string) $pay->total_amount,
            'paid_at'      => $pay->paid_at ? (string) $pay->paid_at : '',
        ];
    }

    public function refund(int $orderPayId, int $amountCents, string $reason): array
    {
        $pay = OrderPay::find($orderPayId);
        if (!$pay) {
            throw new BizException('支付单不存在');
        }
        $channel = (string) ($pay->channel ?? PaymentChannelCatalog::WECHAT);
        if ($channel !== PaymentChannelCatalog::WECHAT) {
            throw new BizException('该支付通道暂未开放后台退款');
        }
        $gateway = PaymentGatewayFactory::make($channel);
        if (!$gateway instanceof WechatPayGateway) {
            throw new BizException('该支付通道暂未开放后台退款');
        }
        $config = PaymentGatewayFactory::configFor($channel, false, (bool) $pay->is_test);
        return $gateway->refund($pay, $config, $amountCents, $reason);
    }

    /**
     * Notifications do not carry the environment, so try the test and live
     * credentials in turn. Only the environment whose signature/credentials
     * match can produce a normalized payload.
     *
     * @return array{normalized:array,test_mode:bool}
     */
    private function verifyNotifyWithConfig(string $channel, array $headers, string $rawBody): array
    {
        $errors = [];
        foreach ([true, false] as $testMode) {
            try {
                $config = PaymentGatewayFactory::configFor($channel, false, $testMode);
                $normalized = PaymentGatewayFactory::make($channel)->verifyNotify($headers, $rawBody, $config);
                return ['normalized' => $normalized, 'test_mode' => $testMode];
            } catch (\Throwable $e) {
                $errors[] = ($testMode ? '测试环境' : '正式环境') . '：' . $e->getMessage();
            }
        }
        throw new BizException('支付回调验签失败（' . implode('；', $errors) . '）');
    }

    protected function markPaid(
        string $outTradeNo,
        string $tradeNo,
        string $channel,
        ?int $amountMinor,
        ?string $currency
    ): void {
        $lock = DistributedLock::lock('pay:' . $outTradeNo, 30);
        if (!$lock) {
            // Another worker is processing the same payment. Only acknowledge
            // when it is already settled; otherwise fail so the gateway retries
            // instead of dropping the notification.
            $current = OrderPay::find($outTradeNo);
            if ($current && (int) $current->pay_status === PayStatus::PAID) {
                return;
            }
            throw new BizException('支付结果处理中，请稍后重试');
        }
        try {
            $pay = OrderPay::find($outTradeNo);
            if (!$pay) {
                throw new BizException('支付单不存在');
            }
            if ((int) $pay->pay_status === PayStatus::PAID) {
                return;
            }
            $currency = strtoupper((string) $currency);
            $payCurrency = strtoupper((string) ($pay->charge_currency ?? 'USD')) ?: 'USD';
            if ($amountMinor !== null && ($currency === '' || $currency === $payCurrency)) {
                $expected = (int) bcmul((string) $pay->total_amount, '100', 0);
                if ($amountMinor !== $expected) {
                    throw new BizException('支付金额与订单金额不一致');
                }
            }

            Db::startTrans();
            try {
                $pay->pay_status = PayStatus::PAID;
                $pay->paid_at = date('Y-m-d H:i:s');
                $pay->channel = $channel;
                // is_test was recorded when the payment was created; do not
                // overwrite it if an admin flips the channel mode later.
                if ($tradeNo !== '') {
                    $pay->trade_no = $tradeNo;
                }
                if ($channel === PaymentChannelCatalog::WECHAT) {
                    $pay->wx_transaction_id = $tradeNo;
                }
                $pay->save();
                // Gateway callbacks run without an admin context; use the
                // query builder so no model-level scope or soft-delete
                // condition can hide the rows being updated.
                Db::name('order')
                    ->where('pay_id', $pay->id)
                    ->where('status', OrderStatus::PENDING_PAY)
                    ->update([
                        'status'      => OrderStatus::PENDING_SHIP,
                        'update_time' => date('Y-m-d H:i:s'),
                    ]);
                Db::commit();
            } catch (\Throwable $e) {
                Db::rollback();
                throw $e;
            }
        } finally {
            DistributedLock::unlock('pay:' . $outTradeNo, $lock);
        }
    }

    protected function notifySuccess(string $channel): string
    {
        if ($channel === PaymentChannelCatalog::ALIPAY) {
            return 'success';
        }
        return (string) json_encode(['code' => 'SUCCESS', 'message' => '成功']);
    }

    protected function notifyFail(string $message): string
    {
        return (string) json_encode(['code' => 'FAIL', 'message' => $message]);
    }

    private function payStatusLabel(int $status): string
    {
        return match ($status) {
            PayStatus::PAID => '已支付',
            PayStatus::REFUNDED => '已退款',
            default => '待支付',
        };
    }
}
