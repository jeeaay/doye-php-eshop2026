<?php

namespace app\common\service;

use app\common\enum\OrderStatus;
use app\common\enum\PayStatus;
use app\common\enum\SettleStatus;
use app\common\exception\BizException;
use app\common\lib\DelayQueue;
use app\common\lib\payment\PaymentChannelCatalog;
use app\common\model\Currency;
use app\common\model\Order;
use app\common\model\OrderAddress;
use app\common\model\OrderItem;
use app\common\model\OrderPay;
use app\common\model\ProductSku;
use app\common\support\LocaleContext;
use think\facade\Db;

class OrderService
{
    /** @var array<string,Currency|null> 订单展示币种缓存（按 code） */
    private static array $displayCurrencyCache = [];
    /**
     * 结算下单
     *
     * 优惠在事务外先算好（{@see CouponService::quote()}），
     * 事务内再按各商户订单的商品小计比例分摊折扣，使 order.total_amount 与
     * order_pay.total_amount 均为「实付金额」，支付、结算、退款直接可用。
     *
     * @param int      $userId       用户 ID
     * @param array    $items        结算明细 [['sku_id'=>int,'quantity'=>int], ...]
     * @param array    $address      收货地址
     * @param string   $remark       备注
     * @param string   $channel      支付通道
     * @param string   $couponCode   优惠码（可选）
     * @param int|null $couponUserId 已领取券记录 ID（可选）
     * @return OrderPay
     */
    public function checkout(
        int $userId,
        array $items,
        array $address,
        string $remark = '',
        string $channel = PaymentChannelCatalog::WECHAT,
        string $couponCode = '',
        ?int $couponUserId = null
    ): OrderPay {
        if (empty($items)) {
            throw new BizException('无结算商品');
        }
        $channel = strtolower(trim($channel));
        if (!in_array($channel, PaymentChannelCatalog::codes(), true)) {
            throw new BizException('不支持的支付方式');
        }
        $skuIds = array_map(fn($i) => (int)$i['sku_id'], $items);
        $skuList = ProductSku::with(['product.merchant'])->where('id', 'in', $skuIds)->select();
        $skuMap = [];
        foreach ($skuList as $s) {
            $skuMap[$s->id] = $s;
        }
        if (count($skuMap) != count(array_unique($skuIds))) {
            throw new BizException('部分商品规格不存在');
        }

        $groups = [];
        $grandTotal = '0.00';
        $discountRows = [];
        foreach ($items as $it) {
            $skuId = (int)$it['sku_id'];
            $qty = (int)$it['quantity'];
            $sku = $skuMap[$skuId] ?? null;
            if (!$sku || $sku->status != 1) {
                throw new BizException('规格已下架');
            }
            $product = $sku->product;
            if (!$product || $product->status != 1) {
                throw new BizException('商品已下架:' . ($product ? $product->title : ''));
            }
            $merchantId = (int)$product->merchant_id;
            $groups[$merchantId][] = ['sku' => $sku, 'qty' => $qty];
            $lineTotal = bcmul((string)$sku->price, (string)$qty, 2);
            $grandTotal = bcadd($grandTotal, $lineTotal, 2);
            $discountRows[] = ['product_id' => (int)$sku->product_id, 'subtotal' => $lineTotal];
        }

        // 优惠试算：全站自动优惠 + 用户券/优惠码；失败时直接抛错提示用户
        $couponService = new CouponService();
        $quote = $couponService->quote($discountRows, $grandTotal, $userId, $couponUserId, $couponCode);
        $discountTotal = $quote['discount'];
        $payableTotal = $quote['payable'];

        // 订单只收 USD；展示币种仅作为参考价快照
        $displayCurrency = LocaleContext::currency();
        $pricing = new PricingService();
        $displayCode = strtoupper((string) ($displayCurrency['code'] ?? 'USD'));
        $displayRate = $pricing->displayRate($displayCurrency);
        $chargeCurrency = base_currency_code();

        $stock = new StockService();
        Db::startTrans();
        try {
            foreach ($groups as $rows) {
                foreach ($rows as $r) {
                    if (!$stock->preDeduct($r['sku']->id, $r['qty'])) {
                        throw new BizException('库存不足:' . $r['sku']->spec_name);
                    }
                }
            }
            $pay = new OrderPay();
            $pay->user_id = $userId;
            $pay->total_amount = $payableTotal;
            $pay->discount_amount = $discountTotal;
            $pay->channel = $channel;
            $pay->pay_method = $channel === PaymentChannelCatalog::WECHAT ? 'wechat_jsapi' : $channel;
            $pay->pay_status = PayStatus::UNPAID;
            $pay->charge_currency = $chargeCurrency;
            $pay->save();

            $merchantIds = array_keys($groups);
            $lastIndex = count($merchantIds) - 1;
            $allocated = '0.00';
            foreach ($merchantIds as $index => $merchantId) {
                $rows = $groups[$merchantId];
                $orderSubtotal = '0.00';
                $itemCount = 0;
                foreach ($rows as $r) {
                    $orderSubtotal = bcadd($orderSubtotal, bcmul((string)$r['sku']->price, (string)$r['qty'], 2), 2);
                    $itemCount += $r['qty'];
                }

                // 按商品小计占比分摊总折扣，最后一家吃掉尾差，保证各单折扣之和等于总折扣
                if (bccomp($discountTotal, '0', 2) <= 0 || bccomp($grandTotal, '0', 2) <= 0) {
                    $orderDiscount = '0.00';
                } elseif ($index === $lastIndex) {
                    $orderDiscount = bcsub($discountTotal, $allocated, 2);
                } else {
                    $orderDiscount = bcmul(bcdiv($orderSubtotal, $grandTotal, 6), $discountTotal, 2);
                    $allocated = bcadd($allocated, $orderDiscount, 2);
                }
                if (bccomp($orderDiscount, $orderSubtotal, 2) > 0) {
                    $orderDiscount = $orderSubtotal;
                }

                $order = new Order();
                $order->order_no = $this->genOrderNo();
                $order->pay_id = $pay->id;
                $order->user_id = $userId;
                $order->merchant_id = $merchantId;
                $order->status = OrderStatus::PENDING_PAY;
                $order->total_amount = bcsub($orderSubtotal, $orderDiscount, 2);
                $order->discount_amount = $orderDiscount;
                $order->item_count = $itemCount;
                $order->settle_status = SettleStatus::UNSETTLED;
                $order->charge_currency = $chargeCurrency;
                $order->display_currency = $displayCode;
                $order->display_rate = $displayRate;
                $order->display_total_amount = $pricing->convert($order->total_amount, $displayCurrency);
                $order->display_rate_at = date('Y-m-d H:i:s');
                $order->remark = $remark !== '' ? $remark : null;
                $order->save();

                foreach ($rows as $r) {
                    $sku = $r['sku'];
                    $item = new OrderItem();
                    $item->order_id = $order->id;
                    $item->sku_id = $sku->id;
                    $item->product_id = $sku->product_id;
                    $item->sku_snapshot_json = [
                        'title' => $sku->product->title,
                        'spec_name' => $sku->spec_name,
                        'main_image' => $sku->product->main_image,
                        'price' => (string)$sku->price,
                    ];
                    $item->quantity = $r['qty'];
                    $item->unit_price = $sku->price;
                    $item->total_price = bcmul((string)$sku->price, (string)$r['qty'], 2);
                    $item->save();
                }

                $addr = new OrderAddress();
                $addr->order_id = $order->id;
                $addr->name = $address['name'];
                $addr->phone = $address['phone'];
                $addr->address_detail = $address['address_detail'];
                $addr->save();
            }

            // 核销优惠：已领券置为已使用，优惠码写入使用记录
            $couponService->consume($quote['coupon_user_id'], $quote['code_coupon_id'], $userId, (int)$pay->id);

            Db::commit();
            foreach ($items as $item) {
                $stock->commitDeduct((int) $item['sku_id'], (int) $item['quantity']);
            }
            DelayQueue::delay('order_cancel', ['order_pay_id' => (int)$pay->id], time() + 900);
            return $pay;
        } catch (\Throwable $e) {
            Db::rollback();
            throw $e;
        }
    }

    public function getOrderList(int $userId, int $page = 1, int $size = 15)
    {
        return (new Order())->db(['merchant'])
            ->where('user_id', $userId)
            ->order('id', 'desc')
            ->paginate(['list_rows' => $size, 'page' => $page]);
    }

    public function getOrderDetail(int $orderId, int $userId): ?Order
    {
        // User-facing reads are scoped by user_id; the model's merchant
        // scope is for admin queries and would otherwise hide API results.
        return (new Order())->db(['merchant'])
            ->with(['items', 'address', 'pay', 'merchant', 'aftersale'])
            ->where('id', $orderId)
            ->where('user_id', $userId)
            ->find();
    }

    /**
     * 订单展示金额：订单币种实付 + 下单时的展示币种参考价
     *
     * 国际版 charge=USD，display=用户选择的币种；
     * 国内版 charge=CNY，display=CNY，无参考价。
     *
     * @return array{charge_currency:string,charge_text:string,currency:string,usd_text:string,local_text:string,rate:string,is_reference:bool}
     */
    public function displaySummary(Order $order): array
    {
        $pricing = new PricingService();
        $chargeCode = strtoupper((string) ($order->charge_currency ?? 'USD')) ?: 'USD';
        $chargeText = $pricing->formatAmount($order->total_amount, $this->orderCurrency($chargeCode));

        $displayCode = strtoupper((string) ($order->display_currency ?? $chargeCode)) ?: $chargeCode;
        $localAmount = (float) ($order->display_total_amount ?? 0);

        $localText = '';
        $isReference = false;
        if ($displayCode !== $chargeCode && $localAmount > 0) {
            $localText = $pricing->formatAmount($order->display_total_amount, $this->orderCurrency($displayCode));
            $isReference = true;
        }

        return [
            'charge_currency' => $chargeCode,
            'charge_text'     => $chargeText,
            'currency'        => $displayCode,
            'usd_text'        => $chargeText, // 兼容旧字段
            'local_text'      => $localText,
            'rate'            => (string) ($order->display_rate ?? '1'),
            'is_reference'    => $isReference,
        ];
    }

    /**
     * 订单展示用币种数组（含已停用币种，历史订单仍可显示）
     *
     * @return array<string,mixed>
     */
    private function orderCurrency(string $code): array
    {
        $code = strtoupper($code);
        if (!array_key_exists($code, self::$displayCurrencyCache)) {
            self::$displayCurrencyCache[$code] = Currency::where('code', $code)->find();
        }
        $currency = self::$displayCurrencyCache[$code];
        if ($currency) {
            return $currency->toArray();
        }

        $isCny = $code === 'CNY';
        return [
            'code'            => $code,
            'symbol'          => $isCny ? '¥' : ($code === 'USD' ? '$' : $code),
            'decimals'        => 2,
            'symbol_position' => 'before',
            'symbol_space'    => $code === 'USD' || $isCny ? 0 : 1,
        ];
    }

    /**
     * Build the order status timeline.
     *
     * Prefers precise timestamps (`ship_at`, `deliver_at`, `pay.paid_at`,
     * `confirm_at`) and falls back to `update_time` for legacy rows that
     * predate the dedicated columns, matching the previous inline behavior
     * in Order::detail().
     *
     * @return array<int, array{label: string, time: string}>
     */
    public function buildTimeline(Order $order): array
    {
        $timeline = [
            ['label' => '下单成功', 'time' => $order->create_time ? (string)$order->create_time : ''],
        ];

        if ($order->pay && $order->pay->paid_at) {
            $timeline[] = ['label' => '已支付', 'time' => (string)$order->pay->paid_at];
        }

        if ($order->ship_at) {
            $timeline[] = ['label' => '已发货', 'time' => (string)$order->ship_at];
        } elseif ($order->status >= OrderStatus::SHIPPING) {
            $timeline[] = ['label' => '已发货', 'time' => (string)$order->update_time];
        }

        if ($order->deliver_at) {
            $timeline[] = ['label' => '已送达', 'time' => (string)$order->deliver_at];
        } elseif ($order->status >= OrderStatus::DELIVERED) {
            $timeline[] = ['label' => '已送达', 'time' => (string)$order->update_time];
        }

        if ($order->status >= OrderStatus::COMPLETED && $order->confirm_at) {
            $timeline[] = ['label' => '已完成', 'time' => (string)$order->confirm_at];
        }

        return $timeline;
    }

    public function merchantMarkShipping(int $orderId, int $merchantId): void
    {
        $order = Order::where('id', $orderId)->where('merchant_id', $merchantId)->find();
        if (!$order) {
            throw new BizException('订单不存在');
        }
        if ($order->status != OrderStatus::PENDING_SHIP) {
            throw new BizException('订单状态不允许发货');
        }
        $order->status = OrderStatus::SHIPPING;
        $order->save();
    }

    public function merchantMarkDelivered(int $orderId, int $merchantId): void
    {
        $order = Order::where('id', $orderId)->where('merchant_id', $merchantId)->find();
        if (!$order) {
            throw new BizException('订单不存在');
        }
        if ($order->status != OrderStatus::SHIPPING) {
            throw new BizException('订单状态不允许标记送达');
        }
        $order->status = OrderStatus::DELIVERED;
        $order->save();
        // TODO S6: queue order_auto_confirm task (delay 7 days)
    }

    public function confirmReceipt(int $orderId, int $userId): void
    {
        $order = (new Order())->db(['merchant'])
            ->where('id', $orderId)
            ->where('user_id', $userId)
            ->find();
        if (!$order) {
            throw new BizException('订单不存在');
        }
        if ($order->status != OrderStatus::DELIVERED) {
            throw new BizException('订单状态不允许确认收货');
        }
        $order->status = OrderStatus::COMPLETED;
        $order->confirm_at = date('Y-m-d H:i:s');
        $order->save();
        // TODO S6: queue settle_window_close task (delay 7 days) then status SETTLEABLE
    }

    public function cancelUnpaid(int $orderPayId, int $userId): void
    {
        $pay = OrderPay::where('id', $orderPayId)->where('user_id', $userId)->find();
        if (!$pay) {
            throw new BizException('支付单不存在');
        }
        if ($pay->pay_status != PayStatus::UNPAID) {
            throw new BizException('订单已支付,无法取消');
        }
        Db::startTrans();
        try {
            $orders = (new Order())->db(['merchant'])->where('pay_id', $pay->id)->select();
            $stock = new StockService();
            foreach ($orders as $order) {
                if ($order->status != OrderStatus::PENDING_PAY) {
                    continue;
                }
                foreach ($order->items as $item) {
                    $stock->release($item->sku_id, $item->quantity);
                }
                $order->status = OrderStatus::CANCELLED;
                $order->save();
            }
            Db::commit();
            foreach ($orders as $order) {
                foreach ($order->items as $item) {
                    $stock->commitDeduct((int)$item->sku_id, (int)$item->quantity);
                }
            }
        } catch (\Throwable $e) {
            Db::rollback();
            throw $e;
        }
    }

    public function cancelUnpaidByPayId(int $orderPayId): void
    {
        $pay = OrderPay::find($orderPayId);
        if (!$pay) {
            return;
        }
        if ($pay->pay_status != PayStatus::UNPAID) {
            return;
        }
        Db::startTrans();
        try {
            $orders = (new Order())->db(['merchant'])->where('pay_id', $pay->id)->select();
            $stock = new StockService();
            foreach ($orders as $order) {
                if ($order->status != OrderStatus::PENDING_PAY) {
                    continue;
                }
                foreach ($order->items as $item) {
                    $stock->release((int)$item->sku_id, (int)$item->quantity);
                }
                $order->status = OrderStatus::CANCELLED;
                $order->save();
            }
            Db::commit();
            foreach ($orders as $order) {
                foreach ($order->items as $item) {
                    $stock->commitDeduct((int)$item->sku_id, (int)$item->quantity);
                }
            }
        } catch (\Throwable $e) {
            Db::rollback();
            throw $e;
        }
    }

    protected function genOrderNo(): string
    {
        return date('YmdHis') . str_pad((string)mt_rand(0, 999999), 6, '0', STR_PAD_LEFT);
    }
}
