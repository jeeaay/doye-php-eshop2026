<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\exception\BizException;
use app\common\model\Setting;
use think\db\exception\PDOException;
use think\facade\Cache;
use think\facade\Config;

/**
 * 站点系统设置服务
 *
 * 存储模型：数据库 setting 表只保存「被后台改过」的项，未保存的项回退 config/site.php 默认值。
 * 前台读取入口统一收敛到公共函数 site_config()，它内部调用 {@see self::mergedConfig()}。
 * 后台「系统设置」页面按 config/setting.php 的分组注册表渲染，按分组整组保存。
 */
class SettingService
{
    /** 覆盖值缓存键 */
    private const CACHE_KEY = 'site:setting:overrides';

    /** 覆盖值缓存时长（秒） */
    private const CACHE_TTL = 3600;

    /** @var array<string,array>|null 字段注册表（点分 key => 字段定义）惰性缓存 */
    private static ?array $schemaCache = null;

    /** @var array<string,mixed>|null 单次请求内合并后的站点配置 */
    private static ?array $mergedCache = null;

    /**
     * 读取字段注册表（点分 key => 字段定义）
     *
     * @return array<string,array>
     */
    public static function schema(): array
    {
        if (self::$schemaCache !== null) {
            return self::$schemaCache;
        }

        $map = [];
        foreach (self::groups() as $group) {
            foreach ((array) ($group['fields'] ?? []) as $key => $def) {
                $map[(string) $key] = (array) $def;
            }
        }

        return self::$schemaCache = $map;
    }

    /**
     * 读取全部分组定义
     *
     * @return array<string,array>
     */
    public static function groups(): array
    {
        return (array) Config::get('setting.groups', []);
    }

    /**
     * 读取数据库中已保存的设置覆盖值（点分 key => 已按类型转换的值）
     *
     * 结果带缓存；数据表尚未创建（安装/迁移阶段）时静默返回空数组，回退配置文件。
     *
     * @return array<string,mixed>
     */
    public static function overrides(): array
    {
        try {
            return (array) Cache::remember(self::CACHE_KEY, function () {
                $schema = self::schema();
                $out = [];
                foreach (Setting::column('value', 'key') as $key => $value) {
                    $type = $schema[(string) $key]['type'] ?? 'text';
                    $out[(string) $key] = self::castValue($value, $type);
                }
                return $out;
            }, self::CACHE_TTL);
        } catch (PDOException $e) {
            return [];
        }
    }

    /**
     * 合并后的站点配置：config/site.php 默认值 + setting 表覆盖值
     *
     * 单次请求内只计算一次，避免模板中多次调用 site_config() 造成重复查询。
     *
     * @return array<string,mixed>
     */
    public static function mergedConfig(): array
    {
        if (self::$mergedCache !== null) {
            return self::$mergedCache;
        }

        $config = (array) Config::get('site', []);
        foreach (self::overrides() as $path => $value) {
            self::setByPath($config, $path, $value);
        }

        return self::$mergedCache = $config;
    }

    /**
     * 清空设置缓存（保存后调用）
     *
     * @return void
     */
    public static function flush(): void
    {
        self::$mergedCache = null;
        Cache::delete(self::CACHE_KEY);

        // 安全设置有自己的 Redis 缓存，任何设置保存后都要一并失效
        SecurityService::flushSettingsCache();
    }

    /**
     * 按类型转换存储值
     *
     * @param mixed  $value 数据库中的原始字符串值
     * @param string $type  字段类型（见 config/setting.php）
     * @return mixed 转换后的值
     */
    public static function castValue($value, string $type)
    {
        return match ($type) {
            'bool'   => in_array((string) $value, ['1', 'true', 'on', 'yes'], true),
            'number' => is_numeric($value) ? $value + 0 : 0,
            default  => (string) $value,
        };
    }

    /**
     * 后台「系统设置」页面数据：全部分组 + 各字段当前值
     *
     * 敏感字段不下发真实值，仅通过 has_value 告知前端「是否已设置」。
     *
     * @return array<int,array> 分组列表，每项含 key/title/desc/fields
     */
    public function groupList(): array
    {
        $groups = [];
        foreach (self::groups() as $key => $definition) {
            // standalone 分组有独立后台页面（如安全设置），不在「系统设置」标签里重复展示
            if (!empty($definition['standalone'])) {
                continue;
            }
            $groups[] = $this->group((string) $key);
        }
        return $groups;
    }

    /**
     * 读取单个分组的结构与当前值
     *
     * @param string $group 分组标识（如 mail）
     * @return array{key:string,title:string,desc:string,fields:array}
     */
    public function group(string $group): array
    {
        $groups = self::groups();
        if (!isset($groups[$group])) {
            throw new BizException('设置分组不存在');
        }

        $fields = [];
        foreach ((array) ($groups[$group]['fields'] ?? []) as $key => $def) {
            $key    = (string) $key;
            $type   = (string) ($def['type'] ?? 'text');
            $secret = !empty($def['secret']);
            $value  = site_config($key, '');

            if ($secret) {
                $def['has_value'] = (string) $value !== '';
                $value = '';
            } elseif ($type === 'bool') {
                $value = (bool) $value;
            } else {
                $value = (string) $value;
            }

            $fields[] = array_merge(
                ['label' => $key, 'placeholder' => '', 'help' => '', 'rows' => 3, 'options' => []],
                $def,
                ['key' => $key, 'value' => $value]
            );
        }

        return [
            'key'    => $group,
            'title'  => (string) ($groups[$group]['title'] ?? $group),
            'desc'   => (string) ($groups[$group]['desc'] ?? ''),
            'fields' => $fields,
        ];
    }

    /**
     * 保存某个分组（整组提交）
     *
     * 规则：布尔项未勾选时显式写 0；敏感项留空表示保持原值；只读项忽略提交。
     *
     * @param string $group 分组标识
     * @param array  $data  表单数据
     * @return void
     * @throws BizException 分组不存在或字段校验失败
     */
    public function save(string $group, array $data): void
    {
        $groups = self::groups();
        if (!isset($groups[$group])) {
            throw new BizException('设置分组不存在');
        }

        try {
            foreach ((array) ($groups[$group]['fields'] ?? []) as $key => $def) {
                $key    = (string) $key;
                $type   = (string) ($def['type'] ?? 'text');
                $secret = !empty($def['secret']);

                if ($type === 'readonly') {
                    continue;
                }

                if ($type === 'bool') {
                    self::put($key, !empty($data[$key]) ? '1' : '0');
                    continue;
                }

                if (!array_key_exists($key, $data)) {
                    continue;
                }

                $value = trim((string) $data[$key]);

                // 敏感项留空 = 不修改已保存的值
                if ($secret && $value === '') {
                    continue;
                }

                if ($type === 'number' && $value !== '' && !is_numeric($value)) {
                    throw new BizException((string) ($def['label'] ?? $key) . ' 必须是数字');
                }

                self::put($key, $value);
            }
        } catch (PDOException $e) {
            throw new BizException('保存失败：' . $e->getMessage());
        }

        self::flush();
    }

    /**
     * 写入单个设置项（供非表单场景使用，如站点版本切换）
     *
     * @param string $key
     * @param mixed $value
     */
    public static function set(string $key, $value): void
    {
        self::put($key, (string) $value);
        self::flush();
    }

    /**
     * 写入单个设置项（存在则更新，不存在则新增）
     *
     * @param string $key   设置键（点分路径）
     * @param string $value 设置值
     * @return void
     */
    private static function put(string $key, string $value): void
    {
        $row = Setting::where('key', $key)->find();
        if ($row) {
            $row->value = $value;
            $row->save([], ['id' => (int) $row->id]);
            return;
        }

        $row = new Setting();
        $row->key = $key;
        $row->value = $value;
        $row->save();
    }

    /**
     * 按点分路径把值写入嵌套数组
     *
     * @param array  $arr   目标数组（引用传入）
     * @param string $path  点分路径，如 currency.code
     * @param mixed  $value 要写入的值
     * @return void
     */
    private static function setByPath(array &$arr, string $path, $value): void
    {
        $ref = &$arr;
        foreach (explode('.', $path) as $segment) {
            if (!isset($ref[$segment]) || !is_array($ref[$segment])) {
                $ref[$segment] = [];
            }
            $ref = &$ref[$segment];
        }
        $ref = $value;
    }
}
