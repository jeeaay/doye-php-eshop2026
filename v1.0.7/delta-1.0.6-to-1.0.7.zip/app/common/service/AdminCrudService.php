<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\enum\AdminRole;
use app\common\enum\OrderStatus;
use app\common\lib\RedisCache;
use app\common\exception\BizException;
use app\common\model\Admin;
use app\common\model\Aftersale;
use app\common\model\Brand;
use app\common\model\Category;
use app\common\model\Merchant;
use app\common\model\Order;
use app\common\model\Product;
use app\common\model\ProductSku;
use app\common\model\ProductTranslation;
use app\common\model\ShareReferral;
use app\common\model\Settlement;
use app\common\model\Withdraw;
use app\common\support\AppContext;
use think\db\exception\PDOException;
use think\facade\Db;

class AdminCrudService
{
    private function merchantIds(): array
    {
        return AppContext::getMerchantIds();
    }

    private function assertSuper(): void
    {
        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            throw new BizException('仅平台管理员可执行此操作');
        }
    }

    private function assertStaffManagementAccess(): void
    {
        if (AppContext::getAdminRole() === AdminRole::STAFF) {
            throw new BizException('无权访问人员管理');
        }
    }

    private function scopedProduct(int $id): Product
    {
        $product = Product::find($id);
        if (!$product || (AppContext::getAdminRole() !== AdminRole::SUPER && (empty($this->merchantIds()) || !in_array((int) $product->merchant_id, $this->merchantIds(), true)))) {
            throw new BizException('商品不存在');
        }
        return $product;
    }

    private function scopedAftersale(int $id): Aftersale
    {
        $aftersale = Aftersale::find($id);
        if (!$aftersale || (AppContext::getAdminRole() !== AdminRole::SUPER && (empty($this->merchantIds()) || !in_array((int) $aftersale->merchant_id, $this->merchantIds(), true)))) {
            throw new BizException('售后单不存在');
        }
        return $aftersale;
    }

    public function saveProduct(array $data, ?int $id = null): Product
    {
        $title = trim((string) ($data['title'] ?? ''));
        $categoryId = (int) ($data['category_id'] ?? 0);
        $mainImage = trim((string) ($data['main_image'] ?? ''));
        if ($title === '' || $categoryId <= 0 || $mainImage === '') {
            throw new BizException('商品名称、分类和主图不能为空');
        }
        if (!Category::find($categoryId)) {
            throw new BizException('商品分类不存在');
        }
        $images = $data['images_json'] ?? [];
        if (is_string($images)) {
            $images = json_decode($images, true);
        }
        if (!is_array($images)) throw new BizException('展示图片数据无效');
        $this->assertLocalMediaUrl($mainImage);
        foreach ((array) $images as $imageUrl) {
            if (!is_string($imageUrl) || $imageUrl === '') throw new BizException('展示图片地址无效');
            $this->assertLocalMediaUrl($imageUrl, 'image');
        }
        if (!empty($data['video_url'])) $this->assertLocalMediaUrl((string) $data['video_url'], 'video');
        if (!empty($data['video_cover'])) $this->assertLocalMediaUrl((string) $data['video_cover'], 'image');
        $specs = $this->normalizeSpecs($data['specs_json'] ?? []);
        $skus = $this->normalizeSkus($data['skus'] ?? [], $specs);
        $merchantIds = $this->merchantIds();
        $existingProduct = $id ? $this->scopedProduct($id) : null;
        if ($existingProduct && $this->specificationShapeChanged($existingProduct, $skus)
            && (string) ($data['spec_change_confirmed'] ?? '') !== '1') {
            throw new BizException('规格变更会影响已有 SKU 的价格、库存或编码，请确认后再保存');
        }
        if (empty($merchantIds) && AppContext::getAdminRole() !== AdminRole::SUPER) {
            throw new BizException('商户管理员未绑定商户');
        }
        $targetMerchantId = AppContext::getAdminRole() === AdminRole::SUPER
            ? (int) ($data['merchant_id'] ?? ($existingProduct?->merchant_id ?? 0))
            : (int) ($existingProduct?->merchant_id ?? ($data['merchant_id'] ?? ($merchantIds[0] ?? 0)));
        if (!$targetMerchantId || !Merchant::find($targetMerchantId)) {
            throw new BizException('请选择商户');
        }
        if (AppContext::getAdminRole() !== AdminRole::SUPER && !in_array($targetMerchantId, $merchantIds, true)) {
            throw new BizException('无权切换商户');
        }

        // 品牌校验：0/空 表示无品牌；非空时必须存在且与所选商户一致（D5）
        $brandId = (int) ($data['brand_id'] ?? 0);
        if ($brandId > 0) {
            $brand = Brand::find($brandId);
            if (!$brand || (int) $brand->merchant_id !== $targetMerchantId) {
                throw new BizException('品牌不存在或与所选商户不一致');
            }
        }

        Db::startTrans();
        try {
            $product = $existingProduct ?? new Product();
            $product->merchant_id = $targetMerchantId;
            $product->category_id = $categoryId;
            $product->title = $title;
            $product->brand_id = $brandId > 0 ? $brandId : null;
            $product->subtitle = trim((string) ($data['subtitle'] ?? '')) ?: null;
            $product->main_image = $mainImage;
            $product->images_json = array_values($images);
            $product->video_url = trim((string) ($data['video_url'] ?? '')) ?: null;
            $product->video_cover = trim((string) ($data['video_cover'] ?? '')) ?: null;
            $videoMeta = $data['video_meta_json'] ?? [];
            if (is_string($videoMeta)) $videoMeta = json_decode($videoMeta, true);
            if (!is_array($videoMeta)) throw new BizException('视频元信息无效');
            $product->video_meta_json = $videoMeta;
            $product->specs_json = $specs;
            $product->detail_html = $this->sanitizeRichText((string) ($data['detail_html'] ?? ''));
            $product->status = (int) ($data['status'] ?? 0);
            if (!in_array((int) $product->status, [0, 1, 2], true)) {
                throw new BizException('商品状态无效');
            }
            $product->sort = (int) ($data['sort'] ?? 0);
            $product->save();

            $existingSkus = ProductSku::where('product_id', $product->id)->select();
            $existingByCombination = [];
            foreach ($existingSkus as $existingSku) {
                $values = (array) $existingSku->spec_values_json;
                ksort($values);
                $existingByCombination[json_encode($values, JSON_UNESCAPED_UNICODE)] = $existingSku;
            }
            $savedCombinationKeys = [];
            foreach ($skus as $skuData) {
                $values = $skuData['spec_values_json'];
                ksort($values);
                $key = json_encode($values, JSON_UNESCAPED_UNICODE);
                $savedCombinationKeys[$key] = true;
                $sku = $existingByCombination[$key] ?? new ProductSku();
                $sku->product_id = $product->id;
                $sku->save($skuData);
            }
            foreach ($existingByCombination as $key => $existingSku) {
                if (isset($savedCombinationKeys[$key])) {
                    continue;
                }
                if (Db::name('cart')->where('sku_id', $existingSku->id)->find()) {
                    throw new BizException('该 SKU 已加入购物车，不能删除或移除其规格组合');
                }
                $existingSku->delete();
            }

            $translations = $data['translations'] ?? [];
            if ($translations === '' || $translations === null) {
                $translations = [];
            }
            if (is_string($translations)) {
                $translations = json_decode($translations, true);
            }
            if (!is_array($translations)) {
                throw new BizException('翻译数据格式无效');
            }
            if ($translations) {
                (new TranslationService())->saveTranslations('product', (int) $product->id, $translations);
            }

            Db::commit();
        } catch (\Throwable $e) {
            Db::rollback();
            throw $e;
        }
        RedisCache::forget('product:detail:public:' . (int) $product->id);
        RedisCache::forget('category:tree');

        // 保存后自动补全缺失语种（失败不影响商品保存）
        if ((bool) site_config('i18n.auto_translate_on_save', false)) {
            try {
                (new TranslationJobService())->enqueue('product', (int) $product->id, [], false, 1);
            } catch (\Throwable $e) {
                \think\facade\Log::warning('auto translate enqueue failed: ' . $e->getMessage());
            }
        }

        return $product->refresh();
    }

    public function productDetail(int $id): array
    {
        $product = $this->scopedProduct($id);
        $product->skus;
        $specs = (array) $product->specs_json;
        if (!$specs) {
            $legacy = [];
            foreach ($product->skus as $sku) {
                foreach ((array) $sku->spec_values_json as $name => $value) {
                    $legacy[$name][$value] = true;
                }
            }
            foreach ($legacy as $name => $values) {
                $specs[] = ['name' => $name, 'values' => array_keys($values)];
            }
        }
        return [
            'id' => (int) $product->id, 'merchant_id' => (int) $product->merchant_id,
            'category_id' => (int) $product->category_id, 'title' => $product->title,
            'subtitle' => $product->subtitle, 'main_image' => $product->main_image,
            'brand_id' => (int) ($product->brand_id ?? 0),
            'images_json' => (array) $product->images_json, 'video_url' => $product->video_url,
            'video_cover' => $product->video_cover, 'video_meta_json' => (array) $product->video_meta_json,
            'detail_html' => $this->sanitizeRichText((string) $product->detail_html), 'status' => (int) $product->status,
            'sort' => (int) $product->sort, 'specs_json' => $specs,
            'skus' => array_map(static fn($sku) => [
                'spec_name' => $sku->spec_name, 'spec_values_json' => (array) $sku->spec_values_json,
                'price' => (string) $sku->price, 'stock' => (int) $sku->stock,
                'sku_code' => $sku->sku_code, 'status' => (int) $sku->status,
            ], $product->skus->all()),
            'translations' => $this->productTranslations((int) $product->id),
        ];
    }

    /**
     * 商品全部语种翻译（后台编辑用，包含草稿）
     *
     * @param int $id 商品 ID（调用前已完成范围校验）
     * @return array<string,array<string,mixed>> 以 lang_code 为键
     */
    public function productTranslations(int $id): array
    {
        $rows = ProductTranslation::where('product_id', $id)->order('id')->select();
        $out = [];
        foreach ($rows as $row) {
            $out[(string) $row->lang_code] = [
                'title'           => (string) ($row->title ?? ''),
                'subtitle'        => (string) ($row->subtitle ?? ''),
                'detail_html'     => $this->sanitizeRichText((string) ($row->detail_html ?? '')),
                'seo_title'       => (string) ($row->seo_title ?? ''),
                'seo_description' => (string) ($row->seo_description ?? ''),
                'specs_json'      => (array) $row->specs_json,
                'source'          => (string) $row->source,
                'status'          => (int) $row->status,
                'stale'           => (int) $row->stale,
                'reviewed_at'     => $row->reviewed_at ? (string) $row->reviewed_at : '',
                'translated_at'   => $row->translated_at ? (string) $row->translated_at : '',
            ];
        }
        return $out;
    }

    /**
     * 单独保存商品翻译（管理 API 用；内部仍走同一个 TranslationService）
     *
     * @param int $id 商品 ID
     * @param array<string,mixed> $translations 翻译数据
     * @return array<string,array<string,mixed>>
     */
    public function saveProductTranslations(int $id, array $translations): array
    {
        $this->scopedProduct($id);
        Db::startTrans();
        try {
            (new TranslationService())->saveTranslations('product', $id, $translations);
            Db::commit();
        } catch (\Throwable $e) {
            Db::rollback();
            throw $e;
        }
        return $this->productTranslations($id);
    }

    /**
     * 发布商品某语种译文
     *
     * @param int $id 商品 ID
     * @param string $lang 语种
     * @return array<string,array<string,mixed>>
     */
    public function publishProductTranslation(int $id, string $lang): array
    {
        $this->scopedProduct($id);
        (new TranslationService())->publish('product', $id, $lang);
        return $this->productTranslations($id);
    }

    private function normalizeSpecs($raw): array
    {
        if (is_string($raw)) $raw = json_decode($raw, true) ?: [];
        if (!is_array($raw)) throw new BizException('规格格式无效');
        $specs = [];
        $names = [];
        foreach ($raw as $spec) {
            $name = trim((string) ($spec['name'] ?? ''));
            $values = array_values(array_unique(array_filter(array_map(static fn($v) => trim((string) $v), (array) ($spec['values'] ?? [])))));
            if ($name === '' || !$values || in_array($name, $names, true)) throw new BizException('规格名称和值不能为空且名称不能重复');
            $names[] = $name;
            $specs[] = ['name' => $name, 'values' => $values];
        }
        return $specs;
    }

    private function assertLocalMediaUrl(string $url, string $type = 'image'): void
    {
        $pattern = $type === 'video'
            ? '~^/uploads/products/videos/\d{6}/[a-f0-9]{32}\.(mp4|webm)$~'
            : '~^/uploads/products/images/\d{6}/[a-f0-9]{32}\.(jpg|jpeg|png|webp)$~';
        if (!preg_match($pattern, $url) || !is_file(public_path() . ltrim($url, '/'))) {
            throw new BizException('媒体地址无效，请重新上传');
        }
    }

    private function assertMerchantMediaUrl(string $url): void
    {
        if (!preg_match('~^/uploads/merchants/images/\d{6}/[a-f0-9]{32}\.(jpg|jpeg|png|webp)$~', $url)
            || !is_file(public_path() . ltrim($url, '/'))) {
            throw new BizException('商户 logo 地址无效，请重新上传');
        }
    }

    /**
     * 校验品牌 logo 地址（正则 + 文件存在双重校验）
     *
     * @param string $url logo 相对地址
     * @return void
     */
    private function assertBrandMediaUrl(string $url): void
    {
        if (!preg_match('~^/uploads/brands/images/\d{6}/[a-f0-9]{32}\.(jpg|jpeg|png|webp)$~', $url)
            || !is_file(public_path() . ltrim($url, '/'))) {
            throw new BizException('品牌 logo 地址无效，请重新上传');
        }
    }

    /**
     * 过滤富文本 HTML，仅保留白名单标签与安全的媒体地址
     *
     * @param string $html 原始 HTML
     * @param string $mediaNamespace 媒体命名空间，限定为 products / merchants / brands，非法值回退 products
     * @return string 过滤后的安全 HTML
     */
    public function sanitizeRichText(string $html, string $mediaNamespace = 'products'): string
    {
        $html = preg_replace('~<\s*(script|style|iframe|object|embed|form)\b[^>]*>.*?<\s*/\s*\1\s*>~is', '', $html) ?? '';
        $allowedTags = ['p', 'br', 'strong', 'b', 'em', 'i', 'u', 's', 'h1', 'h2', 'h3', 'h4', 'ul', 'ol', 'li', 'blockquote', 'a', 'img', 'div', 'span', 'hr'];
        // 命名空间白名单，避免拼出任意上传路径；非法命名空间回退 products（保持既有行为）
        $allowedNamespaces = ['products', 'merchants', 'brands'];
        $namespace = in_array($mediaNamespace, $allowedNamespaces, true) ? $mediaNamespace : 'products';
        $allowedSrc = sprintf(
            '~^/uploads/%s/images/\d{6}/[a-f0-9]{32}\.(?:jpg|jpeg|png|webp)$~i',
            $namespace
        );
        $html = preg_replace_callback('/<\/?([a-z][a-z0-9]*)\b([^>]*)>/i', static function (array $match) use ($allowedTags, $allowedSrc): string {
            $tag = strtolower($match[1]);
            if (!in_array($tag, $allowedTags, true)) return '';
            if ($match[0][1] === '/') return '</' . $tag . '>';
            $attrs = '';
            preg_match_all('/([a-z_:][a-z0-9_.:-]*)\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))/i', $match[2], $matches, PREG_SET_ORDER);
            foreach ($matches as $attr) {
                $name = strtolower($attr[1]);
                if (str_starts_with($name, 'on') || in_array($name, ['style', 'formaction', 'srcdoc'], true)) continue;
                if (!in_array($name, ['href', 'src', 'alt', 'title', 'width', 'height'], true)) continue;
                $value = html_entity_decode($attr[2] !== '' ? $attr[2] : ($attr[3] !== '' ? $attr[3] : $attr[4]), ENT_QUOTES | ENT_HTML5, 'UTF-8');
                if (in_array($name, ['href', 'src'], true)) {
                    $trimmed = preg_replace('/[\x00-\x20]+/', '', $value) ?? $value;
                    if (preg_match('/^(?:javascript|data|vbscript):/i', $trimmed)) continue;
                    if ($name === 'src' && !preg_match($allowedSrc, $value)) continue;
                     if ($name === 'href' && !preg_match('~^(?:https?://|/(?!/)|#)~i', $value)) continue;
                }
                $attrs .= ' ' . $name . '="' . htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '"';
            }
            return '<' . $tag . $attrs . '>';
        }, $html) ?? '';
        return $html;
    }

    private function specificationShapeChanged(Product $product, array $skus): bool
    {
        $oldKeys = [];
        foreach ($product->skus as $sku) {
            $values = (array) $sku->spec_values_json;
            ksort($values);
            $oldKeys[json_encode($values, JSON_UNESCAPED_UNICODE)] = true;
        }
        $newKeys = [];
        foreach ($skus as $sku) {
            $values = $sku['spec_values_json'];
            ksort($values);
            $newKeys[json_encode($values, JSON_UNESCAPED_UNICODE)] = true;
        }
        return array_diff_key($oldKeys, $newKeys) !== [] || array_diff_key($newKeys, $oldKeys) !== [];
    }

    private function normalizeSkus($raw, array $specs): array
    {
        if (is_string($raw)) $raw = json_decode($raw, true);
        if (!is_array($raw) || !$raw) throw new BizException('至少需要一条 SKU');
        $expected = [[]];
        foreach ($specs as $spec) {
            $next = [];
            foreach ($expected as $combination) foreach ($spec['values'] as $value) $next[] = $combination + [$spec['name'] => $value];
            $expected = $next;
        }
        if (!$specs) {
            $expected = [[]];
        }
        $rows = [];
        $combos = [];
        $codes = [];
        $expectedKeys = [];
        foreach ($expected as $combination) {
            ksort($combination);
            $expectedKeys[json_encode($combination, JSON_UNESCAPED_UNICODE)] = true;
        }
        foreach ($raw as $sku) {
            $values = (array) ($sku['spec_values_json'] ?? []);
            if (is_string($sku['spec_values_json'] ?? null)) $values = json_decode($sku['spec_values_json'], true) ?: [];
            if (count($values) !== count($specs)) throw new BizException('SKU 规格组合与规格定义不匹配');
            foreach ($specs as $spec) if (!in_array($values[$spec['name']] ?? null, $spec['values'], true)) throw new BizException('SKU 包含无效规格值');
            ksort($values);
            $key = json_encode($values, JSON_UNESCAPED_UNICODE);
            if (isset($combos[$key])) throw new BizException('SKU 规格组合重复');
            $combos[$key] = true;
            if (!isset($expectedKeys[$key])) throw new BizException('SKU 规格组合与规格定义不匹配');
            $priceRaw = $sku['price'] ?? null;
            $price = (float) $priceRaw;
            $stockRaw = $sku['stock'] ?? -1;
            if (!is_numeric($priceRaw) || $price < 0 || !is_numeric($stockRaw) || (int) $stockRaw < 0 || (string) (int) $stockRaw !== (string) $stockRaw) throw new BizException('SKU 价格和库存必须为非负数，库存必须为整数');
            $code = trim((string) ($sku['sku_code'] ?? ''));
            if ($code !== '' && isset($codes[$code])) throw new BizException('商品内 SKU 编码不能重复');
            if ($code !== '') $codes[$code] = true;
            $rows[] = ['spec_name' => implode(' / ', array_values($values)) ?: '默认规格', 'spec_values_json' => $values,
                'price' => number_format($price, 2, '.', ''), 'stock' => (int) $stockRaw, 'sku_code' => $code ?: null,
                'status' => isset($sku['status']) && (int) $sku['status'] === 0 ? 0 : 1];
        }
        if (count($rows) !== count($expected)) throw new BizException('SKU 组合未完整生成或存在重复');
        if (!array_filter($rows, static fn($row) => $row['status'] === 1)) throw new BizException('至少保留一条启用 SKU');
        return $rows;
    }

    public function deleteProduct(int $id): void
    {
        $product = $this->scopedProduct($id);
        $product->delete();
        RedisCache::forget('product:detail:public:' . (int) $id);
        RedisCache::forget('category:tree');
    }

    public function toggleProduct(int $id, int $status): void
    {
        if (!in_array($status, [0, 1, 2], true)) {
            throw new BizException('商品状态无效');
        }
        $product = $this->scopedProduct($id);
        $product->status = $status;
        $product->save();
        RedisCache::forget('product:detail:public:' . (int) $id);
        RedisCache::forget('category:tree');
    }

    public function saveCategory(array $data, ?int $id = null): Category
    {
        $this->assertSuper();
        $name = trim((string) ($data['name'] ?? ''));
        if ($name === '') {
            throw new BizException('分类名称不能为空');
        }
        $category = $id ? Category::find($id) : new Category();
        if (!$category) {
            throw new BizException('分类不存在');
        }
        $parentId = (int) ($data['parent_id'] ?? 0);
        if ($parentId && $parentId === $id) {
            throw new BizException('分类不能以自身为父级');
        }
        if ($parentId && !Category::find($parentId)) {
            throw new BizException('父分类不存在');
        }
        $category->parent_id = $parentId;
        $category->name = $name;
        $category->sort = (int) ($data['sort'] ?? 0);
        $category->save();
        RedisCache::forget('category:tree');
        return $category;
    }

    public function deleteCategory(int $id): void
    {
        $this->assertSuper();
        if (Product::where('category_id', $id)->find()) {
            throw new BizException('分类下仍有商品，不能删除');
        }
        if (Category::where('parent_id', $id)->find()) {
            throw new BizException('分类下仍有子分类，不能删除');
        }
        $category = Category::find($id);
        if (!$category) {
            throw new BizException('分类不存在');
        }
        $category->delete();
        RedisCache::forget('category:tree');
    }

    public function saveMerchant(array $data, ?int $id = null): Merchant
    {
        $name = trim((string) ($data['name'] ?? ''));
        if ($name === '') {
            throw new BizException('商户名称不能为空');
        }
        if (mb_strlen($name) > 128) {
            throw new BizException('商户名称不能超过 128 个字符');
        }
        $merchant = $id ? $this->scopedMerchant($id) : new Merchant();
        if (!$id && AppContext::getAdminRole() !== AdminRole::SUPER) {
            throw new BizException('仅平台管理员可创建商户');
        }
        $merchant->name = $name;
        if (!$id) {
            $merchant->status = (int) ($data['status'] ?? 1);
        } else {
            // Preserve the legacy edit contract: only overwrite fields that were submitted.
            foreach (['contact' => 64, 'phone' => 20, 'address' => 255] as $field => $maxLength) {
                if (!array_key_exists($field, $data)) {
                    continue;
                }
                $value = trim((string) $data[$field]);
                if (mb_strlen($value) > $maxLength) {
                    throw new BizException('商户资料字段超出长度限制');
                }
                $merchant->$field = $value !== '' ? $value : null;
            }
            if (array_key_exists('status', $data)) {
                $merchant->status = (int) $data['status'] ? 1 : 0;
            }
        }
        $merchant->save();
        $this->forgetMerchantProductCaches((int) $merchant->id);
        return $merchant;
    }

    public function merchantDetail(int $id): array
    {
        $merchant = $this->scopedMerchant($id);
        $fields = [
            'name', 'logo', 'short_intro', 'contact', 'phone', 'address',
            'service_phone', 'service_email', 'business_license_no', 'legal_person', 'uscc', 'website',
        ];
        $detail = ['id' => (int) $merchant->id];
        foreach ($fields as $field) {
            $detail[$field] = (string) ($merchant->getAttr($field) ?? '');
        }
        $detail['description'] = $this->sanitizeRichText((string) ($merchant->getAttr('description') ?? ''), 'merchants');
        $detail['status'] = (int) $merchant->status;
        return $detail;
    }

    public function saveMerchantDetail(array $data, int $id): Merchant
    {
        if ($id <= 0) {
            throw new BizException('商户参数错误');
        }
        $merchant = $this->scopedMerchant($id);

        $name = trim((string) ($data['name'] ?? ''));
        if ($name === '') {
            throw new BizException('商户名称不能为空');
        }
        if (mb_strlen($name) > 128) {
            throw new BizException('商户名称不能超过 128 个字符');
        }

        $limits = [
            'logo' => 255,
            'short_intro' => 200,
            'contact' => 64,
            'phone' => 20,
            'address' => 255,
            'service_phone' => 32,
            'service_email' => 128,
            'business_license_no' => 64,
            'legal_person' => 64,
            'uscc' => 18,
            'website' => 255,
        ];
        $values = [];
        foreach ($limits as $field => $maxLength) {
            $value = trim((string) ($data[$field] ?? ''));
            if (mb_strlen($value) > $maxLength) {
                throw new BizException('商户资料字段“' . $field . '”超出长度限制');
            }
            $values[$field] = $value !== '' ? $value : null;
        }

        if ($values['logo'] !== null) {
            $this->assertMerchantMediaUrl($values['logo']);
        }
        if ($values['service_email'] !== null && !filter_var($values['service_email'], FILTER_VALIDATE_EMAIL)) {
            throw new BizException('客服邮箱格式不正确');
        }
        if ($values['website'] !== null
            && (!filter_var($values['website'], FILTER_VALIDATE_URL) || !preg_match('~^https?://~i', $values['website']))) {
            throw new BizException('官网地址必须是有效的 http(s) 链接');
        }

        $merchant->name = $name;
        foreach ($values as $field => $value) {
            $merchant->$field = $value;
        }
        $description = trim($this->sanitizeRichText((string) ($data['description'] ?? ''), 'merchants'));
        $merchant->description = $description !== '' ? $description : null;
        $merchant->save();
        $this->forgetMerchantProductCaches((int) $merchant->id);
        return $merchant;
    }

    private function scopedMerchant(int $id): Merchant
    {
        $merchant = Merchant::find($id);
        if (!$merchant) {
            throw new BizException('商户不存在');
        }
        if (AppContext::getAdminRole() !== AdminRole::SUPER
            && (empty($this->merchantIds()) || !in_array((int) $merchant->id, $this->merchantIds(), true))) {
            throw new BizException('无权访问该商户');
        }
        return $merchant;
    }

    private function forgetMerchantProductCaches(int $merchantId): void
    {
        foreach (Product::where('merchant_id', $merchantId)->column('id') as $productId) {
            RedisCache::forget('product:detail:public:' . (int) $productId);
        }
    }

    public function toggleMerchant(int $id, int $status): void
    {
        $this->assertSuper();
        $merchant = Merchant::find($id);
        if (!$merchant) {
            throw new BizException('商户不存在');
        }
        $merchant->status = $status ? 1 : 0;
        $merchant->save();
    }

    public function deleteMerchant(int $id): void
    {
        $this->assertSuper();
        $merchant = Merchant::find($id);
        if (!$merchant) {
            throw new BizException('商户不存在');
        }
        if (Product::where('merchant_id', $id)->find()) {
            throw new BizException('商户下仍有商品，不能删除');
        }
        if (Order::where('merchant_id', $id)->find()) {
            throw new BizException('商户下仍有订单，不能删除');
        }
        if (Settlement::where('merchant_id', $id)->find()) {
            throw new BizException('商户下仍有结算记录，不能删除');
        }
        Db::table('admin_merchant')->where('merchant_id', $id)->delete();
        $merchant->delete();
    }

    /**
     * 读取品牌详情（读权限：同商户全部成员可见）
     *
     * @param int $id 品牌 ID
     * @return array 品牌详情数据
     */
    public function brandDetail(int $id): array
    {
        $brand = $this->scopedBrand($id, false);
        $fields = ['name', 'logo', 'slogan', 'short_intro', 'brand_color', 'country', 'website'];
        $detail = [
            'id'          => (int) $brand->id,
            'merchant_id' => (int) $brand->merchant_id,
            'creator_id'  => (int) ($brand->creator_id ?? 0),
        ];
        foreach ($fields as $field) {
            $detail[$field] = (string) ($brand->getAttr($field) ?? '');
        }
        $detail['description'] = $this->sanitizeRichText((string) ($brand->getAttr('description') ?? ''), 'brands');
        $detail['sort'] = (int) $brand->sort;
        $detail['status'] = (int) $brand->status;
        $detail['can_write'] = $this->canWriteBrand($brand);
        return $detail;
    }

    /**
     * 新增/更新品牌基础信息（列表弹窗：仅名称；超管创建需选择归属商户）
     *
     * @param array $data 提交数据（name，超管另需 merchant_id）
     * @param int|null $id 品牌 ID，null 表示新增
     * @return Brand
     */
    public function saveBrand(array $data, ?int $id = null): Brand
    {
        $name = trim((string) ($data['name'] ?? ''));
        if ($name === '') {
            throw new BizException('品牌名称不能为空');
        }
        if (mb_strlen($name) > 64) {
            throw new BizException('品牌名称不能超过 64 个字符');
        }

        if ($id === null) {
            // 新增：解析归属商户（超管必须显式选择；非超管限定本人所属商户），创建者记为当前账号
            $merchantId = $this->resolveBrandMerchantId((int) ($data['merchant_id'] ?? 0));
            if (Brand::where('merchant_id', $merchantId)->where('name', $name)->find()) {
                throw new BizException('该商户下已存在同名品牌');
            }
            $brand = new Brand();
            $brand->merchant_id = $merchantId;
            $brand->creator_id = AppContext::getAdminId();
            $brand->name = $name;
            $brand->status = 1;
            try {
                $brand->save();
            } catch (PDOException | \PDOException $e) {
                // 唯一索引兜底：并发下同名创建
                throw new BizException('该商户下已存在同名品牌');
            }
            return $brand;
        }

        // 更新：需写权限；merchant_id 与 creator_id 均不可变更（R6）
        $brand = $this->scopedBrand($id, true);
        if (Brand::where('merchant_id', (int) $brand->merchant_id)
            ->where('name', $name)
            ->where('id', '<>', $id)
            ->find()) {
            throw new BizException('该商户下已存在同名品牌');
        }
        $brand->name = $name;
        try {
            // 显式带主键条件：MerchantScope 会向查询注入 merchant_id 条件，
            // 若此处不带 where，底层 update() 会跳过主键合并，导致按商户批量更新
            $brand->save([], ['id' => (int) $brand->id]);
        } catch (PDOException | \PDOException $e) {
            throw new BizException('该商户下已存在同名品牌');
        }
        return $brand;
    }

    /**
     * 保存品牌详情资料（详情页：基础资料 / 品牌形象 / 品牌介绍）
     *
     * @param array $data 提交数据
     * @param int $id 品牌 ID
     * @return Brand
     */
    public function saveBrandDetail(array $data, int $id): Brand
    {
        if ($id <= 0) {
            throw new BizException('品牌参数错误');
        }
        $brand = $this->scopedBrand($id, true);

        $name = trim((string) ($data['name'] ?? ''));
        if ($name === '') {
            throw new BizException('品牌名称不能为空');
        }
        if (mb_strlen($name) > 64) {
            throw new BizException('品牌名称不能超过 64 个字符');
        }

        $limits = [
            'logo'        => 255,
            'slogan'      => 100,
            'short_intro' => 200,
            'brand_color' => 16,
            'country'     => 64,
            'website'     => 255,
        ];
        $values = [];
        foreach ($limits as $field => $maxLength) {
            $value = trim((string) ($data[$field] ?? ''));
            if (mb_strlen($value) > $maxLength) {
                throw new BizException('品牌资料字段“' . $field . '”超出长度限制');
            }
            $values[$field] = $value !== '' ? $value : null;
        }

        if ($values['logo'] !== null) {
            $this->assertBrandMediaUrl($values['logo']);
        }
        if ($values['brand_color'] !== null
            && !preg_match('~^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$~', $values['brand_color'])) {
            throw new BizException('品牌主色必须是 #RGB 或 #RRGGBB 格式');
        }
        if ($values['website'] !== null
            && (!filter_var($values['website'], FILTER_VALIDATE_URL) || !preg_match('~^https?://~i', $values['website']))) {
            throw new BizException('官网地址必须是有效的 http(s) 链接');
        }

        if (Brand::where('merchant_id', (int) $brand->merchant_id)
            ->where('name', $name)
            ->where('id', '<>', $id)
            ->find()) {
            throw new BizException('该商户下已存在同名品牌');
        }

        $brand->name = $name;
        foreach ($values as $field => $value) {
            $brand->$field = $value;
        }
        $description = trim($this->sanitizeRichText((string) ($data['description'] ?? ''), 'brands'));
        $brand->description = $description !== '' ? $description : null;
        $brand->sort = (int) ($data['sort'] ?? $brand->sort);
        try {
            // 显式带主键条件，规避 MerchantScope 注入条件后主键条件被跳过
            $brand->save([], ['id' => (int) $brand->id]);
        } catch (PDOException | \PDOException $e) {
            throw new BizException('该商户下已存在同名品牌');
        }
        return $brand;
    }

    /**
     * 启用/停用品牌
     *
     * @param int $id 品牌 ID
     * @param int $status 1 启用 / 0 停用
     * @return void
     */
    public function toggleBrand(int $id, int $status): void
    {
        $brand = $this->scopedBrand($id, true);
        $brand->status = $status ? 1 : 0;
        // 显式带主键条件，规避 MerchantScope 注入条件后主键条件被跳过
        $brand->save([], ['id' => (int) $brand->id]);
    }

    /**
     * 删除品牌（被商品引用时拒绝）
     *
     * @param int $id 品牌 ID
     * @return void
     */
    public function deleteBrand(int $id): void
    {
        $brand = $this->scopedBrand($id, true);
        if (Product::where('brand_id', $id)->find()) {
            throw new BizException('该品牌下仍有商品，不能删除');
        }
        // 经查询构造器按主键删除，避免模型实例 delete() 因 MerchantScope 丢失主键条件
        Brand::where('id', (int) $brand->id)->delete();
    }

    /**
     * 商品表单内快速添加品牌（仅名称；同商户同名自动复用）
     *
     * @param int $merchantId 目标商户 ID
     * @param string $name 品牌名称
     * @return array{id:int,name:string,merchant_id:int,created:bool}
     */
    public function quickAddBrand(int $merchantId, string $name): array
    {
        $name = trim($name);
        if ($name === '') {
            throw new BizException('品牌名称不能为空');
        }
        if (mb_strlen($name) > 64) {
            throw new BizException('品牌名称不能超过 64 个字符');
        }
        $merchantId = $this->resolveBrandMerchantId($merchantId);

        $existing = Brand::where('merchant_id', $merchantId)->where('name', $name)->find();
        if ($existing) {
            return $this->formatQuickBrand($existing, false);
        }

        $brand = new Brand();
        $brand->merchant_id = $merchantId;
        $brand->creator_id = AppContext::getAdminId();
        $brand->name = $name;
        $brand->status = 1;
        try {
            $brand->save();
        } catch (PDOException | \PDOException $e) {
            // 并发下可能撞唯一索引，回查一次并复用
            $existing = Brand::where('merchant_id', $merchantId)->where('name', $name)->find();
            if ($existing) {
                return $this->formatQuickBrand($existing, false);
            }
            throw new BizException('该商户下已存在同名品牌');
        }
        return $this->formatQuickBrand($brand, true);
    }

    /**
     * 品牌下拉选项（按商户过滤；非超管强制限定本人所属商户）
     *
     * @param int $merchantId 商户 ID
     * @return array 选项列表
     */
    public function brandOptions(int $merchantId): array
    {
        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            if ($merchantId <= 0 || !in_array($merchantId, $this->merchantIds(), true)) {
                throw new BizException('无权访问该商户的品牌');
            }
        } elseif ($merchantId <= 0) {
            throw new BizException('请选择商户');
        }

        $brands = Brand::where('merchant_id', $merchantId)->order('sort')->order('id')->select();
        $options = [];
        foreach ($brands as $brand) {
            $options[] = [
                'id'          => (int) $brand->id,
                'name'        => $brand->name,
                'merchant_id' => (int) $brand->merchant_id,
                'status'      => (int) $brand->status,
            ];
        }
        return $options;
    }

    /**
     * 判断当前登录账号是否可写该品牌
     *
     * 超管放行；商户管理员对其商户内品牌放行；创建者对自己创建的品牌放行；其余只读。
     *
     * @param Brand $brand 品牌模型
     * @return bool
     */
    public function canWriteBrand(Brand $brand): bool
    {
        $role = AppContext::getAdminRole();
        if ($role === AdminRole::SUPER) {
            return true;
        }
        $merchantIds = $this->merchantIds();
        if (empty($merchantIds) || !in_array((int) $brand->merchant_id, $merchantIds, true)) {
            return false;
        }
        if ($role === AdminRole::MERCHANT_ADMIN) {
            return true;
        }
        $adminId = (int) (AppContext::getAdminId() ?? 0);
        return $adminId > 0 && (int) ($brand->creator_id ?? 0) === $adminId;
    }

    /**
     * 解析品牌应归属的商户 ID
     *
     * 超管必须显式提交合法商户；非超管必须属于本人所属商户（未提交时默认第一个）。
     *
     * @param int $submittedId 提交的商户 ID
     * @return int 归属商户 ID
     */
    private function resolveBrandMerchantId(int $submittedId): int
    {
        if (AppContext::getAdminRole() === AdminRole::SUPER) {
            if ($submittedId <= 0 || !Merchant::find($submittedId)) {
                throw new BizException('请选择归属商户');
            }
            return $submittedId;
        }
        $merchantIds = $this->merchantIds();
        if (empty($merchantIds)) {
            throw new BizException('未绑定商户，无法创建品牌');
        }
        $merchantId = $submittedId > 0 ? $submittedId : (int) $merchantIds[0];
        if (!in_array($merchantId, $merchantIds, true)) {
            throw new BizException('无权创建该商户的品牌');
        }
        return $merchantId;
    }

    /**
     * 统一快速添加品牌的返回结构
     *
     * @param Brand $brand 品牌模型
     * @param bool $created 是否本次新建
     * @return array{id:int,name:string,merchant_id:int,created:bool}
     */
    private function formatQuickBrand(Brand $brand, bool $created): array
    {
        return [
            'id'          => (int) $brand->id,
            'name'        => $brand->name,
            'merchant_id' => (int) $brand->merchant_id,
            'created'     => $created,
        ];
    }

    /**
     * 读取品牌并按访问范围/写权限校验
     *
     * @param int $id 品牌 ID
     * @param bool $forWrite 为 true 时额外校验写权限
     * @return Brand
     */
    private function scopedBrand(int $id, bool $forWrite = false): Brand
    {
        $brand = Brand::find($id);
        if (!$brand) {
            throw new BizException('品牌不存在');
        }
        if (AppContext::getAdminRole() !== AdminRole::SUPER
            && (empty($this->merchantIds()) || !in_array((int) $brand->merchant_id, $this->merchantIds(), true))) {
            throw new BizException('品牌不存在');
        }
        if ($forWrite && !$this->canWriteBrand($brand)) {
            throw new BizException('无权修改该品牌');
        }
        return $brand;
    }

    public function shipOrder(string $orderNo, string $shippingNo = '', string $shippingCompany = '', string $deliveryMethod = 'express'): void
    {
        $order = Order::where('order_no', $orderNo)->find();
        if (!$order || (AppContext::getAdminRole() !== AdminRole::SUPER && (empty($this->merchantIds()) || !in_array((int) $order->merchant_id, $this->merchantIds(), true)))) {
            throw new BizException('订单不存在');
        }
        if ((int) $order->status !== OrderStatus::PENDING_SHIP) {
            throw new BizException('订单当前状态不可发货');
        }
        if ($deliveryMethod === 'express') {
            if (trim($shippingNo) === '' || trim($shippingCompany) === '') {
                throw new BizException('快递物流发货需填写快递公司和物流单号');
            }
            $order->shipping_no = trim($shippingNo);
            $order->shipping_company = trim($shippingCompany);
        } else {
            $order->shipping_no = null;
            $order->shipping_company = null;
        }
        $order->status = OrderStatus::SHIPPING;
        $order->delivery_method = $deliveryMethod;
        $order->ship_at = date('Y-m-d H:i:s');
        $order->save();
    }

    public function markDelivered(string $orderNo): void
    {
        $order = Order::where('order_no', $orderNo)->find();
        if (!$order || (AppContext::getAdminRole() !== AdminRole::SUPER && (empty($this->merchantIds()) || !in_array((int) $order->merchant_id, $this->merchantIds(), true)))) {
            throw new BizException('订单不存在');
        }
        if ((int) $order->status !== OrderStatus::SHIPPING) {
            throw new BizException('订单当前状态不可确认送达');
        }
        $order->status = OrderStatus::DELIVERED;
        $order->deliver_at = date('Y-m-d H:i:s');
        $order->save();
    }

    public function approveAftersale(int $id): void
    {
        $this->scopedAftersale($id);
        $service = new AftersaleService();
        $service->approve($id, (int) (AppContext::getUserId() ?: 0));
    }

    public function rejectAftersale(int $id, string $reason): void
    {
        $this->scopedAftersale($id);
        (new AftersaleService())->reject($id, (int) (AppContext::getUserId() ?: 0), $reason);
    }

    public function receiveAftersale(int $id): void
    {
        $aftersale = $this->scopedAftersale($id);
        (new AftersaleService())->confirmReturnReceived(
            $id,
            (int) $aftersale->merchant_id
        );
    }

    public function summary(): array
    {
        $query = Settlement::where('status', 0);
        $pending = (float) $query->sum('net_amount');
        $withdrawn = (float) Withdraw::where('status', 3)->sum('amount');
        $withdrawable = (float) Settlement::where('status', 1)->sum('net_amount') - (float) Withdraw::where('status', 'in', [0, 1, 3])->sum('amount');
        return ['withdrawable' => $withdrawable, 'pending' => $pending, 'total_withdrawn' => $withdrawn];
    }

    public function referralStats(): array
    {
        $merchantIds = $this->merchantIds();
        $scoped = AppContext::getAdminRole() !== AdminRole::SUPER && !empty($merchantIds);
        $query = ShareReferral::alias('r')
            ->join('product p', 'p.id = r.product_id')
            ->field('r.*');
        if ($scoped) {
            $query->whereIn('p.merchant_id', $merchantIds);
        }
        $referrals = $query->count();
        $ordersQuery = Db::name('order_attribution')->alias('a')
            ->join('order o', 'o.id=a.order_id')
            ->join('share_referral r', 'r.id=a.share_referral_id')
            ->join('product p', 'p.id=r.product_id');
        if ($scoped) {
            $ordersQuery->whereIn('p.merchant_id', $merchantIds);
        }
        $orders = (int) $ordersQuery->count();
        $amount = (float) $ordersQuery->sum('o.total_amount');
        return ['shares' => $referrals, 'visits' => $query->where('r.visitor_user_id', '>', 0)->count(), 'orders' => $orders, 'amount' => $amount];
    }

    public function saveStaff(array $data, ?int $id = null): Admin
    {
        $this->assertStaffManagementAccess();

        $currentRole = AppContext::getAdminRole();
        $isSuper = $currentRole === AdminRole::SUPER;
        $scopeMerchantIds = $isSuper ? [] : AppContext::getMerchantIds();

        $admin = $id ? Admin::find($id) : new Admin();
        if (!$admin) throw new BizException('人员不存在');

        if (!$isSuper && $id && $admin->role !== AdminRole::STAFF) {
            throw new BizException('只能编辑普通员工');
        }

        $username = trim((string) ($data['username'] ?? ''));
        if ($username === '') {
            if ($id) {
                $username = (string) $admin->username;
            } else {
                throw new BizException('用户名不能为空');
            }
        }

        $existing = Admin::where('username', $username)->find();
        if ($existing && (!$id || (int) $existing->id !== $id)) {
            throw new BizException('用户名已存在');
        }

        $targetRole = (string) ($data['role'] ?? '');
        if ($isSuper) {
            if (!in_array($targetRole, [AdminRole::MERCHANT_ADMIN, AdminRole::STAFF], true)) {
                throw new BizException('角色无效');
            }
        } else {
            if ($targetRole !== AdminRole::STAFF) {
                throw new BizException('商户管理员只能添加普通员工');
            }
        }

        $admin->username = $username;
        $admin->role = $targetRole;
        $admin->status = (int) ($data['status'] ?? 1);
        $admin->email = trim((string) ($data['email'] ?? '')) ?: null;

        if (!empty($data['password'])) {
            if (strlen($data['password']) < 8) throw new BizException('密码至少 8 位');
            $admin->password_hash = password_hash($data['password'], PASSWORD_DEFAULT);
        } elseif (!$admin->password_hash) {
            throw new BizException('新增人员必须设置密码');
        }

        $admin->save();

        $submittedIds = array_filter(array_map('intval', (array) ($data['merchant_ids'] ?? [])));

        if ($isSuper) {
            $admin->merchants()->sync($submittedIds);
        } else {
            $invalid = array_diff($submittedIds, $scopeMerchantIds);
            if ($invalid) throw new BizException('无权分配管理范围外的商户');

            if ($id) {
                $existingExternal = Db::table('admin_merchant')
                    ->where('admin_id', $id)
                    ->whereNotIn('merchant_id', $scopeMerchantIds)
                    ->column('merchant_id');
                $finalIds = array_unique(array_merge($submittedIds, array_map('intval', $existingExternal)));
            } else {
                $finalIds = $submittedIds;
            }
            $admin->merchants()->sync($finalIds);
        }

        return $admin->refresh();
    }

    public function toggleStaff(int $id, int $status): void
    {
        $this->assertStaffManagementAccess();
        $admin = Admin::find($id);
        if (!$admin) throw new BizException('人员不存在');

        $currentRole = AppContext::getAdminRole();
        if ($currentRole === AdminRole::SUPER) {
            if ($admin->role === AdminRole::SUPER) throw new BizException('不能停用超管');
        } else {
            if ($admin->role !== AdminRole::STAFF) throw new BizException('只能操作普通员工');
            $targetMerchantIds = array_map('intval', Db::table('admin_merchant')->where('admin_id', $id)->column('merchant_id'));
            if (!array_intersect($targetMerchantIds, AppContext::getMerchantIds())) {
                throw new BizException('该员工不在你的商户范围内');
            }
        }

        $admin->status = $status ? 1 : 0;
        $admin->save();
    }

    public function deleteStaff(int $id): void
    {
        $this->assertStaffManagementAccess();
        $admin = Admin::find($id);
        if (!$admin) throw new BizException('人员不存在');

        $currentRole = AppContext::getAdminRole();
        if ($currentRole === AdminRole::SUPER) {
            if ($admin->role === AdminRole::SUPER) throw new BizException('不能删除超管');
        } else {
            if ($admin->role !== AdminRole::STAFF) throw new BizException('只能删除普通员工');
            $targetMerchantIds = array_map('intval', Db::table('admin_merchant')->where('admin_id', $id)->column('merchant_id'));
            $external = array_diff($targetMerchantIds, AppContext::getMerchantIds());
            if ($external) throw new BizException('该员工还负责其他商户，无法删除');
        }

        $admin->merchants()->detach();
        $admin->delete();
    }
}
