<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\exception\BizException;
use app\common\model\Page;
use think\db\exception\PDOException;

/**
 * 站点单页（CMS）服务
 *
 * 平台级内容：后台超管用富文本维护隐私政策、退换货、关于我们等页面；
 * 也可以用内置模板（about/service/contact）展示商家 / 品牌信息。
 * 前台入口见 app/controller/Page.php，按 slug 优先查本表，未命中再回退内置页面。
 */
class PageService
{
    /** 内容类型：富文本内容 */
    public const TYPE_DATABASE = 'database';

    /** 内容类型：内置模板 */
    public const TYPE_TEMPLATE = 'template';

    /** 内置模板白名单：视图名 => 展示名 */
    private const TEMPLATES = [
        'about'   => '关于我们（主题模板）',
        'service' => '我们的服务（主题模板）',
        'contact' => '联系我们（主题模板）',
        'page'    => '通用图文页（主题模板）',
    ];

    /**
     * 保留路径：与前台系统路由冲突，禁止作为单页 slug
     */
    private const RESERVED_SLUGS = [
        'products', 'product', 'cart', 'checkout', 'login', 'account',
        'order-success', 'admin', 'api', 'index', 'home',
    ];

    /**
     * 内置模板下拉数据（后台表单用）
     *
     * @return array<int,array{value:string,label:string}>
     */
    public function templateOptions(): array
    {
        $options = [];
        foreach (self::TEMPLATES as $value => $label) {
            $options[] = ['value' => $value, 'label' => $label];
        }
        return $options;
    }

    /**
     * 读取单页详情
     *
     * @param int $id 单页 ID
     * @return array
     * @throws BizException 单页不存在时抛出
     */
    public function detail(int $id): array
    {
        $page = Page::find($id);
        if (!$page) {
            throw new BizException('单页不存在');
        }

        return [
            'id'              => (int) $page->id,
            'title'           => (string) $page->title,
            'slug'            => (string) $page->slug,
            'content_type'    => (string) $page->content_type,
            'template_file'   => (string) $page->template_file,
            'content'         => (string) $page->content,
            'seo_title'       => (string) $page->seo_title,
            'seo_keywords'    => (string) $page->seo_keywords,
            'seo_description' => (string) $page->seo_description,
            'status'          => (int) $page->status,
            'sort'            => (int) $page->sort,
        ];
    }

    /**
     * 新增 / 更新单页
     *
     * @param array    $data 表单数据
     * @param int|null $id   为 null 表示新增
     * @return int 单页 ID
     * @throws BizException 校验失败时抛出
     */
    public function saveItem(array $data, ?int $id = null): int
    {
        $title       = trim((string) ($data['title'] ?? ''));
        $slug        = strtolower(trim((string) ($data['slug'] ?? '')));
        $contentType = (string) ($data['content_type'] ?? self::TYPE_DATABASE);
        $template    = (string) ($data['template_file'] ?? '');

        if ($title === '') {
            throw new BizException('页面标题不能为空');
        }
        if ($slug === '') {
            throw new BizException('访问路径不能为空');
        }
        if (!preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $slug)) {
            throw new BizException('访问路径只能包含小写字母、数字与中划线');
        }
        if (in_array($slug, self::RESERVED_SLUGS, true)) {
            throw new BizException('访问路径「' . $slug . '」与系统页面冲突，请更换');
        }
        if (!in_array($contentType, [self::TYPE_DATABASE, self::TYPE_TEMPLATE], true)) {
            throw new BizException('内容类型不合法');
        }
        if ($contentType === self::TYPE_TEMPLATE && !isset(self::TEMPLATES[$template])) {
            throw new BizException('请选择页面模板');
        }

        $duplicated = Page::where('slug', $slug)->where('id', '<>', (int) $id)->find();
        if ($duplicated) {
            throw new BizException('访问路径「' . $slug . '」已被占用');
        }

        try {
            $page = $id ? Page::find($id) : new Page();
            if (!$page) {
                throw new BizException('单页不存在');
            }

            $page->title           = $title;
            $page->slug            = $slug;
            $page->content_type    = $contentType;
            $page->template_file   = $contentType === self::TYPE_TEMPLATE ? $template : '';
            $page->content         = (string) ($data['content'] ?? '');
            $page->seo_title       = trim((string) ($data['seo_title'] ?? ''));
            $page->seo_keywords    = trim((string) ($data['seo_keywords'] ?? ''));
            $page->seo_description = trim((string) ($data['seo_description'] ?? ''));
            $page->status          = (int) ($data['status'] ?? 0) === 1 ? 1 : 0;
            $page->sort            = (int) ($data['sort'] ?? 0);
            $page->save();

            return (int) $page->id;
        } catch (PDOException $e) {
            throw new BizException('保存失败：' . $e->getMessage());
        }
    }

    /**
     * 上线 / 下线单页
     *
     * @param int $id     单页 ID
     * @param int $status 1 上线 0 下线
     * @return void
     * @throws BizException 单页不存在时抛出
     */
    public function toggleItem(int $id, int $status): void
    {
        $page = Page::find($id);
        if (!$page) {
            throw new BizException('单页不存在');
        }
        $page->status = $status === 1 ? 1 : 0;
        $page->save();
    }

    /**
     * 删除单页
     *
     * @param int $id 单页 ID
     * @return void
     * @throws BizException 单页不存在时抛出
     */
    public function deleteItem(int $id): void
    {
        $page = Page::find($id);
        if (!$page) {
            throw new BizException('单页不存在');
        }
        $page->delete();
    }

    /**
     * 按 slug 查询已上线的单页（前台渲染用）
     *
     * @param string $slug URL 路径段
     * @return array|null 未找到返回 null
     */
    public function findBySlug(string $slug): ?array
    {
        $slug = strtolower(trim($slug));
        if ($slug === '') {
            return null;
        }

        $page = Page::where('slug', $slug)->where('status', 1)->find();
        if (!$page) {
            return null;
        }

        $data = [
            'id'              => (int) $page->id,
            'title'           => (string) $page->title,
            'slug'            => (string) $page->slug,
            'content_type'    => (string) $page->content_type,
            'template_file'   => (string) $page->template_file,
            'content'         => (string) $page->content,
            'seo_title'       => (string) $page->seo_title,
            'seo_keywords'    => (string) $page->seo_keywords,
            'seo_description' => (string) $page->seo_description,
        ];

        $translation = (new TranslationService())->page((int) $page->id);
        if ($translation) {
            $data = (new TranslationService())->mergeFields($data, $translation, [
                'title', 'content', 'seo_title', 'seo_keywords', 'seo_description',
            ]);
        }

        return $data;
    }
}
