<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\model\Currency;
use app\common\model\Language;
use app\common\model\Order;
use app\common\model\Product;
use app\common\support\AppContext;
use think\facade\Db;

/**
 * 站点版本（国内版 / 国际版）
 *
 * 两套独立部署共用同一套代码：
 *   国内版：中文基准 + CNY + 小程序 + 微信/支付宝
 *   国际版：英文基准 + USD + 独立站 + 多语言/多货币 + Stripe/PayPal
 *
 * 版本切换只改「基准语言/基准币种/功能开关」，不做价格换算和内容翻译。
 */
class EditionService
{
    public const INTERNATIONAL = 'international';
    public const DOMESTIC = 'domestic';

    /**
     * 当前版本概览
     *
     * @return array<string,mixed>
     */
    public function summary(): array
    {
        $edition = site_edition();
        $products = (int) Product::count();
        $orders = (int) Order::count();

        return [
            'edition'       => $edition,
            'edition_label' => $edition === self::DOMESTIC ? '国内版' : '国际版',
            'base_locale'   => base_locale(),
            'base_currency' => base_currency_code(),
            'products'      => $products,
            'orders'        => $orders,
            'can_switch'    => $orders === 0,
            'requires_confirm' => $products > 0,
            'channels'      => $edition === self::DOMESTIC ? ['wechat', 'alipay'] : ['stripe', 'paypal'],
        ];
    }

    /**
     * 切换版本
     *
     * @param string $edition international|domestic
     * @param bool $confirmed 有商品时必须显式确认
     * @param string $phrase 必须为 SWITCH
     * @return array<string,mixed>
     */
    public function switchEdition(string $edition, bool $confirmed, string $phrase): array
    {
        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            throw new BizException('仅平台超管可切换站点版本');
        }
        $edition = strtolower(trim($edition));
        if (!in_array($edition, [self::INTERNATIONAL, self::DOMESTIC], true)) {
            throw new BizException('站点版本无效');
        }
        if ($phrase !== 'SWITCH') {
            throw new BizException('请输入 SWITCH 确认切换');
        }
        if ($edition === site_edition()) {
            return $this->summary();
        }
        if ((int) Order::count() > 0) {
            throw new BizException('已有历史订单，版本切换需走迁移流程，不能直接切换');
        }
        if ((int) Product::count() > 0 && !$confirmed) {
            throw new BizException('已有商品，请先备份并确认价格/文案需要重新维护');
        }

        $baseLocale = $edition === self::DOMESTIC ? 'zh' : 'en';
        $baseCurrency = $edition === self::DOMESTIC ? 'CNY' : 'USD';
        $language = Language::where('code', $baseLocale)->find();
        $currency = Currency::where('code', $baseCurrency)->find();
        if (!$language || !$currency) {
            throw new BizException('基准语言或基准币种不存在，请先执行数据库迁移');
        }

        Db::startTrans();
        try {
            SettingService::set('site.edition', $edition);
            SettingService::set('i18n.enabled', $edition === self::DOMESTIC ? '0' : '1');
            SettingService::set('i18n.default_locale', $baseLocale);
            SettingService::set('currency.enabled', $edition === self::DOMESTIC ? '0' : '1');
            SettingService::set('currency.default_code', $baseCurrency);

            // 基准语言：同一时间只有一个 is_default
            foreach (Language::select() as $row) {
                $row->is_default = strtolower((string) $row->code) === $baseLocale ? 1 : 0;
                if (strtolower((string) $row->code) === $baseLocale) {
                    $row->status = 1;
                }
                $row->save();
            }

            // 基准币种：同一时间只有一个 is_base
            foreach (Currency::select() as $row) {
                $row->is_base = strtoupper((string) $row->code) === $baseCurrency ? 1 : 0;
                if (strtoupper((string) $row->code) === $baseCurrency) {
                    $row->status = 1;
                }
                $row->save();
            }

            Db::commit();
        } catch (\Throwable $e) {
            Db::rollback();
            throw $e;
        }

        (new LanguageService())->flush();
        (new CurrencyService())->flush();
        SettingService::flush();

        return $this->summary();
    }
}