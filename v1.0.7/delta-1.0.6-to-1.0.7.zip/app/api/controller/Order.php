<?php
declare(strict_types=1);

namespace app\api\controller;

use app\BaseController;
use app\common\enum\AftersaleStatus;
use app\common\enum\OrderStatus;
use app\common\exception\BizException;
use app\common\model\Order as OrderModel;
use app\common\model\User;
use app\common\model\UserAddress;
use app\common\service\OrderService;
use app\common\service\PaymentService;
use app\common\service\ShareService;
use app\common\support\AppContext;

class Order extends BaseController
{
    public function checkout()
    {
        try {
            $userId = (int)AppContext::getUserId();
            $items = $this->request->post('items', []);
            $addressId = (int)$this->request->post('address_id', 0);
            $remark = (string)$this->request->post('remark', '');

            if (!is_array($items) || empty($items)) {
                return $this->error(40001, '无结算商品');
            }

            if (!$addressId) {
                return $this->error(40001, '请选择收货地址');
            }
            $addr = UserAddress::where('id', $addressId)
                ->where('user_id', $userId)
                ->find();
            if (!$addr) {
                return $this->error(40004, '收货地址不存在');
            }
            $address = [
                'name'           => $addr->name,
                'phone'          => $addr->phone,
                'address_detail' => $addr->address_detail,
            ];

            $normalizedItems = [];
            foreach ($items as $item) {
                $normalizedItems[] = [
                    'sku_id'   => (int)($item['sku_id'] ?? 0),
                    'quantity' => (int)($item['quantity'] ?? 0),
                ];
            }

            $payChannel = strtolower(trim((string) $this->request->post('pay_channel', 'wechat')));
            // 优惠：已领取券优先（coupon_user_id），其次按优惠码（coupon_code）
            $couponCode = strtoupper(trim((string) $this->request->post('coupon_code', '')));
            $couponUserId = (int) $this->request->post('coupon_user_id', 0) ?: null;
            $pay = (new OrderService())->checkout($userId, $normalizedItems, $address, $remark, $payChannel, $couponCode, $couponUserId);

            $orders = (new OrderModel())->db(['merchant'])
                ->with(['merchant'])
                ->where('pay_id', $pay->id)
                ->select();

            $shareService = new ShareService();
            $orderService = new OrderService();
            $subOrders = [];
            foreach ($orders as $order) {
                $shareService->attributeOrder((int)$order->id, $userId);
                $subOrders[] = [
                    'id'           => $order->id,
                    'order_no'      => $order->order_no,
                    'merchant_name' => $order->merchant ? $order->merchant->name : '',
                    'total_amount'  => (string)$order->total_amount,
                    'discount_amount' => (string)$order->discount_amount,
                    'item_count'    => $order->item_count,
                    'display'       => $orderService->displaySummary($order),
                ];
            }

            return $this->success([
                'order_pay_id'    => $pay->id,
                'total_amount'    => (string)$pay->total_amount,
                'discount_amount' => (string)$pay->discount_amount,
                'sub_orders'      => $subOrders,
            ]);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    public function pay()
    {
        try {
            $userId = (int)AppContext::getUserId();
            $orderPayId = (int)$this->request->post('order_pay_id', 0);
            $channel = strtolower(trim((string) $this->request->post('channel', 'wechat')));
            if (!$orderPayId) {
                return $this->error(40001, '参数错误');
            }
            $context = ['user_id' => $userId];
            if ($channel === 'wechat') {
                $user = User::find($userId);
                if (!$user || !$user->openid) {
                    return $this->error(40001, '用户openid不存在');
                }
                $context['openid'] = (string) $user->openid;
            }
            $params = (new PaymentService())->createPayment($orderPayId, $channel, $context);
            return $this->success($params);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    public function list()
    {
        $userId = (int)AppContext::getUserId();
        $page = (int)$this->request->get('page', 1);
        $size = min(max((int)$this->request->get('size', 15), 1), 50);
        $status = (string)$this->request->get('status', 'all');

        $query = (new OrderModel())->db(['merchant'])->where('user_id', $userId);
        if ($status === 'unpaid') {
            $query->where('status', OrderStatus::PENDING_PAY);
        } elseif ($status === 'unshipped') {
            $query->where('status', OrderStatus::PENDING_SHIP);
        } elseif ($status === 'unreceived') {
            $query->whereIn('status', [OrderStatus::SHIPPING, OrderStatus::DELIVERED]);
        } elseif ($status === 'done') {
            $query->where('status', OrderStatus::COMPLETED);
        }

        $pager = $query->with(['items', 'merchant'])
            ->order('id', 'desc')
            ->paginate(['list_rows' => $size, 'page' => $page]);

        $list = [];
        $orderService = new OrderService();
        foreach ($pager->items() as $order) {
            $firstImage = '';
            $firstItem = $order->items->isEmpty() ? null : $order->items[0];
            if ($firstItem) {
                $snap = $firstItem->sku_snapshot_json;
                if (is_string($snap)) {
                    $snap = json_decode($snap, true) ?: [];
                }
                $firstImage = $snap['main_image'] ?? '';
            }
            $list[] = [
                'id'            => $order->id,
                'pay_id'        => (int)$order->pay_id,
                'order_no'      => $order->order_no,
                'merchant_name' => $order->merchant ? $order->merchant->name : '',
                'status'        => $order->status,
                'status_label'  => OrderStatus::label((int)$order->status),
                'total_amount'  => (string)$order->total_amount,
                'display'       => $orderService->displaySummary($order),
                'first_image'   => $firstImage,
                'created_at'    => $order->create_time ? (string)$order->create_time : '',
            ];
        }

        return $this->success([
            'list'    => $list,
            'total'   => $pager->total(),
            'page'    => $pager->currentPage(),
            'size'    => $pager->listRows(),
            'hasMore' => $pager->hasMore(),
        ]);
    }

    public function detail()
    {
        $userId = (int)AppContext::getUserId();
        $orderId = (int)$this->request->get('id', 0);
        if (!$orderId) {
            return $this->error(40001, '参数错误');
        }

        $order = (new OrderService())->getOrderDetail($orderId, $userId);
        if (!$order) {
            return $this->error(40004, '订单不存在');
        }

        $items = [];
        foreach ($order->items as $item) {
            $snap = $item->sku_snapshot_json;
            if (is_string($snap)) {
                $snap = json_decode($snap, true) ?: [];
            }
            $items[] = [
                'sku_id'        => $item->sku_id,
                'product_title' => $snap['title'] ?? '',
                'spec_name'     => $snap['spec_name'] ?? '',
                'unit_price'    => (string)$item->unit_price,
                'quantity'      => $item->quantity,
                'total_price'   => (string)$item->total_price,
                'main_image'    => $snap['main_image'] ?? '',
            ];
        }

        $addr = $order->address;
        $address = [
            'name'           => $addr ? $addr->name : '',
            'phone'          => $addr ? $addr->phone : '',
            'address_detail' => $addr ? $addr->address_detail : '',
        ];

        $orderService = new OrderService();
        $timeline = $orderService->buildTimeline($order);
        $display = $orderService->displaySummary($order);

        $aftersale = null;
        if ($order->aftersale) {
            $aftersale = [
                'id'           => $order->aftersale->id,
                'status'       => $order->aftersale->status,
                'status_label' => AftersaleStatus::label((int)$order->aftersale->status),
            ];
        }

        return $this->success([
            'id'           => $order->id,
            'pay_id'       => (int)$order->pay_id,
            'order_no'     => $order->order_no,
            'status'       => $order->status,
            'status_label' => OrderStatus::label((int)$order->status),
            'total_amount' => (string)$order->total_amount,
            'display'      => $display,
            'remark'       => (string)($order->remark ?? ''),
            'merchant'     => [
                'id'   => $order->merchant ? $order->merchant->id : 0,
                'name' => $order->merchant ? $order->merchant->name : '',
            ],
            'items'     => $items,
            'address'   => $address,
            'timeline'  => $timeline,
            'aftersale' => $aftersale,
        ]);
    }

    public function logistics()
    {
        $userId = (int)AppContext::getUserId();
        $orderId = (int)$this->request->get('id', 0);
        if (!$orderId) {
            return $this->error(40001, '参数错误');
        }

        $order = (new OrderService())->getOrderDetail($orderId, $userId);
        if (!$order) {
            return $this->error(40004, '订单不存在');
        }

        $timeline = (new OrderService())->buildTimeline($order);

        $deliveryMethod = (string)($order->delivery_method ?? '');
        $deliveryMethodLabel = match ($deliveryMethod) {
            'self'   => '商家自行配送',
            'express'=> '快递物流',
            default  => '',
        };

        return $this->success([
            'order_id'             => $order->id,
            'order_no'             => $order->order_no,
            'status'               => $order->status,
            'status_label'         => OrderStatus::label((int)$order->status),
            'shipping_no'          => (string)($order->shipping_no ?? ''),
            'shipping_company'     => (string)($order->shipping_company ?? ''),
            'delivery_method'      => $deliveryMethod,
            'delivery_method_label'=> $deliveryMethodLabel,
            'timeline'             => $timeline,
        ]);
    }

    public function confirm()
    {
        try {
            $userId = (int)AppContext::getUserId();
            $orderId = (int)$this->request->post('order_id', 0);
            if (!$orderId) {
                return $this->error(40001, '参数错误');
            }
            (new OrderService())->confirmReceipt($orderId, $userId);
            return $this->success();
        } catch (BizException $e) {
            return $this->error(40010, $e->getMessage());
        }
    }

    public function cancel()
    {
        try {
            $userId = (int)AppContext::getUserId();
            $orderPayId = (int)$this->request->post('order_pay_id', 0);
            if (!$orderPayId) {
                return $this->error(40001, '参数错误');
            }
            (new OrderService())->cancelUnpaid($orderPayId, $userId);
            return $this->success();
        } catch (BizException $e) {
            return $this->error(40010, $e->getMessage());
        }
    }
}
