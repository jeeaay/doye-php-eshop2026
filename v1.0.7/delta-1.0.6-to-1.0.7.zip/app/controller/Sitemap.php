<?php
declare(strict_types=1);

namespace app\controller;

use app\BaseController;
use app\common\model\Category;
use app\common\model\Page;
use app\common\model\Product;
use app\common\service\LanguageService;

/**
 * 分语种 sitemap
 *
 * GET /sitemap.xml（/ru/sitemap.xml 同样可用，前缀会被 LocalePrefix 剥离）
 * 每个 URL 同时输出所有语种的 hreflang 备选，方便搜索引擎发现翻译页。
 */
class Sitemap extends BaseController
{
    /**
     * @return \think\Response
     */
    public function index()
    {
        $domain = rtrim($this->request->domain(), '/');
        $default = (new LanguageService())->default();
        $defaultCode = strtolower((string) ($default['code'] ?? 'en'));
        $languages = (bool) site_config('i18n.enabled', false)
            ? (new LanguageService())->enabled()
            : [$default];

        $paths = [
            '/', '/products', '/about', '/service', '/contact',
            '/shipping', '/returns', '/terms', '/privacy', '/cookies',
        ];

        foreach (Product::where('status', 1)->whereNull('delete_time')->field('id,update_time')->order('id')->select() as $product) {
            $paths[] = '/products/' . (int) $product->id;
        }
        foreach (Category::order('sort')->order('id')->select() as $category) {
            $paths[] = '/products?category_id=' . (int) $category->id;
        }
        foreach (Page::where('status', 1)->order('sort')->select() as $page) {
            $slug = strtolower((string) $page->slug);
            if ($slug !== '' && !in_array($slug, ['products', 'cart', 'checkout', 'login', 'account'], true)) {
                $paths[] = '/' . $slug;
            }
        }

        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">' . "\n";

        foreach (array_values(array_unique($paths)) as $path) {
            $xml .= '  <url>' . "\n";
            $xml .= '    <loc>' . $this->esc($domain . localized_url($path, $defaultCode)) . '</loc>' . "\n";

            foreach ($languages as $language) {
                $code = strtolower((string) $language['code']);
                $xml .= '    <xhtml:link rel="alternate" hreflang="' . $this->esc($code) . '" href="'
                    . $this->esc($domain . localized_url($path, $code)) . '"/>' . "\n";
            }
            $xml .= '    <xhtml:link rel="alternate" hreflang="x-default" href="'
                . $this->esc($domain . localized_url($path, $defaultCode)) . '"/>' . "\n";
            $xml .= '  </url>' . "\n";
        }

        $xml .= '</urlset>';

        return response($xml, 200, ['Content-Type' => 'application/xml; charset=utf-8']);
    }

    /**
     * XML 转义
     */
    private function esc(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }
}