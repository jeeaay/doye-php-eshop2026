<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\exception\BizException;
use app\common\model\Currency as CurrencyModel;
use app\common\service\CurrencyService;

/**
 * 管理 API：展示币种与汇率
 */
class Currency extends ApiBaseController
{
    /**
     * GET /admin-api/v1/currencies
     *
     * @return \think\response\Json
     */
    public function index()
    {
        return $this->run(function () {
            $this->assertSuper();
            return (new CurrencyService())->all();
        });
    }

    /**
     * POST /admin-api/v1/currencies
     *
     * @return \think\response\Json
     */
    public function save()
    {
        return $this->run(function () {
            $this->assertSuper();
            return (new CurrencyService())->create($this->input());
        }, '币种已创建');
    }

    /**
     * PUT /admin-api/v1/currencies/:id
     *
     * @return \think\response\Json
     */
    public function update()
    {
        return $this->run(function () {
            $this->assertSuper();
            return (new CurrencyService())->save((int) $this->request->param('id', 0), $this->input());
        }, '币种已更新');
    }

    /**
     * DELETE /admin-api/v1/currencies/:id
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        return $this->run(function () {
            $this->assertSuper();
            (new CurrencyService())->delete((int) $this->request->param('id', 0));
            return null;
        }, '币种已删除');
    }

    /**
     * POST /admin-api/v1/currencies/:id/rate/refresh
     *
     * @return \think\response\Json
     */
    public function refresh()
    {
        return $this->run(function () {
            $this->assertSuper();
            $currency = CurrencyModel::find((int) $this->request->param('id', 0));
            if (!$currency) {
                throw new BizException('币种不存在');
            }
            return (new CurrencyService())->syncOne((string) $currency->code);
        }, '汇率已刷新');
    }

    /**
     * PUT /admin-api/v1/currencies/:id/rate/override
     *
     * @return \think\response\Json
     */
    public function override()
    {
        return $this->run(function () {
            $this->assertSuper();
            $raw = $this->input()['rate'] ?? null;
            if ($raw === '' || $raw === null) {
                throw new BizException('请填写人工汇率');
            }
            return (new CurrencyService())->setOverride((int) $this->request->param('id', 0), (float) $raw);
        }, '人工汇率已保存');
    }

    /**
     * DELETE /admin-api/v1/currencies/:id/rate/override
     *
     * @return \think\response\Json
     */
    public function clearOverride()
    {
        return $this->run(function () {
            $this->assertSuper();
            return (new CurrencyService())->setOverride((int) $this->request->param('id', 0), null);
        }, '已恢复自动汇率');
    }

    /**
     * GET /admin-api/v1/currency-rates
     *
     * @return \think\response\Json
     */
    public function rates()
    {
        return $this->run(function () {
            $this->assertSuper();
            $code = strtoupper(trim((string) $this->request->param('currency', '')));
            if ($code === '') {
                throw new BizException('currency 不能为空');
            }
            $limit = max(1, min(200, (int) $this->request->param('limit', 30)));
            return (new CurrencyService())->history($code, $limit);
        });
    }
}