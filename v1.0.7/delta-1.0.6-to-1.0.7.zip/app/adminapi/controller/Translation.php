<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\model\TranslationJob;
use app\common\service\TranslationJobService;

/**
 * 管理 API：AI 翻译任务
 */
class Translation extends ApiBaseController
{
    /**
     * GET /admin-api/v1/translation-jobs
     *
     * @return \think\response\Json
     */
    public function jobs()
    {
        return $this->run(function () {
            $this->assertSuper();
            [$page, $size] = $this->pageParams();

            $query = TranslationJob::order('id', 'desc');
            $status = trim((string) $this->request->param('status', ''));
            $entityType = trim((string) $this->request->param('entity_type', ''));
            $entityId = (int) $this->request->param('entity_id', 0);
            if ($status !== '') {
                $query->where('status', $status);
            }
            if ($entityType !== '') {
                $query->where('entity_type', $entityType);
            }
            if ($entityId > 0) {
                $query->where('entity_id', $entityId);
            }

            $pager = $query->paginate($size, false, ['page' => $page]);
            $service = new TranslationJobService();
            $list = [];
            foreach ($pager->items() as $job) {
                $list[] = $service->payload($job);
            }

            return $this->pagePayload($list, $pager, $page, $size);
        });
    }

    /**
     * POST /admin-api/v1/translation-jobs/:id/retry
     *
     * @return \think\response\Json
     */
    public function retry()
    {
        return $this->run(function () {
            $this->assertSuper();
            (new TranslationJobService())->retry((int) $this->request->param('id', 0));
            return null;
        }, '任务已重新入队');
    }

    /**
     * POST /admin-api/v1/translations/backfill
     *
     * @return \think\response\Json
     */
    public function backfill()
    {
        return $this->run(function () {
            $this->assertSuper();
            $input = $this->input();
            $type = (string) ($input['type'] ?? 'all');
            if (!in_array($type, ['product', 'category', 'brand', 'page', 'all'], true)) {
                throw new \app\common\exception\BizException('翻译类型无效');
            }
            $locales = $input['lang'] ?? $input['locales'] ?? [];
            if (is_string($locales)) {
                $locales = array_values(array_filter(array_map('trim', explode(',', $locales))));
            }
            $limit = max(1, min(1000, (int) ($input['limit'] ?? 100)));
            $force = !empty($input['force']);

            return (new TranslationJobService())->enqueueMissing($type, (array) $locales, $limit, $force);
        }, '已加入翻译队列');
    }
}