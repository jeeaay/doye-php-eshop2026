<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\model\Product as ProductModel;
use app\common\service\AdminCrudService;
use app\common\service\ApiMediaResolver;
use app\common\support\AppContext;

/**
 * 管理 API：商品
 */
class Product extends ApiBaseController
{
    /**
     * GET /admin-api/v1/products
     *
     * @return \think\response\Json
     */
    public function index()
    {
        return $this->run(function () {
            [$page, $size] = $this->pageParams();

            $query = ProductModel::with(['category', 'brand', 'skus']);
            $keyword = trim((string) $this->request->param('keyword', ''));
            $categoryId = (int) $this->request->param('category_id', 0);
            $status = $this->request->param('status', '');
            $merchantId = (int) $this->request->param('merchant_id', 0);

            if ($keyword !== '') {
                $query->whereLike('title', '%' . $keyword . '%');
            }
            if ($categoryId > 0) {
                $query->where('category_id', $categoryId);
            }
            if ($status !== '' && $status !== null) {
                $query->where('status', (int) $status);
            }
            if ($merchantId > 0 && AppContext::getAdminRole() === AdminRole::SUPER) {
                $query->where('merchant_id', $merchantId);
            }

            $pager = $query->order('id', 'desc')->paginate($size, false, [
                'page'  => $page,
                'query' => [
                    'keyword'     => $keyword,
                    'category_id' => $categoryId ?: null,
                    'status'      => $status,
                    'merchant_id' => $merchantId ?: null,
                ],
            ]);

            $list = [];
            foreach ($pager->items() as $product) {
                $stock = 0;
                $prices = [];
                foreach ($product->skus as $sku) {
                    $stock += (int) $sku->stock;
                    $prices[] = (float) $sku->price;
                }

                $list[] = [
                    'id'            => (int) $product->id,
                    'title'         => (string) $product->title,
                    'main_image'    => (string) $product->main_image,
                    'category_id'   => (int) $product->category_id,
                    'category_name' => $product->category?->name ?? '',
                    'brand_id'      => (int) $product->brand_id,
                    'brand_name'    => $product->brand?->name ?? '',
                    'merchant_id'   => (int) $product->merchant_id,
                    'price'         => $prices ? number_format(min($prices), 2, '.', '') : '0.00',
                    'stock'         => $stock,
                    'status'        => (int) $product->status,
                    'status_text'   => [0 => '草稿', 1 => '上架', 2 => '下架'][(int) $product->status] ?? '未知',
                    'create_time'   => $product->create_time ? (string) $product->create_time : '',
                ];
            }

            return $this->pagePayload($list, $pager, $page, $size);
        });
    }

    /**
     * GET /admin-api/v1/products/:id
     *
     * @return \think\response\Json
     */
    public function detail()
    {
        return $this->run(function () {
            return (new AdminCrudService())->productDetail((int) $this->request->param('id', 0));
        });
    }

    /**
     * POST /admin-api/v1/products
     *
     * @return \think\response\Json
     */
    public function save()
    {
        return $this->run(function () {
            $data = $this->resolveMedia($this->input());
            $product = (new AdminCrudService())->saveProduct($data);

            return ['id' => (int) $product->id];
        }, '商品已创建');
    }

    /**
     * PUT /admin-api/v1/products/:id
     *
     * @return \think\response\Json
     */
    public function update()
    {
        return $this->run(function () {
            $id = (int) $this->request->param('id', 0);
            $data = $this->resolveMedia($this->input());
            $product = (new AdminCrudService())->saveProduct($data, $id);

            return ['id' => (int) $product->id];
        }, '商品已更新');
    }

    /**
     * DELETE /admin-api/v1/products/:id
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        return $this->run(function () {
            (new AdminCrudService())->deleteProduct((int) $this->request->param('id', 0));
            return null;
        }, '商品已删除');
    }

    /**
     * POST /admin-api/v1/products/:id/status
     *
     * @return \think\response\Json
     */
    public function status()
    {
        return $this->run(function () {
            $input = $this->input();
            if (!isset($input['status']) || !in_array((int) $input['status'], [0, 1, 2], true)) {
                throw new BizException('商品状态无效');
            }
            (new AdminCrudService())->toggleProduct(
                (int) $this->request->param('id', 0),
                (int) $input['status']
            );
            return null;
        }, '商品状态已更新');
    }

    /**
     * GET /admin-api/v1/products/:id/translations
     *
     * @return \think\response\Json
     */
    public function translations()
    {
        return $this->run(function () {
            $detail = (new AdminCrudService())->productDetail((int) $this->request->param('id', 0));
            return $detail['translations'] ?? [];
        });
    }

    /**
     * PUT /admin-api/v1/products/:id/translations/:lang
     *
     * 请求体可直接是字段对象，也可以是 {"translations": {"ru": {...}}}。
     *
     * @return \think\response\Json
     */
    public function saveTranslation()
    {
        return $this->run(function () {
            $id = (int) $this->request->param('id', 0);
            $lang = strtolower(trim((string) $this->request->param('lang', '')));
            if ($lang === '') {
                throw new BizException('语种不能为空');
            }

            $data = $this->input();
            if (isset($data['translations']) && is_array($data['translations'])) {
                $data = $data['translations'][$lang] ?? $data['translations'];
            } elseif (isset($data[$lang]) && is_array($data[$lang])) {
                $data = $data[$lang];
            }
            if (!is_array($data)) {
                throw new BizException('翻译数据格式无效');
            }

            return (new AdminCrudService())->saveProductTranslations($id, [$lang => $data]);
        }, '翻译已保存');
    }

    /**
     * POST /admin-api/v1/products/:id/translations/:lang/publish
     *
     * @return \think\response\Json
     */
    public function publishTranslation()
    {
        return $this->run(function () {
            $lang = strtolower(trim((string) $this->request->param('lang', '')));
            if ($lang === '') {
                throw new BizException('语种不能为空');
            }
            return (new AdminCrudService())->publishProductTranslation(
                (int) $this->request->param('id', 0),
                $lang
            );
        }, '翻译已发布');
    }

    /**
     * POST /admin-api/v1/products/:id/translations/:lang/ai
     *
     * @return \think\response\Json
     */
    public function translateTranslation()
    {
        return $this->run(function () {
            $id = (int) $this->request->param('id', 0);
            $lang = strtolower(trim((string) $this->request->param('lang', '')));
            $force = (int) $this->request->param('force', 0) === 1;
            if ($lang === '') {
                throw new BizException('语种不能为空');
            }
            (new AdminCrudService())->productDetail($id); // 范围校验
            $jobIds = (new \app\common\service\TranslationJobService())->enqueue('product', $id, [$lang], $force, 10);
            return ['job_ids' => $jobIds, 'queued' => (bool) $jobIds];
        }, '已加入翻译队列');
    }

    /**
     * 把媒体字段统一转成本地 URL
     *
     * @param array $data 请求参数
     * @return array
     * @throws BizException
     */
    private function resolveMedia(array $data): array
    {
        $resolver = new ApiMediaResolver();

        if (array_key_exists('main_image', $data)) {
            $data['main_image'] = $resolver->resolve($data['main_image'], 'image');
        }

        if (array_key_exists('images_json', $data)) {
            $images = $data['images_json'];
            if (is_string($images)) {
                $images = json_decode($images, true);
            }
            if (!is_array($images)) {
                throw new BizException('展示图片数据无效');
            }
            if (count($images) > 10) {
                throw new BizException('展示图片最多 10 张');
            }
            $data['images_json'] = $resolver->resolve(array_values($images), 'image');
        }

        if (array_key_exists('video_url', $data)) {
            $data['video_url'] = $resolver->resolve($data['video_url'], 'video');
        }
        if (array_key_exists('video_cover', $data)) {
            $data['video_cover'] = $resolver->resolve($data['video_cover'], 'image');
        }

        return $data;
    }
}