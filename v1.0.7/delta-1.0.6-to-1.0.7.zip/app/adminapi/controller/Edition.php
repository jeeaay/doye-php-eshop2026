<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\service\EditionService;

/**
 * 管理 API：站点版本
 */
class Edition extends ApiBaseController
{
    /**
     * GET /admin-api/v1/edition
     *
     * @return \think\response\Json
     */
    public function show()
    {
        return $this->run(function () {
            $this->assertSuper();
            return (new EditionService())->summary();
        });
    }

    /**
     * PUT /admin-api/v1/edition
     *
     * @return \think\response\Json
     */
    public function update()
    {
        return $this->run(function () {
            $this->assertSuper();
            $data = $this->input();
            return (new EditionService())->switchEdition(
                (string) ($data['edition'] ?? ''),
                (bool) ($data['confirmed'] ?? false),
                (string) ($data['phrase'] ?? '')
            );
        }, '站点版本已切换');
    }
}