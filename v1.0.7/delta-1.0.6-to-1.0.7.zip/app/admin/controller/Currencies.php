<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\service\CurrencyService;
use app\common\support\AppContext;
use think\facade\View;

/**
 * 展示币种与汇率管理（平台超管）
 */
class Currencies extends AdminBaseController
{
    /**
     * 币种列表
     *
     * @return mixed
     */
    public function index()
    {
        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            return redirect('/admin/index')->with('error', '仅平台超管可管理货币');
        }
        $this->assignActiveMenu('currencies');
        $service = new CurrencyService();
        View::assign('currencies', $service->all());
        View::assign('recent_logs', $service->recentHistory(50));
        View::assign('is_domestic', is_domestic_edition());
        return View::fetch();
    }

    /**
     * 保存单个币种
     *
     * @return \think\response\Json
     */
    public function save()
    {
        try {
            $this->assertSuper();
            $data = $this->request->post();
            $id = (int) ($data['id'] ?? 0);
            return json(['code' => 0, 'message' => '币种已保存', 'data' => (new CurrencyService())->save($id, $data)]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 新增币种
     *
     * @return \think\response\Json
     */
    public function create()
    {
        try {
            $this->assertSuper();
            return json(['code' => 0, 'message' => '币种已创建', 'data' => (new CurrencyService())->create($this->request->post())]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 删除币种
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        try {
            $this->assertSuper();
            (new CurrencyService())->delete((int) $this->request->post('id', 0));
            return json(['code' => 0, 'message' => '币种已删除', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 同步汇率（全部或单个）
     *
     * @return \think\response\Json
     */
    public function refresh()
    {
        try {
            $this->assertSuper();
            $service = new CurrencyService();
            $code = strtoupper(trim((string) $this->request->post('code', '')));
            if ($code !== '') {
                $result = $service->syncOne($code);
                return json([
                    'code'    => 0,
                    'message' => $result['status'] === 'accepted' ? $code . ' 汇率已更新' : ($result['message'] ?: $code . ' 汇率未更新'),
                    'data'    => $result,
                ]);
            }
            $result = $service->syncAll();
            return json([
                'code'    => 0,
                'message' => sprintf('同步完成：更新 %d，拒绝 %d', $result['updated'], $result['rejected']),
                'data'    => $result,
            ]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        } catch (\Throwable $e) {
            return json(['code' => 1, 'message' => '汇率同步失败：' . $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 设置/清除人工汇率
     *
     * @return \think\response\Json
     */
    public function override()
    {
        try {
            $this->assertSuper();
            $id = (int) $this->request->post('id', 0);
            $raw = $this->request->post('rate', '');
            $rate = ($raw === '' || $raw === null) ? null : (float) $raw;
            return json([
                'code'    => 0,
                'message' => $rate === null ? '已恢复自动汇率' : '人工汇率已保存',
                'data'    => (new CurrencyService())->setOverride($id, $rate),
            ]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 汇率历史
     *
     * @return \think\response\Json
     */
    public function history()
    {
        try {
            $this->assertSuper();
            $code = strtoupper(trim((string) $this->request->get('code', '')));
            if ($code === '') {
                throw new BizException('币种不能为空');
            }
            return json(['code' => 0, 'message' => 'ok', 'data' => (new CurrencyService())->history($code, 50)]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * @throws BizException
     */
    private function assertSuper(): void
    {
        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            throw new BizException('仅平台超管可管理货币');
        }
    }
}