# 多语种与多货币 流程检查表

> 配套说明：[`docs/i18n-multicurrency.md`](./i18n-multicurrency.md)
> 用法：每个阶段完成后勾选，并在「验证结果」写实际结果/截图路径。
> 本文档面向开发、测试、运维、运营四个角色。

---

## A. 变更确认（开发负责人）

- [ ] 已确认本次范围：多语言 + 多货币展示 + AI 翻译 + 订单展示快照
- [ ] 已确认**不做本币收款**：订单/支付/退款/结算全部 USD
- [ ] 已确认语种清单与默认币种：
  - `en→USD`、`zh→CNY`、`ru→RUB`、`fr/de/it/es/pt→EUR`、`ar→AED`、`ja→JPY`
- [ ] 已确认语言 URL 形式：默认英文无前缀，其他语种 `/ru/...`
- [ ] 已确认汇率保护方式：**不做上下限钳制**，异常变动拒绝更新并告警
- [ ] 已确认 AI 结果默认自动发布
- [ ] 已确认 Stripe / PayPal 固定 USD，微信/支付宝保持 CNY（小程序侧）
- [ ] 变更文件清单已对照 `git status` / `git diff` 审核

**验证结果：**

---

## B. 环境与依赖（运维）

- [ ] PHP ≥ 8.0
- [ ] `curl` 扩展可用
- [ ] `openssl` 扩展可用
- [ ] 生产环境已配置 CA：
  - `php.ini` 的 `curl.cainfo` 或 `openssl.cafile`
  - 或环境变量 `CURL_CA_BUNDLE`
- [ ] 测试 `curl` HTTPS 不再报 `unable to get local issuer certificate`
- [ ] Redis 可连接
- [ ] MySQL 可连接，且支持 JSON 字段
- [ ] 计划任务可执行 PHP CLI
- [ ] 可常驻运行 `php think translate:work`
- [ ] 防火墙允许出站访问：
  - `open.er-api.com`
  - `cdn.jsdelivr.net`
  - AI 提供者的 `base_url`

**验证命令：**

```bash
php -m | findstr /i "curl openssl"
php -r "var_dump(ini_get('curl.cainfo'), ini_get('openssl.cafile'), getenv('CURL_CA_BUNDLE'));"
php think redis:test
php think migrate:status
```

**验证结果：**

---

## C. 数据库迁移（开发/运维）

- [ ] 已完成数据库备份
- [ ] `php think migrate:run` 成功执行 33–36
- [ ] `language` 表存在 10 条预置语种
- [ ] `currency` 表存在 10 条预置币种，USD 为 `is_base=1`
- [ ] 四张翻译表存在且唯一键为 `(实体id, lang_code)`
- [ ] `translation_job` 存在
- [ ] `order` 存在 `display_currency/display_rate/display_total_amount/display_rate_at`
- [ ] 迁移回滚在**测试库**演练通过（生产不轻易回滚）
- [ ] 迁移脚本可重复执行/幂等性符合预期

**验证 SQL：**

```sql
SELECT COUNT(*) FROM language;          -- 10
SELECT COUNT(*) FROM currency;          -- 10
SHOW COLUMNS FROM `order` LIKE 'display_%';
SHOW INDEX FROM product_translation;    -- uk_product_lang
```

**验证结果：**

---

## D. 配置检查（运维/运营）

后台「系统设置」：

- [ ] 多语言：`i18n.enabled` 已按计划开启（上线前保持关闭）
- [ ] AI：`translation.base_url` 已填写且可访问
- [ ] AI：`translation.api_key` 已保存（后台不回显，重新打开显示「已设置」）
- [ ] AI：`translation.model` 与实际模型一致
- [ ] AI：`translation.daily_budget` 已设置
- [ ] AI：`translation.price_per_1k` 与模型价格一致
- [ ] 多货币：`currency.provider` 已选择
- [ ] 多货币：`currency.sanity_percent` 已确认（默认 10）
- [ ] 多货币：`currency.alert_email` 已填写（可选）
- [ ] 邮件服务已启用（否则告警只写日志）
- [ ] 支付管理：Stripe / PayPal 已启用且密钥有效
- [ ] 支付管理：页面不再出现「币种」字段（已移除）
- [ ] 已确认 Stripe 账户结算币种（HKD）与换汇成本
- [ ] 已确认 PayPal 是否开启「接受未持有币种并自动转换」（本方案固定 USD，不依赖该开关）

**验证结果：**

---

## D2. 站点版本（超管）

- [ ] `/admin/edition` 可访问，当前版本显示正确
- [ ] 商品数 / 订单数显示正确
- [ ] 有订单时两个切换按钮均禁用
- [ ] 有商品时显示「不会自动换算/翻译」提示
- [ ] 未勾选备份 / 未输入 `SWITCH` 时确认按钮禁用
- [ ] 错误确认词被拒绝
- [ ] 国际版：`base_locale=en`、`base_currency=USD`、渠道 Stripe/PayPal
- [ ] 国内版：`base_locale=zh`、`base_currency=CNY`、渠道 微信/支付宝
- [ ] 国内版前台 `html lang="zh"`、价格 `¥`、`/ru/...` 404
- [ ] 国内版 sitemap 只有 `zh` + `x-default`
- [ ] 国内版语言/币种切换器隐藏
- [ ] 国际版恢复多语言、多货币、hreflang
- [ ] 切换后商品/订单数据未被自动修改
- [ ] `order.charge_currency` / `order_pay.charge_currency` 与版本一致
- [ ] 非超管访问 `/admin/edition` 被拒绝
- [ ] 切换操作进入 `admin_audit_log`

**验证结果：**

---

## E. 多语言功能（测试）

### E1. URL 与语言解析

- [ ] `/` 输出英文，`html lang="en"`
- [ ] `/ru/products` 200，`html lang="ru"`
- [ ] `/ar/products` 200，`html dir="rtl"`
- [ ] `/zh`、`/ja`、`/fr`、`/de`、`/it`、`/pt`、`/es` 均可访问
- [ ] `/xx/products` 404
- [ ] `/ru/admin/login` 404（不跨应用）
- [ ] 关闭 `i18n.enabled` 后 `/ru/...` 404，前台恢复单语

### E2. 自动识别

- [ ] 首次访问 `/`，`Accept-Language: ru` + 浏览器 UA → 302 `/ru/`
- [ ] 同请求 Googlebot UA → 200，不跳转
- [ ] 跳转后 Cookie `site_locale=ru`
- [ ] 已有 `site_locale=en` Cookie 时 `/` 不再跳转
- [ ] 根路径响应包含 `Vary: Accept-Language, Cookie`
- [ ] `/api/*` 不跳转

### E3. 翻译读取

- [ ] 商品列表标题/副标题随语种变化
- [ ] 商品详情标题/副标题/详情 HTML/规格随语种变化
- [ ] SKU 规格文案随语种变化
- [ ] 分类树名称随语种变化
- [ ] 品牌名称/标语随语种变化
- [ ] CMS 单页标题/正文/SEO 随语种变化
- [ ] 未翻译字段逐项回退英文，不出现整页空白
- [ ] 草稿状态译文不出现在前台

### E4. 静态文案

- [ ] 导航、页脚、Cookie 提示随语种变化
- [ ] 商品列表 FILTER BY / SORT BY 有对应文案（当前其他语种回退英文）
- [ ] 商品详情配送/评价说明有对应文案
- [ ] 首页 Hero 有对应文案
- [ ] 语言切换器选项使用 `native_name`
- [ ] 切换语言后保留当前路径与查询参数

**验证结果：**

---

## F. AI 翻译（测试/运营）

### F1. Provider

- [ ] 后台填写 AI 配置后保存成功
- [ ] 商品页点击「AI 翻译」→ 返回「已加入翻译队列」
- [ ] worker 未启动时，页面提示「翻译仍在队列中」
- [ ] worker 启动后任务完成，表单自动回填
- [ ] `detail_html` 返回后无 `<script>` 等危险标签
- [ ] 译文过长时按块切分，HTML 结构完整

### F2. 任务与重试

- [ ] `translation_job` 状态流转：pending → running → done
- [ ] 模拟接口失败：任务重试，3 次后 `dead`
- [ ] 后台/API 可重试 `dead` 任务
- [ ] 同一商品同一语种不会重复入队
- [ ] `source_hash` 未变化时不重复计费
- [ ] 日预算用完后 worker 暂停消费
- [ ] 成本、token 数写入任务记录

### F3. 发布与校对

- [ ] `auto_publish_ai=true` 时 AI 结果直接上前台
- [ ] `auto_publish_ai=false` 时只存草稿
- [ ] 人工修改后点击「发布」生效
- [ ] 人工译文不会被自动任务覆盖（除非 force）
- [ ] 「清空回退英文」后前台显示英文

### F4. 批量补全

- [ ] 商品列表「批量补全翻译」可入队
- [ ] `translate:backfill --type=product` 可入队
- [ ] `translate:backfill --type=category|brand|page` 可入队
- [ ] 批量任务不会重复入队已有 pending 任务

**验证命令：**

```bash
php think translate:backfill --type=product --lang=ru --limit=1 --force
php think translate:work --once
```

**验证结果：**

---

## G. 多货币展示（测试）

- [ ] `currency.enabled=false` 时前台仅 USD，币种切换器隐藏
- [ ] 开启后页脚出现币种切换器
- [ ] `USD 19.99` → EUR `€17.91`（按当前汇率）
- [ ] JPY 显示 0 位小数（如 `¥3,156`）
- [ ] CNY/GBP/AED 符号与小数位正确
- [ ] 人工汇率覆盖优先生效
- [ ] 清除人工汇率后恢复自动值
- [ ] 切换币种保留路径与查询参数
- [ ] 刷新页面后币种 Cookie 生效
- [ ] 语言切换后默认币种跟随语种（未手动选过币种时）

### G1. 汇率同步

- [ ] `php think currency:sync --dry-run` 输出主源与更新/拒绝数量
- [ ] `php think currency:sync` 写库成功
- [ ] `currency_rate_log` 有 `accepted` 记录
- [ ] 构造单日 +30% 变动：记录 `rejected`，汇率保持旧值
- [ ] 无效值/空值：记录 `rejected`
- [ ] 告警邮件发送成功（或日志有 warning）
- [ ] 同一天重复同步只保留一条同来源记录
- [ ] `currency:selftest` 全部 PASS

**验证命令：**

```bash
php think currency:sync --dry-run
php think currency:sync
php think currency:selftest
```

**验证结果：**

---

## H. 订单与支付（测试/财务）

- [ ] 下单后 `order.display_currency` 与页面展示币种一致
- [ ] `order.charge_currency` 与站点版本一致（国际版 USD / 国内版 CNY）
- [ ] `order_pay.charge_currency` 与站点版本一致
- [ ] `order.display_rate` 与当时汇率/覆盖值一致
- [ ] `order.display_total_amount` = 订单 USD 总额 × 汇率，按币种取整
- [ ] `order.total_amount` 仍为 USD
- [ ] Stripe Checkout 金额与币种为 USD
- [ ] PayPal 订单金额与币种为 USD
- [ ] Stripe webhook 回调金额校验通过
- [ ] PayPal webhook 回调金额校验通过
- [ ] 支付成功后订单状态正常
- [ ] 退款金额按 USD 原金额
- [ ] 结算金额按 USD
- [ ] 后台订单详情显示「USD + ≈ 本币」
- [ ] 账户中心订单列表/详情显示「USD + ≈ 本币」
- [ ] 结算页显示「实际以 USD 结算」提示
- [ ] 商品详情显示「Charged in USD」
- [ ] 历史订单（display 为空）只显示 USD，不报错
- [ ] 展示币种被删除后，历史订单仍能显示参考价（回退代码+金额）

**验证结果：**

---

## I. SEO 与 RTL（测试/运营）

- [ ] 每个页面有 `rel="canonical"` 绝对地址
- [ ] `/ru/products` canonical 指向 `/ru/products`
- [ ] 每种启用语种输出 `hreflang`
- [ ] 输出 `x-default`
- [ ] 关闭 i18n 后只输出 `x-default`
- [ ] `/sitemap.xml` 返回 200，`Content-Type: application/xml`
- [ ] sitemap 包含商品/分类/单页/政策页
- [ ] sitemap 每个 URL 带 `xhtml:link` 备选
- [ ] `/ru/sitemap.xml` 可访问
- [ ] 阿语页面 `dir="rtl"`，导航/页脚/卡片文字右对齐
- [ ] 阿语商品价格保持 LTR
- [ ] 语言切换器 href 正确
- [ ] 币种切换器 href 保留查询参数

**验证结果：**

---

## J. 权限与安全（测试/安全）

- [ ] 超管可访问多语言/货币/AI 相关功能
- [ ] 商户管理员只能操作自己商户商品的翻译
- [ ] 商户管理员访问他人商品翻译 → 返回「商品不存在」
- [ ] staff 无法访问货币管理
- [ ] 货币/币种/翻译写操作进入 `admin_audit_log`
- [ ] AI 返回 HTML 经过白名单过滤
- [ ] AI Key 后台不回显
- [ ] 日志中不出现 AI Key / SMTP 密码
- [ ] 语言前缀无法穿越到 admin/api 应用
- [ ] 汇率/翻译接口有限流
- [ ] 后台页面直接访问越权 URL 被拦截

**验证结果：**

---

## K. 性能与缓存（测试/运维）

- [ ] 商品列表 100 条时无 N+1（翻译随 `with` 预加载）
- [ ] 商品详情缓存键按语种隔离
- [ ] 保存商品/翻译后详情缓存失效
- [ ] 币种保存/汇率同步后 `site:currencies` 缓存失效
- [ ] 语种保存后 `site:languages` 缓存失效
- [ ] sitemap 在 1000 商品量级下响应时间可接受
- [ ] AI worker 与 Web 请求互不阻塞

**验证结果：**

---

## L. 回滚演练（运维）

- [ ] 关闭 `i18n.enabled` 后前台恢复单语
- [ ] 关闭 `currency.enabled` 后前台恢复 USD
- [ ] 停止 worker 后页面不报错
- [ ] 停止 `currency:sync` 后前台继续用旧汇率
- [ ] 代码回滚后后台页面可访问
- [ ] 数据库回滚在测试库演练通过
- [ ] 已确认回滚会丢失翻译/币种/任务数据，且有备份

**验证结果：**

---

## M. 上线后观察（运维/运营，T+1 / T+7）

- [ ] `translate:work` 常驻进程存活
- [ ] `translation_job` 无长期 `running` 僵尸任务
- [ ] `dead` 任务数量与原因已复盘
- [ ] 当日 AI 成本未超预算
- [ ] `currency_rate_log` 每日有 `accepted`
- [ ] 无连续 `rejected`
- [ ] 汇率告警邮件可收到
- [ ] 404/500 日志无新增异常
- [ ] 订单支付成功率无明显下降
- [ ] 客诉中无「显示币种与扣款不一致」集中反馈

**验证结果：**

---

## N. 签字

| 角色 | 姓名 | 日期 | 结论 |
|---|---|---|---|
| 开发 | | | |
| 测试 | | | |
| 运维 | | | |
| 运营 | | | |
| 负责人 | | | |

---

## 附：上线前必跑命令

```bash
php think migrate:run
php think currency:selftest
php think currency:sync --dry-run
php think currency:sync
php think translate:backfill --type=product --limit=1 --force
php think translate:work --once
php think scope:write-check
```

PHP 语法检查（按改动文件）：

```bash
php -l app/common/service/OrderService.php
php -l app/common/service/CurrencyService.php
php -l app/common/service/TranslationJobService.php
php -l app/common/service/TranslationService.php
php -l app/admin/controller/Currencies.php
php -l app/adminapi/controller/Currency.php
php -l app/adminapi/controller/Translation.php
php -l app/controller/Sitemap.php
```