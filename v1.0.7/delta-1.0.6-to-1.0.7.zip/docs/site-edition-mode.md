# 站点版本（国内版 / 国际版）

> 结论：**两套独立部署，共用同一套代码**。
> 后台通过「站点版本」选择运行形态；在线实例之间互不干扰。
> 配套说明：[`docs/i18n-multicurrency.md`](./i18n-multicurrency.md)

## 1. 两种版本

| 维度 | 国内版 | 国际版 |
|---|---|---|
| 主要入口 | 微信小程序 | 独立站 |
| 结算币种 | **CNY** | **USD** |
| 基准语言 | **简体中文** | **英语** |
| 展示币种 | 仅 CNY | USD + 多币种参考价 |
| 其他语言 | 不做 | 多语言翻译 |
| 支付渠道 | 微信支付、支付宝 | Stripe、PayPal |
| 汇率同步 | 关闭 | 每日同步 |
| 多语言/多货币菜单 | 隐藏/不生效 | 开启 |
| 订单金额 | CNY | USD |

> 版本决定「基准语言 + 基准币种」。主表内容与 SKU 价格按当前版本的基准解释，
> **切换版本不会自动换算价格，也不会自动翻译内容**。

---

## 2. 配置与数据语义

### 2.1 设置项

| 键 | 值 | 说明 |
|---|---|---|
| `site.edition` | `domestic` / `international` | 当前版本，默认 `international` |

派生值（不单独存储，避免不一致）：

| 函数 | 国内版 | 国际版 |
|---|---|---|
| `base_locale()` | `zh` | `en` |
| `base_currency_code()` | `CNY` | `USD` |
| `site_edition()` | `domestic` | `international` |

### 2.2 数据语义

- 国内版部署：
  - 主表（商品/分类/品牌/单页）直接存中文
  - `product_sku.price` 为 CNY
  - 订单 `charge_currency=CNY`
- 国际版部署：
  - 主表存英文
  - `product_sku.price` 为 USD
  - 订单 `charge_currency=USD`
- 两套部署各自一个数据库，不共享商品/订单/支付数据。
- 不做「同一套数据库双价格/双语言」；如未来需要，另行设计。

---

## 3. 后台交互

### 3.1 入口

- 路径：`/admin/edition`
- 菜单：系统与安全 → **站点版本**（仅平台超管）
- 顶部显示：`当前版本：国内版 / 国际版`

### 3.2 页面

- 两张版本卡片：国内版、国际版
- 卡片展示：币种、语言、入口、支付渠道、功能开关
- 当前版本高亮
- 显示商品数 / 订单数
- 有订单时按钮禁用，并提示「需走迁移流程」
- 有商品时显示风险提示：不会自动换算/翻译

### 3.3 切换确认

点击「切换到此版本」后弹出：

- 影响对照表（基准币种、基准语言、价格解释、多语言、支付渠道、汇率同步、小程序）
- 必须勾选「我已备份数据库，并确认商品价格与文案需要重新维护」
- 必须输入 `SWITCH`
- 两项满足后「确认切换」才可点击

### 3.4 守卫

| 条件 | 行为 |
|---|---|
| 非超管 | 拒绝 |
| 订单数 > 0 | **禁止切换** |
| 商品数 > 0 | 需勾选备份确认 + 输入 SWITCH |
| 商品和订单都为空 | 允许直接切换 |
| 切换成功 | 清语言/币种/设置缓存 |

### 3.5 切换后

- `site.edition`
- `i18n.enabled`：国内版 0，国际版 1
- `i18n.default_locale`：zh / en
- `currency.enabled`：国内版 0，国际版 1
- `currency.default_code`：CNY / USD
- `language.is_default`：仅基准语言为 1
- `currency.is_base`：仅基准币种为 1
- 不修改商品、订单、翻译、支付配置

---

## 4. 功能门禁

| 功能 | 国内版 | 国际版 |
|---|---|---|
| 前台语言 | 强制 zh | 按配置多语言 |
| URL 前缀 | 不识别 `/ru/...` | 支持 |
| 语言切换器 | 隐藏 | 显示 |
| 币种 | 强制 CNY | 多币种展示 |
| 币种切换器 | 隐藏 | 显示 |
| 汇率同步 | 关闭 | 开启 |
| 多语言/多货币菜单 | 不生效 | 正常 |
| 支付渠道 | 微信/支付宝 | Stripe/PayPal |
| 商品翻译标签页 | 无（单语） | 有 |
| 商品价格标签 | `价格（CNY）` | `价格（USD）` |
| 订单展示 | CNY 实付 | USD 实付 + 本币参考价 |
| 结算提示 | 「实际将以 CNY 结算」 | 「实际将以 USD 结算」 |
| 小程序 API | 中文 + CNY | 不使用 |

支付渠道按版本**过滤展示**，不修改 `payment_channel.enabled`，切回时无需重配。

---

## 5. 订单与支付

新增字段（迁移 `000037_add_order_charge_currency.php`）：

| 表 | 字段 | 说明 |
|---|---|---|
| `order` | `charge_currency` | USD / CNY |
| `order_pay` | `charge_currency` | USD / CNY |

- 订单金额始终以 `charge_currency` 计价。
- `display_*` 仍是展示参考价；国际版用于本币参考，国内版与实付一致。
- 支付回调金额校验使用 `order_pay.charge_currency`。
- 支付渠道限制：
  - 国内版：微信支付、支付宝（CNY）
  - 国际版：Stripe、PayPal（USD）
- 小程序 `createPayment` 在国内版只允许微信/支付宝；国际版只允许 Stripe/PayPal。

---

## 6. 实现落点

### 6.1 新增

```
app/common/service/EditionService.php
app/admin/controller/Edition.php
app/admin/view/edition/index.html
app/adminapi/controller/Edition.php
database/migrations/000037_add_order_charge_currency.php
```

### 6.2 修改

- `app/common.php`：`site_edition()` / `is_domestic_edition()` / `base_locale()` / `base_currency_code()`
- `LanguageService` / `CurrencyService`：按版本过滤
- `TranslationService` / `TranslationJobService`：源语言改为 `base_locale()`
- `OrderService`：写入 `charge_currency`；`displaySummary` 支持 CNY/USD
- `PaymentService` / `PaymentGatewayFactory`：按版本限制渠道与币种
- `SiteBase` / `base.html` / `checkout.html` / `product.html`：基准币种动态显示
- `admin/controller/Orders.php`：后台订单金额按基准币种显示
- `config/site.php`：`site.edition` 默认值
- `config/admin_menu.php`：站点版本菜单
- `SettingService::set()`：供版本切换写入设置

### 6.3 管理 API

| 方法 | 路径 |
|---|---|
| GET | `/admin-api/v1/edition` |
| PUT | `/admin-api/v1/edition` |

`PUT` body：

```json
{
  "edition": "domestic",
  "confirmed": true,
  "phrase": "SWITCH"
}
```

---

## 7. 新部署步骤

### 国内版

1. 部署代码 + 空数据库
2. `php think migrate:run`
3. 后台 `/admin/edition` 切到「国内版」
4. 后台录入中文商品、CNY 价格
5. 支付管理启用微信/支付宝并填写配置
6. 配置小程序 AppID / 微信登录
7. 关闭 `translate:work`、`currency:sync`（国内版不需要）

### 国际版

1. 部署代码 + 空数据库
2. `php think migrate:run`
3. 后台 `/admin/edition` 保持「国际版」
4. 录入英文商品、USD 价格
5. 支付管理启用 Stripe/PayPal
6. 配置 AI 翻译与汇率同步
7. 启动 `translate:work`、配置 `currency:sync` 定时任务

---

## 8. 验证记录

已实际验证：

- 国际版 → 国内版切换：`base_locale=zh`、`base_currency=CNY`、可用语言 1 个、可用币种 1 个
- 国内版 → 国际版切换：恢复 `en` / `USD`
- 错误确认词：拒绝
- 有订单时切换：拒绝（提示走迁移流程）
- 国内版前台：
  - `html lang="zh"`
  - 商品价格 `¥19.99`，不做换算
  - `/ru/products` 404
  - sitemap 仅 `zh` + `x-default`
  - 结算提示「实际将以 CNY 结算」
- 国际版前台：`/ru/products/1`、hreflang、canonical、多币种参考价正常
- 版本切换页面：`/admin/edition` 200，菜单高亮正常
- 订单展示：`$21.99`（USD 国际版）；临时 RUB 订单 `$21.99 + ₽1,772.80`
- 下单快照：`$19.99` → `display_total_amount=1611.56 RUB`

---

## 9. 限制

- 不支持「同一套数据库随时切换」的双价格/双语言模式
- 切换版本不迁移商品/订单数据
- 国内版仍复用同一套商品表结构；需要中文内容与 CNY 价格
- 小程序端如与国际站同时运行，应使用两套独立部署
- 国内版货币页只展示 CNY；汇率同步/新增币种按钮隐藏
- 国内版 AI 翻译目标语种为空，不会产生翻译任务

---

## 10. 后续可选项

- 版本初始化向导（选版本 → 建基准语言/币种 → 引导录商品）
- 双价格字段（同库双版本）
- 商品/内容跨部署导入导出
- 版本切换自动检查清单与回滚