<?php
use think\migration\Migrator;

/**
 * 订单/支付单增加结算币种快照
 *
 * 国际版为 USD，国内版为 CNY。订单金额始终以 charge_currency 计价；
 * display_* 仍然只是展示参考价。
 */
class AddOrderChargeCurrency extends Migrator
{
    /**
     * @return void
     */
    public function change()
    {
        $this->table('order')
            ->addColumn('charge_currency', 'string', [
                'limit'   => 3,
                'default' => 'USD',
                'comment' => '订单金额所属币种：USD / CNY',
            ])
            ->update();

        $this->table('order_pay')
            ->addColumn('charge_currency', 'string', [
                'limit'   => 3,
                'default' => 'USD',
                'comment' => '支付单金额所属币种：USD / CNY',
            ])
            ->update();
    }
}