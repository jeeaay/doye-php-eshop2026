<?php
use think\migration\Migrator;

/**
 * 多语种基础表：language + 四张翻译副表
 *
 * 设计要点：
 * - 主表（product / category / brand / page）继续保存英文，是唯一事实来源。
 * - 其他语种写入 <entity>_translation，按 (实体 id, lang_code) 唯一。
 * - 翻译表不建 merchant_id：读写必须先经父实体做商户范围校验（见设计文档 §4.4）。
 * - 《迁移执行后初始化 10 个预置语种；default_currency 用于「跟随语言自动选展示币种」。
 */
class CreateLanguageTranslation extends Migrator
{
    /**
     * 执行迁移
     *
     * @return void
     */
    public function change()
    {
        $language = $this->table('language', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '语种注册表',
        ]);

        $language->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('code', 'string', ['limit' => 12, 'null' => false, 'comment' => '短码：en / zh / ru ...'])
            ->addColumn('name', 'string', ['limit' => 64, 'null' => false, 'comment' => '后台显示名'])
            ->addColumn('native_name', 'string', ['limit' => 64, 'null' => false, 'comment' => '原生名'])
            ->addColumn('direction', 'string', ['limit' => 3, 'default' => 'ltr', 'comment' => 'ltr / rtl'])
            ->addColumn('default_currency', 'string', ['limit' => 3, 'null' => true, 'comment' => '该语种默认展示币种'])
            ->addColumn('status', 'tinyinteger', ['default' => 1, 'comment' => '1 启用 0 停用'])
            ->addColumn('is_default', 'tinyinteger', ['default' => 0, 'comment' => '仅 en 为 1'])
            ->addColumn('sort', 'integer', ['default' => 0])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addIndex(['code'], ['unique' => true])
            ->addIndex(['status', 'sort'])
            ->create();

        $this->createTranslationTable('product_translation', 'product_id', [
            'title'           => ['type' => 'string', 'limit' => 255],
            'subtitle'        => ['type' => 'string', 'limit' => 255],
            'detail_html'     => ['type' => 'text', 'limit' => \Phinx\Db\Adapter\MysqlAdapter::TEXT_LONG],
            'specs_json'      => ['type' => 'json'],
            'seo_title'       => ['type' => 'string', 'limit' => 255],
            'seo_description' => ['type' => 'string', 'limit' => 512],
        ], true);

        $this->createTranslationTable('category_translation', 'category_id', [
            'name'            => ['type' => 'string', 'limit' => 128],
            'description'     => ['type' => 'text'],
            'seo_title'       => ['type' => 'string', 'limit' => 255],
            'seo_description' => ['type' => 'string', 'limit' => 512],
        ]);

        $this->createTranslationTable('brand_translation', 'brand_id', [
            'name'        => ['type' => 'string', 'limit' => 64],
            'slogan'      => ['type' => 'string', 'limit' => 100],
            'short_intro' => ['type' => 'string', 'limit' => 200],
            'description' => ['type' => 'text'],
        ]);

        $this->createTranslationTable('page_translation', 'page_id', [
            'title'           => ['type' => 'string', 'limit' => 191],
            'content'         => ['type' => 'text', 'limit' => \Phinx\Db\Adapter\MysqlAdapter::TEXT_LONG],
            'seo_title'       => ['type' => 'string', 'limit' => 255],
            'seo_keywords'    => ['type' => 'string', 'limit' => 255],
            'seo_description' => ['type' => 'string', 'limit' => 512],
        ]);

        $this->seedLanguages();
    }

    /**
     * 创建统一结构的翻译副表
     *
     * @param string $tableName 表名
     * @param string $foreignKey 父实体外键
     * @param array  $fields     语种特有字段定义
     * @param bool   $withSpecs  是否包含规格翻译
     * @return void
     */
    private function createTranslationTable(string $tableName, string $foreignKey, array $fields, bool $withSpecs = false): void
    {
        $table = $this->table($tableName, [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '内容翻译（' . $foreignKey . '）',
        ]);

        $table->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn($foreignKey, 'biginteger', ['signed' => false, 'null' => false])
            ->addColumn('lang_code', 'string', ['limit' => 12, 'null' => false]);

        foreach ($fields as $name => $def) {
            $table->addColumn($name, $def['type'], array_filter([
                'limit' => $def['limit'] ?? null,
                'null'  => true,
            ], static fn ($v) => $v !== null));
        }

        $table->addColumn('source', 'string', ['limit' => 8, 'default' => 'ai', 'comment' => 'ai / manual'])
            ->addColumn('status', 'tinyinteger', ['default' => 0, 'comment' => '0 草稿 1 已发布'])
            ->addColumn('stale', 'tinyinteger', ['default' => 0, 'comment' => '主表变更后置 1'])
            ->addColumn('source_hash', 'string', ['limit' => 32, 'null' => true])
            ->addColumn('translated_at', 'datetime', ['null' => true])
            ->addColumn('reviewed_by', 'biginteger', ['signed' => false, 'null' => true])
            ->addColumn('reviewed_at', 'datetime', ['null' => true])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addIndex([$foreignKey, 'lang_code'], ['unique' => true])
            ->addIndex(['lang_code', 'status'])
            ->addIndex(['stale'])
            ->create();
    }

    /**
     * 初始化预置语种
     *
     * @return void
     */
    private function seedLanguages(): void
    {
        $now = date('Y-m-d H:i:s');
        $rows = [
            ['code' => 'en', 'name' => '英语', 'native_name' => 'English', 'direction' => 'ltr', 'default_currency' => 'USD', 'is_default' => 1, 'sort' => 0],
            ['code' => 'zh', 'name' => '中文', 'native_name' => '中文', 'direction' => 'ltr', 'default_currency' => 'CNY', 'is_default' => 0, 'sort' => 10],
            ['code' => 'ru', 'name' => '俄语', 'native_name' => 'Русский', 'direction' => 'ltr', 'default_currency' => 'RUB', 'is_default' => 0, 'sort' => 20],
            ['code' => 'fr', 'name' => '法语', 'native_name' => 'Français', 'direction' => 'ltr', 'default_currency' => 'EUR', 'is_default' => 0, 'sort' => 30],
            ['code' => 'ar', 'name' => '阿拉伯语', 'native_name' => 'العربية', 'direction' => 'rtl', 'default_currency' => 'AED', 'is_default' => 0, 'sort' => 40],
            ['code' => 'ja', 'name' => '日语', 'native_name' => '日本語', 'direction' => 'ltr', 'default_currency' => 'JPY', 'is_default' => 0, 'sort' => 50],
            ['code' => 'it', 'name' => '意大利语', 'native_name' => 'Italiano', 'direction' => 'ltr', 'default_currency' => 'EUR', 'is_default' => 0, 'sort' => 60],
            ['code' => 'de', 'name' => '德语', 'native_name' => 'Deutsch', 'direction' => 'ltr', 'default_currency' => 'EUR', 'is_default' => 0, 'sort' => 70],
            ['code' => 'pt', 'name' => '葡萄牙语', 'native_name' => 'Português', 'direction' => 'ltr', 'default_currency' => 'EUR', 'is_default' => 0, 'sort' => 80],
            ['code' => 'es', 'name' => '西班牙语', 'native_name' => 'Español', 'direction' => 'ltr', 'default_currency' => 'EUR', 'is_default' => 0, 'sort' => 90],
        ];

        foreach ($rows as &$row) {
            $row['status'] = 1;
            $row['create_time'] = $now;
            $row['update_time'] = $now;
        }
        unset($row);

        $this->table('language')->insert($rows)->saveData();
    }
}