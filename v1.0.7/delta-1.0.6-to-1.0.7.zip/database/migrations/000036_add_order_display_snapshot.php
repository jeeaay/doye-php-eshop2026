<?php
use think\migration\Migrator;

/**
 * 订单增加「展示币种」快照
 *
 * 订单金额仍全部是 USD：total_amount / order_item.unit_price / order_pay.total_amount 不变。
 * 这里只记录用户下单时看到的参考币种与金额，用于订单详情、客服沟通和数据分析，
 * 不参与支付、退款、结算的任何计算。
 */
class AddOrderDisplaySnapshot extends Migrator
{
    /**
     * 执行迁移
     *
     * @return void
     */
    public function change()
    {
        $table = $this->table('order');

        $table->addColumn('display_currency', 'string', [
                'limit'   => 3,
                'default' => 'USD',
                'comment' => '用户当时的展示币种，仅参考',
            ])
            ->addColumn('display_rate', 'decimal', [
                'precision' => 18,
                'scale'     => 8,
                'default'   => 1,
                'comment'   => '下单时的展示汇率（1 USD = rate 本币）',
            ])
            ->addColumn('display_total_amount', 'decimal', [
                'precision' => 12,
                'scale'     => 2,
                'default'   => 0,
                'comment'   => '本币参考总额，不参与结算',
            ])
            ->addColumn('display_rate_at', 'datetime', [
                'null'    => true,
                'comment' => '展示汇率的取数时间',
            ])
            ->update();
    }
}