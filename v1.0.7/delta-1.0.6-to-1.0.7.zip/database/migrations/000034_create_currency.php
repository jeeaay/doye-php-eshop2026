<?php
use think\migration\Migrator;

/**
 * 多货币展示基础表：currency + currency_rate_log
 *
 * 重要：本项目的订单、支付、退款、结算全部使用 USD，currency 只决定前台「参考价」的展示。
 * 因此没有结算币种、渠道支持币种、汇率上下限等字段。
 *
 * 预置汇率为安装当天的快照（2026-10-30，来源 open.er-api.com），仅用于让页面开箱可用；
 * 生产环境必须由 `php think currency:sync` 每日更新，后台也可手工刷新/覆盖。
 */
class CreateCurrency extends Migrator
{
    /**
     * 执行迁移
     *
     * @return void
     */
    public function change()
    {
        $currency = $this->table('currency', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '展示币种',
        ]);

        $currency->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('code', 'string', ['limit' => 3, 'null' => false, 'comment' => 'ISO 4217'])
            ->addColumn('name', 'string', ['limit' => 64, 'null' => false, 'comment' => '后台显示名'])
            ->addColumn('symbol', 'string', ['limit' => 8, 'null' => false, 'default' => '$'])
            ->addColumn('decimals', 'tinyinteger', ['default' => 2, 'comment' => 'JPY 为 0'])
            ->addColumn('symbol_position', 'string', ['limit' => 8, 'default' => 'before', 'comment' => 'before / after'])
            ->addColumn('symbol_space', 'tinyinteger', ['default' => 0, 'comment' => '符号与金额之间是否留空格'])
            ->addColumn('status', 'tinyinteger', ['default' => 0, 'comment' => '1 启用 0 停用'])
            ->addColumn('is_base', 'tinyinteger', ['default' => 0, 'comment' => 'USD 为 1'])
            ->addColumn('rate', 'decimal', ['precision' => 18, 'scale' => 8, 'default' => 1, 'comment' => '1 USD = rate 本币'])
            ->addColumn('rate_override', 'decimal', ['precision' => 18, 'scale' => 8, 'null' => true, 'comment' => '人工覆盖，null 表示用自动汇率'])
            ->addColumn('rate_source', 'string', ['limit' => 32, 'null' => true])
            ->addColumn('rate_updated_at', 'datetime', ['null' => true])
            ->addColumn('rounding_mode', 'string', ['limit' => 16, 'default' => 'half_up'])
            ->addColumn('rounding_step', 'decimal', ['precision' => 8, 'scale' => 2, 'default' => 0.01])
            ->addColumn('sort', 'integer', ['default' => 0])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addIndex(['code'], ['unique' => true])
            ->addIndex(['status', 'sort'])
            ->create();

        $log = $this->table('currency_rate_log', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '汇率同步历史',
        ]);

        $log->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('currency_code', 'string', ['limit' => 3, 'null' => false])
            ->addColumn('raw_rate', 'decimal', ['precision' => 18, 'scale' => 8, 'null' => true, 'comment' => '接口原始值'])
            ->addColumn('applied_rate', 'decimal', ['precision' => 18, 'scale' => 8, 'null' => true, 'comment' => '实际生效值'])
            ->addColumn('prev_rate', 'decimal', ['precision' => 18, 'scale' => 8, 'null' => true, 'comment' => '上一次生效值'])
            ->addColumn('change_percent', 'decimal', ['precision' => 8, 'scale' => 4, 'null' => true])
            ->addColumn('status', 'string', ['limit' => 12, 'default' => 'accepted', 'comment' => 'accepted / rejected / manual'])
            ->addColumn('source', 'string', ['limit' => 32, 'null' => true])
            ->addColumn('effective_date', 'date', ['null' => true])
            ->addColumn('message', 'string', ['limit' => 255, 'null' => true])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addIndex(['currency_code', 'effective_date'])
            ->addIndex(['status', 'create_time'])
            ->create();

        $this->seedCurrencies();
    }

    /**
     * 初始化预置展示币种
     *
     * @return void
     */
    private function seedCurrencies(): void
    {
        $now = date('Y-m-d H:i:s');
        $rows = [
            ['code' => 'USD', 'name' => '美元', 'symbol' => '$', 'decimals' => 2, 'status' => 1, 'is_base' => 1, 'rate' => 1, 'sort' => 0],
            ['code' => 'EUR', 'name' => '欧元', 'symbol' => '€', 'decimals' => 2, 'status' => 1, 'is_base' => 0, 'rate' => 0.895934, 'sort' => 10],
            ['code' => 'GBP', 'name' => '英镑', 'symbol' => '£', 'decimals' => 2, 'status' => 1, 'is_base' => 0, 'rate' => 0.749154, 'sort' => 20],
            ['code' => 'JPY', 'name' => '日元', 'symbol' => '¥', 'decimals' => 0, 'status' => 1, 'is_base' => 0, 'rate' => 157.881601, 'sort' => 30],
            ['code' => 'CNY', 'name' => '人民币', 'symbol' => '¥', 'decimals' => 2, 'status' => 1, 'is_base' => 0, 'rate' => 6.676858, 'sort' => 40],
            ['code' => 'RUB', 'name' => '卢布', 'symbol' => '₽', 'decimals' => 2, 'status' => 1, 'is_base' => 0, 'rate' => 80.572954, 'sort' => 50],
            ['code' => 'AED', 'name' => '阿联酋迪拉姆', 'symbol' => 'AED', 'decimals' => 2, 'status' => 1, 'is_base' => 0, 'rate' => 3.6725, 'sort' => 60],
            ['code' => 'SAR', 'name' => '沙特里亚尔', 'symbol' => 'SAR', 'decimals' => 2, 'status' => 0, 'is_base' => 0, 'rate' => 3.75, 'sort' => 70],
            ['code' => 'MXN', 'name' => '墨西哥比索', 'symbol' => 'MX$', 'decimals' => 2, 'status' => 0, 'is_base' => 0, 'rate' => 18.833591, 'sort' => 80],
            ['code' => 'BRL', 'name' => '巴西雷亚尔', 'symbol' => 'R$', 'decimals' => 2, 'status' => 0, 'is_base' => 0, 'rate' => 5.362061, 'sort' => 90],
        ];

        foreach ($rows as &$row) {
            $row['symbol_position'] = 'before';
            $row['symbol_space'] = in_array($row['code'], ['AED', 'SAR'], true) ? 1 : 0;
            $row['rate_override'] = null;
            $row['rate_source'] = 'seed';
            $row['rate_updated_at'] = $now;
            $row['rounding_mode'] = 'half_up';
            $row['rounding_step'] = 0.01;
            $row['create_time'] = $now;
            $row['update_time'] = $now;
        }
        unset($row);

        $this->table('currency')->insert($rows)->saveData();
    }
}