<?php
use think\migration\Migrator;

/**
 * AI 翻译任务表：translation_job
 *
 * 用数据库保存任务状态（Redis 只做「有新任务」唤醒），保证 worker 重启不丢任务。
 * 状态机：pending -> running -> done / failed -> dead
 */
class CreateTranslationJob extends Migrator
{
    /**
     * 执行迁移
     *
     * @return void
     */
    public function change()
    {
        $table = $this->table('translation_job', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => 'AI 翻译任务',
        ]);

        $table->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('entity_type', 'string', ['limit' => 32, 'null' => false, 'comment' => 'product / category / brand / page'])
            ->addColumn('entity_id', 'biginteger', ['signed' => false, 'null' => false])
            ->addColumn('source_lang', 'string', ['limit' => 12, 'default' => 'en'])
            ->addColumn('target_lang', 'string', ['limit' => 12, 'null' => false])
            ->addColumn('fields_json', 'json', ['null' => true, 'comment' => '入队时的源字段快照'])
            ->addColumn('status', 'string', ['limit' => 12, 'default' => 'pending', 'comment' => 'pending / running / done / failed / dead / skipped'])
            ->addColumn('priority', 'tinyinteger', ['default' => 0, 'comment' => '手工触发优先级更高'])
            ->addColumn('attempts', 'tinyinteger', ['default' => 0])
            ->addColumn('max_attempts', 'tinyinteger', ['default' => 3])
            ->addColumn('provider', 'string', ['limit' => 32, 'null' => true])
            ->addColumn('model', 'string', ['limit' => 64, 'null' => true])
            ->addColumn('input_chars', 'integer', ['default' => 0])
            ->addColumn('output_chars', 'integer', ['default' => 0])
            ->addColumn('cost', 'decimal', ['precision' => 10, 'scale' => 6, 'default' => 0])
            ->addColumn('error', 'string', ['limit' => 500, 'null' => true])
            ->addColumn('next_retry_at', 'datetime', ['null' => true])
            ->addColumn('started_at', 'datetime', ['null' => true])
            ->addColumn('finished_at', 'datetime', ['null' => true])
            ->addColumn('created_by', 'biginteger', ['signed' => false, 'default' => 0, 'comment' => '0=系统'])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addIndex(['status', 'next_retry_at'])
            ->addIndex(['entity_type', 'entity_id'])
            ->addIndex(['target_lang', 'status'])
            ->create();
    }
}