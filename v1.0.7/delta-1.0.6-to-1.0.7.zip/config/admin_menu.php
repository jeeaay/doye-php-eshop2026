<?php

/**
 * 后台左侧菜单配置
 *
 * 结构：
 *   - key        分组唯一标识（用于展开状态）
 *   - title      一级菜单名称
 *   - icon       一级菜单图标（/static/img/*.svg）
 *   - children   二级菜单；没有 children 的一级菜单直接跳转 url
 *   - active     当前页面标识，与控制器 assignActiveMenu() 的参数一致
 *   - roles      可见角色（缺省表示全部角色）
 *   - in_sidebar false 表示不在侧边栏展示（仅用于面包屑/标题，如头像菜单里的账户设置）
 *
 * 新增页面时只需在这里登记，无需改 layout/base.html。
 */
return [
    [
        'key'    => 'workbench',
        'title'  => '工作台',
        'icon'   => '/static/img/dashboard.svg',
        'url'    => '/admin/index',
        'active' => 'index',
    ],

    [
        'key'      => 'catalog',
        'title'    => '商品与内容',
        'icon'     => '/static/img/inventory_2.svg',
        'children' => [
            ['title' => '商品管理', 'url' => '/admin/products', 'active' => 'products'],
            ['title' => '分类管理', 'url' => '/admin/categories', 'active' => 'categories'],
            ['title' => '品牌管理', 'url' => '/admin/brands', 'active' => 'brands'],
            ['title' => '推荐位设置', 'url' => '/admin/home-ops', 'active' => 'home-ops'],
            ['title' => '单页管理', 'url' => '/admin/pages', 'active' => 'pages', 'roles' => ['super']],
        ],
    ],

    [
        'key'      => 'trade',
        'title'    => '交易与营销',
        'icon'     => '/static/img/receipt_long.svg',
        'children' => [
            ['title' => '订单管理', 'url' => '/admin/orders', 'active' => 'orders'],
            ['title' => '售后管理', 'url' => '/admin/aftersales', 'active' => 'aftersales'],
            ['title' => '优惠管理', 'url' => '/admin/coupons', 'active' => 'coupons', 'roles' => ['super']],
            ['title' => '分享归因', 'url' => '/admin/share', 'active' => 'share'],
        ],
    ],

    [
        'key'      => 'finance',
        'title'    => '财务',
        'icon'     => '/static/img/account_balance_wallet.svg',
        'children' => [
            ['title' => '结算提现', 'url' => '/admin/settlement', 'active' => 'settlement'],
            ['title' => '货币与汇率', 'url' => '/admin/currencies', 'active' => 'currencies', 'roles' => ['super']],
            ['title' => '支付管理', 'url' => '/admin/payments', 'active' => 'payments', 'roles' => ['super']],
        ],
    ],

    [
        'key'      => 'customers',
        'title'    => '客户与账号',
        'icon'     => '/static/img/person.svg',
        'children' => [
            ['title' => '用户管理', 'url' => '/admin/users', 'active' => 'users'],
            ['title' => '商户管理', 'url' => '/admin/merchants', 'active' => 'merchants'],
            ['title' => '人员管理', 'url' => '/admin/staff', 'active' => 'staff'],
            ['title' => '留言管理', 'url' => '/admin/messages', 'active' => 'messages', 'roles' => ['super']],
        ],
    ],

    [
        'key'      => 'system',
        'title'    => '系统与安全',
        'icon'     => '/static/img/settings.svg',
        'children' => [
            ['title' => '站点版本', 'url' => '/admin/edition', 'active' => 'edition', 'roles' => ['super']],
            ['title' => '站点设置', 'url' => '/admin/system', 'active' => 'setting', 'roles' => ['super']],
            ['title' => '安全设置', 'url' => '/admin/security', 'active' => 'security', 'roles' => ['super']],
            ['title' => '操作日志', 'url' => '/admin/audit-logs', 'active' => 'audit-logs', 'roles' => ['super']],
        ],
    ],

    // 头像下拉里的入口：不占侧边栏，但参与标题/面包屑计算
    [
        'key'        => 'personal',
        'title'      => '账户',
        'icon'       => '/static/img/person.svg',
        'in_sidebar' => false,
        'children'   => [
            ['title' => '账户设置', 'url' => '/admin/settings', 'active' => 'settings'],
            ['title' => '密钥管理', 'url' => '/admin/api-keys', 'active' => 'api-keys'],
        ],
    ],
];