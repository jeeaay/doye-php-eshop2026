<?php

return [
    'products' => [
        'image' => [
            'max_size' => 10 * 1024 * 1024,
            'extensions' => ['jpg', 'jpeg', 'png', 'webp'],
            'mimes' => ['image/jpeg', 'image/png', 'image/webp'],
        ],
        'video' => [
            'max_size' => 200 * 1024 * 1024,
            'extensions' => ['mp4', 'webm'],
            'mimes' => ['video/mp4', 'video/webm'],
        ],
    ],
    'merchants' => [
        'image' => [
            'max_size' => 10 * 1024 * 1024,
            'extensions' => ['jpg', 'jpeg', 'png', 'webp'],
            'mimes' => ['image/jpeg', 'image/png', 'image/webp'],
        ],
    ],
    // 品牌 logo 上传规格，与 merchants 完全一致
    'brands' => [
        'image' => [
            'max_size' => 10 * 1024 * 1024,
            'extensions' => ['jpg', 'jpeg', 'png', 'webp'],
            'mimes' => ['image/jpeg', 'image/png', 'image/webp'],
        ],
    ],
    // 单页（CMS）富文本内插图
    'pages' => [
        'image' => [
            'max_size' => 10 * 1024 * 1024,
            'extensions' => ['jpg', 'jpeg', 'png', 'webp'],
            'mimes' => ['image/jpeg', 'image/png', 'image/webp'],
        ],
    ],
    // 专题富文本内插图（规格与 pages 一致）
    'topics' => [
        'image' => [
            'max_size' => 10 * 1024 * 1024,
            'extensions' => ['jpg', 'jpeg', 'png', 'webp'],
            'mimes' => ['image/jpeg', 'image/png', 'image/webp'],
        ],
    ],
    // 商品评论媒体（路径 /uploads/reviews/images|videos/YYYYMM/）
    // 图片与 pages 规格一致；视频限 50MB，前端写评价提示推荐 MP4（iOS Safari 不支持 WebM）
    // compress 存在即执行服务端压缩 + 预生成缩略图（产物 /uploads/thumbs/{width}/reviews/...）
    'reviews' => [
        'image' => [
            'max_size' => 10 * 1024 * 1024,
            'extensions' => ['jpg', 'jpeg', 'png', 'webp'],
            'mimes' => ['image/jpeg', 'image/png', 'image/webp'],
            'compress' => [
                'max_width'  => 1600,
                'max_height' => 1600,
                'quality'    => 82,
                // 尺寸达标且小于该体积时跳过重编码（避免小图二次损失）
                'min_bytes'  => 150 * 1024,
                // 上传后预生成的展示缩略图宽度（前台列表用 480）
                'presets'    => [160, 480, 960],
            ],
        ],
        'video' => [
            'max_size' => 50 * 1024 * 1024,
            'extensions' => ['mp4', 'webm'],
            'mimes' => ['video/mp4', 'video/webm'],
        ],
    ],
];
