<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 站点专题模型
 *
 * 平台级特殊内容页：默认使用单页通用模板，也可指定
 * templates/{theme}/topics/*.html 专属模板；可关联若干商品。
 * 不带商户维度，直接继承 BaseModel。
 */
class Topic extends BaseModel
{
    protected $name = 'topic';

    protected $autoWriteTimestamp = 'datetime';

    /** data 扩展配置按关联数组读写 */
    protected $json = ['data'];

    protected $jsonAssoc = true;

    /**
     * 商品关联（按 sort 升序展示）
     *
     * @return \think\model\relation\HasMany
     */
    public function products()
    {
        return $this->hasMany(TopicProduct::class, 'topic_id');
    }

    /**
     * 翻译
     *
     * @return \think\model\relation\HasMany
     */
    public function translations()
    {
        return $this->hasMany(TopicTranslation::class, 'topic_id');
    }
}
