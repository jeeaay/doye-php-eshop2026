<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 专题关联商品
 */
class TopicProduct extends BaseModel
{
    protected $name = 'topic_product';

    protected $autoWriteTimestamp = 'datetime';

    /** 关联表没有 update_time 列 */
    protected $updateTime = false;
}
