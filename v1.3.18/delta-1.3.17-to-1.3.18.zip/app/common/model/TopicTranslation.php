<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 专题翻译
 */
class TopicTranslation extends BaseModel
{
    protected $name = 'topic_translation';

    protected $autoWriteTimestamp = 'datetime';

    /** data 覆盖按关联数组读写（顶层 key 浅合并） */
    protected $json = ['data'];

    protected $jsonAssoc = true;

    public function topic()
    {
        return $this->belongsTo(Topic::class, 'topic_id');
    }
}
