<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\exception\BizException;
use app\common\model\Topic;

/**
 * 专题模板文件服务
 *
 * 只允许操作当前主题 templates/{theme}/topics/ 下的 .html 文件：
 * 查看 / 新建 / 保存 / 删除。名称白名单、大小上限、归属校验、写前备份、
 * 写后清理编译缓存；模板被专题引用时禁止删除。
 *
 * 模板会经 ThinkTemplate 编译，仅平台超管可编辑，属可信操作。
 */
class TopicTemplateService
{
    /** 目录名：不能用 topic（5 个纯字母会被当成语言目录） */
    public const DIR = 'topics';

    /** 单个模板文件上限（字节） */
    private const MAX_BYTES = 262144;

    /** 文件名称白名单 */
    private const NAME_PATTERN = '/^[a-z0-9][a-z0-9-]{0,63}$/';

    /** 每个文件保留的备份份数 */
    private const BACKUP_KEEP = 10;

    /**
     * 当前活动模板名
     *
     * @throws BizException 未启用前台模板
     */
    public function theme(): string
    {
        $theme = (new TemplateManager())->activeTemplate();
        if ($theme === '' || $theme === 'none') {
            throw new BizException('当前未启用前台模板，无法管理专题模板');
        }
        return $theme;
    }

    /**
     * 专题模板目录绝对路径（不存在时自动创建）
     */
    public function root(): string
    {
        $root = (new TemplateManager())->templatesRootPath()
            . $this->theme() . DIRECTORY_SEPARATOR . self::DIR;
        if (!is_dir($root)) {
            mkdir($root, 0755, true);
        }
        return $root;
    }

    /**
     * 文件是否存在
     */
    public function exists(string $name): bool
    {
        try {
            if (!$this->isValidName($name)) {
                return false;
            }
            return is_file($this->root() . DIRECTORY_SEPARATOR . $name . '.html');
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * 模板列表（含大小、修改时间、被引用专题）
     *
     * @return array<int,array{name:string,size:int,mtime:string,used_by:array<int,string>}>
     */
    public function list(): array
    {
        $root = $this->root();
        $list = [];
        foreach (glob($root . DIRECTORY_SEPARATOR . '*.html') ?: [] as $file) {
            $name = basename($file, '.html');
            if (!$this->isValidName($name)) {
                continue;
            }
            $list[] = [
                'name'  => $name,
                'size'  => (int) (filesize($file) ?: 0),
                'mtime' => date('Y-m-d H:i:s', (int) (filemtime($file) ?: time())),
            ];
        }

        // 一次查询所有引用关系，避免按文件逐个回表（N+1）
        $usedMap = [];
        if ($list !== []) {
            $rows = Topic::whereIn('template_file', array_column($list, 'name'))
                ->order('id')->field('template_file,title')->select();
            foreach ($rows as $row) {
                $usedMap[(string) $row->template_file][] = (string) $row->title;
            }
        }
        foreach ($list as &$item) {
            $item['used_by'] = $usedMap[$item['name']] ?? [];
            $item['used_by_label'] = implode('、', $item['used_by']);
        }
        unset($item);

        usort($list, static fn (array $a, array $b) => strcmp($a['name'], $b['name']));
        return $list;
    }

    /**
     * 读取内容
     */
    public function read(string $name): string
    {
        $path = $this->filePath($name);
        if (!is_file($path)) {
            throw new BizException('模板不存在：' . $name);
        }
        $content = file_get_contents($path);
        if ($content === false) {
            throw new BizException('模板文件读取失败');
        }
        return $content;
    }

    /**
     * 新建模板（写入骨架）
     */
    public function create(string $name): void
    {
        $path = $this->filePath($name);
        if (is_file($path)) {
            throw new BizException('模板已存在：' . $name);
        }
        $skeleton = <<<'HTML'
{extend name="layout/base" /}

{block name="title"}{$page_title}{/block}
{block name="meta"}
{if condition="$meta_desc"}<meta name="description" content="{$meta_desc|htmlentities}">{/if}
{if condition="$meta_keys"}<meta name="keywords" content="{$meta_keys|htmlentities}">{/if}
{/block}

{block name="content"}
  <main>
    <section class="article-hero article-hero-w page-hero">
      <div class="container text-center">
        <h1 class="hero-title">{$topic.title}</h1>
      </div>
    </section>
    <section class="container content-section">
      {if condition="$topic_content"}<div class="cms-content">{$topic_content|raw}</div>{/if}
      {if condition="$topic_products"}
      <div class="topic-products">
        {volist name="topic_products" id="product"}
        <article class="topic-product">
          <a href="{$product.url}">
            {if condition="$product.image"}<img src="{$product.image}" alt="{$product.name}" loading="lazy">{/if}
            <h3>{$product.name}</h3>
            <p>{$product.price}</p>
          </a>
        </article>
        {/volist}
      </div>
      {/if}
    </section>
  </main>
{/block}
HTML;
        $this->write($name, $skeleton, 'create');
    }

    /**
     * 保存模板内容
     */
    public function save(string $name, string $content): void
    {
        $path = $this->filePath($name);
        if (!is_file($path)) {
            throw new BizException('模板不存在：' . $name);
        }
        $this->write($name, $content, 'save');
    }

    /**
     * 删除模板（被专题引用时拒绝）
     */
    public function delete(string $name): void
    {
        $path = $this->filePath($name);
        $usedBy = Topic::where('template_file', $name)->order('id')->column('title');
        if ($usedBy !== []) {
            throw new BizException('模板正被专题使用：' . implode('、', array_map('strval', $usedBy)));
        }
        if (!is_file($path)) {
            throw new BizException('模板不存在：' . $name);
        }
        if (!unlink($path)) {
            throw new BizException('模板删除失败');
        }
    }

    /**
     * 校验模板名并返回绝对路径（防穿越 / 防符号链接逃逸）
     */
    private function filePath(string $name): string
    {
        if (!$this->isValidName($name)) {
            throw new BizException('模板名无效：仅支持小写字母、数字与中划线（1-64 位）');
        }
        $root = realpath($this->root());
        if ($root === false) {
            throw new BizException('专题模板目录不可用');
        }
        $path = $root . DIRECTORY_SEPARATOR . $name . '.html';
        $dir = realpath(dirname($path));
        if ($dir === false || $dir !== $root) {
            throw new BizException('模板路径无效');
        }
        // 目录归属已校验；文件本身不允许是符号链接（防止把 templates 外的文件
        // 软链进 topics/ 后被读取 / 覆盖）
        if (is_link($path)) {
            throw new BizException('模板路径无效：不允许符号链接');
        }
        if (is_file($path)) {
            $realFile = realpath($path);
            if ($realFile === false || !str_starts_with($realFile, $root . DIRECTORY_SEPARATOR)) {
                throw new BizException('模板路径无效');
            }
        }
        return $path;
    }

    private function isValidName(string $name): bool
    {
        return (bool) preg_match(self::NAME_PATTERN, $name);
    }

    /**
     * 写入内容：大小校验 → 备份旧文件 → 写盘 → 清编译缓存 → 审计
     */
    private function write(string $name, string $content, string $action): void
    {
        if (strlen($content) > self::MAX_BYTES) {
            throw new BizException('模板内容超过 256KB 限制');
        }
        $path = $this->filePath($name);
        if (is_file($path)) {
            $this->backup($name, $path);
        }
        $dir = dirname($path);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        if (file_put_contents($path, $content) === false) {
            throw new BizException('模板写入失败');
        }
        $this->clearCompiled();
    }

    /**
     * 备份到 runtime/topic-template-backup，每个文件保留最近 N 份
     */
    private function backup(string $name, string $path): void
    {
        $dir = app()->getRuntimePath() . 'topic-template-backup';
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $target = $dir . DIRECTORY_SEPARATOR . $name . '.' . date('YmdHis') . '.html';
        @copy($path, $target);

        $old = glob($dir . DIRECTORY_SEPARATOR . $name . '.*.html') ?: [];
        usort($old, static fn (string $a, string $b) => strcmp($b, $a));
        foreach (array_slice($old, self::BACKUP_KEEP) as $file) {
            @unlink($file);
        }
    }

    /**
     * 清理模板编译缓存，保存后立即生效
     */
    private function clearCompiled(): void
    {
        $runtime = app()->getRuntimePath();
        foreach (['temp', 'cache'] as $sub) {
            $dir = $runtime . $sub;
            if (!is_dir($dir)) {
                continue;
            }
            foreach (glob($dir . DIRECTORY_SEPARATOR . '*.php') ?: [] as $file) {
                @unlink($file);
            }
        }
    }
}
