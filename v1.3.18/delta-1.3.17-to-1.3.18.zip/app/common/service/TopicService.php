<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\exception\BizException;
use app\common\lib\RedisCache;
use app\common\model\Page;
use app\common\model\Topic;
use app\common\model\TopicProduct;
use app\common\model\TopicTranslation;
use app\controller\Page as PageController;
use think\db\exception\PDOException;
use think\facade\Db;

/**
 * 站点专题服务
 *
 * 平台级内容：后台超管维护产品专题 / 活动专题。
 * - 固定入口 /topic/{slug}，可选顶级路径 custom_path（与单页 / 商品 / 分类互斥）
 * - 模板默认回退 page.html，或 templates/{theme}/topics/*.html
 * - 关联商品手动选择并按 sort 展示
 * 前台入口见 app/controller/Topic.php 与 app/controller/Page.php 的兜底链。
 */
class TopicService
{
    /** 默认模板（单页通用图文页） */
    public const DEFAULT_TEMPLATE = 'page';

    /** 顶级路径缓存 key 前缀 */
    private const CACHE_PREFIX = 'topic:route:';

    /** 顶级路径缓存 TTL（秒） */
    private const CACHE_TTL = 60;

    /** 顶级路径最大长度 */
    private const MAX_PATH_LENGTH = 190;

    /** 专题专用保留路径（其余系统保留路径复用 ProductRouteService::RESERVED_PATHS） */
    private const EXTRA_RESERVED_PATHS = ['topic', 'topics'];

    /**
     * 专题模板下拉数据（后台表单用）
     *
     * @return array<int,array{value:string,label:string}>
     */
    public function templateOptions(): array
    {
        $options = [['value' => '', 'label' => '通用图文页（page 模板）']];
        try {
            foreach ((new TopicTemplateService())->list() as $file) {
                $options[] = ['value' => $file['name'], 'label' => $file['name']];
            }
        } catch (BizException $e) {
            // 未启用前台模板时只保留默认项
        }
        return $options;
    }

    /**
     * 后台详情（含商品顺序与全部译文）
     *
     * @throws BizException 专题不存在
     */
    public function detail(int $id): array
    {
        $topic = Topic::find($id);
        if (!$topic) {
            throw new BizException('专题不存在');
        }

        $translations = [];
        foreach (TopicTranslation::where('topic_id', $id)->order('lang_code')->select() as $row) {
            $lang = strtolower((string) $row->lang_code);
            $translations[$lang] = [
                'title'           => (string) ($row->title ?? ''),
                'content'         => (string) ($row->content ?? ''),
                'seo_title'       => (string) ($row->seo_title ?? ''),
                'seo_keywords'    => (string) ($row->seo_keywords ?? ''),
                'seo_description' => (string) ($row->seo_description ?? ''),
                'data'            => is_array($row->data) ? $row->data : [],
                'status'          => (int) $row->status,
            ];
        }

        return [
            'id'              => (int) $topic->id,
            'title'           => (string) $topic->title,
            'slug'            => (string) $topic->slug,
            'custom_path'     => (string) ($topic->custom_path ?? ''),
            'template_file'   => (string) $topic->template_file,
            'content'         => (string) ($topic->content ?? ''),
            'data'            => is_array($topic->data) ? $topic->data : [],
            'seo_title'       => (string) $topic->seo_title,
            'seo_keywords'    => (string) $topic->seo_keywords,
            'seo_description' => (string) $topic->seo_description,
            'status'          => (int) $topic->status,
            'sort'            => (int) $topic->sort,
            'product_ids'     => $this->productIds($id),
            'translations'    => $translations,
        ];
    }

    /**
     * 新增 / 更新专题
     *
     * @param array    $data 表单数据（product_ids、translations 可为数组或 JSON）
     * @param int|null $id   null 表示新增
     * @return int 专题 ID
     * @throws BizException 校验失败
     */
    public function saveItem(array $data, ?int $id = null): int
    {
        $title       = trim((string) ($data['title'] ?? ''));
        $slug        = strtolower(trim((string) ($data['slug'] ?? '')));
        $customPath  = (new ProductRouteService())->normalize((string) ($data['custom_path'] ?? ''));
        $template    = trim((string) ($data['template_file'] ?? ''));
        $content     = (string) ($data['content'] ?? '');
        $dataConfig  = $this->normalizeData($data['data'] ?? null);

        if ($title === '') {
            throw new BizException('专题标题不能为空');
        }
        $this->validateSlug($slug, $id);
        $this->validateCustomPath($customPath, $id);
        $this->assertTemplate($template);

        $productIds   = $this->normalizeProductIds($data['product_ids'] ?? []);
        $translations = $this->normalizeTranslationsPayload($data['translations'] ?? []);

        $oldCustomPath = '';
        try {
            $topicId = Db::transaction(function () use (
                $data, $id, $title, $slug, $customPath, $template, $content, $dataConfig, $productIds, $translations, &$oldCustomPath
            ): int {
                $topic = $id ? Topic::find($id) : new Topic();
                if (!$topic) {
                    throw new BizException('专题不存在');
                }
                $oldCustomPath = (string) ($topic->custom_path ?? '');

                $topic->title           = $title;
                $topic->slug            = $slug;
                $topic->custom_path     = $customPath !== '' ? $customPath : null;
                $topic->template_file   = $template;
                $topic->content         = $content;
                $topic->data            = $dataConfig;
                $topic->seo_title       = trim((string) ($data['seo_title'] ?? ''));
                $topic->seo_keywords    = trim((string) ($data['seo_keywords'] ?? ''));
                $topic->seo_description = trim((string) ($data['seo_description'] ?? ''));
                $topic->status          = (int) ($data['status'] ?? 0) === 1 ? 1 : 0;
                $topic->sort            = (int) ($data['sort'] ?? 0);
                $topic->save();

                $topicId = (int) $topic->id;
                $this->syncProducts($topicId, $productIds);

                if ($translations !== []) {
                    $this->saveTranslations($topicId, $translations);
                }

                return $topicId;
            });
        } catch (PDOException $e) {
            throw new BizException('保存失败：' . $e->getMessage());
        }

        $this->forgetRouteCache($oldCustomPath, $customPath);
        return $topicId;
    }

    /**
     * 上线 / 下线
     *
     * @throws BizException 专题不存在
     */
    public function toggleItem(int $id, int $status): void
    {
        $topic = Topic::find($id);
        if (!$topic) {
            throw new BizException('专题不存在');
        }
        $topic->status = $status === 1 ? 1 : 0;
        $topic->save();
        $this->forgetRouteCache((string) ($topic->custom_path ?? ''));
    }

    /**
     * 删除专题（级联删除关联商品与译文）
     *
     * @throws BizException 专题不存在
     */
    public function deleteItem(int $id): void
    {
        $topic = Topic::find($id);
        if (!$topic) {
            throw new BizException('专题不存在');
        }
        $customPath = (string) ($topic->custom_path ?? '');

        Db::transaction(static function () use ($id): void {
            TopicProduct::where('topic_id', $id)->delete();
            TopicTranslation::where('topic_id', $id)->delete();
            Topic::where('id', $id)->delete();
        });

        $this->forgetRouteCache($customPath);
    }

    /**
     * 按 slug 查询已上线专题（前台 /topic/{slug}）
     *
     * @return array|null 未找到返回 null
     */
    public function findBySlug(string $slug): ?array
    {
        $slug = strtolower(trim($slug));
        if ($slug === '') {
            return null;
        }
        $topic = Topic::where('slug', $slug)->where('status', 1)->find();
        return $topic ? $this->frontPayload($topic) : null;
    }

    /**
     * 按顶级路径查询已上线专题（Page/detail 兜底链）
     *
     * @return array|null 未找到返回 null
     */
    public function findByCustomPath(string $path): ?array
    {
        $path = (new ProductRouteService())->normalize($path);
        if ($path === '') {
            return null;
        }

        $base = preg_replace('/\.html$/', '', $path) ?? $path;
        foreach (array_unique([$base, $base . '.html']) as $candidate) {
            // 未命中缓存 0（而不是 null）：RedisCache 对 null 视为未命中，
            // 负结果无法缓存，根路径 404 场景会每次回源数据库。
            $topicId = RedisCache::remember(
                self::CACHE_PREFIX . $candidate,
                self::CACHE_TTL,
                static fn (): int => (int) (Topic::where('custom_path', $candidate)->where('status', 1)->value('id') ?: 0)
            );
            if ($topicId > 0) {
                $topic = Topic::find($topicId);
                if ($topic && (int) $topic->status === 1) {
                    return $this->frontPayload($topic);
                }
            }
        }

        return null;
    }

    /**
     * 保存专题译文
     *
     * 标量字段走 TranslationService（与单页/商品同一套校验），
     * data 覆盖单独写入（顶层 key 浅合并）。
     *
     * @param array<string,array<string,mixed>> $payload
     * @return int 实际写入的语种数
     */
    public function saveTranslations(int $id, array $payload): int
    {
        if (!Topic::find($id)) {
            throw new BizException('专题不存在');
        }
        $saved = (new TranslationService())->saveTranslations('topic', $id, $payload);

        foreach ($payload as $lang => $row) {
            $lang = strtolower(trim((string) $lang));
            if ($lang === '' || $lang === base_locale() || !is_array($row) || !array_key_exists('data', $row)) {
                continue;
            }
            $translation = TopicTranslation::where('topic_id', $id)->where('lang_code', $lang)->find();
            if (!$translation) {
                continue;
            }
            $translation->data = $this->normalizeData($row['data']);
            $translation->save();
        }

        return $saved;
    }

    /**
     * 校验 slug：格式 + 唯一
     *
     * @throws BizException
     */
    public function validateSlug(string $slug, ?int $exceptId = null): void
    {
        if ($slug === '') {
            throw new BizException('访问路径不能为空');
        }
        if (mb_strlen($slug) > 191) {
            throw new BizException('访问路径不能超过 191 个字符');
        }
        if (!preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $slug)) {
            throw new BizException('访问路径只能包含小写字母、数字与中划线');
        }

        $exists = Topic::where('slug', $slug)->where('id', '<>', (int) $exceptId)->find();
        if ($exists) {
            throw new BizException('访问路径 /topic/' . $slug . ' 已被其他专题占用');
        }
    }

    /**
     * 校验顶级路径：格式、保留字、内置页、单页、商品、分类、专题互斥
     *
     * @throws BizException
     */
    public function validateCustomPath(string $path, ?int $exceptId = null): void
    {
        if ($path === '') {
            return;
        }
        if (mb_strlen($path) > self::MAX_PATH_LENGTH) {
            throw new BizException('顶级路径不能超过 ' . self::MAX_PATH_LENGTH . ' 个字符');
        }
        if (!preg_match('/^[a-z0-9\-]+(\.html)?$/', $path)) {
            throw new BizException('顶级路径格式无效：仅支持小写字母、数字和连字符，可选 .html 后缀');
        }
        if (preg_match('/^\d+(\.html)?$/', $path)) {
            throw new BizException('顶级路径不能是纯数字（会与商品 / 分类 ID 路径冲突），请加入字母或连字符');
        }

        $base = preg_replace('/\.html$/', '', $path) ?? $path;
        $candidates = array_values(array_unique([$base, $path]));

        foreach ($candidates as $candidate) {
            if (in_array($candidate, self::reservedPaths(), true)) {
                throw new BizException('顶级路径「' . $candidate . '」为系统保留路径，请更换');
            }
            if (in_array($candidate, PageController::builtinSlugs(), true)) {
                throw new BizException('顶级路径「' . $candidate . '」为系统内置页面，请更换');
            }
        }

        if (Page::whereIn('slug', $candidates)->find()) {
            throw new BizException('顶级路径「' . $base . '」已被内容单页占用，请更换');
        }
        if (Db::name('product')->whereIn('custom_path', $candidates)->value('id')) {
            throw new BizException('顶级路径「' . $base . '」已被商品使用，请更换');
        }
        if (Db::name('category')->whereIn('custom_path', $candidates)->value('id')) {
            throw new BizException('顶级路径「' . $base . '」已被分类使用，请更换');
        }
        if (Topic::whereIn('custom_path', $candidates)->where('id', '<>', (int) $exceptId)->find()) {
            throw new BizException('顶级路径「' . $base . '」已被其他专题占用，请更换');
        }
    }

    /**
     * 顶级路径的系统保留清单
     *
     * 复用 {@see ProductRouteService::RESERVED_PATHS}（唯一来源），只追加专题自身的
     * 两段路由前缀，避免第三份清单与商品 / 分类口径漂移。
     *
     * @return array<int,string>
     */
    private static function reservedPaths(): array
    {
        return array_values(array_unique(array_merge(
            ProductRouteService::RESERVED_PATHS,
            self::EXTRA_RESERVED_PATHS
        )));
    }

    /**
     * 检查模板是否可用（空 = 默认 page 模板）
     *
     * @throws BizException
     */
    private function assertTemplate(string $template): void
    {
        if ($template === '') {
            return;
        }
        if (!(new TopicTemplateService())->exists($template)) {
            throw new BizException('专题模板不存在：' . $template);
        }
    }

    /**
     * 前台数据结构（含译文合并与商品顺序）
     */
    private function frontPayload(Topic $topic): array
    {
        $id = (int) $topic->id;
        $payload = [
            'id'              => $id,
            'title'           => (string) $topic->title,
            'slug'            => (string) $topic->slug,
            'custom_path'     => (string) ($topic->custom_path ?? ''),
            'template_file'   => (string) $topic->template_file,
            'content'         => (string) ($topic->content ?? ''),
            'data'            => is_array($topic->data) ? $topic->data : [],
            'seo_title'       => (string) $topic->seo_title,
            'seo_keywords'    => (string) $topic->seo_keywords,
            'seo_description' => (string) $topic->seo_description,
            'product_ids'     => $this->productIds($id),
            'static_url'      => '/topic/' . $topic->slug . '/static',
        ];

        $translation = (new TranslationService())->topic($id);
        if ($translation) {
            $payload = (new TranslationService())->mergeFields($payload, $translation, [
                'title', 'content', 'seo_title', 'seo_keywords', 'seo_description',
            ]);
            if (is_array($translation['data'] ?? null) && $translation['data'] !== []) {
                $payload['data'] = array_replace($payload['data'], $translation['data']);
            }
        }

        return $payload;
    }

    /**
     * 关联商品 ID（按 sort 升序）
     *
     * @return array<int,int>
     */
    private function productIds(int $topicId): array
    {
        return array_map('intval', TopicProduct::where('topic_id', $topicId)
            ->order('sort', 'asc')->order('id', 'asc')->column('product_id'));
    }

    /**
     * 全量重建商品关联
     *
     * @param array<int,int> $productIds
     */
    private function syncProducts(int $topicId, array $productIds): void
    {
        TopicProduct::where('topic_id', $topicId)->delete();
        foreach ($productIds as $index => $productId) {
            $row = new TopicProduct();
            $row->topic_id = $topicId;
            $row->product_id = $productId;
            $row->sort = $index;
            $row->save();
        }
    }

    /**
     * 归一化商品 ID：数组或逗号分隔字符串，去重保序
     *
     * @return array<int,int>
     */
    private function normalizeProductIds($raw): array
    {
        if (is_string($raw)) {
            $raw = array_filter(array_map('trim', explode(',', $raw)), static fn ($v) => $v !== '');
        }
        if (!is_array($raw)) {
            return [];
        }
        $ids = [];
        foreach ($raw as $value) {
            $id = (int) $value;
            if ($id > 0 && !in_array($id, $ids, true)) {
                $ids[] = $id;
            }
        }
        return $ids;
    }

    /**
     * 归一化 data 扩展配置：数组或 JSON 字符串，空 -> null
     *
     * @throws BizException JSON 非法
     */
    private function normalizeData($raw): ?array
    {
        if ($raw === null) {
            return null;
        }
        if (is_string($raw)) {
            $raw = trim($raw);
            if ($raw === '') {
                return null;
            }
            $decoded = json_decode($raw, true);
            if (!is_array($decoded)) {
                throw new BizException('扩展数据必须是合法 JSON 对象');
            }
            if ($decoded !== [] && array_is_list($decoded)) {
                throw new BizException('扩展数据必须是 JSON 对象（不能是数组）');
            }
            return $decoded === [] ? null : $decoded;
        }
        if (is_array($raw)) {
            if ($raw !== [] && array_is_list($raw)) {
                throw new BizException('扩展数据必须是 JSON 对象（不能是数组）');
            }
            return $raw === [] ? null : $raw;
        }
        throw new BizException('扩展数据必须是合法 JSON 对象');
    }

    /**
     * 归一化译文载荷（数组或 JSON 字符串）
     *
     * @return array<string,array<string,mixed>>
     */
    private function normalizeTranslationsPayload($raw): array
    {
        if (is_string($raw)) {
            $raw = trim($raw);
            if ($raw === '') {
                return [];
            }
            $raw = json_decode($raw, true);
        }
        if (!is_array($raw)) {
            return [];
        }
        $payload = [];
        foreach ($raw as $lang => $row) {
            if (!is_string($lang) || !is_array($row)) {
                continue;
            }
            $payload[strtolower(trim($lang))] = $row;
        }
        return $payload;
    }

    /**
     * 失效顶级路径缓存（保存 / 上下线 / 删除时调用）
     */
    public function forgetRouteCache(?string ...$paths): void
    {
        foreach ($paths as $path) {
            $path = strtolower(trim((string) $path));
            if ($path === '') {
                continue;
            }
            $base = preg_replace('/\.html$/', '', $path) ?? $path;
            foreach (array_unique([$path, $base, $base . '.html']) as $candidate) {
                if ($candidate !== '') {
                    RedisCache::forget(self::CACHE_PREFIX . $candidate);
                }
            }
        }
    }
}
