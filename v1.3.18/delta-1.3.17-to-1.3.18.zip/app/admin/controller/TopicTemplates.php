<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\service\LanguageService;
use app\common\service\TemplateManager;
use app\common\service\TopicTemplateService;
use app\common\support\AppContext;
use think\facade\View;

/**
 * 后台专题模板文件管理（平台超管专用）
 *
 * 只允许查看 / 新建 / 编辑 / 删除当前主题 templates/{theme}/topics/ 下的 .html 文件。
 * 写入委托 {@see TopicTemplateService}（大小限制、备份、清缓存、审计）。
 */
class TopicTemplates extends AdminBaseController
{
    /**
     * 模板文件管理页
     *
     * @return \think\response\View|\think\response\Redirect
     */
    public function index()
    {
        $this->assignActiveMenu('topics');

        if (!$this->isSuper()) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可管理专题模板');
        }

        try {
            $service = new TopicTemplateService();
            $theme = $service->theme();
            $files = $service->list();
        } catch (BizException $e) {
            return redirect(admin_url('topics'))->with('error', $e->getMessage());
        }

        View::assign('theme', $theme);
        View::assign('files', $files);
        View::assign('languages', (new LanguageService())->enabled());
        View::assign('templates_root', (new TemplateManager())->templatesRootPath() . $theme . DIRECTORY_SEPARATOR . TopicTemplateService::DIR);

        return View::fetch('topics/templates');
    }

    /**
     * 文件列表（AJAX）
     *
     * @return \think\response\Json
     */
    public function files()
    {
        try {
            $this->assertSuper();
            return json(['code' => 0, 'message' => '', 'data' => (new TopicTemplateService())->list()]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 读取文件内容
     *
     * @return \think\response\Json
     */
    public function read()
    {
        try {
            $this->assertSuper();
            $name = trim((string) $this->request->get('name', ''));
            $service = new TopicTemplateService();
            if (!$service->exists($name)) {
                throw new BizException('模板不存在：' . $name);
            }
            return json(['code' => 0, 'message' => '', 'data' => [
                'name'    => $name,
                'content' => $service->read($name),
            ]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 保存文件内容
     *
     * @return \think\response\Json
     */
    public function save()
    {
        try {
            $this->assertSuper();
            $name = trim((string) $this->request->post('name', ''));
            $content = (string) $this->request->post('content', '');
            (new TopicTemplateService())->save($name, $content);
            return json(['code' => 0, 'message' => '模板已保存，前台已生效', 'data' => ['name' => $name]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 新建模板
     *
     * @return \think\response\Json
     */
    public function create()
    {
        try {
            $this->assertSuper();
            $name = strtolower(trim((string) $this->request->post('name', '')));
            (new TopicTemplateService())->create($name);
            return json(['code' => 0, 'message' => '模板已创建', 'data' => ['name' => $name]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 删除模板
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        try {
            $this->assertSuper();
            $name = trim((string) $this->request->post('name', ''));
            (new TopicTemplateService())->delete($name);
            return json(['code' => 0, 'message' => '模板已删除', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 仅平台超管
     *
     * @throws BizException
     */
    private function assertSuper(): void
    {
        if (!$this->isSuper()) {
            throw new BizException('仅平台超级管理员可管理专题模板');
        }
    }

    private function isSuper(): bool
    {
        return AppContext::getAdminRole() === AdminRole::SUPER;
    }
}
