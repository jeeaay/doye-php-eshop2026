<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\model\Product;
use app\common\model\Topic;
use app\common\service\LanguageService;
use app\common\service\MediaUploadService;
use app\common\service\TemplateManager;
use app\common\service\TopicService;
use app\common\support\AppContext;
use think\facade\Db;
use think\facade\View;

/**
 * 后台专题管理（产品专题 / 活动专题）
 *
 * 平台级内容，仅平台超级管理员可维护；写入委托 {@see TopicService}。
 * 列表 + 独立编辑页（富文本 + 商品选择 + 扩展 data + 翻译）。
 * 专题模板文件在线编辑见 TopicTemplates。
 */
class Topics extends AdminBaseController
{
    /**
     * 专题列表
     *
     * @return \think\response\View|\think\response\Redirect
     */
    public function index()
    {
        $this->assignActiveMenu('topics');

        if (!$this->isSuper()) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可管理专题');
        }

        $title  = trim((string) $this->request->get('title', ''));
        $status = $this->request->get('status', '');

        $query = Topic::order('sort')->order('id', 'desc');
        if ($title !== '') {
            $query->whereLike('title', '%' . $title . '%');
        }
        if ($status !== '' && $status !== null) {
            $query->where('status', (int) $status);
        }

        $topics = $query->paginate(20, false, [
            'query' => ['title' => $title, 'status' => $status],
        ]);

        $ids = [];
        foreach ($topics as $topic) {
            $ids[] = (int) $topic->id;
        }
        $counts = [];
        if ($ids !== []) {
            $counts = Db::name('topic_product')->whereIn('topic_id', $ids)
                ->group('topic_id')->column('COUNT(*)', 'topic_id');
        }

        $list = [];
        foreach ($topics as $topic) {
            $list[] = [
                'id'            => (int) $topic->id,
                'title'         => (string) $topic->title,
                'slug'          => (string) $topic->slug,
                'custom_path'   => (string) ($topic->custom_path ?? ''),
                'template_file' => (string) $topic->template_file,
                'product_count' => (int) ($counts[(int) $topic->id] ?? 0),
                'status'        => (int) $topic->status,
                'sort'          => (int) $topic->sort,
                'update_time'   => (string) $topic->update_time,
            ];
        }

        View::assign('topics_list', $list);
        View::assign('filters', ['title' => $title, 'status' => $status]);
        View::assign('topics_link', $topics->render());

        return View::fetch();
    }

    /**
     * 新增 / 编辑专题表单
     *
     * @return \think\response\View|\think\response\Redirect
     */
    public function form()
    {
        $this->assignActiveMenu('topics');

        if (!$this->isSuper()) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可管理专题');
        }

        $service = new TopicService();
        $id = (int) $this->request->get('id', 0);
        $topic = [
            'id'              => 0,
            'title'           => '',
            'slug'            => '',
            'custom_path'     => '',
            'template_file'   => '',
            'content'         => '',
            'data'            => [],
            'seo_title'       => '',
            'seo_keywords'    => '',
            'seo_description' => '',
            'status'          => 1,
            'sort'            => 0,
            'product_ids'     => [],
            'translations'    => [],
        ];

        if ($id > 0) {
            try {
                $topic = $service->detail($id);
            } catch (BizException $e) {
                return redirect(admin_url('topics'))->with('error', $e->getMessage());
            }
        }

        $selected = [];
        if ($topic['product_ids'] !== []) {
            $products = Product::whereIn('id', $topic['product_ids'])
                ->field('id,title,status,main_image')->select();
            $map = [];
            foreach ($products as $product) {
                $map[(int) $product->id] = [
                    'id'     => (int) $product->id,
                    'title'  => (string) $product->title,
                    'status' => (int) $product->status,
                    'image'  => (string) ($product->main_image ?? ''),
                ];
            }
            foreach ($topic['product_ids'] as $pid) {
                if (isset($map[$pid])) {
                    $selected[] = $map[$pid];
                }
            }
        }

        $languages = $this->translationLanguages();
        $templateOptions = $service->templateOptions();

        View::assign('topic', $topic);
        View::assign('template_options', $templateOptions);
        View::assign('template_missing', $topic['template_file'] !== ''
            && !in_array($topic['template_file'], array_column($templateOptions, 'value'), true));
        View::assign('theme', (new TemplateManager())->activeTemplate());
        View::assign('data_json', json_encode($topic['data'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        View::assign('translations_json', json_encode($topic['translations'], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT));
        View::assign('selected_products', $selected);
        View::assign('languages', $languages);
        View::assign('multilingual_enabled', (bool) site_config('i18n.enabled', false) && $languages !== []);

        return View::fetch('topics/form');
    }

    /**
     * 保存专题（新增或更新）
     *
     * @return \think\response\Json
     */
    public function save()
    {
        try {
            $this->assertSuper();

            $id = (int) $this->request->post('id', 0);
            $data = (array) $this->request->post();
            $data['product_ids'] = (array) $this->request->post('product_ids', []);

            $newId = (new TopicService())->saveItem($data, $id ?: null);

            return json(['code' => 0, 'message' => '专题已保存', 'data' => ['id' => $newId]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 上线 / 下线
     *
     * @return \think\response\Json
     */
    public function status()
    {
        try {
            $this->assertSuper();
            (new TopicService())->toggleItem(
                (int) $this->request->post('id'),
                (int) $this->request->post('status')
            );
            return json(['code' => 0, 'message' => '专题状态已更新', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 删除专题
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        try {
            $this->assertSuper();
            $id = (int) $this->request->post('id');
            (new TopicService())->deleteItem($id);

            return json(['code' => 0, 'message' => '专题已删除', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 商品搜索（专题商品选择器）
     *
     * @return \think\response\Json
     */
    public function productSearch()
    {
        try {
            $this->assertSuper();

            $keyword = trim((string) $this->request->get('keyword', ''));
            $query = Product::field('id,title,status,main_image')->order('id', 'desc');
            if ($keyword !== '') {
                $query->whereLike('title', '%' . $keyword . '%');
            }

            $list = [];
            foreach ($query->limit(30)->select() as $product) {
                $list[] = [
                    'id'     => (int) $product->id,
                    'title'  => (string) $product->title,
                    'status' => (int) $product->status,
                    'image'  => (string) ($product->main_image ?? ''),
                ];
            }

            return json(['code' => 0, 'message' => '', 'data' => $list]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 富文本编辑器图片上传（topics 命名空间）
     *
     * @return \think\response\Json
     */
    public function upload()
    {
        try {
            $this->assertSuper();
            $data = (new MediaUploadService())->upload($this->request->file('file'), 'image', 'topics');
            return json(['code' => 0, 'message' => 'ok', 'data' => $data]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 可编辑的翻译语种（不含基准语种）
     *
     * @return array<int,array<string,mixed>>
     */
    private function translationLanguages(): array
    {
        $languages = [];
        foreach ((new LanguageService())->enabled() as $language) {
            if (strtolower((string) $language['code']) === base_locale()) {
                continue;
            }
            $languages[] = $language;
        }
        return $languages;
    }

    /**
     * 仅平台超管
     *
     * @throws BizException
     */
    private function assertSuper(): void
    {
        if (!$this->isSuper()) {
            throw new BizException('仅平台超级管理员可管理专题');
        }
    }

    /**
     * 当前登录账号是否为平台超级管理员
     */
    private function isSuper(): bool
    {
        return AppContext::getAdminRole() === AdminRole::SUPER;
    }
}
