<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\exception\BizException;
use app\common\model\Topic as TopicModel;
use app\common\service\TopicService;
use think\facade\Db;

/**
 * 管理 API：站点专题（产品专题 / 活动专题）
 *
 * 平台级内容，仅平台超级管理员可读写；写入委托 {@see TopicService}，
 * 与后台「专题管理」共用同一套校验（slug / 顶级路径冲突、模板存在性、商品顺序）。
 */
class Topic extends ApiBaseController
{
    /**
     * GET /admin-api/v1/topics
     *
     * 支持 title / status / page / page_size
     *
     * @return \think\response\Json
     */
    public function index()
    {
        return $this->run(function () {
            $this->assertSuper();
            [$page, $size] = $this->pageParams();

            $title  = trim((string) $this->request->param('title', ''));
            $status = $this->request->param('status', '');

            $query = TopicModel::order('sort')->order('id', 'desc');
            if ($title !== '') {
                $query->whereLike('title', '%' . $title . '%');
            }
            if ($status !== '' && $status !== null) {
                $query->where('status', (int) $status);
            }

            $pager = $query->paginate($size, false, [
                'page'  => $page,
                'query' => ['title' => $title, 'status' => $status],
            ]);

            $ids = [];
            foreach ($pager->items() as $row) {
                $ids[] = (int) $row->id;
            }
            $counts = [];
            if ($ids !== []) {
                $counts = Db::name('topic_product')->whereIn('topic_id', $ids)
                    ->group('topic_id')->column('COUNT(*)', 'topic_id');
            }

            $list = [];
            foreach ($pager->items() as $row) {
                $list[] = [
                    'id'            => (int) $row->id,
                    'title'         => (string) $row->title,
                    'slug'          => (string) $row->slug,
                    'custom_path'   => (string) ($row->custom_path ?? ''),
                    'template_file' => (string) $row->template_file,
                    'product_count' => (int) ($counts[(int) $row->id] ?? 0),
                    'status'        => (int) $row->status,
                    'sort'          => (int) $row->sort,
                    'update_time'   => $row->update_time ? (string) $row->update_time : '',
                ];
            }

            return $this->pagePayload($list, $pager, $page, $size);
        });
    }

    /**
     * GET /admin-api/v1/topics/:id
     *
     * @return \think\response\Json
     */
    public function detail()
    {
        return $this->run(function () {
            $this->assertSuper();
            return (new TopicService())->detail((int) $this->request->param('id', 0));
        });
    }

    /**
     * POST /admin-api/v1/topics
     *
     * 必填 title / slug；product_ids 为有序商品 ID 数组；data 为 JSON 对象或字符串
     *
     * @return \think\response\Json
     */
    public function save()
    {
        return $this->run(function () {
            $this->assertSuper();
            $data = $this->input();
            $id = (new TopicService())->saveItem($data, null);
            return ['id' => $id];
        }, '专题已创建');
    }

    /**
     * PUT /admin-api/v1/topics/:id
     *
     * 建议提交完整字段（缺省字段按默认值处理）；product_ids 为全量顺序。
     *
     * @return \think\response\Json
     */
    public function update()
    {
        return $this->run(function () {
            $this->assertSuper();
            $id = (int) $this->request->param('id', 0);
            if ($id <= 0) {
                throw new BizException('缺少专题 ID');
            }
            (new TopicService())->saveItem($this->input(), $id);
            return ['id' => $id];
        }, '专题已更新');
    }

    /**
     * DELETE /admin-api/v1/topics/:id
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        return $this->run(function () {
            $this->assertSuper();
            (new TopicService())->deleteItem((int) $this->request->param('id', 0));
            return null;
        }, '专题已删除');
    }

    /**
     * POST /admin-api/v1/topics/:id/status
     *
     * body {status:0|1}
     *
     * @return \think\response\Json
     */
    public function status()
    {
        return $this->run(function () {
            $this->assertSuper();
            $input = $this->input();
            if (!isset($input['status']) || !in_array((int) $input['status'], [0, 1], true)) {
                throw new BizException('专题状态无效');
            }
            (new TopicService())->toggleItem(
                (int) $this->request->param('id', 0),
                (int) $input['status']
            );
            return null;
        }, '专题状态已更新');
    }

    /**
     * GET /admin-api/v1/topics/:id/translations
     *
     * @return \think\response\Json
     */
    public function translations()
    {
        return $this->run(function () {
            $this->assertSuper();
            $detail = (new TopicService())->detail((int) $this->request->param('id', 0));
            return $detail['translations'];
        });
    }

    /**
     * PUT /admin-api/v1/topics/:id/translations
     *
     * body {translations: {ru: {title, content, seo_title, seo_keywords, seo_description, data, status}}}
     *
     * @return \think\response\Json
     */
    public function saveTranslations()
    {
        return $this->run(function () {
            $this->assertSuper();
            $input = $this->input();
            $payload = $input['translations'] ?? $input;
            if (!is_array($payload)) {
                throw new BizException('翻译数据格式无效');
            }
            $id = (int) $this->request->param('id', 0);
            if ($id <= 0) {
                throw new BizException('缺少专题 ID');
            }
            $saved = (new TopicService())->saveTranslations($id, $payload);
            return ['saved' => $saved];
        }, '专题译文已保存');
    }
}
