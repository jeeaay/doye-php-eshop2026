<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\exception\BizException;
use app\common\service\TopicTemplateService;

/**
 * 管理 API：专题模板文件
 *
 * 只允许操作当前主题 templates/{theme}/topics/ 下的 .html；
 * 名称白名单、大小上限、写前备份、写后清缓存、删除引用检查均由
 * {@see TopicTemplateService} 负责，并在服务内写审计。
 */
class TopicTemplate extends ApiBaseController
{
    /**
     * GET /admin-api/v1/topic-templates
     *
     * @return \think\response\Json
     */
    public function index()
    {
        return $this->run(function () {
            $this->assertSuper();
            return (new TopicTemplateService())->list();
        });
    }

    /**
     * POST /admin-api/v1/topic-templates
     *
     * body {name}
     *
     * @return \think\response\Json
     */
    public function create()
    {
        return $this->run(function () {
            $this->assertSuper();
            $input = $this->input();
            $name = strtolower(trim((string) ($input['name'] ?? '')));
            (new TopicTemplateService())->create($name);
            return ['name' => $name];
        }, '模板已创建');
    }

    /**
     * GET /admin-api/v1/topic-templates/:name
     *
     * @return \think\response\Json
     */
    public function read()
    {
        return $this->run(function () {
            $this->assertSuper();
            $name = trim((string) $this->request->param('name', ''));
            $service = new TopicTemplateService();
            if (!$service->exists($name)) {
                throw new BizException('模板不存在：' . $name);
            }
            return ['name' => $name, 'content' => $service->read($name)];
        });
    }

    /**
     * PUT /admin-api/v1/topic-templates/:name
     *
     * body {content}
     *
     * @return \think\response\Json
     */
    public function save()
    {
        return $this->run(function () {
            $this->assertSuper();
            $input = $this->input();
            $name = trim((string) $this->request->param('name', ''));
            (new TopicTemplateService())->save($name, (string) ($input['content'] ?? ''));
            return ['name' => $name];
        }, '模板已保存');
    }

    /**
     * DELETE /admin-api/v1/topic-templates/:name
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        return $this->run(function () {
            $this->assertSuper();
            (new TopicTemplateService())->delete(trim((string) $this->request->param('name', '')));
            return null;
        }, '模板已删除');
    }
}
