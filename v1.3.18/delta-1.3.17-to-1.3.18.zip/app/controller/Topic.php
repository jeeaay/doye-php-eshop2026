<?php
declare(strict_types=1);

namespace app\controller;

use app\common\service\TopicService;
use app\common\support\LocaleContext;

/**
 * 专题页（产品专题 / 活动专题）
 *
 * 固定入口 /topic/{slug}；设置顶级路径后也可经由 Page/detail 的兜底链访问。
 * 模板默认复用单页通用模板 page.html，或 templates/{theme}/topics/*.html。
 * 后台入口：/admin/topics（仅平台超管）。
 */
class Topic extends SiteBase
{
    /**
     * 专题详情
     *
     * @param string $slug 专题 slug
     * @return mixed
     */
    public function detail($slug = '')
    {
        $slug = strtolower(trim((string) $slug));
        $topic = (new TopicService())->findBySlug($slug);
        if ($topic === null) {
            return $this->notFound('Topic not found');
        }

        return $this->renderTopicView($topic);
    }

    /**
     * 渲染专题（供顶级路径解析复用）
     *
     * @param array $topic TopicService::findBySlug()/findByCustomPath() 返回的数据
     * @return mixed
     */
    public function renderTopicView(array $topic)
    {
        $brand = $this->store->brand();
        $seoTitle = $topic['seo_title'] !== '' ? $topic['seo_title'] : $topic['title'];
        // 顶级路径可能存成 xxx.html（校验允许），但前台实际可访问的是不带后缀的 xxx，
        // sitemap 同样按基础路径收录，canonical / hreflang 必须与之一致
        $customPath = preg_replace('/\.html$/', '', (string) $topic['custom_path']) ?? '';
        $urlPath = $customPath !== ''
            ? '/' . ltrim($customPath, '/')
            : '/topic/' . $topic['slug'];

        // 专属模板不存在时回退通用图文页，避免专题「打不开」
        $view = 'page';
        if ($topic['template_file'] !== '') {
            $candidate = 'topics/' . $topic['template_file'];
            $tmpl = $this->templates->activeTemplate();
            $locale = LocaleContext::localeCode();
            if ($this->templates->resolveView($tmpl, $candidate . '.html', $locale)) {
                $view = $candidate;
            }
        }

        return $this->render($view, [
            'nav_active'     => '',
            'page_title'     => $seoTitle . ' - ' . $brand['name'] . $brand['suffix'],
            'page_name'      => $topic['title'],
            'page_content'   => $topic['content'],
            'meta_desc'      => $topic['seo_description'],
            'meta_keys'      => $topic['seo_keywords'],
            'canonical_url'  => $this->canonicalUrl($urlPath),
            'hreflang_links' => $this->hreflangLinks($urlPath),
            'topic'          => $topic,
            'topic_products' => $this->store->topicProducts($topic['product_ids']),
            'topic_content'  => $topic['content'],
            'topic_static'   => $topic['static_url'],
            'slug'           => $topic['slug'],
        ]);
    }
}
