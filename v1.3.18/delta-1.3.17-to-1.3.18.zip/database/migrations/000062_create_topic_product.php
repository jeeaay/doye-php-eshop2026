<?php
use think\migration\Migrator;

/**
 * 创建专题商品关联表 topic_product
 *
 * 专题按手动挑选的商品顺序展示；用关联表而不是 JSON 数组，
 * 便于稳定排序、统计商品被引用次数与后续扩展。
 */
class CreateTopicProduct extends Migrator
{
    /**
     * 执行迁移：创建 topic_product 表
     *
     * @return void
     */
    public function change()
    {
        $table = $this->table('topic_product', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '专题关联商品（有序）',
        ]);
        $table->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('topic_id', 'biginteger', ['signed' => false, 'null' => false, 'comment' => '专题 ID'])
            ->addColumn('product_id', 'biginteger', ['signed' => false, 'null' => false, 'comment' => '商品 ID'])
            ->addColumn('sort', 'integer', ['limit' => 11, 'null' => false, 'default' => 0, 'comment' => '展示顺序，升序'])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addIndex(['topic_id', 'product_id'], ['unique' => true, 'name' => 'uk_topic_product'])
            ->addIndex(['product_id'])
            ->addIndex(['topic_id', 'sort'])
            ->create();
    }
}
