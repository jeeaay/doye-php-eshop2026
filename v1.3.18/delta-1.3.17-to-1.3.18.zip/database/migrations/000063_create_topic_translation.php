<?php
use think\migration\Migrator;

/**
 * 创建专题翻译表 topic_translation
 *
 * 结构对齐 page_translation：标题 / 正文 / SEO 可由人工或翻译任务覆盖；
 * data 为 JSON 顶层 key 浅合并（模板结构化文案的多语言覆盖）。
 */
class CreateTopicTranslation extends Migrator
{
    /**
     * 执行迁移：创建 topic_translation 表
     *
     * @return void
     */
    public function change()
    {
        $table = $this->table('topic_translation', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '专题翻译',
        ]);
        $table->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('topic_id', 'biginteger', ['signed' => false, 'null' => false])
            ->addColumn('lang_code', 'string', ['limit' => 12, 'null' => false])
            ->addColumn('title', 'string', ['limit' => 191, 'null' => true])
            ->addColumn('content', 'text', ['limit' => \Phinx\Db\Adapter\MysqlAdapter::TEXT_LONG, 'null' => true])
            ->addColumn('seo_title', 'string', ['limit' => 255, 'null' => true])
            ->addColumn('seo_keywords', 'string', ['limit' => 255, 'null' => true])
            ->addColumn('seo_description', 'string', ['limit' => 512, 'null' => true])
            ->addColumn('data', 'json', ['null' => true, 'comment' => 'data 覆盖（顶层 key 浅合并）'])
            ->addColumn('source', 'string', ['limit' => 8, 'default' => 'ai', 'comment' => 'ai / manual'])
            ->addColumn('status', 'tinyinteger', ['default' => 0, 'comment' => '0 草稿 1 已发布'])
            ->addColumn('stale', 'tinyinteger', ['default' => 0, 'comment' => '主表变更后置 1'])
            ->addColumn('source_hash', 'string', ['limit' => 32, 'null' => true])
            ->addColumn('translated_at', 'datetime', ['null' => true])
            // TranslationService::saveTranslations() 在 payload 带 reviewed 时会写这两列，
            // 结构必须与 page_translation（000033 createTranslationTable）保持一致
            ->addColumn('reviewed_by', 'biginteger', ['signed' => false, 'null' => true])
            ->addColumn('reviewed_at', 'datetime', ['null' => true])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addIndex(['topic_id', 'lang_code'], ['unique' => true, 'name' => 'uk_topic_translation'])
            ->addIndex(['lang_code', 'status'])
            ->addIndex(['stale'])
            ->create();
    }
}
