<?php
use think\migration\Migrator;

/**
 * 创建专题表 topic
 *
 * 专题是平台级特殊内容页：默认复用单页通用模板（page.html），也可指定
 * templates/{theme}/topics/*.html 专属模板；可引用若干商品并携带扩展 data。
 * 不是商户内容，不带 merchant_id，仅平台超级管理员维护。
 */
class CreateTopic extends Migrator
{
    /**
     * 执行迁移：创建 topic 表
     *
     * @return void
     */
    public function change()
    {
        $table = $this->table('topic', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '站点专题（产品专题 / 活动专题）',
        ]);
        $table->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('title', 'string', ['limit' => 191, 'null' => false, 'default' => '', 'comment' => '专题标题（H1 / 后台列表名）'])
            ->addColumn('slug', 'string', ['limit' => 191, 'null' => false, 'default' => '', 'comment' => 'URL 路径段，固定前缀 /topic/{slug}'])
            ->addColumn('custom_path', 'string', ['limit' => 191, 'null' => true, 'default' => null, 'comment' => '可选顶级路径，如 summer-sale；与单页/商品/分类互斥'])
            ->addColumn('template_file', 'string', ['limit' => 191, 'null' => false, 'default' => '', 'comment' => 'topics/ 下的模板名（不含 .html）；空=page.html'])
            ->addColumn('content', 'text', ['null' => true, 'comment' => '富文本内容（HTML），供模板调用'])
            ->addColumn('data', 'json', ['null' => true, 'comment' => '扩展配置 JSON（banner/subtitle/cta/theme 等，模板自由解释）'])
            ->addColumn('seo_title', 'string', ['limit' => 255, 'null' => false, 'default' => '', 'comment' => 'SEO 标题'])
            ->addColumn('seo_keywords', 'string', ['limit' => 255, 'null' => false, 'default' => '', 'comment' => 'SEO 关键词'])
            ->addColumn('seo_description', 'string', ['limit' => 512, 'null' => false, 'default' => '', 'comment' => 'SEO 描述'])
            ->addColumn('status', 'tinyinteger', ['limit' => 1, 'null' => false, 'default' => 1, 'comment' => '1 上线 0 下线'])
            ->addColumn('sort', 'integer', ['limit' => 11, 'null' => false, 'default' => 0, 'comment' => '排序，数字越小越靠前'])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addIndex(['slug'], ['unique' => true, 'name' => 'uk_topic_slug'])
            ->addIndex(['custom_path'], ['unique' => true, 'name' => 'uk_topic_custom_path'])
            ->addIndex(['status', 'sort'])
            ->create();
    }
}
