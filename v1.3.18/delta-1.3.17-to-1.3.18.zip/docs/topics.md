# 专题（Topic）

专题是一种平台级特殊内容页，用于「产品专题」「活动专题」这类需要**专属版式 + 引用商品 + 独立静态资源**的页面。
默认可以直接用单页通用模板展示富文本，也可以指定自己的模板文件，与前台常规模板目录隔离。

后台入口：`商品与内容 → 专题管理`（`/console/topics`，仅平台超管）。
管理 API：`/admin-api/v1/topics`、`/admin-api/v1/topic-templates`，见 [admin-api.md](./admin-api.md) §9.2。

## 1. 目录约定

```
templates/{theme}/topics/          # 专题专属模板（theme 为当前启用模板，如 almi2026）
templates/{theme}/{locale}/topics/ # 可选：按语种覆盖同名模板
public/topic/{slug}/static/        # 专题静态资源（CSS/JS/图片），Nginx 直接托管
runtime/topic-template-backup/     # 在线编辑时的旧文件备份（保留最近 10 份，不进版本库）
```

- 目录名必须是 `topics`，**不能改成 `topic`**：`TemplateManager::listLangDirs()` 会把
  `templates/{theme}/` 下 2–5 个纯字母的子目录当成语言目录，`topic` 会被误判为语言 `topic`。
- 模板名只允许小写字母、数字与中划线（`^[a-z0-9][a-z0-9-]{0,63}$`），单文件 ≤ 256KB。

## 2. 后台使用

1. 在「专题模板文件」中新建 / 编辑模板（保存后前台立即生效，会自动清理编译缓存）。
2. 在「专题管理 → 新增专题」中填写：
   - 标题、`slug`（固定地址 `/topic/{slug}`）
   - 顶级路径（可选，如 `summer-sale`，前台可直接 `/summer-sale`）
   - 模板（默认「通用图文页」，或选择 `topics/` 下的模板）
   - 富文本正文、扩展数据 `data`（JSON）、关联商品（搜索添加、上下移动排序）
   - SEO 字段、状态、排序；开启多语种后可维护各语种标题 / 正文 / SEO / `data` 覆盖
3. 上线后访问 `/topic/{slug}`（或顶级路径）查看效果。

### 路径冲突规则

顶级路径与以下内容**双向互斥**（后创建的一方会被拒绝）：

- 系统保留路径（`products`、`cart`、`checkout`、`login`、`account`、`topic`、`topics` 等）
- 主题内置页面（`about`、`service`、`contact`、`privacy` …）
- 单页 `page.slug`
- 商品 `product.custom_path`
- 分类 `category.custom_path`
- 其他专题 `custom_path`

纯数字路径会被拒绝（避免与商品/分类 ID 路径冲突）。另外，**不要使用与已启用语言代码相同的两字母路径**（如 `de`、`ru`）：
`LocalePrefix` 会把两字母首段当语言前缀剥离，导致 `https://站点/de` 进入首页而非专题；这是商品/分类/单页的同款历史缺口，建议统一避开。

> 修改 `slug` 不会自动迁移 `public/topic/{slug}/static/`；需要自行把静态目录改名，
> 否则模板里的 `topic_static()` 会指向新路径而文件还在旧目录。

## 3. 模板变量

| 变量 | 说明 |
|---|---|
| `$topic` | 专题数据：`id` / `title` / `slug` / `custom_path` / `template_file` / `content` / `data`（数组）/ `seo_title` / `seo_keywords` / `seo_description` / `product_ids` / `static_url` |
| `$topic_products` | 关联商品卡片数组，按后台顺序；只含在售且未删除商品，已按当前语言与展示币种处理 |
| `$topic_content` | 富文本正文 HTML（配合 `\|raw` 输出） |
| `$topic_static` | 静态资源目录：`/topic/{slug}/static` |
| `$page_title` | 已拼接品牌后缀的页面标题 |
| `$meta_desc` / `$meta_keys` | SEO 描述 / 关键词 |

商品卡片字段与商品列表一致（`StorefrontService::card()`）：
`id` / `url` / `name` / `brief` / `price` / `price_max` / `has_range` / `images` / `image` / `sku_count` 等。

最小模板示例：

```html
{extend name="layout/base" /}

{block name="title"}{$page_title}{/block}

{block name="content"}
  <main class="container">
    <h1>{$topic.title}</h1>
    {if condition="$topic.data.subtitle"}<p>{$topic.data.subtitle}</p>{/if}

    {if condition="$topic_products"}
    <div class="topic-grid">
      {volist name="topic_products" id="p"}
      <a class="topic-card" href="{$p.url}">
        {if condition="$p.image"}<img src="{$p.image}" alt="{$p.name}" loading="lazy">{/if}
        <h3>{$p.name}</h3>
        <p>{$p.price}</p>
      </a>
      {/volist}
    </div>
    {/if}

    {if condition="$topic_content"}<div class="cms-content">{$topic_content|raw}</div>{/if}

    <script src="{:topic_static($topic.slug, 'app.js')}"></script>
  </main>
{/block}
```

> 模板内联 `<script>` / `<style>` 仍按项目约定包 `{literal}...{/literal}`；
> 外链 `src` 里的 `{:topic_static(...)}` 不需要 literal。

## 4. 静态资源

把文件放到 `public/topic/{slug}/static/`，模板用 `{:topic_static($topic.slug, 'app.js')}` 引用。
开发环境（`php -S … -t public`）会直接命中；生产由 Nginx 托管，建议：

```nginx
# 专题静态资源：命中文件直接返回，未命中交回 PHP（避免把 /topic/{slug} 页面也拦掉）
location ^~ /topic/ {
    location ~ ^/topic/[a-z0-9-]+/static/ {
        try_files $uri =404;
        expires 7d;
        add_header Cache-Control "public";
    }
    try_files $uri $uri/ /index.php?s=$uri&$args;
}
```

`public/topic/` 属于站点内容，不在发布包的 `manage_roots` 中：**在线更新不会覆盖也不会删除它**，
但也不会帮你备份 —— 站点迁移/备份时请把 `public/topic/` 与 `templates/{theme}/topics/` 一起带上。

## 5. 多语言

- 译文存 `topic_translation`，字段：标题 / 正文 / SEO / `data`（顶层 key 浅合并）/ 发布状态。
- 前台按当前 locale 合并，空字段回退基准语种；`/ru/topic/{slug}` 与 hreflang、canonical 自动生效。
- 模板内的静态文案可用 `templates/{theme}/{locale}/topics/同名模板` 覆盖，或在模板中调用 `site_lang()`。

## 6. 在线编辑模板的安全边界

- 仅平台超管可进入；只能操作当前主题 `topics/` 目录下的 `.html`，文件名白名单 + realpath 归属校验。
- 每次保存前把旧文件复制到 `runtime/topic-template-backup/`；保存后清理模板编译缓存。
- 模板被任一专题引用时禁止删除。
- 模板经 ThinkTemplate 编译，等价于「超管可执行模板逻辑」；不开放给非超管，也不提供任意目录编辑。

## 7. 发布与更新

- 代码层（迁移、`templates/{theme}/topics/` 下的模板）随增量包下发；`templates` 已在 `config/update.php` 的 `manage_roots`。
- 数据库内容（专题记录、`data`、译文）与静态资源属于站点数据，按站点自身备份策略处理。
- 升级脚本只会执行 `php think migrate:run`，三张 `topic*` 表会自动创建。
