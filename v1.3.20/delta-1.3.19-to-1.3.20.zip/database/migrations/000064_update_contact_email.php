<?php
use think\migration\Migrator;

/**
 * 全站联系邮箱统一为 almitoolservice@gmail.com
 *
 * 线上 setting 覆盖值（contact.email / contact.support / mail.notify_to / mail.from）
 * 与 page / page_translation 正文里仍残留旧地址，这里做一次性替换。
 *
 * 只替换已知旧地址：管理员后来自定义的其它邮箱不受影响。
 * 数据替换不可逆，down() 不反向回滚（反向替换会覆盖管理员后设的 gmail）。
 */
class UpdateContactEmail extends Migrator
{
    /** 新邮箱（与 config/site.php 默认值一致） */
    private const NEW_EMAIL = 'almitoolservice@gmail.com';

    /** 正文中需要替换的旧地址（与 setting 的旧值集合一致） */
    private const LEGACY_EMAILS = [
        'service@almi.co.uk',
        'hello@almi.example',
        'info@almiliving.com',
        'service@almiliving.com',
        'trade@almiliving.com',
    ];

    public function up()
    {
        $this->updateSettingRows();
        $this->replacePageContent('page');
        $this->replacePageContent('page_translation');
    }

    public function down()
    {
        // 数据替换不可逆：保持空操作，人工回退请直接改回目标邮箱。
    }

    /**
     * setting：contact.email / contact.support / mail.notify_to 旧值替换；
     * mail.from 单独处理（历史发件人为 no-reply@almi.co.uk）。
     */
    private function updateSettingRows(): void
    {
        if (!$this->hasTable('setting')) {
            return;
        }

        $placeholders = implode(', ', array_fill(0, count(self::LEGACY_EMAILS), '?'));
        $params = array_merge(
            [self::NEW_EMAIL, 'contact.email', 'contact.support', 'mail.notify_to'],
            self::LEGACY_EMAILS
        );

        $this->execute(
            'UPDATE `setting` SET `value` = ?'
            . ' WHERE `key` IN (?, ?, ?)'
            . ' AND `value` IN (' . $placeholders . ')',
            $params
        );

        $this->execute(
            'UPDATE `setting` SET `value` = ? WHERE `key` = ? AND `value` = ?',
            [self::NEW_EMAIL, 'mail.from', 'no-reply@almi.co.uk']
        );
    }

    /**
     * page / page_translation 正文中的旧地址逐条 REPLACE
     */
    private function replacePageContent(string $table): void
    {
        if (!$this->hasTable($table)) {
            return;
        }

        foreach (self::LEGACY_EMAILS as $legacy) {
            $this->execute(
                'UPDATE `' . $table . '` SET `content` = REPLACE(`content`, ?, ?)'
                . ' WHERE `content` LIKE ?',
                [$legacy, self::NEW_EMAIL, '%' . $legacy . '%']
            );
        }
    }
}
