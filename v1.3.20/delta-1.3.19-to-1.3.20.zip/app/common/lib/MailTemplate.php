<?php
declare(strict_types=1);

namespace app\common\lib;

/**
 * 事务性邮件模板（验证码 / 订单支付成功 / 券到账 / 到期提醒 / 券退回）
 *
 * 只渲染字符串，不接模板引擎：邮件不需要 layout 继承，且在 CLI 里能直接单测。
 * 基准语言取 base_locale()（国内版 zh、国际版 en），缺文案时回退英文。
 * 所有变量输出前统一转义，模板里不拼 SQL / 不读请求参数；
 * 新版式只用 inline CSS + 表格布局，不引用外部 CSS / 图片（邮箱客户端兼容性最好）。
 */
class MailTemplate
{
    /** 场景 => 中/英模板 */
    private const COPY = [
        'grant_arrived' => [
            'zh' => [
                'subject' => '「%s」优惠券已到账',
                'title'   => '优惠券已到账',
                'intro'   => '你好 %s，你获得了一张优惠券，已存入账户：',
                'cta'     => '去查看我的优惠券',
            ],
            'en' => [
                'subject' => 'Your coupon from %s has arrived',
                'title'   => 'Your coupon has arrived',
                'intro'   => 'Hi %s, a coupon has been added to your account:',
                'cta'     => 'View my coupons',
            ],
        ],
        'expiring_soon' => [
            'zh' => [
                'subject' => '「%s」优惠券即将过期',
                'title'   => '优惠券即将过期',
                'intro'   => '你好 %s，以下优惠券即将过期，请尽快使用：',
                'cta'     => '去使用优惠券',
            ],
            'en' => [
                'subject' => 'Your coupon from %s expires soon',
                'title'   => 'Your coupon expires soon',
                'intro'   => 'Hi %s, the following coupon will expire soon:',
                'cta'     => 'Use my coupon',
            ],
        ],
        'coupon_restored' => [
            'zh' => [
                'subject' => '「%s」退款完成，优惠券已退回',
                'title'   => '优惠券已退回',
                'intro'   => '你好 %s，订单已全额退款，当时使用的优惠券已退回账户：',
                'cta'     => '去查看我的优惠券',
            ],
            'en' => [
                'subject' => '%s: coupon restored after refund',
                'title'   => 'Coupon restored',
                'intro'   => 'Hi %s, your order has been fully refunded and the coupon you used is back in your account:',
                'cta'     => 'View my coupons',
            ],
        ],
        'verification_code' => [
            'zh' => [
                'subject'   => '「%s」邮箱验证码',
                'title'     => '邮箱验证码',
                'intro'     => '你好 %s，请使用下面的验证码完成验证：',
                'code'      => '验证码',
                'expire'    => '验证码 %s 分钟内有效，请尽快使用。',
                'notice'    => '如果这不是你本人的操作，请忽略本邮件，你的账户不会有任何变更。',
                'preheader' => '你的验证码 %s，%s 分钟内有效。',
            ],
            'en' => [
                'subject'   => '%s verification code',
                'title'     => 'Your verification code',
                'intro'     => 'Hi %s, use the code below to complete your verification:',
                'code'      => 'Verification code',
                'expire'    => 'This code expires in %s minutes.',
                'notice'    => "If you didn't request this code, you can safely ignore this email. Your account will not be changed.",
                'preheader' => 'Your code is %s. It expires in %s minutes.',
            ],
        ],
        'order_paid' => [
            'zh' => [
                'subject'    => '「%s」订单支付成功',
                'title'      => '支付成功',
                'intro'      => '你好 %s，我们已收到你的付款，正在为你安排发货。',
                'order_no'   => '订单号',
                'paid_at'    => '支付时间',
                'total'      => '实付金额',
                'items'      => '商品明细',
                'qty'        => '数量',
                'amount'     => '小计',
                'more'       => '另有 %s 件商品未列出',
                'cta'        => '查看我的订单',
                'preheader'  => '订单 %s 已支付成功，实付 %s。',
            ],
            'en' => [
                'subject'    => '%s: payment received',
                'title'      => 'Payment received',
                'intro'      => 'Hi %s, we have received your payment and your order is being prepared.',
                'order_no'   => 'Order number',
                'paid_at'    => 'Paid at',
                'total'      => 'Total paid',
                'items'      => 'Items',
                'qty'        => 'Qty',
                'amount'     => 'Amount',
                'more'       => 'and %s more item(s)',
                'cta'        => 'View my orders',
                'preheader'  => 'Order %s has been paid. Total %s.',
            ],
        ],
    ];

    /**
     * 渲染一封邮件
     *
     * @param string $scene 场景：verification_code / order_paid / grant_arrived / expiring_soon / coupon_restored
     * @param array  $vars  场景变量，见各 renderXxx 方法
     * @return array{subject:string,html:string,text:string} text 为空时由 Mailer 从 HTML 粗略生成
     * @throws \InvalidArgumentException 未知场景
     */
    public static function render(string $scene, array $vars): array
    {
        $lang = str_starts_with(base_locale(), 'zh') ? 'zh' : 'en';
        $copy = self::COPY[$scene][$lang] ?? self::COPY[$scene]['en'] ?? null;
        if (!is_array($copy)) {
            throw new \InvalidArgumentException('未知邮件场景: ' . $scene);
        }

        return match ($scene) {
            'verification_code' => self::renderVerificationCode($lang, $copy, $vars),
            'order_paid'        => self::renderOrderPaid($lang, $copy, $vars),
            default             => self::renderCoupon($lang, $copy, $vars),
        };
    }

    /**
     * 优惠券三场景（本次不做视觉改版，保持原有 HTML 输出）
     *
     * @param string $lang zh / en
     * @param array  $copy 文案
     * @param array  $vars brand, name, coupon_name, amount_text, min_amount, expire_at, link
     * @return array{subject:string,html:string,text:string}
     */
    private static function renderCoupon(string $lang, array $copy, array $vars): array
    {
        $brand      = self::e((string) ($vars['brand'] ?? ''));
        $name       = self::e(self::displayName((string) ($vars['name'] ?? '')));
        $couponName = self::e((string) ($vars['coupon_name'] ?? ''));
        $amount     = self::e((string) ($vars['amount_text'] ?? ''));
        $minAmount  = (string) ($vars['min_amount'] ?? '0.00');
        $expireAt   = (string) ($vars['expire_at'] ?? '');
        $link       = self::safeLink((string) ($vars['link'] ?? ''));

        $labels = $lang === 'zh'
            ? ['coupon' => '优惠券', 'amount' => '面额', 'threshold' => '使用门槛', 'expire' => '到期时间', 'noThreshold' => '无门槛']
            : ['coupon' => 'Coupon', 'amount' => 'Value', 'threshold' => 'Minimum spend', 'expire' => 'Expires at', 'noThreshold' => 'No minimum'];

        $threshold = bccomp($minAmount, '0', 2) > 0 ? $minAmount : $labels['noThreshold'];

        $rows = '<tr><td style="padding:6px 12px;color:#666">' . $labels['coupon'] . '</td>'
            . '<td style="padding:6px 12px;font-weight:600">' . $couponName . '</td></tr>'
            . '<tr><td style="padding:6px 12px;color:#666">' . $labels['amount'] . '</td>'
            . '<td style="padding:6px 12px;font-weight:600">' . $amount . '</td></tr>'
            . '<tr><td style="padding:6px 12px;color:#666">' . $labels['threshold'] . '</td>'
            . '<td style="padding:6px 12px">' . self::e($threshold) . '</td></tr>';

        if ($expireAt !== '') {
            $rows .= '<tr><td style="padding:6px 12px;color:#666">' . $labels['expire'] . '</td>'
                . '<td style="padding:6px 12px">' . self::e($expireAt) . '</td></tr>';
        }

        $button = $link === ''
            ? ''
            : '<p style="margin:24px 0 0"><a href="' . $link . '" '
                . 'style="display:inline-block;padding:10px 20px;background:#111;color:#fff;text-decoration:none;border-radius:6px">'
                . self::e($copy['cta']) . '</a></p>';

        $html = '<!doctype html><html><body style="margin:0;background:#f6f6f6;font-family:-apple-system,Segoe UI,Arial,sans-serif">'
            . '<div style="max-width:560px;margin:24px auto;background:#fff;border-radius:8px;padding:24px;color:#222">'
            . '<p style="margin:0 0 16px;font-size:13px;color:#888">' . $brand . '</p>'
            . '<h2 style="margin:0 0 16px;font-size:20px">' . self::e($copy['title']) . '</h2>'
            . '<p style="margin:0 0 16px">' . sprintf($copy['intro'], $name) . '</p>'
            . '<table style="border-collapse:collapse;font-size:14px">' . $rows . '</table>'
            . $button
            . '</div></body></html>';

        return [
            'subject' => sprintf((string) $copy['subject'], (string) ($vars['brand'] ?? '')),
            'html'    => $html,
            'text'    => '',
        ];
    }

    /**
     * 验证码邮件：大字号等宽验证码 + 有效期 + 「非本人操作请忽略」
     *
     * @param string $lang zh / en
     * @param array  $copy 文案
     * @param array  $vars brand, name, code, ttl_minutes, contact_email
     * @return array{subject:string,html:string,text:string}
     */
    private static function renderVerificationCode(string $lang, array $copy, array $vars): array
    {
        $rawBrand = (string) ($vars['brand'] ?? '');
        $brand    = self::e($rawBrand);
        $name     = self::e(self::displayName((string) ($vars['name'] ?? '')));
        $code     = self::e((string) ($vars['code'] ?? ''));
        $ttl      = (int) ($vars['ttl_minutes'] ?? 10);
        $ttl      = $ttl > 0 ? $ttl : 10;
        $contact  = self::e((string) ($vars['contact_email'] ?? ''));

        $content = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
            . 'style="margin:8px 0 20px;background:#f7f8fa;border:1px solid #e6e8eb;border-radius:8px;">'
            . '<tr><td align="center" style="padding:20px 12px;'
            . 'font-family:\'SFMono-Regular\',Consolas,\'Liberation Mono\',Menlo,monospace;'
            . 'font-size:32px;line-height:1.2;letter-spacing:8px;font-weight:700;color:#111">' . $code . '</td></tr>'
            . '</table>'
            . '<p style="margin:0 0 12px;font-size:15px;line-height:1.6;color:#3d4450">' . sprintf($copy['expire'], (string) $ttl) . '</p>'
            . '<p style="margin:0;font-size:13px;line-height:1.6;color:#8a9099">' . self::e($copy['notice']) . '</p>';

        $html = self::layout($lang, [
            'brand'   => $brand,
            'title'   => self::e($copy['title']),
            'intro'   => sprintf($copy['intro'], $name),
            'content' => $content,
            'button'  => '',
            'contact' => $contact,
            'preheader' => sprintf($copy['preheader'], (string) ($vars['code'] ?? ''), (string) $ttl),
        ]);

        $text = $copy['title'] . "\n\n"
            . sprintf($copy['intro'], self::displayName((string) ($vars['name'] ?? ''))) . "\n\n"
            . '    ' . (string) ($vars['code'] ?? '') . "\n\n"
            . sprintf($copy['expire'], (string) $ttl) . "\n"
            . $copy['notice'] . "\n\n"
            . self::textFooter($lang, $contact, $brand);

        return [
            'subject' => sprintf((string) $copy['subject'], $rawBrand),
            'html'    => $html,
            'text'    => $text,
        ];
    }

    /**
     * 订单支付成功邮件：订单信息表 + 商品摘要 + 「查看我的订单」按钮
     *
     * @param string $lang zh / en
     * @param array  $copy 文案
     * @param array  $vars brand, name, order_nos, paid_at, total_text, items[], more_count, link, contact_email
     * @return array{subject:string,html:string,text:string}
     */
    private static function renderOrderPaid(string $lang, array $copy, array $vars): array
    {
        $rawBrand = (string) ($vars['brand'] ?? '');
        $brand    = self::e($rawBrand);
        $name     = self::e(self::displayName((string) ($vars['name'] ?? '')));
        $paidAt   = self::e((string) ($vars['paid_at'] ?? ''));
        $total    = self::e((string) ($vars['total_text'] ?? ''));
        $contact  = self::e((string) ($vars['contact_email'] ?? ''));
        $link     = self::safeLink((string) ($vars['link'] ?? ''));

        $orderNosSource = $vars['order_nos'] ?? '';
        if (is_array($orderNosSource)) {
            $orderNosSource = implode(', ', array_map(static fn ($no): string => (string) $no, $orderNosSource));
        }
        $orderNosRaw = trim((string) $orderNosSource);
        $orderNos    = self::e($orderNosRaw);

        $items = is_array($vars['items'] ?? null) ? $vars['items'] : [];
        $moreCount = (int) ($vars['more_count'] ?? 0);

        // 订单信息表
        $infoRows = self::infoRow($copy['order_no'], $orderNos);
        if ($paidAt !== '') {
            $infoRows .= self::infoRow($copy['paid_at'], $paidAt);
        }
        $infoRows .= self::infoRow($copy['total'], '<span style="font-weight:700">' . $total . '</span>');

        $content = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
            . 'style="width:100%;margin:4px 0 20px;font-size:14px;color:#1f2328;border-collapse:collapse">'
            . $infoRows . '</table>';

        // 商品摘要表
        if ($items !== []) {
            $itemRows = '';
            foreach ($items as $item) {
                if (!is_array($item)) {
                    continue;
                }
                $title  = self::e((string) ($item['title'] ?? ''));
                $spec   = self::e((string) ($item['spec'] ?? ''));
                $qty    = (int) ($item['qty'] ?? 0);
                $amount = self::e((string) ($item['amount'] ?? ''));

                $itemRows .= '<tr>'
                    . '<td style="padding:8px 0;border-top:1px solid #ececec;font-size:14px;line-height:1.5;color:#1f2328">'
                    . $title
                    . ($spec !== '' ? '<br><span style="font-size:12px;color:#8a9099">' . $spec . '</span>' : '')
                    . '</td>'
                    . '<td align="center" style="padding:8px 0;border-top:1px solid #ececec;white-space:nowrap;font-size:13px;color:#5c6470">'
                    . '×' . $qty . '</td>'
                    . '<td align="right" style="padding:8px 0;border-top:1px solid #ececec;white-space:nowrap;font-size:14px;font-weight:600;color:#1f2328">'
                    . $amount . '</td>'
                    . '</tr>';
            }

            if ($itemRows !== '') {
                $content .= '<p style="margin:0 0 6px;font-size:13px;font-weight:600;color:#5c6470">' . self::e($copy['items']) . '</p>'
                    . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" '
                    . 'style="width:100%;border-collapse:collapse;font-size:14px">'
                    . $itemRows . '</table>';
            }
        }

        if ($moreCount > 0) {
            $content .= '<p style="margin:10px 0 0;font-size:13px;color:#8a9099">'
                . sprintf($copy['more'], (string) $moreCount) . '</p>';
        }

        $button = $link === ''
            ? ''
            : '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:24px 0 0"><tr>'
                . '<td style="border-radius:6px;background:#111">'
                . '<a href="' . $link . '" style="display:inline-block;padding:12px 24px;font-size:14px;'
                . 'font-weight:600;color:#ffffff;text-decoration:none;border-radius:6px">' . self::e($copy['cta']) . '</a>'
                . '</td></tr></table>';

        $html = self::layout($lang, [
            'brand'   => $brand,
            'title'   => self::e($copy['title']),
            'intro'   => sprintf($copy['intro'], $name),
            'content' => $content,
            'button'  => $button,
            'contact' => $contact,
            'preheader' => sprintf($copy['preheader'], $orderNosRaw, (string) ($vars['total_text'] ?? '')),
        ]);

        // 纯文本备用正文
        $text = $copy['title'] . "\n\n"
            . sprintf($copy['intro'], self::displayName((string) ($vars['name'] ?? ''))) . "\n\n"
            . $copy['order_no'] . ': ' . $orderNosRaw . "\n";
        if ((string) ($vars['paid_at'] ?? '') !== '') {
            $text .= $copy['paid_at'] . ': ' . (string) $vars['paid_at'] . "\n";
        }
        $text .= $copy['total'] . ': ' . (string) ($vars['total_text'] ?? '') . "\n";

        if ($items !== []) {
            $text .= "\n" . $copy['items'] . ":\n";
            foreach ($items as $item) {
                if (!is_array($item)) {
                    continue;
                }
                $line = '- ' . (string) ($item['title'] ?? '');
                if ((string) ($item['spec'] ?? '') !== '') {
                    $line .= ' (' . (string) $item['spec'] . ')';
                }
                $line .= ' x' . (int) ($item['qty'] ?? 0) . '  ' . (string) ($item['amount'] ?? '');
                $text .= $line . "\n";
            }
        }
        if ($moreCount > 0) {
            $text .= sprintf($copy['more'], (string) $moreCount) . "\n";
        }
        if ($link !== '') {
            $text .= "\n" . $copy['cta'] . ': ' . html_entity_decode($link, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
        $text .= "\n" . self::textFooter($lang, $contact, $brand);

        return [
            'subject' => sprintf((string) $copy['subject'], $rawBrand),
            'html'    => $html,
            'text'    => $text,
        ];
    }

    /**
     * 统一版式：100% 宽外表格 + 600px 白卡片（品牌头 / 标题 / 正文 / 按钮 / 页脚）
     *
     * 全部 inline CSS，不引用外部样式与图片，兼容主流邮箱客户端。
     *
     * @param string $lang    zh / en
     * @param array  $options brand,title,intro,content,button,contact,preheader
     * @return string
     */
    private static function layout(string $lang, array $options): string
    {
        $font = "-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif";
        $langAttr = $lang === 'zh' ? 'zh-CN' : 'en';

        $preheader = trim((string) ($options['preheader'] ?? ''));

        return '<!doctype html><html lang="' . $langAttr . '"><head>'
            . '<meta charset="UTF-8">'
            . '<meta name="viewport" content="width=device-width,initial-scale=1">'
            . '<title>' . (string) $options['title'] . '</title>'
            . '</head>'
            . '<body style="margin:0;padding:0;background:#f4f5f7;">'
            . ($preheader === ''
                ? ''
                : '<div style="display:none;max-height:0;overflow:hidden;opacity:0;color:#f4f5f7">' . self::e($preheader) . '</div>')
            . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="width:100%;background:#f4f5f7">'
            . '<tr><td align="center" style="padding:24px 12px;">'
            . '<table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" '
            . 'style="width:600px;max-width:600px;background:#ffffff;border:1px solid #ececec;border-radius:10px;font-family:' . $font . ';">'
            . '<tr><td style="padding:24px 32px 0;font-size:17px;font-weight:700;letter-spacing:0.2px;color:#111111">'
            . (string) $options['brand'] . '</td></tr>'
            . '<tr><td style="padding:16px 32px 24px;">'
            . '<h1 style="margin:0 0 16px;font-size:22px;line-height:1.35;font-weight:700;color:#111111">' . (string) $options['title'] . '</h1>'
            . '<p style="margin:0 0 16px;font-size:15px;line-height:1.6;color:#3d4450">' . (string) $options['intro'] . '</p>'
            . (string) $options['content']
            . (string) ($options['button'] ?? '')
            . '</td></tr>'
            . '<tr><td style="padding:18px 32px 26px;border-top:1px solid #ececec;font-size:12px;line-height:1.7;color:#8a9099">'
            . self::footerHtml($lang, (string) ($options['contact'] ?? ''), (string) $options['brand'])
            . '</td></tr>'
            . '</table></td></tr></table></body></html>';
    }

    /**
     * 页脚 HTML：客服邮箱 + 自动发送说明 + 版权
     *
     * @param string $lang    zh / en
     * @param string $contact 已转义的客服邮箱（空则省略该行）
     * @param string $brand   已转义的品牌名
     * @return string
     */
    private static function footerHtml(string $lang, string $contact, string $brand): string
    {
        $lines = [];
        if ($contact !== '') {
            $lines[] = ($lang === 'zh' ? '如需帮助，请联系 ' : 'Need help? Contact ') . $contact;
        }
        $lines[] = $lang === 'zh'
            ? '本邮件由系统自动发送，请勿直接回复。'
            : 'This email was sent automatically, please do not reply.';
        $lines[] = '&copy; ' . date('Y') . ' ' . $brand;

        return implode('<br>', $lines);
    }

    /**
     * 页脚纯文本
     *
     * @param string $lang    zh / en
     * @param string $contact 已转义的客服邮箱
     * @param string $brand   已转义的品牌名
     * @return string
     */
    private static function textFooter(string $lang, string $contact, string $brand): string
    {
        $contactPlain = html_entity_decode($contact, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $brandPlain   = html_entity_decode($brand, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        $lines = [];
        if ($contactPlain !== '') {
            $lines[] = ($lang === 'zh' ? '如需帮助，请联系 ' : 'Need help? Contact ') . $contactPlain;
        }
        $lines[] = $lang === 'zh'
            ? '本邮件由系统自动发送，请勿直接回复。'
            : 'This email was sent automatically, please do not reply.';
        $lines[] = '© ' . date('Y') . ' ' . $brandPlain;

        return implode("\n", $lines);
    }

    /**
     * 订单信息表的一行（标签 + 值）
     *
     * @param string $label 标签文案
     * @param string $value 已转义的值
     * @return string
     */
    private static function infoRow(string $label, string $value): string
    {
        return '<tr>'
            . '<td style="padding:8px 0;border-top:1px solid #ececec;font-size:13px;color:#8a9099;white-space:nowrap;vertical-align:top">'
            . self::e($label) . '</td>'
            . '<td align="right" style="padding:8px 0;border-top:1px solid #ececec;font-size:14px;line-height:1.5;color:#1f2328;word-break:break-all">'
            . $value . '</td>'
            . '</tr>';
    }

    /**
     * 收件人显示名：有昵称用昵称，没有就给一个中性称呼
     *
     * @param string $name 昵称
     * @return string
     */
    private static function displayName(string $name): string
    {
        return $name !== '' ? $name : (str_starts_with(base_locale(), 'zh') ? '你好' : 'there');
    }

    /**
     * HTML 转义
     *
     * @param string $value 原值
     * @return string
     */
    private static function e(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    /**
     * 只允许 http(s) 链接，避免模板被注入 javascript:
     *
     * @param string $link 链接
     * @return string
     */
    private static function safeLink(string $link): string
    {
        return preg_match('#^https?://#i', $link) === 1 ? self::e($link) : '';
    }
}
