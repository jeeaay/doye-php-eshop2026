<?php
declare(strict_types=1);

namespace app\common\lib;

use app\common\exception\BizException;
use app\common\model\User;
use app\common\service\MarketingService;
use app\common\service\UserService;
use think\facade\Log;

/**
 * 前台（浏览器）登录：邮箱 + 验证码
 *
 * 背景：PHP 后台原本只有微信小程序登录（code2session -> openid），
 * 浏览器端无法取得 wx.login 的 code，因此独立站需要一个可在浏览器完成的登录方式。
 * 这里补一个最小实现的邮箱验证码登录，签发与小程序相同的 Bearer token
 * （Redis key: token:{token}），从而复用后台全部 /api/* 用户接口。
 *
 * 依赖：user.email 字段（见 database/migrations 中 add_user_email_for_web_login）。
 */
class SiteAuth
{
    private const CODE_PREFIX     = 'site:auth:code:';
    private const ATTEMPT_PREFIX  = 'site:auth:try:';
    private const THROTTLE_PREFIX = 'site:auth:at:';
    private const CODE_TTL        = 600;

    public function sendCode(string $email): array
    {
        $email = self::normalizeEmail($email);

        // 模式判定：启用邮件服务即真实发送（永不回显验证码）；
        // 未启用时只有打开 dev_show_code 才允许开发模式；两者都关闭直接拒绝，不生成验证码。
        $mailEnabled = (bool) site_config('mail.enabled', false);
        $dev         = !$mailEnabled && (bool) site_config('auth.dev_show_code', false);
        if (!$mailEnabled && !$dev) {
            throw new BizException('邮件服务未启用，暂时无法发送验证码');
        }

        // 60 秒重发节流：SET NX 原子占位，避免并发双击发出两封
        $interval    = max(1, (int) site_config('auth.resend_interval', 60));
        $throttleKey = self::THROTTLE_PREFIX . md5($email);
        $acquired    = RedisCache::client()->set($throttleKey, serialize(1), 'EX', $interval, 'NX');
        if (!$acquired) {
            throw new BizException('发送过于频繁，请稍后再试');
        }

        // 真实发信先过三维限流（收件 / IP / 全站）；超限不占额度，但要让用户能立刻重试
        if ($mailEnabled) {
            $limit = (new MailRateLimiter())->check($email, client_ip());
            if (!$limit['allowed']) {
                RedisCache::del($throttleKey);
                $minutes = max(1, (int) ceil(max(1, (int) $limit['retry_after']) / 60));
                throw new BizException('发送过于频繁，请 ' . $minutes . ' 分钟后再试');
            }
        }

        $code = (string) random_int(100000, 999999);
        $ttl  = (int) site_config('auth.code_ttl', self::CODE_TTL);

        if ($mailEnabled) {
            // 发送成功才落验证码：失败时不留可用验证码，也不阻塞用户立刻重试
            if (!$this->deliver($email, $code)) {
                RedisCache::del($throttleKey);
                throw new BizException('验证码邮件发送失败，请稍后重试');
            }
            $this->storeCode($email, $code, $ttl);

            return [
                'sent'     => true,
                'ttl'      => $ttl,
                'dev_mode' => false,
                'dev_code' => null,
            ];
        }

        // 开发模式：不发信、不占真实发信额度，只落 Redis 并回显（邮件启用后日志不再输出验证码）
        $this->storeCode($email, $code, $ttl);
        Log::info("[site-auth] dev mode code for {$email}: {$code}");

        return [
            'sent'     => false,
            'ttl'      => $ttl,
            'dev_mode' => true,
            'dev_code' => $code,
        ];
    }

    public function verifyCode(string $email, string $code): array
    {
        $email = self::normalizeEmail($email);
        $code = trim($code);
        if (!preg_match('/^\d{6}$/', $code)) {
            throw new BizException('验证码格式不正确');
        }

        $key = self::CODE_PREFIX . md5($email);
        $cached = RedisCache::get($key);
        if (!$cached) {
            throw new BizException('验证码已过期，请重新获取');
        }

        $attemptKey = self::ATTEMPT_PREFIX . md5($email);
        $attempts = (int) RedisCache::get($attemptKey);
        $maxAttempts = (int) site_config('auth.max_attempts', 5);
        if ($attempts >= $maxAttempts) {
            RedisCache::del($key);
            throw new BizException('尝试次数过多，请重新获取验证码');
        }

        if (!hash_equals((string) $cached, $code)) {
            RedisCache::set($attemptKey, $attempts + 1, (int) site_config('auth.code_ttl', self::CODE_TTL));
            throw new BizException('验证码不正确');
        }

        RedisCache::del($key);
        RedisCache::del($attemptKey);

        $user = $this->findOrCreateUser($email);
        $token = bin2hex(random_bytes(16));
        RedisCache::set('token:' . $token, (int) $user->id, UserService::TOKEN_TTL);

        return ['token' => $token, 'user' => $user];
    }

    public function findOrCreateUser(string $email): User
    {
        $user = User::where('email', $email)->find();
        if ($user) {
            return $user;
        }

        // user.openid 为 NOT NULL，浏览器用户用固定前缀占位，避免与微信 openid 冲突
        $user = new User();
        $user->openid = 'web_' . substr(sha1($email), 0, 24);
        $user->email = $email;
        $user->nickname = self::nicknameFromEmail($email);
        $user->save();
        $user = User::find($user->id);

        // 注册即发的新人礼只在这里挂：本方法是浏览器端唯一造出新用户的地方。
        // 发券失败不能挡住登录（签发 token 在前台是主流程），MarketingService 内部已把异常
        // 落进 marketing_rule_log 交给 php think marketing:grant 补偿，这里再兜一层。
        try {
            (new MarketingService())->grantOnRegister((int) $user->id);
        } catch (\Throwable $e) {
            Log::error('marketing grant on register failed: user=' . (int) $user->id . ' err=' . $e->getMessage());
        }

        return $user;
    }

    public static function userFromToken(?string $token): ?User
    {
        if (!$token) {
            return null;
        }
        $userId = RedisCache::get('token:' . $token);
        return $userId ? User::find((int) $userId) : null;
    }

    public static function normalizeEmail(string $email): string
    {
        $email = strtolower(trim($email));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new BizException('邮箱格式不正确');
        }
        return $email;
    }

    /**
     * 投递登录验证码邮件（HTML + 纯文本备用正文）
     *
     * 失败只记日志并返回 false（日志不含验证码），由 sendCode() 转成统一的业务错误；
     * 只有真实发送成功时验证码才写入 Redis，避免"发信失败但验证码已存在"的假成功。
     *
     * @param string $email 收件邮箱
     * @param string $code  6 位验证码
     * @return bool 邮件是否实际发出
     */
    private function deliver(string $email, string $code): bool
    {
        $brand      = (string) site_config('brand.name', 'Store');
        $ttlMinutes = (int) ceil((int) site_config('auth.code_ttl', self::CODE_TTL) / 60);
        $contact    = (string) site_config('contact.support', '');
        if ($contact === '') {
            $contact = (string) site_config('contact.email', '');
        }

        $mail = MailTemplate::render('verification_code', [
            'brand'         => $brand,
            'name'          => '',
            'code'          => $code,
            'ttl_minutes'   => $ttlMinutes,
            'contact_email' => $contact,
        ]);

        $mailer = new Mailer();
        $sent   = $mailer->send(
            $email,
            (string) $mail['subject'],
            (string) $mail['html'],
            '',
            true,
            (string) $mail['text']
        );
        if (!$sent) {
            Log::warning('[site-auth] verification mail failed: ' . ($mailer->lastError() ?: 'unknown error'));
        }

        return $sent;
    }

    /**
     * 写入验证码并重置尝试计数
     *
     * @param string $email 收件邮箱
     * @param string $code  验证码
     * @param int    $ttl   有效期（秒）
     * @return void
     */
    private function storeCode(string $email, string $code, int $ttl): void
    {
        RedisCache::del(self::ATTEMPT_PREFIX . md5($email));
        RedisCache::set(self::CODE_PREFIX . md5($email), $code, $ttl);
    }

    private static function nicknameFromEmail(string $email): string
    {
        $local = strstr($email, '@', true) ?: $email;
        return mb_substr($local, 0, 32);
    }
}