<?php
declare(strict_types=1);

namespace app\common\lib;

use think\facade\Log;

/**
 * 发信频率限制（滑动窗口）
 *
 * 背景：免费 Gmail 约 500 封/天且无公开分钟配额，验证码、订单通知、营销通知共用一个通道，
 * 单点被刷会直接吃掉全站额度。这里按「收件邮箱 / 来源 IP / 全站」三个维度同时计数，
 * 任一维度超限即拒绝，避免固定窗口在边界处双倍放量。
 *
 * 实现要点：
 * - 每个维度一个 ZSET，score 用 Redis 服务端 TIME（毫秒），member 带随机后缀（同毫秒多次写入不合并）；
 * - 单个 Lua 脚本原子完成「修剪 24h 前记录 → 逐窗口 ZCOUNT → 全部通过才 ZADD + PEXPIRE」；
 * - 被拒绝时不写入记录（不额外消耗配额），只返回最早解锁的等待秒数；
 * - key 与日志只出现 sha1 前缀，不落明文邮箱 / IP。
 */
class MailRateLimiter
{
    /** 保留时长（秒）：最长窗口即 24 小时 */
    private const RETENTION = 86400;

    /** 维度 => [窗口秒数（长窗口取最大值用于修剪）] */
    private const WINDOWS = [
        'recipient' => [900, 3600, 86400],
        'ip'        => [900, 3600, 86400],
        'global'    => [60, 3600, 86400],
    ];

    /** 配置键 => 默认阈值（<=0 视为使用默认值） */
    private const DEFAULTS = [
        'mail.rate.to_15m'     => 5,
        'mail.rate.to_1h'      => 10,
        'mail.rate.to_24h'     => 20,
        'mail.rate.ip_15m'     => 20,
        'mail.rate.ip_1h'      => 60,
        'mail.rate.ip_24h'     => 150,
        'mail.rate.global_1m'  => 20,
        'mail.rate.global_1h'  => 150,
        'mail.rate.global_24h' => 400,
    ];

    /** 三维同时判定，任一超限即整体拒绝 */
    private const CHECK_LUA = <<<'LUA'
local t = redis.call('TIME')
local now = (tonumber(t[1]) * 1000) + math.floor(tonumber(t[2]) / 1000)
local member = ARGV[1]
local argi = 2
local rejected = false
local retry_ms = 0
local scope = 0

for i = 1, #KEYS do
  local key = KEYS[i]
  local w1 = tonumber(ARGV[argi])
  local l1 = tonumber(ARGV[argi + 1])
  local w2 = tonumber(ARGV[argi + 2])
  local l2 = tonumber(ARGV[argi + 3])
  local w3 = tonumber(ARGV[argi + 4])
  local l3 = tonumber(ARGV[argi + 5])
  argi = argi + 6

  local maxw = math.max(w1, w2, w3)
  redis.call('ZREMRANGEBYSCORE', key, '-inf', now - maxw * 1000)

  local windows = {{w1, l1}, {w2, l2}, {w3, l3}}
  for j = 1, 3 do
    local w = windows[j][1]
    local l = windows[j][2]
    if l > 0 then
      local entries = redis.call('ZRANGEBYSCORE', key, now - w * 1000, '+inf', 'WITHSCORES')
      local count = math.floor(#entries / 2)
      if count >= l then
        -- 需要腾出 (count - l + 1) 条记录才回到上限之下
        local drop = count - l + 1
        local freed_at = tonumber(entries[drop * 2]) + w * 1000
        local wait = freed_at - now
        if wait < 0 then wait = 0 end
        if (not rejected) or wait < retry_ms then
          retry_ms = wait
          scope = i
        end
        rejected = true
      end
    end
  end
end

if rejected then
  return {0, math.max(1, math.ceil(retry_ms / 1000)), scope}
end

for i = 1, #KEYS do
  redis.call('ZADD', KEYS[i], now, member)
  redis.call('PEXPIRE', KEYS[i], tonumber(ARGV[#ARGV]))
end

return {1, 0, 0}
LUA;

    /**
     * 判定一次发信是否放行（放行时立即计入三个维度）
     *
     * @param string      $to          收件邮箱
     * @param string|null $ip          来源 IP（空跳过 IP 维度）
     * @param bool        $skipTarget  true 只检查全站维度（后台测试邮件反复调试 SMTP）
     * @param bool        $skipEnabled true 跳过 mail.enabled 开关（测试邮件在未启用时也要判全站额度）
     * @return array{allowed:bool,retry_after:int,scope:string} retry_after 为最早解锁等待秒数（>=1）
     */
    public function check(string $to, ?string $ip = null, bool $skipTarget = false, bool $skipEnabled = false): array
    {
        // 未启用邮件服务时不占真实发信额度（开发模式只保留 60 秒重发间隔）
        if (!$skipEnabled && !(bool) site_config('mail.enabled', false)) {
            return ['allowed' => true, 'retry_after' => 0, 'scope' => ''];
        }

        $dimensions = [];   // 顺序即 Lua 返回的维度序号（1 起）
        $scopes     = [];   // 维度序号 => scope 名称
        $hashes     = [];   // scope 名称 => 哈希前缀（仅用于日志）

        $recipient = strtolower(trim($to));
        $ip = $ip === null ? '' : trim($ip);
        if ($ip === '0.0.0.0') {
            $ip = '';
        }

        if (!$skipTarget && $recipient !== '') {
            $hash = sha1($recipient);
            $dimensions[] = ['scope' => 'recipient', 'key' => 'mail:rl:to:' . $hash, 'hash' => $hash];
        }
        if (!$skipTarget && $ip !== '') {
            $hash = sha1($ip);
            $dimensions[] = ['scope' => 'ip', 'key' => 'mail:rl:ip:' . $hash, 'hash' => $hash];
        }
        $dimensions[] = ['scope' => 'global', 'key' => 'mail:rl:global', 'hash' => ''];

        $keys = [];
        $args = [bin2hex(random_bytes(8)) . ':' . getmypid()];
        foreach ($dimensions as $index => $dimension) {
            $scope = $dimension['scope'];
            $scopes[$index + 1] = $scope;
            $hashes[$scope]     = $dimension['hash'] === '' ? 'global' : substr($dimension['hash'], 0, 8);
            $keys[] = $dimension['key'];
            foreach (self::WINDOWS[$scope] as $window) {
                $args[] = $window;
                $args[] = $this->limit($scope, $window);
            }
        }
        $args[] = self::RETENTION * 1000;

        try {
            $result = RedisCache::client()->eval(self::CHECK_LUA, count($keys), ...array_merge($keys, $args));
        } catch (\Throwable $e) {
            // Redis 不可用时不额外放大故障：调用方自身还会写 Redis（验证码），失败自会暴露
            Log::warning('[mail-ratelimit] redis unavailable, skip limiting: ' . $e->getMessage());
            return ['allowed' => true, 'retry_after' => 0, 'scope' => ''];
        }

        $allowed = is_array($result) && (int) ($result[0] ?? 0) === 1;
        if ($allowed) {
            return ['allowed' => true, 'retry_after' => 0, 'scope' => ''];
        }

        $retry  = max(1, (int) ($result[1] ?? 1));
        $scope  = $scopes[(int) ($result[2] ?? 0)] ?? 'global';
        Log::warning('[mail-ratelimit] rejected scope=' . $scope . ' hash=' . ($hashes[$scope] ?? '-') . ' retry_after=' . $retry);

        return ['allowed' => false, 'retry_after' => $retry, 'scope' => $scope];
    }

    /**
     * 读取某维度某窗口的阈值：配置缺失或 <=0 时使用默认值
     *
     * @param string $scope  recipient / ip / global
     * @param int    $window 窗口秒数
     * @return int
     */
    private function limit(string $scope, int $window): int
    {
        $suffix = match ($window) {
            60     => '1m',
            900    => '15m',
            3600   => '1h',
            default => '24h',
        };
        $prefix = match ($scope) {
            'recipient' => 'mail.rate.to_',
            'ip'        => 'mail.rate.ip_',
            default     => 'mail.rate.global_',
        };

        $key     = $prefix . $suffix;
        $default = self::DEFAULTS[$key] ?? 0;
        $value   = (int) site_config($key, $default);

        return $value > 0 ? $value : $default;
    }
}
