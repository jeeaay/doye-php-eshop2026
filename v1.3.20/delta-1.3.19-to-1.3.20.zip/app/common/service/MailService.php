<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\exception\BizException;
use app\common\lib\Mailer;
use app\common\lib\MailRateLimiter;
use app\common\lib\SiteAuth;
use think\facade\Log;

/**
 * 邮件服务运维入口（后台「发送测试邮件」）
 *
 * 目的：让超管在启用 `mail.enabled` 之前先验证 SMTP 配置（主机/端口/加密/账号/发件人）是否可用，
 * 并把 `Mailer::lastError()` 的原始失败原因原样带回界面，避免"发不出去也看不出为什么"。
 *
 * 额度口径：只受全站维度约束（`skipTarget=true`），不消耗收件邮箱与 IP 维度，
 * 方便超管反复调试；未启用邮件服务时同样要判全站额度（`skipEnabled=true`）。
 */
class MailService
{
    /**
     * 用已保存的邮件配置发送一封测试邮件
     *
     * 未启用 `mail.enabled` 也允许发送：此时只发这一封测试信，不会解锁验证码等正式邮件。
     *
     * @param string $to 接收测试邮件的邮箱
     * @return array{to:string,enabled:bool} to 为规范化后的邮箱；enabled 为当前 mail.enabled
     * @throws BizException 邮箱非法 / 全站额度用尽 / 发送失败时抛出
     */
    public function sendTest(string $to): array
    {
        $to = SiteAuth::normalizeEmail($to);

        $limited = (new MailRateLimiter())->check($to, null, true, true);
        if (empty($limited['allowed'])) {
            throw new BizException('发送过于频繁，请稍后再试（全站额度）');
        }

        $brand    = (string) site_config('brand.name', 'Store');
        $subject  = $brand . ' 邮件服务测试';
        $body     = $this->testBody($brand);
        $mailer   = new Mailer();

        if (!$mailer->sendTest($to, $subject, $body)) {
            throw new BizException('发送失败：' . ($mailer->lastError() ?: '未知错误'));
        }

        Log::info('[mail] test mail sent to ' . substr(sha1($to), 0, 8));

        return [
            'to'      => $to,
            'enabled' => (bool) site_config('mail.enabled', false),
        ];
    }

    /**
     * 组装测试邮件正文（纯文本）
     *
     * 逐项列出本次发信实际读取的配置值，超管对照界面上的字段即可判断配置是否生效。
     *
     * @param string $brand 品牌名
     * @return string
     */
    private function testBody(string $brand): string
    {
        $provider   = strtolower(trim((string) site_config('mail.provider', 'smtp')));
        $host       = trim((string) site_config('mail.smtp.host', ''));
        $port       = (int) site_config('mail.smtp.port', 0);
        $encryption = strtolower(trim((string) site_config('mail.smtp.encryption', 'none')));
        $from       = trim((string) site_config('mail.from', ''));

        $server = $host === '' ? '（未配置）' : $host . ':' . ($port > 0 ? (string) $port : '默认端口');
        if ($encryption === '') {
            $encryption = 'none';
        }

        return implode("\n", [
            '这是一封来自 ' . $brand . ' 后台的邮件服务测试。',
            '',
            '发送时间：' . date('Y-m-d H:i:s'),
            '发送服务商：' . ($provider === '' ? 'smtp' : $provider),
            'SMTP 服务器：' . $server,
            '加密方式：' . $encryption,
            '发件人：' . ($from === '' ? '（未配置）' : $from),
            '',
            '收到这封邮件说明后台已保存的邮件配置可以正常发信。',
            '若你并未发起测试，请忽略本邮件。',
        ]);
    }
}
