<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\exception\BizException;
use app\common\lib\Mailer;
use app\common\lib\MailRateLimiter;
use app\common\model\SiteMessage;
use think\facade\Log;

/**
 * 留言（联系表单）服务
 *
 * 平台级数据，仅供平台超级管理员使用；覆盖后台列表 / 详情 / 状态 / 删除 / 未读数，
 * 以及新留言落库后的通知邮件。
 * 批量写操作一律按主键 `whereIn('id', ...)`，避免实例写路径带来的范围放大风险。
 */
class MessageService
{
    /**
     * 后台留言列表（分页）
     *
     * 支持按状态（0=未读 / 1=已读）筛选与关键字（命中 name / email / subject / content）检索，
     * 按 create_time 倒序；列表行只下发正文截断摘要，不把全文带到列表页。
     *
     * @param array $filters 支持 keyword / status
     * @param int   $page    页码
     * @param int   $size    每页数量
     * @return array{list:array,pager:\think\Paginator,unread:int}
     */
    public function adminList(array $filters, int $page = 1, int $size = 20): array
    {
        $query = SiteMessage::order('create_time', 'desc')->order('id', 'desc');

        $keyword = trim((string) ($filters['keyword'] ?? ''));
        if ($keyword !== '') {
            $query->where(function ($q) use ($keyword) {
                $q->whereLike('name', '%' . $keyword . '%')
                    ->whereOr('email', 'like', '%' . $keyword . '%')
                    ->whereOr('subject', 'like', '%' . $keyword . '%')
                    ->whereOr('content', 'like', '%' . $keyword . '%');
            });
        }

        $status = $filters['status'] ?? '';
        if ($status !== '' && $status !== null) {
            $query->where('status', (int) $status);
        }

        $pager = $query->paginate([
            'list_rows' => $size,
            'page'      => $page,
            'query'     => ['keyword' => $keyword, 'status' => $status],
        ]);

        $list = [];
        foreach ($pager->items() as $message) {
            $list[] = $this->formatRow($message);
        }

        return [
            'list'   => $list,
            'pager'  => $pager,
            'unread' => $this->unreadCount(),
        ];
    }

    /**
     * 读取留言详情（命中即自动置为已读）
     *
     * @param int $id 留言 ID
     * @return array
     * @throws BizException 留言不存在时抛出
     */
    public function adminDetail(int $id): array
    {
        $message = SiteMessage::find($id);
        if (!$message) {
            throw new BizException('留言不存在');
        }

        // 打开详情即视为已读：按主键显式更新，避免实例写路径
        if ((int) $message->status !== 1) {
            SiteMessage::where('id', $id)->update(['status' => 1]);
            $message->status = 1;
        }

        return [
            'id'           => (int) $message->id,
            'name'         => (string) $message->name,
            'email'        => (string) $message->email,
            'subject'      => (string) ($message->subject ?? ''),
            'content'      => (string) $message->content,
            'ip'           => (string) ($message->ip ?? ''),
            'status'       => (int) $message->status,
            'status_label' => (int) $message->status === 1 ? '已读' : '未读',
            'create_time'  => (string) ($message->create_time ?? ''),
        ];
    }

    /**
     * 批量设置留言状态（已读 / 未读）
     *
     * @param array $ids    留言 ID 列表
     * @param int   $status 目标状态（0=未读，1=已读）
     * @return int 受影响条数
     * @throws BizException ID 列表为空时抛出
     */
    public function setStatus(array $ids, int $status): int
    {
        $ids = $this->normalizeIds($ids);
        if (empty($ids)) {
            throw new BizException('请选择要操作的留言');
        }

        return (int) SiteMessage::whereIn('id', $ids)->update(['status' => $status === 1 ? 1 : 0]);
    }

    /**
     * 批量删除留言
     *
     * @param array $ids 留言 ID 列表
     * @return int 删除条数
     * @throws BizException ID 列表为空时抛出
     */
    public function adminDelete(array $ids): int
    {
        $ids = $this->normalizeIds($ids);
        if (empty($ids)) {
            throw new BizException('请选择要删除的留言');
        }

        return (int) SiteMessage::whereIn('id', $ids)->delete();
    }

    /**
     * 统计未读留言数
     *
     * @return int
     */
    public function unreadCount(): int
    {
        return (int) SiteMessage::where('status', 0)->count();
    }

    /**
     * 发送新留言通知邮件
     *
     * 收件人取 site_config('mail.notify_to')，为空回退 site_config('mail.from')；
     * Mailer 内部已保证失败不抛异常，这里再包一层兜底 try/catch，
     * 任何失败只写日志并返回 false，绝不影响留言落库与接口响应。
     *
     * @param array $message 留言数据（name / email / subject / content / ip）
     * @return bool 发送成功返回 true，否则 false
     */
    public function notify(array $message): bool
    {
        try {
            $to = trim((string) site_config('mail.notify_to', ''));
            if ($to === '') {
                $to = trim((string) site_config('mail.from', ''));
            }
            if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
                Log::info('[message] notify skipped: no valid recipient configured');
                return false;
            }

            $limit = (new MailRateLimiter())->check($to, (string) ($message['ip'] ?? ''));
            if (!$limit['allowed']) {
                Log::warning('[message] notify skipped by rate limit, scope=' . (string) ($limit['scope'] ?? ''));
                return false;
            }

            $subject = trim((string) ($message['subject'] ?? ''));
            $body = "收到一条新的站点留言：\n\n"
                . '姓名：' . (string) ($message['name'] ?? '') . "\n"
                . '邮箱：' . (string) ($message['email'] ?? '') . "\n"
                . '主题：' . ($subject !== '' ? $subject : '（无主题）') . "\n"
                . '正文：' . (string) ($message['content'] ?? '') . "\n"
                . 'IP：' . (string) ($message['ip'] ?? '') . "\n";

            $ok = (new Mailer())->send($to, '【站点留言】' . ($subject !== '' ? $subject : '新留言'), $body);
            if (!$ok) {
                Log::error('[message] notify mail send failed, to=' . $to);
            }

            return $ok;
        } catch (\Throwable $e) {
            Log::error('[message] notify exception: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * 组装列表行（正文只下发截断摘要）
     *
     * @param SiteMessage $message 留言模型
     * @return array
     */
    private function formatRow(SiteMessage $message): array
    {
        $status = (int) $message->status;

        return [
            'id'              => (int) $message->id,
            'name'            => (string) $message->name,
            'email'           => (string) $message->email,
            'subject'         => $this->excerpt((string) ($message->subject ?? ''), 40),
            'content_excerpt' => $this->excerpt((string) $message->content, 60),
            'ip'              => (string) ($message->ip ?? ''),
            'status'          => $status,
            'status_label'    => $status === 1 ? '已读' : '未读',
            'create_time'     => (string) ($message->create_time ?? ''),
        ];
    }

    /**
     * 生成文本摘要（按字符截断，超长追加省略号）
     *
     * @param string $text   原文本
     * @param int    $length 最大保留字符数
     * @return string
     */
    private function excerpt(string $text, int $length): string
    {
        $text = trim($text);
        if (mb_strlen($text) <= $length) {
            return $text;
        }

        return mb_substr($text, 0, $length) . '…';
    }

    /**
     * 归一化 ID 列表（转整、剔除非法值、去重）
     *
     * @param array $ids 原始 ID 列表
     * @return int[]
     */
    private function normalizeIds(array $ids): array
    {
        $ids = array_map('intval', $ids);
        $ids = array_filter($ids, static fn (int $id): bool => $id > 0);

        return array_values(array_unique($ids));
    }
}
