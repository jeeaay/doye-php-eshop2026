<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\enum\PayStatus;
use app\common\lib\DelayQueue;
use app\common\lib\Mailer;
use app\common\lib\MailRateLimiter;
use app\common\lib\MailTemplate;
use app\common\model\OrderPay;
use think\facade\Db;
use think\facade\Log;

/**
 * 订单支付成功邮件（延迟队列消费端）
 *
 * 触发点只有一处：PaymentService::markPaid() 首次把 pay_status 改成 PAID 之后入队，
 * 重复支付回调走早退分支，天然不重发；这里不再做"发过没有"的判重。
 *
 * 三条不变量：
 * 1. 绝不抛异常给队列消费者：任何失败都只记日志并返回 false，否则 delay:consume 会中断；
 * 2. 撞发信限流时按 retry_after 重新入队（最多 3 次），长期撞线才丢弃；
 * 3. 订单/商品用查询构造器读取（模型 scope 与软删除条件可能挡住回调里刚写的行），
 *    金额按 order_pay.charge_currency 格式化，不用展示币种。
 */
class OrderMailService
{
    /** 邮件商品摘要最多行数，其余归入 more_count */
    private const MAX_ITEMS = 8;

    /** 撞限流的最多重排次数 */
    private const MAX_ATTEMPTS = 3;

    /** 重排等待下限 / 上限（秒） */
    private const RETRY_MIN = 30;
    private const RETRY_MAX = 86400;

    /**
     * 发送支付成功邮件
     *
     * @param int    $orderPayId 支付单 ID
     * @param string $baseUrl    站内基础地址（空则回退 site.web_url，再空则不渲染按钮）
     * @param int    $attempt    第几次尝试（撞限流重排时自增，达到上限即丢弃）
     * @return bool 邮件是否真实发出
     */
    public function sendPaid(int $orderPayId, string $baseUrl = '', int $attempt = 0): bool
    {
        try {
            $pay = OrderPay::find($orderPayId);
            if (!$pay) {
                Log::warning('[order-mail] pay not found: pay=' . $orderPayId);
                return false;
            }
            if ((int) $pay->pay_status !== PayStatus::PAID) {
                Log::warning('[order-mail] pay not paid, skip: pay=' . $orderPayId);
                return false;
            }
            if ((int) ($pay->is_test ?? 0) === 1) {
                Log::info('[order-mail] test payment, skip: pay=' . $orderPayId);
                return false;
            }

            $user = $pay->user;
            if (!$user) {
                Log::warning('[order-mail] user missing, skip: pay=' . $orderPayId);
                return false;
            }
            $email = trim((string) ($user->email ?? ''));
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                Log::info('[order-mail] user has no valid email, skip: pay=' . $orderPayId);
                return false;
            }

            $orders = Db::name('order')
                ->where('pay_id', (int) $pay->id)
                ->whereNull('delete_time')
                ->select()
                ->toArray();
            if ($orders === []) {
                Log::warning('[order-mail] no order for pay, skip: pay=' . $orderPayId);
                return false;
            }

            $orderIds = [];
            $orderNos = [];
            foreach ($orders as $order) {
                $orderIds[] = (int) ($order['id'] ?? 0);
                $no = trim((string) ($order['order_no'] ?? ''));
                if ($no !== '' && !in_array($no, $orderNos, true)) {
                    $orderNos[] = $no;
                }
            }

            $items = $orderIds === []
                ? []
                : Db::name('order_item')->whereIn('order_id', $orderIds)->select()->toArray();

            $currency = strtoupper(trim((string) ($pay->charge_currency ?? '')));
            if ($currency === '') {
                $currency = 'USD';
            }
            $symbol = match ($currency) {
                'USD'   => '$',
                'CNY'   => '¥',
                default => $currency . ' ',
            };

            $rows = [];
            foreach ($items as $item) {
                $snap = $item['sku_snapshot_json'] ?? [];
                if (is_string($snap)) {
                    $decoded = json_decode($snap, true);
                    $snap = is_array($decoded) ? $decoded : [];
                }
                if (!is_array($snap)) {
                    $snap = [];
                }
                $rows[] = [
                    'title'  => (string) ($snap['title'] ?? ''),
                    'spec'   => (string) ($snap['spec_name'] ?? ''),
                    'qty'    => (int) ($item['quantity'] ?? 0),
                    'amount' => $symbol . money($item['total_price'] ?? 0),
                ];
            }
            $totalRows = count($rows);
            $moreCount = $totalRows > self::MAX_ITEMS ? $totalRows - self::MAX_ITEMS : 0;
            if ($moreCount > 0) {
                $rows = array_slice($rows, 0, self::MAX_ITEMS);
            }

            $base = trim($baseUrl);
            if ($base === '') {
                $base = trim((string) site_config('site.web_url', ''));
            }
            $base = rtrim($base, '/');
            $link = $base === '' ? '' : $base . '/account/orders';

            $contact = (string) site_config('contact.support', '');
            if ($contact === '') {
                $contact = (string) site_config('contact.email', '');
            }

            // 发信限流：收件邮箱 + 全站两个维度（队列里没有来源 IP）
            $limit = (new MailRateLimiter())->check($email);
            if (empty($limit['allowed'])) {
                $retryAfter = (int) ($limit['retry_after'] ?? 0);
                if ($attempt < self::MAX_ATTEMPTS) {
                    $delay = min(self::RETRY_MAX, max(self::RETRY_MIN, $retryAfter));
                    DelayQueue::delay('order_paid_mail', [
                        'order_pay_id' => $orderPayId,
                        'base_url'     => $baseUrl,
                        'attempt'      => $attempt + 1,
                    ], time() + $delay);
                    Log::warning('[order-mail] rate limited, requeued: pay=' . $orderPayId
                        . ' attempt=' . ($attempt + 1) . ' delay=' . $delay
                        . ' scope=' . (string) ($limit['scope'] ?? ''));
                } else {
                    Log::warning('[order-mail] rate limited, dropped: pay=' . $orderPayId
                        . ' attempt=' . $attempt . ' scope=' . (string) ($limit['scope'] ?? ''));
                }
                return false;
            }

            $mail = MailTemplate::render('order_paid', [
                'brand'         => (string) site_config('brand.name', ''),
                'name'          => (string) ($user->nickname ?? ''),
                'order_nos'     => implode(', ', $orderNos),
                'paid_at'       => (string) ($pay->paid_at ?? ''),
                'total_text'    => $symbol . money($pay->total_amount),
                'items'         => $rows,
                'more_count'    => $moreCount,
                'link'          => $link,
                'contact_email' => $contact,
            ]);

            $mailer = new Mailer();
            $sent = $mailer->send(
                $email,
                (string) ($mail['subject'] ?? ''),
                (string) ($mail['html'] ?? ''),
                '',
                true,
                (string) ($mail['text'] ?? '')
            );
            if (!$sent) {
                Log::warning('[order-mail] send failed: pay=' . $orderPayId
                    . ' err=' . ($mailer->lastError() ?: 'unknown error'));
                return false;
            }

            Log::info('[order-mail] order paid mail sent: pay=' . $orderPayId
                . ' orders=' . count($orderNos));
            return true;
        } catch (\Throwable $e) {
            Log::error('[order-mail] send paid mail failed: pay=' . $orderPayId . ' err=' . $e->getMessage());
            return false;
        }
    }
}
