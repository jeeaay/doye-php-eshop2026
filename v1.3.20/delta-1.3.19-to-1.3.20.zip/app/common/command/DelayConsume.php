<?php

namespace app\common\command;

use app\common\lib\DelayQueue;
use app\common\service\MarketingGrantService;
use app\common\service\OrderMailService;
use app\common\service\OrderService;
use think\console\Command;
use think\console\Input;
use think\console\Output;

class DelayConsume extends Command
{
    protected function configure(): void
    {
        $this->setName('delay:consume')->setDescription('Consume expired delay-queue tasks');
    }

    protected function execute(Input $input, Output $output): void
    {
        $count = 0;
        while ($task = DelayQueue::popExpired()) {
            try {
                $this->dispatch($task);
                $output->writeln('processed: ' . $task['type']);
                $count++;
            } catch (\Throwable $e) {
                $output->writeln('<error>error: ' . $e->getMessage() . '</error>');
            }
        }
        $output->writeln('done, processed ' . $count . ' task(s)');
    }

    protected function dispatch(array $task): void
    {
        $svc = new OrderService();
        switch ($task['type']) {
            case 'order_cancel':
                $svc->cancelUnpaidByPayId((int)($task['payload']['order_pay_id'] ?? 0));
                break;
            case 'order_auto_confirm':
                // 送达满 N 天无人点确认 → 系统代为确认，确认收货返利在这一步触发
                $svc->autoConfirm((int)($task['payload']['order_id'] ?? 0));
                break;
            case 'marketing_grant_run':
                // 批量发券推进一步；未完成时 run() 自己续排下一批
                (new MarketingGrantService())->run((int)($task['payload']['id'] ?? 0));
                break;
            case 'marketing_notify':
                // 事务性通知（到账/到期/退回）；邮件失败只记日志，不抛
                (new MarketingGrantService())->sendNotify((int)($task['payload']['id'] ?? 0));
                break;
            case 'order_paid_mail':
                // 支付成功邮件；撞发信限流时自己在 sendPaid() 里按 retry_after 重排
                (new OrderMailService())->sendPaid(
                    (int)($task['payload']['order_pay_id'] ?? 0),
                    (string)($task['payload']['base_url'] ?? ''),
                    (int)($task['payload']['attempt'] ?? 0)
                );
                break;
            default:
                throw new \RuntimeException('unknown task type: ' . $task['type']);
        }
    }
}
