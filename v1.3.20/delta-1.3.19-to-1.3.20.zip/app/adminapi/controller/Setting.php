<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\service\MailService;
use app\common\service\SettingService;

/**
 * 管理 API：系统设置
 *
 * 仅平台超管可用。
 */
class Setting extends ApiBaseController
{
    /**
     * GET /admin-api/v1/settings
     *
     * 敏感字段只返回 has_value，不回显已保存的值。
     *
     * @return \think\response\Json
     */
    public function index()
    {
        return $this->run(function () {
            $this->assertSuper();
            return ['groups' => (new SettingService())->groupList()];
        });
    }

    /**
     * POST /admin-api/v1/settings/:group
     *
     * 支持两种请求体：
     * - {"values": {"brand.name": "Almi"}}
     * - {"brand.name": "Almi"}
     *
     * @return \think\response\Json
     */
    public function save()
    {
        return $this->run(function () {
            $this->assertSuper();
            $group = (string) $this->request->param('group', '');
            $input = $this->input();
            $values = isset($input['values']) && is_array($input['values']) ? $input['values'] : $input;
            unset($values['group']);

            (new SettingService())->save($group, $values);
            return null;
        }, '设置已保存');
    }

    /**
     * POST /admin-api/v1/mail/test
     *
     * 用已保存的邮件配置发送一封测试邮件；兼容 body 里的 `to` 与 `email` 两种写法。
     * 未启用「邮件发送」也可测试，只占全站发信额度。
     *
     * @return \think\response\Json
     */
    public function testMail()
    {
        return $this->run(function () {
            $this->assertSuper();
            $to = (string) ($this->request->param('to', $this->request->param('email', '')));

            return (new MailService())->sendTest($to);
        }, '测试邮件已发送');
    }
}
