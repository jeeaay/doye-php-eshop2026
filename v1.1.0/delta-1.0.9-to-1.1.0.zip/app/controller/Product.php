<?php
declare(strict_types=1);

namespace app\controller;

/**
 * 商品列表 / 详情（eshop2026 主题）
 *
 * 迁移自 Go 站点：/products、/products/:slug
 * PHP 后台商品没有 slug / custom_route，路由使用 /products/:id（见 todo.md）
 */
class Product extends SiteBase
{
    public function list()
    {
        $categoryId = (int) $this->request->get('category_id', 0);
        $keyword = trim((string) $this->request->get('keyword', ''));
        $sort = (string) $this->request->get('sort', 'newest');
        if (!in_array($sort, ['newest', 'price-asc', 'price-desc', 'popular'], true)) {
            $sort = 'newest';
        }

        $brand = $this->store->brand();
        $result = $this->store->productCards(1, 120, $categoryId, $keyword, $sort);

        return $this->render('products', [
            'nav_active'      => 'products',
            'page_title'      => 'Products - ' . $brand['name'],
            'meta_desc'       => 'Browse our full range of home storage and organisation solutions.',
            'products'        => $result['list'],
            'total'           => $result['total'],
            'sort'            => $sort,
            'page_size'       => (int) site_config('per_page', 24),
            'categories'      => $this->store->categories(),
            'active_category' => $categoryId,
        ]);
    }

    public function detail($id = 0)
    {
        $product = $this->store->product((int) $id);
        if (!$product) {
            return $this->notFound('Product not found');
        }

        $seoTitle = trim((string) ($product['seo_title'] ?? ''));
        $seoDescription = trim((string) ($product['seo_description'] ?? ''));
        if ($seoDescription === '') {
            $seoDescription = $product['brief'] !== ''
                ? $product['brief']
                : mb_substr(trim(strip_tags((string) $product['description'])), 0, 160);
        }
        $seoKeywords = trim((string) ($product['seo_keywords'] ?? ''));
        if ($seoKeywords === '') {
            $seoKeywords = implode(',', (array) ($product['tags'] ?? []));
        }

        // 页面标题：商品名称 - 副标题 - SEO 标题；缺失的部分自动省略
        $titleParts = array_filter([
            trim((string) ($product['name'] ?? '')),
            trim((string) ($product['brief'] ?? '')),
            $seoTitle,
        ], static fn (string $part): bool => $part !== '');
        $json = json_encode([
            'id'        => $product['id'],
            'name'      => $product['name'],
            'price'     => $product['price'],
            'image'     => $product['image'],
            'url'       => $product['url'],
            'brief'     => $product['brief'],
            'has_stock' => $product['has_stock'],
            'skus'      => array_map(static fn ($s) => [
                'id'        => $s['id'],
                'spec_name' => $s['spec_name'],
                'price'     => $s['price'],
                'stock'     => $s['stock'],
            ], $product['skus']),
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        return $this->render('product', [
            'nav_active'   => 'products',
            'page_title'   => implode(' - ', $titleParts),
            'meta_desc'    => $seoDescription,
            'meta_keys'    => $seoKeywords,
            'meta_robots'  => (int) ($product['seo_noindex'] ?? 0) === 1 ? 'noindex,follow' : '',
            'product'      => $product,
            'product_json' => htmlspecialchars((string) $json, ENT_QUOTES, 'UTF-8'),
        ]);
    }
}