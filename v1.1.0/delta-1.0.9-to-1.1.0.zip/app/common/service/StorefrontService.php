<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\model\Category;
use app\common\model\Product;

/**
 * 前台站点数据组装
 *
 * 把 PHP 后台的数据结构（Product / ProductSku / HomeOps / Category）
 * 转换成原 Go 站点模板需要的字段，尽量保持模板层无需改动：
 *   Name / Price / Images[].Full / Images[].Thumb / Brief / Description / URL / SeoDesc ...
 */
class StorefrontService
{
    /** 排序方式 -> order 片段 */
    private const SORTS = [
        'newest'     => ['sort' => 'desc', 'id' => 'desc'],
        'price-asc'  => ['price' => 'asc'],
        'price-desc' => ['price' => 'desc'],
        'popular'    => ['sort' => 'desc', 'id' => 'desc'],
    ];

    public function brand(): array
    {
        $brand = (array) site_config('brand', []);
        $currency = display_currency();
        return [
            'name'     => (string) ($brand['name'] ?? 'Store'),
            'suffix'   => (string) ($brand['suffix'] ?? ''),
            'logo'     => (string) ($brand['logo_text'] ?? ($brand['name'] ?? 'Store')),
            'tagline'  => (string) ($brand['tagline'] ?? ''),
            'currency' => (string) ($currency['symbol'] ?? '$'),
            'code'     => (string) ($currency['code'] ?? 'USD'),
        ];
    }

    /**
     * 顶部导航（与原 Go 主题一致）
     */
    public function nav(): array
    {
        return [
            ['key' => 'home',     'label' => site_lang('nav.home'),     'url' => localized_url('/')],
            ['key' => 'products', 'label' => site_lang('nav.products'), 'url' => localized_url('/products')],
            ['key' => 'service',  'label' => site_lang('nav.service'),  'url' => localized_url('/service')],
            ['key' => 'about',    'label' => site_lang('nav.about'),    'url' => localized_url('/about')],
            ['key' => 'contact',  'label' => site_lang('nav.contact'),  'url' => localized_url('/contact')],
        ];
    }

    public function footerNav(): array
    {
        return [
            'company'  => [
                ['label' => site_lang('footer.about'), 'url' => localized_url('/about')],
                ['label' => site_lang('footer.products'), 'url' => localized_url('/products')],
                ['label' => site_lang('footer.contact'), 'url' => localized_url('/contact')],
            ],
            'policies' => [
                ['label' => site_lang('footer.shipping'), 'url' => localized_url('/shipping')],
                ['label' => site_lang('footer.returns'), 'url' => localized_url('/returns')],
                ['label' => site_lang('footer.terms'), 'url' => localized_url('/terms')],
            ],
            'privacy'  => [
                ['label' => site_lang('footer.privacy'), 'url' => localized_url('/privacy')],
                ['label' => site_lang('footer.cookies'), 'url' => localized_url('/cookies')],
            ],
        ];
    }

    /**
     * 分类（一级 + 子级，带在售商品数）
     */
    public function categories(): array
    {
        $rows = Category::order('sort', 'asc')->order('id', 'asc')->select();
        $counts = [];
        foreach (
            Product::where('status', 1)->whereNull('delete_time')
                ->field('category_id, COUNT(*) AS cnt')->group('category_id')->select() as $row
        ) {
            $counts[(int) $row->category_id] = (int) $row->cnt;
        }

        $translations = (new TranslationService())->categoryMap(array_map(
            static fn ($row) => (int) $row->id,
            $rows->all()
        ));
        $nameOf = static function ($row) use ($translations): string {
            $translated = trim((string) ($translations[(int) $row->id]['name'] ?? ''));
            return $translated !== '' ? $translated : (string) $row->name;
        };

        $childrenOf = [];
        foreach ($rows as $row) {
            $childrenOf[(int) $row->parent_id][] = $row;
        }

        $tree = [];
        foreach ($childrenOf[0] ?? [] as $parent) {
            $children = [];
            $total = $counts[(int) $parent->id] ?? 0;
            foreach ($childrenOf[(int) $parent->id] ?? [] as $child) {
                $cnt = $counts[(int) $child->id] ?? 0;
                $total += $cnt;
                $children[] = ['id' => (int) $child->id, 'name' => $nameOf($child), 'count' => $cnt];
            }
            $tree[] = [
                'id'       => (int) $parent->id,
                'name'     => $nameOf($parent),
                'count'    => $total,
                'children' => $children,
            ];
        }
        return $tree;
    }

    /**
     * 首个在售商品的 URL（原 Go 主题用 FirstProductSlug 做 CTA 链接）
     */
    public function firstProductUrl(): string
    {
        $first = Product::where('status', 1)->whereNull('delete_time')->order('sort', 'desc')->order('id', 'asc')->find();
        return $first ? localized_url(storefront_product_url($first->id)) : localized_url('/products');
    }

    /**
     * 商品列表
     *
     * @return array{list: array, total: int, page: int, size: int, hasMore: bool}
     */
    public function productCards(int $page = 1, int $size = 12, int $categoryId = 0, string $keyword = '', string $sort = 'newest'): array
    {
        $query = Product::with([
            'skus',
            'translations' => fn ($q) => $q->where('lang_code', $this->locale())->where('status', 1),
        ])->where('status', 1)->whereNull('delete_time');

        if ($categoryId > 0) {
            $ids = [$categoryId];
            foreach (Category::where('parent_id', $categoryId)->column('id') as $childId) {
                $ids[] = (int) $childId;
            }
            $query->whereIn('category_id', $ids);
        }
        if ($keyword !== '') {
            $like = '%' . $keyword . '%';
            $query->where(function ($q) use ($like) {
                $q->whereLike('title', $like)->whereOr('subtitle', 'like', $like);
            });
        }

        $order = self::SORTS[$sort] ?? self::SORTS['newest'];
        if (isset($order['price'])) {
            // 以最低 SKU 价格排序：PHP 后台价格在 SKU 上，这里用子查询排序
            $query->orderRaw(
                '(SELECT MIN(price) FROM product_sku WHERE product_sku.product_id = product.id) ' .
                ($order['price'] === 'asc' ? 'ASC' : 'DESC')
            );
        } else {
            $query->order('sort', $order['sort'])->order('id', $order['id']);
        }

        $pager = $query->paginate(['list_rows' => $size, 'page' => $page]);

        $list = [];
        foreach ($pager->items() as $product) {
            $list[] = $this->card($product, $this->translationOf($product));
        }

        return [
            'list'    => $list,
            'total'   => (int) $pager->total(),
            'page'    => (int) $pager->currentPage(),
            'size'    => (int) $pager->listRows(),
            'hasMore' => (bool) $pager->hasMore(),
        ];
    }

    /**
     * 商品详情（前台展示结构）
     */
    public function product(int $id): ?array
    {
        $product = Product::with([
            'skus',
            'merchant',
            'category',
            'translations' => fn ($q) => $q->where('lang_code', $this->locale())->where('status', 1),
        ])->where('status', 1)->find($id);
        if (!$product) {
            return null;
        }

        $translation = $this->translationOf($product);
        $card = $this->card($product, $translation);

        $baseSpecs = $this->baseSpecs($product);
        $translatedSpecs = (array) ($translation['specs_json'] ?? []);
        $specs = (new TranslationService())->mergeSpecs($baseSpecs, $translatedSpecs);
        $valueMap = (new TranslationService())->valueMap($baseSpecs, $translatedSpecs);

        $categoryName = $product->category ? (string) $product->category->name : '';
        if ($product->category) {
            $categoryTranslation = (new TranslationService())->categoryMap([(int) $product->category->id]);
            $translatedName = trim((string) ($categoryTranslation[(int) $product->category->id]['name'] ?? ''));
            if ($translatedName !== '') {
                $categoryName = $translatedName;
            }
        }

        $skus = [];
        foreach ($product->skus as $sku) {
            if ((int) $sku->status !== 1) {
                continue;
            }
            $values = (new TranslationService())->translateSkuValues(
                (array) $sku->spec_values_json,
                $valueMap
            );
            $skus[] = [
                'id'        => (int) $sku->id,
                'spec_name' => implode(' / ', array_values($values)) ?: (string) $sku->spec_name,
                'price'     => money($sku->price),
                'stock'     => (int) $sku->stock,
                'code'      => (string) ($sku->sku_code ?? ''),
                'values'    => $values,
            ];
        }

        return array_merge($card, [
            'description' => (string) ($translation['detail_html'] ?? $product->detail_html ?? ''),
            'category'    => $categoryName,
            'category_id' => (int) $product->category_id,
            'merchant'    => $product->merchant ? (string) $product->merchant->name : '',
            'skus'        => $skus,
            'specs'       => $specs,
            'has_stock'   => (bool) array_filter($skus, static fn ($s) => $s['stock'] > 0),
            'seo_title'   => $this->seoValue($product, $translation, 'seo_title'),
            'seo_description' => $this->seoValue($product, $translation, 'seo_description'),
            'seo_keywords'    => (string) ($product->seo_keywords ?? ''),
            'tags'            => array_values(array_map('strval', (array) ($product->tags_json ?? []))),
            'published_at'    => $product->published_at ? (string) $product->published_at : '',
            'seo_noindex'     => (int) ($product->seo_noindex ?? 0),
        ]);
    }

    /**
     * 取 SEO 字段：当前语种译文优先，其次基准语种主表
     *
     * @param Product $product 商品
     * @param array<string,mixed>|null $translation 当前语种译文
     * @param string $field 字段名
     * @return string
     */
    private function seoValue(Product $product, ?array $translation, string $field): string
    {
        $value = trim((string) ($translation[$field] ?? ''));
        if ($value !== '') {
            return $value;
        }
        return trim((string) ($product->{$field} ?? ''));
    }

    /**
     * 首页运营位（复用后台 HomeOpsService 的聚合结果）
     */
    public function homeOps(): array
    {
        $ops = (new HomeOpsService())->aggregate();

        $ids = array_map(static fn ($row) => (int) $row['id'], (array) ($ops['categories'] ?? []));
        $translations = (new TranslationService())->categoryMap($ids);
        foreach ($ops['categories'] as &$category) {
            $translated = trim((string) ($translations[(int) $category['id']]['name'] ?? ''));
            if ($translated !== '') {
                $category['name'] = $translated;
            }
        }
        unset($category);

        return $ops;
    }

    // ------------------------------------------------------------------

    /**
     * 列表卡片结构
     */
    private function card(Product $product, ?array $translation = null): array
    {
        $prices = [];
        foreach ($product->skus as $sku) {
            if ((int) $sku->status === 1) {
                $prices[] = (float) $sku->price;
            }
        }
        $min = $prices ? min($prices) : 0.0;
        $max = $prices ? max($prices) : 0.0;

        $images = $this->images($product);

        $name = trim((string) ($translation['title'] ?? ''));
        $brief = trim((string) ($translation['subtitle'] ?? ''));

        return [
            'id'         => (int) $product->id,
            'url'        => localized_url(storefront_product_url($product->id)),
            'name'       => $name !== '' ? $name : (string) $product->title,
            'brief'      => $brief !== '' ? $brief : (string) ($product->subtitle ?? ''),
            'price'      => money($min),
            'price_max'  => money($max),
            'has_range'  => $max > $min,
            'images'     => $images,
            'image'      => $images[0]['thumb'] ?? '',
            'sku_count'  => count($prices),
            'created_at' => (string) ($product->create_time ?? ''),
        ];
    }

    /**
     * 商品图片：main_image + images_json（PHP 后台只存原图，没有缩略图）
     */
    private function images(Product $product): array
    {
        $urls = [];
        if (!empty($product->main_image)) {
            $urls[] = (string) $product->main_image;
        }
        $extra = $product->images_json;
        $extra = is_array($extra) ? $extra : (array) json_decode((string) $extra, true);
        foreach ($extra as $url) {
            $url = is_string($url) ? trim($url) : '';
            if ($url !== '' && !in_array($url, $urls, true)) {
                $urls[] = $url;
            }
        }

        $images = [];
        foreach ($urls as $url) {
            $images[] = [
                'full'  => $url,
                'thumb' => $url, // PHP 后台无缩略图，见 todo.md
            ];
        }
        return $images;
    }

    /**
     * 规格维度：优先 specs_json，其次由 SKU 的 spec_values_json 反推（英文基准）
     */
    private function baseSpecs(Product $product): array
    {
        $specs = [];
        $raw = $product->specs_json;
        $raw = is_array($raw) ? $raw : (array) json_decode((string) $raw, true);
        foreach ($raw as $spec) {
            $name = trim((string) ($spec['name'] ?? ''));
            $values = [];
            foreach ((array) ($spec['values'] ?? []) as $value) {
                $value = trim((string) $value);
                if ($value !== '' && !in_array($value, $values, true)) {
                    $values[] = $value;
                }
            }
            if ($name !== '' && $values) {
                $specs[] = ['name' => $name, 'values' => $values];
            }
        }
        if ($specs) {
            return $specs;
        }

        $legacy = [];
        foreach ($product->skus as $sku) {
            foreach ((array) $sku->spec_values_json as $name => $value) {
                $legacy[(string) $name][(string) $value] = true;
            }
        }
        foreach ($legacy as $name => $values) {
            $specs[] = ['name' => (string) $name, 'values' => array_map('strval', array_keys($values))];
        }
        return $specs;
    }

    /**
     * 当前语种
     */
    private function locale(): string
    {
        return (new TranslationService())->locale();
    }

    /**
     * 取预加载的翻译行（数组）
     *
     * @return array<string,mixed>|null
     */
    private function translationOf(Product $product): ?array
    {
        $translation = $product->translations ?? null;
        if ($translation instanceof \think\Collection) {
            $translation = $translation->first();
        }
        if (is_object($translation)) {
            $translation = $translation->toArray();
        }
        return is_array($translation) ? $translation : null;
    }
}