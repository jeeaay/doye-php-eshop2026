<?php
use think\migration\Migrator;

/**
 * 商品增加 SEO / 标签 / 发布时间字段
 *
 * - seo_title / seo_description / seo_keywords：基准语种的 SEO 信息
 * - tags_json：商品标签数组，前台可作为关键词兜底
 * - published_at：发布时间，留空表示使用创建时间
 * - seo_noindex：1 表示禁止搜索引擎索引（同时从 sitemap 排除）
 */
class AddProductSeoFields extends Migrator
{
    /**
     * @return void
     */
    public function change()
    {
        $this->table('product')
            ->addColumn('seo_title', 'string', [
                'limit'   => 255,
                'null'    => true,
                'comment' => 'SEO 标题，留空回退商品名称',
            ])
            ->addColumn('seo_description', 'string', [
                'limit'   => 512,
                'null'    => true,
                'comment' => 'SEO 描述，留空回退副标题/详情摘要',
            ])
            ->addColumn('seo_keywords', 'string', [
                'limit'   => 255,
                'null'    => true,
                'comment' => 'SEO 关键词，英文逗号分隔',
            ])
            ->addColumn('tags_json', 'json', [
                'null'    => true,
                'comment' => '商品标签数组',
            ])
            ->addColumn('published_at', 'datetime', [
                'null'    => true,
                'comment' => '发布时间，留空表示使用创建时间',
            ])
            ->addColumn('seo_noindex', 'tinyinteger', [
                'limit'   => 1,
                'default' => 0,
                'comment' => '1=禁止搜索引擎索引',
            ])
            ->addIndex(['published_at'])
            ->update();
    }
}