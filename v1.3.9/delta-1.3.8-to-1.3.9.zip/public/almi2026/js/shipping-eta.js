/*
 * 商品详情页「配送至」默认地址推断
 *
 * 服务端已按 ?ship_to / ship_to cookie / 站点默认国家渲染首屏；
 * 这里只在「用户没有显式选择过（无 ship_to cookie）」且已登录时，
 * 用默认收货地址的 country 校正选择器与时效文案。
 *
 * 只改 DOM，不写 cookie（地址变更后仍能自动跟随）。
 * 任何异常（未登录 / 401 / 网络失败 / JSON 解析失败）静默降级，保持服务端结果。
 */
(function () {
  'use strict';

  var COOKIE_NAME = 'ship_to';

  /** cookie 里是否已有显式选择 */
  function hasShipToCookie() {
    var pairs = String(document.cookie || '').split(';');
    for (var i = 0; i < pairs.length; i++) {
      var pair = pairs[i];
      var eq = pair.indexOf('=');
      var name = (eq === -1 ? pair : pair.slice(0, eq)).replace(/^\s+|\s+$/g, '');
      if (name === COOKIE_NAME) { return true; }
    }
    return false;
  }

  /** data-* 上的 JSON，解析失败返回 null */
  function readJSON(text) {
    if (!text) { return null; }
    try {
      var value = JSON.parse(text);
      return value && typeof value === 'object' ? value : null;
    } catch (e) {
      return null;
    }
  }

  /** 默认地址（无默认标记时取第一条） */
  function pickAddress(list) {
    if (!list || typeof list.length !== 'number' || !list.length) { return null; }
    for (var i = 0; i < list.length; i++) {
      if (list[i] && Number(list[i].is_default) === 1) { return list[i]; }
    }
    return list[0];
  }

  /** 与 select 选项对齐（该 option 不存在时保持原值） */
  function syncSelect(select, country) {
    if (!select || !country) { return; }
    var options = select.options || [];
    for (var i = 0; i < options.length; i++) {
      if (String(options[i].value) === String(country)) {
        select.value = country;
        return;
      }
    }
  }

  function apply(box, address) {
    var country = address && address.country ? String(address.country).toUpperCase() : '';
    // 地址没有国家：保持服务端（站点默认国家）结果
    if (!country) { return; }

    // 服务端已按「本商品仓库 × 国家」生成文案映射，这里只查表，不重算规则
    var texts = readJSON(box.getAttribute('data-eta-by-country')) || {};
    var text = Object.prototype.hasOwnProperty.call(texts, country) ? String(texts[country]) : '';
    if (!text) { return; }

    var eta = box.querySelector('.product-eta');
    if (eta) { eta.textContent = text; }
    // 未知国家没有对应选项时，syncSelect 保持原选中值
    syncSelect(box.querySelector('select[name="ship_to"]'), country);
  }

  function init() {
    var box = document.querySelector('.product-delivery-info');
    if (!box || !box.getAttribute('data-eta-by-country')) { return; }
    if (hasShipToCookie()) { return; }
    if (!window.StoreAuth || !window.StoreAuth.isLoggedIn()) { return; }
    if (!window.StoreAddress || typeof window.StoreAddress.list !== 'function') { return; }

    try {
      Promise.resolve(window.StoreAddress.list()).then(function (list) {
        try {
          var address = pickAddress(list);
          if (address) { apply(box, address); }
        } catch (e) { /* 静默：保持服务端渲染结果 */ }
      }, function () { /* 静默：接口失败不影响页面 */ });
    } catch (e) { /* 静默 */ }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
