/*
 * 购物车页面渲染（cart.html / checkout.html 共用）
 *
 * 数据源：GET /api/cart/list -> { groups: [{ merchant, items: [...] }] }
 * PHP 后台购物车是「用户 + SKU」模型，条目 id 为 cart_item.id，数量修改用 /api/cart/update。
 */
var CartPage = (function () {
  var state = {
    groups: [],
    items: [],
    scope: null,
    loading: true,
    minPayable: 0
  };

  function currency() { return StoreAPI.currency(); }

  function money(value) {
    return currency() + (parseFloat(value || 0)).toFixed(2);
  }

  function isGuestId(id) {
    return String(id).indexOf('g:') === 0;
  }

  function host() {
    return document.querySelector('.cart-items-list') || document.getElementById('cart-items');
  }

  function subtotal() {
    return state.items.reduce(function (sum, item) {
      // 游客车下架/失效条目不计入金额
      if (item.available === false) { return sum; }
      return sum + (item.selected ? parseFloat(item.price) * item.quantity : 0);
    }, 0);
  }

  function renderItems() {
    var el = host();
    if (!el) { return; }
    // 先按条目数切换空态/列表显隐，空车时下面会提前 return
    updateTotals();
    if (!state.items.length) {
      el.innerHTML = '<p class="cart-empty-hint">Your basket is empty. '
        + '<a href="/products">Continue shopping</a></p>';
      return;
    }

    el.innerHTML = state.items.map(function (item) {
      var unavailable = item.available === false;
      return ''
        + '<div class="cart-item' + (unavailable ? ' cart-item--unavailable' : '') + '" data-id="' + item.id + '">'
        + '  <div class="cart-item__media">'
        + (item.main_image ? '<img src="' + item.main_image + '" alt="">' : '')
        + '  </div>'
        + '  <div class="cart-item__body">'
        + '    <p class="cart-item__title">' + escapeHtml(item.product_title || 'Unavailable item') + '</p>'
        + '    <p class="cart-item__spec">' + escapeHtml(unavailable ? 'No longer available' : (item.spec_name || '')) + '</p>'
        + '  </div>'
        + '  <div class="cart-item__qty">'
        + '    <button type="button" class="qty-btn" data-action="dec" aria-label="Decrease">&minus;</button>'
        + '    <input type="number" class="qty-input" value="' + item.quantity + '" min="1">'
        + '    <button type="button" class="qty-btn" data-action="inc" aria-label="Increase">+</button>'
        + '  </div>'
        + '  <div class="cart-item__price">' + money(parseFloat(item.price) * item.quantity) + '</div>'
        + '  <button type="button" class="btn-link cart-item__remove" data-action="remove">Remove</button>'
        + '</div>';
    }).join('');

    bindItems(el);
    updateTotals();
  }

  function bindItems(el) {
    el.querySelectorAll('.cart-item').forEach(function (row) {
      var id = row.dataset.id;
      var input = row.querySelector('.qty-input');

      row.querySelector('[data-action="dec"]').addEventListener('click', function () {
        var item = find(id);
        if (item && item.quantity > 1) { updateQty(id, item.quantity - 1); }
      });
      row.querySelector('[data-action="inc"]').addEventListener('click', function () {
        var item = find(id);
        if (item) { updateQty(id, item.quantity + 1); }
      });
      input.addEventListener('change', function () {
        var qty = Math.max(1, parseInt(input.value, 10) || 1);
        updateQty(id, qty);
      });
      row.querySelector('[data-action="remove"]').addEventListener('click', function () {
        remove(id);
      });
    });
  }

  function find(id) {
    return state.items.find(function (i) { return String(i.id) === String(id); });
  }

  async function updateQty(id, quantity) {
    var item = find(id);
    if (isGuestId(id)) {
      if (item && item.stock && quantity > item.stock) {
        StoreUI.toast('Only ' + item.stock + ' available', 'error');
        renderItems();
        return;
      }
      StoreCart.updateLocal(String(id).slice(2), quantity);
      if (item) { item.quantity = quantity; }
      renderItems();
      return;
    }
    try {
      await StoreCart.update(id, { quantity: quantity });
      if (item) { item.quantity = quantity; }
      renderItems();
    } catch (e) {
      StoreUI.toast(e.message, 'error');
    }
  }

  async function remove(id) {
    if (isGuestId(id)) {
      StoreCart.removeLocal(String(id).slice(2));
      state.items = state.items.filter(function (i) { return String(i.id) !== String(id); });
      renderItems();
      return;
    }
    try {
      await StoreCart.remove([id]);
      state.items = state.items.filter(function (i) { return String(i.id) !== String(id); });
      renderItems();
    } catch (e) {
      StoreUI.toast(e.message, 'error');
    }
  }

  var quoteToken = 0;
  var currentDiscount = 0;
  var currentMin = 0;
  var currentMinMet = true;
  var currentMinShortfall = 0;

  /**
   * 试算优惠：与结算页共用 /api/coupon/quote（同一接口同一参数），
   * 前端只展示服务端结果，不做任何金额推断。
   */
  async function refreshDiscount() {
    if (!StoreAuth.isLoggedIn()) {
      var guestMin = state.minPayable;
      var guestData = { min_payable: guestMin };
      // 游客没有个人券，只用商品小计做保守判断；平台自动折扣由结算页 quote 再校验
      if (guestMin > 0 && subtotal() < guestMin) {
        guestData.min_payable_met = false;
        guestData.min_payable_shortfall = (guestMin - subtotal()).toFixed(2);
      }
      applyDiscount(0, guestData);
      return;
    }
    if (!state.items.length) {
      applyDiscount(0);
      return;
    }
    var items = state.items
      .filter(function (i) { return i.selected; })
      .map(function (i) { return { sku_id: i.sku_id, quantity: i.quantity }; });
    if (!items.length) {
      applyDiscount(0);
      return;
    }
    var token = ++quoteToken;
    try {
      var data = await StoreAPI.post('/api/coupon/quote', { items: items });
      if (token !== quoteToken) { return; }
      applyDiscount(parseFloat((data && data.discount) || 0), data);
    } catch (e) {
      if (token === quoteToken) { applyDiscount(0); }
    }
  }

  function applyDiscount(discount, data) {
    currentDiscount = discount > 0 ? discount : 0;
    currentMin = data ? parseFloat(data.min_payable || 0) || 0 : 0;
    currentMinMet = !(data && data.min_payable_met === false);
    currentMinShortfall = data ? parseFloat(data.min_payable_shortfall || 0) || 0 : 0;
    var row = document.getElementById('discount-coupon-row');
    var amount = document.getElementById('discount-coupon-amount');
    if (row && amount) {
      row.style.display = currentDiscount > 0 ? 'flex' : 'none';
      amount.textContent = '-' + money(currentDiscount);
    }
    renderTotals();
  }

  function renderTotals() {
    var goods = subtotal();
    var payable = Math.max(0, goods - currentDiscount);
    var sub = document.getElementById('cart-subtotal');
    if (sub) { sub.textContent = money(goods); }
    ['cart-total', 'cart-payable'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) { el.textContent = money(payable); }
    });

    var minRow = document.getElementById('min-payable-row');
    var minValue = document.getElementById('min-payable-value');
    if (minRow && minValue) {
      if (currentMin > 0) {
        minRow.style.display = 'flex';
        minValue.textContent = currentMinMet
          ? money(currentMin) + ' after discounts'
          : 'Add ' + money(currentMinShortfall) + ' more to checkout';
        minValue.classList.toggle('is-warning', !currentMinMet);
      } else {
        minRow.style.display = 'none';
      }
    }

    var checkoutBtn = document.getElementById('cart-checkout-btn');
    if (checkoutBtn) {
      checkoutBtn.classList.toggle('is-disabled', currentMin > 0 && !currentMinMet);
      checkoutBtn.onclick = function (event) {
        if (currentMin > 0 && !currentMinMet) {
          event.preventDefault();
          StoreUI.toast('Add ' + money(currentMinShortfall) + ' more to checkout', 'error');
          return;
        }
        window.location.href = '/checkout';
      };
    }
  }

  function updateTotals() {
    renderTotals();

    var empty = document.querySelector('.empty-cart');
    var layout = document.querySelector('.cart-layout');
    if (empty && layout) {
      var isEmpty = state.items.length === 0;
      empty.style.display = isEmpty ? '' : 'none';
      layout.style.display = isEmpty ? 'none' : '';
    }

    refreshDiscount();
  }

  function escapeHtml(str) {
    return String(str || '').replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  async function load() {
    state.loading = true;
    try {
      if (!StoreAuth.isLoggedIn()) {
        // 游客车：本地 sku_id/quantity + 服务端 preview 展示数据
        var guest = await StoreCart.guestDisplayItems();
        state.groups = [];
        state.items = guest.items || [];
        state.minPayable = parseFloat(guest.min_payable || 0) || 0;
      } else {
        var data = await StoreCart.list();
        state.minPayable = parseFloat((data && data.min_payable) || 0) || 0;
        state.groups = (data && data.groups) || [];
        state.items = [];
        state.groups.forEach(function (group) {
          (group.items || []).forEach(function (item) {
            state.items.push({
              id: item.id,
              sku_id: item.sku_id,
              product_title: item.product_title,
              spec_name: item.spec_name,
              price: item.price,
              quantity: parseInt(item.quantity, 10) || 1,
              main_image: item.main_image,
              stock: item.stock,
              selected: !!Number(item.selected)
            });
          });
        });
      }
    } catch (e) {
      /* 接口不可用时静默展示空购物车 */
      state.items = [];
    } finally {
      state.loading = false;
      renderItems();
      StoreCart.notify();
    }
  }

  return {
    mount: function (scope) {
      state.scope = scope;
      load();
    },
    reload: load,
    selectedItems: function () {
      return state.items
        .filter(function (i) { return i.selected; })
        .map(function (i) { return { sku_id: i.sku_id, quantity: i.quantity }; });
    },
    items: function () { return state.items; }
  };
})();

window.CartPage = CartPage;

document.addEventListener('DOMContentLoaded', function () {
  var isCheckout = document.querySelector('main[data-checkout]');
  if (!isCheckout && (document.querySelector('.cart-items-list') || document.getElementById('cart-items'))) {
    CartPage.mount(null);
  }
});