<?php
use think\migration\Migrator;

/**
 * 营销发放记录补充「被邀请人」字段
 *
 * 分享拉新奖励里 user_id 是领奖人（邀请人），referee_user_id 才是产生奖励的被邀请人；
 * scope_key 仍单独承担幂等（referee:{id}），此列只用于后台展示与对账。
 */
class AddMarketingRuleLogReferee extends Migrator
{
    public function change()
    {
        $this->table('marketing_rule_log')
            ->addColumn('referee_user_id', 'biginteger', [
                'signed'  => false,
                'null'    => true,
                'comment' => '分享拉新场景的被邀请人；其他场景为 NULL',
            ])
            ->addIndex(['referee_user_id'], ['name' => 'idx_referee'])
            ->update();
    }
}
