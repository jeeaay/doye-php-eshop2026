<?php
use think\migration\Migrator;

/**
 * 商品增加海外仓字段
 *
 * - warehouses_json：JSON 数组，取值 north_america / germany / korea，可多选
 * - 空数组或 NULL 表示无海外仓（国内直发），库存仍按 SKU 总量，不按仓拆分
 */
class AddProductWarehouses extends Migrator
{
    /**
     * @return void
     */
    public function change()
    {
        $this->table('product')
            ->addColumn('warehouses_json', 'json', [
                'null'    => true,
                'comment' => '海外仓数组：north_america/germany/korea，空=国内直发',
            ])
            ->update();
    }
}
