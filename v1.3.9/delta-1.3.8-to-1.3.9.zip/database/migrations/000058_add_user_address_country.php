<?php
use think\migration\Migrator;

/**
 * 收货地址增加国家字段
 *
 * - country：ISO2 国家码（US / GB / DE ...），或固定值 OTHER（其他国家）
 * - NULL / 空表示未设置：历史地址与小程序创建的地址保持该语义
 */
class AddUserAddressCountry extends Migrator
{
    /**
     * @return void
     */
    public function change()
    {
        $this->table('user_address')
            ->addColumn('country', 'string', [
                'limit'   => 8,
                'null'    => true,
                'comment' => '收货国家 ISO2；OTHER=其他国家；空=未设置',
            ])
            ->update();
    }
}
