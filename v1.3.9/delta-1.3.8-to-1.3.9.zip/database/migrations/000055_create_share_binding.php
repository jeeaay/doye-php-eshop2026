<?php
use think\migration\Migrator;

/**
 * 分享拉新绑定关系
 *
 * share_referral 记录"谁在什么时候打开过分享链接"的事件流水；
 * share_binding 记录"这个被邀请人最终归谁"的唯一关系，奖励与归因都以它为准。
 *
 * 口径：首触优先，默认 7 天有效；过期且被邀请人仍无已支付订单时允许被新分享重绑。
 * visitor_user_id 唯一索引是并发兜底，写入方必须处理重复键。
 */
class CreateShareBinding extends Migrator
{
    public function change()
    {
        $table = $this->table('share_binding', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '分享拉新绑定关系（邀请人 → 被邀请人）',
        ]);
        $table->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('visitor_user_id', 'biginteger', ['signed' => false, 'null' => false, 'comment' => '被邀请人'])
            ->addColumn('referrer_user_id', 'biginteger', ['signed' => false, 'null' => false, 'comment' => '邀请人'])
            ->addColumn('share_referral_id', 'biginteger', ['signed' => false, 'null' => true, 'comment' => '首次命中的分享事件'])
            ->addColumn('product_id', 'biginteger', ['signed' => false, 'null' => true, 'comment' => '分享时商品；为空表示非商品页分享'])
            ->addColumn('scene', 'string', ['limit' => 32, 'null' => true, 'comment' => 'friend / group'])
            ->addColumn('client_ip', 'string', ['limit' => 45, 'null' => true, 'comment' => '绑定时的客户端 IP，仅风控留痕'])
            ->addColumn('status', 'string', ['limit' => 16, 'null' => false, 'default' => 'bound', 'comment' => 'bound / rewarded / expired / invalid'])
            ->addColumn('reward_rule_id', 'biginteger', ['signed' => false, 'null' => true, 'comment' => '实际发奖规则'])
            ->addColumn('reward_coupon_user_id', 'biginteger', ['signed' => false, 'null' => true, 'comment' => '发出的券实例'])
            ->addColumn('bound_at', 'datetime', ['null' => true])
            ->addColumn('expire_at', 'datetime', ['null' => true])
            ->addColumn('rewarded_at', 'datetime', ['null' => true])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addIndex(['visitor_user_id'], ['unique' => true, 'name' => 'uk_visitor'])
            ->addIndex(['referrer_user_id', 'bound_at'], ['name' => 'idx_referrer_time'])
            ->addIndex(['status'])
            ->addIndex(['expire_at'])
            ->create();
    }
}
