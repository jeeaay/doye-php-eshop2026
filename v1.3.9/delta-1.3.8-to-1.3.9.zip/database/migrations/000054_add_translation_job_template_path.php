<?php
use think\migration\Migrator;

/**
 * translation_job 增加模板任务冗余检索列 + 复合索引
 *
 * 模板翻译任务（entity_type=template_file）的 template / path 原本只存在 fields_json 里，
 * 去重与「取每 (path,lang) 最新一条任务」只能靠 json_contains(fields_json->...)：
 * fields_json 内嵌整页规范化 HTML（可达上百 KB），且无索引可用，全表扫 + 逐行解析大 JSON，
 * 无法支撑后台模板翻译面板每 3 秒一次的轮询查询。
 *
 * 方案：把 template / path 冗余到 template_name / file_path 两个可空列，
 * 配合 idx_template_job(entity_type, template_name, target_lang, file_path) 走索引检索。
 * 仅 entity_type=template_file 写入，实体翻译（product/category/brand/page）保持 NULL，不受影响。
 *
 * 只向前（规范禁用 migrate:rollback）：change() 末尾对存量模板任务分批回填，
 * 每批 LIMIT 500 循环到受影响行数为 0，避免一次性大 UPDATE 造成长时间锁表。
 */
class AddTranslationJobTemplatePath extends Migrator
{
    /**
     * 执行迁移
     *
     * @return void
     */
    public function change()
    {
        $this->table('translation_job')
            ->addColumn('template_name', 'string', [
                'limit'   => 64,
                'null'    => true,
                'comment' => '模板名，仅 entity_type=template_file 使用，冗余自 fields_json，供索引查询',
            ])
            ->addColumn('file_path', 'string', [
                'limit'   => 255,
                'null'    => true,
                'comment' => '模板内相对路径，仅 entity_type=template_file 使用，冗余自 fields_json，供索引查询',
            ])
            ->addIndex(
                ['entity_type', 'template_name', 'target_lang', 'file_path'],
                ['name' => 'idx_template_job']
            )
            ->update();

        // 分批回填存量模板任务：每批 500 行，循环到受影响行数为 0（避免长锁）
        while (true) {
            $affected = $this->execute(
                "UPDATE `translation_job`
                 SET `template_name` = JSON_UNQUOTE(JSON_EXTRACT(`fields_json`, '$.template')),
                     `file_path` = JSON_UNQUOTE(JSON_EXTRACT(`fields_json`, '$.path'))
                 WHERE `entity_type` = 'template_file'
                   AND `template_name` IS NULL
                 LIMIT 500"
            );

            if ((int) $affected <= 0) {
                break;
            }
        }
    }
}
