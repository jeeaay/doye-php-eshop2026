<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\service\ShareService;

/**
 * 管理 API：分享拉新
 *
 * 只读接口；数据范围与权限口径由 ShareService 统一处理（超管全量，其他角色按 merchant_ids）。
 */
class Share extends ApiBaseController
{
    /**
     * GET /admin-api/v1/share/overview
     *
     * @return \think\response\Json
     */
    public function overview()
    {
        return $this->run(function () {
            return (new ShareService())->adminOverview();
        });
    }

    /**
     * GET /admin-api/v1/share/inviters
     *
     * @return \think\response\Json
     */
    public function inviters()
    {
        return $this->run(function () {
            [$page, $size] = $this->pageParams();
            return (new ShareService())->adminInviters($this->filters(), $page, $size);
        });
    }

    /**
     * GET /admin-api/v1/share/referrals
     *
     * @return \think\response\Json
     */
    public function referrals()
    {
        return $this->run(function () {
            [$page, $size] = $this->pageParams();
            return (new ShareService())->adminReferrals($this->filters(), $page, $size);
        });
    }

    /**
     * GET /admin-api/v1/share/bindings
     *
     * @return \think\response\Json
     */
    public function bindings()
    {
        return $this->run(function () {
            [$page, $size] = $this->pageParams();
            return (new ShareService())->adminBindings($this->filters(), $page, $size);
        });
    }

    /**
     * GET /admin-api/v1/share/rewards
     *
     * @return \think\response\Json
     */
    public function rewards()
    {
        return $this->run(function () {
            [$page, $size] = $this->pageParams();
            return (new ShareService())->adminRewards($this->filters(), $page, $size);
        });
    }

    /**
     * 统一筛选参数
     *
     * @return array
     */
    private function filters(): array
    {
        return [
            'keyword'   => trim((string) $this->request->param('keyword', '')),
            'status'    => trim((string) $this->request->param('status', '')),
            'date_from' => trim((string) $this->request->param('date_from', '')),
            'date_to'   => trim((string) $this->request->param('date_to', '')),
        ];
    }
}
