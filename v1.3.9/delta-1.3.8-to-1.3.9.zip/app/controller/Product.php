<?php
declare(strict_types=1);

namespace app\controller;

use app\common\service\CouponService;
use app\common\service\ProductRouteService;
use app\common\service\ReviewService;
use app\common\service\ShippingEtaService;
use think\facade\Cookie;

/**
 * 商品列表 / 详情（eshop2026 主题）
 *
 * 详情支持两种寻址：
 *   - /products/{id}、/product/{id}：数字 ID（保持兼容，不做 301）
 *   - /products/{custom_path}：后台「高级」选项卡配置的自定义访问路径
 *   - 根级 /{custom_path}/：由 Page/detail 解析后转发到本控制器
 */
class Product extends SiteBase
{
    public function list()
    {
        $categoryId = (int) $this->request->get('category_id', 0);
        $keyword = trim((string) $this->request->get('keyword', ''));
        $sort = (string) $this->request->get('sort', 'newest');
        if (!in_array($sort, ['newest', 'price-asc', 'price-desc', 'popular'], true)) {
            $sort = 'newest';
        }

        $brand = $this->store->brand();
        $result = $this->store->productCards(1, 120, $categoryId, $keyword, $sort);

        return $this->render('products', [
            'nav_active'      => 'products',
            'page_title'      => 'Products - ' . $brand['name'],
            'meta_desc'       => 'Browse our full range of home storage and organisation solutions.',
            'products'        => $result['list'],
            'total'           => $result['total'],
            'sort'            => $sort,
            'page_size'       => (int) site_config('per_page', 24),
            'categories'      => $this->store->categories(),
            'active_category' => $categoryId,
            'flash_promotions' => (new CouponService())->activePlatformPromotions(),
        ]);
    }

    public function detail($id = 0)
    {
        $param = trim((string) $id);
        if ($param === '' || $param === '0') {
            // 路由未绑定到有效参数（如 /products.html 被 url_html_suffix 剥离为 /products）
            return $this->notFound('Product not found');
        }

        if (ctype_digit($param)) {
            $product = $this->store->product((int) $param);
        } else {
            // 自定义访问路径：Redis 优先，MySQL 兜底（Redis 不可用时仍可访问）
            $productId = (new ProductRouteService())->resolve($param);
            $product = $productId !== null ? $this->store->product($productId) : null;
        }
        if (!$product) {
            return $this->notFound('Product not found');
        }

        $seoTitle = trim((string) ($product['seo_title'] ?? ''));
        $seoDescription = trim((string) ($product['seo_description'] ?? ''));
        if ($seoDescription === '') {
            $seoDescription = $product['brief'] !== ''
                ? $product['brief']
                : mb_substr(trim(strip_tags((string) $product['description'])), 0, 160);
        }
        $seoKeywords = trim((string) ($product['seo_keywords'] ?? ''));
        if ($seoKeywords === '') {
            $seoKeywords = implode(',', (array) ($product['tags'] ?? []));
        }

        // 页面标题：商品名称 - 副标题 - SEO 标题；缺失的部分自动省略
        $titleParts = array_filter([
            trim((string) ($product['name'] ?? '')),
            trim((string) ($product['brief'] ?? '')),
            $seoTitle,
        ], static fn (string $part): bool => $part !== '');
        $json = json_encode([
            'id'        => $product['id'],
            'name'      => $product['name'],
            'price'     => $product['price'],
            'image'     => $product['image'],
            'url'       => $product['url'],
            'brief'     => $product['brief'],
            'has_stock' => $product['has_stock'],
            'skus'      => array_map(static fn ($s) => [
                'id'        => $s['id'],
                'spec_name' => $s['spec_name'],
                'price'     => $s['price'],
                'stock'     => $s['stock'],
            ], $product['skus']),
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        // canonical 指向自定义路径（填写 slug 时）；数字路径保持 200 不重定向
        $canonicalPath = storefront_product_url($product);

        // 评论：首屏服务端渲染（SEO / 无 JS 可用），筛选与加载更多由前端接管
        $reviewService = new ReviewService();
        $reviewSummary = $reviewService->summary((int) $product['id']);
        $reviewPage    = $reviewService->listApproved((int) $product['id'], [], 1, ReviewService::PAGE_SIZE);

        $vars = [
            'nav_active'   => 'products',
            'page_title'   => implode(' - ', $titleParts),
            'meta_desc'    => $seoDescription,
            'meta_keys'    => $seoKeywords,
            'meta_robots'  => (int) ($product['seo_noindex'] ?? 0) === 1 ? 'noindex,follow' : '',
            'product'      => $product,
            'related_products' => $this->store->relatedProducts((int) $product['id'], (int) $product['category_id']),
            'product_json' => htmlspecialchars((string) $json, ENT_QUOTES, 'UTF-8'),
            'canonical_url'  => $this->canonicalUrl($canonicalPath),
            'hreflang_links' => $this->hreflangLinks($canonicalPath),
            'review_summary'   => $reviewSummary,
            'review_stars'     => $this->reviewStarStates((float) $reviewSummary['avg']),
            'reviews'          => $reviewPage['list'],
            'reviews_total'    => (int) $reviewPage['total'],
            'review_page_size' => ReviewService::PAGE_SIZE,
        ];

        // 配送时效模块只在国际版渲染（国内版保持原有文案）
        if (!is_domestic_edition()) {
            $shippingEta = new ShippingEtaService();
            $shipTo = $this->resolveShipTo($shippingEta);
            $warehouses = (array) ($product['warehouses'] ?? []);

            $vars['ship_to']            = $shipTo;
            $vars['ship_to_groups']     = $shippingEta->countries();
            $vars['shipping_eta_text']  = $shippingEta->textForCountry($warehouses, $shipTo);
            // 默认地址国家由前端补：按「本商品仓库 × 国家」预生成文案，JS 只查表
            $vars['eta_by_country_json'] = htmlspecialchars(
                (string) json_encode(
                    $shippingEta->textsByCountry($warehouses),
                    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
                ),
                ENT_QUOTES,
                'UTF-8'
            );
        }

        $html = $this->render('product', $vars);
        if (!is_string($html)) {
            return $html;
        }

        // 页面内容随语种与 ship_to cookie 变化，避免 CDN 把 A 国页面缓存给 B 国
        return response($html)
            ->contentType('text/html')
            ->header(['Vary' => 'Accept-Language, Cookie']);
    }

    /**
     * 解析「配送至」国家
     *
     * 优先级：?ship_to（合法则写 cookie 1 年，视为用户显式选择）> ship_to cookie > 站点默认国家。
     * 非法 query 值忽略且不写 cookie。
     */
    private function resolveShipTo(ShippingEtaService $service): string
    {
        $queryCode = $this->request->get('ship_to', '');
        $fromQuery = $service->normalize(is_scalar($queryCode) ? (string) $queryCode : '');
        if ($fromQuery !== null) {
            Cookie::set('ship_to', $fromQuery, 31536000);

            return $fromQuery;
        }

        $cookieCode = Cookie::get('ship_to', '');
        $fromCookie = $service->normalize(is_scalar($cookieCode) ? (string) $cookieCode : '');

        return $fromCookie ?? $service->defaultCountry();
    }

    /**
     * 5 颗星的展示状态：满星 → 半星 → 空星（空星复用 star.svg + opacity）
     *
     * @param float $avg 平均分（0-5，1 位小数）
     * @return array<int,string> 长度恒为 5，值 ∈ full|half|empty
     */
    private function reviewStarStates(float $avg): array
    {
        $avg  = max(0.0, min(5.0, $avg));
        $full = (int) floor($avg);
        $half = ($avg - $full) >= 0.5 ? 1 : 0;
        $empty = max(0, 5 - $full - $half);

        return array_merge(
            array_fill(0, $full, 'full'),
            $half === 1 ? ['half'] : [],
            array_fill(0, $empty, 'empty')
        );
    }
}