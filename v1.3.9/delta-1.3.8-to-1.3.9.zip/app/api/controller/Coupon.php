<?php
declare(strict_types=1);

namespace app\api\controller;

use app\BaseController;
use app\common\exception\BizException;
use app\common\model\ProductSku;
use app\common\service\CouponService;
use app\common\support\AppContext;

/**
 * 优惠（券）前台接口
 *
 * 提供可领取列表、领取、我的可用券与折扣试算；
 * 折扣口径统一走 {@see CouponService::quote()}，与结算保持一致。
 */
class Coupon extends BaseController
{
    /**
     * 当前可领取的优惠券列表（首单券、活动券、优惠码券）
     *
     * @return \think\Response
     */
    public function list()
    {
        $userId = (int) AppContext::getUserId();
        $list = (new CouponService())->claimableList($userId);
        return $this->success(['list' => $list]);
    }

    /**
     * 领取优惠券
     *
     * @return \think\Response
     */
    public function claim()
    {
        try {
            $userId = (int) AppContext::getUserId();
            $couponId = (int) $this->request->post('coupon_id', 0);
            if (!$couponId) {
                return $this->error(40001, '参数错误');
            }
            $record = (new CouponService())->claim($couponId, $userId);
            return $this->success([
                'coupon_user_id' => (int) $record->id,
                'expire_time'    => (string) ($record->expire_time ?? ''),
            ]);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    /**
     * 我的优惠券（账户中心，按 tab 展示；与结算页可用券试算分开）
     *
     * @return \think\Response
     */
    public function myCoupons()
    {
        try {
            $userId = (int) AppContext::getUserId();
            $tab    = trim((string) $this->request->param('status', ''));
            $result = (new CouponService())->myCoupons($userId, $tab);
            return $this->success($result);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    /**
     * 当前用户在指定购物车下可用的已领取券
     *
     * @return \think\Response
     */
    public function mine()
    {
        try {
            $userId = (int) AppContext::getUserId();
            [$rows, $subtotal] = $this->resolveItems($this->request->param('items', []));
            $list = (new CouponService())->myAvailableCoupons($userId, $rows, $subtotal);
            return $this->success([
                'list'         => $list,
                'subtotal'     => $subtotal,
                'min_payable'  => min_payable_amount(),
            ]);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    /**
     * 折扣试算（优惠码 / 已领券），返回明细与实付金额
     *
     * @return \think\Response
     */
    public function quote()
    {
        try {
            $userId = (int) AppContext::getUserId();
            [$rows, $subtotal] = $this->resolveItems($this->request->param('items', []));
            $code = strtoupper(trim((string) $this->request->param('coupon_code', '')));
            $couponUserId = (int) $this->request->param('coupon_user_id', 0) ?: null;

            $result = (new CouponService())->quote($rows, $subtotal, $userId, $couponUserId, $code);
            return $this->success([
                'lines'          => $result['lines'],
                'discount'       => $result['discount'],
                'payable'        => $result['payable'],
                'subtotal'       => $subtotal,
                'coupon_user_id' => $result['coupon_user_id'],
                'no_threshold_coupon_user_id' => $result['no_threshold_coupon_user_id'] ?? null,
                'no_threshold_notice' => $result['no_threshold_notice'] ?? '',
                'min_payable'    => $result['min_payable'],
                'min_payable_met' => $result['min_payable_met'],
                'min_payable_shortfall' => $result['min_payable_shortfall'],
            ]);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    /**
     * 将结算商品归一化为优惠计算的商品行
     *
     * 入参形如 [['sku_id'=>1,'quantity'=>2], ...]，按规格价格汇总小计；
     * 供「我的可用券」与「折扣试算」复用，避免金额口径与结算不一致。
     *
     * @param mixed $items 商品明细（POST/GET 传入）
     * @return array{0:array<int,array{product_id:int,subtotal:string}>,1:string} [商品行, 商品小计]
     * @throws BizException 无商品或规格不存在时抛出
     */
    private function resolveItems($items): array
    {
        if (!is_array($items) || empty($items)) {
            throw new BizException('无结算商品');
        }
        $skuIds = [];
        foreach ($items as $item) {
            $skuIds[] = (int) ($item['sku_id'] ?? 0);
        }
        $skuList = ProductSku::where('id', 'in', $skuIds)->select();
        $skuMap = [];
        foreach ($skuList as $sku) {
            $skuMap[(int) $sku->id] = $sku;
        }

        $rows = [];
        $subtotal = '0.00';
        foreach ($items as $item) {
            $skuId = (int) ($item['sku_id'] ?? 0);
            $qty = max(0, (int) ($item['quantity'] ?? 0));
            $sku = $skuMap[$skuId] ?? null;
            if (!$sku || $qty < 1) {
                throw new BizException('部分商品规格不存在');
            }
            $lineTotal = bcmul((string) $sku->price, (string) $qty, 2);
            $rows[] = ['product_id' => (int) $sku->product_id, 'subtotal' => $lineTotal];
            $subtotal = bcadd($subtotal, $lineTotal, 2);
        }
        return [$rows, $subtotal];
    }
}
