<?php
declare(strict_types=1);

namespace app\api\controller;

use app\BaseController;
use app\common\lib\RedisCache;
use app\common\model\Product as ProductModel;
use app\common\service\ProductService;

class Product extends BaseController
{
    public function list()
    {
        $page = (int)$this->request->get('page', 1);
        $size = min(max((int)$this->request->get('size', 20), 1), 50);

        $filter = [
            'category_id' => (int)$this->request->get('category_id', 0),
            'keyword'     => trim((string)$this->request->get('keyword', '')),
            'merchant_id' => (int)$this->request->get('merchant_id', 0),
        ];

        $pager = (new ProductService())->listProducts($page, $size, $filter);

        $list = [];
        foreach ($pager->items() as $product) {
            $prices = [];
            foreach ($product->skus as $sku) {
                $prices[] = (float)$sku->price;
            }
            $list[] = [
                'id'            => $product->id,
                'title'         => $product->title,
                'main_image'    => $product->main_image,
                'price_min'     => $prices ? number_format(min($prices), 2, '.', '') : '0.00',
                'price_max'     => $prices ? number_format(max($prices), 2, '.', '') : '0.00',
                'merchant_name' => $product->merchant ? $product->merchant->name : '',
            ];
        }

        return $this->success([
            'list'     => $list,
            'total'    => $pager->total(),
            'page'     => $pager->currentPage(),
            'size'     => $pager->listRows(),
            'hasMore'  => $pager->hasMore(),
        ]);
    }

    public function detail()
    {
        $id = (int)$this->request->get('id', 0);
        if (!$id) {
            return $this->error(40001, '参数错误');
        }

        $data = RedisCache::remember('product:detail:public:' . $id, 300, static function () use ($id): ?array {
            $product = (new ProductService())->getProductDetail($id);
            if (!$product || (int) $product->status !== 1) {
                return null;
            }

            return [
                'id' => (int) $product->id,
                'title' => (string) $product->title,
                'subtitle' => (string) ($product->subtitle ?? ''),
                'main_image' => (string) $product->main_image,
                'images' => is_array($product->images_json) ? $product->images_json : ((array) json_decode((string) $product->images_json, true)),
                'video_url' => (string) ($product->video_url ?? ''),
                'video_cover' => (string) ($product->video_cover ?? ''),
                'detail_html' => (string) ($product->detail_html ?? ''),
                'skus' => array_map(static fn($sku) => [
                    'id' => (int) $sku->id,
                    'spec_name' => (string) $sku->spec_name,
                    'price' => (string) $sku->price,
                    'stock' => (int) $sku->stock,
                    'sku_code' => (string) ($sku->sku_code ?? ''),
                    'spec_values_json' => $sku->spec_values_json,
                ], $product->skus->all()),
                'specs' => self::productSpecs($product),
                'merchant' => [
                    'id' => (int) ($product->merchant?->id ?? 0),
                    'name' => (string) ($product->merchant?->name ?? ''),
                ],
            ];
        });
        if (!$data) {
            return $this->error(40004, '商品不存在');
        }

        return $this->success($data);
    }

    private static function productSpecs(ProductModel $product): array
    {
        $specs = [];
        foreach ((array)$product->specs_json as $spec) {
            $name = trim((string)($spec['name'] ?? ''));
            $values = [];
            foreach ((array)($spec['values'] ?? []) as $value) {
                $value = trim((string)$value);
                if ($value !== '' && !in_array($value, $values, true)) {
                    $values[] = $value;
                }
            }
            if ($name === '' || !$values) {
                continue;
            }
            $specs[] = ['name' => $name, 'values' => $values];
        }
        if (!$specs) {
            $legacy = [];
            foreach ($product->skus as $sku) {
                foreach ((array)$sku->spec_values_json as $name => $value) {
                    $legacy[(string)$name][(string)$value] = true;
                }
            }
            foreach ($legacy as $name => $values) {
                $specs[] = ['name' => (string)$name, 'values' => array_map('strval', array_keys($values))];
            }
        }
        return array_values($specs);
    }
}
