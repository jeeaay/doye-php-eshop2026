<?php
declare(strict_types=1);

namespace app\api\controller;

use app\BaseController;
use app\common\exception\BizException;
use app\common\service\ShareService;
use app\common\support\AppContext;

/**
 * 小程序分享拉新接口
 *
 * 上报、邀请概况与记录都只操作当前登录用户自己的数据；
 * 绑定与发奖逻辑全部在 ShareService / MarketingService，控制器只做参数整形。
 */
class Share extends BaseController
{
    /**
     * 上报一次分享访问并尝试绑定
     *
     * POST /api/share/report
     * {referrer_user_id, product_id?, scene?}
     *
     * @return \think\Response
     */
    public function report()
    {
        try {
            $userId = (int) AppContext::getUserId();
            $referrerId = (int) $this->request->post('referrer_user_id', 0);
            $productId = $this->request->post('product_id');
            $productId = $productId !== null && $productId !== '' ? (int) $productId : null;
            $scene = (string) $this->request->post('scene', 'friend');
            $capturedAt = (int) $this->request->post('captured_at', 0);

            if ($referrerId <= 0) {
                return $this->error(40001, '参数错误');
            }

            $result = (new ShareService())->recordReferral(
                $referrerId,
                $userId,
                $productId,
                $scene,
                client_ip(),
                $capturedAt > 0 ? $capturedAt : null
            );
            return $this->success($result);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    /**
     * 我的邀请概况
     *
     * GET /api/share/invite/summary
     *
     * @return \think\Response
     */
    public function summary()
    {
        $userId = (int) AppContext::getUserId();
        return $this->success((new ShareService())->inviteSummary($userId));
    }

    /**
     * 我的邀请记录
     *
     * GET /api/share/invite/list?page=1&page_size=20
     *
     * @return \think\Response
     */
    public function inviteList()
    {
        $userId = (int) AppContext::getUserId();
        $page = max(1, (int) $this->request->get('page', 1));
        $size = (int) $this->request->get('page_size', 20);
        if ($size <= 0) {
            $size = 20;
        }
        return $this->success((new ShareService())->inviteList($userId, $page, min($size, 100)));
    }
}
