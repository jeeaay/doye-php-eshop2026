<?php
declare(strict_types=1);

namespace app\common\command;

use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\facade\Db;

/**
 * 迁移目录守卫
 *
 * think-migration 硬编码扫描 <root>/database/migrations 与 <root>/database/seeds
 * （vendor Migrate.php:30 / Seed.php:30），目录被挪走后 migrate:run / seed:run
 * 会静默空跑而不是报错。本命令把「框架能扫描到」变成显式断言：
 *
 *   1. migrations 目录存在且至少有 1 个 .php 文件；
 *   2. 每个迁移文件的版本号要么已在 migrations 账本，要么是待执行的更新版本
 *      （版本号小于账本最大值却不在账本 = 账本断裂）；
 *   3. seeds 目录存在且至少有 1 个 seeder（AGENTS.md 的 seed:run 依赖它）。
 *
 * 输出契约与 scope:write-check 一致：每行 `PASS|FAIL <check> : <detail>`，
 * 末行 ALL PASSED / FAILED，退出码 0 / 1。
 */
class MigrateGuard extends Command
{
    protected function configure(): void
    {
        $this->setName('migrate:guard')
            ->setDescription('守卫：迁移/seeder 目录断链时必须失败退出，不允许静默空跑');
    }

    protected function execute(Input $input, Output $output): int
    {
        $root = $this->app->getRootPath();
        $failed = false;

        // 1) 迁移文件扫描
        $migrationFiles = glob($root . 'database' . DIRECTORY_SEPARATOR . 'migrations' . DIRECTORY_SEPARATOR . '*.php') ?: [];
        if ($migrationFiles === []) {
            $output->writeln('<error>FAIL migrations.scanned : database/migrations 下没有 .php 文件（目录缺失或被移动，migrate:run 会静默空跑）</error>');
            $failed = true;
        } else {
            $output->writeln('<info>PASS migrations.scanned : ' . count($migrationFiles) . ' 个迁移文件</info>');
        }

        // 2) 文件版本与 migrations 账本一致性（目录正常时才有意义）
        $ledger = array_map('intval', Db::name('migrations')->column('version'));
        $maxLedger = $ledger === [] ? 0 : max($ledger);
        $broken = [];
        $pending = 0;
        foreach ($migrationFiles as $file) {
            $base = basename((string) $file);
            if (!preg_match('/^(\d+)_/', $base, $m)) {
                $broken[] = $base . '（文件名缺少 0000NN 版本前缀）';
                continue;
            }
            $version = (int) $m[1];
            if (in_array($version, $ledger, true)) {
                continue;
            }
            if ($version > $maxLedger) {
                $pending++;
                continue;
            }
            $broken[] = $base . '（版本号小于账本最大值 ' . $maxLedger . ' 却不在账本，账本断裂）';
        }
        if ($broken !== []) {
            $output->writeln('<error>FAIL migrations.ledger : ' . count($broken) . ' 个异常 —— ' . implode('；', array_slice($broken, 0, 3)) . '</error>');
            $failed = true;
        } else {
            $output->writeln('<info>PASS migrations.ledger : 账本 ' . count($ledger) . ' 条，待执行 ' . $pending . ' 个，无断裂</info>');
        }

        // 3) seeder 扫描
        $seedFiles = glob($root . 'database' . DIRECTORY_SEPARATOR . 'seeds' . DIRECTORY_SEPARATOR . '*.php') ?: [];
        if ($seedFiles === []) {
            $output->writeln('<error>FAIL seeds.scanned : database/seeds 下没有 .php 文件（目录缺失或被移动，seed:run 会静默空跑）</error>');
            $failed = true;
        } else {
            $output->writeln('<info>PASS seeds.scanned : ' . count($seedFiles) . ' 个 seeder</info>');
        }

        if ($failed) {
            $output->writeln('<error>FAILED</error>');
            return 1;
        }

        $output->writeln('<info>ALL PASSED</info>');
        return 0;
    }
}
