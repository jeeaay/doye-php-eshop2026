<?php

namespace app\common\command;

use app\common\enum\OrderStatus;
use app\common\lib\DelayQueue;
use app\common\model\Order;
use app\common\model\ProductSku;
use app\common\model\User;
use app\common\service\OrderService;
use app\common\service\UserService;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\facade\Db;

class OrderDelayTest extends Command
{
    protected function configure(): void
    {
        $this->setName('order:delaytest')->setDescription('Test checkout delay-enqueue + consume cancel + stock release');
    }

    protected function execute(Input $input, Output $output): void
    {
        $user = User::where('openid', 'mock_check')->find();
        if (!$user) {
            $user = (new UserService())->loginByCode('check')['user'];
        }
        // 下单门槛要求手机号，测试用户补一个固定号码
        if (trim((string) $user->phone) === '') {
            $user->phone = '13800000000';
            $user->save();
        }
        $sku = ProductSku::where('sku_code', 'CONC_TEST')->find();
        if (!$sku) {
            $output->writeln('<error>run stock:test first to create CONC_TEST sku</error>');
            return;
        }
        Db::name('product_sku')->where('id', $sku->id)->update(['stock' => 5]);
        $stockBefore = 5;

        $svc = new OrderService();
        $pay = $svc->checkout((int)$user->id, [['sku_id' => (int)$sku->id, 'quantity' => 1]], ['name' => '测试', 'phone' => '13800000000', 'address_detail' => '测试地址']);
        $stockAfterCheckout = (int)Db::name('product_sku')->where('id', $sku->id)->value('stock');
        $output->writeln("checkout pay_id={$pay->id} stock {$stockBefore}->{$stockAfterCheckout} delayQueue=" . DelayQueue::count());

        DelayQueue::delay('order_cancel', ['order_pay_id' => (int)$pay->id], time());
        $output->writeln('enqueued immediate cancel, delayQueue=' . DelayQueue::count());

        $consumed = 0;
        while ($task = DelayQueue::popExpired()) {
            if (($task['type'] ?? '') !== 'order_cancel') {
                continue;
            }
            try {
                (new OrderService())->cancelUnpaidByPayId((int)($task['payload']['order_pay_id'] ?? 0));
                $consumed++;
            } catch (\Throwable $e) {
                $output->writeln('<error>' . $e->getMessage() . '</error>');
            }
        }
        $stockAfterCancel = (int)Db::name('product_sku')->where('id', $sku->id)->value('stock');
        $order = (new Order())->db(['merchant'])->where('pay_id', $pay->id)->find();
        $output->writeln("consumed={$consumed} stock={$stockAfterCancel} order_status={$order->status}");
        if ($stockAfterCancel == 5 && $order->status == OrderStatus::CANCELLED) {
            $output->writeln('<info>delay cancel path OK</info>');
        } else {
            $output->writeln('<error>delay cancel path FAILED</error>');
        }
    }
}
