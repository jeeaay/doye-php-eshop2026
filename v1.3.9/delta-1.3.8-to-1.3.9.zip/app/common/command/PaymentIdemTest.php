<?php

namespace app\common\command;

use app\common\enum\OrderStatus;
use app\common\enum\PayStatus;
use app\common\model\Order;
use app\common\model\OrderPay;
use app\common\model\ProductSku;
use app\common\model\User;
use app\common\service\OrderService;
use app\common\service\PaymentService;
use think\console\Command;
use think\console\Input;
use think\console\Output;
use think\facade\Db;

class PaymentIdemTest extends Command
{
    protected function configure(): void
    {
        $this->setName('payment:idemtest')->setDescription('Test payment notify idempotency (mock)');
    }

    protected function execute(Input $input, Output $output): void
    {
        Db::name('product_sku')->where('sku_code', 'CONC_TEST')->update(['stock' => 5]);
        $user = User::where('openid', 'mock_check')->find();
        $sku = ProductSku::where('sku_code', 'CONC_TEST')->find();
        if (!$user || !$sku) {
            $output->writeln('<error>run model:check and stock:test first</error>');
            return;
        }
        // 下单门槛要求手机号，测试用户补一个固定号码
        if (trim((string) $user->phone) === '') {
            $user->phone = '13800000000';
            $user->save();
        }
        $pay = (new OrderService())->checkout((int)$user->id, [['sku_id' => (int)$sku->id, 'quantity' => 1]], ['name' => 't', 'phone' => '1', 'address_detail' => 'x']);
        $stockAfterCheckout = (int)Db::name('product_sku')->where('id', $sku->id)->value('stock');
        $output->writeln("checkout pay_id={$pay->id} stock 5->{$stockAfterCheckout}");

        $svc = new PaymentService();
        $payload = json_encode(['out_trade_no' => (string)$pay->id, 'transaction_id' => 'wx_test_' . time(), 'trade_state' => 'SUCCESS']);

        $r1 = $svc->handleNotify($payload, [], true);
        $order = (new Order())->db(['merchant'])->where('pay_id', $pay->id)->find();
        $pay1 = OrderPay::find($pay->id);
        $output->writeln("notify#1: {$r1} | pay_status={$pay1->pay_status} order_status={$order->status}");

        $r2 = $svc->handleNotify($payload, [], true);
        $pay2 = OrderPay::find($pay->id);
        $stockAfter = (int)Db::name('product_sku')->where('id', $sku->id)->value('stock');
        $output->writeln("notify#2: {$r2} | pay_status={$pay2->pay_status} stock={$stockAfter}");

        if ($pay1->pay_status == PayStatus::PAID && $pay2->pay_status == PayStatus::PAID && $order->status == OrderStatus::PENDING_SHIP && $stockAfter == $stockAfterCheckout) {
            $output->writeln('<info>idempotency OK (no double processing)</info>');
        } else {
            $output->writeln('<error>idempotency FAILED</error>');
        }
    }
}
