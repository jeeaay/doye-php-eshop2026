<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\model\Coupon;
use app\common\model\CouponProduct;
use app\common\model\CouponRestoreLog;
use app\common\model\CouponUser;
use app\common\model\Merchant;
use app\common\model\OrderPay;
use app\common\model\Product;
use app\common\support\AppContext;
use think\facade\Db;
use think\facade\Log;

/**
 * 优惠（券 / 活动）服务
 *
 * 覆盖四类需求：全站自动优惠、无门槛券、满减券、指定商品券。
 * - 全站自动优惠：apply_type=auto，结算时自动生效（如圣诞全站 9 折）
 * - 无门槛券：apply_type=claim + min_amount=0（如首次进入领取 5 美元券）
 * - 满减券：apply_type=claim/code + min_amount>0
 * - 指定商品券：scope=product，仅对 coupon_product 命中的商品小计生效
 *
 * 叠加口径由 tier 决定，不按 apply_type 判断：
 * 10 商家折扣 → 20 平台活动 → 30 自动到账券 → 40 手选券/优惠码，前一层扣完的余额给下一层继续减；
 * 门槛（min_amount）一律按原价小计判定，金额上限按本层余额截断。
 * 固定金额无门槛券（min_amount=0 + discount_type=fixed，tier 30/40）一单只应用减免最大的一张；
 * 百分比券始终按原价适用金额计算，再与固定减免叠加，保证消费者优惠最大。
 *
 * 折扣试算统一走 {@see self::quote()}，后台/前台/结算共用同一套口径，避免金额不一致；
 * 下单时逐层明细写入 order_pay.discount_lines_json，展示与对账读快照不重算。
 *
 * 商户维度：`merchant_id` 非空的优惠只抵扣该商户的商品行（{@see self::eligibleBase()}），
 * 读写可见性在 Service 层显式收敛（{@see self::scopedCoupon()}）——
 * 这张表同时装平台行与商户行，不能交给 MerchantScope 自动注入。
 */
class CouponService
{
    /** product_id => merchant_id 的本次请求缓存，避免分层试算逐层重复查库 */
    private array $productMerchantCache = [];

    // ------------------------------------------------------------------
    // 后台管理
    // ------------------------------------------------------------------

    /**
     * 后台优惠列表（分页）
     *
     * 可见范围：超管全量（可按 merchant_id 筛选）；商家角色只见本店记录 + 平台活动（只读），
     * 未绑定商户的账号得到空集而不是全量。
     *
     * @param array $filters 支持 keyword / apply_type / status / merchant_id（仅超管）
     * @param int   $page    页码
     * @param int   $size    每页数量
     * @return array{list:array,pager:\think\Paginator}
     */
    public function adminList(array $filters, int $page = 1, int $size = 20): array
    {
        $query = Coupon::order('sort')->order('id', 'desc');
        $this->applyAdminVisibility($query, $filters);

        $keyword = trim((string) ($filters['keyword'] ?? ''));
        if ($keyword !== '') {
            $query->where(function ($q) use ($keyword) {
                $q->whereLike('name', '%' . $keyword . '%')
                    ->whereOr('code', 'like', '%' . $keyword . '%');
            });
        }

        $applyType = (string) ($filters['apply_type'] ?? '');
        if (in_array($applyType, [Coupon::APPLY_AUTO, Coupon::APPLY_CLAIM, Coupon::APPLY_CODE], true)) {
            $query->where('apply_type', $applyType);
        }

        $status = $filters['status'] ?? '';
        if ($status !== '' && $status !== null) {
            $query->where('status', (int) $status);
        }

        $pager = $query->paginate([
            'list_rows' => $size,
            'page'      => $page,
            'query'     => [
                'keyword'     => $keyword,
                'apply_type'  => $applyType,
                'status'      => $status,
                'merchant_id' => (int) ($filters['merchant_id'] ?? 0) ?: '',
            ],
        ]);

        $merchantNames = $this->merchantNames(array_map(
            fn($coupon) => $coupon->merchant_id,
            $pager->items()
        ));

        $list = [];
        foreach ($pager->items() as $coupon) {
            $list[] = $this->formatCoupon($coupon, $merchantNames);
        }

        return ['list' => $list, 'pager' => $pager];
    }

    /**
     * 列表查询的商户可见性
     *
     * 平台活动（merchant_id IS NULL）对商家只读可见，好让商家看懂自己商品上的叠加效果。
     * whereNull 必须走 whereOr(Closure)：`whereOr('merchant_id', 'null')` 会被当成
     * 「等于字符串 null」，条件恒假，商家会突然看不到任何平台活动。
     *
     * @param \think\db\Query $query
     * @param array           $filters
     * @return void
     */
    private function applyAdminVisibility($query, array $filters): void
    {
        if ($this->isSuper()) {
            $merchantId = (int) ($filters['merchant_id'] ?? 0);
            if ($merchantId > 0) {
                $query->where('merchant_id', $merchantId);
            }
            return;
        }

        $merchantIds = $this->merchantIds();
        if (empty($merchantIds)) {
            $query->whereRaw('1 = 0');
            return;
        }
        $query->where(function ($q) use ($merchantIds) {
            $q->whereIn('merchant_id', $merchantIds)
                ->whereOr(function ($o) {
                    $o->whereNull('merchant_id');
                });
        });
    }

    /**
     * 读取单条优惠详情（含适用商品 ID）
     *
     * @param int $id 优惠 ID
     * @return array
     * @throws BizException 不在当前账号可见范围时抛出
     */
    public function adminDetail(int $id): array
    {
        $coupon = $this->scopedCoupon($id);
        $data = $this->formatCoupon($coupon, $this->merchantNames([$coupon->merchant_id]));
        $data['product_ids'] = array_map('intval', CouponProduct::where('coupon_id', $id)->column('product_id'));
        return $data;
    }

    /**
     * 组装列表/详情用的输出结构
     *
     * @param Coupon $coupon        优惠模型
     * @param array  $merchantNames 商户 ID => 商户名（调用方批量取，缺名列 '-'）
     * @return array
     */
    private function formatCoupon(Coupon $coupon, array $merchantNames = []): array
    {
        $merchantId = $coupon->merchant_id === null ? null : (int) $coupon->merchant_id;

        return [
            'id'             => (int) $coupon->id,
            'name'           => (string) $coupon->name,
            'code'           => (string) ($coupon->code ?? ''),
            'merchant_id'    => $merchantId,
            'merchant_name'  => $merchantId === null ? '平台' : ($merchantNames[$merchantId] ?? '-'),
            'can_write'      => $this->canWrite($merchantId),
            'apply_type'     => (string) $coupon->apply_type,
            'apply_type_label' => self::applyTypeLabel((string) $coupon->apply_type),
            'tier'           => (int) $coupon->tier,
            'tier_label'     => Coupon::TIER_LABELS[(int) $coupon->tier] ?? '',
            'auto_apply'     => (int) $coupon->auto_apply,
            'discount_type'  => (string) $coupon->discount_type,
            'discount_value' => (string) $coupon->discount_value,
            'min_amount'     => (string) $coupon->min_amount,
            'max_discount'   => (string) $coupon->max_discount,
            'scope'          => (string) $coupon->scope,
            'scope_label'    => $coupon->scope === Coupon::SCOPE_PRODUCT ? '指定商品' : '全站',
            'total_qty'      => (int) $coupon->total_qty,
            'claimed_qty'    => (int) $coupon->claimed_qty,
            'used_qty'       => (int) $coupon->used_qty,
            'per_user_limit' => (int) $coupon->per_user_limit,
            'valid_days'     => (int) $coupon->valid_days,
            'expire_at'      => (string) ($coupon->expire_at ?? ''),
            'start_time'     => (string) ($coupon->start_time ?? ''),
            'end_time'       => (string) ($coupon->end_time ?? ''),
            'status'         => (int) $coupon->status,
            'sort'           => (int) $coupon->sort,
            'remark'         => (string) ($coupon->remark ?? ''),
            'discount_text'  => self::discountText($coupon),
            'create_time'    => (string) ($coupon->create_time ?? ''),
        ];
    }

    /**
     * 优惠面额展示文案，如「9 折」「减 £5.00」「满 £50 减 £5.00」
     *
     * @param Coupon $coupon 优惠模型
     * @return string
     */
    public static function discountText(Coupon $coupon): string
    {
        if ($coupon->discount_type === Coupon::TYPE_PERCENT) {
            $value = (float) $coupon->discount_value;
            return rtrim(rtrim(number_format(100 - $value, 2, '.', ''), '0'), '.') . ' 折（-' . rtrim(rtrim(number_format($value, 2, '.', ''), '0'), '.') . '%）';
        }
        if (bccomp((string) $coupon->min_amount, '0', 2) > 0) {
            return '满 ' . $coupon->min_amount . ' 减 ' . $coupon->discount_value;
        }
        return '立减 ' . $coupon->discount_value;
    }

    /**
     * 优惠类型中文标签
     *
     * @param string $applyType 类型值
     * @return string
     */
    public static function applyTypeLabel(string $applyType): string
    {
        return match ($applyType) {
            Coupon::APPLY_AUTO  => '全站自动',
            Coupon::APPLY_CODE  => '优惠码',
            default             => '前台领取',
        };
    }

    /**
     * 保存优惠（新增或更新），同步维护适用商品范围
     *
     * @param array    $data 表单数据
     * @param int|null $id   为空表示新增
     * @return int 优惠 ID
     * @throws BizException 校验失败
     */
    public function adminSave(array $data, ?int $id = null): int
    {
        $name = trim((string) ($data['name'] ?? ''));
        if ($name === '') {
            throw new BizException('请填写优惠名称');
        }

        $applyType = (string) ($data['apply_type'] ?? Coupon::APPLY_CLAIM);
        if (!in_array($applyType, [Coupon::APPLY_AUTO, Coupon::APPLY_CLAIM, Coupon::APPLY_CODE], true)) {
            throw new BizException('优惠类型不合法');
        }

        // 更新先按写权限取记录：他店记录报「不存在」，平台记录给明确的「不可修改」文案
        $existing = $id ? $this->scopedCoupon((int) $id, true) : null;
        $merchantId = $this->resolveOwnerMerchant($data, $existing);

        // 层级由 (生效方式, 归属商户) 推导：auto+商户→10、auto+平台→20、claim/code→40，
        // 与迁移回填口径一致（无商户的 auto 就是原来的平台活动）
        $tier = isset($data['tier']) ? (int) $data['tier'] : $this->deriveTier($applyType, $merchantId);
        if ($tier === Coupon::TIER_AUTO_GRANT) {
            throw new BizException('「自动到账券」层由营销规则维护，不能在优惠管理里配置');
        }
        if (!isset(Coupon::TIER_APPLY_TYPES[$tier])) {
            throw new BizException('优惠层级不合法');
        }
        if (!in_array($applyType, Coupon::TIER_APPLY_TYPES[$tier], true)) {
            throw new BizException('「' . Coupon::TIER_LABELS[$tier] . '」层不支持该生效方式');
        }
        if ($tier === Coupon::TIER_MERCHANT && $merchantId === null) {
            throw new BizException('「商家折扣」必须指定归属商户');
        }
        if ($tier === Coupon::TIER_PLATFORM && $merchantId !== null) {
            throw new BizException('「平台活动」不能挂到商户名下，请改为「商家折扣」');
        }
        // 全场自动折扣对新配置不开放给商家；存量商家的 auto 记录仍可编辑（需求方 2026-11-16 定案）
        if (!$this->isSuper() && $applyType === Coupon::APPLY_AUTO
            && (!$existing || $existing->apply_type !== Coupon::APPLY_AUTO)) {
            throw new BizException('全场自动生效的折扣由平台配置，本店优惠请使用「前台领取」或「优惠码」');
        }
        $autoApply = $tier === Coupon::TIER_AUTO_GRANT ? 1 : 0;

        $discountType = (string) ($data['discount_type'] ?? Coupon::TYPE_FIXED);
        if (!in_array($discountType, [Coupon::TYPE_PERCENT, Coupon::TYPE_FIXED], true)) {
            throw new BizException('折扣方式不合法');
        }

        $discountValue = $this->decimal($data['discount_value'] ?? 0);
        if (bccomp($discountValue, '0', 2) <= 0) {
            throw new BizException('折扣值必须大于 0');
        }
        if ($discountType === Coupon::TYPE_PERCENT && bccomp($discountValue, '100', 2) > 0) {
            throw new BizException('百分比折扣不能超过 100');
        }

        $minAmount   = $this->decimal($data['min_amount'] ?? 0);
        $maxDiscount = $this->decimal($data['max_discount'] ?? 0);
        if (bccomp($minAmount, '0', 2) < 0 || bccomp($maxDiscount, '0', 2) < 0) {
            throw new BizException('门槛与封顶金额不能为负数');
        }

        $scope = (string) ($data['scope'] ?? Coupon::SCOPE_ALL);
        if (!in_array($scope, [Coupon::SCOPE_ALL, Coupon::SCOPE_PRODUCT], true)) {
            throw new BizException('适用范围不合法');
        }

        $code = trim((string) ($data['code'] ?? ''));
        if ($applyType === Coupon::APPLY_CODE) {
            if ($code === '') {
                throw new BizException('优惠码券必须填写优惠码');
            }
            if (!preg_match('/^[A-Za-z0-9\-]{3,32}$/', $code)) {
                throw new BizException('优惠码只能包含字母、数字与短横线，长度 3-32');
            }
            $code = strtoupper($code);
            $exists = Coupon::where('code', $code)->where('id', '<>', (int) $id)->find();
            if ($exists) {
                throw new BizException('优惠码「' . $code . '」已被占用');
            }
        } else {
            $code = '';
        }

        $startTime = $this->normalizeTime($data['start_time'] ?? '');
        $endTime   = $this->normalizeTime($data['end_time'] ?? '');
        if ($startTime && $endTime && strtotime($startTime) > strtotime($endTime)) {
            throw new BizException('开始时间不能晚于结束时间');
        }

        // 固定到期日优先于 valid_days（expireTime() 的口径），两者同时填不算冲突
        $expireAt = $this->normalizeTime($data['expire_at'] ?? '');
        if ($expireAt && $startTime && strtotime($expireAt) < strtotime($startTime)) {
            throw new BizException('券固定到期日不能早于活动开始时间');
        }

        $productIds = array_values(array_unique(array_filter(array_map('intval', (array) ($data['product_ids'] ?? [])))));
        if ($scope === Coupon::SCOPE_PRODUCT && empty($productIds)) {
            throw new BizException('适用范围为「指定商品」时必须至少选择一个商品');
        }
        if ($scope === Coupon::SCOPE_PRODUCT) {
            $this->assertProductsOwned($productIds, $merchantId);
        }

        $totalQty     = max(0, (int) ($data['total_qty'] ?? 0));
        $perUserLimit = max(0, (int) ($data['per_user_limit'] ?? 1));
        $validDays    = max(0, (int) ($data['valid_days'] ?? 0));
        $sort         = (int) ($data['sort'] ?? 0);
        $status       = (int) ($data['status'] ?? 1) ? 1 : 0;
        $remark       = trim((string) ($data['remark'] ?? ''));

        Db::startTrans();
        try {
            $coupon = $existing ?: new Coupon();

            $coupon->name           = $name;
            $coupon->code           = $code !== '' ? $code : null;
            $coupon->apply_type     = $applyType;
            $coupon->tier           = $tier;
            $coupon->auto_apply     = $autoApply;
            $coupon->merchant_id    = $merchantId;
            $coupon->discount_type  = $discountType;
            $coupon->discount_value = $discountValue;
            $coupon->min_amount     = $minAmount;
            $coupon->max_discount   = $discountType === Coupon::TYPE_PERCENT ? $maxDiscount : '0.00';
            $coupon->scope          = $scope;
            $coupon->total_qty      = $totalQty;
            $coupon->per_user_limit = $perUserLimit;
            $coupon->valid_days     = $validDays;
            $coupon->expire_at      = $expireAt;
            $coupon->start_time     = $startTime;
            $coupon->end_time       = $endTime;
            $coupon->status         = $status;
            $coupon->sort           = $sort;
            $coupon->remark         = $remark !== '' ? $remark : null;
            $coupon->save();

            $couponId = (int) $coupon->id;

            // 全站券清空商品范围；商品券整体覆盖写入
            CouponProduct::where('coupon_id', $couponId)->delete();
            if ($scope === Coupon::SCOPE_PRODUCT) {
                foreach ($productIds as $productId) {
                    $row = new CouponProduct();
                    $row->coupon_id  = $couponId;
                    $row->product_id = $productId;
                    $row->save();
                }
            }

            Db::commit();
            return $couponId;
        } catch (\Throwable $e) {
            Db::rollback();
            throw $e;
        }
    }

    /**
     * 启用 / 停用优惠
     *
     * @param int $id     优惠 ID
     * @param int $status 1 启用 / 0 停用
     * @return void
     * @throws BizException
     */
    public function adminToggle(int $id, int $status): void
    {
        $coupon = $this->scopedCoupon($id, true);
        $coupon->status = $status ? 1 : 0;
        $coupon->save();
    }

    /**
     * 删除优惠（连带清理适用范围与领取记录）
     *
     * @param int $id 优惠 ID
     * @return void
     * @throws BizException
     */
    public function adminDelete(int $id): void
    {
        $coupon = $this->scopedCoupon($id, true);
        Db::startTrans();
        try {
            CouponProduct::where('coupon_id', $id)->delete();
            CouponUser::where('coupon_id', $id)->delete();
            $coupon->delete();
            Db::commit();
        } catch (\Throwable $e) {
            Db::rollback();
            throw $e;
        }
    }

    /**
     * 后台表单「指定商品」选择器数据
     *
     * 商家只返回本商户上架商品：作用范围只能圈自己的货，
     * 保存时再用 assertProductsOwned() 兜一道，不能只靠前端下拉。
     *
     * @return array<int,array{id:int,title:string}>
     */
    public function productOptions(): array
    {
        $query = Product::where('status', 1);
        if (!$this->isSuper()) {
            $merchantIds = $this->merchantIds();
            if (empty($merchantIds)) {
                return [];
            }
            $query->whereIn('merchant_id', $merchantIds);
        }

        $out = [];
        foreach ($query->order('id', 'desc')->field('id,title')->select() as $product) {
            $out[] = ['id' => (int) $product->id, 'title' => (string) $product->title];
        }
        return $out;
    }

    /**
     * 取一条优惠并收敛到当前管理员的可见范围
     *
     * 三种结果的口径是刻意分开的：
     * - 他店记录 → 「优惠不存在」，不给枚举 ID 提供反馈；
     * - 平台记录（merchant_id IS NULL）→ 可读；写操作给「平台优惠不可修改」，
     *   这句是产品文案（商家本来就看得见这张活动），不构成额外的信息泄露；
     * - 本店记录 → 放行。
     *
     * @param int  $id       优惠 ID
     * @param bool $forWrite 是否为写操作
     * @return Coupon
     * @throws BizException
     */
    private function scopedCoupon(int $id, bool $forWrite = false): Coupon
    {
        $coupon = Coupon::find($id);
        if (!$coupon) {
            throw new BizException('优惠不存在');
        }
        if ($this->isSuper()) {
            return $coupon;
        }

        $merchantId = $coupon->merchant_id === null ? null : (int) $coupon->merchant_id;
        if ($merchantId === null) {
            if ($forWrite) {
                throw new BizException('平台优惠不可修改，如需本店促销请新建优惠');
            }
            return $coupon;
        }
        if (!$this->canWrite($merchantId)) {
            throw new BizException('优惠不存在');
        }
        return $coupon;
    }

    /**
     * 当前管理员是否能写这条归属的记录
     *
     * @param int|null $merchantId 记录的归属商户
     * @return bool
     */
    private function canWrite(?int $merchantId): bool
    {
        if ($this->isSuper()) {
            return true;
        }
        return $merchantId !== null && in_array($merchantId, $this->merchantIds(), true);
    }

    /**
     * 归属商户判定：商家一律落自己名下的商户，超管可显式指定
     *
     * 更新时沿用原归属，避免多商户员工编辑一条记录时把商户改成自己的第一个商户；
     * 超管更新时同理，只有请求里显式带了 merchant_id 才改归属（留空 = 迁到平台）。
     * 非超管传来的 merchant_id 不报错也不生效：他店 ID 只会被静默覆盖成本人商户，
     * 报错等于告诉对方「这个商户存在」。
     *
     * @param array        $data     表单数据
     * @param Coupon|null  $existing 更新时的原记录
     * @return int|null
     * @throws BizException 超管指定了不存在的商户
     */
    private function resolveOwnerMerchant(array $data, ?Coupon $existing): ?int
    {
        if ($this->isSuper()) {
            if ($existing !== null && !array_key_exists('merchant_id', $data)) {
                return $existing->merchant_id === null ? null : (int) $existing->merchant_id;
            }
            $merchantId = (int) ($data['merchant_id'] ?? 0);
            if ($merchantId <= 0) {
                return null;
            }
            if (!Merchant::where('id', $merchantId)->value('id')) {
                throw new BizException('归属商户不存在');
            }
            return $merchantId;
        }

        if ($existing !== null) {
            return $existing->merchant_id === null ? null : (int) $existing->merchant_id;
        }

        $merchantIds = $this->merchantIds();
        if (empty($merchantIds)) {
            throw new BizException('当前账号未绑定商户，无法创建本店优惠');
        }
        $requested = (int) ($data['merchant_id'] ?? 0);
        return in_array($requested, $merchantIds, true) ? $requested : (int) $merchantIds[0];
    }

    /**
     * 由生效方式与归属商户推导层级
     *
     * @param string   $applyType  生效方式
     * @param int|null $merchantId 归属商户
     * @return int
     */
    private function deriveTier(string $applyType, ?int $merchantId): int
    {
        if ($applyType !== Coupon::APPLY_AUTO) {
            return Coupon::TIER_MANUAL;
        }
        return $merchantId === null ? Coupon::TIER_PLATFORM : Coupon::TIER_MERCHANT;
    }

    /**
     * 指定商品范围必须全部属于优惠的归属商户
     *
     * @param array    $productIds 提交的商品 ID
     * @param int|null $merchantId 归属商户（null = 平台，不限商户）
     * @return void
     * @throws BizException
     */
    private function assertProductsOwned(array $productIds, ?int $merchantId): void
    {
        $owners = $this->productMerchantMap($productIds);
        if (count($owners) !== count($productIds)) {
            throw new BizException('适用商品里有不存在或已删除的商品，请重新选择');
        }
        if ($merchantId === null) {
            return;
        }
        foreach ($owners as $owner) {
            if ((int) $owner !== $merchantId) {
                throw new BizException('本店优惠只能选择本商户的商品');
            }
        }
    }

    /**
     * 批量取商品归属商户（product_id => merchant_id），一次查全
     *
     * 走 db(['merchant']) 关掉 MerchantScope 注入：商品归属是客观事实，
     * 不能因为「谁在算这笔优惠」而给出不同结果（超管后台预览与用户结算必须一致）。
     *
     * @param array $productIds 商品 ID
     * @return array<int,int>
     */
    private function productMerchantMap(array $productIds): array
    {
        $missing = [];
        foreach (array_unique(array_map('intval', $productIds)) as $productId) {
            if ($productId > 0 && !isset($this->productMerchantCache[$productId])) {
                $missing[] = $productId;
            }
        }
        if ($missing) {
            $rows = (new Product())->db(['merchant'])->whereIn('id', $missing)->column('merchant_id', 'id');
            foreach ($rows as $productId => $owner) {
                $this->productMerchantCache[(int) $productId] = (int) $owner;
            }
        }

        $map = [];
        foreach ($productIds as $productId) {
            $productId = (int) $productId;
            if (isset($this->productMerchantCache[$productId])) {
                $map[$productId] = $this->productMerchantCache[$productId];
            }
        }
        return $map;
    }

    /**
     * 批量取商户名，避免逐行查库
     *
     * @param array $merchantIds 可能含 null 的归属商户 ID 列表
     * @return array<int,string>
     */
    private function merchantNames(array $merchantIds): array
    {
        $ids = [];
        foreach ($merchantIds as $merchantId) {
            if ($merchantId !== null && (int) $merchantId > 0) {
                $ids[] = (int) $merchantId;
            }
        }
        return $ids ? Merchant::whereIn('id', array_unique($ids))->column('name', 'id') : [];
    }

    /**
     * 当前后台账号是否为平台超管
     *
     * @return bool
     */
    private function isSuper(): bool
    {
        return AppContext::getAdminRole() === AdminRole::SUPER;
    }

    /**
     * 当前后台账号绑定的商户 ID
     *
     * @return array<int,int>
     */
    private function merchantIds(): array
    {
        return array_values(array_filter(array_map('intval', AppContext::getMerchantIds())));
    }

    // ------------------------------------------------------------------
    // 前台：领取
    // ------------------------------------------------------------------

    /**
     * 当前用户可领取的优惠列表（仅「前台领取」类型）
     *
     * 优惠码券（apply_type=code）不在此列，需在结算页手动输入优惠码使用；
     * 自动发放层（tier=30，新人券/返利券）由系统直接到账，也不允许用户自己领。
     *
     * @param int $userId 用户 ID
     * @return array<int,array>
     */
    public function claimableList(int $userId): array
    {
        $out = [];
        $coupons = $this->activeQuery()
            ->where('apply_type', Coupon::APPLY_CLAIM)
            ->where('tier', '<>', Coupon::TIER_AUTO_GRANT)
            ->order('sort')->order('id', 'desc')
            ->select();
        foreach ($coupons as $coupon) {
            $limit = (int) $coupon->per_user_limit;
            $claimed = $limit > 0
                ? (int) CouponUser::where('coupon_id', $coupon->id)->where('user_id', $userId)->count()
                : 0;
            $out[] = [
                'id'             => (int) $coupon->id,
                'name'           => (string) $coupon->name,
                'discount_type'  => (string) $coupon->discount_type,
                'discount_value' => (string) $coupon->discount_value,
                'min_amount'     => (string) $coupon->min_amount,
                'scope'          => (string) $coupon->scope,
                'end_time'       => (string) ($coupon->end_time ?? ''),
                'discount_text'  => self::discountText($coupon),
                'remark'         => (string) ($coupon->remark ?? ''),
                'claimable'      => $limit === 0 || $claimed < $limit,
            ];
        }
        return $out;
    }

    /**
     * 发放一张券给用户 —— 全站唯一的发券出口
     *
     * 前台领取（claim）与营销规则发放都必须走这里：行锁 + 库存与每人上限校验 + 写券实例 +
     * claimed_qty 递增在同一段事务里完成，并发不会超发，也避免出现第二条「偷偷发券」的路径。
     * 调用方只负责判断「该不该发」（活动期、身份、预算），不自己拼 coupon_user。
     *
     * @param Coupon $coupon            券模板
     * @param int    $userId            用户 ID
     * @param string $overLimitMessage  超过每人上限时的提示（系统发放场景不叫「领取」）
     * @return CouponUser 券实例
     * @throws BizException 券已停用 / 已发完 / 超过每人上限
     */
    public function issue(Coupon $coupon, int $userId, string $overLimitMessage = '您已领取过该优惠券'): CouponUser
    {
        Db::startTrans();
        try {
            $locked = Coupon::where('id', (int) $coupon->id)->lock(true)->find();
            if (!$locked) {
                throw new BizException('优惠券不存在');
            }
            if ((int) $locked->status !== 1) {
                throw new BizException('优惠券已停用');
            }
            if ((int) $locked->total_qty > 0 && (int) $locked->claimed_qty >= (int) $locked->total_qty) {
                throw new BizException('优惠券已被领完');
            }

            $limit = (int) $locked->per_user_limit;
            if ($limit > 0) {
                $count = (int) CouponUser::where('coupon_id', (int) $locked->id)->where('user_id', $userId)->count();
                if ($count >= $limit) {
                    throw new BizException($overLimitMessage);
                }
            }

            $record = new CouponUser();
            $record->coupon_id   = (int) $locked->id;
            $record->user_id     = $userId;
            $record->code        = $locked->code ?: null;
            $record->status      = CouponUser::STATUS_UNUSED;
            $record->expire_time = $this->expireTime($locked);
            $record->save();

            $locked->claimed_qty = (int) $locked->claimed_qty + 1;
            $locked->save();

            Db::commit();
            return $record;
        } catch (\Throwable $e) {
            Db::rollback();
            throw $e;
        }
    }

    /**
     * 领取优惠券（存在并发，加行锁保证不超发）
     *
     * @param int $couponId 优惠 ID
     * @param int $userId   用户 ID
     * @return CouponUser 领取记录
     * @throws BizException
     */
    public function claim(int $couponId, int $userId): CouponUser
    {
        $coupon = Coupon::find($couponId);
        if (!$coupon) {
            throw new BizException('优惠券不存在');
        }
        if ((string) $coupon->apply_type === Coupon::APPLY_AUTO) {
            throw new BizException('该优惠无需领取，结算时自动生效');
        }
        if ((string) $coupon->apply_type === Coupon::APPLY_CODE) {
            throw new BizException('该优惠为优惠码，请在结算页输入优惠码使用');
        }
        if ((int) $coupon->tier === Coupon::TIER_AUTO_GRANT) {
            throw new BizException('该优惠券由系统发放，无需领取');
        }
        if ((int) $coupon->status !== 1) {
            throw new BizException('优惠券已停用');
        }
        if (!$this->isActiveNow($coupon)) {
            throw new BizException('优惠券不在活动时间内');
        }

        return $this->issue($coupon, $userId);
    }

    // ------------------------------------------------------------------
    // 折扣试算与核销
    // ------------------------------------------------------------------

    /**
     * 归一化结算商品行，统一为 [['product_id'=>int,'subtotal'=>'12.00'], ...]
     *
     * @param array $items 每项含 product_id 与 subtotal（或 price+quantity）
     * @return array<int,array{product_id:int,subtotal:string}>
     */
    public function normalizeRows(array $items): array
    {
        $rows = [];
        foreach ($items as $item) {
            $productId = (int) ($item['product_id'] ?? 0);
            $subtotal = isset($item['subtotal'])
                ? $this->decimal($item['subtotal'])
                : bcmul($this->decimal($item['price'] ?? 0), (string) max(0, (int) ($item['quantity'] ?? 0)), 2);
            $rows[] = ['product_id' => $productId, 'subtotal' => $subtotal];
        }
        return $rows;
    }

    /**
     * 折扣试算：按层级顺序计算优惠，返回逐层明细与实付金额
     *
     * 层顺序（Coupon::TIER_LABELS）为 商家折扣 → 平台活动 → 自动到账券 → 手动券/优惠码，
     * 前三个自动层依次吃掉余额，最后一个手动层只能在剩余额度里继续减；
     * 门槛（min_amount）始终按原价基数判定，不受上层优惠影响。
     *
     * @param array    $rows           归一化商品行
     * @param string   $subtotal       商品小计
     * @param int      $userId         用户 ID
     * @param int|null $couponUserId   已领取券记录 ID（可选）
     * @param string   $code           优惠码（可选）
     * @return array{lines:array,discount:string,payable:string,coupon_user_id:?int,code_coupon_id:?int,auto_coupon_user_ids:array,no_threshold_coupon_user_id:?int,no_threshold_notice:string,min_payable:string,min_payable_met:bool,min_payable_shortfall:string}
     * @throws BizException 优惠码/券不可用时抛出，供前台提示
     */
    public function quote(array $rows, string $subtotal, int $userId, ?int $couponUserId = null, string $code = ''): array
    {
        $subtotal = $this->decimal($subtotal);
        $lines = [];
        $total = '0.00';
        $remaining = $subtotal;
        $autoCouponUserIds = [];

        // 先解析手动券/优惠码（只解析不应用）：后面要和自动无门槛券比一次「谁更优惠」
        $manual = $this->resolveUserCoupon($userId, $couponUserId, $code, $rows, $subtotal);
        $manualCoupon = $manual[0] ?? null;
        $manualRecord = $manual[1] ?? null;
        $manualIsNoThreshold = $manualCoupon !== null && $this->isFixedNoThreshold($manualCoupon);

        // 自动层拆成两组：普通优惠（折扣/满减/平台活动）与固定金额无门槛券（一单只能用一张）
        $normalAuto = [];
        $noThresholdAuto = [];
        foreach ($this->autoLayerItems($userId) as $item) {
            if ($this->isFixedNoThreshold($item['coupon'])) {
                $noThresholdAuto[] = $item;
            } else {
                $normalAuto[] = $item;
            }
        }

        // 1）普通自动优惠：商家折扣、平台活动、折扣/满减型到账券
        foreach ($normalAuto as $item) {
            $amount = $this->layerAmount($item['coupon'], $rows, $subtotal, $remaining);
            if (bccomp($amount, '0', 2) <= 0) {
                continue;
            }
            $this->pushLine($lines, $total, $remaining, $item['coupon'], $amount, $item['source'], $item['coupon_user_id']);
            if ($item['coupon_user_id'] !== null) {
                $autoCouponUserIds[] = (int) $item['coupon_user_id'];
            }
        }

        // 2）固定金额无门槛券：自动候选与手动券里只留减免最大的一张
        $couponUserIdResult = null;
        $codeCouponIdResult = null;
        $noThresholdCouponUserId = null;
        $noThresholdNotice = '';
        $bestAuto = $this->bestNoThresholdItem($noThresholdAuto, $rows, $subtotal, $remaining);

        if ($manualIsNoThreshold) {
            $manualAmount = $this->computeAmount($manualCoupon, $rows, $subtotal);
            $manualCapped = $this->capToRemaining($manualCoupon, $rows, $subtotal, $manualAmount, $remaining);
            $bestAmount = $bestAuto['amount'] ?? '0.00';

            if (bccomp($manualCapped, $bestAmount, 2) >= 0) {
                if (bccomp($manualAmount, '0', 2) <= 0) {
                    throw new BizException($this->ineligibleReason($manualCoupon, $rows, $subtotal));
                }
                if (bccomp($manualCapped, '0', 2) > 0) {
                    $this->pushLine(
                        $lines,
                        $total,
                        $remaining,
                        $manualCoupon,
                        $manualCapped,
                        $manualRecord !== null ? 'coupon' : 'code',
                        $manualRecord !== null ? (int) $manualRecord->id : null
                    );
                    if ($manualRecord !== null) {
                        $couponUserIdResult = (int) $manualRecord->id;
                        $noThresholdCouponUserId = (int) $manualRecord->id;
                    } else {
                        $codeCouponIdResult = (int) $manualCoupon->id;
                    }
                }
            } else {
                // 手动选的券不如自动券：不核销手动券，仍给消费者最大优惠
                $this->applyBestNoThreshold($bestAuto, $lines, $total, $remaining, $autoCouponUserIds, $noThresholdCouponUserId);
                $noThresholdNotice = '已自动使用优惠更大的无门槛券';
            }
        } else {
            $this->applyBestNoThreshold($bestAuto, $lines, $total, $remaining, $autoCouponUserIds, $noThresholdCouponUserId);
        }

        // 3）手动券/优惠码（非固定无门槛券）：沿用原来的二选一逻辑
        if ($manualCoupon !== null && !$manualIsNoThreshold) {
            $amount = $this->computeAmount($manualCoupon, $rows, $subtotal);
            if (bccomp($amount, '0', 2) <= 0) {
                throw new BizException($this->ineligibleReason($manualCoupon, $rows, $subtotal));
            }
            $capped = $this->capToRemaining($manualCoupon, $rows, $subtotal, $amount, $remaining);
            if (bccomp($capped, '0', 2) > 0) {
                if ($manualRecord !== null) {
                    $couponUserIdResult = (int) $manualRecord->id;
                } else {
                    $codeCouponIdResult = (int) $manualCoupon->id;
                }
                $this->pushLine(
                    $lines,
                    $total,
                    $remaining,
                    $manualCoupon,
                    $capped,
                    $manualRecord !== null ? 'coupon' : 'code',
                    $couponUserIdResult
                );
            }
        }

        // 4）防御性兜底：总优惠不超过商品小计，超出部分从后往前扣减明细
        if (bccomp($total, $subtotal, 2) > 0) {
            $excess = bcsub($total, $subtotal, 2);
            for ($i = count($lines) - 1; $i >= 0 && bccomp($excess, '0', 2) > 0; $i--) {
                $lineAmount = $lines[$i]['amount'];
                if (bccomp($lineAmount, $excess, 2) >= 0) {
                    $lines[$i]['amount'] = bcsub($lineAmount, $excess, 2);
                    $excess = '0.00';
                } else {
                    $lines[$i]['amount'] = '0.00';
                    $excess = bcsub($excess, $lineAmount, 2);
                }
            }
            $lines = array_values(array_filter($lines, fn($line) => bccomp($line['amount'], '0', 2) > 0));
            $total = $subtotal;
        }

        $payable = bcsub($subtotal, $total, 2);
        $minPayable = min_payable_amount();
        $shortfall = '0.00';
        if (bccomp($minPayable, '0', 2) > 0 && bccomp($payable, $minPayable, 2) < 0) {
            $shortfall = bcsub($minPayable, $payable, 2);
        }

        return [
            'lines'                => $lines,
            'discount'             => $total,
            'payable'              => $payable,
            'coupon_user_id'       => $couponUserIdResult,
            'code_coupon_id'       => $codeCouponIdResult,
            'auto_coupon_user_ids' => $autoCouponUserIds,
            'no_threshold_coupon_user_id' => $noThresholdCouponUserId,
            'no_threshold_notice'  => $noThresholdNotice,
            'min_payable'          => $minPayable,
            'min_payable_met'      => bccomp($shortfall, '0', 2) === 0,
            'min_payable_shortfall' => $shortfall,
        ];
    }

    /**
     * 追加一条优惠明细并推进总额/余额
     */
    private function pushLine(
        array &$lines,
        string &$total,
        string &$remaining,
        Coupon $coupon,
        string $amount,
        string $source,
        ?int $couponUserId
    ): void {
        if (bccomp($amount, '0', 2) <= 0) {
            return;
        }
        $lines[] = $this->line($coupon, $amount, $source, $couponUserId);
        $total = bcadd($total, $amount, 2);
        $remaining = bcsub($remaining, $amount, 2);
    }

    /**
     * 固定金额无门槛券：min_amount=0 且 discount_type=fixed，且属于用户持有的券层
     */
    private function isFixedNoThreshold(Coupon $coupon): bool
    {
        return (int) $coupon->tier >= Coupon::TIER_AUTO_GRANT
            && (string) $coupon->discount_type === Coupon::TYPE_FIXED
            && bccomp((string) $coupon->min_amount, '0', 2) === 0;
    }

    /**
     * 在候选自动无门槛券里选本单减免最大的一张
     *
     * @param array<int,array{coupon:Coupon,source:string,coupon_user_id:?int}> $items
     * @return array{item:array,amount:string}|null
     */
    private function bestNoThresholdItem(array $items, array $rows, string $base, string $remaining): ?array
    {
        $best = null;
        foreach ($items as $item) {
            $amount = $this->layerAmount($item['coupon'], $rows, $base, $remaining);
            if (bccomp($amount, '0', 2) <= 0) {
                continue;
            }
            if ($best === null || bccomp($amount, $best['amount'], 2) > 0) {
                $best = ['item' => $item, 'amount' => $amount];
            }
        }
        return $best;
    }

    /**
     * 应用选中的自动无门槛券
     */
    private function applyBestNoThreshold(
        ?array $best,
        array &$lines,
        string &$total,
        string &$remaining,
        array &$autoCouponUserIds,
        ?int &$noThresholdCouponUserId
    ): void {
        if ($best === null) {
            return;
        }
        $item = $best['item'];
        $this->pushLine($lines, $total, $remaining, $item['coupon'], $best['amount'], $item['source'], $item['coupon_user_id']);
        if ($item['coupon_user_id'] !== null) {
            $autoCouponUserIds[] = (int) $item['coupon_user_id'];
            $noThresholdCouponUserId = (int) $item['coupon_user_id'];
        }
    }

    /**
     * 自动生效层的候选优惠，按层级顺序返回
     *
     * @param int $userId 用户 ID
     * @return array<int,array{coupon:Coupon,source:string,coupon_user_id:?int}>
     */
    private function autoLayerItems(int $userId): array
    {
        $items = [];
        $layers = [
            Coupon::TIER_MERCHANT => 'merchant',
            Coupon::TIER_PLATFORM => 'activity',
        ];
        foreach ($layers as $tier => $source) {
            // 商家折扣只作用于归属商户的商品行，收敛点在 eligibleBase()（基数为 0 时自然不产出明细）
            $coupons = $this->activeQuery()->where('tier', $tier)->order('sort')->order('id')->select();
            foreach ($coupons as $coupon) {
                $items[] = ['coupon' => $coupon, 'source' => $source, 'coupon_user_id' => null];
            }
        }
        foreach ($this->heldAutoCoupons($userId) as $item) {
            $items[] = ['coupon' => $item['coupon'], 'source' => 'rebate', 'coupon_user_id' => $item['coupon_user_id']];
        }
        return $items;
    }

    /**
     * 用户持有、到账即自动抵扣的券（tier=30）
     *
     * 只按券实例的 expire_time 判过期，不再看活动的 start_time/end_time：
     * 活动停了只影响「还能不能再发」，已发到账户里的券要能用满自己的有效期。
     * 这与 tier 40 走 isActiveNow() 的口径**故意不同**（营销规则发的券一旦到账就是用户资产，
     * 活动一停就失效属于资损），改动 quote() 时不要顺手把两处统一成一个判断。
     *
     * @param int $userId 用户 ID
     * @return array<int,array{coupon:Coupon,coupon_user_id:int}>
     */
    private function heldAutoCoupons(int $userId): array
    {
        if ($userId <= 0) {
            return [];
        }
        $now = date('Y-m-d H:i:s');
        $holdings = CouponUser::where('user_id', $userId)
            ->where('status', CouponUser::STATUS_UNUSED)
            ->where(function ($q) use ($now) {
                $q->whereNull('expire_time')->whereOr('expire_time', '>=', $now);
            })
            ->order('id')
            ->column('coupon_id', 'id');
        if (empty($holdings)) {
            return [];
        }

        $coupons = Coupon::whereIn('id', array_unique(array_map('intval', $holdings)))
            ->where('status', 1)
            ->where('tier', Coupon::TIER_AUTO_GRANT)
            ->where('auto_apply', 1)
            ->order('sort')->order('id')
            ->select();

        $items = [];
        foreach ($coupons as $coupon) {
            foreach ($holdings as $recordId => $couponId) {
                if ((int) $couponId === (int) $coupon->id) {
                    $items[] = ['coupon' => $coupon, 'coupon_user_id' => (int) $recordId];
                }
            }
        }
        return $items;
    }

    /**
     * 自动层单条优惠的减免额：先按原价基数算，再被本层剩余额度截断
     *
     * @param Coupon $coupon    优惠
     * @param array  $rows      归一化商品行
     * @param string $base      原价商品小计（门槛判定用）
     * @param string $remaining 上层扣完后的余额
     * @return string
     */
    private function layerAmount(Coupon $coupon, array $rows, string $base, string $remaining): string
    {
        $amount = $this->computeAmount($coupon, $rows, $base);
        if (bccomp($amount, '0', 2) <= 0) {
            return '0.00';
        }
        return $this->capToRemaining($coupon, $rows, $base, $amount, $remaining);
    }

    /**
     * 把减免额压进剩余额度：商品券最多只能减到命中商品的金额
     *
     * @param Coupon $coupon    优惠
     * @param array  $rows      归一化商品行
     * @param string $base      原价商品小计
     * @param string $amount    未截断的减免额
     * @param string $remaining 剩余额度
     * @return string
     */
    private function capToRemaining(Coupon $coupon, array $rows, string $base, string $amount, string $remaining): string
    {
        $cap = $this->eligibleBase($coupon, $rows, $base);
        if (bccomp($cap, $remaining, 2) > 0) {
            $cap = $remaining;
        }
        return bccomp($amount, $cap, 2) > 0 ? $cap : $amount;
    }

    /**
     * 生效中的平台大促（tier=20 全站自动活动），供前台站内横幅使用
     *
     * 大促只自动生效 + 站内告知，不发主动邮件（2026-11-16 决策）；没有生效活动时返回空数组。
     *
     * @param int $limit 最多返回活动数
     * @return array<int,array{id:int,name:string,discount_text:string,start_time:string,end_time:string}>
     */
    public function activePlatformPromotions(int $limit = 3): array
    {
        $rows = $this->activeQuery()
            ->where('tier', Coupon::TIER_PLATFORM)
            ->where('apply_type', Coupon::APPLY_AUTO)
            ->order('sort')
            ->order('id')
            ->limit(max(1, $limit))
            ->select();

        $out = [];
        foreach ($rows as $coupon) {
            $out[] = [
                'id'            => (int) $coupon->id,
                'name'          => (string) $coupon->name,
                'discount_text' => self::discountText($coupon),
                'start_time'    => (string) ($coupon->start_time ?? ''),
                'end_time'      => (string) ($coupon->end_time ?? ''),
            ];
        }
        return $out;
    }

    /**
     * 我的优惠券（账户中心三个 tab：未使用 / 已使用 / 已过期）
     *
     * 与 {@see myAvailableCoupons()} 的区别：那边是「结算页可用券试算」，这里只做展示，
     * 不依赖购物车行，也不按门槛过滤；已过期按「状态=过期」或「未使用但 expire_time 已过」判定。
     * 返回计数供 tab 角标使用；已作废（退款回收）归入「已使用」tab，状态文案单独标出。
     *
     * @param int    $userId 用户
     * @param string $tab    unused / used / expired；空=全部
     * @param int    $limit  单次最多返回条数
     * @return array{list:array,counts:array{unused:int,used:int,expired:int}}
     */
    public function myCoupons(int $userId, string $tab = '', int $limit = 100): array
    {
        $records = CouponUser::where('user_id', $userId)->order('id', 'desc')->select();

        $couponIds = [];
        foreach ($records as $record) {
            $couponIds[] = (int) $record->coupon_id;
        }
        $coupons = [];
        if ($couponIds) {
            foreach (Coupon::whereIn('id', array_unique($couponIds))->select() as $coupon) {
                $coupons[(int) $coupon->id] = $coupon;
            }
        }

        $counts = ['unused' => 0, 'used' => 0, 'expired' => 0];
        $list   = [];
        $now    = time();

        foreach ($records as $record) {
            $coupon = $coupons[(int) $record->coupon_id] ?? null;
            if (!$coupon) {
                continue;
            }

            $status  = (int) $record->status;
            $expire  = (string) ($record->expire_time ?? '');
            $expired = $status === CouponUser::STATUS_EXPIRED
                || ($status === CouponUser::STATUS_UNUSED && $expire !== '' && strtotime($expire) !== false && strtotime($expire) <= $now);

            if ($expired) {
                $bucket = 'expired';
                $label  = '已过期';
            } elseif ($status === CouponUser::STATUS_USED) {
                $bucket = 'used';
                $label  = '已使用';
            } elseif ($status === CouponUser::STATUS_REVOKED) {
                $bucket = 'used';
                $label  = '已失效';
            } else {
                $bucket = 'unused';
                $label  = '未使用';
            }

            $counts[$bucket]++;

            if ($tab !== '' && $tab !== $bucket) {
                continue;
            }
            if (count($list) >= max(1, $limit)) {
                continue;
            }

            $autoApply = (int) $coupon->auto_apply === 1;
            $list[] = [
                'coupon_user_id' => (int) $record->id,
                'coupon_id'      => (int) $coupon->id,
                'name'           => (string) $coupon->name,
                'discount_text'  => self::discountText($coupon),
                'min_amount'     => (string) $coupon->min_amount,
                'expire_time'    => $expire,
                'status'         => $status,
                'status_label'   => $label,
                'tab'            => $bucket,
                'auto_apply'     => $autoApply ? 1 : 0,
                'tier'           => (int) $coupon->tier,
                'tier_label'     => Coupon::TIER_LABELS[(int) $coupon->tier] ?? '',
                'scope'          => (string) $coupon->scope,
                'scope_label'    => (string) $coupon->scope === Coupon::SCOPE_PRODUCT ? '指定商品可用' : '全场通用',
                'use_type'       => $autoApply ? 'auto' : ((string) $coupon->apply_type === Coupon::APPLY_CODE ? 'code' : 'manual'),
            ];
        }

        return ['list' => $list, 'counts' => $counts];
    }

    /**
     * 当前用户在给定购物车下可用的已领取券列表
     *
     * @param int    $userId   用户 ID
     * @param array  $rows     归一化商品行
     * @param string $subtotal 商品小计
     * @return array<int,array>
     */
    public function myAvailableCoupons(int $userId, array $rows, string $subtotal): array
    {
        $subtotal = $this->decimal($subtotal);
        $out = [];
        $records = CouponUser::where('user_id', $userId)
            ->where('status', CouponUser::STATUS_UNUSED)
            ->order('id', 'desc')
            ->select();

        $couponIds = [];
        foreach ($records as $record) {
            $couponIds[] = (int) $record->coupon_id;
        }
        if (empty($couponIds)) {
            return $out;
        }
        $coupons = [];
        foreach (Coupon::whereIn('id', array_unique($couponIds))->where('status', 1)->select() as $coupon) {
            $coupons[(int) $coupon->id] = $coupon;
        }

        // 先算出本单最优的固定金额无门槛券，后续把更小的无门槛券标成不可选
        $prepared = [];
        $bestNoThresholdAmount = '0.00';
        foreach ($records as $record) {
            $coupon = $coupons[(int) $record->coupon_id] ?? null;
            if (!$coupon) {
                continue;
            }
            if ($record->expire_time && strtotime((string) $record->expire_time) < time()) {
                continue;
            }
            $amount = $this->computeAmount($coupon, $rows, $subtotal);
            $noThreshold = $this->isFixedNoThreshold($coupon);
            if ($noThreshold && bccomp($amount, $bestNoThresholdAmount, 2) > 0) {
                $bestNoThresholdAmount = $amount;
            }
            $prepared[] = [$record, $coupon, $amount, $noThreshold];
        }

        foreach ($prepared as [$record, $coupon, $amount, $noThreshold]) {
            $usable = bccomp($amount, '0', 2) > 0;
            $reason = $usable ? '' : $this->ineligibleReason($coupon, $rows, $subtotal);
            if ($usable && $noThreshold && bccomp($amount, $bestNoThresholdAmount, 2) < 0) {
                $usable = false;
                $reason = '无门槛券每单限用 1 张，系统优先使用优惠最大的无门槛券';
            }
            $out[] = [
                'coupon_user_id' => (int) $record->id,
                'coupon_id'      => (int) $coupon->id,
                'name'           => (string) $coupon->name,
                'tier'           => (int) $coupon->tier,
                'auto_apply'     => (int) $coupon->auto_apply,
                'no_threshold'   => $noThreshold,
                'discount_text'  => self::discountText($coupon),
                'discount_value' => (string) $coupon->discount_value,
                'min_amount'     => (string) $coupon->min_amount,
                'expire_time'    => (string) ($record->expire_time ?? ''),
                'usable'         => $usable,
                'amount'         => $amount,
                'reason'         => $reason,
            ];
        }
        return $out;
    }

    /**
     * 核销优惠（下单成功后调用）：使用已领券 / 记录优惠码使用 / 核销自动抵扣券
     *
     * @param int|null    $couponUserId       已领取券记录 ID
     * @param int|null    $codeCouponId       优惠码券 ID
     * @param int         $userId             用户 ID
     * @param int         $orderPayId         支付单 ID
     * @param array       $autoCouponUserIds  本单实际抵扣到的自动发放券记录 ID（tier=30）
     * @return void
     */
    public function consume(?int $couponUserId, ?int $codeCouponId, int $userId, int $orderPayId, array $autoCouponUserIds = []): void
    {
        if ($couponUserId) {
            $record = CouponUser::where('id', $couponUserId)->where('user_id', $userId)->find();
            if ($record && (int) $record->status === CouponUser::STATUS_UNUSED) {
                $record->status      = CouponUser::STATUS_USED;
                $record->order_pay_id = $orderPayId;
                $record->used_at     = date('Y-m-d H:i:s');
                $record->save();
                Coupon::where('id', $record->coupon_id)->inc('used_qty')->update();
            }
        }

        if ($codeCouponId) {
            $coupon = Coupon::find($codeCouponId);
            if ($coupon) {
                $record = new CouponUser();
                $record->coupon_id    = (int) $coupon->id;
                $record->user_id      = $userId;
                $record->code         = $coupon->code ?: null;
                $record->status       = CouponUser::STATUS_USED;
                $record->order_pay_id = $orderPayId;
                $record->used_at      = date('Y-m-d H:i:s');
                $record->save();
                $coupon->used_qty = (int) $coupon->used_qty + 1;
                $coupon->save();
            }
        }

        if (empty($autoCouponUserIds)) {
            return;
        }
        $records = CouponUser::whereIn('id', array_map('intval', $autoCouponUserIds))
            ->where('user_id', $userId)
            ->column('coupon_id', 'id');
        foreach ($records as $recordId => $couponId) {
            // 状态写在条件里，同一张券被并发下单时只有一次能核销成功
            $affected = CouponUser::where('id', (int) $recordId)
                ->where('status', CouponUser::STATUS_UNUSED)
                ->update([
                    'status'       => CouponUser::STATUS_USED,
                    'order_pay_id' => $orderPayId,
                    'used_at'      => date('Y-m-d H:i:s'),
                ]);
            if ($affected) {
                Coupon::where('id', $couponId)->inc('used_qty')->update();
            }
        }
    }

    /**
     * 回收一张未使用的券（订单全额退款时作废该单挣到的奖励券）
     *
     * 只针对「这单挣到的券」；「这单花掉的券」返还是另一条路径（coupon-refund-restore），
     * 两者不要共用方法。条件更新保证只有仍未使用的券会被作废：已核销的不追回，
     * 因为抵扣已经反映在这笔实付里，追回等于向用户要钱。
     *
     * @param int $couponUserId 券实例 ID
     * @return bool 是否真的回收了（false 表示券已使用/已失效，或记录不存在）
     */
    public function revokeCoupon(int $couponUserId): bool
    {
        $couponId = (int) CouponUser::where('id', $couponUserId)->value('coupon_id');
        if ($couponId <= 0) {
            return false;
        }

        $affected = CouponUser::where('id', $couponUserId)
            ->where('status', CouponUser::STATUS_UNUSED)
            ->update(['status' => CouponUser::STATUS_REVOKED]);
        if (!$affected) {
            return false;
        }

        // 发放计数回退，券模板的额度要还给后面的活动，claimed_qty 不允许减成负数
        Coupon::where('id', $couponId)->where('claimed_qty', '>', 0)->dec('claimed_qty')->update();
        return true;
    }

    /**
     * 全额退款后把「这单花掉的券」退回未使用
     *
     * 与 {@see revokeCoupon()} 语义相反：那边回收这单挣到的券，这里退回这单花掉的券，
     * 两条路径互不复用。判定只看 `coupon_user.order_pay_id + status=USED`，不解析折扣快照；
     * 快照里的金额仅作为对账记录。
     *
     * 幂等：uk_restore(order_pay_id, coupon_user_id) 已存在即跳过；条件更新再兜一层并发。
     * 任何异常都吞在本方法内（退款成功事实已落库，返券失败只记 failed，不反向影响退款）。
     *
     * @param int $orderPayId 支付单 ID
     * @return array{restored:int,skipped_expired:int,skipped_used_again:int,failed:int,items:array}
     */
    public function restoreByOrderPay(int $orderPayId): array
    {
        $stats = ['restored' => 0, 'skipped_expired' => 0, 'skipped_used_again' => 0, 'failed' => 0, 'items' => []];

        $rows = CouponUser::where('order_pay_id', $orderPayId)
            ->where('status', CouponUser::STATUS_USED)
            ->select();
        if (count($rows) === 0) {
            return $stats;
        }

        $amounts = $this->restoreAmountMap($orderPayId);
        $now     = time();

        foreach ($rows as $row) {
            $couponUserId = (int) $row->id;

            $existing = CouponRestoreLog::where('order_pay_id', $orderPayId)
                ->where('coupon_user_id', $couponUserId)
                ->find();
            if ($existing) {
                continue;
            }

            $expireTime = (string) ($row->expire_time ?? '');
            if ($expireTime !== '' && strtotime($expireTime) !== false && strtotime($expireTime) <= $now) {
                $this->writeRestoreLog($orderPayId, (int) $row->user_id, (int) $row->coupon_id, $couponUserId, $amounts[$couponUserId] ?? '0.00', CouponRestoreLog::STATUS_SKIPPED_EXPIRED, '券已过期');
                $stats['skipped_expired']++;
                $stats['items'][] = ['coupon_user_id' => $couponUserId, 'status' => CouponRestoreLog::STATUS_SKIPPED_EXPIRED];
                continue;
            }

            Db::startTrans();
            try {
                $affected = CouponUser::where('id', $couponUserId)
                    ->where('status', CouponUser::STATUS_USED)
                    ->update([
                        'status'       => CouponUser::STATUS_UNUSED,
                        'order_pay_id' => null,
                        'used_at'      => null,
                    ]);
                if (!$affected) {
                    Db::rollback();
                    $this->writeRestoreLog($orderPayId, (int) $row->user_id, (int) $row->coupon_id, $couponUserId, $amounts[$couponUserId] ?? '0.00', CouponRestoreLog::STATUS_SKIPPED_USED_AGAIN, '券状态已被其他流程改动');
                    $stats['skipped_used_again']++;
                    $stats['items'][] = ['coupon_user_id' => $couponUserId, 'status' => CouponRestoreLog::STATUS_SKIPPED_USED_AGAIN];
                    continue;
                }

                // 核销计数回退，不允许减成负数
                Coupon::where('id', (int) $row->coupon_id)->where('used_qty', '>', 0)->dec('used_qty')->update();

                $this->writeRestoreLog($orderPayId, (int) $row->user_id, (int) $row->coupon_id, $couponUserId, $amounts[$couponUserId] ?? '0.00', CouponRestoreLog::STATUS_RESTORED, null);
                Db::commit();

                $stats['restored']++;
                $stats['items'][] = ['coupon_user_id' => $couponUserId, 'status' => CouponRestoreLog::STATUS_RESTORED];
            } catch (\Throwable $e) {
                Db::rollback();
                Log::error('coupon restore failed: pay=' . $orderPayId . ' coupon_user=' . $couponUserId . ' err=' . $e->getMessage());
                try {
                    $this->writeRestoreLog($orderPayId, (int) $row->user_id, (int) $row->coupon_id, $couponUserId, $amounts[$couponUserId] ?? '0.00', CouponRestoreLog::STATUS_FAILED, mb_substr($e->getMessage(), 0, 200));
                } catch (\Throwable $ignore) {
                }
                $stats['failed']++;
                $stats['items'][] = ['coupon_user_id' => $couponUserId, 'status' => CouponRestoreLog::STATUS_FAILED];
            }
        }

        return $stats;
    }

    /**
     * 折扣快照里这张券抵扣的金额（只用于对账记录，不参与退回判定）
     *
     * @param int $orderPayId 支付单 ID
     * @return array<int,string> coupon_user_id => amount
     */
    private function restoreAmountMap(int $orderPayId): array
    {
        $pay = OrderPay::find($orderPayId);
        if (!$pay) {
            return [];
        }
        $lines = $pay->discount_lines_json;
        if (!is_array($lines)) {
            return [];
        }

        $map = [];
        foreach ($lines as $line) {
            if (!is_array($line)) {
                continue;
            }
            $couponUserId = (int) ($line['coupon_user_id'] ?? 0);
            if ($couponUserId > 0) {
                $map[$couponUserId] = (string) ($line['amount'] ?? '0.00');
            }
        }
        return $map;
    }

    /**
     * 写返券日志（唯一键冲突时视为已处理，不抛）
     *
     * @param int         $orderPayId   支付单 ID
     * @param int         $userId       用户
     * @param int         $couponId     券模板
     * @param int         $couponUserId 券实例
     * @param string      $amount       抵扣金额快照
     * @param string      $status       结果状态
     * @param string|null $reason       原因
     * @return void
     */
    private function writeRestoreLog(int $orderPayId, int $userId, int $couponId, int $couponUserId, string $amount, string $status, ?string $reason): void
    {
        $log = new CouponRestoreLog();
        $log->order_pay_id   = $orderPayId;
        $log->user_id        = $userId;
        $log->coupon_id      = $couponId;
        $log->coupon_user_id = $couponUserId;
        $log->amount         = $amount;
        $log->status         = $status;
        $log->reason         = $reason;
        try {
            $log->save();
        } catch (\Throwable $e) {
            if (!str_contains($e->getMessage(), 'Duplicate entry') && !str_contains($e->getMessage(), '1062')) {
                throw $e;
            }
        }
    }

    // ------------------------------------------------------------------
    // 内部计算
    // ------------------------------------------------------------------

    /**
     * 计算单个优惠在给定商品行下的减免金额（不适用时返回 0.00）
     *
     * @param Coupon $coupon   优惠
     * @param array  $rows     归一化商品行
     * @param string $subtotal 商品小计
     * @return string
     */
    private function computeAmount(Coupon $coupon, array $rows, string $subtotal): string
    {
        $base = $this->eligibleBase($coupon, $rows, $subtotal);
        if (bccomp($base, '0', 2) <= 0) {
            return '0.00';
        }
        // 门槛按「参与优惠的商品小计」判断
        if (bccomp($base, (string) $coupon->min_amount, 2) < 0) {
            return '0.00';
        }

        if ($coupon->discount_type === Coupon::TYPE_PERCENT) {
            $amount = bcmul($base, bcdiv((string) $coupon->discount_value, '100', 6), 2);
            if (bccomp((string) $coupon->max_discount, '0', 2) > 0 && bccomp($amount, (string) $coupon->max_discount, 2) > 0) {
                $amount = (string) $coupon->max_discount;
            }
        } else {
            $amount = (string) $coupon->discount_value;
        }

        if (bccomp($amount, $base, 2) > 0) {
            $amount = $base;
        }
        if (bccomp($amount, $subtotal, 2) > 0) {
            $amount = $subtotal;
        }
        return $amount;
    }

    /**
     * 计算优惠的参与基数
     *
     * 两个收敛维度叠加：scope=product 只算圈定的商品；merchant_id 非空只算该商户的商品行
     * （不分 tier，商家建的 tier=40 券同样不能减别家的货）。两者都不限时才用整单小计。
     *
     * @param Coupon $coupon   优惠
     * @param array  $rows     归一化商品行
     * @param string $subtotal 商品小计
     * @return string
     */
    private function eligibleBase(Coupon $coupon, array $rows, string $subtotal): string
    {
        $merchantId = $coupon->merchant_id === null ? null : (int) $coupon->merchant_id;
        $productIds = null;

        if ((string) $coupon->scope === Coupon::SCOPE_PRODUCT) {
            $productIds = array_map('intval', CouponProduct::where('coupon_id', $coupon->id)->column('product_id'));
            if (empty($productIds)) {
                return '0.00';
            }
        }

        if ($merchantId === null && $productIds === null) {
            return $subtotal;
        }

        $owners = $this->productMerchantMap(array_column($rows, 'product_id'));
        $base = '0.00';
        foreach ($rows as $row) {
            $productId = (int) $row['product_id'];
            if ($productIds !== null && !in_array($productId, $productIds, true)) {
                continue;
            }
            if ($merchantId !== null && ($owners[$productId] ?? 0) !== $merchantId) {
                continue;
            }
            $base = bcadd($base, (string) $row['subtotal'], 2);
        }
        return $base;
    }

    /**
     * 优惠不可用时的提示文案
     *
     * @param Coupon $coupon   优惠
     * @param array  $rows     归一化商品行
     * @param string $subtotal 商品小计
     * @return string
     */
    private function ineligibleReason(Coupon $coupon, array $rows, string $subtotal): string
    {
        $base = $this->eligibleBase($coupon, $rows, $subtotal);
        if (bccomp($base, '0', 2) <= 0) {
            return '购物车中没有该优惠适用的商品';
        }
        if (bccomp($base, (string) $coupon->min_amount, 2) < 0) {
            return '未达到使用门槛（需满 ' . $coupon->min_amount . '）';
        }
        return '该优惠当前不可用';
    }

    /**
     * 解析用户券：优先使用已领取券记录，其次按优惠码查找
     *
     * @param int      $userId         用户 ID
     * @param int|null $couponUserId   已领取券记录 ID
     * @param string   $code           优惠码
     * @param array    $rows           归一化商品行
     * @param string   $subtotal       商品小计
     * @return array{0:Coupon,1:?CouponUser}|null
     * @throws BizException 券/码无效
     */
    private function resolveUserCoupon(int $userId, ?int $couponUserId, string $code, array $rows, string $subtotal): ?array
    {
        if ($couponUserId) {
            $record = CouponUser::where('id', $couponUserId)->where('user_id', $userId)->find();
            if (!$record) {
                throw new BizException('优惠券不存在');
            }
            if ((int) $record->status !== CouponUser::STATUS_UNUSED) {
                throw new BizException('优惠券已使用或已失效');
            }
            if ($record->expire_time && strtotime((string) $record->expire_time) < time()) {
                throw new BizException('优惠券已过期');
            }
            $coupon = Coupon::find($record->coupon_id);
            if (!$coupon || (int) $coupon->status !== 1 || !$this->isActiveNow($coupon)) {
                throw new BizException('优惠券已失效');
            }
            if ((int) $coupon->tier === Coupon::TIER_AUTO_GRANT && (int) $coupon->auto_apply === 1) {
                // 自动抵扣层已经在前面算过这张券，这里按「未选择」处理，避免同一张券减两次
                return null;
            }
            return [$coupon, $record];
        }

        $code = strtoupper(trim($code));
        if ($code === '') {
            return null;
        }
        $coupon = Coupon::where('code', $code)->where('apply_type', Coupon::APPLY_CODE)->find();
        if (!$coupon) {
            throw new BizException('优惠码无效');
        }
        if ((int) $coupon->status !== 1) {
            throw new BizException('优惠码已停用');
        }
        if (!$this->isActiveNow($coupon)) {
            throw new BizException('优惠码不在活动时间内');
        }
        $limit = (int) $coupon->per_user_limit;
        if ($limit > 0) {
            $used = (int) CouponUser::where('coupon_id', $coupon->id)
                ->where('user_id', $userId)
                ->where('status', CouponUser::STATUS_USED)
                ->count();
            if ($used >= $limit) {
                throw new BizException('该优惠码您已使用过');
            }
        }
        return [$coupon, null];
    }

    /**
     * 构造折扣明细行
     *
     * @param Coupon   $coupon        优惠
     * @param string   $amount        减免金额
     * @param string   $source        merchant 商家折扣 / activity 平台活动 / rebate 到账自动券 / coupon 手选券 / code 优惠码
     * @param int|null $couponUserId  自动抵扣券的记录 ID（仅 tier=30 有值）
     * @return array
     */
    private function line(Coupon $coupon, string $amount, string $source, ?int $couponUserId = null): array
    {
        $tier = (int) $coupon->tier;
        return [
            'tier'           => $tier,
            'tier_label'     => Coupon::TIER_LABELS[$tier] ?? '',
            'source'         => $source,
            'coupon_id'      => (int) $coupon->id,
            'coupon_user_id' => $couponUserId,
            'merchant_id'    => $coupon->merchant_id === null ? null : (int) $coupon->merchant_id,
            'name'           => (string) $coupon->name,
            'discount_text'  => self::discountText($coupon),
            'amount'         => $amount,
        ];
    }

    /**
     * 生效中的优惠查询构造器（启用 + 在活动期 + 未领完）
     *
     * @return \think\db\Query
     */
    private function activeQuery()
    {
        $now = date('Y-m-d H:i:s');
        return Coupon::where('status', 1)
            ->where(function ($q) use ($now) {
                $q->whereNull('start_time')->whereOr('start_time', '<=', $now);
            })
            ->where(function ($q) use ($now) {
                $q->whereNull('end_time')->whereOr('end_time', '>=', $now);
            })
            ->whereRaw('(total_qty = 0 OR claimed_qty < total_qty)');
    }

    /**
     * 判断优惠当前是否在活动时间内
     *
     * @param Coupon $coupon 优惠
     * @return bool
     */
    private function isActiveNow(Coupon $coupon): bool
    {
        $now = time();
        if ($coupon->start_time && strtotime((string) $coupon->start_time) > $now) {
            return false;
        }
        if ($coupon->end_time && strtotime((string) $coupon->end_time) < $now) {
            return false;
        }
        return true;
    }

    /**
     * 计算券实例的过期时间
     *
     * 优先级：固定到期日 expire_at > 发放后 N 天 valid_days > 跟随活动结束时间。
     * 存量行 expire_at 为 NULL，口径与加列前一致。
     *
     * @param Coupon $coupon 优惠
     * @return string|null
     */
    private function expireTime(Coupon $coupon): ?string
    {
        if (!empty($coupon->expire_at)) {
            return (string) $coupon->expire_at;
        }
        if ((int) $coupon->valid_days > 0) {
            return date('Y-m-d H:i:s', strtotime('+' . (int) $coupon->valid_days . ' days'));
        }
        return $coupon->end_time ? (string) $coupon->end_time : null;
    }

    /**
     * 金额统一格式化为两位小数字符串
     *
     * @param mixed $value 任意数值
     * @return string
     */
    private function decimal($value): string
    {
        if (!is_numeric($value)) {
            return '0.00';
        }
        return bcadd((string) $value, '0', 2);
    }

    /**
     * 归一化日期时间输入（兼容 datetime-local 的 T 分隔与纯日期）
     *
     * @param mixed $value 表单值
     * @return string|null
     */
    private function normalizeTime($value): ?string
    {
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }
        $value = str_replace('T', ' ', $value);
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
            $value .= ' 00:00:00';
        } elseif (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $value)) {
            $value .= ':00';
        }
        $ts = strtotime($value);
        if ($ts === false) {
            return null;
        }
        return date('Y-m-d H:i:s', $ts);
    }
}
