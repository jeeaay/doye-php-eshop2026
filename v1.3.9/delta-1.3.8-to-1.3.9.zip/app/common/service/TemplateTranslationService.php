<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\lib\DistributedLock;
use app\common\lib\translation\HtmlTextExtractor;
use app\common\lib\translation\OpenAiCompatibleProvider;
use app\common\lib\translation\TranslationQueue;
use app\common\model\TemplateFile;
use app\common\model\TranslationJob;
use app\common\support\AppContext;
use think\facade\Db;
use think\facade\Log;

/**
 * 模板翻译服务
 *
 * 核心流程：
 *   1. HtmlTextExtractor 从模板 HTML 提取纯文本节点
 *   2. 文本列表通过 AI provider 翻译
 *   3. 翻译结果还原回 HTML，写入目标语言目录
 *   4. 更新 template_file 表
 */
class TemplateTranslationService
{
    private TemplateManager $templates;
    private HtmlTextExtractor $extractor;

    public function __construct()
    {
        $this->templates = new TemplateManager();
        $this->extractor = new HtmlTextExtractor();
    }

    /**
     * outcome 五态常量（design §3 判定表，互斥且可计数）
     */
    public const OUTCOME_CREATED = 'created';
    public const OUTCOME_QUEUED = 'queued';
    public const OUTCOME_UP_TO_DATE = 'up_to_date';
    public const OUTCOME_NEED_RETRY = 'need_retry';
    public const OUTCOME_EMPTY = 'empty';

    /**
     * 快照单次拉取的任务行上限。实测模型水合约 3.4KB/行，128M 内存上限下
     * 无上限查询在单模板约 2.8 万行历史时 OOM；限 2000 行内存约 7MB 且
     * 覆盖 23 文件 × 全部语言各取最新一条绰绰有余。命中上限时快照带 truncated=true。
     */
    public const SNAPSHOT_ROW_LIMIT = 2000;

    /**
     * 入队一个模板文件的翻译任务（单文件 × 单语言）
     *
     * 判定顺序严格遵循 design.md §3：
     *   pending/running → queued（复用原 job id，不重复 push Redis）；
     *   failed/dead → need_retry（带 job id，绝不新建行）；
     *   其余（无任务或最新 done/skipped）走 up-to-date 判定；都没有才新建。
     *
     * 去重与「取最新一条任务」走 idx_template_job 索引列
     * （template_name + file_path + target_lang + entity_type），不再用 whereJsonContains。
     *
     * @param string $template 模板名
     * @param string $path 相对路径，如 index.html
     * @param string $targetLang 目标语言代码（ru/zh 等）
     * @return array{outcome:string,job_id:int|null}
     */
    public function enqueueOne(string $template, string $path, string $targetLang): array
    {
        $targetLang = LanguageService::normalizeCode($targetLang);
        if ($targetLang === '' || $targetLang === strtolower(base_locale())) {
            return $this->outcomeEmpty();
        }

        // 读取源文件
        $sourceHtml = $this->templates->fileContent($template, $path, 'base');
        if ($sourceHtml === null) {
            Log::warning("TemplateTranslation: source not found: {$template}/{$path}");
            return $this->outcomeEmpty();
        }

        // 提取文本节点
        $extract = $this->extractor->extract($sourceHtml);
        $texts = array_values(array_unique(array_filter($extract['texts'])));

        // 没有可翻译文本 → 跳过
        if ($texts === []) {
            Log::info("TemplateTranslation: no translatable text: {$template}/{$path}");
            return $this->outcomeEmpty();
        }

        // 短锁串行化同一 (文件,语言) 的判定窗口：translation_job 无唯一索引，
        // 两个会话同秒入队会各自判「无最新行」而重复建行、重复计费；
        // 拿不到锁说明对方正在判，按 queued 口径复用其最新行，不建行不 push。
        $lockKey = 'template-enqueue:' . $template . ':' . $path . ':' . $targetLang;
        $token = DistributedLock::lock($lockKey, 10);
        if ($token === null) {
            $concurrent = TranslationJob::where('entity_type', 'template_file')
                ->where('template_name', $template)
                ->where('file_path', $path)
                ->where('target_lang', $targetLang)
                ->order('id', 'desc')
                ->find();

            return [
                'outcome' => self::OUTCOME_QUEUED,
                'job_id'  => $concurrent !== null ? (int) $concurrent->id : null,
            ];
        }

        try {
            // 取该 (template, path, lang) 的最新一条任务（走 idx_template_job）
            $latest = TranslationJob::where('entity_type', 'template_file')
                ->where('template_name', $template)
                ->where('file_path', $path)
                ->where('target_lang', $targetLang)
                ->order('id', 'desc')
                ->find();

            if ($latest && in_array((string) $latest->status, [TranslationJob::STATUS_PENDING, TranslationJob::STATUS_RUNNING], true)) {
                // 已在队列/执行中：复用原任务，不写库、不重复 push Redis
                return ['outcome' => self::OUTCOME_QUEUED, 'job_id' => (int) $latest->id];
            }

            if ($latest && in_array((string) $latest->status, [TranslationJob::STATUS_FAILED, TranslationJob::STATUS_DEAD], true)) {
                // R3.2：失败只能走「重试」复用原记录，绝不新建行、绝不 push Redis
                return ['outcome' => self::OUTCOME_NEED_RETRY, 'job_id' => (int) $latest->id];
            }

            // 无任务，或最新一条为 done/skipped：检查目标文件是否已是最新。
            // 库里 source_hash 相同还不够：译文文件被手工删掉时行仍存在，
            // 不加存在性校验会永远误报「已是最新」而拒绝重翻。
            $targetFile = TemplateFile::where('template', $template)
                ->where('lang', $targetLang)
                ->where('path', $path)
                ->find();

            $baseMd5 = $this->templates->fileMd5(
                $this->templates->absPath($template, $path, 'base') ?? ''
            );
            $targetAbs = $this->templates->absPath($template, $path, $targetLang);
            if ($targetFile
                && (string) $targetFile->source_hash === $baseMd5
                && $targetAbs !== null
                && is_file($targetAbs)) {
                Log::info("TemplateTranslation: already up-to-date: {$template}/{$path} -> {$targetLang}");
                return ['outcome' => self::OUTCOME_UP_TO_DATE, 'job_id' => null];
            }

            // 创建翻译任务
            $sourceHash = md5(json_encode([
                'template' => $template,
                'path'     => $path,
                'texts'    => $texts,
            ], JSON_UNESCAPED_UNICODE));

            $job = new TranslationJob();
            $job->entity_type = 'template_file';
            $job->entity_id = 0;
            $job->source_lang = base_locale();
            $job->target_lang = $targetLang;
            $job->template_name = $template;
            $job->file_path = $path;
            $job->fields_json = [
                'template' => $template,
                'path'     => $path,
                'source'   => [
                    'template'        => $template,
                    'path'            => $path,
                    'source_html'     => $extract['normalized'],
                    'texts'           => $texts,
                    'placeholders'    => $extract['placeholders'],
                    'base_md5'        => $baseMd5,
                    'source_hash'     => $sourceHash,
                ],
            ];
            $job->status = TranslationJob::STATUS_PENDING;
            $job->priority = 10; // 模板翻译优先级高于批量实体翻译
            $job->attempts = 0;
            $job->max_attempts = 3;
            $job->created_by = (int) (AppContext::getAdminId() ?? 0);
            $job->save();

            // 推入 Redis 队列
            try {
                TranslationQueue::push((int) $job->id, 10);
            } catch (\Throwable $e) {
                Log::error("TemplateTranslation queue push failed: {$e->getMessage()}");
            }

            return ['outcome' => self::OUTCOME_CREATED, 'job_id' => (int) $job->id];
        } finally {
            DistributedLock::unlock($lockKey, $token);
        }
    }

    /**
     * 单文件 × 多语言入队（修 R5.1：多选语言时每种语言都要有结果）
     *
     * 语言代码统一 normalizeCode，等于默认语种的被过滤掉（不产生结果行）。
     *
     * @param array<int,string> $langs
     * @return array{results:array<int,array{lang:string,outcome:string,job_id:int|null}>,counts:array<string,int>}
     */
    public function enqueueMany(string $template, string $path, array $langs): array
    {
        $base = strtolower(base_locale());
        $results = [];
        $counts = $this->emptyOutcomeCounts();

        foreach ($langs as $lang) {
            $code = LanguageService::normalizeCode((string) $lang);
            if ($code === '' || $code === $base) {
                continue;
            }

            $outcome = $this->enqueueOne($template, $path, $code);
            $results[] = [
                'lang'    => $code,
                'outcome' => $outcome['outcome'],
                'job_id'  => $outcome['job_id'],
            ];
            $counts[$outcome['outcome']]++;
        }

        return ['results' => $results, 'counts' => $counts];
    }

    /**
     * 批量入队：扫描指定模板的文件并按 outcome 分类计数（R3.3）
     *
     * @param string $template 模板名，空表示全部
     * @param array<int,string> $targetLangs 目标语言列表，空表示按模板自动探测
     * @return array{scanned_files:int,langs:int,created:int,queued:int,up_to_date:int,need_retry:int,empty:int}
     */
    public function enqueueModified(string $template = '', array $targetLangs = []): array
    {
        $manager = new TemplateManager();
        $manager->scan($template !== '' ? $template : null);

        $base = strtolower(base_locale());
        $scannedFiles = 0;
        $observedLangs = [];
        $counts = $this->emptyOutcomeCounts();

        $query = TemplateFile::where('lang', 'base');
        if ($template !== '') {
            $query->where('template', $template);
        }

        foreach ($query->select() as $file) {
            $scannedFiles++;
            if ($targetLangs === []) {
                // 自动扫描已有翻译目录
                $langs = $this->detectTargetLangs((string) $file->template);
            } else {
                $langs = $targetLangs;
            }

            foreach ($langs as $lang) {
                $code = LanguageService::normalizeCode((string) $lang);
                if ($code === '' || $code === $base) {
                    continue;
                }
                $observedLangs[$code] = true;

                $outcome = $this->enqueueOne((string) $file->template, (string) $file->path, $code);
                $counts[$outcome['outcome']]++;
            }
        }

        return array_merge(
            ['scanned_files' => $scannedFiles, 'langs' => count($observedLangs)],
            $counts
        );
    }

    /**
     * 模板翻译队列快照（面板 + 行内徽标的唯一数据源，design §4 契约）
     *
     * 口径：summary 按 (path, lang) 取最新一条任务聚合，与行内徽标同源；
     * 只发 3 类查询（translation_job 走新索引一次取回、template_file 该模板一次取回、Redis 若干命令），
     * 不读磁盘、不做 fileMd5 —— up_to_date 判定用库内 base 行的 md5_hash（最近一次扫描结果）。
     *
     * @return array<string,mixed>
     */
    public function jobsSnapshot(string $template): array
    {
        // 1) 该模板全部模板任务：按 id 倒序，PHP 取每 (path,lang) 首条即最新。
        //    显式 field() 列表，绝不把 fields_json（整页 HTML）拉进内存。
        //    行数封顶 SNAPSHOT_ROW_LIMIT：无上限时单模板历史堆到 ~2.8 万行即 OOM（实测）。
        $jobRows = TranslationJob::where('entity_type', 'template_file')
            ->where('template_name', $template)
            ->field('id,file_path,target_lang,status,attempts,max_attempts,error,next_retry_at,finished_at')
            ->order('id', 'desc')
            ->limit(self::SNAPSHOT_ROW_LIMIT)
            ->select();
        $truncated = count($jobRows) >= self::SNAPSHOT_ROW_LIMIT;

        $latestJobs = [];
        foreach ($jobRows as $row) {
            $key = ((string) $row->file_path) . '|' . LanguageService::normalizeCode((string) $row->target_lang);
            if (!isset($latestJobs[$key])) {
                $latestJobs[$key] = $row;
            }
        }

        // 2) 该模板全部文件行：base 行给路径全集与 md5 基准，语言行给已翻译/最新判定
        $fileRows = TemplateFile::where('template', $template)->select();

        $baseHash = [];
        $paths = [];
        $targetRows = [];
        $langs = [];
        foreach ($fileRows as $row) {
            $lang = LanguageService::normalizeCode((string) $row->lang);
            $path = (string) $row->path;
            $paths[$path] = true;
            if ($lang === TemplateFile::LANG_BASE) {
                $baseHash[$path] = (string) $row->md5_hash;
                continue;
            }
            $targetRows[$path . '|' . $lang] = $row;
            $langs[$lang] = true;
        }
        foreach (array_keys($latestJobs) as $key) {
            [$path, $lang] = explode('|', $key, 2);
            $paths[$path] = true;
            $langs[$lang] = true;
        }
        unset($langs[strtolower(base_locale())]);

        // 3) 聚合：每个 (path, lang) 一条徽标数据；summary 与其同源
        $summary = [
            'pending'       => 0,
            'running'       => 0,
            'done'          => 0,
            'failed'        => 0,
            'dead'          => 0,
            'skipped'       => 0,
            'retry_waiting' => 0,
            'up_to_date'    => 0,
            'untranslated'  => 0,
        ];
        $files = [];

        $pathKeys = array_keys($paths);
        sort($pathKeys, SORT_STRING);
        foreach ($pathKeys as $path) {
            $langEntries = [];
            $upToDateLangs = [];
            $translatedLangs = [];

            $langCodes = array_keys($langs);
            sort($langCodes, SORT_STRING);
            foreach ($langCodes as $lang) {
                $key = $path . '|' . $lang;
                $target = $targetRows[$key] ?? null;
                $upToDate = $target !== null
                    && isset($baseHash[$path])
                    && $baseHash[$path] !== ''
                    && (string) $target->source_hash === $baseHash[$path];

                if ($target !== null) {
                    $translatedLangs[] = $lang;
                }
                if ($upToDate) {
                    $upToDateLangs[] = $lang;
                }

                $job = $latestJobs[$key] ?? null;
                if ($job !== null) {
                    $status = (string) $job->status;
                    if (isset($summary[$status])) {
                        $summary[$status]++;
                    }
                    if ($status === TranslationJob::STATUS_FAILED || $status === TranslationJob::STATUS_DEAD) {
                        $summary['retry_waiting']++;
                    }
                    $langEntries[$lang] = [
                        'job_id'        => (int) $job->id,
                        'status'        => $status,
                        'attempts'      => (int) $job->attempts,
                        'max_attempts'  => (int) $job->max_attempts,
                        'error'         => (string) ($job->error ?? ''),
                        'next_retry_at' => $job->next_retry_at !== null ? (string) $job->next_retry_at : null,
                        'finished_at'   => $job->finished_at !== null ? (string) $job->finished_at : null,
                        'up_to_date'    => $upToDate,
                    ];
                } else {
                    // 无任务：已是最新计入 up_to_date，否则（未翻译或已过期）计入 untranslated
                    if ($upToDate) {
                        $summary['up_to_date']++;
                    } else {
                        $summary['untranslated']++;
                    }
                    $langEntries[$lang] = [
                        'job_id'     => null,
                        'status'     => null,
                        'up_to_date' => $upToDate,
                    ];
                }
            }

            $files[$path] = [
                'langs'            => (object) $langEntries,
                'up_to_date_langs' => $upToDateLangs,
                'translated_langs' => $translatedLangs,
            ];
        }

        // 4) Redis：队列深度 + worker 探活（与 lock() 同一 key 空间）
        $client = \app\common\lib\RedisCache::client();
        $queue = [
            'ready'          => (int) $client->zcard(TranslationQueue::READY_KEY),
            'delayed'        => (int) $client->zcard(TranslationQueue::DELAYED_KEY),
            'processing'     => (int) $client->llen(TranslationQueue::PROCESSING_KEY),
            'depth'          => TranslationQueue::pendingCount(),
            'worker_running' => DistributedLock::held('translate:worker'),
        ];

        // 5) AI 配置与预算（missing 只给缺哪几项，绝不返回 key 值本身）
        $jobService = new TranslationJobService();
        $config = $jobService->config();
        $missing = [];
        foreach (['base_url', 'api_key', 'model'] as $field) {
            if ($config[$field] === '') {
                $missing[] = $field;
            }
        }
        $ai = [
            'configured'      => $missing === [],
            'missing'         => $missing,
            'today_cost'      => sprintf('%.6f', $jobService->todayCost()),
            'daily_budget'    => (float) ($config['daily_budget'] ?? 0),
            'budget_exceeded' => $jobService->isBudgetExceeded(),
        ];

        return [
            'template'      => $template,
            'summary'       => $summary,
            'queue'         => $queue,
            'ai'            => $ai,
            'files'         => (object) $files,
            'truncated'     => $truncated,
            'generated_at'  => date('Y-m-d H:i:s'),
        ];
    }

    /**
     * @return array{outcome:string,job_id:null}
     */
    private function outcomeEmpty(): array
    {
        return ['outcome' => self::OUTCOME_EMPTY, 'job_id' => null];
    }

    /**
     * @return array<string,int>
     */
    private function emptyOutcomeCounts(): array
    {
        return [
            self::OUTCOME_CREATED    => 0,
            self::OUTCOME_QUEUED     => 0,
            self::OUTCOME_UP_TO_DATE => 0,
            self::OUTCOME_NEED_RETRY => 0,
            self::OUTCOME_EMPTY      => 0,
        ];
    }

    /**
     * 执行一个 template_file 类型的翻译任务
     *
     * 由 TranslationJobService::run() 在 entity_type = template_file 时调用。
     *
     * @throws \Throwable
     */
    public function runJob(TranslationJob $job): void
    {
        $fields = (array) $job->fields_json;
        $source = (array) ($fields['source'] ?? []);
        $template = (string) ($fields['template'] ?? '');
        $path = (string) ($fields['path'] ?? '');
        $targetLang = LanguageService::normalizeCode((string) $job->target_lang);

        if ($template === '' || $path === '' || !isset($source['texts'])) {
            throw new \RuntimeException('任务字段不完整');
        }

        $texts = (array) $source['texts'];
        $normalizedHtml = (string) ($source['source_html'] ?? '');
        $placeholders = (array) ($source['placeholders'] ?? []);
        $baseMd5 = (string) ($source['base_md5'] ?? '');

        if ($texts === []) {
            // 没有可翻译文本，直接标记完成
            $job->status = TranslationJob::STATUS_DONE;
            $job->finished_at = date('Y-m-d H:i:s');
            $job->save();
            return;
        }

        // 调用 AI
        $provider = new OpenAiCompatibleProvider((new TranslationJobService())->config());
        $textsAsKeys = [];
        foreach ($texts as $t) {
            $textsAsKeys[$t] = '';
        }

        $result = $provider->translate($textsAsKeys, base_locale(), $targetLang);
        $translatedTexts = (array) ($result['fields'] ?? []);

        // 验证：原文存在但译文为空 → 视为失败
        foreach ($texts as $original) {
            if (!array_key_exists($original, $translatedTexts) || trim((string) $translatedTexts[$original]) === '') {
                // 允许原文保留（AI 可能认为无需翻译）
                $translatedTexts[$original] = $original;
            }
        }

        // 重建 HTML
        $html = $this->extractor->rebuild($normalizedHtml, $placeholders, $translatedTexts);

        // 写入目标语言目录
        $written = $this->templates->writeFile($template, $path, $targetLang, $html);
        if (!$written) {
            throw new \RuntimeException('写入目标文件失败：' . $template . '/' . $targetLang . '/' . $path);
        }

        // 更新 template_file 表
        $absPath = $this->templates->absPath($template, $path, $targetLang) ?? '';
        $md5 = $this->templates->fileMd5($absPath);
        $mtime = $this->templates->fileMtime($absPath);
        $now = date('Y-m-d H:i:s');

        $existing = TemplateFile::where('template', $template)
            ->where('lang', $targetLang)
            ->where('path', $path)
            ->find();

        if ($existing) {
            $existing->md5_hash = $md5;
            $existing->file_mtime = $mtime;
            $existing->source_hash = $baseMd5;
            $existing->translated_at = $now;
            $existing->last_scanned = $now;
            $existing->update_time = $now;
            $existing->save();
        } else {
            $row = new TemplateFile();
            $row->template = $template;
            $row->lang = $targetLang;
            $row->path = $path;
            $row->md5_hash = $md5;
            $row->file_mtime = $mtime;
            $row->source_hash = $baseMd5;
            $row->translated_at = $now;
            $row->last_scanned = $now;
            $row->create_time = $now;
            $row->update_time = $now;
            $row->save();
        }

        // 更新任务状态
        $tokens = $result['usage'] ?? [];
        $price = (float) ((new TranslationJobService())->config()['price_per_1k'] ?? 0.002);
        $cost = (($tokens['prompt_tokens'] ?? 0) + ($tokens['completion_tokens'] ?? 0)) / 1000 * $price;

        $job->status = TranslationJob::STATUS_DONE;
        $job->provider = 'openai-compatible';
        $job->model = (string) ((new TranslationJobService())->config()['model'] ?? '');
        $job->input_chars = mb_strlen(json_encode($texts, JSON_UNESCAPED_UNICODE) ?: '');
        $job->output_chars = mb_strlen(json_encode($translatedTexts, JSON_UNESCAPED_UNICODE) ?: '');
        $job->cost = round($cost, 6);
        $job->error = null;
        $job->finished_at = $now;
        $job->save();

        Log::info("TemplateTranslation done: {$template}/{$path} -> {$targetLang}, cost={$cost}");
    }

    /**
     * 检测模板有哪些目标语言目录
     *
     * @return array<int,string>
     */
    private function detectTargetLangs(string $template): array
    {
        $langs = $this->templates->listLangDirs($template);

        // 同时考虑已启用的语种
        foreach ((new LanguageService())->targetLocales() as $code) {
            if (!in_array($code, $langs, true)) {
                $langs[] = $code;
            }
        }

        return $langs;
    }
}
