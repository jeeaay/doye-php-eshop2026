<?php
declare(strict_types=1);

namespace app\common\service;

/**
 * 商品发货时效规则（海外仓）
 *
 * 本类是全站唯一的规则来源：海外仓白名单、仓覆盖国家、国家选择器分组、
 * 时效天数与展示文案。控制器 / 模板 / 管理 API 只调用这里，不要各写一份映射。
 */
class ShippingEtaService
{
    /** 海外仓白名单（固定顺序：多仓命中同一目的地时按此顺序取第一个） */
    public const WAREHOUSES = ['north_america', 'germany', 'korea'];

    /** 各海外仓覆盖的国家（ISO2） */
    public const COVERAGE = [
        'north_america' => ['US', 'CA', 'MX'],
        'germany'       => [
            'AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR',
            'HU', 'IE', 'IT', 'LV', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK',
            'SI', 'ES', 'SE', 'GB',
        ],
        'korea'         => ['KR'],
    ];

    /** 「其他国家」哨兵值：不算海外仓，按卖家发货计算 */
    public const OTHER_COUNTRY = 'OTHER';

    /**
     * 国家英文标准名（本版不做国家名翻译，选择器直接展示）
     * 同时充当国家码合法集合：只有出现在这里的国家码才被接受
     */
    private const COUNTRY_NAMES = [
        // North America
        'US' => 'United States',
        'CA' => 'Canada',
        'MX' => 'Mexico',
        // Europe（EU27 + GB）
        'AT' => 'Austria',
        'BE' => 'Belgium',
        'BG' => 'Bulgaria',
        'HR' => 'Croatia',
        'CY' => 'Cyprus',
        'CZ' => 'Czechia',
        'DK' => 'Denmark',
        'EE' => 'Estonia',
        'FI' => 'Finland',
        'FR' => 'France',
        'DE' => 'Germany',
        'GR' => 'Greece',
        'HU' => 'Hungary',
        'IE' => 'Ireland',
        'IT' => 'Italy',
        'LV' => 'Latvia',
        'LT' => 'Lithuania',
        'LU' => 'Luxembourg',
        'MT' => 'Malta',
        'NL' => 'Netherlands',
        'PL' => 'Poland',
        'PT' => 'Portugal',
        'RO' => 'Romania',
        'SK' => 'Slovakia',
        'SI' => 'Slovenia',
        'ES' => 'Spain',
        'SE' => 'Sweden',
        'GB' => 'United Kingdom',
        // Asia
        'KR' => 'South Korea',
        // 兜底
        'OTHER' => 'Other countries',
    ];

    /**
     * 选择器分组：分组 key => 取哪个仓的覆盖国家
     * other 组单独追加（只有 OTHER 一项）
     */
    private const GROUPS = [
        'north_america' => 'north_america',
        'europe'        => 'germany',
        'asia'          => 'korea',
    ];

    /**
     * 国家选择器数据（optgroup 结构）
     *
     * @return array<int,array{key:string,label:string,countries:array<int,array{code:string,name:string}>}>
     */
    public function countries(): array
    {
        $groups = [];

        foreach (self::GROUPS as $groupKey => $warehouse) {
            $items = [];
            foreach (self::COVERAGE[$warehouse] as $code) {
                $items[] = ['code' => $code, 'name' => $this->countryName($code)];
            }

            $groups[] = [
                'key'       => $groupKey,
                'label'     => site_lang('shipping.zone.' . $groupKey),
                'countries' => $items,
            ];
        }

        $groups[] = [
            'key'       => 'other',
            'label'     => site_lang('shipping.zone.other'),
            'countries' => [
                ['code' => self::OTHER_COUNTRY, 'name' => $this->countryName(self::OTHER_COUNTRY)],
            ],
        ];

        return $groups;
    }

    /**
     * 归一化国家码：大写去空白，命中覆盖国家或 OTHER 才返回，否则 null
     */
    public function normalize(string $code): ?string
    {
        $code = strtoupper(trim($code));
        if ($code === '') {
            return null;
        }

        return array_key_exists($code, self::COUNTRY_NAMES) ? $code : null;
    }

    /**
     * 站点默认收货国家（配置非法时回落 US）
     */
    public function defaultCountry(): string
    {
        $configured = (string) site_config('shipping.default_country', 'US');

        return $this->normalize($configured) ?? 'US';
    }

    /**
     * 海外仓发货时效（工作日）
     */
    public function overseasDays(): int
    {
        return max(1, (int) site_config('shipping.eta_overseas_days', 7));
    }

    /**
     * 卖家（国内）发货时效（工作日）
     */
    public function sellerDays(): int
    {
        return max(1, (int) site_config('shipping.eta_seller_days', 14));
    }

    /**
     * 覆盖该国家的仓码；未被任何仓覆盖，或目的地为 OTHER 时返回 null
     */
    public function zoneOf(string $country): ?string
    {
        $code = $this->normalize($country);
        if ($code === null || $code === self::OTHER_COUNTRY) {
            return null;
        }

        foreach (self::WAREHOUSES as $warehouse) {
            if (in_array($code, self::COVERAGE[$warehouse], true)) {
                return $warehouse;
            }
        }

        return null;
    }

    /**
     * 计算发货时效
     *
     * 按 WAREHOUSES 固定顺序取首个「商品有该仓且该仓覆盖目的地」的仓；
     * 无命中（含无海外仓 / 目的地未覆盖 / OTHER）回落到卖家发货。
     *
     * @param array<int,string> $warehouses 商品所属海外仓
     * @return array{warehouse:string|null,days:int}
     */
    public function estimate(array $warehouses, string $country): array
    {
        $codes = [];
        foreach ($warehouses as $warehouse) {
            if (is_string($warehouse)) {
                $codes[] = $warehouse;
            }
        }
        // array_intersect 保留第一个数组的顺序 => 白名单固定顺序 + 去重
        $codes = array_values(array_intersect(self::WAREHOUSES, $codes));

        $zone = $this->zoneOf($country);
        if ($zone !== null && in_array($zone, $codes, true)) {
            return ['warehouse' => $zone, 'days' => $this->overseasDays()];
        }

        return ['warehouse' => null, 'days' => $this->sellerDays()];
    }

    /**
     * 仓名语言键（模板 / 后台提示复用）
     */
    public function warehouseLabelKey(string $code): string
    {
        return 'shipping.warehouse.' . $code;
    }

    /**
     * 指定商品 + 目的地的最终时效文案（唯一判定入口）
     *
     * @param array<int,string> $warehouses 商品所属海外仓
     */
    public function textForCountry(array $warehouses, string $country): string
    {
        $eta = $this->estimate($warehouses, $country);
        if ($eta['warehouse'] !== null) {
            return site_lang('shipping.eta_warehouse', [
                'warehouse' => site_lang($this->warehouseLabelKey($eta['warehouse'])),
                'days'      => $eta['days'],
            ]);
        }

        return site_lang('shipping.eta_seller', ['days' => $eta['days']]);
    }

    /**
     * 指定商品的「国家码 => 时效文案」映射（供前台按默认地址国家直接查表）
     *
     * 规则只在本服务计算，前端不得再拿覆盖表自行推导。
     *
     * @param array<int,string> $warehouses 商品所属海外仓
     * @return array<string,string>
     */
    public function textsByCountry(array $warehouses): array
    {
        $texts = [];
        foreach (array_keys(self::COUNTRY_NAMES) as $code) {
            $texts[$code] = $this->textForCountry($warehouses, $code);
        }

        return $texts;
    }

    /**
     * 国家英文标准名（未登记的国家码原样返回，避免出现空白选项）
     */
    private function countryName(string $code): string
    {
        return self::COUNTRY_NAMES[$code] ?? $code;
    }
}
