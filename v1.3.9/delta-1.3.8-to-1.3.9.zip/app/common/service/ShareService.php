<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\enum\AdminRole;
use app\common\enum\PayStatus;
use app\common\model\Coupon;
use app\common\model\MarketingRule;
use app\common\model\MarketingRuleLog;
use app\common\model\Order;
use app\common\model\OrderAttribution;
use app\common\model\OrderPay;
use app\common\model\Product;
use app\common\model\ShareBinding;
use app\common\model\ShareReferral;
use app\common\model\User;
use app\common\support\AppContext;
use think\facade\Db;
use think\facade\Log;

/**
 * 分享拉新：事件流水、绑定关系、订单归因与后台统计
 *
 * 三条链路各司其职：
 * - share_referral：访问事件流水，用于统计「分享带来了多少访问」；
 * - share_binding ：邀请人 → 被邀请人的唯一关系，奖励与归因都以它为准；
 * - order_attribution：支付成功后写入，用于统计真实转化。
 *
 * 所有写入口都不向外抛业务异常：分享上报失败不能影响用户浏览，
 * 支付后的归因失败不能影响支付通知（调用方仍需自行 try/catch）。
 */
class ShareService
{
    /** 分享事件节流窗口（秒）：同一访客对同一商品/场景 1 小时内只记一条 */
    private const EVENT_THROTTLE = 3600;

    /** 场景白名单：本期只做好友/群 */
    private const SCENES = ['friend', 'group'];

    /**
     * 记录一次分享访问，并尝试建立绑定
     *
     * @param int         $referrerId 邀请人
     * @param int         $visitorId  被邀请人（当前登录用户）
     * @param int|null    $productId  分享商品
     * @param string      $scene      场景 friend / group
     * @param string|null $ip         客户端 IP
     * @param int|null    $capturedAt 分享打开时间（Unix 秒），用于按「打开时刻」计算 7 天绑定窗口
     * @return array{bound:bool,reason:string,binding_id:int|null}
     */
    public function recordReferral(int $referrerId, int $visitorId, ?int $productId, string $scene, ?string $ip = null, ?int $capturedAt = null): array
    {
        if ($referrerId <= 0 || $visitorId <= 0) {
            return ['bound' => false, 'reason' => 'invalid', 'binding_id' => null];
        }
        if ($referrerId === $visitorId) {
            return ['bound' => false, 'reason' => 'self', 'binding_id' => null];
        }
        if (!User::find($referrerId)) {
            return ['bound' => false, 'reason' => 'invalid', 'binding_id' => null];
        }
        if ($productId !== null && $productId > 0 && !Product::find($productId)) {
            $productId = null;
        }

        $scene = in_array($scene, self::SCENES, true) ? $scene : 'friend';
        $ip = $ip !== null && $ip !== '' ? mb_substr($ip, 0, 45) : null;

        $referralId = $this->recordEvent($referrerId, $visitorId, $productId, $scene);
        $result = $this->bindIfAbsent($referrerId, $visitorId, $referralId, $productId, $scene, $ip, $capturedAt);

        return $result;
    }

    /**
     * 事件流水：节流后插入一条
     *
     * @return int|null 分享事件 ID；被节流时为 null
     */
    private function recordEvent(int $referrerId, int $visitorId, ?int $productId, string $scene): ?int
    {
        try {
            $since = date('Y-m-d H:i:s', time() - self::EVENT_THROTTLE);
            $query = ShareReferral::where('visitor_user_id', $visitorId)
                ->where('scene', $scene)
                ->where('create_time', '>', $since);
            if ($productId !== null && $productId > 0) {
                $query->where('product_id', $productId);
            } else {
                $query->whereNull('product_id');
            }
            if ($query->find()) {
                return null;
            }

            $referral = new ShareReferral();
            $referral->referrer_user_id = $referrerId;
            $referral->visitor_user_id = $visitorId;
            $referral->product_id = $productId;
            $referral->scene = $scene;
            $referral->save();
            return (int) $referral->id;
        } catch (\Throwable $e) {
            Log::error('share referral record failed: referrer=' . $referrerId . ' visitor=' . $visitorId . ' err=' . $e->getMessage());
            return null;
        }
    }

    /**
     * 首触绑定；过期且被邀请人仍无已支付订单时允许重绑
     *
     * @return array{bound:bool,reason:string,binding_id:int|null}
     */
    private function bindIfAbsent(int $referrerId, int $visitorId, ?int $referralId, ?int $productId, string $scene, ?string $ip, ?int $capturedAt = null): array
    {
        $now = date('Y-m-d H:i:s');
        $bindDays = max(1, (int) site_config('share_reward.bind_days', 7));
        // 分享打开时间超过绑定窗口直接拒绝，避免延迟上报把有效期无限后延
        if ($capturedAt !== null && $capturedAt > 0 && $capturedAt < time() - $bindDays * 86400) {
            return ['bound' => false, 'reason' => 'expired', 'binding_id' => null];
        }
        // 绑定窗口从「分享打开时刻」起算；客户端时间异常时退回服务端当前时间
        $boundTs = $capturedAt !== null && $capturedAt > 0
            && $capturedAt <= time() + 300
            ? $capturedAt
            : time();
        $boundAt = date('Y-m-d H:i:s', $boundTs);
        $expireAt = date('Y-m-d H:i:s', $boundTs + $bindDays * 86400);

        $existing = ShareBinding::where('visitor_user_id', $visitorId)->find();
        if ($existing) {
            $isExpired = $existing->expire_at !== null && strtotime((string) $existing->expire_at) <= time();
            $canRebind = ((string) $existing->status === ShareBinding::STATUS_INVALID || $isExpired)
                && (string) $existing->status !== ShareBinding::STATUS_REWARDED
                && !$this->hasPaidOrder($visitorId);

            if (!$canRebind) {
                if ($isExpired && (string) $existing->status === ShareBinding::STATUS_BOUND) {
                    Db::name('share_binding')->where('id', (int) $existing->id)->update([
                        'status'      => ShareBinding::STATUS_EXPIRED,
                        'update_time' => $now,
                    ]);
                }
                return ['bound' => false, 'reason' => 'already_bound', 'binding_id' => (int) $existing->id];
            }

            // 条件更新兜底并发：只有仍是「过期且未奖励」的行能被替换
            $affected = Db::name('share_binding')
                ->where('id', (int) $existing->id)
                ->where(function ($query) use ($now) {
                    $query->where('expire_at', '<=', $now)
                        ->whereOr('status', ShareBinding::STATUS_INVALID);
                })
                ->where('status', '<>', ShareBinding::STATUS_REWARDED)
                ->update([
                    'referrer_user_id'      => $referrerId,
                    'share_referral_id'     => $referralId,
                    'product_id'            => $productId,
                    'scene'                 => $scene,
                    'client_ip'             => $ip,
                    'status'                => ShareBinding::STATUS_BOUND,
                    'reward_rule_id'        => null,
                    'reward_coupon_user_id' => null,
                    'bound_at'              => $boundAt,
                    'expire_at'             => $expireAt,
                    'rewarded_at'           => null,
                    'update_time'           => $now,
                ]);
            if ($affected > 0) {
                return ['bound' => true, 'reason' => 'rebound', 'binding_id' => (int) $existing->id];
            }
            return ['bound' => false, 'reason' => 'already_bound', 'binding_id' => (int) $existing->id];
        }

        try {
            $binding = new ShareBinding();
            $binding->visitor_user_id = $visitorId;
            $binding->referrer_user_id = $referrerId;
            $binding->share_referral_id = $referralId;
            $binding->product_id = $productId;
            $binding->scene = $scene;
            $binding->client_ip = $ip;
            $binding->status = ShareBinding::STATUS_BOUND;
            $binding->bound_at = $boundAt;
            $binding->expire_at = $expireAt;
            $binding->save();
            return ['bound' => true, 'reason' => 'bound', 'binding_id' => (int) $binding->id];
        } catch (\Throwable $e) {
            if ($this->isDuplicateKey($e)) {
                return ['bound' => false, 'reason' => 'already_bound', 'binding_id' => null];
            }
            Log::error('share binding failed: referrer=' . $referrerId . ' visitor=' . $visitorId . ' err=' . $e->getMessage());
            return ['bound' => false, 'reason' => 'error', 'binding_id' => null];
        }
    }

    /**
     * 读取有效绑定（奖励与归因共用）
     *
     * @param int  $visitorId  被邀请人
     * @param bool $requireActive 是否要求未过期
     * @return ShareBinding|null
     */
    public function bindingOf(int $visitorId, bool $requireActive = true): ?ShareBinding
    {
        $binding = ShareBinding::where('visitor_user_id', $visitorId)->find();
        if (!$binding || (string) $binding->status === ShareBinding::STATUS_INVALID) {
            return null;
        }
        if ($requireActive && $binding->expire_at !== null && strtotime((string) $binding->expire_at) <= time()) {
            return null;
        }
        return $binding;
    }

    /**
     * 标记绑定已发奖（发奖成功后由营销引擎调用，失败不影响发券）
     */
    public function markRewarded(int $visitorId, int $ruleId, int $couponUserId): void
    {
        try {
            Db::name('share_binding')
                ->where('visitor_user_id', $visitorId)
                ->where('status', '<>', ShareBinding::STATUS_INVALID)
                ->update([
                    'status'                => ShareBinding::STATUS_REWARDED,
                    'reward_rule_id'        => $ruleId,
                    'reward_coupon_user_id' => $couponUserId,
                    'rewarded_at'           => date('Y-m-d H:i:s'),
                    'update_time'           => date('Y-m-d H:i:s'),
                ]);
        } catch (\Throwable $e) {
            Log::error('share binding mark rewarded failed: visitor=' . $visitorId . ' err=' . $e->getMessage());
        }
    }

    /**
     * 支付成功后写入订单归因（每个子订单一条）
     *
     * 归因从「下单」移到「支付成功」：未支付/取消的订单不再计入转化。
     * 重复通知由 order_attribution.order_id 唯一索引兜底。
     */
    public function attributePay(int $orderPayId): void
    {
        if ($orderPayId <= 0) {
            return;
        }
        $pay = OrderPay::find($orderPayId);
        if (!$pay || (int) $pay->pay_status !== PayStatus::PAID) {
            return;
        }
        $binding = $this->bindingOf((int) $pay->user_id);
        if (!$binding) {
            return;
        }

        $orderIds = (new Order())->db(['merchant'])->where('pay_id', $orderPayId)->column('id');
        foreach ($orderIds as $orderId) {
            try {
                $attr = new OrderAttribution();
                $attr->order_id = (int) $orderId;
                $attr->referrer_user_id = (int) $binding->referrer_user_id;
                $attr->share_referral_id = $binding->share_referral_id !== null
                    ? (int) $binding->share_referral_id
                    : null;
                $attr->save();
            } catch (\Throwable $e) {
                // 唯一键冲突 = 重复通知，忽略；其他异常只记日志
                if (!$this->isDuplicateKey($e)) {
                    Log::error('share attribution failed: order=' . (int) $orderId . ' err=' . $e->getMessage());
                }
            }
        }
    }

    /**
     * 兼容旧调用：按订单写入归因（内部仍以绑定为准）
     */
    public function attributeOrder(int $orderId, int $userId): void
    {
        $binding = $this->bindingOf($userId);
        if (!$binding) {
            return;
        }
        try {
            $attr = new OrderAttribution();
            $attr->order_id = $orderId;
            $attr->referrer_user_id = (int) $binding->referrer_user_id;
            $attr->share_referral_id = $binding->share_referral_id !== null
                ? (int) $binding->share_referral_id
                : null;
            $attr->save();
        } catch (\Throwable $e) {
            if (!$this->isDuplicateKey($e)) {
                Log::error('share attribute order failed: order=' . $orderId . ' err=' . $e->getMessage());
            }
        }
    }

    /**
     * 邀请概况（小程序「邀请有奖」页）
     *
     * @param int $userId 当前用户（邀请人）
     * @return array
     */
    public function inviteSummary(int $userId): array
    {
        $rule = $this->activeReferralRule();
        $enabled = (bool) site_config('share_reward.enabled', false) && $rule !== null;

        $bindings = ShareBinding::where('referrer_user_id', $userId)->select();
        $logRows = MarketingRuleLog::alias('l')
            ->join('marketing_rule r', 'r.id = l.rule_id')
            ->where('l.user_id', $userId)
            ->where('r.type', MarketingRule::TYPE_REFERRAL_REWARD)
            ->field('l.referee_user_id, l.status')
            ->order('l.id')
            ->select();
        $logStatus = [];
        foreach ($logRows as $row) {
            $logStatus[(int) $row->referee_user_id] = (string) $row->status;
        }

        $invited = 0;
        $rewarded = 0;
        $expired = 0;
        $closed = 0;
        foreach ($bindings as $binding) {
            $invited++;
            $visitorId = (int) $binding->visitor_user_id;
            $status = $logStatus[$visitorId] ?? '';
            if ($status === MarketingRuleLog::STATUS_GRANTED) {
                $rewarded++;
            } elseif (in_array($status, [MarketingRuleLog::STATUS_SKIPPED, MarketingRuleLog::STATUS_REVOKED], true)) {
                // 条件不满足或退款回收：不再算「待成单」
                $closed++;
            } elseif ((string) $binding->status === ShareBinding::STATUS_EXPIRED
                || ($binding->expire_at !== null && strtotime((string) $binding->expire_at) <= time())) {
                $expired++;
            } elseif ((string) $binding->status === ShareBinding::STATUS_REWARDED) {
                $closed++;
            }
        }

        $rewardAmount = MarketingRuleLog::alias('l')
            ->join('marketing_rule r', 'r.id = l.rule_id')
            ->where('l.user_id', $userId)
            ->where('r.type', MarketingRule::TYPE_REFERRAL_REWARD)
            ->where('l.status', MarketingRuleLog::STATUS_GRANTED)
            ->sum('l.reward_amount');

        $reward = [
            'amount'      => '5.00',
            'min_amount'  => '0.00',
            'valid_days'  => 30,
            'description' => '好友首单成功后，你得一张无门槛券',
        ];
        if ($rule) {
            $reward['amount'] = (string) $rule->reward_value;
            $inline = $rule->inlineCoupon();
            $reward['min_amount'] = (string) ($inline['min_amount'] ?? '0.00');
            $reward['valid_days'] = (int) ($inline['valid_days'] ?? 30);
            if ((int) $rule->coupon_id > 0) {
                $coupon = Coupon::find((int) $rule->coupon_id);
                if ($coupon) {
                    $reward['min_amount'] = (string) $coupon->min_amount;
                    $reward['valid_days'] = (int) $coupon->valid_days;
                }
            }
        }

        return [
            'enabled'             => $enabled,
            'reward'              => $reward,
            'bind_days'           => max(1, (int) site_config('share_reward.bind_days', 7)),
            'share_title'         => (string) site_config('share_reward.share_title', ''),
            'invited_total'       => $invited,
            'pending_total'       => max(0, $invited - $rewarded - $expired - $closed),
            'rewarded_total'      => $rewarded,
            'expired_total'       => $expired,
            'reward_amount_total' => bcadd((string) $rewardAmount, '0', 2),
        ];
    }

    /**
     * 我的邀请记录
     *
     * @return array{list:array,total:int,page:int,page_size:int}
     */
    public function inviteList(int $userId, int $page = 1, int $size = 20): array
    {
        $page = max(1, $page);
        $size = min(max($size, 1), 100);

        $pager = ShareBinding::with(['visitor'])
            ->where('referrer_user_id', $userId)
            ->order('id', 'desc')
            ->paginate($size, false, ['page' => $page]);

        $visitorIds = [];
        foreach ($pager as $binding) {
            $visitorIds[] = (int) $binding->visitor_user_id;
        }

        $logs = [];
        if ($visitorIds) {
            $rows = MarketingRuleLog::where('user_id', $userId)
                ->whereIn('referee_user_id', array_values(array_unique($visitorIds)))
                ->where('trigger_event', MarketingRule::TRIGGER_REFERRAL_PAY)
                ->order('id', 'desc')
                ->select();
            foreach ($rows as $row) {
                $refereeId = (int) $row->referee_user_id;
                if (!isset($logs[$refereeId])) {
                    $logs[$refereeId] = $row;
                }
            }
        }

        $list = [];
        foreach ($pager as $binding) {
            $visitor = $binding->visitor;
            $visitorId = (int) $binding->visitor_user_id;
            $log = $logs[$visitorId] ?? null;
            $status = 'pending';
            $rewardAmount = '0.00';
            $rewardedAt = '';
            if ($log) {
                $status = match ((string) $log->status) {
                    MarketingRuleLog::STATUS_GRANTED => 'rewarded',
                    MarketingRuleLog::STATUS_REVOKED => 'revoked',
                    MarketingRuleLog::STATUS_PENDING => 'pending',
                    default => 'skipped',
                };
                $rewardAmount = (string) $log->reward_amount;
                $rewardedAt = (string) ($log->update_time ?: '');
            } elseif ((string) $binding->status === ShareBinding::STATUS_REWARDED) {
                $status = 'rewarded';
            } elseif ((string) $binding->status === ShareBinding::STATUS_EXPIRED
                || ($binding->expire_at !== null && strtotime((string) $binding->expire_at) <= time())) {
                $status = 'expired';
            }

            $list[] = [
                'visitor_user_id' => $visitorId,
                'nickname'        => $this->maskName($visitor?->nickname, $visitorId),
                'avatar'          => (string) ($visitor?->avatar ?: ''),
                'scene'           => (string) ($binding->scene ?: 'friend'),
                'scene_label'     => $this->sceneLabel((string) $binding->scene),
                'product_id'      => $binding->product_id !== null ? (int) $binding->product_id : null,
                'bound_at'        => (string) $binding->bound_at,
                'expire_at'       => (string) ($binding->expire_at ?: ''),
                'status'          => $status,
                'status_label'    => $this->inviteStatusLabel($status),
                'reward_amount'   => $rewardAmount,
                'rewarded_at'     => $rewardedAt,
            ];
        }

        return [
            'list'      => $list,
            'total'     => (int) $pager->total(),
            'page'      => $page,
            'page_size' => $size,
        ];
    }

    /**
     * 后台概览：今日 / 昨日 / 累计
     */
    public function adminOverview(): array
    {
        $today = date('Y-m-d 00:00:00');
        $tomorrow = date('Y-m-d 00:00:00', strtotime('+1 day'));
        $yesterday = date('Y-m-d 00:00:00', strtotime('-1 day'));

        return [
            'today'     => $this->overviewRange($today, $tomorrow),
            'yesterday' => $this->overviewRange($yesterday, $today),
            'total'     => $this->overviewRange(null, null),
        ];
    }

    /**
     * 按时间范围统计；null 表示不限
     */
    private function overviewRange(?string $from, ?string $to): array
    {
        $merchantIds = $this->merchantScope();

        $shares = $this->scopedShareQuery(ShareReferral::alias('r'), $merchantIds, 'r');
        if ($from !== null) {
            $shares->where('r.create_time', '>=', $from)->where('r.create_time', '<', $to);
        }
        $shareCount = (int) $shares->count();

        $bindings = $this->scopedShareQuery(ShareBinding::alias('b'), $merchantIds, 'b');
        if ($from !== null) {
            $bindings->where('b.bound_at', '>=', $from)->where('b.bound_at', '<', $to);
        }
        $bindingCount = (int) $bindings->count();

        $attrs = Db::name('order_attribution')->alias('a')
            ->join('order o', 'o.id = a.order_id')
            ->leftJoin('share_referral r', 'r.id = a.share_referral_id')
            ->leftJoin('product p', 'p.id = r.product_id');
        if ($from !== null) {
            $attrs->where('a.create_time', '>=', $from)->where('a.create_time', '<', $to);
        }
        if ($merchantIds !== null) {
            $attrs->whereIn('p.merchant_id', $merchantIds);
        }
        $orderCount = (int) (clone $attrs)->count();
        $amount = (string) (clone $attrs)->sum('o.total_amount');

        $rewards = Db::name('marketing_rule_log')->alias('l')
            ->join('marketing_rule r', 'r.id = l.rule_id')
            ->where('r.type', MarketingRule::TYPE_REFERRAL_REWARD)
            ->where('l.status', MarketingRuleLog::STATUS_GRANTED);
        if ($from !== null) {
            $rewards->where('l.create_time', '>=', $from)->where('l.create_time', '<', $to);
        }
        if ($merchantIds !== null) {
            // 非超管只能看到与自己商品相关的奖励：按被邀请人的绑定商品收敛
            $rewards->join('share_binding b', 'b.visitor_user_id = l.referee_user_id')
                ->leftJoin('product p2', 'p2.id = b.product_id')
                ->whereIn('p2.merchant_id', $merchantIds);
        }
        $rewardCount = (int) (clone $rewards)->count();
        $rewardAmount = (string) (clone $rewards)->sum('l.reward_amount');

        return [
            'shares'        => $shareCount,
            'bindings'      => $bindingCount,
            'orders'        => $orderCount,
            'amount'        => bcadd($amount !== '' ? $amount : '0', '0', 2),
            'rewards'       => $rewardCount,
            'reward_amount' => bcadd($rewardAmount !== '' ? $rewardAmount : '0', '0', 2),
        ];
    }

    /**
     * 后台：邀请人维度汇总
     *
     * @param array $filters keyword / date_from / date_to
     * @return array{list:array,total:int,page:int,page_size:int}
     */
    public function adminInviters(array $filters, int $page = 1, int $size = 20): array
    {
        $page = max(1, $page);
        $size = min(max($size, 1), 100);
        $merchantIds = $this->merchantScope();

        $query = Db::name('share_binding')->alias('b')
            ->leftJoin('product p', 'p.id = b.product_id')
            ->leftJoin('user u', 'u.id = b.referrer_user_id')
            ->field('b.referrer_user_id, u.nickname, u.avatar, COUNT(*) AS invited_total,'
                . ' SUM(CASE WHEN b.status = "rewarded" THEN 1 ELSE 0 END) AS rewarded_total,'
                . ' SUM(CASE WHEN b.status = "expired" THEN 1 ELSE 0 END) AS expired_total,'
                . ' MAX(b.bound_at) AS last_bound')
            ->group('b.referrer_user_id');
        if ($merchantIds !== null) {
            $query->whereIn('p.merchant_id', $merchantIds);
        }
        $keyword = trim((string) ($filters['keyword'] ?? ''));
        if ($keyword !== '') {
            if (ctype_digit($keyword)) {
                $query->where('b.referrer_user_id', (int) $keyword);
            } else {
                $query->whereLike('u.nickname', '%' . $keyword . '%');
            }
        }
        if (!empty($filters['date_from'])) {
            $query->where('b.bound_at', '>=', $filters['date_from'] . ' 00:00:00');
        }
        if (!empty($filters['date_to'])) {
            $query->where('b.bound_at', '<=', $filters['date_to'] . ' 23:59:59');
        }

        $pager = $query->order('invited_total', 'desc')->paginate($size, false, ['page' => $page]);

        $referrerIds = [];
        foreach ($pager as $row) {
            $referrerIds[] = (int) $row['referrer_user_id'];
        }
        $rewardMap = [];
        $closedMap = [];
        if ($referrerIds) {
            $rows = Db::name('marketing_rule_log')->alias('l')
                ->join('marketing_rule r', 'r.id = l.rule_id')
                ->whereIn('l.user_id', array_values(array_unique($referrerIds)))
                ->where('r.type', MarketingRule::TYPE_REFERRAL_REWARD)
                ->where('l.status', MarketingRuleLog::STATUS_GRANTED)
                ->field('l.user_id, COUNT(*) AS reward_count, SUM(l.reward_amount) AS reward_amount')
                ->group('l.user_id')
                ->select();
            foreach ($rows as $row) {
                $rewardMap[(int) $row['user_id']] = $row;
            }

            $closedRows = Db::name('marketing_rule_log')->alias('l')
                ->join('marketing_rule r', 'r.id = l.rule_id')
                ->whereIn('l.user_id', array_values(array_unique($referrerIds)))
                ->where('r.type', MarketingRule::TYPE_REFERRAL_REWARD)
                ->whereIn('l.status', [MarketingRuleLog::STATUS_SKIPPED, MarketingRuleLog::STATUS_REVOKED])
                ->field('l.user_id, COUNT(*) AS closed_count')
                ->group('l.user_id')
                ->select();
            foreach ($closedRows as $row) {
                $closedMap[(int) $row['user_id']] = (int) $row['closed_count'];
            }
        }

        $list = [];
        foreach ($pager as $row) {
            $referrerId = (int) $row['referrer_user_id'];
            $invited = (int) $row['invited_total'];
            $rewarded = (int) $row['rewarded_total'];
            $expired = (int) $row['expired_total'];
            $closed = $closedMap[$referrerId] ?? 0;
            $reward = $rewardMap[$referrerId] ?? null;
            $list[] = [
                'referrer_user_id' => $referrerId,
                'referrer_name'    => $this->maskName($row['nickname'] ?? null, $referrerId),
                'avatar'           => (string) ($row['avatar'] ?? ''),
                'invited_total'    => $invited,
                'pending_total'    => max(0, $invited - $rewarded - $expired - $closed),
                'rewarded_total'   => $rewarded,
                'expired_total'    => $expired,
                'reward_count'     => (int) ($reward['reward_count'] ?? 0),
                'reward_amount'    => bcadd((string) ($reward['reward_amount'] ?? '0'), '0', 2),
                'last_bound'       => (string) ($row['last_bound'] ?? ''),
            ];
        }

        return [
            'list'      => $list,
            'total'     => (int) $pager->total(),
            'page'      => $page,
            'page_size' => $size,
        ];
    }

    /**
     * 后台：分享事件流水
     */
    public function adminReferrals(array $filters, int $page = 1, int $size = 20): array
    {
        $page = max(1, $page);
        $size = min(max($size, 1), 100);
        $merchantIds = $this->merchantScope();

        $query = Db::name('share_referral')->alias('r')
            ->leftJoin('product p', 'p.id = r.product_id')
            ->leftJoin('user u', 'u.id = r.referrer_user_id')
            ->leftJoin('user v', 'v.id = r.visitor_user_id')
            ->field('r.*, p.title AS product_title, u.nickname AS referrer_nickname, v.nickname AS visitor_nickname');
        if ($merchantIds !== null) {
            $query->whereIn('p.merchant_id', $merchantIds);
        }
        $this->applyDateFilter($query, 'r.create_time', $filters);
        $this->applyKeywordFilter($query, $filters, 'r.referrer_user_id', 'u.nickname');

        $pager = $query->order('r.id', 'desc')->paginate($size, false, ['page' => $page]);

        $list = [];
        foreach ($pager as $row) {
            $list[] = [
                'id'              => (int) $row['id'],
                'referrer_user_id' => (int) $row['referrer_user_id'],
                'referrer_name'   => $this->maskName($row['referrer_nickname'] ?? null, (int) $row['referrer_user_id']),
                'visitor_user_id' => (int) $row['visitor_user_id'],
                'visitor_name'    => $this->maskName($row['visitor_nickname'] ?? null, (int) $row['visitor_user_id']),
                'product_id'      => $row['product_id'] !== null ? (int) $row['product_id'] : null,
                'product_title'   => (string) ($row['product_title'] ?? '-'),
                'scene'           => (string) ($row['scene'] ?? ''),
                'scene_label'     => $this->sceneLabel((string) ($row['scene'] ?? '')),
                'create_time'     => (string) ($row['create_time'] ?? ''),
            ];
        }

        return ['list' => $list, 'total' => (int) $pager->total(), 'page' => $page, 'page_size' => $size];
    }

    /**
     * 后台：邀请绑定关系
     */
    public function adminBindings(array $filters, int $page = 1, int $size = 20): array
    {
        $page = max(1, $page);
        $size = min(max($size, 1), 100);
        $merchantIds = $this->merchantScope();

        $query = Db::name('share_binding')->alias('b')
            ->leftJoin('product p', 'p.id = b.product_id')
            ->leftJoin('user u', 'u.id = b.referrer_user_id')
            ->leftJoin('user v', 'v.id = b.visitor_user_id')
            ->field('b.*, p.title AS product_title, u.nickname AS referrer_nickname, v.nickname AS visitor_nickname');
        if ($merchantIds !== null) {
            $query->whereIn('p.merchant_id', $merchantIds);
        }
        $status = trim((string) ($filters['status'] ?? ''));
        if ($status !== '') {
            $query->where('b.status', $status);
        }
        $this->applyDateFilter($query, 'b.bound_at', $filters);
        $this->applyKeywordFilter($query, $filters, 'b.referrer_user_id', 'u.nickname');

        $pager = $query->order('b.id', 'desc')->paginate($size, false, ['page' => $page]);

        $list = [];
        foreach ($pager as $row) {
            $list[] = [
                'id'              => (int) $row['id'],
                'referrer_user_id' => (int) $row['referrer_user_id'],
                'referrer_name'   => $this->maskName($row['referrer_nickname'] ?? null, (int) $row['referrer_user_id']),
                'visitor_user_id' => (int) $row['visitor_user_id'],
                'visitor_name'    => $this->maskName($row['visitor_nickname'] ?? null, (int) $row['visitor_user_id']),
                'product_title'   => (string) ($row['product_title'] ?? '-'),
                'scene_label'     => $this->sceneLabel((string) ($row['scene'] ?? '')),
                'status'          => (string) $row['status'],
                'status_label'    => $this->bindingStatusLabel((string) $row['status']),
                'bound_at'        => (string) ($row['bound_at'] ?? ''),
                'expire_at'       => (string) ($row['expire_at'] ?? ''),
                'rewarded_at'     => (string) ($row['rewarded_at'] ?? ''),
            ];
        }

        return ['list' => $list, 'total' => (int) $pager->total(), 'page' => $page, 'page_size' => $size];
    }

    /**
     * 后台：邀请奖励记录
     */
    public function adminRewards(array $filters, int $page = 1, int $size = 20): array
    {
        $page = max(1, $page);
        $size = min(max($size, 1), 100);
        $merchantIds = $this->merchantScope();

        $query = Db::name('marketing_rule_log')->alias('l')
            ->join('marketing_rule r', 'r.id = l.rule_id')
            ->leftJoin('user u', 'u.id = l.user_id')
            ->leftJoin('user v', 'v.id = l.referee_user_id')
            ->where('r.type', MarketingRule::TYPE_REFERRAL_REWARD)
            ->field('l.*, r.name AS rule_name, u.nickname AS referrer_nickname, v.nickname AS visitor_nickname');
        if ($merchantIds !== null) {
            $query->join('share_binding b', 'b.visitor_user_id = l.referee_user_id')
                ->leftJoin('product p', 'p.id = b.product_id')
                ->whereIn('p.merchant_id', $merchantIds);
        }
        $status = trim((string) ($filters['status'] ?? ''));
        if ($status !== '') {
            $query->where('l.status', $status);
        }
        $this->applyDateFilter($query, 'l.create_time', $filters);
        $this->applyKeywordFilter($query, $filters, 'l.user_id', 'u.nickname');

        $pager = $query->order('l.id', 'desc')->paginate($size, false, ['page' => $page]);

        $list = [];
        foreach ($pager as $row) {
            $list[] = [
                'id'              => (int) $row['id'],
                'rule_name'       => (string) ($row['rule_name'] ?? ''),
                'referrer_user_id' => (int) $row['user_id'],
                'referrer_name'   => $this->maskName($row['referrer_nickname'] ?? null, (int) $row['user_id']),
                'visitor_user_id' => $row['referee_user_id'] !== null ? (int) $row['referee_user_id'] : 0,
                'visitor_name'    => $this->maskName($row['visitor_nickname'] ?? null, (int) ($row['referee_user_id'] ?? 0)),
                'amount'          => bcadd((string) ($row['reward_amount'] ?? '0'), '0', 2),
                'coupon_user_id'  => $row['coupon_user_id'] !== null ? (int) $row['coupon_user_id'] : null,
                'status'          => (string) $row['status'],
                'status_label'    => MarketingRuleLog::STATUS_LABELS[(string) $row['status']] ?? (string) $row['status'],
                'skip_reason'     => (string) ($row['skip_reason'] ?? ''),
                'create_time'     => (string) ($row['create_time'] ?? ''),
            ];
        }

        return ['list' => $list, 'total' => (int) $pager->total(), 'page' => $page, 'page_size' => $size];
    }

    /**
     * 邀请转化排行（历史方法，保留给旧调用）
     */
    public function conversionRank(\DateTime $from, \DateTime $to): array
    {
        $rows = OrderAttribution::alias('a')
            ->join('order o', 'a.order_id = o.id')
            ->whereTime('a.create_time', 'between', [$from->format('Y-m-d H:i:s'), $to->format('Y-m-d H:i:s')])
            ->field('a.referrer_user_id, count(*) as order_count, sum(o.total_amount) as amount')
            ->group('a.referrer_user_id')
            ->order('amount', 'desc')
            ->select();
        return $rows->toArray();
    }

    /**
     * 当前启用中的分享拉新规则（用于展示奖励面额/有效期）
     */
    private function activeReferralRule(): ?MarketingRule
    {
        $now = date('Y-m-d H:i:s');
        return MarketingRule::where('status', 1)
            ->where('type', MarketingRule::TYPE_REFERRAL_REWARD)
            ->where(function ($q) use ($now) {
                $q->whereNull('start_time')->whereOr('start_time', '<=', $now);
            })
            ->where(function ($q) use ($now) {
                $q->whereNull('end_time')->whereOr('end_time', '>=', $now);
            })
            ->order('priority')->order('id')
            ->find();
    }

    /**
     * 是否已有已支付订单（「新用户」口径与营销引擎一致）
     */
    private function hasPaidOrder(int $userId): bool
    {
        return (int) OrderPay::where('user_id', $userId)
            ->where('pay_status', PayStatus::PAID)
            ->count() > 0;
    }

    /**
     * 后台数据范围：null = 超管不限；数组 = 仅这些商户的商品
     */
    private function merchantScope(): ?array
    {
        if (AppContext::getAdminRole() === AdminRole::SUPER) {
            return null;
        }
        return array_values(array_map('intval', AppContext::getMerchantIds()));
    }

    /**
     * 给分享/绑定查询套上商品商户范围（无商品的分享只对超管可见）
     */
    private function scopedShareQuery($query, ?array $merchantIds, string $alias)
    {
        if ($merchantIds !== null) {
            $query->leftJoin('product p', 'p.id = ' . $alias . '.product_id')
                ->whereIn('p.merchant_id', $merchantIds);
        }
        return $query;
    }

    private function applyDateFilter($query, string $field, array $filters): void
    {
        if (!empty($filters['date_from'])) {
            $query->where($field, '>=', $filters['date_from'] . ' 00:00:00');
        }
        if (!empty($filters['date_to'])) {
            $query->where($field, '<=', $filters['date_to'] . ' 23:59:59');
        }
    }

    private function applyKeywordFilter($query, array $filters, string $idField, string $nameField): void
    {
        $keyword = trim((string) ($filters['keyword'] ?? ''));
        if ($keyword === '') {
            return;
        }
        if (ctype_digit($keyword)) {
            $query->where($idField, (int) $keyword);
        } else {
            $query->whereLike($nameField, '%' . $keyword . '%');
        }
    }

    private function sceneLabel(string $scene): string
    {
        return $scene === 'group' ? '群聊' : '好友';
    }

    private function inviteStatusLabel(string $status): string
    {
        return [
            'pending'  => '待好友首单',
            'rewarded' => '已奖励',
            'revoked'  => '奖励已退回',
            'skipped'  => '未满足条件',
            'expired'  => '邀请已过期',
        ][$status] ?? '待好友首单';
    }

    private function bindingStatusLabel(string $status): string
    {
        return [
            ShareBinding::STATUS_BOUND    => '待首单',
            ShareBinding::STATUS_REWARDED => '已奖励',
            ShareBinding::STATUS_EXPIRED  => '已过期',
            ShareBinding::STATUS_INVALID  => '无效',
        ][$status] ?? $status;
    }

    private function maskName(?string $name, int $userId): string
    {
        $name = trim((string) $name);
        if ($name === '') {
            return '用户' . $userId;
        }
        $length = mb_strlen($name);
        if ($length <= 1) {
            return $name . '*';
        }
        if ($length === 2) {
            return mb_substr($name, 0, 1) . '*';
        }
        return mb_substr($name, 0, 1) . str_repeat('*', $length - 2) . mb_substr($name, -1);
    }

    private function isDuplicateKey(\Throwable $e): bool
    {
        $message = $e->getMessage();
        return str_contains($message, 'Duplicate entry') || str_contains($message, '1062');
    }
}
