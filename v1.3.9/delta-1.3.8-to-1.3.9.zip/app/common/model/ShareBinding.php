<?php
declare (strict_types = 1);

namespace app\common\model;

/**
 * 分享拉新绑定关系
 *
 * 一个被邀请人只有一条记录；首触优先，过期且尚未成单时可被新分享替换。
 * 奖励与订单归因都以 binding 为准，不再使用「最新一条分享事件」。
 */
class ShareBinding extends BaseModel
{
    protected $name = 'share_binding';
    protected $autoWriteTimestamp = 'datetime';

    /** 已绑定，等待被邀请人首单 */
    public const STATUS_BOUND = 'bound';

    /** 已发放邀请奖励 */
    public const STATUS_REWARDED = 'rewarded';

    /** 已过期 */
    public const STATUS_EXPIRED = 'expired';

    /** 无效（自邀、邀请人不存在等） */
    public const STATUS_INVALID = 'invalid';

    public function referrer()
    {
        return $this->belongsTo(User::class, 'referrer_user_id');
    }

    public function visitor()
    {
        return $this->belongsTo(User::class, 'visitor_user_id');
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }
}
