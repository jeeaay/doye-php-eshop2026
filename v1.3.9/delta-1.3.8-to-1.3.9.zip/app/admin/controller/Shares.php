<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\service\ShareService;
use think\facade\View;

/**
 * 后台「分享归因」页
 *
 * 四个视图共用同一个入口：概况 / 分享记录 / 邀请关系 / 奖励记录。
 * 数据组装全部在 ShareService，页面与管理 API 共用同一口径。
 */
class Shares extends AdminBaseController
{
    private const TABS = ['overview', 'referrals', 'bindings', 'rewards'];

    public function index()
    {
        $this->assignActiveMenu('share');

        $service = new ShareService();
        $tab = (string) $this->request->get('tab', 'overview');
        if (!in_array($tab, self::TABS, true)) {
            $tab = 'overview';
        }
        $page = max(1, (int) $this->request->get('page', 1));
        $size = 20;
        $filters = [
            'keyword'   => trim((string) $this->request->get('keyword', '')),
            'status'    => trim((string) $this->request->get('status', '')),
            'date_from' => trim((string) $this->request->get('date_from', '')),
            'date_to'   => trim((string) $this->request->get('date_to', '')),
        ];

        $overview = $service->adminOverview();

        $list = [];
        $total = 0;
        if ($tab === 'overview') {
            $result = $service->adminInviters($filters, $page, $size);
            $list = $result['list'];
            $total = $result['total'];
        } elseif ($tab === 'referrals') {
            $result = $service->adminReferrals($filters, $page, $size);
            $list = $result['list'];
            $total = $result['total'];
        } elseif ($tab === 'bindings') {
            $result = $service->adminBindings($filters, $page, $size);
            $list = $result['list'];
            $total = $result['total'];
        } elseif ($tab === 'rewards') {
            $result = $service->adminRewards($filters, $page, $size);
            $list = $result['list'];
            $total = $result['total'];
        }

        $totalPages = max(1, (int) ceil($total / $size));
        $query = array_filter([
            'tab'       => $tab,
            'keyword'   => $filters['keyword'],
            'status'    => $filters['status'],
            'date_from' => $filters['date_from'],
            'date_to'   => $filters['date_to'],
        ], static fn ($value) => $value !== '' && $value !== null);

        View::assign('tab', $tab);
        View::assign('overview', $overview);
        View::assign('list', $list);
        View::assign('filters', $filters);
        View::assign('total', $total);
        View::assign('page_no', $page);
        View::assign('total_pages', $totalPages);
        View::assign('prev_url', $page > 1
            ? admin_base() . '/share?' . http_build_query($query + ['page' => $page - 1])
            : '');
        View::assign('next_url', $page < $totalPages
            ? admin_base() . '/share?' . http_build_query($query + ['page' => $page + 1])
            : '');

        return View::fetch();
    }
}
