<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\model\Category;
use app\common\model\MarketingRule;
use app\common\model\Merchant;
use app\common\service\CouponService;
use app\common\service\CurrencyService;
use app\common\service\MarketingService;
use app\common\support\AppContext;
use think\facade\View;

/**
 * 后台营销规则管理（拉新奖励 / 确认收货返利）
 *
 * 平台级能力，只有超管可用：菜单按角色隐藏，页面再做一次跳转兜底，
 * 真正的读写收口在 MarketingService（与管理 API 同一口径），控制器不写业务判断。
 */
class Marketing extends AdminBaseController
{
    /**
     * 规则列表页
     *
     * @return \think\response\View|\think\response\Redirect
     */
    public function index()
    {
        $this->assignActiveMenu('marketing');
        if (!$this->isSuper()) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可管理营销规则');
        }

        $filters = [
            'keyword' => trim((string) $this->request->get('keyword', '')),
            'type'    => (string) $this->request->get('type', ''),
            'status'  => $this->request->get('status', ''),
        ];

        $result = (new MarketingService())->adminList($filters, (int) $this->request->get('page', 1));

        View::assign('rules', $result['list']);
        View::assign('filters', $filters);
        View::assign('rules_link', $result['pager']->render());
        View::assign('type_options', (new MarketingService())->typeOptions());

        return View::fetch();
    }

    /**
     * 新增 / 编辑规则表单
     *
     * @return \think\response\View|\think\response\Redirect
     */
    public function form()
    {
        $this->assignActiveMenu('marketing');
        if (!$this->isSuper()) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可管理营销规则');
        }

        $service = new MarketingService();
        $id = (int) $this->request->get('id', 0);

        $rule = [
            'id'            => 0,
            'name'          => '',
            'type'          => MarketingRule::TYPE_ORDER_GIFT,
            'trigger_event' => MarketingRule::TRIGGER_PAY,
            'trigger_label' => MarketingRule::TRIGGER_LABELS[MarketingRule::TRIGGER_PAY],
            'reward_mode'   => MarketingRule::REWARD_FIXED,
            'reward_value'  => '5.00',
            'reward_cap'    => '0.00',
            'coupon_id'     => null,
            'inline_coupon' => ['name' => '', 'min_amount' => '0.00', 'valid_days' => 30, 'expire_at' => ''],
            'conditions'    => [
                'min_order_amount'      => '0.00',
                'new_user_only'         => true,
                'referee_new_user_only' => false,
                'merchant_ids'          => [],
                'category_ids'          => [],
                'product_ids'           => [],
            ],
            'total_limit'   => 0,
            'issued_qty'    => 0,
            'per_user_limit' => 1,
            'start_time'    => '',
            'end_time'      => '',
            'status'        => 1,
            'priority'      => 0,
            'remark'        => '',
        ];

        if ($id > 0) {
            try {
                $rule = $service->adminDetail($id);
            } catch (BizException $e) {
                return redirect(admin_url('marketing'))->with('error', $e->getMessage());
            }
        }

        View::assign('rule', $rule);
        View::assign('currency_symbol', (string) ((new CurrencyService())->base()['symbol'] ?? ''));
        View::assign('rule_json', $this->json($rule));
        View::assign('types_json', $this->json($service->typeOptions()));
        View::assign('coupons_json', $this->json($service->couponOptions($rule['coupon_id'] ?? null)));
        View::assign('merchants_json', $this->json($this->optionRows(Merchant::where('status', 1)->order('id')->field('id,name')->select())));
        View::assign('categories_json', $this->json($this->optionRows(
            Category::order('sort')->order('id')->field('id,name')->select()
        )));
        View::assign('products_json', $this->json((new CouponService())->productOptions()));

        return View::fetch('marketing/form');
    }

    /**
     * 发放记录页
     *
     * @return \think\response\View|\think\response\Redirect
     */
    public function logs()
    {
        $this->assignActiveMenu('marketing');
        if (!$this->isSuper()) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可管理营销规则');
        }

        $filters = [
            'rule_id'  => (int) $this->request->get('rule_id', 0),
            'user_id'  => (int) $this->request->get('user_id', 0),
            'order_id' => (int) $this->request->get('order_id', 0),
            'status'   => (string) $this->request->get('status', ''),
        ];

        $result = (new MarketingService())->adminLogs($filters, (int) $this->request->get('page', 1));

        View::assign('logs', $result['list']);
        View::assign('filters', $filters);
        View::assign('logs_link', $result['pager']->render());
        View::assign('rules', (new MarketingService())->adminList([], 1, 200)['list']);

        return View::fetch();
    }

    /**
     * 保存规则（新增 / 更新）
     *
     * @return \think\response\Json
     */
    public function save()
    {
        try {
            $data = $this->request->post();
            $id = !empty($data['id']) ? (int) $data['id'] : null;
            $ruleId = (new MarketingService())->adminSave($data, $id);

            return json(['code' => 0, 'message' => '营销规则已保存', 'data' => ['id' => $ruleId]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 启用 / 停用规则
     *
     * @return \think\response\Json
     */
    public function status()
    {
        try {
            (new MarketingService())->adminToggle(
                (int) $this->request->post('id', 0),
                (int) $this->request->post('status', 1)
            );

            return json(['code' => 0, 'message' => '规则状态已更新', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 删除规则
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        try {
            (new MarketingService())->adminDelete((int) $this->request->post('id', 0));

            return json(['code' => 0, 'message' => '营销规则已删除', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 选择器数据统一成 {id,name}（商品用 title）
     *
     * @param iterable $rows 模型集合
     * @return array<int,array{id:int,name:string}>
     */
    private function optionRows($rows): array
    {
        $out = [];
        foreach ($rows as $row) {
            $out[] = ['id' => (int) $row->id, 'name' => (string) ($row->name ?? $row->title)];
        }

        return $out;
    }

    /**
     * 传给前端组件的 JSON（转义标签与引号，避免提前闭合 script）
     *
     * @param mixed $value 数据
     * @return string
     */
    private function json($value): string
    {
        return (string) json_encode($value, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    }

    /**
     * 当前登录管理员是否为平台超级管理员
     *
     * @return bool
     */
    private function isSuper(): bool
    {
        return AppContext::getAdminRole() === AdminRole::SUPER;
    }
}
