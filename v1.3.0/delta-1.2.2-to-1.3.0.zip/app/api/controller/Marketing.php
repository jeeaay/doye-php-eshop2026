<?php
declare(strict_types=1);

namespace app\api\controller;

use app\BaseController;
use app\common\service\MarketingService;
use app\common\support\AppContext;

/**
 * 营销前台接口
 *
 * 当前只有「某笔订单已到账返利」查询，供确认收货后的订单详情提示使用；
 * 查询一律走 MarketingService，控制器不做 SQL。
 */
class Marketing extends BaseController
{
    /**
     * 某笔订单已到账的返利（只能查自己的订单）
     *
     * @return \think\Response
     */
    public function benefits()
    {
        $userId  = (int) AppContext::getUserId();
        $orderId = (int) $this->request->get('order_id', 0);
        if ($orderId <= 0) {
            return $this->error(40001, '参数错误');
        }

        return $this->success([
            'list' => (new MarketingService())->benefitsByOrder($orderId, $userId),
        ]);
    }
}
