<?php
use app\common\middleware\RateLimit;
use app\common\middleware\UserAuth;
use think\facade\Route;

Route::group(function () {
    Route::post('auth/login', 'Auth/login');
    Route::get('product/list', 'Product/list');
    Route::get('product/detail', 'Product/detail');
    Route::get('category/tree', 'Category/tree');
    Route::get('home/ops', 'HomeOps/ops');
    Route::get('payment/channels', 'Payment/channels');
    // Dynamic rule must be registered before the legacy static rule because
    // route_complete_match is disabled globally.
    Route::post('payment/notify/:channel', 'Payment/notify')->completeMatch();
    Route::post('payment/notify', 'Payment/notify')->completeMatch();
})->middleware(RateLimit::class);

// --- 独立站（浏览器）专用接口 ---
Route::group(function () {
    Route::post('site/auth/send-code', 'Site/sendCode');
    Route::post('site/auth/verify-code', 'Site/verifyCode');
    Route::get('site/auth/me', 'Site/me');
    Route::post('site/auth/sign-out', 'Site/signOut');
    Route::post('site/contact', 'Site/contact');
})->middleware(RateLimit::class);

Route::group(function () {
    Route::post('cart/add', 'Cart/add');
    Route::get('cart/list', 'Cart/list');
    Route::post('cart/update', 'Cart/update');
    Route::post('cart/remove', 'Cart/remove');

    Route::get('coupon/list', 'Coupon/list');
    Route::get('coupon/my-coupons', 'Coupon/myCoupons');
    Route::get('marketing/benefits', 'Marketing/benefits');
    Route::post('coupon/mine', 'Coupon/mine');
    Route::post('coupon/claim', 'Coupon/claim');
    Route::post('coupon/quote', 'Coupon/quote');

    Route::post('order/checkout', 'Order/checkout');
    Route::post('order/pay', 'Order/pay');
    Route::get('order/list', 'Order/list');
    Route::get('order/detail', 'Order/detail');
    Route::get('order/logistics', 'Order/logistics');
    Route::post('order/confirm', 'Order/confirm');
    Route::post('order/cancel', 'Order/cancel');
    Route::get('payment/status', 'Payment/status');

    Route::post('aftersale/apply', 'Aftersale/apply');
    Route::get('aftersale/list', 'Aftersale/list');
    Route::get('aftersale/detail', 'Aftersale/detail');

    Route::post('share/report', 'Share/report');

    Route::get('user/profile', 'User/profile');
    Route::post('user/update', 'User/update');
    Route::post('user/avatar', 'User/avatar');
    Route::post('user/bind-phone', 'User/bindPhone');
    Route::get('user/address/list', 'User/addressList');
    Route::post('user/address/add', 'User/addressAdd');
    Route::post('user/address/update', 'User/addressUpdate');
    Route::post('user/address/delete', 'User/addressDelete');
})->middleware([UserAuth::class, RateLimit::class]);