<?php
declare(strict_types=1);

namespace app\common\lib;

/**
 * 事务性邮件模板（券到账 / 到期提醒 / 券退回）
 *
 * 只渲染 HTML 字符串，不接模板引擎：邮件不需要 layout 继承，且在 CLI 里能直接单测。
 * 基准语言取 base_locale()（国内版 zh、国际版 en），缺文案时回退英文。
 * 所有变量输出前统一转义，模板里不拼 SQL / 不读请求参数。
 */
class MailTemplate
{
    /** 场景 => 中/英模板 */
    private const COPY = [
        'grant_arrived' => [
            'zh' => [
                'subject' => '「%s」优惠券已到账',
                'title'   => '优惠券已到账',
                'intro'   => '你好 %s，你获得了一张优惠券，已存入账户：',
                'cta'     => '去查看我的优惠券',
            ],
            'en' => [
                'subject' => 'Your coupon from %s has arrived',
                'title'   => 'Your coupon has arrived',
                'intro'   => 'Hi %s, a coupon has been added to your account:',
                'cta'     => 'View my coupons',
            ],
        ],
        'expiring_soon' => [
            'zh' => [
                'subject' => '「%s」优惠券即将过期',
                'title'   => '优惠券即将过期',
                'intro'   => '你好 %s，以下优惠券即将过期，请尽快使用：',
                'cta'     => '去使用优惠券',
            ],
            'en' => [
                'subject' => 'Your coupon from %s expires soon',
                'title'   => 'Your coupon expires soon',
                'intro'   => 'Hi %s, the following coupon will expire soon:',
                'cta'     => 'Use my coupon',
            ],
        ],
        'coupon_restored' => [
            'zh' => [
                'subject' => '「%s」退款完成，优惠券已退回',
                'title'   => '优惠券已退回',
                'intro'   => '你好 %s，订单已全额退款，当时使用的优惠券已退回账户：',
                'cta'     => '去查看我的优惠券',
            ],
            'en' => [
                'subject' => '%s: coupon restored after refund',
                'title'   => 'Coupon restored',
                'intro'   => 'Hi %s, your order has been fully refunded and the coupon you used is back in your account:',
                'cta'     => 'View my coupons',
            ],
        ],
    ];

    /**
     * 渲染一封邮件
     *
     * @param string $scene 场景：grant_arrived / expiring_soon / coupon_restored
     * @param array  $vars  brand, name, coupon_name, amount_text, min_amount, expire_at, link
     * @return array{subject:string,html:string}
     */
    public static function render(string $scene, array $vars): array
    {
        $lang = str_starts_with(base_locale(), 'zh') ? 'zh' : 'en';
        $copy = self::COPY[$scene][$lang] ?? self::COPY[$scene]['en'];

        $brand      = self::e((string) ($vars['brand'] ?? ''));
        $name       = self::e(self::displayName((string) ($vars['name'] ?? '')));
        $couponName = self::e((string) ($vars['coupon_name'] ?? ''));
        $amount     = self::e((string) ($vars['amount_text'] ?? ''));
        $minAmount  = (string) ($vars['min_amount'] ?? '0.00');
        $expireAt   = (string) ($vars['expire_at'] ?? '');
        $link       = self::safeLink((string) ($vars['link'] ?? ''));

        $labels = $lang === 'zh'
            ? ['coupon' => '优惠券', 'amount' => '面额', 'threshold' => '使用门槛', 'expire' => '到期时间', 'noThreshold' => '无门槛']
            : ['coupon' => 'Coupon', 'amount' => 'Value', 'threshold' => 'Minimum spend', 'expire' => 'Expires at', 'noThreshold' => 'No minimum'];

        $threshold = bccomp($minAmount, '0', 2) > 0 ? $minAmount : $labels['noThreshold'];

        $rows = '<tr><td style="padding:6px 12px;color:#666">' . $labels['coupon'] . '</td>'
            . '<td style="padding:6px 12px;font-weight:600">' . $couponName . '</td></tr>'
            . '<tr><td style="padding:6px 12px;color:#666">' . $labels['amount'] . '</td>'
            . '<td style="padding:6px 12px;font-weight:600">' . $amount . '</td></tr>'
            . '<tr><td style="padding:6px 12px;color:#666">' . $labels['threshold'] . '</td>'
            . '<td style="padding:6px 12px">' . self::e($threshold) . '</td></tr>';

        if ($expireAt !== '') {
            $rows .= '<tr><td style="padding:6px 12px;color:#666">' . $labels['expire'] . '</td>'
                . '<td style="padding:6px 12px">' . self::e($expireAt) . '</td></tr>';
        }

        $button = $link === ''
            ? ''
            : '<p style="margin:24px 0 0"><a href="' . $link . '" '
                . 'style="display:inline-block;padding:10px 20px;background:#111;color:#fff;text-decoration:none;border-radius:6px">'
                . self::e($copy['cta']) . '</a></p>';

        $html = '<!doctype html><html><body style="margin:0;background:#f6f6f6;font-family:-apple-system,Segoe UI,Arial,sans-serif">'
            . '<div style="max-width:560px;margin:24px auto;background:#fff;border-radius:8px;padding:24px;color:#222">'
            . '<p style="margin:0 0 16px;font-size:13px;color:#888">' . $brand . '</p>'
            . '<h2 style="margin:0 0 16px;font-size:20px">' . self::e($copy['title']) . '</h2>'
            . '<p style="margin:0 0 16px">' . sprintf($copy['intro'], $name) . '</p>'
            . '<table style="border-collapse:collapse;font-size:14px">' . $rows . '</table>'
            . $button
            . '</div></body></html>';

        return [
            'subject' => sprintf((string) $copy['subject'], (string) ($vars['brand'] ?? '')),
            'html'    => $html,
        ];
    }

    /**
     * 收件人显示名：有昵称用昵称，没有就给一个中性称呼
     *
     * @param string $name 昵称
     * @return string
     */
    private static function displayName(string $name): string
    {
        return $name !== '' ? $name : (str_starts_with(base_locale(), 'zh') ? '你好' : 'there');
    }

    /**
     * HTML 转义
     *
     * @param string $value 原值
     * @return string
     */
    private static function e(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    /**
     * 只允许 http(s) 链接，避免模板被注入 javascript:
     *
     * @param string $link 链接
     * @return string
     */
    private static function safeLink(string $link): string
    {
        return preg_match('#^https?://#i', $link) === 1 ? self::e($link) : '';
    }
}
