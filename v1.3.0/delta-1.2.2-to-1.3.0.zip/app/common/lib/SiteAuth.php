<?php
declare(strict_types=1);

namespace app\common\lib;

use app\common\exception\BizException;
use app\common\model\User;
use app\common\service\MarketingService;
use app\common\service\UserService;
use think\facade\Log;

/**
 * 前台（浏览器）登录：邮箱 + 验证码
 *
 * 背景：PHP 后台原本只有微信小程序登录（code2session -> openid），
 * 浏览器端无法取得 wx.login 的 code，因此独立站需要一个可在浏览器完成的登录方式。
 * 这里补一个最小实现的邮箱验证码登录，签发与小程序相同的 Bearer token
 * （Redis key: token:{token}），从而复用后台全部 /api/* 用户接口。
 *
 * 依赖：user.email 字段（见 database/migrations 中 add_user_email_for_web_login）。
 */
class SiteAuth
{
    private const CODE_PREFIX     = 'site:auth:code:';
    private const ATTEMPT_PREFIX  = 'site:auth:try:';
    private const THROTTLE_PREFIX = 'site:auth:at:';
    private const CODE_TTL        = 600;

    public function sendCode(string $email): array
    {
        $email = self::normalizeEmail($email);
        $interval = (int) site_config('auth.resend_interval', 60);
        $throttleKey = self::THROTTLE_PREFIX . md5($email);
        if (RedisCache::get($throttleKey)) {
            throw new BizException('发送过于频繁，请稍后再试');
        }

        $code = (string) random_int(100000, 999999);
        $ttl = (int) site_config('auth.code_ttl', self::CODE_TTL);
        RedisCache::set(self::CODE_PREFIX . md5($email), $code, $ttl);
        RedisCache::del(self::ATTEMPT_PREFIX . md5($email));
        RedisCache::set($throttleKey, 1, $interval);

        $sent = $this->deliver($email, $code);
        $dev = (bool) site_config('auth.dev_show_code', false);

        return [
            'sent'      => $sent,
            'ttl'       => $ttl,
            'dev_mode'  => $dev,
            // 仅在开发模式（未配置邮件服务）下回显验证码，便于本地联调
            'dev_code'  => $dev ? $code : null,
        ];
    }

    public function verifyCode(string $email, string $code): array
    {
        $email = self::normalizeEmail($email);
        $code = trim($code);
        if (!preg_match('/^\d{6}$/', $code)) {
            throw new BizException('验证码格式不正确');
        }

        $key = self::CODE_PREFIX . md5($email);
        $cached = RedisCache::get($key);
        if (!$cached) {
            throw new BizException('验证码已过期，请重新获取');
        }

        $attemptKey = self::ATTEMPT_PREFIX . md5($email);
        $attempts = (int) RedisCache::get($attemptKey);
        $maxAttempts = (int) site_config('auth.max_attempts', 5);
        if ($attempts >= $maxAttempts) {
            RedisCache::del($key);
            throw new BizException('尝试次数过多，请重新获取验证码');
        }

        if (!hash_equals((string) $cached, $code)) {
            RedisCache::set($attemptKey, $attempts + 1, (int) site_config('auth.code_ttl', self::CODE_TTL));
            throw new BizException('验证码不正确');
        }

        RedisCache::del($key);
        RedisCache::del($attemptKey);

        $user = $this->findOrCreateUser($email);
        $token = bin2hex(random_bytes(16));
        RedisCache::set('token:' . $token, (int) $user->id, UserService::TOKEN_TTL);

        return ['token' => $token, 'user' => $user];
    }

    public function findOrCreateUser(string $email): User
    {
        $user = User::where('email', $email)->find();
        if ($user) {
            return $user;
        }

        // user.openid 为 NOT NULL，浏览器用户用固定前缀占位，避免与微信 openid 冲突
        $user = new User();
        $user->openid = 'web_' . substr(sha1($email), 0, 24);
        $user->email = $email;
        $user->nickname = self::nicknameFromEmail($email);
        $user->save();
        $user = User::find($user->id);

        // 注册即发的新人礼只在这里挂：本方法是浏览器端唯一造出新用户的地方。
        // 发券失败不能挡住登录（签发 token 在前台是主流程），MarketingService 内部已把异常
        // 落进 marketing_rule_log 交给 php think marketing:grant 补偿，这里再兜一层。
        try {
            (new MarketingService())->grantOnRegister((int) $user->id);
        } catch (\Throwable $e) {
            Log::error('marketing grant on register failed: user=' . (int) $user->id . ' err=' . $e->getMessage());
        }

        return $user;
    }

    public static function userFromToken(?string $token): ?User
    {
        if (!$token) {
            return null;
        }
        $userId = RedisCache::get('token:' . $token);
        return $userId ? User::find((int) $userId) : null;
    }

    public static function normalizeEmail(string $email): string
    {
        $email = strtolower(trim($email));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new BizException('邮箱格式不正确');
        }
        return $email;
    }

    /**
     * 投递登录验证码邮件
     *
     * 未启用邮件服务时只写日志并返回 false（开发环境用 dev_show_code 回显验证码）；
     * 发送失败同样只记日志，不阻塞登录主流程。
     *
     * @param string $email 收件邮箱
     * @param string $code  6 位验证码
     * @return bool 邮件是否实际发出
     */
    private function deliver(string $email, string $code): bool
    {
        $subject = site_config('brand.name', 'Store') . ' verification code';
        $body = "Your verification code is {$code}. It expires in "
            . (int) ceil((int) site_config('auth.code_ttl', self::CODE_TTL) / 60) . " minutes.";

        // 未配置邮件服务时，把验证码写入 runtime 日志，方便本地调试
        \think\facade\Log::info("[site-auth] code for {$email}: {$code}");

        if (!(bool) site_config('mail.enabled', false)) {
            return false;
        }

        return (new Mailer())->send(
            $email,
            $subject,
            $body,
            (string) site_config('brand.name', 'Store')
        );
    }

    private static function nicknameFromEmail(string $email): string
    {
        $local = strstr($email, '@', true) ?: $email;
        return mb_substr($local, 0, 32);
    }
}