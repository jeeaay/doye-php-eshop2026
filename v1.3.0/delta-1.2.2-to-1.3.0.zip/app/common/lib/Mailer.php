<?php
declare(strict_types=1);

namespace app\common\lib;

use think\facade\Log;

/**
 * 轻量 SMTP 邮件发送器
 *
 * 背景：PHP 内置 mail() 在本机与多数云主机上不可用（被服务商禁用或无本地 MTA），
 * 这里基于 socket 直接实现 SMTP 协议，支持 SSL / STARTTLS / 明文三种连接方式，
 * 认证采用 AUTH LOGIN（绝大多数邮箱服务商通用）。
 *
 * 配置来源：site_config('mail.*')，由后台「系统设置 → 邮件服务」维护。
 * 发送失败不抛异常，只写日志并返回 false，避免阻塞主流程（如登录发码）。
 */
class Mailer
{
    /** @var resource|null SMTP 连接句柄 */
    private $socket = null;

    /** @var int 读写超时（秒） */
    private int $timeout = 15;

    /**
     * 发送一封纯文本邮件
     *
     * @param string $to      收件人邮箱
     * @param string $subject 邮件主题
     * @param string $body    邮件正文（默认纯文本，$html=true 时按 HTML 发送）
     * @param string $toName  收件人显示名（可选）
     * @param bool   $html    正文是否为 HTML（营销通知用；既有纯文本调用方不受影响）
     * @return bool 发送成功返回 true；未启用邮件服务或失败返回 false
     */
    public function send(string $to, string $subject, string $body, string $toName = '', bool $html = false): bool
    {
        if (!(bool) site_config('mail.enabled', false)) {
            Log::info('[mailer] mail service disabled, skip sending to ' . $to);
            return false;
        }

        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            Log::error('[mailer] invalid recipient: ' . $to);
            return false;
        }

        try {
            $this->connect();
            $this->authenticate();
            $this->deliver($to, $toName, $subject, $body, $html);
            $this->quit();
            return true;
        } catch (\Throwable $e) {
            Log::error('[mailer] send failed: ' . $e->getMessage());
            $this->close();
            return false;
        }
    }

    /**
     * 建立 SMTP 连接：连接 -> 读取问候 -> EHLO -> 按需 STARTTLS
     *
     * @return void
     * @throws \RuntimeException 连接或加密协商失败时抛出
     */
    private function connect(): void
    {
        $host          = trim((string) site_config('mail.smtp.host', ''));
        $port          = (int) site_config('mail.smtp.port', 0);
        $encryption    = strtolower(trim((string) site_config('mail.smtp.encryption', 'none')));
        $this->timeout = max(5, (int) site_config('mail.smtp.timeout', 15));

        if ($host === '') {
            throw new \RuntimeException('SMTP 服务器地址未配置');
        }
        if ($port <= 0) {
            $port = match ($encryption) {
                'ssl'   => 465,
                'tls'   => 587,
                default => 25,
            };
        }

        $remote = ($encryption === 'ssl' ? 'ssl://' : '') . $host . ':' . $port;
        $errno  = 0;
        $errstr = '';
        $socket = @stream_socket_client($remote, $errno, $errstr, $this->timeout);
        if (!$socket) {
            throw new \RuntimeException("无法连接 SMTP 服务器 {$host}:{$port}（{$errstr}）");
        }

        $this->socket = $socket;
        stream_set_timeout($socket, $this->timeout);

        $this->expect(220);
        $this->command('EHLO ' . $this->localHostname(), 250);

        if ($encryption === 'tls') {
            $this->command('STARTTLS', 220);
            if (@stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT) !== true) {
                throw new \RuntimeException('STARTTLS 加密协商失败');
            }
            // 加密通道建立后按协议要求重新 EHLO
            $this->command('EHLO ' . $this->localHostname(), 250);
        }
    }

    /**
     * AUTH LOGIN 认证；未配置账号时跳过（适用于内网中继）
     *
     * @return void
     * @throws \RuntimeException 认证被拒绝时抛出
     */
    private function authenticate(): void
    {
        $username = (string) site_config('mail.smtp.username', '');
        if ($username === '') {
            return;
        }

        $password = (string) site_config('mail.smtp.password', '');

        $this->command('AUTH LOGIN', 334);
        $this->command(base64_encode($username), 334);
        $this->command(base64_encode($password), 235);
    }

    /**
     * 投递邮件正文：MAIL FROM -> RCPT TO -> DATA
     *
     * @param string $to      收件人邮箱
     * @param string $toName  收件人显示名
     * @param string $subject 主题
     * @param string $body    正文
     * @return void
     * @throws \RuntimeException 任一环节被服务端拒绝时抛出
     */
    private function deliver(string $to, string $toName, string $subject, string $body, bool $html = false): void
    {
        $from     = trim((string) site_config('mail.from', ''));
        $fromName = (string) site_config('mail.from_name', '');
        if ($from === '') {
            throw new \RuntimeException('发件人邮箱未配置');
        }

        $this->command('MAIL FROM:<' . $from . '>', 250);
        $this->command('RCPT TO:<' . $to . '>', [250, 251]);
        $this->command('DATA', 354);

        fwrite($this->socket, $this->buildMessage($from, $fromName, $to, $toName, $subject, $body, $html));
        $this->expect(250);
    }

    /**
     * 组装符合 RFC 5322 的邮件报文（正文 base64 编码，避免以点号开头的行被误判为结束符）
     *
     * @return string 以 CRLF 结尾的完整报文（含结束标记 "."）
     */
    private function buildMessage(
        string $from,
        string $fromName,
        string $to,
        string $toName,
        string $subject,
        string $body,
        bool $html = false
    ): string {
        $headers = [
            'Date: ' . date('r'),
            'From: ' . $this->encodeName($fromName) . ' <' . $from . '>',
            'To: ' . $this->encodeName($toName) . ' <' . $to . '>',
            'Subject: ' . $this->encodeText($subject),
            'MIME-Version: 1.0',
            'Content-Type: ' . ($html ? 'text/html' : 'text/plain') . '; charset=UTF-8',
            'Content-Transfer-Encoding: base64',
        ];

        return implode("\r\n", $headers)
            . "\r\n\r\n"
            . chunk_split(base64_encode($body), 76, "\r\n")
            . "\r\n.\r\n";
    }

    /**
     * 发送一行 SMTP 命令并校验响应码
     *
     * @param string       $command 命令内容（不含 CRLF）
     * @param int|int[]    $expect  期望的响应码
     * @return void
     */
    private function command(string $command, $expect): void
    {
        fwrite($this->socket, $command . "\r\n");
        $this->expect($expect);
    }

    /**
     * 读取 SMTP 响应并校验响应码（兼容多行响应）
     *
     * @param int|int[] $expect 期望的响应码
     * @return void
     * @throws \RuntimeException 响应为空或响应码不符合预期时抛出
     */
    private function expect($expect): void
    {
        $expected = is_array($expect) ? $expect : [$expect];
        $response = '';

        while (($line = fgets($this->socket, 515)) !== false) {
            $response .= $line;
            // 第 4 个字符为 '-' 表示还有后续行
            if (strlen($line) < 4 || $line[3] !== '-') {
                break;
            }
        }

        if ($response === '') {
            throw new \RuntimeException('SMTP 无响应（连接可能已被对方关闭）');
        }

        $code = (int) substr($response, 0, 3);
        if (!in_array($code, $expected, true)) {
            throw new \RuntimeException('SMTP 返回异常：' . trim($response));
        }
    }

    /**
     * 发送 QUIT 并关闭连接
     *
     * @return void
     */
    private function quit(): void
    {
        try {
            $this->command('QUIT', 221);
        } catch (\Throwable $e) {
            // 退出阶段的异常无需上报
        }
        $this->close();
    }

    /**
     * 关闭连接句柄
     *
     * @return void
     */
    private function close(): void
    {
        if (is_resource($this->socket)) {
            @fclose($this->socket);
        }
        $this->socket = null;
    }

    /**
     * EHLO 使用的本机标识（取当前域名，非法时回退 localhost）
     *
     * @return string
     */
    private function localHostname(): string
    {
        $host = (string) ($_SERVER['SERVER_NAME'] ?? '');
        if ($host === '' || !preg_match('/^[a-zA-Z0-9.\-]+$/', $host)) {
            $host = 'localhost';
        }
        return $host;
    }

    /**
     * 按 RFC 2047 编码地址显示名（含非 ASCII 时必须编码）
     *
     * @param string $name 显示名
     * @return string 需要编码时返回 =?UTF-8?B?...?=，否则原文
     */
    private function encodeName(string $name): string
    {
        if ($name === '') {
            return '';
        }
        return $this->encodeText($name);
    }

    /**
     * 按 RFC 2047 编码头部文本
     *
     * @param string $text 原文
     * @return string 纯 ASCII 时返回原文，否则 base64 编码
     */
    private function encodeText(string $text): string
    {
        if (preg_match('/^[\x20-\x7E]*$/', $text) === 1) {
            return $text;
        }
        return '=?UTF-8?B?' . base64_encode($text) . '?=';
    }
}
