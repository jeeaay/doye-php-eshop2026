<?php
declare (strict_types = 1);

namespace app\common\lib\payment;

use app\common\exception\BizException;
use app\common\model\OrderPay;

class WechatPayGateway implements PaymentGatewayInterface
{
    private const BASE_URL = 'https://api.mch.weixin.qq.com';

    public function createPayment(OrderPay $pay, array $config, array $context): array
    {
        $openid = trim((string) ($context['openid'] ?? ''));
        if ($openid === '') {
            throw new BizException('微信支付需要用户 openid，请先完成小程序登录');
        }
        $this->assertConfig($config);

        $response = $this->request($config, 'POST', '/v3/pay/transactions/jsapi', [
            'mchid'       => (string) $config['mch_id'],
            'appid'       => (string) $config['app_id'],
            'description' => mb_substr('订单支付 ' . $pay->id, 0, 127),
            'out_trade_no'=> (string) $pay->id,
            'notify_url'  => (string) $config['notify_url'],
            'amount'      => [
                'total'    => $this->amountMinor($pay),
                'currency' => 'CNY',
            ],
            'payer'       => ['openid' => $openid],
        ]);
        $prepayId = (string) ($response['prepay_id'] ?? '');
        if ($prepayId === '') {
            throw new BizException('微信支付下单失败：未返回 prepay_id');
        }
        $params = $this->buildJsapiParams($config, $prepayId);
        $params['trade_no'] = $prepayId;
        return $params;
    }

    public function verifyNotify(array $headers, string $rawBody, array $config): array
    {
        $this->assertConfig($config);
        $headers = array_change_key_case($headers, CASE_LOWER);
        $timestamp = (string) ($headers['wechatpay-timestamp'] ?? '');
        $nonce = (string) ($headers['wechatpay-nonce'] ?? '');
        $signature = (string) ($headers['wechatpay-signature'] ?? '');
        if ($timestamp === '' || $nonce === '' || $signature === '') {
            throw new BizException('微信支付回调缺少签名头');
        }
        if (abs(time() - (int) $timestamp) > 300) {
            throw new BizException('微信支付回调时间戳超出允许范围');
        }

        $certificate = Pem::certificate((string) $config['platform_cert']);
        $publicKey = openssl_pkey_get_public($certificate);
        if ($publicKey === false) {
            throw new BizException('微信支付平台证书无效');
        }
        $message = $timestamp . "\n" . $nonce . "\n" . $rawBody . "\n";
        $ok = openssl_verify($message, base64_decode($signature, true) ?: '', $publicKey, OPENSSL_ALGO_SHA256);
        if ($ok !== 1) {
            throw new BizException('微信支付回调验签失败');
        }

        $payload = json_decode($rawBody, true);
        if (!is_array($payload)) {
            throw new BizException('微信支付回调数据无效');
        }
        $resource = $payload['resource'] ?? [];
        $plain = $this->decryptResource($resource, (string) $config['api_v3_key']);
        $decoded = json_decode($plain, true);
        if (!is_array($decoded)) {
            throw new BizException('微信支付回调解密失败');
        }
        $tradeState = (string) ($decoded['trade_state'] ?? '');
        if ($tradeState !== 'SUCCESS') {
            throw new BizException('微信支付未成功，状态：' . ($tradeState ?: 'unknown'));
        }
        // The WeChat platform certificate is shared by every merchant, so a
        // valid signature alone does not prove the notification belongs to
        // this merchant. Bind the payload to our own mchid/appid; otherwise a
        // foreign merchant could point their notify_url here and mark our
        // order paid without the money ever reaching this account.
        if ((string) ($decoded['mchid'] ?? '') !== (string) $config['mch_id']
            || (string) ($decoded['appid'] ?? '') !== (string) $config['app_id']) {
            throw new BizException('微信支付回调商户信息不匹配');
        }

        $amount = $decoded['amount'] ?? [];
        return [
            'out_trade_no' => (string) ($decoded['out_trade_no'] ?? ''),
            'trade_no'     => (string) ($decoded['transaction_id'] ?? ''),
            'amount_minor' => isset($amount['total']) ? (int) $amount['total'] : null,
            'currency'     => (string) ($amount['currency'] ?? 'CNY'),
            'paid_at'      => isset($decoded['success_time']) ? (string) $decoded['success_time'] : null,
            'raw'          => $decoded,
        ];
    }

    public function testConnection(array $config): string
    {
        $this->assertConfig($config);
        $key = openssl_pkey_get_private(Pem::privateKey((string) $config['private_key']));
        if ($key === false) {
            throw new BizException('商户私钥无法解析');
        }
        $certificate = Pem::certificate((string) $config['platform_cert']);
        if (openssl_x509_parse($certificate) === false) {
            throw new BizException('平台证书无法解析');
        }
        if (strlen((string) $config['api_v3_key']) !== 32) {
            throw new BizException('APIv3 密钥必须为 32 字节');
        }
        return '微信支付配置格式正确（未发起真实下单）';
    }

    public function refund(OrderPay $pay, array $config, int $refundCents, string $reason, ?string $outRefundNo = null): array
    {
        $this->assertConfig($config);
        $total = $this->amountMinor($pay);
        if ($refundCents <= 0 || $refundCents > $total) {
            throw new BizException('退款金额无效');
        }
        return $this->request($config, 'POST', '/v3/refund/domestic/refunds', [
            'out_trade_no'  => (string) $pay->id,
            // 重试必须复用同一个单号，否则通道侧会当成两笔出款（S7 由 refund_log.refund_no 提供）
            'out_refund_no' => $outRefundNo !== null && $outRefundNo !== '' ? $outRefundNo : 'R' . $pay->id . time(),
            'reason'        => mb_substr($reason, 0, 80),
            'amount'        => [
                'refund'   => $refundCents,
                'total'    => $total,
                'currency' => 'CNY',
            ],
        ]);
    }

    private function assertConfig(array $config): void
    {
        $required = ['app_id', 'mch_id', 'serial_no', 'private_key', 'api_v3_key', 'platform_cert', 'notify_url'];
        $missing = [];
        foreach ($required as $key) {
            if (trim((string) ($config[$key] ?? '')) === '') {
                $missing[] = $key;
            }
        }
        if ($missing) {
            throw new BizException('微信支付配置不完整：' . implode(', ', $missing));
        }
    }

    private function amountMinor(OrderPay $pay): int
    {
        return (int) bcmul((string) $pay->total_amount, '100', 0);
    }

    private function buildJsapiParams(array $config, string $prepayId): array
    {
        $timestamp = (string) time();
        $nonce = bin2hex(random_bytes(16));
        $package = 'prepay_id=' . $prepayId;
        $message = $config['app_id'] . "\n" . $timestamp . "\n" . $nonce . "\n" . $package . "\n";
        $signature = $this->sign($config, $message);
        return [
            'appId'     => (string) $config['app_id'],
            'timeStamp' => $timestamp,
            'nonceStr'  => $nonce,
            'package'   => $package,
            'signType'  => 'RSA',
            'paySign'   => $signature,
        ];
    }

    private function sign(array $config, string $message): string
    {
        $key = openssl_pkey_get_private(Pem::privateKey((string) $config['private_key']));
        if ($key === false) {
            throw new BizException('微信支付商户私钥无效');
        }
        if (!openssl_sign($message, $signature, $key, OPENSSL_ALGO_SHA256)) {
            throw new BizException('微信支付签名失败');
        }
        return base64_encode($signature);
    }

    private function authHeader(array $config, string $method, string $path, string $body): string
    {
        $timestamp = (string) time();
        $nonce = bin2hex(random_bytes(16));
        $message = $method . "\n" . $path . "\n" . $timestamp . "\n" . $nonce . "\n" . $body . "\n";
        return sprintf(
            'WECHATPAY2-SHA256-RSA2048 mchid="%s",nonce_str="%s",timestamp="%s",serial_no="%s",signature="%s"',
            $config['mch_id'],
            $nonce,
            $timestamp,
            $config['serial_no'],
            $this->sign($config, $message)
        );
    }

    private function request(array $config, string $method, string $path, array $body = []): array
    {
        $bodyString = $body ? (string) json_encode($body, JSON_UNESCAPED_UNICODE) : '';
        $url = self::BASE_URL . $path;
        $headers = [
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/json',
            'User-Agent'    => 'b2cshop/1.0',
            'Authorization' => $this->authHeader($config, $method, $path, $bodyString),
        ];
        $response = PaymentHttpClient::request($method, $url, $headers, $bodyString === '' ? null : $bodyString);
        return PaymentHttpClient::assertSuccess($response, '微信支付');
    }

    private function decryptResource(array $resource, string $apiV3Key): string
    {
        $ciphertext = base64_decode((string) ($resource['ciphertext'] ?? ''), true);
        $nonce = (string) ($resource['nonce'] ?? '');
        $aad = (string) ($resource['associated_data'] ?? '');
        if ($ciphertext === false || strlen($ciphertext) <= 16 || $nonce === '' || strlen($apiV3Key) !== 32) {
            throw new BizException('微信支付回调解密参数无效');
        }
        $tag = substr($ciphertext, -16);
        $data = substr($ciphertext, 0, -16);
        $plain = openssl_decrypt($data, 'aes-256-gcm', $apiV3Key, OPENSSL_RAW_DATA, $nonce, $tag, $aad);
        if ($plain === false) {
            throw new BizException('微信支付回调解密失败');
        }
        return $plain;
    }
}