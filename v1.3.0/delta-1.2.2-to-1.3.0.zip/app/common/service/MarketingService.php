<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\enum\AdminRole;
use app\common\enum\PayStatus;
use app\common\exception\BizException;
use app\common\lib\DistributedLock;
use app\common\model\Coupon;
use app\common\model\CouponUser;
use app\common\model\MarketingRule;
use app\common\model\MarketingRuleLog;
use app\common\model\Merchant;
use app\common\model\Order;
use app\common\model\OrderItem;
use app\common\model\OrderPay;
use app\common\model\Product;
use app\common\support\AppContext;
use think\facade\Db;
use think\facade\Log;

/**
 * 营销规则引擎：把「什么条件下、给谁、发什么奖励」变成后台可配的数据
 *
 * 三条不变量，改动前先读：
 * 1. 奖励一律落成一张券（coupon_user），抵扣只认 {@see CouponService::quote()}，不存在返现/余额通道；
 * 2. 发放绝不阻塞主流程 —— 支付通知、确认收货、注册都在本类内 try/catch 收口，
 *    异常写进 marketing_rule_log（status=pending）由 php think marketing:grant 补偿；
 * 3. 幂等靠唯一键 uk_grant(rule_id, user_id, scope_key)，scope_key 取 user:{id} / pay:{id} / order:{id}，
 *    **先占键再发放**，所以重复通知与并发触发的第二次会撞键并跳过。
 *
 * 金额全程为基准币种（国内版 CNY / 国际版 USD）两位小数字符串，只用 bc*，不做币种换算。
 * 平台级功能：只有平台超管能读写，权限收口在本 Service（{@see assertSuper()}），
 * 页面与管理 API 共用同一口径，入口层不再各写一遍角色判断；本类不含商户范围逻辑。
 */
class MarketingService
{
    /** 同一 (规则,用户) 的发放串行锁，保护每人上限的判断窗口 */
    private const LOCK_TTL = 15;

    /** 内联券模板的归属标记前缀：同一规则、同一面额复用同一张模板券 */
    private const TEMPLATE_MARK = 'marketing_rule:';

    // ------------------------------------------------------------------
    // 后台管理（页面与管理 API 共用同一套校验）
    // ------------------------------------------------------------------

    /**
     * 规则列表（分页）
     *
     * 非超管拿到的是空集而不是报错：商家不该从「有没有这条规则」里读出信息，
     * 菜单隐藏只是体验优化，真正的收口在这里。
     *
     * @param array $filters 支持 keyword / type / status
     * @param int   $page    页码
     * @param int   $size    每页数量
     * @return array{list:array,pager:\think\Paginator}
     */
    public function adminList(array $filters, int $page = 1, int $size = 20): array
    {
        $query = MarketingRule::order('priority')->order('id', 'desc');

        if (!$this->isSuper()) {
            $query->whereRaw('1 = 0');
        }

        $keyword = trim((string) ($filters['keyword'] ?? ''));
        if ($keyword !== '') {
            $query->whereLike('name', '%' . $keyword . '%');
        }

        $type = (string) ($filters['type'] ?? '');
        if (isset(MarketingRule::TYPE_LABELS[$type])) {
            $query->where('type', $type);
        }

        $status = $filters['status'] ?? '';
        if ($status !== '' && $status !== null) {
            $query->where('status', (int) $status);
        }

        $pager = $query->paginate([
            'list_rows' => $size,
            'page'      => $page,
            'query'     => ['keyword' => $keyword, 'type' => $type, 'status' => $status],
        ]);

        $rules = $pager->items();
        $ids = [];
        $couponIds = [];
        foreach ($rules as $rule) {
            $ids[] = (int) $rule->id;
            $couponIds[] = (int) $rule->coupon_id;
        }
        $granted = $this->grantedCounts($ids);
        $couponNames = $this->couponNames($couponIds);

        $list = [];
        foreach ($rules as $rule) {
            $list[] = $this->formatRule($rule, $granted[(int) $rule->id] ?? 0, $couponNames[(int) $rule->coupon_id] ?? '');
        }

        return ['list' => $list, 'pager' => $pager];
    }

    /**
     * 规则详情
     *
     * @param int $id 规则 ID
     * @return array
     * @throws BizException 非超管或不存在
     */
    public function adminDetail(int $id): array
    {
        $this->assertSuper();

        $rule = MarketingRule::find($id);
        if (!$rule) {
            throw new BizException('营销规则不存在');
        }
        $granted = $this->grantedCounts([(int) $rule->id]);

        return $this->formatRule(
            $rule,
            $granted[(int) $rule->id] ?? 0,
            $this->couponNames([(int) $rule->coupon_id])[(int) $rule->coupon_id] ?? ''
        );
    }

    /**
     * 保存规则（新增或更新）
     *
     * @param array    $data 表单数据
     * @param int|null $id   为空表示新增
     * @return int 规则 ID
     * @throws BizException 非超管或校验失败
     */
    public function adminSave(array $data, ?int $id = null): int
    {
        $this->assertSuper();

        $name = trim((string) ($data['name'] ?? ''));
        if ($name === '') {
            throw new BizException('请填写规则名称');
        }

        $type = (string) ($data['type'] ?? MarketingRule::TYPE_ORDER_GIFT);
        if (!isset(MarketingRule::TYPE_LABELS[$type])) {
            throw new BizException('规则类型不合法');
        }
        $trigger = (string) ($data['trigger_event'] ?? '');
        if (!in_array($trigger, MarketingRule::TYPE_TRIGGERS[$type], true)) {
            throw new BizException('「' . MarketingRule::TYPE_LABELS[$type] . '」不支持该触发事件');
        }

        $rewardMode = (string) ($data['reward_mode'] ?? MarketingRule::REWARD_FIXED);
        if (!isset(MarketingRule::REWARD_LABELS[$rewardMode])) {
            throw new BizException('奖励方式不合法');
        }
        $rewardValue = $this->decimal($data['reward_value'] ?? 0);
        if (bccomp($rewardValue, '0', 2) <= 0) {
            throw new BizException('奖励值必须大于 0');
        }
        if ($rewardMode === MarketingRule::REWARD_PERCENT) {
            if (bccomp($rewardValue, '100', 2) > 0) {
                throw new BizException('按比例奖励不能超过 100%');
            }
            $rewardCap = $this->decimal($data['reward_cap'] ?? 0);
        } else {
            $rewardCap = '0.00';
        }
        if (bccomp($rewardCap, '0', 2) < 0) {
            throw new BizException('封顶金额不能为负数');
        }

        // 奖励券：给了 coupon_id 就用这张券模板，否则按内联定义在发放时懒生成
        $couponId = isset($data['coupon_id']) && (int) $data['coupon_id'] > 0 ? (int) $data['coupon_id'] : null;
        $inline = null;
        if ($couponId !== null) {
            $coupon = Coupon::find($couponId);
            if (!$coupon) {
                throw new BizException('奖励券模板不存在');
            }
            if (!in_array((int) $coupon->tier, [Coupon::TIER_AUTO_GRANT, Coupon::TIER_MANUAL], true)) {
                throw new BizException('奖励券模板只能是「自动到账券」或「优惠券」，活动类优惠请直接配活动');
            }
        } else {
            $inline = $this->normalizeInline($data['inline_coupon'] ?? [], $name);
        }

        $conditions = $this->normalizeConditions($data['condition_json'] ?? [], $type);

        $startTime = $this->normalizeTime($data['start_time'] ?? '');
        $endTime = $this->normalizeTime($data['end_time'] ?? '');
        if ($startTime && $endTime && strtotime($startTime) > strtotime($endTime)) {
            throw new BizException('开始时间不能晚于结束时间');
        }

        $totalLimit = max(0, (int) ($data['total_limit'] ?? 0));
        $perUserLimit = max(0, (int) ($data['per_user_limit'] ?? 1));
        $priority = (int) ($data['priority'] ?? 0);
        $status = (int) ($data['status'] ?? 1) ? 1 : 0;
        $remark = trim((string) ($data['remark'] ?? ''));

        Db::startTrans();
        try {
            $rule = $id ? MarketingRule::find($id) : new MarketingRule();
            if (!$rule) {
                throw new BizException('营销规则不存在');
            }

            $rule->name           = $name;
            $rule->type           = $type;
            $rule->trigger_event  = $trigger;
            $rule->reward_mode    = $rewardMode;
            $rule->reward_value   = $rewardValue;
            $rule->reward_cap     = $rewardCap;
            $rule->coupon_id      = $couponId;
            $rule->inline_coupon_json = $couponId === null ? $inline : null;
            $rule->condition_json = $conditions;
            $rule->total_limit    = $totalLimit;
            $rule->per_user_limit = $perUserLimit;
            $rule->start_time     = $startTime;
            $rule->end_time       = $endTime;
            $rule->status         = $status;
            $rule->priority       = $priority;
            $rule->remark         = $remark !== '' ? $remark : null;
            $rule->save();

            Db::commit();
            return (int) $rule->id;
        } catch (\Throwable $e) {
            Db::rollback();
            throw $e;
        }
    }

    /**
     * 启用 / 停用规则
     *
     * 停用只关掉「还发不发新券」，已发到账户的券按自身有效期继续可用（父任务双层有效期口径）。
     *
     * @param int $id     规则 ID
     * @param int $status 1 启用 / 0 停用
     * @return void
     * @throws BizException 非超管或不存在
     */
    public function adminToggle(int $id, int $status): void
    {
        $this->assertSuper();

        $rule = MarketingRule::find($id);
        if (!$rule) {
            throw new BizException('营销规则不存在');
        }
        $rule->status = $status ? 1 : 0;
        $rule->save();
    }

    /**
     * 删除规则（已发放记录保留，只断掉 rule_id 的反查）
     *
     * @param int $id 规则 ID
     * @return void
     * @throws BizException 非超管或不存在
     */
    public function adminDelete(int $id): void
    {
        $this->assertSuper();

        $rule = MarketingRule::find($id);
        if (!$rule) {
            throw new BizException('营销规则不存在');
        }
        $rule->delete();
    }

    /**
     * 发放记录（后台可查：发了多少张、给了谁、关联哪笔订单、为什么没发）
     *
     * @param array $filters rule_id(0=全部) / user_id / order_id / status
     * @param int   $page    页码
     * @param int   $size    每页数量
     * @return array{list:array,pager:\think\Paginator}
     * @throws BizException 非超管
     */
    public function adminLogs(array $filters, int $page = 1, int $size = 20): array
    {
        $this->assertSuper();

        $query = MarketingRuleLog::order('id', 'desc');

        $ruleId = (int) ($filters['rule_id'] ?? 0);
        if ($ruleId > 0) {
            $query->where('rule_id', $ruleId);
        }

        $status = (string) ($filters['status'] ?? '');
        if (in_array($status, [
            MarketingRuleLog::STATUS_PENDING,
            MarketingRuleLog::STATUS_GRANTED,
            MarketingRuleLog::STATUS_SKIPPED,
            MarketingRuleLog::STATUS_REVOKED,
        ], true)) {
            $query->where('status', $status);
        }

        $userId = (int) ($filters['user_id'] ?? 0);
        if ($userId > 0) {
            $query->where('user_id', $userId);
        }

        $orderId = (int) ($filters['order_id'] ?? 0);
        if ($orderId > 0) {
            $query->where('order_id', $orderId);
        }

        $pager = $query->paginate(['list_rows' => $size, 'page' => $page]);

        $logs = $pager->items();
        $ruleIds = [];
        foreach ($logs as $log) {
            $ruleIds[] = (int) $log->rule_id;
        }
        $names = $ruleIds
            ? MarketingRule::whereIn('id', array_unique($ruleIds))->column('name', 'id')
            : [];

        $list = [];
        foreach ($logs as $log) {
            $row = $this->formatLog($log);
            $row['rule_name'] = (string) ($names[$row['rule_id']] ?? '');
            $list[] = $row;
        }

        return ['list' => $list, 'pager' => $pager];
    }

    /**
     * 规则类型选项（表单联动数据源）
     *
     * 类型决定触发事件（MarketingRule::TYPE_TRIGGERS 是后端校验口径），
     * 前端把 trigger_event 做成只读展示，运营就配不出「注册礼挂在支付事件」这类组合。
     *
     * @return array<int,array<string,string>>
     */
    public function typeOptions(): array
    {
        $hints = [
            MarketingRule::TYPE_REGISTER_GIFT  => '用户注册成功即发券，用来拉第一单转化。',
            MarketingRule::TYPE_ORDER_GIFT     => '首笔支付成功后发券，默认只发给此前没有成交记录的新人。',
            MarketingRule::TYPE_CONFIRM_REBATE => '确认收货（手动与自动同一条路径）后，按该单实付金额发放。',
        ];

        $out = [];
        foreach (MarketingRule::TYPE_LABELS as $type => $label) {
            $trigger = MarketingRule::TYPE_TRIGGERS[$type][0];
            $out[] = [
                'type'          => (string) $type,
                'label'         => (string) $label,
                'trigger_event' => $trigger,
                'trigger_label' => MarketingRule::TRIGGER_LABELS[$trigger] ?? '',
                'hint'          => $hints[$type] ?? '',
            ];
        }

        return $out;
    }

    /**
     * 可引用的奖励券模板（tier 30 自动到账券 / tier 40 手动优惠券）
     *
     * 「需要用户手动勾选」的券只能在优惠管理里建好再引用；内联方式一律落 tier 30
     * （理由见 {@see normalizeInline()}）。
     * $currentId 对应的券即便已停用也要出现在结果里：下拉缺 option 会回落成第一项，
     * 保存后规则的奖励载体就被悄悄换掉了。
     *
     * @param int|null $currentId 当前规则已引用的券 ID
     * @return array<int,array<string,mixed>>
     */
    public function couponOptions(?int $currentId = null): array
    {
        $query = Coupon::whereIn('tier', [Coupon::TIER_AUTO_GRANT, Coupon::TIER_MANUAL])
            ->where('status', 1);
        if ($currentId !== null && $currentId > 0) {
            $query = Coupon::whereIn('tier', [Coupon::TIER_AUTO_GRANT, Coupon::TIER_MANUAL])
                ->where(function ($q) use ($currentId) {
                    $q->where('status', 1)->whereOr('id', $currentId);
                });
        }

        $coupons = $query->order('sort')->order('id', 'desc')->select();

        $merchantIds = [];
        foreach ($coupons as $coupon) {
            if ($coupon->merchant_id !== null) {
                $merchantIds[] = (int) $coupon->merchant_id;
            }
        }
        $merchantNames = $merchantIds
            ? Merchant::whereIn('id', array_unique($merchantIds))->column('name', 'id')
            : [];

        $out = [];
        foreach ($coupons as $coupon) {
            $label = $coupon->name . ' · ' . CouponService::discountText($coupon);
            if ($coupon->code) {
                $label .= ' · 码 ' . $coupon->code;
            }
            if ($coupon->merchant_id !== null) {
                $label .= ' · 限「' . ($merchantNames[(int) $coupon->merchant_id] ?? '商户 #' . $coupon->merchant_id) . '」';
            }
            if ((int) $coupon->status !== 1) {
                $label .= '（已停用）';
            }

            $out[] = [
                'id'        => (int) $coupon->id,
                'name'      => (string) $coupon->name,
                'tier'      => (int) $coupon->tier,
                'status'    => (int) $coupon->status,
                'label'     => $label,
            ];
        }

        return $out;
    }

    /**
     * 某笔订单已到账的返利（前台「本单返利已到账」提示）
     *
     * 只返回当前用户自己的订单；没有命中规则或尚未发放时返回空数组，前台据此不渲染该模块。
     * 金额是发放时的快照（marketing_rule_log.reward_amount），不按当前规则重算。
     *
     * @param int $orderId 订单 ID
     * @param int $userId  当前用户
     * @return array<int,array{order_id:int,rule_id:int,rule_name:string,reward_amount:string,coupon_user_id:int|null,expire_time:string}>
     */
    public function benefitsByOrder(int $orderId, int $userId): array
    {
        if ($orderId <= 0 || $userId <= 0) {
            return [];
        }

        $order = $this->orderQuery()->where('id', $orderId)->where('user_id', $userId)->find();
        if (!$order) {
            return [];
        }

        // 支付事件发放的记录（首单礼等）只带 order_pay_id，不落 order_id，必须按支付单一并查
        $payId = (int) $order->pay_id;
        $logs  = MarketingRuleLog::where('user_id', $userId)
            ->where('status', MarketingRuleLog::STATUS_GRANTED)
            ->where(function ($q) use ($orderId, $payId) {
                $q->where('order_id', $orderId);
                if ($payId > 0) {
                    $q->whereOr('order_pay_id', $payId);
                }
            })
            ->order('id')
            ->select();
        if (count($logs) === 0) {
            return [];
        }

        $ruleIds = [];
        $couponUserIds = [];
        foreach ($logs as $log) {
            $ruleIds[] = (int) $log->rule_id;
            if ((int) $log->coupon_user_id > 0) {
                $couponUserIds[] = (int) $log->coupon_user_id;
            }
        }
        $ruleNames = $ruleIds ? MarketingRule::whereIn('id', array_unique($ruleIds))->column('name', 'id') : [];
        $expires   = $couponUserIds ? CouponUser::whereIn('id', array_unique($couponUserIds))->column('expire_time', 'id') : [];

        $out = [];
        foreach ($logs as $log) {
            $out[] = [
                'order_id'       => (int) $log->order_id,
                'rule_id'        => (int) $log->rule_id,
                'rule_name'      => (string) ($ruleNames[(int) $log->rule_id] ?? ''),
                'reward_amount'  => (string) $log->reward_amount,
                'coupon_user_id' => $log->coupon_user_id !== null ? (int) $log->coupon_user_id : null,
                'expire_time'    => (string) ($expires[(int) $log->coupon_user_id] ?? ''),
            ];
        }
        return $out;
    }

    // ------------------------------------------------------------------
    // 触发入口（三个事件 + 补偿重放，全部不抛异常）
    // ------------------------------------------------------------------

    /**
     * 注册成功后发放（邮箱验证码建号与小程序首登建号都调这里）
     *
     * @param int $userId 新用户 ID
     * @return array 每条命中规则的处理结果
     */
    public function grantOnRegister(int $userId): array
    {
        if ($userId <= 0) {
            return [];
        }

        return $this->grantEvent(MarketingRule::TRIGGER_REGISTER, $this->registerContext($userId));
    }

    /**
     * 支付成功后发放（挂在 PaymentService::markPaid 事务之外）
     *
     * @param int $orderPayId 支付单 ID
     * @return array
     */
    public function grantOnPaid(int $orderPayId): array
    {
        $pay = OrderPay::find($orderPayId);
        if (!$pay || !$this->isGrantablePay($pay)) {
            return [];
        }

        return $this->grantEvent(MarketingRule::TRIGGER_PAY, $this->payContext($pay));
    }

    /**
     * 确认收货后发放返利（手动确认与自动确认同一条路径）
     *
     * @param int $orderId 订单 ID
     * @return array
     */
    public function grantOnOrderCompleted(int $orderId): array
    {
        $order = $this->findOrder($orderId);
        if (!$order) {
            return [];
        }

        return $this->grantEvent(MarketingRule::TRIGGER_CONFIRM, $this->orderContext($order));
    }

    /**
     * 全额退款后回收该单挣到的奖励券
     *
     * 三种行分别处理：已发放且券未用 → 作废券并回退计数；已发放但券已抵扣出去 → 只标 revoked，
     * 不追回（那部分价值已经反映在这笔实付里，追回等于向用户要钱）；仍在 pending → 直接结案，
     * 不让补偿命令在退款之后把券发出来。回收本身失败不能拖住退款，异常一律吞掉。
     *
     * @param int $orderPayId 支付单 ID
     * @return array
     */
    public function revokeByOrderPay(int $orderPayId): array
    {
        $out = [];
        try {
            $logs = MarketingRuleLog::where('order_pay_id', $orderPayId)
                ->whereIn('status', [MarketingRuleLog::STATUS_GRANTED, MarketingRuleLog::STATUS_PENDING])
                ->select();

            $couponService = new CouponService();
            foreach ($logs as $log) {
                if ((string) $log->status === MarketingRuleLog::STATUS_PENDING) {
                    // 卡在 pending 的行会被 marketing:grant 重放，退款后必须就地结案，
                    // 否则补偿命令会把一张已退款订单的奖励券发出去
                    $log->status = MarketingRuleLog::STATUS_SKIPPED;
                    $log->skip_reason = MarketingRuleLog::SKIP_ORDER_REFUNDED;
                    $log->save();
                    $out[] = ['log_id' => (int) $log->id, 'reclaimed' => false];
                    continue;
                }

                $reclaimed = (int) $log->coupon_user_id > 0 && $couponService->revokeCoupon((int) $log->coupon_user_id);
                $log->status = MarketingRuleLog::STATUS_REVOKED;
                $log->skip_reason = $reclaimed ? null : MarketingRuleLog::SKIP_COUPON_ALREADY_USED;
                $log->save();

                if ($reclaimed) {
                    // 发放计数回退，预算要还给后面的单；已经抵扣掉的券不回退计数
                    MarketingRule::where('id', (int) $log->rule_id)
                        ->where('issued_qty', '>', 0)->dec('issued_qty')->update();
                }
                $out[] = ['log_id' => (int) $log->id, 'reclaimed' => $reclaimed];
            }
        } catch (\Throwable $e) {
            Log::error('marketing revoke failed: pay=' . $orderPayId . ' err=' . $e->getMessage());
        }

        return $out;
    }

    /**
     * 补偿重放：把 status=pending 的发放记录再跑一遍
     *
     * pending 有两种来源：发放本身抛异常（skip_reason=error），以及进程在占键之后、回写之前挂掉
     * （skip_reason 为空）。两种都要重放，否则用户挣到的奖励会永久卡在中间态。
     * 重放不再检查活动窗与规则启停（资格在事件发生那一刻已经确定，事后停用不该吞掉已挣到的奖励），
     * 但预算与每人上限仍然生效；判定不过的行会被标成 skipped，不会永久滞留在 pending。
     *
     * @param int $limit 单次最多处理条数
     * @return array{processed:int,granted:int,skipped:int,failed:int}
     */
    public function replayPending(int $limit = 100): array
    {
        $stats = ['processed' => 0, 'granted' => 0, 'skipped' => 0, 'failed' => 0];
        $logs = MarketingRuleLog::where('status', MarketingRuleLog::STATUS_PENDING)
            ->order('id')->limit(max(1, $limit))->select();

        foreach ($logs as $log) {
            $rule = MarketingRule::find((int) $log->rule_id);
            if (!$rule) {
                $log->status = MarketingRuleLog::STATUS_SKIPPED;
                $log->skip_reason = MarketingRuleLog::SKIP_NOT_ELIGIBLE;
                $log->error_msg = '规则已删除';
                $log->save();
                $stats['processed']++;
                $stats['skipped']++;
                continue;
            }

            $ctx = $this->contextFromLog($log);
            if ($ctx === null) {
                // 事件对象已经不可发放（订单被删/支付单回退）：结案，否则这行会一直卡在 pending
                $log->status = MarketingRuleLog::STATUS_SKIPPED;
                $log->skip_reason = MarketingRuleLog::SKIP_NOT_ELIGIBLE;
                $log->error_msg = '事件对象已不存在或状态已回退';
                $log->save();
                $stats['processed']++;
                $stats['skipped']++;
                continue;
            }

            $result = $this->grantForRule($rule, $ctx);
            $stats['processed']++;
            if ($result['status'] === MarketingRuleLog::STATUS_GRANTED) {
                $stats['granted']++;
            } elseif ($result['status'] === MarketingRuleLog::STATUS_SKIPPED) {
                $stats['skipped']++;
            } else {
                $stats['failed']++;
            }
        }

        return $stats;
    }

    /**
     * 待补偿记录（供命令行输出与监控）
     *
     * @param int $limit 条数
     * @return array
     */
    public function pendingLogs(int $limit = 100): array
    {
        $out = [];
        foreach (MarketingRuleLog::where('status', MarketingRuleLog::STATUS_PENDING)
            ->order('id')->limit(max(1, $limit))->select() as $log) {
            $out[] = $this->formatLog($log);
        }
        return $out;
    }

    // ------------------------------------------------------------------
    // 发放内核
    // ------------------------------------------------------------------

    /**
     * 取出某事件当前生效的规则并逐条发放
     *
     * @param string $event 触发事件
     * @param array  $ctx   事件上下文
     * @return array
     */
    private function grantEvent(string $event, array $ctx): array
    {
        $results = [];
        foreach ($this->activeRules($event) as $rule) {
            $results[] = $this->grantForRule($rule, $ctx);
        }
        return $results;
    }

    /**
     * 启用中、事件匹配、且落在活动窗内的规则
     *
     * @param string $event 触发事件
     * @return array<int,MarketingRule>
     */
    private function activeRules(string $event): array
    {
        $now = date('Y-m-d H:i:s');
        return MarketingRule::where('status', 1)
            ->where('trigger_event', $event)
            ->where(function ($q) use ($now) {
                $q->whereNull('start_time')->whereOr('start_time', '<=', $now);
            })
            ->where(function ($q) use ($now) {
                $q->whereNull('end_time')->whereOr('end_time', '>=', $now);
            })
            ->order('priority')->order('id')
            ->select()
            ->all();
    }

    /**
     * 单条规则的发放：占幂等键 → 判资格 → 扣预算 → 发券 → 回写快照
     *
     * 整个过程不向外抛异常（R9：支付通知不能被发券失败拖垮），失败都体现在返回值与日志行里。
     * 活动窗与规则启停只在 {@see activeRules()} 那一层判定，补偿重放不走这里的活动窗过滤。
     *
     * @param MarketingRule $rule 规则
     * @param array         $ctx  事件上下文
     * @return array{rule_id:int,status:string,reason:string,amount:string,coupon_user_id:int|null}
     */
    private function grantForRule(MarketingRule $rule, array $ctx): array
    {
        $result = [
            'rule_id'        => (int) $rule->id,
            'status'         => MarketingRuleLog::STATUS_SKIPPED,
            'reason'         => '',
            'amount'         => '0.00',
            'coupon_user_id' => null,
        ];
        $userId = (int) $ctx['user_id'];
        if ($userId <= 0) {
            $result['reason'] = 'no_user';
            return $result;
        }

        $lockKey = 'marketing:' . (int) $rule->id . ':' . $userId;
        $token = DistributedLock::lock($lockKey, self::LOCK_TTL);
        if ($token === null) {
            // 同一 (规则,用户) 正在发放：让先拿到锁的那次完成，这次直接跳过
            $result['reason'] = MarketingRuleLog::SKIP_ALREADY_GRANTED;
            return $result;
        }

        try {
            $log = $this->claimLog($rule, $ctx);
            if ($log === null) {
                $result['reason'] = MarketingRuleLog::SKIP_ALREADY_GRANTED;
                return $result;
            }

            $eligibility = $this->eligibility($rule, $ctx);
            if ($eligibility['ok'] !== true) {
                $this->markSkipped($log, $eligibility['reason']);
                $result['reason'] = $eligibility['reason'];
                return $result;
            }

            $amount = $this->rewardAmount($rule, $ctx);
            if (bccomp($amount, '0', 2) <= 0) {
                $this->markSkipped($log, MarketingRuleLog::SKIP_NOT_ELIGIBLE);
                $result['reason'] = 'zero_reward';
                return $result;
            }

            $budgetTaken = $this->takeBudget($rule);
            if (!$budgetTaken) {
                $this->markSkipped($log, MarketingRuleLog::SKIP_BUDGET_EXHAUSTED);
                $result['reason'] = MarketingRuleLog::SKIP_BUDGET_EXHAUSTED;
                return $result;
            }

            try {
                $template = $this->resolveTemplate($rule, $amount);
                $record = (new CouponService())->issue(
                    $template,
                    $userId,
                    '该用户已达奖励券发放上限'
                );
            } catch (\Throwable $e) {
                // 预算先扣后退，避免并发窗口里把额度吃在一张没发出去的券上
                MarketingRule::where('id', (int) $rule->id)->where('issued_qty', '>', 0)->dec('issued_qty')->update();
                $log->status = MarketingRuleLog::STATUS_PENDING;
                $log->skip_reason = MarketingRuleLog::SKIP_ERROR;
                $log->error_msg = mb_substr($e->getMessage(), 0, 200);
                $log->save();
                Log::error('marketing grant failed: rule=' . (int) $rule->id . ' user=' . $userId . ' err=' . $e->getMessage());
                $result['status'] = MarketingRuleLog::STATUS_PENDING;
                $result['reason'] = MarketingRuleLog::SKIP_ERROR;
                return $result;
            }

            $log->status = MarketingRuleLog::STATUS_GRANTED;
            $log->reward_amount = $amount;
            $log->coupon_id = (int) $template->id;
            $log->coupon_user_id = (int) $record->id;
            $log->skip_reason = null;
            $log->error_msg = null;
            $log->save();

            $result['status'] = MarketingRuleLog::STATUS_GRANTED;
            $result['amount'] = $amount;
            $result['coupon_user_id'] = (int) $record->id;
            return $result;
        } catch (\Throwable $e) {
            Log::error('marketing grant crashed: rule=' . (int) $rule->id . ' user=' . $userId . ' err=' . $e->getMessage());
            $result['status'] = MarketingRuleLog::STATUS_PENDING;
            $result['reason'] = MarketingRuleLog::SKIP_ERROR;
            return $result;
        } finally {
            DistributedLock::unlock($lockKey, $token);
        }
    }

    /**
     * 占住幂等键：插入 pending 记录，或复用上一次失败留下的 pending 记录
     *
     * @param MarketingRule $rule 规则
     * @param array         $ctx  上下文
     * @return MarketingRuleLog|null null 表示这个事件已经处理过（或正被并发处理）
     */
    private function claimLog(MarketingRule $rule, array $ctx): ?MarketingRuleLog
    {
        $existing = MarketingRuleLog::where('rule_id', (int) $rule->id)
            ->where('user_id', (int) $ctx['user_id'])
            ->where('scope_key', (string) $ctx['scope_key'])
            ->find();
        if ($existing) {
            // granted/skipped/revoked 都是终态：重复通知、并发触发、以及补偿重放都到此为止
            return (string) $existing->status === MarketingRuleLog::STATUS_PENDING ? $existing : null;
        }

        try {
            $log = new MarketingRuleLog();
            $log->rule_id = (int) $rule->id;
            $log->user_id = (int) $ctx['user_id'];
            $log->order_id = $ctx['order_id'] ?? null;
            $log->order_pay_id = $ctx['order_pay_id'] ?? null;
            $log->trigger_event = (string) $rule->trigger_event;
            $log->scope_key = (string) $ctx['scope_key'];
            $log->status = MarketingRuleLog::STATUS_PENDING;
            $log->save();
            return $log;
        } catch (\Throwable $e) {
            if ($this->isDuplicateKey($e)) {
                return null;
            }
            throw $e;
        }
    }

    /**
     * 条件判定：新老用户、金额门槛、指定范围、每人上限
     *
     * @param MarketingRule $rule 规则
     * @param array         $ctx  上下文
     * @return array{ok:bool,reason:string}
     */
    private function eligibility(MarketingRule $rule, array $ctx): array
    {
        $conditions = $rule->conditions();

        if (!empty($conditions['new_user_only'])
            && !$this->isNewUser((int) $ctx['user_id'], (int) ($ctx['exclude_pay_id'] ?? $ctx['order_pay_id'] ?? 0))) {
            return ['ok' => false, 'reason' => MarketingRuleLog::SKIP_NOT_ELIGIBLE];
        }

        $minAmount = $this->decimal($conditions['min_order_amount'] ?? 0);
        if (bccomp($minAmount, '0', 2) > 0 && bccomp($ctx['base_amount'], $minAmount, 2) < 0) {
            return ['ok' => false, 'reason' => MarketingRuleLog::SKIP_NOT_ELIGIBLE];
        }

        foreach (['merchant_ids', 'product_ids', 'category_ids'] as $key) {
            $wanted = array_map('intval', (array) ($conditions[$key] ?? []));
            if (empty($wanted)) {
                continue;
            }
            $actual = array_map('intval', (array) ($ctx[$key] ?? []));
            if (empty(array_intersect($wanted, $actual))) {
                return ['ok' => false, 'reason' => MarketingRuleLog::SKIP_NOT_ELIGIBLE];
            }
        }

        $perUserLimit = (int) $rule->per_user_limit;
        if ($perUserLimit > 0) {
            // 本次 pending 记录已计入，所以判定用的是「严格大于」
            $held = (int) MarketingRuleLog::where('rule_id', (int) $rule->id)
                ->where('user_id', (int) $ctx['user_id'])
                ->whereIn('status', [MarketingRuleLog::STATUS_GRANTED, MarketingRuleLog::STATUS_PENDING])
                ->count();
            if ($held > $perUserLimit) {
                return ['ok' => false, 'reason' => MarketingRuleLog::SKIP_USER_LIMIT];
            }
        }

        return ['ok' => true, 'reason' => ''];
    }

    /**
     * 奖励金额：固定额直接取，比例额按事件实付算并封顶
     *
     * 基数是「实付」而不是商品小计 —— 优惠已经扣完之后再返利，天然防住折上折超额返利。
     *
     * @param MarketingRule $rule 规则
     * @param array         $ctx  上下文
     * @return string 两位小数字符串
     */
    private function rewardAmount(MarketingRule $rule, array $ctx): string
    {
        if ((string) $rule->reward_mode === MarketingRule::REWARD_PERCENT) {
            $ratio = bcdiv((string) $rule->reward_value, '100', 6);
            $amount = bcmul($ctx['base_amount'], $ratio, 2);
        } else {
            $amount = $this->decimal($rule->reward_value);
        }

        $cap = $this->decimal($rule->reward_cap ?? 0);
        if (bccomp($cap, '0', 2) > 0 && bccomp($amount, $cap, 2) > 0) {
            $amount = $cap;
        }

        return bccomp($amount, '0', 2) > 0 ? $amount : '0.00';
    }

    /**
     * 原子占用规则预算：total_limit=0 表示不限
     *
     * 条件更新一次搞定「查余额 + 扣减」，并发下不会超发；不再比对 status，
     * 否则规则中途停用会让补偿重放把已挣到的名额误判成预算耗尽。
     *
     * @param MarketingRule $rule 规则
     * @return bool 是否占到一个发放名额
     */
    private function takeBudget(MarketingRule $rule): bool
    {
        $affected = Db::name('marketing_rule')
            ->where('id', (int) $rule->id)
            ->whereRaw('(total_limit = 0 OR issued_qty < total_limit)')
            ->inc('issued_qty')
            ->update();
        return (int) $affected === 1;
    }

    /**
     * 奖励券模板：引用现成的，或按内联定义懒建一张
     *
     * 比例型奖励的面额逐单不同，没法预先建模板，所以内联生成的券按「规则 + 面额」复用：
     * 同一笔面额第二次发放不会再开一张券，coupon 表不会随订单数无限膨胀。
     *
     * 内联模板一律落 tier=30（自动到账层）：这一层的券在领券中心（claimableList 过滤 tier<>30）
     * 和领取接口（claim 拒绝 tier=30）都是关闭的，系统生成的模板不会被人自助领走。
     * 想做「用户手动选用」的奖励券，请在优惠管理建一张正常优惠券再用 coupon_id 引用。
     *
     * @param MarketingRule $rule   规则
     * @param string        $amount 本次奖励金额
     * @return Coupon
     * @throws BizException 模板不可用
     */
    private function resolveTemplate(MarketingRule $rule, string $amount): Coupon
    {
        if ((int) $rule->coupon_id > 0) {
            $coupon = Coupon::find((int) $rule->coupon_id);
            if (!$coupon) {
                throw new BizException('奖励券模板不存在');
            }
            if ((int) $coupon->status !== 1) {
                throw new BizException('奖励券模板已停用');
            }
            return $coupon;
        }

        $inline = $rule->inlineCoupon();
        $mark = self::TEMPLATE_MARK . (int) $rule->id . ':' . $amount;
        $existing = Coupon::where('remark', $mark)->find();
        if ($existing) {
            return $existing;
        }

        $coupon = new Coupon();
        $coupon->name           = (string) ($inline['name'] ?? $rule->name);
        $coupon->code           = null;
        // claim 只是「凭发放到账」的标记：这些券不进可领列表，由规则发给用户
        $coupon->apply_type     = Coupon::APPLY_CLAIM;
        $coupon->tier           = Coupon::TIER_AUTO_GRANT;
        $coupon->auto_apply     = 1;
        $coupon->discount_type  = Coupon::TYPE_FIXED;
        $coupon->discount_value = $amount;
        $coupon->min_amount     = $this->decimal($inline['min_amount'] ?? 0);
        $coupon->max_discount   = '0.00';
        $coupon->scope          = Coupon::SCOPE_ALL;
        $coupon->total_qty      = 0;
        $coupon->claimed_qty    = 0;
        $coupon->used_qty       = 0;
        // 上限由规则自己的 total_limit / per_user_limit 管，券模板不设限，避免两处口径打架
        $coupon->per_user_limit = 0;
        $coupon->valid_days     = max(0, (int) ($inline['valid_days'] ?? 30));
        $coupon->expire_at      = $this->normalizeTime($inline['expire_at'] ?? '');
        $coupon->start_time     = null;
        $coupon->end_time       = null;
        $coupon->status         = 1;
        $coupon->sort           = 0;
        $coupon->remark         = $mark;
        $coupon->save();

        return $coupon;
    }

    /**
     * 除本单之外没有更早的已支付订单 = 新用户（「未下单都是新人」口径）
     *
     * 两条口径都试过才能确定：
     * - 必须排除当前支付单，否则触发时它自己已入库，永远没人算新人；
     * - 只把「更早的」已支付订单算作老用户证据。用户同时下两单再一起付款时，
     *   两笔支付单在发放前都已经是 PAID；若不排除时间关系，两笔会互相把对方判成老用户，
     *   首单礼一张都发不出去。按 ID 取早的那笔，结果就是恰好发一张。
     *
     * @param int $userId        用户 ID
     * @param int $notAfterPayId 当前支付单 ID：只统计比它更早的已支付订单
     * @return bool
     */
    private function isNewUser(int $userId, int $notAfterPayId = 0): bool
    {
        $query = OrderPay::where('user_id', $userId)->where('pay_status', PayStatus::PAID);
        if ($notAfterPayId > 0) {
            $query->where('id', '<', $notAfterPayId);
        }
        return (int) $query->count() === 0;
    }

    /**
     * 从发放记录还原上下文，供补偿重放使用
     *
     * @param MarketingRuleLog $log 发放记录
     * @return array|null 事件对象已不存在或已不可发放时返回 null
     */
    private function contextFromLog(MarketingRuleLog $log): ?array
    {
        $event = (string) $log->trigger_event;

        if ($event === MarketingRule::TRIGGER_REGISTER) {
            return $this->registerContext((int) $log->user_id);
        }

        if ($event === MarketingRule::TRIGGER_PAY) {
            $pay = OrderPay::find((int) $log->order_pay_id);
            return $pay && $this->isGrantablePay($pay) ? $this->payContext($pay) : null;
        }

        $order = $this->findOrder((int) $log->order_id);

        return $order ? $this->orderContext($order) : null;
    }

    /**
     * 注册事件上下文（首次发放与重放共用，避免两处口径写两遍）
     *
     * @param int $userId 用户 ID
     * @return array
     */
    private function registerContext(int $userId): array
    {
        return [
            'user_id'      => $userId,
            'scope_key'    => 'user:' . $userId,
            'base_amount'  => '0.00',
            'order_id'     => null,
            'order_pay_id' => null,
            'merchant_ids' => [],
            'product_ids'  => [],
            'category_ids' => [],
        ];
    }

    /**
     * 支付事件上下文：基数取支付单实付，条件判定域覆盖该支付单下的全部订单
     *
     * @param OrderPay $pay 支付单
     * @return array
     */
    private function payContext(OrderPay $pay): array
    {
        $orderIds = array_map('intval', $this->orderQuery()->where('pay_id', (int) $pay->id)->column('id'));

        return [
            'user_id'        => (int) $pay->user_id,
            'scope_key'      => 'pay:' . (int) $pay->id,
            'base_amount'    => $this->decimal($pay->total_amount),
            'order_id'       => null,
            'order_pay_id'   => (int) $pay->id,
            'exclude_pay_id' => (int) $pay->id,
        ] + $this->scopeOfOrders($orderIds);
    }

    /**
     * 确认收货事件上下文：基数取该订单实付
     *
     * @param Order $order 订单
     * @return array
     */
    private function orderContext(Order $order): array
    {
        return [
            'user_id'      => (int) $order->user_id,
            'scope_key'    => 'order:' . (int) $order->id,
            'base_amount'  => $this->decimal($order->total_amount),
            'order_id'     => (int) $order->id,
            'order_pay_id' => (int) $order->pay_id,
        ] + $this->scopeOfOrders([(int) $order->id]);
    }

    /**
     * 这笔支付单是否够格触发发放
     *
     * 沙箱单（is_test）走的不是真钱，发券等于凭空造出一笔可抵扣资产。
     *
     * @param OrderPay $pay 支付单
     * @return bool
     */
    private function isGrantablePay(OrderPay $pay): bool
    {
        return (int) $pay->pay_status === PayStatus::PAID && (int) ($pay->is_test ?? 0) !== 1;
    }

    /**
     * 发放引擎读的订单一律不带商户范围
     *
     * 触发点可能落在商户后台、用户端接口或命令行，同一条规则不能因为「谁触发的」而给出不同结果。
     *
     * @return \think\db\Query
     */
    private function orderQuery()
    {
        return (new Order())->db(['merchant']);
    }

    /**
     * 按 ID 取订单（忽略商户范围与软删除条件由框架处理）
     *
     * @param int $orderId 订单 ID
     * @return Order|null
     */
    private function findOrder(int $orderId): ?Order
    {
        return $orderId > 0 ? $this->orderQuery()->where('id', $orderId)->find() : null;
    }

    /**
     * 反查一批订单涉及的商户 / 商品 / 分类，作为定向条件的判定域
     *
     * @param array $orderIds 订单 ID
     * @return array
     */
    private function scopeOfOrders(array $orderIds): array
    {
        if (empty($orderIds)) {
            return ['merchant_ids' => [], 'product_ids' => [], 'category_ids' => []];
        }

        $merchantIds = array_map('intval', array_unique($this->orderQuery()->whereIn('id', $orderIds)->column('merchant_id')));
        $productIds = array_map('intval', array_unique(OrderItem::whereIn('order_id', $orderIds)->column('product_id')));
        $categoryIds = $productIds === []
            ? []
            : array_map('intval', array_unique((new Product())->db(['merchant'])->whereIn('id', $productIds)->column('category_id')));

        return [
            'merchant_ids' => $merchantIds,
            'product_ids'  => $productIds,
            'category_ids' => $categoryIds,
        ];
    }

    /**
     * 把记录标成终态 skipped
     *
     * @param MarketingRuleLog $log    发放记录
     * @param string           $reason 跳过原因
     * @return void
     */
    private function markSkipped(MarketingRuleLog $log, string $reason): void
    {
        $log->status = MarketingRuleLog::STATUS_SKIPPED;
        $log->skip_reason = $reason;
        $log->save();
    }

    /**
     * 是否唯一键冲突（并发触发时由数据库裁决，不靠应用层判断）
     *
     * @param \Throwable $e 异常
     * @return bool
     */
    private function isDuplicateKey(\Throwable $e): bool
    {
        return str_contains($e->getMessage(), 'Duplicate entry') || str_contains($e->getMessage(), '1062');
    }

    /**
     * 批量统计各规则成功发放张数（列表页一次查完，不逐行 count）
     *
     * @param array<int> $ruleIds 规则 ID
     * @return array<int,int> rule_id => 成功发放张数
     */
    private function grantedCounts(array $ruleIds): array
    {
        if ($ruleIds === []) {
            return [];
        }

        $rows = MarketingRuleLog::whereIn('rule_id', $ruleIds)
            ->where('status', MarketingRuleLog::STATUS_GRANTED)
            ->group('rule_id')
            ->column('COUNT(*)', 'rule_id');

        return array_map('intval', $rows);
    }

    /**
     * 当前后台账号是否为平台超管
     *
     * @return bool
     */
    private function isSuper(): bool
    {
        return AppContext::getAdminRole() === AdminRole::SUPER;
    }

    /**
     * 后台按 ID 读写规则的统一权限收口
     *
     * 报错文案与「记录不存在」一致：营销规则对商家是不可见能力，
     * 给「无权限」等于告诉他这条规则存在（同 CouponService::scopedCoupon 的防枚举口径）。
     *
     * @return void
     * @throws BizException 非平台超管
     */
    private function assertSuper(): void
    {
        if (!$this->isSuper()) {
            throw new BizException('营销规则不存在');
        }
    }

    /**
     * 奖励展示文案，如「立减 20.00」「实付 10%（封顶 20.00）」
     *
     * 金额是基准币种数字（与 CouponService::discountText() 同一口径，不带币种符号），
     * 符号由页面表头统一给，避免每行重复查币种配置。
     *
     * @param MarketingRule $rule 规则
     * @return string
     */
    private function rewardText(MarketingRule $rule): string
    {
        if ($rule->reward_mode === MarketingRule::REWARD_PERCENT) {
            $percent = rtrim(rtrim(number_format((float) $rule->reward_value, 2, '.', ''), '0'), '.');
            $text = '实付 ' . $percent . '%';
            if (bccomp((string) $rule->reward_cap, '0', 2) > 0) {
                $text .= '（封顶 ' . money($rule->reward_cap) . '）';
            }
            return $text;
        }

        return '立减 ' . money($rule->reward_value);
    }

    /**
     * 批量取奖励券模板名（coupon_id => name），一次查全
     *
     * @param array<int,int> $couponIds 券 ID（0/空自动忽略）
     * @return array<int,string>
     */
    private function couponNames(array $couponIds): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $couponIds))));
        if ($ids === []) {
            return [];
        }

        $names = [];
        foreach (Coupon::whereIn('id', $ids)->column('name', 'id') as $id => $name) {
            $names[(int) $id] = (string) $name;
        }

        return $names;
    }

    /**
     * 组装规则输出
     *
     * @param MarketingRule $rule       规则
     * @param int           $granted    成功发放张数
     * @param string        $couponName 引用的奖励券名（内联时为空）
     * @return array
     */
    private function formatRule(MarketingRule $rule, int $granted, string $couponName = ''): array
    {
        return [
            'id'            => (int) $rule->id,
            'name'          => (string) $rule->name,
            'type'          => (string) $rule->type,
            'type_label'    => MarketingRule::TYPE_LABELS[(string) $rule->type] ?? '',
            'trigger_event' => (string) $rule->trigger_event,
            'trigger_label' => MarketingRule::TRIGGER_LABELS[(string) $rule->trigger_event] ?? '',
            'reward_mode'   => (string) $rule->reward_mode,
            'reward_label'  => MarketingRule::REWARD_LABELS[(string) $rule->reward_mode] ?? '',
            'reward_value'  => (string) $rule->reward_value,
            'reward_cap'    => (string) $rule->reward_cap,
            'reward_text'   => $this->rewardText($rule),
            'coupon_id'     => $rule->coupon_id !== null ? (int) $rule->coupon_id : null,
            'coupon_name'   => $rule->coupon_id !== null ? $couponName : '',
            'inline_coupon' => $rule->coupon_id !== null ? null : $rule->inlineCoupon(),
            'conditions'    => $rule->conditions(),
            'total_limit'   => (int) $rule->total_limit,
            'issued_qty'    => (int) $rule->issued_qty,
            'granted_logs'  => $granted,
            'per_user_limit' => (int) $rule->per_user_limit,
            'start_time'    => (string) ($rule->start_time ?? ''),
            'end_time'      => (string) ($rule->end_time ?? ''),
            'status'        => (int) $rule->status,
            'priority'      => (int) $rule->priority,
            'remark'        => (string) ($rule->remark ?? ''),
            'create_time'   => (string) ($rule->create_time ?? ''),
        ];
    }

    /**
     * 组装发放记录输出
     *
     * @param MarketingRuleLog $log 发放记录
     * @return array
     */
    private function formatLog(MarketingRuleLog $log): array
    {
        return [
            'id'             => (int) $log->id,
            'rule_id'        => (int) $log->rule_id,
            'user_id'        => (int) $log->user_id,
            'order_id'       => $log->order_id !== null ? (int) $log->order_id : null,
            'order_pay_id'   => $log->order_pay_id !== null ? (int) $log->order_pay_id : null,
            'trigger_event'  => (string) $log->trigger_event,
            'trigger_label'  => MarketingRule::TRIGGER_LABELS[(string) $log->trigger_event] ?? (string) $log->trigger_event,
            'scope_key'      => (string) $log->scope_key,
            'reward_amount'  => (string) $log->reward_amount,
            'coupon_id'      => $log->coupon_id !== null ? (int) $log->coupon_id : null,
            'coupon_user_id' => $log->coupon_user_id !== null ? (int) $log->coupon_user_id : null,
            'status'         => (string) $log->status,
            'status_label'   => MarketingRuleLog::STATUS_LABELS[(string) $log->status] ?? (string) $log->status,
            'skip_reason'    => (string) ($log->skip_reason ?? ''),
            'skip_label'     => MarketingRuleLog::SKIP_LABELS[(string) ($log->skip_reason ?? '')] ?? '',
            'error_msg'      => (string) ($log->error_msg ?? ''),
            'create_time'    => (string) ($log->create_time ?? ''),
        ];
    }

    /**
     * 内联券定义校验与归一化
     *
     * 内联只用于生成「自动到账层」的奖励券（面额由规则算出来，无法预先建模板）。
     * 需要「用户手动选用」的券请在优惠管理里建好，再用 coupon_id 引用。
     *
     * @param array|string $inline 内联定义
     * @param string       $name   规则名，缺省用作券名
     * @return array
     * @throws BizException 字段不合法
     */
    private function normalizeInline($inline, string $name): array
    {
        $inline = is_array($inline) ? $inline : (json_decode((string) $inline, true) ?: []);

        $validDays = max(0, (int) ($inline['valid_days'] ?? 30));
        $expireAt = $this->normalizeTime($inline['expire_at'] ?? '');
        if ($validDays === 0 && $expireAt === null) {
            throw new BizException('优惠券有效期需填「发放后 N 天」或「固定到期日」其中之一');
        }

        $minAmount = $this->decimal($inline['min_amount'] ?? 0);
        if (bccomp($minAmount, '0', 2) < 0) {
            throw new BizException('券门槛金额不能为负数');
        }

        return [
            'name'       => trim((string) ($inline['name'] ?? '')) ?: $name,
            'min_amount' => $minAmount,
            'valid_days' => $validDays,
            'expire_at'  => $expireAt,
        ];
    }

    /**
     * 条件校验与归一化
     *
     * @param array|string $conditions 条件
     * @param string       $type       规则类型（决定 new_user_only 的缺省值）
     * @return array
     * @throws BizException 字段不合法
     */
    private function normalizeConditions($conditions, string $type): array
    {
        $conditions = is_array($conditions) ? $conditions : (json_decode((string) $conditions, true) ?: []);

        $minAmount = $this->decimal($conditions['min_order_amount'] ?? 0);
        if (bccomp($minAmount, '0', 2) < 0) {
            throw new BizException('最低订单金额不能为负数');
        }

        $out = [
            'min_order_amount' => $minAmount,
            'new_user_only'    => isset($conditions['new_user_only'])
                ? (bool) $conditions['new_user_only']
                : $type === MarketingRule::TYPE_ORDER_GIFT,
        ];
        foreach (['merchant_ids', 'product_ids', 'category_ids'] as $key) {
            $ids = array_values(array_unique(array_filter(array_map('intval', (array) ($conditions[$key] ?? [])))));
            if ($ids !== []) {
                $out[$key] = $ids;
            }
        }

        return $out;
    }

    /**
     * 时间字段归一化，空串按 null 处理
     *
     * @param mixed $value 时间
     * @return string|null
     */
    private function normalizeTime($value): ?string
    {
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }
        $ts = strtotime($value);
        return $ts ? date('Y-m-d H:i:s', $ts) : null;
    }

    /**
     * 金额统一格式化为两位小数字符串
     *
     * @param mixed $value 金额
     * @return string
     */
    private function decimal($value): string
    {
        return bcadd((string) $value, '0', 2);
    }
}
