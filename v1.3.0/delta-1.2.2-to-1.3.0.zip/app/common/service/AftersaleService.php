<?php

namespace app\common\service;

use app\common\enum\AftersaleStatus;
use app\common\enum\OrderStatus;
use app\common\exception\BizException;
use app\common\model\Aftersale;
use app\common\model\Order;
use app\common\model\RefundLog;
use app\common\support\AppContext;

class AftersaleService
{
    public function apply(int $orderId, int $userId, int $type, string $reason): Aftersale
    {
        $order = Order::where('id', $orderId)->where('user_id', $userId)->find();
        if (!$order) {
            throw new BizException('订单不存在');
        }
        if (!in_array($order->status, [OrderStatus::PENDING_SHIP, OrderStatus::SHIPPING, OrderStatus::DELIVERED, OrderStatus::COMPLETED])) {
            throw new BizException('订单状态不允许申请售后');
        }
        $existing = Aftersale::where('order_id', $orderId)->where('status', 'in', [AftersaleStatus::PENDING_REVIEW, AftersaleStatus::APPROVED, AftersaleStatus::PENDING_RETURN])->find();
        if ($existing) {
            throw new BizException('该订单已有处理中的售后');
        }
        $as = new Aftersale();
        $as->aftersale_no = date('YmdHis') . str_pad((string)mt_rand(0, 9999), 4, '0', STR_PAD_LEFT);
        $as->order_id = $orderId;
        $as->user_id = $userId;
        $as->merchant_id = $order->merchant_id;
        $as->type = $type;
        $as->reason = $reason;
        $as->status = AftersaleStatus::PENDING_REVIEW;
        $as->refund_amount = $order->total_amount;
        $as->apply_at = date('Y-m-d H:i:s');
        $as->save();
        return $as;
    }

    public function approve(int $aftersaleId, int $adminId): void
    {
        $as = Aftersale::find($aftersaleId);
        if (!$as) {
            throw new BizException('售后单不存在');
        }
        if ($as->status != AftersaleStatus::PENDING_REVIEW) {
            throw new BizException('售后单状态不允许审核');
        }
        $as->approve_at = date('Y-m-d H:i:s');

        if ((int) $as->type === 2) {
            // 退货退款：先等商家确认收到退货，再出款
            $as->status = AftersaleStatus::PENDING_RETURN;
            $as->save();
            return;
        }

        // 仅退款：审核通过即出款；出款成功才置「已完成」
        $as->status = AftersaleStatus::APPROVED;
        $as->save();
        $this->settle($as, $adminId);
    }

    public function reject(int $aftersaleId, int $adminId, string $reason): void
    {
        $as = Aftersale::find($aftersaleId);
        if (!$as) {
            throw new BizException('售后单不存在');
        }
        if ($as->status != AftersaleStatus::PENDING_REVIEW) {
            throw new BizException('售后单状态不允许操作');
        }
        $as->status = AftersaleStatus::REJECTED;
        $as->approve_at = date('Y-m-d H:i:s');
        $as->save();
    }

    public function confirmReturnReceived(int $aftersaleId, int $merchantId): void
    {
        $as = Aftersale::where('id', $aftersaleId)->where('merchant_id', $merchantId)->find();
        if (!$as) {
            throw new BizException('售后单不存在');
        }
        if ($as->status != AftersaleStatus::PENDING_RETURN) {
            throw new BizException('售后单状态不允许操作');
        }
        $this->settle($as, AppContext::getAdminId());
    }

    /**
     * 后台重试退款：只允许停在中间态且上次未成功的售后
     *
     * requesting（结果未知）也会走这里，由 RefundService 判定为「待确认」并拒绝重复出款。
     *
     * @param int      $aftersaleId 售后单 ID
     * @param int|null $operatorId  操作人
     * @return void
     * @throws BizException
     */
    public function retryRefund(int $aftersaleId, ?int $operatorId = null): void
    {
        $as = Aftersale::find($aftersaleId);
        if (!$as) {
            throw new BizException('售后单不存在');
        }
        if (!in_array((int) $as->status, [AftersaleStatus::APPROVED, AftersaleStatus::PENDING_RETURN], true)) {
            throw new BizException('当前售后状态不需要重试退款');
        }
        $this->settle($as, $operatorId);
    }

    /**
     * 执行退款并把售后推进到已完成
     *
     * 退款事实以 refund_log 为准：只有通道确认成功，订单才会被 RefundService 转成已退款，
     * 这里才把售后置「已完成」；失败/待确认保持中间态，由后台重试或人工核对。
     *
     * @param Aftersale $as         售后单
     * @param int|null  $operatorId 操作人
     * @return void
     * @throws BizException 退款未完成
     */
    private function settle(Aftersale $as, ?int $operatorId): void
    {
        $result = (new RefundService())->apply((int) $as->id, $operatorId);
        if ($result['status'] !== RefundLog::STATUS_SUCCESS) {
            throw new BizException('退款未完成：' . $result['message']);
        }

        $as->status = AftersaleStatus::COMPLETED;
        $as->complete_at = date('Y-m-d H:i:s');
        $as->save();
    }
}
