<?php

namespace app\common\service;

use app\common\exception\BizException;
use app\common\lib\RedisCache;
use app\common\lib\WechatLogin;
use app\common\model\User;
use think\facade\Log;

class UserService
{
    /** 用户 token 有效期：30 天（访问时滑动续期） */
    public const TOKEN_TTL = 30 * 24 * 3600;

    /** 剩余有效期低于 7 天时自动续期，活跃用户可长期保持登录 */
    public const TOKEN_RENEW_THRESHOLD = 7 * 24 * 3600;

    public function loginByCode(string $code): array
    {
        $sess = WechatLogin::code2session($code);
        $openid = $sess['openid'];
        $user = User::where('openid', $openid)->find();
        if (!$user) {
            $user = new User();
            $user->openid = $openid;
            $user->unionid = $sess['unionid'] ?? null;
            $user->save();
            $user = User::find($user->id);

            // 小程序首登即注册，注册礼与浏览器端走同一个入口；此时用户还没有 email，
            // 到账通知会在发放侧标 skipped_no_email，券照发。
            try {
                (new MarketingService())->grantOnRegister((int) $user->id);
            } catch (\Throwable $e) {
                Log::error('marketing grant on register failed: user=' . (int) $user->id . ' err=' . $e->getMessage());
            }
        }
        $token = bin2hex(random_bytes(16));
        RedisCache::set('token:' . $token, (int)$user->id, self::TOKEN_TTL);
        return ['token' => $token, 'user' => $user];
    }

    public function getTokenUser(string $token): ?User
    {
        $userId = RedisCache::get('token:' . $token);
        if (!$userId) {
            return null;
        }
        return User::find((int)$userId);
    }

    public function getProfile(int $userId): User
    {
        $user = User::find($userId);
        if (!$user) {
            throw new BizException('用户不存在');
        }
        return $user;
    }

    public function updateProfile(int $userId, ?string $nickname, ?string $avatar): User
    {
        $user = User::find($userId);
        if (!$user) {
            throw new BizException('用户不存在');
        }
        if ($nickname !== null && $nickname !== '') {
            $user->nickname = mb_substr($nickname, 0, 64);
        }
        if ($avatar !== null && $avatar !== '') {
            $user->avatar = $avatar;
        }
        $user->save();
        return $user;
    }

    public function bindPhone(int $userId, string $code): array
    {
        if ($code === '') {
            throw new BizException('code不能为空');
        }
        $phone = WechatLogin::getPhoneNumber($code);
        $user = User::find($userId);
        if (!$user) {
            throw new BizException('用户不存在');
        }
        $user->phone = $phone;
        $user->save();
        return ['phone' => $phone];
    }
}
