<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\enum\AdminRole;
use app\common\enum\PayStatus;
use app\common\exception\BizException;
use app\common\lib\DelayQueue;
use app\common\lib\DistributedLock;
use app\common\lib\Mailer;
use app\common\lib\MailTemplate;
use app\common\model\Coupon;
use app\common\model\CouponUser;
use app\common\model\MarketingGrant;
use app\common\model\MarketingGrantLog;
use app\common\model\MarketingNotifyLog;
use app\common\model\Order;
use app\common\model\User;
use app\common\support\AppContext;
use think\facade\Db;
use think\facade\Log;

/**
 * 批量发券：圈选人群 → 分批发券 → 事务性邮件通知
 *
 * 三条不变量，改动前先读：
 * 1. 券只由 CouponService::issue() 发放（行锁 + 模板限量 + 每人限额），本服务不复制发放逻辑，
 *    只负责任务幂等（uk_grant_user）、进度游标与通知；
 * 2. 重复执行、进程重启、并发点击都不重复发：先插每人一条 grant_log 占键，撞键即「已发放过」；
 * 3. 通知失败绝不冒泡：邮件未开/无邮箱/SMTP 异常只写 marketing_notify_log，由补偿命令重放。
 *
 * 平台级功能：后台入口（admin* 方法）只允许平台超管；队列里的 run()/sendNotify() 不带角色判断
 * （命令行没有登录态），权限收口的差异在方法命名上显式区分。
 */
class MarketingGrantService
{
    /** 同一 (任务,用户) 的发放串行锁 */
    private const LOCK_TTL = 15;

    /** 每批上限，防止一次 ack 太多把请求拖死 */
    private const MAX_BATCH = 2000;

    /** 通知最多尝试次数（补偿命令限次） */
    private const MAX_NOTIFY_ATTEMPTS = 3;

    /** 导入名单最多行数，防止把接口当群发工具 */
    private const MAX_IMPORT_ROWS = 50000;

    // ------------------------------------------------------------------
    // 后台管理（页面与管理 API 共用，权限收口在这里）
    // ------------------------------------------------------------------

    /**
     * 任务列表
     *
     * @param array $filters keyword / status / audience_type
     * @param int   $page    页码
     * @param int   $size    每页数量
     * @return array{list:array,pager:\think\Paginator}
     */
    public function adminList(array $filters, int $page = 1, int $size = 20): array
    {
        $this->assertSuper();

        $query = MarketingGrant::order('id', 'desc');

        $keyword = trim((string) ($filters['keyword'] ?? ''));
        if ($keyword !== '') {
            $query->whereLike('name', '%' . $keyword . '%');
        }
        $type = (string) ($filters['audience_type'] ?? '');
        if (isset(MarketingGrant::AUDIENCE_LABELS[$type])) {
            $query->where('audience_type', $type);
        }
        $status = (string) ($filters['status'] ?? '');
        if (isset(MarketingGrant::STATUS_LABELS[$status])) {
            $query->where('status', $status);
        }

        $pager = $query->paginate([
            'list_rows' => $size,
            'page'      => $page,
            'query'     => ['keyword' => $keyword, 'audience_type' => $type, 'status' => $status],
        ]);

        $grants      = $pager->items();
        $couponNames = $this->couponNames(array_map(fn ($g) => (int) $g->coupon_id, $grants));

        $list = [];
        foreach ($grants as $grant) {
            $list[] = $this->formatGrant($grant, $couponNames[(int) $grant->coupon_id] ?? '');
        }

        return ['list' => $list, 'pager' => $pager];
    }

    /**
     * 任务详情：进度 + 最近发放记录 + 通知统计
     *
     * @param int $id 任务 ID
     * @return array
     * @throws BizException 非超管或不存在
     */
    public function adminDetail(int $id): array
    {
        $this->assertSuper();

        $grant = MarketingGrant::find($id);
        if (!$grant) {
            throw new BizException('发券任务不存在');
        }

        $data = $this->formatGrant($grant, $this->couponNames([(int) $grant->coupon_id])[(int) $grant->coupon_id] ?? '');

        $logs = MarketingGrantLog::where('grant_id', $id)->order('id', 'desc')->limit(50)->select();
        $userIds = [];
        foreach ($logs as $log) {
            $userIds[] = (int) $log->user_id;
        }
        $userNames = $userIds
            ? User::whereIn('id', array_unique(array_filter($userIds)))->column('nickname', 'id')
            : [];

        $data['logs'] = [];
        foreach ($logs as $log) {
            $data['logs'][] = [
                'id'             => (int) $log->id,
                'user_id'        => (int) $log->user_id,
                'user_name'      => (string) ($userNames[(int) $log->user_id] ?? ''),
                'email'          => $this->maskEmail((string) $log->email),
                'coupon_user_id' => $log->coupon_user_id !== null ? (int) $log->coupon_user_id : null,
                'status'         => (string) $log->status,
                'status_label'   => MarketingGrantLog::STATUS_LABELS[(string) $log->status] ?? (string) $log->status,
                'skip_reason'    => (string) ($log->skip_reason ?? ''),
                'skip_label'     => MarketingGrantLog::SKIP_LABELS[(string) ($log->skip_reason ?? '')] ?? '',
                'error_msg'      => (string) ($log->error_msg ?? ''),
                'create_time'    => (string) ($log->create_time ?? ''),
            ];
        }

        $data['notify'] = $this->notifySummary($id);

        return $data;
    }

    /**
     * 创建 / 更新任务
     *
     * 只允许在待执行 / 已暂停时改配置；导入型任务保存时就把名单落成每人一条 pending 记录，
     * 这样「目标人数」与勾选结果稳定，重复导入只会在执行时撞幂等键。
     *
     * @param array    $data 表单数据
     * @param int|null $id   为空表示新增
     * @return int 任务 ID
     * @throws BizException
     */
    public function adminSave(array $data, ?int $id = null): int
    {
        $this->assertSuper();

        $name = trim((string) ($data['name'] ?? ''));
        if ($name === '') {
            throw new BizException('请填写任务名称');
        }

        $type = (string) ($data['audience_type'] ?? '');
        if (!isset(MarketingGrant::AUDIENCE_LABELS[$type])) {
            throw new BizException('人群方式不合法');
        }

        $couponId = (int) ($data['coupon_id'] ?? 0);
        $coupon   = $couponId > 0 ? Coupon::find($couponId) : null;
        if (!$coupon) {
            throw new BizException('发放券模板不存在');
        }
        if (!in_array((int) $coupon->tier, [Coupon::TIER_AUTO_GRANT, Coupon::TIER_MANUAL], true)) {
            throw new BizException('只能选择「自动到账券」或「优惠券」作为发放模板');
        }

        $audience = $this->normalizeAudience($type, $data['audience'] ?? $data['audience_json'] ?? []);

        $batchSize = (int) ($data['batch_size'] ?? 500);
        $batchSize = max(1, min(self::MAX_BATCH, $batchSize));

        $startTime = $this->normalizeTime($data['start_time'] ?? '');
        $endTime   = $this->normalizeTime($data['end_time'] ?? '');
        if ($startTime && $endTime && strtotime($startTime) > strtotime($endTime)) {
            throw new BizException('开始时间不能晚于结束时间');
        }

        $importRows = [];
        if ($type === MarketingGrant::AUDIENCE_IMPORT) {
            $raw = trim((string) ($data['import_list'] ?? ''));
            if ($raw !== '') {
                $importRows = $this->parseImport($raw);
            } elseif ($id === null) {
                throw new BizException('请粘贴名单或上传 CSV');
            }
        }

        $grant = null;
        if ($id !== null) {
            $grant = MarketingGrant::find($id);
            if (!$grant) {
                throw new BizException('发券任务不存在');
            }
            if (!in_array((string) $grant->status, MarketingGrant::EDITABLE_STATUSES, true)) {
                throw new BizException('只有待执行或已暂停的任务可以修改');
            }
        } else {
            $grant = new MarketingGrant();
            $grant->status = MarketingGrant::STATUS_PENDING;
        }

        $grant->name          = $name;
        $grant->coupon_id     = $couponId;
        $grant->audience_type = $type;
        $grant->audience_json = $audience;
        $grant->batch_size    = $batchSize;
        $grant->start_time    = $startTime;
        $grant->end_time      = $endTime;
        $grant->remark        = trim((string) ($data['remark'] ?? '')) ?: null;

        if ($type === MarketingGrant::AUDIENCE_IMPORT) {
            if ($importRows) {
                $grant->total_target = count($importRows);
            } elseif ($id === null) {
                $grant->total_target = 0;
            }
        } else {
            $grant->total_target = $this->previewAudience($type, $audience);
        }

        $grant->save();

        if ($importRows) {
            $this->importTargets((int) $grant->id, $importRows);
        }

        return (int) $grant->id;
    }

    /**
     * 删除任务（只允许没开始跑或已取消的）
     *
     * @param int $id 任务 ID
     * @return void
     * @throws BizException
     */
    public function adminDelete(int $id): void
    {
        $this->assertSuper();

        $grant = MarketingGrant::find($id);
        if (!$grant) {
            throw new BizException('发券任务不存在');
        }
        if (!in_array((string) $grant->status, [MarketingGrant::STATUS_PENDING, MarketingGrant::STATUS_CANCELED], true)) {
            throw new BizException('执行中或已完成的任务不能删除，请先取消');
        }

        Db::startTrans();
        try {
            MarketingGrantLog::where('grant_id', $id)->delete();
            MarketingNotifyLog::where('grant_id', $id)->delete();
            $grant->delete();
            Db::commit();
        } catch (\Throwable $e) {
            Db::rollback();
            throw $e;
        }
    }

    /**
     * 后台触发的执行（带权限）
     *
     * @param int      $id    任务 ID
     * @param int|null $batch 本批人数
     * @return array
     */
    public function adminRun(int $id, ?int $batch = null): array
    {
        $this->assertSuper();
        return $this->run($id, $batch);
    }

    /**
     * 后台取消（带权限）
     *
     * @param int $id 任务 ID
     * @return void
     */
    public function adminCancel(int $id): void
    {
        $this->assertSuper();
        $this->cancel($id);
    }

    /**
     * 后台作废未使用券（带权限）
     *
     * @param int $id 任务 ID
     * @return int 受影响的券张数
     */
    public function adminRevoke(int $id): int
    {
        $this->assertSuper();
        return $this->revoke($id);
    }

    /**
     * 后台重放失败通知（带权限）
     *
     * @param int $limit 本批数量
     * @return int 入队条数
     */
    public function adminResendFailed(int $limit = 100): int
    {
        $this->assertSuper();
        return $this->resendFailed($limit);
    }

    // ------------------------------------------------------------------
    // 人群与预览
    // ------------------------------------------------------------------

    /**
     * 预估覆盖人数（只 count，不取 ID）
     *
     * @param string $type     人群方式
     * @param array  $audience 参数
     * @return int
     * @throws BizException
     */
    public function previewAudience(string $type, array $audience): int
    {
        if (!isset(MarketingGrant::AUDIENCE_LABELS[$type])) {
            throw new BizException('人群方式不合法');
        }
        if ($type === MarketingGrant::AUDIENCE_IMPORT) {
            return (int) ($audience['imported_count'] ?? 0);
        }

        $audience = $this->normalizeAudience($type, $audience);
        $fake     = new MarketingGrant();
        $fake->audience_type = $type;
        $fake->audience_json = $audience;

        return (int) $this->audienceQuery($fake)->count();
    }

    // ------------------------------------------------------------------
    // 执行（队列与后台共用，不带角色判断）
    // ------------------------------------------------------------------

    /**
     * 推进一批；未完成时自动续排下一批
     *
     * @param int      $id    任务 ID
     * @param int|null $batch 本批人数，缺省用任务配置
     * @return array{processed:int,granted:int,skipped:int,failed:int,done:bool,reason:string}
     */
    public function run(int $id, ?int $batch = null): array
    {
        $result = ['processed' => 0, 'granted' => 0, 'skipped' => 0, 'failed' => 0, 'done' => false, 'reason' => ''];

        $grant = MarketingGrant::find($id);
        if (!$grant) {
            $result['reason'] = 'missing';
            return $result;
        }

        $status = (string) $grant->status;
        if (in_array($status, [MarketingGrant::STATUS_DONE, MarketingGrant::STATUS_CANCELED, MarketingGrant::STATUS_PAUSED], true)) {
            $result['reason'] = $status;
            return $result;
        }

        $now = date('Y-m-d H:i:s');
        if ($grant->start_time && $now < (string) $grant->start_time) {
            $result['reason'] = 'not_started';
            $result['done']   = true;
            return $result;
        }
        if ($grant->end_time && $now > (string) $grant->end_time) {
            $grant->status = MarketingGrant::STATUS_DONE;
            $grant->save();
            $result['reason'] = 'ended';
            $result['done']   = true;
            return $result;
        }

        $coupon = Coupon::find((int) $grant->coupon_id);
        if (!$coupon || (int) $coupon->status !== 1) {
            $result['reason'] = MarketingGrantLog::SKIP_COUPON_UNAVAILABLE;
            $result['done']   = true;
            return $result;
        }

        if ((string) $grant->status === MarketingGrant::STATUS_PENDING) {
            $grant->status = MarketingGrant::STATUS_RUNNING;
            $grant->save();
        }

        $batch = max(1, min(self::MAX_BATCH, $batch ?? (int) $grant->batch_size));

        if ((string) $grant->audience_type === MarketingGrant::AUDIENCE_IMPORT) {
            [$cursor, $more] = $this->runImportBatch($grant, $coupon, $batch, $result);
            $grant->cursor_log_id = $cursor;
        } else {
            [$cursor, $more] = $this->runAudienceBatch($grant, $coupon, $batch, $result);
            $grant->cursor_user_id = $cursor;
        }

        $grant->granted_qty = (int) $grant->granted_qty + $result['granted'];
        $grant->skipped_qty = (int) $grant->skipped_qty + $result['skipped'];
        $grant->failed_qty  = (int) $grant->failed_qty + $result['failed'];
        $grant->status      = $more ? MarketingGrant::STATUS_RUNNING : MarketingGrant::STATUS_DONE;
        $grant->save();

        $result['done'] = !$more;
        if ($more) {
            DelayQueue::delay('marketing_grant_run', ['id' => $id], time() + 1);
        }

        return $result;
    }

    /**
     * 取消任务：已发出的券不受影响，没发的立即停
     *
     * @param int $id 任务 ID
     * @return void
     * @throws BizException
     */
    public function cancel(int $id): void
    {
        $grant = MarketingGrant::find($id);
        if (!$grant) {
            throw new BizException('发券任务不存在');
        }
        if ((string) $grant->status === MarketingGrant::STATUS_DONE) {
            throw new BizException('已完成的任务不能取消');
        }
        $grant->status = MarketingGrant::STATUS_CANCELED;
        $grant->save();
    }

    /**
     * 止损：作废该任务发出的未使用券（已核销的不追）
     *
     * @param int $id 任务 ID
     * @return int 受影响的券张数
     */
    public function revoke(int $id): int
    {
        $couponUserIds = MarketingGrantLog::where('grant_id', $id)
            ->where('status', MarketingGrantLog::STATUS_GRANTED)
            ->whereNotNull('coupon_user_id')
            ->column('coupon_user_id');
        if (!$couponUserIds) {
            return 0;
        }

        return (int) CouponUser::whereIn('id', $couponUserIds)
            ->where('status', CouponUser::STATUS_UNUSED)
            ->update(['status' => CouponUser::STATUS_REVOKED]);
    }

    // ------------------------------------------------------------------
    // 通知
    // ------------------------------------------------------------------

    /**
     * 发送通知（队列消费入口）：邮件异常只记失败，不抛
     *
     * @param int $logId 通知记录 ID
     * @return void
     */
    public function sendNotify(int $logId): void
    {
        $log = MarketingNotifyLog::find($logId);
        if (!$log) {
            return;
        }
        if (!in_array((string) $log->status, [MarketingNotifyLog::STATUS_PENDING, MarketingNotifyLog::STATUS_FAILED], true)) {
            return;
        }
        if ((int) $log->attempts >= self::MAX_NOTIFY_ATTEMPTS) {
            return;
        }
        if ((string) $log->to_email === '') {
            $log->status = MarketingNotifyLog::STATUS_SKIPPED_NO_EMAIL;
            $log->save();
            return;
        }

        $couponUser = CouponUser::find((int) $log->coupon_user_id);
        $coupon     = $couponUser ? Coupon::find((int) $couponUser->coupon_id) : null;
        $user       = User::find((int) $log->user_id);
        if (!$couponUser || !$coupon) {
            $log->status    = MarketingNotifyLog::STATUS_FAILED;
            $log->error_msg = '券实例不存在';
            $log->save();
            return;
        }

        $mail = MailTemplate::render((string) $log->scene, [
            'brand'       => (string) site_config('brand.name', ''),
            'name'        => (string) ($user->nickname ?? ''),
            'coupon_name' => (string) $coupon->name,
            'amount_text' => CouponService::discountText($coupon),
            'min_amount'  => (string) $coupon->min_amount,
            'expire_at'   => (string) ($couponUser->expire_time ?? ''),
            'link'        => $this->couponLink(),
        ]);

        $log->attempts = (int) $log->attempts + 1;
        try {
            $ok = (new Mailer())->send((string) $log->to_email, $mail['subject'], $mail['html'], '', true);
            $log->status    = $ok ? MarketingNotifyLog::STATUS_SENT : MarketingNotifyLog::STATUS_FAILED;
            $log->error_msg = $ok ? null : '邮件服务未启用或发送失败';
            $log->sent_at   = $ok ? date('Y-m-d H:i:s') : null;
        } catch (\Throwable $e) {
            $log->status    = MarketingNotifyLog::STATUS_FAILED;
            $log->error_msg = mb_substr($e->getMessage(), 0, 200);
        }
        $log->save();
    }

    /**
     * 券退回通知（退款成功后由 RefundService 调用）
     *
     * 与到账通知共用 createNotify：无邮箱/邮件未开只落状态，不影响退款与返券。
     *
     * @param int $couponUserId 券实例
     * @return void
     */
    public function notifyCouponRestored(int $couponUserId): void
    {
        try {
            $userId = (int) CouponUser::where('id', $couponUserId)->value('user_id');
            if ($userId > 0) {
                $this->createNotify(MarketingNotifyLog::SCENE_COUPON_RESTORED, $userId, $couponUserId, null);
            }
        } catch (\Throwable $e) {
            Log::error('coupon restored notify failed: coupon_user=' . $couponUserId . ' err=' . $e->getMessage());
        }
    }

    /**
     * 重放失败通知（补偿命令用），限次由 sendNotify 自己卡
     *
     * @param int $limit 本批条数
     * @return int 入队条数
     */
    public function resendFailed(int $limit = 100): int
    {
        $logs = MarketingNotifyLog::whereIn('status', [MarketingNotifyLog::STATUS_FAILED, MarketingNotifyLog::STATUS_PENDING])
            ->where('attempts', '<', self::MAX_NOTIFY_ATTEMPTS)
            ->where('to_email', '<>', '')
            ->order('id')
            ->limit(max(1, min(1000, $limit)))
            ->select();

        $queued = 0;
        foreach ($logs as $log) {
            DelayQueue::delay('marketing_notify', ['id' => (int) $log->id], time());
            $queued++;
        }
        return $queued;
    }

    /**
     * 到期提醒：未使用且 N 天内到期的券，每券一次
     *
     * @param int $days 提前天数
     * @return int 新增通知条数
     */
    public function remindExpiring(int $days = 3): int
    {
        $days = max(1, $days);
        $from = date('Y-m-d H:i:s');
        $to   = date('Y-m-d H:i:s', time() + $days * 86400);

        $rows = CouponUser::where('status', CouponUser::STATUS_UNUSED)
            ->whereNotNull('expire_time')
            ->whereBetween('expire_time', [$from, $to])
            ->field('id,user_id')
            ->order('id')
            ->limit(1000)
            ->select();

        $created = 0;
        foreach ($rows as $row) {
            if ($this->createNotify(MarketingNotifyLog::SCENE_EXPIRING_SOON, (int) $row['user_id'], (int) $row['id'], null) !== null) {
                $created++;
            }
        }

        return $created;
    }

    // ------------------------------------------------------------------
    // 内部
    // ------------------------------------------------------------------

    /**
     * 查询型人群本批：按 user.id 游标推进
     *
     * @param MarketingGrant $grant  任务
     * @param Coupon         $coupon 券模板
     * @param int            $batch  本批人数
     * @param array          $result 计数引用
     * @return array{0:int,1:bool} [新游标, 是否还有下一批]
     */
    private function runAudienceBatch(MarketingGrant $grant, Coupon $coupon, int $batch, array &$result): array
    {
        $cursor = (int) $grant->cursor_user_id;
        $ids    = $this->audienceQuery($grant)
            ->where('id', '>', $cursor)
            ->order('id')
            ->limit($batch)
            ->column('id');

        if (!$ids) {
            return [$cursor, false];
        }

        $emails = User::whereIn('id', $ids)->column('email', 'id');
        foreach ($ids as $userId) {
            $result['processed']++;
            $res = $this->grantOne($grant, $coupon, (int) $userId, (string) ($emails[$userId] ?? ''));
            $result[$res]++;
        }

        $last = (int) end($ids);
        return [$last, count($ids) >= $batch];
    }

    /**
     * 导入型人群本批：按 marketing_grant_log.id 游标推进
     *
     * @param MarketingGrant $grant  任务
     * @param Coupon         $coupon 券模板
     * @param int            $batch  本批条数
     * @param array          $result 计数引用
     * @return array{0:int,1:bool}
     */
    private function runImportBatch(MarketingGrant $grant, Coupon $coupon, int $batch, array &$result): array
    {
        $cursor = (int) $grant->cursor_log_id;
        $logs   = MarketingGrantLog::where('grant_id', (int) $grant->id)
            ->where('id', '>', $cursor)
            ->where('status', MarketingGrantLog::STATUS_PENDING)
            ->order('id')
            ->limit($batch)
            ->select();

        if (!$logs) {
            return [$cursor, false];
        }

        $last = 0;
        foreach ($logs as $log) {
            $result['processed']++;
            $last = (int) $log->id;
            $res  = $this->grantOne($grant, $coupon, (int) $log->user_id, (string) $log->email, $log);
            $result[$res]++;
        }
        $pending = MarketingGrantLog::where('grant_id', (int) $grant->id)
            ->where('id', '>', $last)
            ->where('status', MarketingGrantLog::STATUS_PENDING)
            ->count();

        return [$last, $pending > 0];
    }

    /**
     * 给一个用户发一张券（幂等 + 单用户串行）
     *
     * @param MarketingGrant          $grant   任务
     * @param Coupon                  $coupon  券模板
     * @param int                     $userId  用户 ID（导入名单里无账号为 0）
     * @param string                  $email   邮箱快照
     * @param MarketingGrantLog|null  $existing 导入型人群已预建的 pending 记录
     * @return string granted / skipped / failed
     */
    private function grantOne(MarketingGrant $grant, Coupon $coupon, int $userId, string $email, ?MarketingGrantLog $existing = null): string
    {
        $lockKey = 'marketing_grant:' . (int) $grant->id . ':' . $userId;
        $token   = DistributedLock::lock($lockKey, self::LOCK_TTL);
        if ($token === null) {
            return 'skipped';
        }

        try {
            $log = $existing;
            if ($log === null) {
                $log = new MarketingGrantLog();
                $log->grant_id = (int) $grant->id;
                $log->user_id  = $userId;
                $log->email    = $email;
                $log->status   = MarketingGrantLog::STATUS_PENDING;
                try {
                    $log->save();
                } catch (\Throwable $e) {
                    if ($this->isDuplicateKey($e)) {
                        return 'skipped';
                    }
                    throw $e;
                }
            }

            if ($userId <= 0) {
                $this->markLog($log, MarketingGrantLog::STATUS_SKIPPED, MarketingGrantLog::SKIP_NO_ACCOUNT);
                return 'skipped';
            }

            try {
                $record = (new CouponService())->issue($coupon, $userId, '该用户已达领取上限');
            } catch (BizException $e) {
                $reason = str_contains($e->getMessage(), '上限')
                    ? MarketingGrantLog::SKIP_USER_LIMIT
                    : MarketingGrantLog::SKIP_COUPON_UNAVAILABLE;
                $this->markLog($log, MarketingGrantLog::STATUS_SKIPPED, $reason);
                return 'skipped';
            } catch (\Throwable $e) {
                $this->markLog($log, MarketingGrantLog::STATUS_FAILED, MarketingGrantLog::SKIP_ERROR, mb_substr($e->getMessage(), 0, 200));
                Log::error('marketing grant failed: grant=' . (int) $grant->id . ' user=' . $userId . ' err=' . $e->getMessage());
                return 'failed';
            }

            $log->status         = MarketingGrantLog::STATUS_GRANTED;
            $log->coupon_user_id = (int) $record->id;
            $log->skip_reason    = null;
            $log->error_msg      = null;
            $log->save();

            // 通知失败不影响发券
            try {
                $this->createNotify(MarketingNotifyLog::SCENE_GRANT_ARRIVED, $userId, (int) $record->id, (int) $grant->id);
            } catch (\Throwable $e) {
                Log::error('marketing notify enqueue failed: coupon_user=' . (int) $record->id . ' err=' . $e->getMessage());
            }

            return 'granted';
        } catch (\Throwable $e) {
            Log::error('marketing grant crashed: grant=' . (int) $grant->id . ' user=' . $userId . ' err=' . $e->getMessage());
            return 'failed';
        } finally {
            DistributedLock::unlock($lockKey, $token);
        }
    }

    /**
     * 建通知记录；邮箱为空记 skipped_no_email，邮件服务未开记 failed（可在后台重放）
     *
     * @param string   $scene        场景
     * @param int      $userId       用户
     * @param int      $couponUserId 券实例
     * @param int|null $grantId      批量任务
     * @return MarketingNotifyLog|null null 表示该券该场景已通知过
     */
    private function createNotify(string $scene, int $userId, int $couponUserId, ?int $grantId): ?MarketingNotifyLog
    {
        if ($userId <= 0 || $couponUserId <= 0) {
            return null;
        }

        $user  = User::find($userId);
        $email = trim((string) ($user->email ?? ''));
        if ($email === '') {
            $status = MarketingNotifyLog::STATUS_SKIPPED_NO_EMAIL;
        } elseif (!(bool) site_config('mail.enabled', false)) {
            $status = MarketingNotifyLog::STATUS_FAILED;
        } else {
            $status = MarketingNotifyLog::STATUS_PENDING;
        }

        $log = new MarketingNotifyLog();
        $log->channel        = MarketingNotifyLog::CHANNEL_EMAIL;
        $log->scene          = $scene;
        $log->user_id        = $userId;
        $log->coupon_user_id = $couponUserId;
        $log->grant_id       = $grantId;
        $log->to_email       = $email;
        $log->status         = $status;
        $log->error_msg      = $status === MarketingNotifyLog::STATUS_FAILED ? '邮件服务未启用' : null;
        try {
            $log->save();
        } catch (\Throwable $e) {
            if ($this->isDuplicateKey($e)) {
                return null;
            }
            throw $e;
        }

        if ($status === MarketingNotifyLog::STATUS_PENDING) {
            DelayQueue::delay('marketing_notify', ['id' => (int) $log->id], time());
        }

        return $log;
    }

    /**
     * 人群查询（只取 user.id）
     *
     * @param MarketingGrant $grant 任务
     * @return \think\db\Query
     */
    private function audienceQuery(MarketingGrant $grant)
    {
        $type = (string) $grant->audience_type;
        $aud  = $grant->audience();

        if ($type === MarketingGrant::AUDIENCE_ALL) {
            return (new User())->field('id');
        }

        return (new User())->field('id')->whereIn('id', function ($query) use ($type, $aud) {
            // 用 Query 的 name() 切表，不套 Order 模型：这里要跨商户统计客群，
            // 模型层会自动注入 merchant scope，圈选口径必须与「谁在下单」无关。
            $query->name('order')
                ->field('user_id')
                ->whereIn('pay_id', function ($pay) {
                    $pay->name('order_pay')
                        ->field('id')
                        ->where('pay_status', PayStatus::PAID)
                        ->where('is_test', 0);
                });

            if ($type === MarketingGrant::AUDIENCE_MERCHANT_CUSTOMERS) {
                $query->whereIn('merchant_id', $aud['merchant_ids']);
            }
            if ((int) $aud['days'] > 0) {
                $query->where('create_time', '>=', date('Y-m-d H:i:s', time() - (int) $aud['days'] * 86400));
            }
            if (bccomp((string) $aud['min_amount'], '0', 2) > 0) {
                $query->where('total_amount', '>=', (string) $aud['min_amount']);
            }
        });
    }

    /**
     * 圈选参数归一化
     *
     * @param string $type 人群方式
     * @param mixed  $raw  原始参数
     * @return array
     * @throws BizException
     */
    private function normalizeAudience(string $type, $raw): array
    {
        $raw = is_array($raw) ? $raw : (json_decode((string) $raw, true) ?: []);

        $merchantIds = array_values(array_unique(array_filter(array_map('intval', (array) ($raw['merchant_ids'] ?? [])))));
        if ($type === MarketingGrant::AUDIENCE_MERCHANT_CUSTOMERS && $merchantIds === []) {
            throw new BizException('「指定商户客群」必须选择商户');
        }

        $days = max(0, (int) ($raw['days'] ?? 0));
        $min  = bcadd((string) ($raw['min_amount'] ?? '0'), '0', 2);
        if (bccomp($min, '0', 2) < 0) {
            throw new BizException('金额门槛不能为负数');
        }

        return [
            'days'           => $days,
            'min_amount'     => $min,
            'merchant_ids'   => $type === MarketingGrant::AUDIENCE_MERCHANT_CUSTOMERS ? $merchantIds : [],
            'imported_count' => (int) ($raw['imported_count'] ?? 0),
        ];
    }

    /**
     * 解析导入名单：每行一个邮箱或用户 ID，去重后返回
     *
     * @param string $raw 原始文本（CSV 首列 / 粘贴）
     * @return array<int,array{user_id:int,email:string}>
     * @throws BizException
     */
    private function parseImport(string $raw): array
    {
        $lines = preg_split('/\r\n|\r|\n/', $raw) ?: [];
        $rows  = [];
        $seen  = [];
        foreach ($lines as $line) {
            $value = trim(strtok($line, ',') ?: '');
            $value = trim($value, " \t\"'");
            if ($value === '' || strcasecmp($value, 'email') === 0 || strcasecmp($value, 'user_id') === 0) {
                continue;
            }
            if (ctype_digit($value)) {
                $key = 'id:' . (int) $value;
                if (isset($seen[$key])) {
                    continue;
                }
                $seen[$key] = true;
                $rows[] = ['user_id' => (int) $value, 'email' => ''];
            } elseif (filter_var($value, FILTER_VALIDATE_EMAIL)) {
                $email = strtolower($value);
                if (isset($seen['email:' . $email])) {
                    continue;
                }
                $seen['email:' . $email] = true;
                $rows[] = ['user_id' => 0, 'email' => $email];
            }
        }

        if ($rows === []) {
            throw new BizException('名单里没有可识别的邮箱或用户 ID');
        }
        if (count($rows) > self::MAX_IMPORT_ROWS) {
            throw new BizException('单次导入不能超过 ' . self::MAX_IMPORT_ROWS . ' 条');
        }

        return $rows;
    }

    /**
     * 把导入名单落成每人一条 pending 记录（邮箱/ID 解析成已有账号）
     *
     * 解析不到账号的行保留原始标识（邮箱或数字 ID）并直接记 skipped/no_account：
     * 既让运营看到「哪几行没发出去」，也保证 (grant,user,email) 幂等键对每行唯一。
     *
     * @param int   $grantId 任务 ID
     * @param array $rows    解析后的名单
     * @return void
     */
    private function importTargets(int $grantId, array $rows): void
    {
        $ids    = [];
        $emails = [];
        foreach ($rows as $row) {
            if ((int) $row['user_id'] > 0) {
                $ids[] = (int) $row['user_id'];
            }
            if ((string) $row['email'] !== '') {
                $emails[] = (string) $row['email'];
            }
        }

        $idToEmail = $ids ? User::whereIn('id', array_unique($ids))->column('email', 'id') : [];
        $emailToId = $emails ? User::whereIn('email', array_unique($emails))->column('id', 'email') : [];

        foreach ($rows as $row) {
            $userId = 0;
            $email  = (string) $row['email'];

            if ($email !== '') {
                $userId = (int) ($emailToId[$email] ?? 0);
                if ($userId > 0) {
                    // 统一用账号里的邮箱做快照：按 ID 导入与按邮箱导入要撞同一个幂等键
                    $email = (string) (User::where('id', $userId)->value('email') ?? $email);
                }
            } elseif ((int) $row['user_id'] > 0) {
                $userId = (int) $row['user_id'];
                if (array_key_exists($userId, $idToEmail)) {
                    $email = (string) ($idToEmail[$userId] ?? '');
                } else {
                    // 账号不存在：保留原始 ID 做标识，直接记跳过
                    $userId = 0;
                    $email  = (string) $row['user_id'];
                }
            }

            $log = new MarketingGrantLog();
            $log->grant_id = $grantId;
            $log->user_id  = $userId;
            $log->email    = $email;
            $log->status   = $userId > 0 ? MarketingGrantLog::STATUS_PENDING : MarketingGrantLog::STATUS_SKIPPED;
            $log->skip_reason = $userId > 0 ? null : MarketingGrantLog::SKIP_NO_ACCOUNT;
            try {
                $log->save();
            } catch (\Throwable $e) {
                if (!$this->isDuplicateKey($e)) {
                    throw $e;
                }
            }
        }
    }

    /**
     * 写回发放记录状态
     *
     * @param MarketingGrantLog $log   记录
     * @param string            $status 状态
     * @param string|null       $reason 跳过原因
     * @param string|null       $error  异常信息
     * @return void
     */
    private function markLog(MarketingGrantLog $log, string $status, ?string $reason = null, ?string $error = null): void
    {
        $log->status      = $status;
        $log->skip_reason = $reason;
        $log->error_msg   = $error;
        $log->save();
    }

    /**
     * 组装任务输出
     *
     * @param MarketingGrant $grant      任务
     * @param string         $couponName 券名
     * @return array
     */
    private function formatGrant(MarketingGrant $grant, string $couponName = ''): array
    {
        $total   = (int) $grant->total_target;
        $granted = (int) $grant->granted_qty;
        $done    = $granted + (int) $grant->skipped_qty + (int) $grant->failed_qty;

        return [
            'id'              => (int) $grant->id,
            'name'            => (string) $grant->name,
            'coupon_id'       => (int) $grant->coupon_id,
            'coupon_name'     => $couponName,
            'audience_type'   => (string) $grant->audience_type,
            'audience_label'  => MarketingGrant::AUDIENCE_LABELS[(string) $grant->audience_type] ?? '',
            'audience'        => $grant->audience(),
            'total_target'    => $total,
            'granted_qty'     => $granted,
            'skipped_qty'     => (int) $grant->skipped_qty,
            'failed_qty'      => (int) $grant->failed_qty,
            'processed_qty'   => $done,
            'progress'        => $total > 0 ? min(100, (int) floor($done * 100 / $total)) : 0,
            'status'          => (string) $grant->status,
            'status_label'    => MarketingGrant::STATUS_LABELS[(string) $grant->status] ?? (string) $grant->status,
            'batch_size'      => (int) $grant->batch_size,
            'start_time'      => (string) ($grant->start_time ?? ''),
            'end_time'        => (string) ($grant->end_time ?? ''),
            'remark'          => (string) ($grant->remark ?? ''),
            'editable'        => in_array((string) $grant->status, MarketingGrant::EDITABLE_STATUSES, true),
            'create_time'     => (string) ($grant->create_time ?? ''),
        ];
    }

    /**
     * 通知统计（后台「待重放数量」用）
     *
     * @param int $grantId 任务 ID
     * @return array
     */
    private function notifySummary(int $grantId): array
    {
        $rows = MarketingNotifyLog::where('grant_id', $grantId)->field('status, count(*) as c')->group('status')->select();
        $out  = ['pending' => 0, 'sent' => 0, 'failed' => 0, 'skipped_no_email' => 0, 'replayable' => 0];
        foreach ($rows as $row) {
            $status = (string) $row->status;
            $count  = (int) $row->c;
            if (array_key_exists($status, $out)) {
                $out[$status] = $count;
            }
        }
        $out['replayable'] = (int) MarketingNotifyLog::where('grant_id', $grantId)
            ->whereIn('status', [MarketingNotifyLog::STATUS_FAILED, MarketingNotifyLog::STATUS_PENDING])
            ->where('attempts', '<', self::MAX_NOTIFY_ATTEMPTS)
            ->count();

        return $out;
    }

    /**
     * 批量取券名
     *
     * @param array $couponIds 券 ID
     * @return array<int,string>
     */
    private function couponNames(array $couponIds): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $couponIds))));
        if ($ids === []) {
            return [];
        }
        $out = [];
        foreach (Coupon::whereIn('id', $ids)->column('name', 'id') as $id => $name) {
            $out[(int) $id] = (string) $name;
        }
        return $out;
    }

    /**
     * 邮箱脱敏（后台展示，避免整表导出个人信息）
     *
     * @param string $email 邮箱
     * @return string
     */
    private function maskEmail(string $email): string
    {
        if ($email === '' || !str_contains($email, '@')) {
            return $email;
        }
        [$name, $domain] = explode('@', $email, 2);
        $head = mb_substr($name, 0, 2);
        return $head . str_repeat('*', max(1, mb_strlen($name) - 2)) . '@' . $domain;
    }

    /**
     * 「我的优惠券」链接：只有配置了 site.web_url 才生成，不猜请求域名
     *
     * @return string
     */
    private function couponLink(): string
    {
        $base = rtrim(trim((string) site_config('site.web_url', '')), '/');
        return $base === '' ? '' : $base . '/coupons';
    }

    /**
     * 时间归一化
     *
     * @param mixed $value 时间串
     * @return string|null
     */
    private function normalizeTime($value): ?string
    {
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }
        $ts = strtotime($value);
        return $ts ? date('Y-m-d H:i:s', $ts) : null;
    }

    /**
     * 是否唯一键冲突（并发/重复导入的正常路径，不按异常处理）
     *
     * @param \Throwable $e 异常
     * @return bool
     */
    private function isDuplicateKey(\Throwable $e): bool
    {
        return str_contains($e->getMessage(), 'Duplicate entry')
            || str_contains($e->getMessage(), '1062');
    }

    /**
     * 是否平台超管
     *
     * @return bool
     */
    private function isSuper(): bool
    {
        return AppContext::getAdminRole() === AdminRole::SUPER;
    }

    /**
     * 后台入口统一权限口径：非超管一律「任务不存在」，避免从报错里枚举任务
     *
     * @return void
     * @throws BizException
     */
    private function assertSuper(): void
    {
        if (!$this->isSuper()) {
            throw new BizException('发券任务不存在');
        }
    }
}
