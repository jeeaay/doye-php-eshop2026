<?php

namespace app\common\service;

use app\common\enum\OrderStatus;
use app\common\enum\SettleStatus;
use app\common\exception\BizException;
use app\common\model\Order;
use app\common\model\Settlement;
use app\common\model\SettlementDeduction;
use app\common\model\Withdraw;
use think\facade\Db;

class SettlementService
{
    public function generatePeriodicSettlements(\DateTime $periodEnd): int
    {
        $count = 0;
        $orders = Order::where('status', OrderStatus::SETTLEABLE)
            ->where('settle_status', SettleStatus::UNSETTLED)
            ->whereTime('confirm_at', '<=', $periodEnd->format('Y-m-d H:i:s'))
            ->select();
        $byMerchant = [];
        foreach ($orders as $order) {
            $mid = $order->merchant_id;
            $byMerchant[$mid][] = $order;
        }
        foreach ($byMerchant as $merchantId => $list) {
            $gross = '0.00';
            $n = 0;
            foreach ($list as $order) {
                $gross = bcadd($gross, (string)$order->total_amount, 2);
                $n++;
                $order->settle_status = SettleStatus::SETTLED;
                $order->settle_at = date('Y-m-d H:i:s');
                $order->save();
            }
            $settlement = new Settlement();
            $settlement->merchant_id = $merchantId;
            $settlement->period_start = date('Y-m-d', strtotime('-7 days', $periodEnd->getTimestamp()));
            $settlement->period_end = $periodEnd->format('Y-m-d');
            $settlement->order_count = $n;
            $settlement->gross_amount = $gross;

            // 已结算订单退款留下的待冲减：本期内扣回，扣到 0 为止，不产生负数结算单
            $net = $gross;
            $deducted = '0.00';
            $appliedRows = [];
            $pending = SettlementDeduction::where('merchant_id', $merchantId)
                ->whereNull('settlement_id')
                ->order('id')
                ->select();
            foreach ($pending as $row) {
                $amount = (string) $row->amount;
                if (bccomp($net, $amount, 2) < 0) {
                    break;
                }
                $net = bcsub($net, $amount, 2);
                $deducted = bcadd($deducted, $amount, 2);
                $appliedRows[] = $row;
            }

            $settlement->refund_deduction = $deducted;
            $settlement->net_amount = $net;
            $settlement->status = 0;
            $settlement->save();

            foreach ($appliedRows as $row) {
                $row->settlement_id = (int) $settlement->id;
                $row->save();
            }
            $count++;
        }
        return $count;
    }

    public function applyWithdraw(int $merchantId, int $settlementId, float $amount): Withdraw
    {
        $settlement = Settlement::where('id', $settlementId)->where('merchant_id', $merchantId)->find();
        if (!$settlement) {
            throw new BizException('结算单不存在');
        }
        if (bccomp((string)$amount, (string)$settlement->net_amount, 2) > 0) {
            throw new BizException('提现金额超过可结算金额');
        }
        $w = new Withdraw();
        $w->merchant_id = $merchantId;
        $w->settlement_id = $settlementId;
        $w->amount = $amount;
        $w->status = 0;
        $w->save();
        return $w;
    }

    public function approveWithdraw(int $withdrawId, int $adminId): void
    {
        $w = Withdraw::find($withdrawId);
        if (!$w) {
            throw new BizException('提现申请不存在');
        }
        $w->status = 1;
        $w->save();
    }

    public function rejectWithdraw(int $withdrawId, int $adminId, string $reason): void
    {
        $w = Withdraw::find($withdrawId);
        if (!$w) {
            throw new BizException('提现申请不存在');
        }
        $w->status = 2;
        $w->save();
    }
}
