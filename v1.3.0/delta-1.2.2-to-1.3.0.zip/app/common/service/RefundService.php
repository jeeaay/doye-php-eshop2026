<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\enum\OrderStatus;
use app\common\enum\PayStatus;
use app\common\enum\SettleStatus;
use app\common\exception\BizException;
use app\common\model\Aftersale;
use app\common\model\CouponRestoreLog;
use app\common\model\Order;
use app\common\model\OrderPay;
use app\common\model\RefundLog;
use app\common\model\SettlementDeduction;
use think\facade\Db;
use think\facade\Log;

/**
 * 售后退款执行
 *
 * 唯一出款入口：售后审核 / 确认收货 / 后台重试 都只调 {@see apply()}，页面与 API 共用。
 *
 * 三条不变量（资金安全，改动前先读）：
 * 1. 「退款成功」是订单转已退款、券回收、结算冲减的唯一事实来源——没有 refund_log.success 之前，
 *    订单不得进入已退款态（旧实现直接改状态不出款，是本任务修掉的资损缺口）；
 * 2. 同一售后只有一条退款单（uk_refund_target），单号确定（重试复用），
 *    pending|failed → requesting 用条件更新拿执行权，挡住并发双击；
 * 3. requesting 表示「结果未知」，任何自动重放都可能二次出款，只能人工核对后再决定。
 */
class RefundService
{
    /**
     * 发起（或复用）退款
     *
     * @param int      $aftersaleId 售后单 ID
     * @param int|null $operatorId  触发人（后台账号）
     * @return array{status:string,message:string,refund_id:?int}
     * @throws BizException 通道不支持 / 金额或币种不合法
     */
    public function apply(int $aftersaleId, ?int $operatorId = null): array
    {
        $as = Aftersale::find($aftersaleId);
        if (!$as) {
            throw new BizException('售后单不存在');
        }
        $order = Order::find((int) $as->order_id);
        if (!$order) {
            throw new BizException('订单不存在');
        }
        $pay = OrderPay::find((int) $order->pay_id);
        if (!$pay) {
            throw new BizException('支付单不存在');
        }

        // 已成功/结果未知的退款单先返回现状：此时支付单早已不是 PAID，不能再走通道守卫
        $existing = RefundLog::where('order_pay_id', (int) $pay->id)
            ->where('aftersale_id', (int) $as->id)
            ->find();
        if ($existing) {
            $status = (string) $existing->status;
            if ($status === RefundLog::STATUS_SUCCESS) {
                return $this->result($existing, '该售后已退款成功');
            }
            if ($status === RefundLog::STATUS_REQUESTING) {
                return $this->result($existing, '退款结果待确认，请勿重复操作（可到微信商户后台核对）');
            }
        }

        $this->assertSupported($pay);

        $total = (int) bcmul((string) $pay->total_amount, '100', 0);
        $cents = (int) bcmul((string) $as->refund_amount, '100', 0);
        if ($cents <= 0 || $cents > $total) {
            throw new BizException('退款金额无效');
        }

        $refund = $this->createRecord($as, $order, $pay, $cents, $operatorId);

        return $this->execute($refund, $pay, $operatorId);
    }

    /**
     * 通道与币种守卫：在建退款单之前拦，避免留下永远失败的记录
     *
     * @param OrderPay $pay 支付单
     * @return void
     * @throws BizException
     */
    public function assertSupported(OrderPay $pay): void
    {
        $channel = (string) ($pay->channel ?? '');
        if ($channel !== 'wechat') {
            throw new BizException('该支付通道暂不支持后台自动退款，请到渠道后台操作；该路径不会触发自动返券');
        }
        $currency = strtoupper(trim((string) ($pay->charge_currency ?? '')) ?: 'CNY');
        if ($currency !== 'CNY') {
            throw new BizException('该支付单收款币种为 ' . $currency . '，微信退款仅支持 CNY，请到渠道后台操作');
        }
        if ((int) $pay->pay_status !== PayStatus::PAID) {
            throw new BizException('支付单不是已支付状态，不能退款');
        }
    }

    /**
     * 标记通道结果（成功路径也供「通道查询确认成功」复用）
     *
     * @param int    $refundId refund_log.id
     * @param string $status   success / failed
     * @param array  $payload  通道返回体（取 refund_id）或 ['error'=>'...']
     * @return array{status:string,message:string,refund_id:?int}
     */
    public function markResult(int $refundId, string $status, array $payload = []): array
    {
        $refund = RefundLog::find($refundId);
        if (!$refund) {
            return ['status' => RefundLog::STATUS_FAILED, 'message' => '退款单不存在', 'refund_id' => null];
        }

        if ($status === RefundLog::STATUS_SUCCESS) {
            return $this->finishSuccess($refund, $payload);
        }

        $refund->status      = RefundLog::STATUS_FAILED;
        $refund->error_msg   = mb_substr((string) ($payload['error'] ?? '通道返回失败'), 0, 200);
        $refund->finished_at = date('Y-m-d H:i:s');
        $refund->save();

        return $this->result($refund, '退款失败：' . $refund->error_msg);
    }

    /**
     * 建/复用退款单：唯一键兜住重复，success 与 requesting 都直接返回现状
     *
     * @param Aftersale $as         售后单
     * @param Order     $order      订单
     * @param OrderPay  $pay        支付单
     * @param int       $cents      退款金额（分）
     * @param int|null  $operatorId 操作人
     * @return RefundLog
     */
    private function createRecord(Aftersale $as, Order $order, OrderPay $pay, int $cents, ?int $operatorId): RefundLog
    {
        $existing = RefundLog::where('order_pay_id', (int) $pay->id)
            ->where('aftersale_id', (int) $as->id)
            ->find();
        if ($existing) {
            return $existing;
        }

        $refund = new RefundLog();
        $refund->refund_no       = 'R' . (int) $pay->id . 'A' . (int) $as->id;
        $refund->order_pay_id    = (int) $pay->id;
        $refund->order_id        = (int) $order->id;
        $refund->aftersale_id    = (int) $as->id;
        $refund->channel         = 'wechat';
        $refund->amount_minor    = $cents;
        $refund->charge_currency = strtoupper((string) ($pay->charge_currency ?? '')) ?: 'CNY';
        $refund->status          = RefundLog::STATUS_PENDING;
        $refund->operator_id     = $operatorId;
        try {
            $refund->save();
        } catch (\Throwable $e) {
            if (!$this->isDuplicateKey($e)) {
                throw $e;
            }
            $refund = RefundLog::where('order_pay_id', (int) $pay->id)
                ->where('aftersale_id', (int) $as->id)
                ->find();
            if (!$refund) {
                throw new BizException('退款单创建失败，请重试');
            }
        }

        return $refund;
    }

    /**
     * 拿执行权并调通道
     *
     * @param RefundLog $refund     退款单
     * @param OrderPay  $pay        支付单
     * @param int|null  $operatorId 操作人
     * @return array{status:string,message:string,refund_id:?int}
     */
    private function execute(RefundLog $refund, OrderPay $pay, ?int $operatorId): array
    {
        $now = date('Y-m-d H:i:s');
        $acquired = RefundLog::where('id', (int) $refund->id)
            ->whereIn('status', [RefundLog::STATUS_PENDING, RefundLog::STATUS_FAILED])
            ->update([
                'status'       => RefundLog::STATUS_REQUESTING,
                'requested_at' => $refund->requested_at ?: $now,
                'error_msg'    => null,
                'operator_id'  => $operatorId ?: $refund->operator_id,
            ]);

        if (!$acquired) {
            $fresh = RefundLog::find((int) $refund->id);
            return $this->result($fresh, $fresh && (string) $fresh->status === RefundLog::STATUS_REQUESTING
                ? '退款请求处理中，请勿重复操作'
                : '该售后已退款');
        }

        $refund = RefundLog::find((int) $refund->id);
        $reason = '售后 ' . (string) $refund->refund_no;

        try {
            $response = (new PaymentService())->refund((int) $pay->id, (int) $refund->amount_minor, $reason, (string) $refund->refund_no);
        } catch (BizException $e) {
            if (str_contains($e->getMessage(), '支付网关连接失败')) {
                // 超时/连接异常：请求可能已经到达通道，宁可停在 requesting 等人核对
                Log::error('refund unknown result: refund=' . (int) $refund->id . ' err=' . $e->getMessage());
                return $this->result(RefundLog::find((int) $refund->id), '退款结果未知（网关连接异常），请到微信商户后台核对后再决定是否重试');
            }
            return $this->markResult((int) $refund->id, RefundLog::STATUS_FAILED, ['error' => $e->getMessage()]);
        } catch (\Throwable $e) {
            Log::error('refund unknown result: refund=' . (int) $refund->id . ' err=' . $e->getMessage());
            return $this->result(RefundLog::find((int) $refund->id), '退款结果未知，请到微信商户后台核对后再决定是否重试');
        }

        $status = strtoupper((string) ($response['status'] ?? ''));
        if ($status === 'SUCCESS') {
            return $this->markResult((int) $refund->id, RefundLog::STATUS_SUCCESS, $response);
        }
        if ($status === 'PROCESSING' || $status === '') {
            return $this->result(RefundLog::find((int) $refund->id), '退款已受理，结果待确认（通道处理中）');
        }

        return $this->markResult((int) $refund->id, RefundLog::STATUS_FAILED, [
            'error' => '通道返回 ' . $status . (!empty($response['reason']) ? '：' . $response['reason'] : ''),
        ]);
    }

    /**
     * 退款成功：先落事实（事务内回写订单/支付单），再做副作用（事务外，失败不回滚退款）
     *
     * @param RefundLog $refund  退款单
     * @param array     $payload 通道返回体
     * @return array{status:string,message:string,refund_id:?int}
     */
    private function finishSuccess(RefundLog $refund, array $payload): array
    {
        $order = Order::find((int) $refund->order_id);
        if (!$order) {
            return $this->result($refund, '退款成功但订单不存在，请人工核对');
        }

        Db::startTrans();
        try {
            $refund->status      = RefundLog::STATUS_SUCCESS;
            $refund->refund_id   = (string) ($payload['refund_id'] ?? '') ?: null;
            $refund->error_msg   = null;
            $refund->finished_at = date('Y-m-d H:i:s');
            $refund->save();

            $order->status = OrderStatus::REFUNDED;
            $order->save();

            $pay = OrderPay::find((int) $refund->order_pay_id);
            if ($pay) {
                $pay->pay_status = PayStatus::REFUNDED;
                $pay->save();
            }

            Db::commit();
        } catch (\Throwable $e) {
            Db::rollback();
            throw $e;
        }

        $this->applyEffects($refund, $order);

        return $this->result($refund, '退款成功');
    }

    /**
     * 退款成功后的副作用：奖励券回收与结算冲减
     *
     * 每项独立 try/catch：任何副作用失败都不能把已发生的退款事实回滚。
     * 「本单花掉的券退回」由 11-16-coupon-refund-restore 在同一出口接线。
     *
     * @param RefundLog $refund 退款单
     * @param Order     $order  订单
     * @return void
     */
    private function applyEffects(RefundLog $refund, Order $order): void
    {
        try {
            (new MarketingService())->revokeByOrderPay((int) $refund->order_pay_id);
        } catch (\Throwable $e) {
            Log::error('refund effect revoke failed: refund=' . (int) $refund->id . ' err=' . $e->getMessage());
        }

        // 先回收「这单挣到的」，再退回「这单花掉的」：两者针对不同券行，互不覆盖
        try {
            $notifier = new MarketingGrantService();
            $restore  = (new CouponService())->restoreByOrderPay((int) $refund->order_pay_id);
            foreach ($restore['items'] as $item) {
                if (($item['status'] ?? '') === CouponRestoreLog::STATUS_RESTORED) {
                    $notifier->notifyCouponRestored((int) $item['coupon_user_id']);
                }
            }
        } catch (\Throwable $e) {
            Log::error('refund effect restore failed: refund=' . (int) $refund->id . ' err=' . $e->getMessage());
        }

        try {
            $this->recordSettlementDeduction($refund, $order);
        } catch (\Throwable $e) {
            Log::error('refund effect deduction failed: refund=' . (int) $refund->id . ' err=' . $e->getMessage());
        }
    }

    /**
     * 已结算订单：写一条待冲减明细，下一期结算扣回
     *
     * 未结算订单退款后状态已是 REFUNDED，不会再进入结算口径，无需冲减。
     *
     * @param RefundLog $refund 退款单
     * @param Order     $order  订单
     * @return void
     */
    private function recordSettlementDeduction(RefundLog $refund, Order $order): void
    {
        if ((int) $order->settle_status !== SettleStatus::SETTLED) {
            return;
        }

        $exists = SettlementDeduction::where('refund_id', (int) $refund->id)->find();
        if ($exists) {
            return;
        }

        $row = new SettlementDeduction();
        $row->merchant_id  = (int) $order->merchant_id;
        $row->order_id     = (int) $order->id;
        $row->refund_id    = (int) $refund->id;
        $row->amount       = bcdiv((string) $refund->amount_minor, '100', 2);
        $row->settlement_id = null;
        $row->save();
    }

    /**
     * 组装返回
     *
     * @param RefundLog|null $refund  退款单
     * @param string         $message 提示
     * @return array{status:string,message:string,refund_id:?int}
     */
    private function result(?RefundLog $refund, string $message): array
    {
        return [
            'status'    => $refund ? (string) $refund->status : RefundLog::STATUS_FAILED,
            'message'   => $message,
            'refund_id' => $refund ? (int) $refund->id : null,
        ];
    }

    /**
     * 唯一键冲突
     *
     * @param \Throwable $e 异常
     * @return bool
     */
    private function isDuplicateKey(\Throwable $e): bool
    {
        return str_contains($e->getMessage(), 'Duplicate entry') || str_contains($e->getMessage(), '1062');
    }
}
