<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 事务性通知记录（券到账 / 到期提醒 / 券退回）
 *
 * uk_notify (scene, coupon_user_id) 保证同一张券的同一场景只通知一次：
 * 批量任务重复执行、提醒命令每天跑、退款重复通知，都不会重复发信。
 * 发送本身在 DelayQueue 里异步完成，SMTP 往返不阻塞主流程。
 */
class MarketingNotifyLog extends BaseModel
{
    protected $name = 'marketing_notify_log';

    protected $autoWriteTimestamp = 'datetime';

    /** 邮件渠道（短信/微信留作扩展） */
    public const CHANNEL_EMAIL = 'email';

    /** 券到账 */
    public const SCENE_GRANT_ARRIVED = 'grant_arrived';

    /** 到期前提醒 */
    public const SCENE_EXPIRING_SOON = 'expiring_soon';

    /** 全额退款后券退回（由返券任务写入） */
    public const SCENE_COUPON_RESTORED = 'coupon_restored';

    /** 待发送 */
    public const STATUS_PENDING = 'pending';

    /** 已发送 */
    public const STATUS_SENT = 'sent';

    /** 用户没有邮箱，跳过 */
    public const STATUS_SKIPPED_NO_EMAIL = 'skipped_no_email';

    /** 发送失败（邮件服务未开或 SMTP 异常），可重放 */
    public const STATUS_FAILED = 'failed';

    /** 场景 => 展示名 */
    public const SCENE_LABELS = [
        self::SCENE_GRANT_ARRIVED   => '券到账提醒',
        self::SCENE_EXPIRING_SOON   => '到期提醒',
        self::SCENE_COUPON_RESTORED => '券退回提醒',
    ];

    /** 状态 => 展示名 */
    public const STATUS_LABELS = [
        self::STATUS_PENDING           => '待发送',
        self::STATUS_SENT              => '已发送',
        self::STATUS_SKIPPED_NO_EMAIL  => '无邮箱跳过',
        self::STATUS_FAILED            => '发送失败',
    ];

    /**
     * 对应的券实例
     *
     * @return \think\model\relation\BelongsTo
     */
    public function couponUser()
    {
        return $this->belongsTo(CouponUser::class, 'coupon_user_id');
    }
}
