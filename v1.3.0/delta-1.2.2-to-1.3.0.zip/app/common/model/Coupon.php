<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 优惠券 / 优惠活动模型
 *
 * 一张表同时装平台行与商户行，故仍继承 BaseModel、不改 MerchantModel：
 * merchant_id IS NULL 在自动注入下语义不明，且商户写操作可能圈进平台行，
 * 读写范围一律在 CouponService 里显式收敛（scopedCoupon()）。
 * apply_type：auto 全站自动生效 / claim 前台领取 / code 凭码使用。
 */
class Coupon extends BaseModel
{
    protected $name = 'coupon';

    protected $autoWriteTimestamp = 'datetime';

    /** 全站自动生效（如圣诞全站 9 折） */
    public const APPLY_AUTO = 'auto';

    /** 前台领取后使用（如首次进入领取 5 美元无门槛券） */
    public const APPLY_CLAIM = 'claim';

    /** 凭优惠码使用 */
    public const APPLY_CODE = 'code';

    /** 百分比折扣 */
    public const TYPE_PERCENT = 'percent';

    /** 固定金额减免（满减券即 min_amount > 0 的固定金额券） */
    public const TYPE_FIXED = 'fixed';

    /** 作用范围：全站 */
    public const SCOPE_ALL = 'all';

    /** 作用范围：指定商品 */
    public const SCOPE_PRODUCT = 'product';

    /** 层级：商家折扣（商家在自己的后台配置） */
    public const TIER_MERCHANT = 10;

    /** 层级：平台活动（全站自动生效，不落用户券记录） */
    public const TIER_PLATFORM = 20;

    /** 层级：系统自动发放的券（新人奖励、确认收货返利），到账即自动抵扣 */
    public const TIER_AUTO_GRANT = 30;

    /** 层级：用户手动选择的券或优惠码 */
    public const TIER_MANUAL = 40;

    /** 层级 => 展示名，顺序即结算时的计算顺序 */
    public const TIER_LABELS = [
        self::TIER_MERCHANT   => '商家折扣',
        self::TIER_PLATFORM   => '平台活动',
        self::TIER_AUTO_GRANT => '自动到账券',
        self::TIER_MANUAL     => '优惠券/优惠码',
    ];

    /**
     * 各层级允许的生效方式：层级决定「怎么算」，apply_type 决定「怎么到用户手里」
     */
    public const TIER_APPLY_TYPES = [
        self::TIER_MERCHANT   => [self::APPLY_AUTO],
        self::TIER_PLATFORM   => [self::APPLY_AUTO],
        self::TIER_AUTO_GRANT => [self::APPLY_CLAIM],
        self::TIER_MANUAL     => [self::APPLY_CLAIM, self::APPLY_CODE],
    ];

    /**
     * 适用范围商品（scope=product）
     *
     * @return \think\model\relation\HasMany
     */
    public function products()
    {
        return $this->hasMany(CouponProduct::class, 'coupon_id');
    }

    /**
     * 领取/核销记录
     *
     * @return \think\model\relation\HasMany
     */
    public function records()
    {
        return $this->hasMany(CouponUser::class, 'coupon_id');
    }
}
