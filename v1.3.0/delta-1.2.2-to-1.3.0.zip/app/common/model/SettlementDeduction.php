<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 已结算订单退款的待冲减明细
 *
 * 退款事实在 refund_log；这里只解决「钱已经给过商家，怎么从后续结算扣回来」：
 * settlement_id 为空表示待冲减，结算生成时并入某一期并回填，uk_refund 防止重复冲减。
 */
class SettlementDeduction extends BaseModel
{
    protected $name = 'settlement_deduction';

    protected $updateTime = false;
}
