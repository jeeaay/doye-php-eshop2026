<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 用户优惠券记录模型（领取 / 核销凭据）
 *
 * 平台级数据，继承 BaseModel。status：0 未使用 / 1 已使用 / 2 已过期 / 3 已回收（奖励券随订单退款作废）。
 */
class CouponUser extends BaseModel
{
    protected $name = 'coupon_user';

    protected $autoWriteTimestamp = 'datetime';

    public const STATUS_UNUSED = 0;
    public const STATUS_USED = 1;
    public const STATUS_EXPIRED = 2;
    public const STATUS_REVOKED = 3;

    /**
     * 所属优惠
     *
     * @return \think\model\relation\BelongsTo
     */
    public function coupon()
    {
        return $this->belongsTo(Coupon::class, 'coupon_id');
    }
}
