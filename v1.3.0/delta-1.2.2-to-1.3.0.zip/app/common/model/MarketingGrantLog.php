<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 批量发券：每人一条发放记录
 *
 * 一份记录承担两件事：uk_grant_user 是重复点击执行 / 进程重启 / 补跑时的幂等凭据；
 * skip_reason 说明这个人为什么没拿到券（重复导入、超出每人限额、名单里没有账号等）。
 */
class MarketingGrantLog extends BaseModel
{
    protected $name = 'marketing_grant_log';

    protected $autoWriteTimestamp = 'datetime';

    /** 待发放（导入型人群在保存时就落 pending 行） */
    public const STATUS_PENDING = 'pending';

    /** 券已到账 */
    public const STATUS_GRANTED = 'granted';

    /** 跳过，不会补发 */
    public const STATUS_SKIPPED = 'skipped';

    /** 发放异常，可重跑 */
    public const STATUS_FAILED = 'failed';

    /** 该任务已处理过这个人 */
    public const SKIP_ALREADY_GRANTED = 'already_granted';

    /** 券模板的每人限额已满 */
    public const SKIP_USER_LIMIT = 'user_limit_exceeded';

    /** 导入名单里的邮箱没有对应账号 */
    public const SKIP_NO_ACCOUNT = 'no_account';

    /** 券模板不可用（已停用或已被领完） */
    public const SKIP_COUPON_UNAVAILABLE = 'coupon_unavailable';

    /** 任务不在可发放时间窗内（或已取消） */
    public const SKIP_NOT_IN_WINDOW = 'not_in_window';

    /** 发放过程异常 */
    public const SKIP_ERROR = 'error';

    /** 状态 => 展示名 */
    public const STATUS_LABELS = [
        self::STATUS_PENDING => '待发放',
        self::STATUS_GRANTED => '已到账',
        self::STATUS_SKIPPED => '已跳过',
        self::STATUS_FAILED  => '发放失败',
    ];

    /** 跳过原因 => 展示名 */
    public const SKIP_LABELS = [
        self::SKIP_ALREADY_GRANTED => '该任务已发放过',
        self::SKIP_USER_LIMIT      => '已达每人限领次数',
        self::SKIP_NO_ACCOUNT      => '名单邮箱无对应账号',
        self::SKIP_COUPON_UNAVAILABLE => '券模板不可用',
        self::SKIP_NOT_IN_WINDOW   => '不在可发放时间窗',
        self::SKIP_ERROR           => '发放异常（可重跑）',
    ];

    /**
     * 所属任务
     *
     * @return \think\model\relation\BelongsTo
     */
    public function grant()
    {
        return $this->belongsTo(MarketingGrant::class, 'grant_id');
    }

    /**
     * 目标用户
     *
     * @return \think\model\relation\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
