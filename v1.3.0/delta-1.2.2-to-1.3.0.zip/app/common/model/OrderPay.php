<?php
declare (strict_types = 1);

namespace app\common\model;

class OrderPay extends BaseModel
{
    protected $name = 'order_pay';
    protected $autoWriteTimestamp = 'datetime';
    protected $updateTime = false;
    protected $json = ['discount_lines_json'];
    protected $jsonAssoc = true;

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function orders()
    {
        return $this->hasMany(Order::class, 'pay_id');
    }
}
