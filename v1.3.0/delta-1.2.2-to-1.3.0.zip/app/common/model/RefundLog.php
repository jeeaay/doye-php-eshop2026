<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 售后退款记录
 *
 * 一条记录 = 一次售后的全部退款事实：确定性单号、金额快照、通道结果与失败原因。
 * uk_refund_target(order_pay_id, aftersale_id) 是「同一售后只出款一次」的唯一凭据；
 * requesting 表示请求已发出但结果未知，任何自动重放都可能造成二次出款。
 */
class RefundLog extends BaseModel
{
    protected $name = 'refund_log';

    protected $autoWriteTimestamp = 'datetime';

    /** 已建单，尚未发起 */
    public const STATUS_PENDING = 'pending';

    /** 已发起，等待通道结果（结果未知时停留在此，人工介入） */
    public const STATUS_REQUESTING = 'requesting';

    /** 通道已确认退款成功 */
    public const STATUS_SUCCESS = 'success';

    /** 通道明确返回失败（可重试，复用同一单号） */
    public const STATUS_FAILED = 'failed';

    /** 状态 => 展示名 */
    public const STATUS_LABELS = [
        self::STATUS_PENDING    => '待发起',
        self::STATUS_REQUESTING => '结果待确认',
        self::STATUS_SUCCESS    => '退款成功',
        self::STATUS_FAILED     => '退款失败',
    ];

    /**
     * 关联售后单
     *
     * @return \think\model\relation\BelongsTo
     */
    public function aftersale()
    {
        return $this->belongsTo(Aftersale::class, 'aftersale_id');
    }
}
