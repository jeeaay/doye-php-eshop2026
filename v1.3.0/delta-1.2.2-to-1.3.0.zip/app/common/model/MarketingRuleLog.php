<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 营销规则发放记录模型
 *
 * 一份记录同时承担三件事：幂等凭据（uk_grant: rule_id + user_id + scope_key）、
 * 奖励金额快照（规则改了不重算）、发放失败后的补偿入口（status=pending）。
 * 平台级数据，继承 BaseModel。
 */
class MarketingRuleLog extends BaseModel
{
    protected $name = 'marketing_rule_log';

    protected $autoWriteTimestamp = 'datetime';

    /** 待发放 / 发放失败，由 php think marketing:grant 重扫 */
    public const STATUS_PENDING = 'pending';

    /** 券已到账 */
    public const STATUS_GRANTED = 'granted';

    /** 条件不满足或预算耗尽，未发券 */
    public const STATUS_SKIPPED = 'skipped';

    /** 订单全额退款后回收 */
    public const STATUS_REVOKED = 'revoked';

    /** 规则级发放总量已达上限 */
    public const SKIP_BUDGET_EXHAUSTED = 'budget_exhausted';

    /** 每人可获得次数已达上限 */
    public const SKIP_USER_LIMIT = 'user_limit_exceeded';

    /** 条件不匹配（金额门槛、新老用户、指定范围） */
    public const SKIP_NOT_ELIGIBLE = 'not_eligible';

    /** 幂等键已被占用：重复通知或并发触发 */
    public const SKIP_ALREADY_GRANTED = 'already_granted';

    /** 发放过程异常 */
    public const SKIP_ERROR = 'error';

    /** 回收时券已核销，不追回 */
    public const SKIP_COUPON_ALREADY_USED = 'coupon_already_used';

    /** 待发放的记录遇上订单全额退款：就地结案，不让补偿命令在退款后把券发出去 */
    public const SKIP_ORDER_REFUNDED = 'order_refunded';

    /** 发放状态 => 展示名 */
    public const STATUS_LABELS = [
        self::STATUS_PENDING => '待发放',
        self::STATUS_GRANTED => '已到账',
        self::STATUS_SKIPPED => '已跳过',
        self::STATUS_REVOKED => '已回收',
    ];

    /**
     * 跳过 / 回收原因 => 展示名
     *
     * 文案是给运营看的口径说明，不改判定逻辑：skip_reason 的取值仍由本模型常量决定。
     */
    public const SKIP_LABELS = [
        self::SKIP_BUDGET_EXHAUSTED    => '规则预算已发完',
        self::SKIP_USER_LIMIT          => '已达每人限得次数',
        self::SKIP_NOT_ELIGIBLE        => '不满足触发条件',
        self::SKIP_ALREADY_GRANTED     => '该对象已发放过',
        self::SKIP_ERROR               => '发放异常（待补偿重放）',
        self::SKIP_COUPON_ALREADY_USED => '券已使用，无法回收',
        self::SKIP_ORDER_REFUNDED      => '订单已退款',
    ];

    /**
     * 关联规则
     *
     * @return \think\model\relation\BelongsTo
     */
    public function rule()
    {
        return $this->belongsTo(MarketingRule::class, 'rule_id');
    }

    /**
     * 关联用户
     *
     * @return \think\model\relation\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
