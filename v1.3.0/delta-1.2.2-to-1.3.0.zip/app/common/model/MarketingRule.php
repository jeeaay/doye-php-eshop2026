<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 营销规则模型（拉新奖励 / 确认收货返利）
 *
 * 平台级数据，继承 BaseModel（不走 MerchantScope，见父任务 design §6）。
 * 金额列（reward_value / reward_cap）一律存基准币种：国内版 CNY、国际版 USD，不做换算。
 */
class MarketingRule extends BaseModel
{
    protected $name = 'marketing_rule';

    protected $autoWriteTimestamp = 'datetime';

    protected $json = ['condition_json', 'inline_coupon_json'];

    protected $jsonAssoc = true;

    /** 新人注册礼：建号即发券，拉首单转化 */
    public const TYPE_REGISTER_GIFT = 'new_user_register_gift';

    /** 新人首单奖励：第一笔支付成功后发券，拉长回购 */
    public const TYPE_ORDER_GIFT = 'new_user_order_gift';

    /** 确认收货返利：基数为该单实付金额 */
    public const TYPE_CONFIRM_REBATE = 'order_confirm_rebate';

    /** 注册成功 */
    public const TRIGGER_REGISTER = 'register_success';

    /** 支付成功 */
    public const TRIGGER_PAY = 'pay_success';

    /** 确认收货（手动与自动同一条路径） */
    public const TRIGGER_CONFIRM = 'confirm_receipt';

    /** 固定金额奖励 */
    public const REWARD_FIXED = 'fixed';

    /** 按比例奖励（基数为该事件对应的实付金额） */
    public const REWARD_PERCENT = 'percent';

    /** 规则类型 => 展示名 */
    public const TYPE_LABELS = [
        self::TYPE_REGISTER_GIFT => '新人注册礼',
        self::TYPE_ORDER_GIFT    => '新人首单奖励',
        self::TYPE_CONFIRM_REBATE => '确认收货返利',
    ];

    /**
     * 各类型允许的触发事件：类型决定「奖励谁」，触发事件决定「什么时候到账」，
     * 非法组合会让预算被莫名其妙的事件吃掉，所以在保存时就要拒绝。
     */
    public const TYPE_TRIGGERS = [
        self::TYPE_REGISTER_GIFT  => [self::TRIGGER_REGISTER],
        self::TYPE_ORDER_GIFT     => [self::TRIGGER_PAY],
        self::TYPE_CONFIRM_REBATE => [self::TRIGGER_CONFIRM],
    ];

    /** 奖励方式 => 展示名 */
    public const REWARD_LABELS = [
        self::REWARD_FIXED   => '固定金额',
        self::REWARD_PERCENT => '按比例',
    ];

    /** 触发事件 => 展示名 */
    public const TRIGGER_LABELS = [
        self::TRIGGER_REGISTER => '注册成功',
        self::TRIGGER_PAY      => '支付成功',
        self::TRIGGER_CONFIRM  => '确认收货',
    ];

    /**
     * 关联的奖励券模板
     *
     * @return \think\model\relation\BelongsTo
     */
    public function coupon()
    {
        return $this->belongsTo(Coupon::class, 'coupon_id');
    }

    /**
     * 条件字段，缺失时补默认值，调用方不必再判 null
     *
     * 「是否仅限新用户」按类型给默认值：首单礼默认只发新人，返利与注册礼默认不限，
     * 否则运营漏填就会把老用户的返利一起关掉。
     *
     * @return array
     */
    public function conditions(): array
    {
        return array_merge([
            'min_order_amount' => '0.00',
            'merchant_ids'     => [],
            'category_ids'     => [],
            'product_ids'      => [],
            'new_user_only'    => $this->type === self::TYPE_ORDER_GIFT,
        ], is_array($this->condition_json) ? $this->condition_json : []);
    }

    /**
     * 内联券定义，缺失时补默认值
     *
     * 只描述「券长什么样、能用多久」；面额由规则算出来的奖励金额决定，
     * 所以这里没有 discount_value —— 同一个比例型规则会给不同用户发不同面额的券。
     * 层级也不在这里配：内联生成的券一律落在自动到账层（tier=30），
     * 要发「用户手动选用」的券就在优惠管理建好后用 coupon_id 引用（理由见 MarketingService::resolveTemplate()）。
     *
     * @return array
     */
    public function inlineCoupon(): array
    {
        return array_merge([
            'name'       => (string) $this->name,
            'min_amount' => '0.00',
            'valid_days' => 30,
            'expire_at'  => null,
        ], is_array($this->inline_coupon_json) ? $this->inline_coupon_json : []);
    }
}
