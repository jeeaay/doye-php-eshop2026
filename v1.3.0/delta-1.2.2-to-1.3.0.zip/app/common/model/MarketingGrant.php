<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 批量发券任务
 *
 * 平台级数据，继承 BaseModel：批量发券是平台超管能力，不注入商户 scope。
 * 任务本身只记录「圈谁、发哪张券、发到哪了」；重复执行与进程重启的幂等靠
 * marketing_grant_log 的 uk_grant_user，券的发放仍由 CouponService::issue() 完成。
 */
class MarketingGrant extends BaseModel
{
    protected $name = 'marketing_grant';

    protected $autoWriteTimestamp = 'datetime';

    protected $json = ['audience_json'];

    protected $jsonAssoc = true;

    /** 全站注册用户 */
    public const AUDIENCE_ALL = 'all';

    /** 有过已支付订单的用户（可选时间窗与金额门槛） */
    public const AUDIENCE_PURCHASED = 'purchased';

    /** 指定商户下过单的用户（merchant_ids 必填） */
    public const AUDIENCE_MERCHANT_CUSTOMERS = 'merchant_customers';

    /** 名单导入（CSV / 粘贴，邮箱或用户 ID） */
    public const AUDIENCE_IMPORT = 'import';

    /** 待执行 */
    public const STATUS_PENDING = 'pending';

    /** 执行中（可能暂停在某一批之间） */
    public const STATUS_RUNNING = 'running';

    /** 运营暂停 */
    public const STATUS_PAUSED = 'paused';

    /** 发完 */
    public const STATUS_DONE = 'done';

    /** 运营取消（已发出的券不受影响） */
    public const STATUS_CANCELED = 'canceled';

    /** 人群方式 => 展示名 */
    public const AUDIENCE_LABELS = [
        self::AUDIENCE_ALL                => '全站用户',
        self::AUDIENCE_PURCHASED          => '已购买用户',
        self::AUDIENCE_MERCHANT_CUSTOMERS => '指定商户客群',
        self::AUDIENCE_IMPORT             => '名单导入',
    ];

    /** 状态 => 展示名 */
    public const STATUS_LABELS = [
        self::STATUS_PENDING  => '待执行',
        self::STATUS_RUNNING  => '执行中',
        self::STATUS_PAUSED   => '已暂停',
        self::STATUS_DONE     => '已完成',
        self::STATUS_CANCELED => '已取消',
    ];

    /** 只有这两个状态允许改配置 / 删除 */
    public const EDITABLE_STATUSES = [self::STATUS_PENDING, self::STATUS_PAUSED];

    /**
     * 发放的券模板
     *
     * @return \think\model\relation\BelongsTo
     */
    public function coupon()
    {
        return $this->belongsTo(Coupon::class, 'coupon_id');
    }

    /**
     * 每人发放记录
     *
     * @return \think\model\relation\HasMany
     */
    public function logs()
    {
        return $this->hasMany(MarketingGrantLog::class, 'grant_id');
    }

    /**
     * 圈选参数，缺失时补默认值
     *
     * @return array{days:int,min_amount:string,merchant_ids:array<int,int>,imported_count:int}
     */
    public function audience(): array
    {
        return array_merge([
            'days'           => 0,
            'min_amount'     => '0.00',
            'merchant_ids'   => [],
            'imported_count' => 0,
        ], is_array($this->audience_json) ? $this->audience_json : []);
    }
}
