<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 退款返券记录（这单花掉的券退回去了）
 *
 * 与 MarketingRuleLog（这单挣到的券被回收）语义相反，分表存放；
 * uk_restore(order_pay_id, coupon_user_id) 是「同一笔退款只退一次」的幂等凭据。
 */
class CouponRestoreLog extends BaseModel
{
    protected $name = 'coupon_restore_log';

    protected $autoWriteTimestamp = 'datetime';

    /** 已退回未使用 */
    public const STATUS_RESTORED = 'restored';

    /** 券已过期，不退 */
    public const STATUS_SKIPPED_EXPIRED = 'skipped_expired';

    /** 券状态已被其他流程改动（并发），不重试 */
    public const STATUS_SKIPPED_USED_AGAIN = 'skipped_used_again';

    /** 退回过程异常 */
    public const STATUS_FAILED = 'failed';

    /** 状态 => 展示名 */
    public const STATUS_LABELS = [
        self::STATUS_RESTORED          => '已退回',
        self::STATUS_SKIPPED_EXPIRED   => '已过期未退',
        self::STATUS_SKIPPED_USED_AGAIN => '状态已变更',
        self::STATUS_FAILED            => '退回失败',
    ];
}
