<?php
declare(strict_types=1);

namespace app\common\command;

use app\common\service\MarketingService;
use think\console\Command;
use think\console\Input;
use think\console\input\Option;
use think\console\Output;

/**
 * 营销发放补偿命令
 *
 * 发放动作挂在支付回调、确认收货、注册这些主流程之外，失败只落 marketing_rule_log（status=pending），
 * 由本命令重放。建议放进 crontab（每 5 分钟一次），没有 pending 时它什么都不做。
 *
 * 用法：
 *   php think marketing:grant                 重放待发放记录（默认单次 100 条）
 *   php think marketing:grant --limit=500     指定单次处理条数
 *   php think marketing:grant --list          只看待发放记录，不重放
 */
class MarketingGrant extends Command
{
    /**
     * 配置命令
     *
     * @return void
     */
    protected function configure(): void
    {
        $this->setName('marketing:grant')
            ->addOption('limit', null, Option::VALUE_REQUIRED, '单次最多重放条数，默认 100', 100)
            ->addOption('list', null, Option::VALUE_NONE, '只列出待发放记录，不做重放')
            ->setDescription('重放营销规则的待发放记录（发券失败补偿）');
    }

    /**
     * 执行命令
     *
     * @param Input  $input  输入
     * @param Output $output 输出
     * @return void
     */
    protected function execute(Input $input, Output $output): void
    {
        $service = new MarketingService();
        $limit = max(1, (int) $input->getOption('limit'));

        if ($input->getOption('list')) {
            $rows = $service->pendingLogs($limit);
            if ($rows === []) {
                $output->writeln('<info>没有待发放的营销记录。</info>');
                return;
            }

            $output->writeln('<comment>待发放记录（' . count($rows) . ' 条）：</comment>');
            foreach ($rows as $row) {
                $output->writeln(sprintf(
                    '  #%d  rule=%d  user=%d  %s  原因=%s  %s',
                    (int) $row['id'],
                    (int) $row['rule_id'],
                    (int) $row['user_id'],
                    (string) $row['scope_key'],
                    (string) ($row['skip_reason'] ?: '-'),
                    (string) $row['error_msg']
                ));
            }
            return;
        }

        $stats = $service->replayPending($limit);
        if ($stats['processed'] === 0) {
            $output->writeln('<info>没有待发放的营销记录。</info>');
            return;
        }

        $output->writeln(sprintf(
            '处理 %d 条：到账 %d，跳过 %d，仍失败 %d',
            (int) $stats['processed'],
            (int) $stats['granted'],
            (int) $stats['skipped'],
            (int) $stats['failed']
        ));
        if ($stats['failed'] > 0) {
            $output->writeln('<comment>仍有失败记录，可用 php think marketing:grant --list 查看原因。</comment>');
        }
    }
}
