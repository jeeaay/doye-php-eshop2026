<?php

namespace app\common\command;

use app\common\service\MarketingGrantService;
use think\console\Command;
use think\console\Input;
use think\console\input\Option;
use think\console\Output;

/**
 * 优惠券到期提醒
 *
 * 每日跑一次：扫未使用且 N 天内到期的券，写 expiring_soon 通知并入队。
 * 同一张券同一场景只提醒一次（uk_notify），重复执行不会重复发信。
 */
class MarketingRemind extends Command
{
    /**
     * 配置命令
     *
     * @return void
     */
    protected function configure(): void
    {
        $this->setName('marketing:remind')
            ->addOption('days', null, Option::VALUE_OPTIONAL, '提前多少天提醒', null)
            ->setDescription('Queue coupon expiry reminder emails');
    }

    /**
     * 执行
     *
     * @param Input  $input  输入
     * @param Output $output 输出
     * @return void
     */
    protected function execute(Input $input, Output $output): void
    {
        $days = $input->getOption('days');
        $days = $days === null ? (int) site_config('marketing.remind_days', 3) : (int) $days;
        $days = max(1, $days);

        $count = (new MarketingGrantService())->remindExpiring($days);
        $output->writeln('queued ' . $count . ' reminder(s) for coupons expiring within ' . $days . ' day(s)');
    }
}
