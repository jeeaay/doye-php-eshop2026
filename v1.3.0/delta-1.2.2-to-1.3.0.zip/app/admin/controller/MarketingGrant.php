<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\model\MarketingGrant as GrantModel;
use app\common\model\Merchant;
use app\common\service\MarketingGrantService;
use app\common\service\MarketingService;
use app\common\support\AppContext;
use think\facade\View;

/**
 * 后台批量发券（圈选人群 → 发券任务 → 到账通知）
 *
 * 平台级能力，只有超管可用：菜单按角色隐藏，页面再做一次兜底跳转，
 * 真正的读写收口在 MarketingGrantService（与管理 API 同一口径）。
 */
class MarketingGrant extends AdminBaseController
{
    /**
     * 任务列表
     *
     * @return \think\response\View|\think\response\Redirect
     */
    public function index()
    {
        $this->assignActiveMenu('marketing-grants');
        if (!$this->isSuper()) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可管理批量发券');
        }

        $filters = [
            'keyword'       => trim((string) $this->request->get('keyword', '')),
            'audience_type' => (string) $this->request->get('audience_type', ''),
            'status'        => (string) $this->request->get('status', ''),
        ];

        $result = (new MarketingGrantService())->adminList($filters, (int) $this->request->get('page', 1));

        View::assign('grants', $result['list']);
        View::assign('filters', $filters);
        View::assign('grants_link', $result['pager']->render());
        View::assign('audience_options', GrantModel::AUDIENCE_LABELS);
        View::assign('status_options', GrantModel::STATUS_LABELS);

        return View::fetch();
    }

    /**
     * 新建 / 编辑任务
     *
     * @return \think\response\View|\think\response\Redirect
     */
    public function form()
    {
        $this->assignActiveMenu('marketing-grants');
        if (!$this->isSuper()) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可管理批量发券');
        }

        $id = (int) $this->request->get('id', 0);
        if ($id > 0) {
            try {
                $grant = (new MarketingGrantService())->adminDetail($id);
            } catch (BizException $e) {
                return redirect(admin_url('marketing-grants'))->with('error', $e->getMessage());
            }
        } else {
            $grant = [
                'id'            => 0,
                'name'          => '',
                'coupon_id'     => 0,
                'audience_type' => GrantModel::AUDIENCE_ALL,
                'audience'      => ['days' => 0, 'min_amount' => '0.00', 'merchant_ids' => [], 'imported_count' => 0],
                'batch_size'    => 500,
                'start_time'    => '',
                'end_time'      => '',
                'remark'        => '',
                'status'        => GrantModel::STATUS_PENDING,
                'total_target'  => 0,
            ];
        }

        $merchants = [];
        foreach (Merchant::order('id')->field('id,name')->select() as $row) {
            $merchants[] = ['id' => (int) $row->id, 'name' => (string) $row->name];
        }

        $coupons = (new MarketingService())->couponOptions((int) ($grant['coupon_id'] ?? 0) ?: null);

        View::assign('grant', $grant);
        View::assign('grant_json', $this->json($grant));
        View::assign('audience_options', GrantModel::AUDIENCE_LABELS);
        View::assign('coupons', $coupons);
        View::assign('coupons_json', $this->json($coupons));
        View::assign('merchants_json', $this->json($merchants));

        return View::fetch();
    }

    /**
     * 任务详情：进度、发放记录、通知
     *
     * @return \think\response\View|\think\response\Redirect
     */
    public function detail()
    {
        $this->assignActiveMenu('marketing-grants');
        if (!$this->isSuper()) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可管理批量发券');
        }

        try {
            $grant = (new MarketingGrantService())->adminDetail((int) $this->request->get('id', 0));
        } catch (BizException $e) {
            return redirect(admin_url('marketing-grants'))->with('error', $e->getMessage());
        }

        View::assign('grant', $grant);
        View::assign('notify', $grant['notify']);

        return View::fetch();
    }

    /**
     * 保存任务
     *
     * @return \think\response\Json
     */
    public function save()
    {
        try {
            $data   = $this->request->post();
            $id     = !empty($data['id']) ? (int) $data['id'] : null;
            $grantId = (new MarketingGrantService())->adminSave($data, $id);

            return json(['code' => 0, 'message' => '发券任务已保存', 'data' => ['id' => $grantId]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 执行一批
     *
     * @return \think\response\Json
     */
    public function run()
    {
        try {
            $result = (new MarketingGrantService())->adminRun((int) $this->request->post('id', 0));
            $done   = $result['done'] ? '已全部处理' : '已推进一批';

            return json(['code' => 0, 'message' => $done, 'data' => $result]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 取消任务
     *
     * @return \think\response\Json
     */
    public function cancel()
    {
        try {
            (new MarketingGrantService())->adminCancel((int) $this->request->post('id', 0));
            return json(['code' => 0, 'message' => '任务已取消', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 作废该任务发出的未使用券
     *
     * @return \think\response\Json
     */
    public function revoke()
    {
        try {
            $count = (new MarketingGrantService())->adminRevoke((int) $this->request->post('id', 0));
            return json(['code' => 0, 'message' => '已作废 ' . $count . ' 张未使用券', 'data' => ['revoked' => $count]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 删除任务
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        try {
            (new MarketingGrantService())->adminDelete((int) $this->request->post('id', 0));
            return json(['code' => 0, 'message' => '任务已删除', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 人数预览（表单联动，POST 与 AdminAjax 保持一致）
     *
     * @return \think\response\Json
     */
    public function preview()
    {
        try {
            $audience = json_decode((string) $this->request->post('audience', '{}'), true) ?: [];
            $count    = (new MarketingGrantService())->previewAudience(
                (string) $this->request->post('audience_type', ''),
                $audience
            );
            return json(['code' => 0, 'message' => 'ok', 'data' => ['count' => $count]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 传给前端的 JSON（转义标签与引号，避免提前闭合 script）
     *
     * @param mixed $value 数据
     * @return string
     */
    private function json($value): string
    {
        return (string) json_encode($value, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);
    }

    /**
     * 是否平台超管
     *
     * @return bool
     */
    private function isSuper(): bool
    {
        return AppContext::getAdminRole() === AdminRole::SUPER;
    }
}
