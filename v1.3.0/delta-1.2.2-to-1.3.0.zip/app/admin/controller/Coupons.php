<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\model\Merchant;
use app\common\service\CouponService;
use app\common\support\AppContext;
use think\facade\View;

/**
 * 后台优惠管理
 *
 * 平台超管与商家共用这一页：可见范围与写权限全部由 CouponService 按 AppContext 收敛，
 * 控制器不再判角色（超管全量 + 可按商户筛选；商家只见本店记录与平台活动，平台活动只读）。
 */
class Coupons extends AdminBaseController
{
    /**
     * 优惠列表页
     *
     * @return \think\response\View
     */
    public function index()
    {
        $this->assignActiveMenu('coupons');

        $isSuper = $this->isSuper();
        $filters = [
            'keyword'     => trim((string) $this->request->get('keyword', '')),
            'apply_type'  => (string) $this->request->get('apply_type', ''),
            'status'      => $this->request->get('status', ''),
            'merchant_id' => $isSuper ? (int) $this->request->get('merchant_id', 0) : 0,
        ];

        $result = (new CouponService())->adminList($filters, (int) $this->request->get('page', 1));

        View::assign('coupons', $result['list']);
        View::assign('filters', $filters);
        View::assign('coupons_link', $result['pager']->render());
        View::assign('is_super', $isSuper ? 1 : 0);
        View::assign('merchants', $isSuper ? $this->merchantOptions() : []);
        return View::fetch();
    }

    /**
     * 新增 / 编辑优惠表单
     *
     * @return \think\response\View|\think\response\Redirect
     */
    public function form()
    {
        $this->assignActiveMenu('coupons');

        $isSuper = $this->isSuper();
        $service = new CouponService();
        $id = (int) $this->request->get('id', 0);

        $coupon = [
            'id'             => 0,
            'name'           => '',
            'code'           => '',
            'merchant_id'    => null,
            'apply_type'     => 'claim',
            'tier'           => 40,
            'discount_type'  => 'fixed',
            'discount_value' => '5.00',
            'min_amount'     => '0.00',
            'max_discount'   => '0.00',
            'scope'          => 'all',
            'total_qty'      => 0,
            'per_user_limit' => 1,
            'valid_days'     => 0,
            'expire_at'      => '',
            'start_time'     => '',
            'end_time'       => '',
            'status'         => 1,
            'sort'           => 0,
            'remark'         => '',
            'product_ids'    => [],
        ];

        if ($id > 0) {
            try {
                $coupon = $service->adminDetail($id);
            } catch (BizException $e) {
                return redirect(admin_url('coupons'))->with('error', $e->getMessage());
            }
        }

        View::assign('coupon', $coupon);
        View::assign('coupon_json', json_encode($coupon, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT));
        View::assign('products_json', json_encode($service->productOptions(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT));
        View::assign('is_super', $isSuper ? 1 : 0);
        View::assign('merchants', $isSuper ? $this->merchantOptions($coupon['merchant_id'] ?? null) : []);
        return View::fetch('coupons/form');
    }

    /**
     * 保存优惠（新增 / 更新）
     *
     * @return \think\response\Json
     */
    public function save()
    {
        try {
            $data = $this->request->post();
            $id = !empty($data['id']) ? (int) $data['id'] : null;
            $couponId = (new CouponService())->adminSave($data, $id);
            return json(['code' => 0, 'message' => '优惠已保存', 'data' => ['id' => $couponId]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 启用 / 停用优惠
     *
     * @return \think\response\Json
     */
    public function status()
    {
        try {
            (new CouponService())->adminToggle(
                (int) $this->request->post('id', 0),
                (int) $this->request->post('status', 1)
            );
            return json(['code' => 0, 'message' => '优惠状态已更新', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 删除优惠
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        try {
            (new CouponService())->adminDelete((int) $this->request->post('id', 0));
            return json(['code' => 0, 'message' => '优惠已删除', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 归属商户下拉数据（仅超管可见）
     *
     * 编辑时额外带上当前归属商户：停用中的商户不在 status=1 列表里，
     * 下拉找不到对应 option 会把值回落成「平台」，保存后记录就被悄悄迁走了归属。
     *
     * @param int|null $ownerId 当前记录的归属商户
     * @return array<int,array{id:int,name:string}>
     */
    private function merchantOptions(?int $ownerId = null): array
    {
        $query = Merchant::where('status', 1);
        if ($ownerId !== null && $ownerId > 0) {
            $query = Merchant::where(function ($q) use ($ownerId) {
                $q->where('status', 1)->whereOr('id', $ownerId);
            });
        }

        $out = [];
        foreach ($query->order('id')->field('id,name')->select() as $merchant) {
            $out[] = ['id' => (int) $merchant->id, 'name' => (string) $merchant->name];
        }
        return $out;
    }

    /**
     * 当前登录管理员是否为平台超级管理员
     *
     * @return bool
     */
    private function isSuper(): bool
    {
        return AppContext::getAdminRole() === AdminRole::SUPER;
    }
}
