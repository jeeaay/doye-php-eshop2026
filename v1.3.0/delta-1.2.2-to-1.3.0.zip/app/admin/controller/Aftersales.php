<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\model\Aftersale;
use app\common\model\RefundLog;
use think\facade\View;
use app\common\service\AdminCrudService;
use app\common\exception\BizException;

class Aftersales extends AdminBaseController
{
    public function index()
    {
        $this->assignActiveMenu('aftersales');

        $query = Aftersale::with(['order.items', 'user']);
        $number = trim((string) $this->request->get('aftersale_no', ''));
        $status = $this->request->get('status', '');
        $type = $this->request->get('type', '');
        if ($number !== '') $query->whereLike('aftersale_no', '%' . $number . '%');
        if ($status !== '') $query->where('status', (int) $status);
        if ($type !== '') $query->where('type', (int) $type);
        $aftersales = $query
            ->order('id', 'desc')
            ->paginate(20);

        $list = [];
        $refunds = [];
        $ids = [];
        foreach ($aftersales as $item) {
            $ids[] = (int) $item->id;
        }
        if ($ids) {
            foreach (RefundLog::whereIn('aftersale_id', $ids)->order('id')->select() as $refund) {
                $refunds[(int) $refund->aftersale_id] = $refund;
            }
        }
        foreach ($aftersales as $item) {
            $order = $item->order;
            $firstItem = $order?->items?->first();
            $refund = $refunds[(int) $item->id] ?? null;
            $list[] = [
                'id'             => $item->id,
                'aftersale_no'   => $item->aftersale_no,
                'product_title'  => $firstItem ? ($firstItem->sku_snapshot_json['title'] ?? '') : '',
                'product_image'  => $firstItem ? ($firstItem->sku_snapshot_json['main_image'] ?? '') : '',
                'order_no'       => $order?->order_no ?? '',
                'buyer_name'     => $item->user?->nickname ?? '',
                'type_text'      => $item->type == 1 ? '仅退款' : '退货退款',
                'refund_amount'  => '¥' . number_format((float)$item->refund_amount, 2),
                'status'         => $item->status,
                'refund_status'  => $refund ? (string) $refund->status : '',
                'refund_label'   => $refund ? (RefundLog::STATUS_LABELS[(string) $refund->status] ?? (string) $refund->status) : '',
                'refund_error'   => $refund ? (string) ($refund->error_msg ?? '') : '',
                'can_retry'      => $refund
                    && (string) $refund->status === RefundLog::STATUS_FAILED
                    && in_array((int) $item->status, [1, 3], true),
            ];
        }

        View::assign('aftersales', $list);
        View::assign('filters', ['aftersale_no' => $number, 'status' => $status, 'type' => $type]);
        View::assign('pages', $aftersales->render());
        return View::fetch();
    }

    public function approve()
    {
        try {
            (new AdminCrudService())->approveAftersale((int) $this->request->post('id'));
            return redirect(admin_url('aftersales'))->with('success', '售后已审核');
        } catch (BizException $e) {
            return redirect(admin_url('aftersales'))->with('error', $e->getMessage());
        }
    }

    public function reject()
    {
        try {
            (new AdminCrudService())->rejectAftersale((int) $this->request->post('id'), (string) $this->request->post('reason'));
            return redirect(admin_url('aftersales'))->with('success', '售后已拒绝');
        } catch (BizException $e) {
            return redirect(admin_url('aftersales'))->with('error', $e->getMessage());
        }
    }

    public function receive()
    {
        try {
            (new AdminCrudService())->receiveAftersale((int) $this->request->post('id'));
            return redirect(admin_url('aftersales'))->with('success', '已确认收货并完成售后');
        } catch (BizException $e) {
            return redirect(admin_url('aftersales'))->with('error', $e->getMessage());
        }
    }

    /**
     * 重试退款（上次失败才显示入口；结果未知时 Service 会拒绝重复出款）
     *
     * @return \think\response\Redirect
     */
    public function refundRetry()
    {
        try {
            (new AdminCrudService())->retryRefund((int) $this->request->post('id'));
            return redirect(admin_url('aftersales'))->with('success', '退款已重新发起并成功');
        } catch (BizException $e) {
            return redirect(admin_url('aftersales'))->with('error', $e->getMessage());
        }
    }
}
