<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\exception\BizException;
use app\common\service\MarketingService;

/**
 * 管理 API：营销规则（拉新奖励 / 确认收货返利）
 *
 * 与后台页面同一批 MarketingService 方法、同一权限口径：
 * 营销规则是平台级能力，非超管在 Service 层统一收到「营销规则不存在」，控制器不判角色。
 */
class Marketing extends ApiBaseController
{
    /**
     * GET /admin-api/v1/marketing/rules
     *
     * @return \think\response\Json
     */
    public function index()
    {
        return $this->run(function () {
            [$page, $size] = $this->pageParams();

            $filters = [
                'keyword' => trim((string) $this->request->param('keyword', '')),
                'type'    => trim((string) $this->request->param('type', '')),
                'status'  => $this->request->param('status', ''),
            ];

            $result = (new MarketingService())->adminList($filters, $page, $size);
            return $this->pagePayload($result['list'], $result['pager'], $page, $size);
        });
    }

    /**
     * GET /admin-api/v1/marketing/rules/:id
     *
     * @return \think\response\Json
     */
    public function detail()
    {
        return $this->run(function () {
            return (new MarketingService())->adminDetail((int) $this->request->param('id', 0));
        });
    }

    /**
     * POST /admin-api/v1/marketing/rules
     *
     * @return \think\response\Json
     */
    public function save()
    {
        return $this->run(function () {
            $input = $this->input();
            unset($input['id']);
            return ['id' => (new MarketingService())->adminSave($input)];
        }, '营销规则已创建');
    }

    /**
     * PUT /admin-api/v1/marketing/rules/:id
     *
     * @return \think\response\Json
     */
    public function update()
    {
        return $this->run(function () {
            $id = (int) $this->request->param('id', 0);
            return ['id' => (new MarketingService())->adminSave($this->input(), $id)];
        }, '营销规则已更新');
    }

    /**
     * POST /admin-api/v1/marketing/rules/:id/status
     *
     * @return \think\response\Json
     */
    public function status()
    {
        return $this->run(function () {
            $input = $this->input();
            if (!isset($input['status']) || !in_array((int) $input['status'], [0, 1], true)) {
                throw new BizException('规则状态无效');
            }
            (new MarketingService())->adminToggle(
                (int) $this->request->param('id', 0),
                (int) $input['status']
            );
            return null;
        }, '规则状态已更新');
    }

    /**
     * DELETE /admin-api/v1/marketing/rules/:id
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        return $this->run(function () {
            (new MarketingService())->adminDelete((int) $this->request->param('id', 0));
            return null;
        }, '营销规则已删除');
    }

    /**
     * GET /admin-api/v1/marketing/logs
     * GET /admin-api/v1/marketing/rules/:id/logs
     *
     * 路径里带 :id 时按该规则过滤，否则可跨规则查（rule_id 走查询参数）
     *
     * @return \think\response\Json
     */
    public function logs()
    {
        return $this->run(function () {
            [$page, $size] = $this->pageParams();

            $filters = [
                // 路径 :id 优先（rules/:id/logs），否则允许 /marketing/logs?rule_id= 跨规则筛
                'rule_id'  => (int) ($this->request->param('id', 0) ?: $this->request->param('rule_id', 0)),
                'user_id'  => (int) $this->request->param('user_id', 0),
                'order_id' => (int) $this->request->param('order_id', 0),
                'status'   => trim((string) $this->request->param('status', '')),
            ];

            $result = (new MarketingService())->adminLogs($filters, $page, $size);
            return $this->pagePayload($result['list'], $result['pager'], $page, $size);
        });
    }
}
