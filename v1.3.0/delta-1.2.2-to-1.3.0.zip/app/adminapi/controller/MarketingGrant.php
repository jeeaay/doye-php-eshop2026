<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\service\MarketingGrantService;

/**
 * 管理 API：批量发券任务
 *
 * 与后台页面同一批 MarketingGrantService 方法、同一权限口径（平台超管）；
 * 非超管在 Service 层统一收到「发券任务不存在」，控制器不判角色。
 */
class MarketingGrant extends ApiBaseController
{
    /**
     * GET /admin-api/v1/marketing/grants
     *
     * @return \think\response\Json
     */
    public function index()
    {
        return $this->run(function () {
            [$page, $size] = $this->pageParams();

            $filters = [
                'keyword'       => trim((string) $this->request->param('keyword', '')),
                'audience_type' => (string) $this->request->param('audience_type', ''),
                'status'        => (string) $this->request->param('status', ''),
            ];

            $result = (new MarketingGrantService())->adminList($filters, $page, $size);
            return $this->pagePayload($result['list'], $result['pager'], $page, $size);
        });
    }

    /**
     * GET /admin-api/v1/marketing/grants/:id
     *
     * @return \think\response\Json
     */
    public function detail()
    {
        return $this->run(function () {
            return (new MarketingGrantService())->adminDetail((int) $this->request->param('id', 0));
        });
    }

    /**
     * POST /admin-api/v1/marketing/grants
     *
     * @return \think\response\Json
     */
    public function save()
    {
        return $this->run(function () {
            $input = $this->input();
            unset($input['id']);
            return ['id' => (new MarketingGrantService())->adminSave($input)];
        }, '发券任务已创建');
    }

    /**
     * PUT /admin-api/v1/marketing/grants/:id
     *
     * @return \think\response\Json
     */
    public function update()
    {
        return $this->run(function () {
            $id = (int) $this->request->param('id', 0);
            return ['id' => (new MarketingGrantService())->adminSave($this->input(), $id)];
        }, '发券任务已更新');
    }

    /**
     * DELETE /admin-api/v1/marketing/grants/:id
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        return $this->run(function () {
            (new MarketingGrantService())->adminDelete((int) $this->request->param('id', 0));
            return null;
        }, '发券任务已删除');
    }

    /**
     * POST /admin-api/v1/marketing/grants/:id/run
     *
     * @return \think\response\Json
     */
    public function execute()
    {
        return $this->run(function () {
            $batch = $this->request->param('batch_size', null);
            return (new MarketingGrantService())->adminRun(
                (int) $this->request->param('id', 0),
                $batch === null ? null : (int) $batch
            );
        }, '已推进一批');
    }

    /**
     * POST /admin-api/v1/marketing/grants/:id/cancel
     *
     * @return \think\response\Json
     */
    public function cancel()
    {
        return $this->run(function () {
            (new MarketingGrantService())->adminCancel((int) $this->request->param('id', 0));
            return null;
        }, '任务已取消');
    }

    /**
     * POST /admin-api/v1/marketing/grants/:id/revoke
     *
     * @return \think\response\Json
     */
    public function revoke()
    {
        return $this->run(function () {
            return ['revoked' => (new MarketingGrantService())->adminRevoke((int) $this->request->param('id', 0))];
        }, '未使用券已作废');
    }

    /**
     * POST /admin-api/v1/marketing/grants/:id/resend
     *
     * @return \think\response\Json
     */
    public function resend()
    {
        return $this->run(function () {
            return ['queued' => (new MarketingGrantService())->adminResendFailed((int) $this->request->param('limit', 100))];
        }, '失败通知已重新入队');
    }

    /**
     * POST /admin-api/v1/marketing/grants/preview
     *
     * @return \think\response\Json
     */
    public function preview()
    {
        return $this->run(function () {
            $audience = $this->request->param('audience', []);
            if (is_string($audience)) {
                $audience = json_decode($audience, true) ?: [];
            }

            return [
                'count' => (new MarketingGrantService())->previewAudience(
                    (string) $this->request->param('audience_type', ''),
                    is_array($audience) ? $audience : []
                ),
            ];
        });
    }
}
