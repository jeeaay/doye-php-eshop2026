<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\exception\BizException;
use app\common\service\CouponService;

/**
 * 管理 API：优惠活动
 *
 * 超管与商家共用同一批端点，可见范围与写权限由 CouponService 按 AppContext 收敛，
 * 与后台页面完全同口径（页面能做的 API 能做，反之亦然）。
 */
class Coupon extends ApiBaseController
{
    /**
     * GET /admin-api/v1/coupons
     *
     * @return \think\response\Json
     */
    public function index()
    {
        return $this->run(function () {
            [$page, $size] = $this->pageParams();

            $filters = [
                'keyword'     => trim((string) $this->request->param('keyword', '')),
                'apply_type'  => trim((string) $this->request->param('apply_type', '')),
                'status'      => $this->request->param('status', ''),
                'merchant_id' => (int) $this->request->param('merchant_id', 0),
            ];

            $result = (new CouponService())->adminList($filters, $page, $size);
            return $this->pagePayload($result['list'], $result['pager'], $page, $size);
        });
    }

    /**
     * GET /admin-api/v1/coupons/:id
     *
     * @return \think\response\Json
     */
    public function detail()
    {
        return $this->run(function () {
            return (new CouponService())->adminDetail((int) $this->request->param('id', 0));
        });
    }

    /**
     * POST /admin-api/v1/coupons
     *
     * @return \think\response\Json
     */
    public function save()
    {
        return $this->run(function () {
            $input = $this->input();
            unset($input['id']);
            return ['id' => (new CouponService())->adminSave($input)];
        }, '优惠已创建');
    }

    /**
     * PUT /admin-api/v1/coupons/:id
     *
     * @return \think\response\Json
     */
    public function update()
    {
        return $this->run(function () {
            $id = (int) $this->request->param('id', 0);
            return ['id' => (new CouponService())->adminSave($this->input(), $id)];
        }, '优惠已更新');
    }

    /**
     * POST /admin-api/v1/coupons/:id/status
     *
     * @return \think\response\Json
     */
    public function status()
    {
        return $this->run(function () {
            $input = $this->input();
            if (!isset($input['status']) || !in_array((int) $input['status'], [0, 1], true)) {
                throw new BizException('优惠状态无效');
            }
            (new CouponService())->adminToggle(
                (int) $this->request->param('id', 0),
                (int) $input['status']
            );
            return null;
        }, '优惠状态已更新');
    }

    /**
     * DELETE /admin-api/v1/coupons/:id
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        return $this->run(function () {
            (new CouponService())->adminDelete((int) $this->request->param('id', 0));
            return null;
        }, '优惠已删除');
    }
}