<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\service\AdminCrudService;

/**
 * 管理 API：售后
 *
 * 本期只开放退款重试：审核/确认收货仍走后台页面。
 * 权限与数据范围复用 AdminCrudService::retryRefund()（与页面同一口径）。
 */
class Aftersale extends ApiBaseController
{
    /**
     * POST /admin-api/v1/aftersales/:id/refund-retry
     *
     * @return \think\response\Json
     */
    public function refundRetry()
    {
        return $this->run(function () {
            (new AdminCrudService())->retryRefund((int) $this->request->param('id', 0));
            return null;
        }, '退款已重新发起');
    }
}
