/* Cookie 同意横幅（替代原 Go 主题的 layouts/cookie_banner.html + 内联脚本） */
(function () {
  var KEY = 'site_cookie_consent';

  function applyConsent(granted) {
    if (typeof window.gtag === 'function') {
      window.gtag('consent', 'update', {
        ad_storage: granted ? 'granted' : 'denied',
        ad_user_data: granted ? 'granted' : 'denied',
        ad_personalization: granted ? 'granted' : 'denied'
      });
    }
  }

  function syncBodyOffset(el, visible) {
    document.body.classList.toggle('cookie-visible', visible);
    if (visible && el) {
      document.body.style.setProperty('--cookie-h', el.offsetHeight + 'px');
    } else {
      document.body.style.removeProperty('--cookie-h');
    }
  }

  function show() {
    var el = document.getElementById('cookie-banner');
    if (!el) { return; }
    el.hidden = false;
    syncBodyOffset(el, true);
  }

  function hide() {
    var el = document.getElementById('cookie-banner');
    if (el) { el.hidden = true; }
    syncBodyOffset(null, false);
  }

  document.addEventListener('DOMContentLoaded', function () {
    var saved = localStorage.getItem(KEY);
    if (!saved) {
      show();
    } else {
      applyConsent(saved === 'granted');
    }

    document.querySelectorAll('[data-cookie-action]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var granted = btn.dataset.cookieAction === 'accept';
        localStorage.setItem(KEY, granted ? 'granted' : 'denied');
        applyConsent(granted);
        hide();
      });
    });

    window.addEventListener('resize', function () {
      var el = document.getElementById('cookie-banner');
      if (el && !el.hidden) { syncBodyOffset(el, true); }
    });
  });

  window.SiteCookieConsent = {
    open: function () { show(); },
    reset: function () { localStorage.removeItem(KEY); show(); }
  };
})();