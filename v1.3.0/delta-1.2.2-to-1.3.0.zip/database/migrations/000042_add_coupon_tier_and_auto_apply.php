<?php
use think\migration\Migrator;

/**
 * 优惠定义增加层级（tier）与自动抵扣（auto_apply）标记
 *
 * tier 决定优惠在分层计算中的位置，10 商家折扣 / 20 平台活动 / 30 自动发放券 / 40 手动选择券或优惠码。
 * auto_apply=1 表示券到账后在结算时自动抵扣，用户无需勾选（tier=30 的返利券、新人券走这一路）。
 *
 * 回填口径：apply_type=auto 视为平台活动层（20），其余（claim / code）归入手动层（40），
 * 保证分层重构前后同一批现网数据的试算结果逐分钱一致。
 */
class AddCouponTierAndAutoApply extends Migrator
{
    /**
     * @return void
     */
    public function up()
    {
        $this->table('coupon')
            ->addColumn('tier', 'smallinteger', [
                'signed'  => false,
                'default' => 40,
                'comment' => '优惠层级 10 商家折扣 / 20 平台活动 / 30 自动发放券 / 40 手动券或优惠码',
            ])
            ->addColumn('auto_apply', 'tinyinteger', [
                'limit'   => 1,
                'default' => 0,
                'comment' => '1=到账后结算时自动抵扣，无需用户勾选',
            ])
            ->addIndex(['tier', 'status'], ['name' => 'idx_tier_status'])
            ->update();

        $this->execute("UPDATE coupon SET tier = 20 WHERE apply_type = 'auto'");
        $this->execute("UPDATE coupon SET tier = 40 WHERE apply_type <> 'auto'");
    }

    /**
     * @return void
     */
    public function down()
    {
        $this->table('coupon')
            ->removeIndexByName('idx_tier_status')
            ->removeColumn('tier')
            ->removeColumn('auto_apply')
            ->update();
    }
}
