<?php
use think\migration\Migrator;

/**
 * 创建批量发券任务、每人发放记录与通知记录
 *
 * - marketing_grant       运营任务（圈选人群 + 发哪张券 + 分批进度）
 * - marketing_grant_log   每人一条，uk_grant_user 是重复点击执行/进程重启时的幂等键
 * - marketing_notify_log  券到账 / 到期提醒 / 券退回三类事务性通知，uk_notify 保证一券一场景一次
 *
 * 全部平台级表：批量发券是平台超管能力，不注入商户 scope（MerchantScope），不存 merchant_id。
 * 券发放本身仍走 CouponService::issue()（行锁 + 模板限量 + 每人限额），本处只负责任务幂等与进度。
 */
class CreateMarketingGrant extends Migrator
{
    /**
     * 执行迁移
     *
     * @return void
     */
    public function change()
    {
        $grant = $this->table('marketing_grant', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '批量发券任务',
        ]);
        $grant->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('name', 'string', ['limit' => 96, 'null' => false, 'comment' => '任务名'])
            ->addColumn('coupon_id', 'biginteger', ['signed' => false, 'null' => false, 'comment' => '发放的券模板（tier 30/40）'])
            ->addColumn('audience_type', 'string', ['limit' => 24, 'null' => false, 'comment' => 'all 全站 / purchased 已购买 / merchant_customers 指定商户客群 / import 名单导入'])
            ->addColumn('audience_json', 'json', ['null' => true, 'comment' => '圈选参数 {days,min_amount,merchant_ids[],imported_count}'])
            ->addColumn('total_target', 'integer', ['null' => false, 'default' => 0, 'signed' => false, 'comment' => '目标人数（执行前 count 的快照）'])
            ->addColumn('granted_qty', 'integer', ['null' => false, 'default' => 0, 'signed' => false, 'comment' => '已成功发放'])
            ->addColumn('skipped_qty', 'integer', ['null' => false, 'default' => 0, 'signed' => false, 'comment' => '跳过人数'])
            ->addColumn('failed_qty', 'integer', ['null' => false, 'default' => 0, 'signed' => false, 'comment' => '发放失败（可重跑）'])
            ->addColumn('cursor_user_id', 'biginteger', ['signed' => false, 'null' => false, 'default' => 0, 'comment' => '查询型人群的 user.id 断点'])
            ->addColumn('cursor_log_id', 'biginteger', ['signed' => false, 'null' => false, 'default' => 0, 'comment' => '导入型人群的 marketing_grant_log.id 断点'])
            ->addColumn('batch_size', 'integer', ['null' => false, 'default' => 500, 'signed' => false, 'comment' => '每批人数'])
            ->addColumn('status', 'string', ['limit' => 16, 'null' => false, 'default' => 'pending', 'comment' => 'pending 待执行 / running 执行中 / paused 暂停 / done 完成 / canceled 已取消'])
            ->addColumn('start_time', 'datetime', ['null' => true, 'comment' => '可发放开始时间；为空立即生效'])
            ->addColumn('end_time', 'datetime', ['null' => true, 'comment' => '可发放结束时间；已发出的券按自身有效期继续可用'])
            ->addColumn('remark', 'string', ['limit' => 255, 'null' => true])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addIndex(['status', 'id'], ['name' => 'idx_status'])
            ->addIndex(['coupon_id'])
            ->create();

        $log = $this->table('marketing_grant_log', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '批量发券：每人一条发放记录（幂等键）',
        ]);
        $log->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('grant_id', 'biginteger', ['signed' => false, 'null' => false, 'comment' => '所属任务'])
            ->addColumn('user_id', 'biginteger', ['signed' => false, 'null' => false, 'default' => 0, 'comment' => '目标用户；导入名单里无账号的邮箱记 0'])
            ->addColumn('email', 'string', ['limit' => 190, 'null' => false, 'default' => '', 'comment' => '邮箱快照（脱敏展示）；无邮箱存空串，保证幂等键里不出现 NULL'])
            ->addColumn('coupon_user_id', 'biginteger', ['signed' => false, 'null' => true, 'comment' => '发出的券实例'])
            ->addColumn('status', 'string', ['limit' => 16, 'null' => false, 'default' => 'pending', 'comment' => 'pending 待发放 / granted 已到账 / skipped 跳过 / failed 失败'])
            ->addColumn('skip_reason', 'string', ['limit' => 32, 'null' => true, 'comment' => 'already_granted / user_limit_exceeded / coupon_unavailable / no_account / not_in_window / error'])
            ->addColumn('error_msg', 'string', ['limit' => 255, 'null' => true])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addIndex(['grant_id', 'user_id', 'email'], ['unique' => true, 'name' => 'uk_grant_user'])
            ->addIndex(['grant_id', 'status', 'id'], ['name' => 'idx_grant_status'])
            ->addIndex(['user_id'])
            ->create();

        $notify = $this->table('marketing_notify_log', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '事务性通知记录（券到账 / 到期提醒 / 券退回）',
        ]);
        $notify->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('channel', 'string', ['limit' => 16, 'null' => false, 'default' => 'email', 'comment' => 'email；短信/微信预留'])
            ->addColumn('scene', 'string', ['limit' => 24, 'null' => false, 'comment' => 'grant_arrived 到账 / expiring_soon 到期提醒 / coupon_restored 券退回'])
            ->addColumn('user_id', 'biginteger', ['signed' => false, 'null' => false])
            ->addColumn('coupon_user_id', 'biginteger', ['signed' => false, 'null' => false, 'comment' => '通知对应的券实例'])
            ->addColumn('grant_id', 'biginteger', ['signed' => false, 'null' => true, 'comment' => '批量发券来源；规则发放为 NULL'])
            ->addColumn('to_email', 'string', ['limit' => 190, 'null' => true, 'comment' => '发送时快照'])
            ->addColumn('status', 'string', ['limit' => 20, 'null' => false, 'default' => 'pending', 'comment' => 'pending / sent / skipped_no_email / failed'])
            ->addColumn('attempts', 'tinyinteger', ['null' => false, 'default' => 0, 'signed' => false, 'comment' => '发送尝试次数，补偿限次'])
            ->addColumn('error_msg', 'string', ['limit' => 255, 'null' => true])
            ->addColumn('sent_at', 'datetime', ['null' => true])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addIndex(['scene', 'coupon_user_id'], ['unique' => true, 'name' => 'uk_notify'])
            ->addIndex(['status', 'id'], ['name' => 'idx_status'])
            ->addIndex(['user_id'])
            ->create();
    }
}
