<?php
use think\migration\Migrator;

/**
 * 售后退款记录与结算冲减明细
 *
 * refund_log：
 * - refund_no 同时作为微信 out_refund_no，**确定性单号**是重试不重复出款的前提；
 * - uk_refund_target(order_pay_id, aftersale_id)：一次售后只能有一条退款单，幂等落在库上；
 * - status 走 pending → requesting → success/failed，requesting 表示结果未知，不得自动重放。
 *
 * settlement_deduction：
 * - 已结算订单发生退款时写一条待冲减明细，下一期结算把 refund_deduction 扣进 net_amount；
 * - uk_refund 保证同一退款单只冲减一次。
 */
class CreateRefundLog extends Migrator
{
    /**
     * 执行迁移
     *
     * @return void
     */
    public function change()
    {
        $refund = $this->table('refund_log', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '售后退款记录（幂等凭据 + 通道结果）',
        ]);
        $refund->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('refund_no', 'string', ['limit' => 64, 'null' => false, 'comment' => '平台退款单号，同时作为微信 out_refund_no'])
            ->addColumn('order_pay_id', 'biginteger', ['signed' => false, 'null' => false])
            ->addColumn('order_id', 'biginteger', ['signed' => false, 'null' => false])
            ->addColumn('aftersale_id', 'biginteger', ['signed' => false, 'null' => false])
            ->addColumn('channel', 'string', ['limit' => 16, 'null' => false, 'default' => 'wechat'])
            ->addColumn('refund_id', 'string', ['limit' => 64, 'null' => true, 'comment' => '通道侧退款单号'])
            ->addColumn('amount_minor', 'biginteger', ['signed' => false, 'null' => false, 'default' => 0, 'comment' => '退款金额（分），与网关口径一致'])
            ->addColumn('charge_currency', 'string', ['limit' => 8, 'null' => false, 'default' => 'CNY', 'comment' => '下单时收款币种快照'])
            ->addColumn('status', 'string', ['limit' => 16, 'null' => false, 'default' => 'pending', 'comment' => 'pending / requesting / success / failed'])
            ->addColumn('error_msg', 'string', ['limit' => 255, 'null' => true])
            ->addColumn('requested_at', 'datetime', ['null' => true, 'comment' => '首次发起时间'])
            ->addColumn('finished_at', 'datetime', ['null' => true, 'comment' => '成功/失败落定时间'])
            ->addColumn('operator_id', 'biginteger', ['signed' => false, 'null' => true, 'comment' => '触发退款的后台账号'])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addIndex(['refund_no'], ['unique' => true, 'name' => 'uk_refund_no'])
            ->addIndex(['order_pay_id', 'aftersale_id'], ['unique' => true, 'name' => 'uk_refund_target'])
            ->addIndex(['status', 'id'], ['name' => 'idx_status'])
            ->create();

        $deduction = $this->table('settlement_deduction', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '已结算订单退款的待冲减明细',
        ]);
        $deduction->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('merchant_id', 'biginteger', ['signed' => false, 'null' => false])
            ->addColumn('order_id', 'biginteger', ['signed' => false, 'null' => false])
            ->addColumn('refund_id', 'biginteger', ['signed' => false, 'null' => false, 'comment' => 'refund_log.id'])
            ->addColumn('amount', 'decimal', ['precision' => 10, 'scale' => 2, 'null' => false, 'default' => 0, 'comment' => '需从商家后续结算扣回的金额'])
            ->addColumn('settlement_id', 'biginteger', ['signed' => false, 'null' => true, 'comment' => '并入的结算单；NULL = 待冲减'])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addIndex(['refund_id'], ['unique' => true, 'name' => 'uk_refund'])
            ->addIndex(['settlement_id', 'merchant_id'], ['name' => 'idx_settlement'])
            ->create();
    }
}
