<?php
use think\migration\Migrator;

/**
 * coupon 增加商户归属 merchant_id（商家折扣维度）
 *
 * NULL = 平台记录（平台活动、平台发的券、营销规则发的券），非空 = 该商户的优惠，
 * 参与计算的基数只包含该商户的商品行（见 CouponService::eligibleBase()）。
 *
 * 存量行不回填：迁移前所有优惠都由平台超管配置，语义上就是平台记录，
 * 回填成任意商户都会让原本全站生效的优惠突然只作用于某家商品。
 *
 * Coupon 模型继续 extends BaseModel（不改 MerchantModel）：这张表同时装平台行与商户行，
 * 交给 MerchantScope 自动注入会让 NULL 行语义不明，且商户写操作可能圈进平台行。
 */
class AddCouponMerchantId extends Migrator
{
    /**
     * @return void
     */
    public function up()
    {
        $this->table('coupon')
            ->addColumn('merchant_id', 'biginteger', [
                'signed'  => false,
                'null'    => true,
                'comment' => '归属商户，NULL=平台活动/平台券，非空=该商户的优惠（只抵扣该商户商品）',
            ])
            ->addIndex(['merchant_id', 'status'], ['name' => 'idx_merchant_status'])
            ->update();
    }

    /**
     * @return void
     */
    public function down()
    {
        $this->table('coupon')
            ->removeIndexByName('idx_merchant_status')
            ->removeColumn('merchant_id')
            ->update();
    }
}
