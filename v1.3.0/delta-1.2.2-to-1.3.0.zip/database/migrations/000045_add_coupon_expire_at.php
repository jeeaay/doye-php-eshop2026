<?php
use think\migration\Migrator;

/**
 * coupon 增加固定到期日 expire_at，并同步 coupon_user.status 注释
 *
 * 券有效期有两种配法：valid_days（发放后 N 天）与 expire_at（固定到期日），后者优先。
 * 营销规则要给用户发「7 天内可用」这类券，光靠活动结束时间兜底会把有效期和活动窗绑死，
 * 而活动一停已发出去的券必须继续可用（见 CouponService::heldAutoCoupons 的双层有效期口径）。
 * 存量行 expire_at 为 NULL，行为与改造前一致。
 *
 * status 注释补 3 已回收：退款回收奖励券会用到这个状态，注释漏了会让后来人以为只有三种值。
 * 两处 changeColumn 都不要传 limit：tinyinteger 默认是 tinyint(4)，一旦写成 tinyint(1)，
 * PDO 会把该列当布尔返回，status=2/3 都会被读成 1（已使用），券状态直接错乱。
 */
class AddCouponExpireAt extends Migrator
{
    /**
     * 执行迁移：追加 expire_at 列 + 更新 coupon_user.status 注释
     *
     * @return void
     */
    public function up()
    {
        $this->table('coupon')
            ->addColumn('expire_at', 'datetime', ['null' => true, 'after' => 'valid_days',
                'comment' => '券固定到期日，优先于 valid_days；两者都空时跟随活动结束时间'])
            ->update();

        $this->table('coupon_user')
            ->changeColumn('status', 'tinyinteger', ['null' => false, 'default' => 0,
                'comment' => '0 未使用 / 1 已使用 / 2 已过期 / 3 已回收（奖励券随订单退款作废）'])
            ->update();
    }

    /**
     * 回滚：删除 expire_at 列并还原 status 注释
     *
     * @return void
     */
    public function down()
    {
        $this->table('coupon_user')
            ->changeColumn('status', 'tinyinteger', ['null' => false, 'default' => 0,
                'comment' => '0 未使用 / 1 已使用 / 2 已过期'])
            ->update();

        $this->table('coupon')->removeColumn('expire_at')->update();
    }
}
