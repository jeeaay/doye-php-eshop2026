<?php
use think\migration\Migrator;

/**
 * 支付单增加折扣明细快照
 *
 * discount_lines_json 记录下单那一刻每一层优惠的名称、来源与金额，
 * 后续退款、对账、前台「优惠明细」展示都读这份快照，不再回头重算，
 * 避免活动改配置或券过期后订单金额解释不了。
 */
class AddOrderPayDiscountLines extends Migrator
{
    /**
     * @return void
     */
    public function change()
    {
        $this->table('order_pay')
            ->addColumn('discount_lines_json', 'json', [
                'null'    => true,
                'after'   => 'discount_amount',
                'comment' => '下单时的逐层优惠明细快照',
            ])
            ->update();
    }
}
