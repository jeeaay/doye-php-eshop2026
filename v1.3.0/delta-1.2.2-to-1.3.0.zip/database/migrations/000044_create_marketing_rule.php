<?php
use think\migration\Migrator;

/**
 * 创建营销规则与发放记录表
 *
 * 两张表分工：
 * - marketing_rule      规则定义（什么条件下、给谁、发什么奖励），后台可配
 * - marketing_rule_log  发放记录（幂等凭据 + 奖励金额快照 + 跳过/回收原因）
 *
 * 奖励一律落成一张 coupon_user 券，不开第二条抵扣通道；金额计算仍由 CouponService::quote() 负责。
 * 平台级数据：不带 merchant_id，仅平台超级管理员可维护。
 *
 * 币种口径：所有金额列存**基准币种**（国内版 CNY / 国际版 USD），不做换算、不存展示币种。
 */
class CreateMarketingRule extends Migrator
{
    /**
     * 执行迁移：创建 marketing_rule / marketing_rule_log
     *
     * @return void
     */
    public function change()
    {
        $rule = $this->table('marketing_rule', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '营销规则（拉新奖励 / 确认收货返利）',
        ]);
        $rule->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('name', 'string', ['limit' => 96, 'null' => false, 'comment' => '规则名，如「新人首单送 5 元券」'])
            ->addColumn('type', 'string', ['limit' => 32, 'null' => false, 'comment' => 'new_user_register_gift 注册礼 / new_user_order_gift 首单礼 / order_confirm_rebate 确认收货返利'])
            ->addColumn('trigger_event', 'string', ['limit' => 32, 'null' => false, 'comment' => 'register_success / pay_success / confirm_receipt'])
            ->addColumn('reward_mode', 'string', ['limit' => 16, 'null' => false, 'default' => 'fixed', 'comment' => 'fixed 固定金额 / percent 按比例'])
            ->addColumn('reward_value', 'decimal', ['precision' => 10, 'scale' => 2, 'null' => false, 'default' => 0, 'comment' => '基准币种金额(fixed) 或百分数(percent，10=10%)'])
            ->addColumn('reward_cap', 'decimal', ['precision' => 10, 'scale' => 2, 'null' => false, 'default' => 0, 'comment' => '比例型封顶金额，基准币种，0 表示不封顶'])
            ->addColumn('coupon_id', 'biginteger', ['signed' => false, 'null' => true, 'comment' => '奖励券模板；为空则按 inline_coupon_json 懒建一张券'])
            ->addColumn('inline_coupon_json', 'json', ['null' => true, 'comment' => '内联券定义 {name,min_amount,valid_days,expire_at}；面额由规则算出的奖励金额决定，不在此存；懒建的模板一律落 tier=30'])
            ->addColumn('condition_json', 'json', ['null' => true, 'comment' => '条件 {min_order_amount,merchant_ids[],category_ids[],product_ids[],new_user_only}；每人限次用 per_user_limit 列'])
            ->addColumn('total_limit', 'integer', ['null' => false, 'default' => 0, 'signed' => false, 'comment' => '规则级发放张数上限，0 表示不限'])
            ->addColumn('issued_qty', 'integer', ['null' => false, 'default' => 0, 'signed' => false, 'comment' => '已发放张数（含回收前的发放）'])
            ->addColumn('per_user_limit', 'integer', ['null' => false, 'default' => 1, 'signed' => false, 'comment' => '每人可获得次数，0 表示不限'])
            ->addColumn('start_time', 'datetime', ['null' => true, 'comment' => '活动开始时间，只控制是否还发新券'])
            ->addColumn('end_time', 'datetime', ['null' => true, 'comment' => '活动结束时间，过了不再发新券，但已发的券按自身有效期继续可用'])
            ->addColumn('status', 'tinyinteger', ['null' => false, 'default' => 1, 'comment' => '1 启用 / 0 停用'])
            ->addColumn('priority', 'integer', ['null' => false, 'default' => 0, 'comment' => '同一事件命中多规则时的处理顺序，小者优先'])
            ->addColumn('remark', 'string', ['limit' => 255, 'null' => true, 'comment' => '备注/使用说明'])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addIndex(['type', 'status'], ['name' => 'idx_type_status'])
            ->addIndex(['trigger_event', 'status'], ['name' => 'idx_trigger_status'])
            ->addIndex(['status', 'priority'])
            ->create();

        $log = $this->table('marketing_rule_log', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '营销规则发放记录（幂等凭据 + 奖励快照）',
        ]);
        $log->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('rule_id', 'biginteger', ['signed' => false, 'null' => false, 'comment' => '命中的规则'])
            ->addColumn('user_id', 'biginteger', ['signed' => false, 'null' => false, 'comment' => '获得奖励的用户'])
            ->addColumn('order_id', 'biginteger', ['signed' => false, 'null' => true, 'comment' => '确认收货场景的订单；注册场景为 NULL'])
            ->addColumn('order_pay_id', 'biginteger', ['signed' => false, 'null' => true, 'comment' => '支付场景的支付单；注册场景为 NULL'])
            ->addColumn('trigger_event', 'string', ['limit' => 32, 'null' => false, 'comment' => '触发事件，与 scope_key 一起表达发放来源'])
            ->addColumn('scope_key', 'string', ['limit' => 64, 'null' => false, 'comment' => '幂等作用域：user:{id} / pay:{orderPayId} / order:{orderId}'])
            ->addColumn('reward_amount', 'decimal', ['precision' => 10, 'scale' => 2, 'null' => false, 'default' => 0, 'comment' => '奖励金额快照（基准币种），规则改了也不重算'])
            ->addColumn('coupon_id', 'biginteger', ['signed' => false, 'null' => true, 'comment' => '发放使用的券模板'])
            ->addColumn('coupon_user_id', 'biginteger', ['signed' => false, 'null' => true, 'comment' => '发出的券实例'])
            ->addColumn('status', 'string', ['limit' => 16, 'null' => false, 'default' => 'pending', 'comment' => 'pending 待发放或发放失败待补偿 / granted 已到账 / skipped 不符合条件 / revoked 已回收'])
            ->addColumn('skip_reason', 'string', ['limit' => 32, 'null' => true, 'comment' => 'budget_exhausted / user_limit_exceeded / not_eligible / already_granted / error / coupon_already_used / order_refunded'])
            ->addColumn('error_msg', 'string', ['limit' => 255, 'null' => true, 'comment' => '发放异常信息，供补偿命令与排查'])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addIndex(['rule_id', 'user_id', 'scope_key'], ['unique' => true, 'name' => 'uk_grant'])
            ->addIndex(['user_id', 'status'])
            ->addIndex(['order_pay_id'])
            ->addIndex(['coupon_user_id'])
            ->addIndex(['status', 'id'])
            ->create();
    }
}
