<?php
use think\migration\Migrator;

/**
 * 退款返券记录
 *
 * 与 marketing_rule_log 语义相反：那边记「这单挣到的券」，这里记「这单花掉的券退回去了」。
 * uk_restore(order_pay_id, coupon_user_id) 保证同一笔支付单上的同一张券只退一次；
 * 金额只是对账快照，是否退回以 coupon_user.status 与过期时间判定。
 */
class CreateCouponRestoreLog extends Migrator
{
    /**
     * 执行迁移
     *
     * @return void
     */
    public function change()
    {
        $table = $this->table('coupon_restore_log', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '全额退款后退回已核销券的记录',
        ]);
        $table->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('order_pay_id', 'biginteger', ['signed' => false, 'null' => false])
            ->addColumn('user_id', 'biginteger', ['signed' => false, 'null' => false])
            ->addColumn('coupon_id', 'biginteger', ['signed' => false, 'null' => false])
            ->addColumn('coupon_user_id', 'biginteger', ['signed' => false, 'null' => false])
            ->addColumn('amount', 'decimal', ['precision' => 10, 'scale' => 2, 'null' => false, 'default' => 0, 'comment' => '下单时这张券抵扣掉的金额（对账快照）'])
            ->addColumn('status', 'string', ['limit' => 24, 'null' => false, 'default' => 'restored', 'comment' => 'restored / skipped_expired / skipped_used_again / failed'])
            ->addColumn('reason', 'string', ['limit' => 255, 'null' => true])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addIndex(['order_pay_id', 'coupon_user_id'], ['unique' => true, 'name' => 'uk_restore'])
            ->addIndex(['user_id', 'status'], ['name' => 'idx_user_status'])
            ->create();
    }
}
