# 管理 API v1

后台管理能力的 REST 入口，供脚本、CI、第三方系统调用。接口与后台页面共用同一套 Service，因此权限、校验与业务规则一致。

- Base URL：`https://<your-domain>/admin-api/v1`
- 认证：`Authorization: Bearer <API Key>`（兼容 `X-API-Key`）
- 内容类型：`application/json`；媒体上传用 `multipart/form-data`
- 限流：默认 120 次/分钟/IP（`RateLimit` 中间件）

---

## 1. 创建 API 密钥

登录后台 → 左侧「密钥管理」→ 创建密钥 → **立即保存明文**（只显示一次）。

密钥权限实时继承所属账号：账号被停用、降权或解绑商户后，密钥立即同步失效或降权。

---

## 2. 响应约定

成功：

```json
{ "code": 0, "message": "ok", "data": { } }
```

业务失败（HTTP 200）：

```json
{ "code": 1, "message": "商品名称不能为空", "data": null }
```

| HTTP | 场景 | Body |
|---|---|---|
| 200 | 成功 / 业务失败 | `{code:0}` / `{code:1}` |
| 401 | 未认证、密钥无效/过期/吊销、账号停用 | `{code:401,"message":"未认证或密钥无效"}` |
| 429 | 超过限流 | `{code:429,"message":"请求过于频繁"}` |

分页响应：

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "list": [],
    "total": 0,
    "page": 1,
    "page_size": 20
  }
}
```

- `page` 默认 1；`page_size` 默认 20，最大 100。
- 时间格式 `Y-m-d H:i:s`；金额为字符串两位小数。

---

## 3. 身份与密钥

### GET /me

返回当前账号与密钥信息。

```bash
curl -s "$BASE/me" -H "Authorization: Bearer $KEY"
```

```json
{
  "code": 0,
  "message": "ok",
  "data": {
    "admin_id": 1,
    "username": "admin",
    "role": "super",
    "merchant_ids": [],
    "auth_source": "api_key",
    "api_key": { "id": 1, "name": "deploy-bot", "key_prefix": "dak_1a2b3c4d", "expires_at": null, "last_used_at": "2026-10-28 10:00:00" }
  }
}
```

### 密钥自助

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/keys` | 列出自己的密钥（不含明文/哈希） |
| POST | `/keys` | 创建，body `{name, expires_in_days?}`；明文只返回一次 |
| DELETE | `/keys/:id` | 删除自己的密钥 |

---

## 4. 媒体上传

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/media/upload` | multipart：`file`、`type=image|video`、`namespace=products|brands|pages|merchants` |
| POST | `/media/base64` | `{data:"data:image/png;base64,...", type, namespace}` |
| POST | `/media/import` | `{url:"https://...", type, namespace}` |

返回：

```json
{ "code": 0, "message": "上传成功", "data": { "url": "/uploads/products/images/202610/abc.png", "mime": "image/png", "size": 68, "width": 1, "height": 1 } }
```

限制：

- 图片：jpg/png/webp，≤ 10MB；视频：mp4/webm，≤ 200MB。
- 外链导入仅 http/https，最多 3 次跳转，拒绝内网/环回地址，超时 10 秒。
- 商品接口的媒体字段也接受本地 `/uploads/...`、外链、`data:` 三种形态，服务端自动转存。

---

## 5. 商品

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/products` | `keyword`、`category_id`、`status`、`merchant_id`、`page`、`page_size` |
| GET | `/products/:id` | 详情（含 specs、skus、媒体） |
| POST | `/products` | 创建 |
| PUT | `/products/:id` | 更新（建议提交完整字段） |
| DELETE | `/products/:id` | 软删除 |
| POST | `/products/:id/status` | `{status:0|1|2}` |
| GET | `/products/:id/translations` | 全部语种译文（含草稿） |
| PUT | `/products/:id/translations/:lang` | 保存/更新单语种译文 |
| POST | `/products/:id/translations/:lang/publish` | 发布该语种 |
| POST | `/products/:id/translations/:lang/ai` | 该语种加入 AI 翻译队列 |

创建示例：

```bash
curl -s -X POST "$BASE/products" \
  -H "Authorization: Bearer $KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Laser Tape",
    "category_id": 3,
    "merchant_id": 1,
    "brand_id": 0,
    "main_image": "https://cdn.example.com/a.jpg",
    "images_json": ["data:image/png;base64,...", "/uploads/products/images/202610/abc.png"],
    "video_url": "https://cdn.example.com/a.mp4",
    "video_cover": "/uploads/products/images/202610/cover.png",
    "detail_html": "<p>Product description</p>",
    "status": 1,
    "sort": 0,
    "specs_json": [{"name": "Color", "values": ["Black", "White"]}],
    "skus": [
      {"spec_name": "Black", "spec_values_json": {"Color": "Black"}, "price": "9.90", "stock": 10, "sku_code": "LT-BK", "status": 1}
    ],
    "spec_change_confirmed": 0
  }'
```

- `status`：0 草稿、1 上架、2 下架。
- 更新时若修改规格结构，必须显式传 `spec_change_confirmed: 1`，否则返回 `code=1`。
- 展示图最多 10 张。
- 商户管理员不能指定非本人绑定的 `merchant_id`。
- 高级 SEO 字段：`seo_title`、`seo_description`、`seo_keywords`、`tags`（数组或逗号分隔字符串）、
  `published_at`（`YYYY-MM-DD HH:MM:SS` 或 `YYYY-MM-DDTHH:MM`）、`seo_noindex`（1 表示禁止索引并从 sitemap 排除）。
  这些字段留空时会回退商品名称/副标题/详情摘要。
- 自定义访问路径：`custom_path`（如 `laser-cutter.html`，留空表示沿用 `/products/{id}`）、
  `custom_path_root`（1 表示同时注册为根级路径 `/{custom_path}/`）。保存时统一归一化并校验：
  格式 `[a-z0-9\-]+(\.html)?`、长度 ≤190、不能是纯数字（含 `123.html`，会与商品 ID 路径冲突）、
  不得命中系统保留路径（`products`、`cart`、`about` 等）、
  不得与内容单页 slug 重名、全局唯一（跨商户）。校验失败返回 `code=1` + 中文提示。
  填写后 `GET /products/:id` 的返回体同样包含这两个字段，前台链接与 canonical 会改用自定义路径。

### 5.1 商品多语种翻译

主表只保存英文；其他语种通过翻译副表维护。`POST/PUT /products` 也可以在请求体里带上
`translations` 对象，与商品基础字段在同一事务内保存。

```json
{
  "translations": {
    "ru": {
      "title": "Лазерная лента",
      "subtitle": "Краткое описание",
      "detail_html": "<p>Описание</p>",
      "seo_title": "Лазерная лента",
      "seo_description": "Описание для поиска",
      "specs_json": [{"name": "Цвет", "values": ["Чёрный", "Белый"]}],
      "status": 1
    }
  }
}
```

- `title/subtitle/seo_title/seo_description` 超长会返回 `code=1`；`detail_html` 会走白名单过滤。
- 空字符串表示「回退英文」，不会覆盖成空页面。
- `status`：0 草稿、1 已发布。省略时新建默认 1，更新时保留原状态。
- `source`：`manual` / `ai`，省略时新建默认 `manual`，更新时保留原值。
- `specs_json` 必须与主表 `specs_json` **同序**，渲染时按索引对齐。
- 译文缺失或未发布时，前台逐字段回退英文。

单独保存一个语种：

```bash
curl -s -X PUT "$BASE/products/12/translations/ru" \
  -H "Authorization: Bearer $KEY" \
  -H "Content-Type: application/json" \
  -d '{"title":"Лазерная лента","detail_html":"<p>Описание</p>","status":1}'
```

发布：

```bash
curl -s -X POST "$BASE/products/12/translations/ru/publish" \
  -H "Authorization: Bearer $KEY"
```

AI 翻译（异步）：

```bash
curl -s -X POST "$BASE/products/12/translations/ru/ai" \
  -H "Authorization: Bearer $KEY" \
  -H "Content-Type: application/json" \
  -d '{"force":1}'
```

- 返回 `{ job_ids: [123], queued: true }`。
- 需要后台已配置 `translation.base_url` / `api_key` / `model`，并运行 `php think translate:work`。
- `force=1` 会忽略「译文已是最新」的跳过逻辑；人工译文仍会被覆盖，请谨慎。
- 默认由 `i18n.auto_publish_ai` 决定 AI 结果是否直接发布。

> 单独保存接口只接受一个语种；批量保存请直接用 `PUT /products/:id` 的 `translations` 字段。

### 5.2 AI 翻译任务

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/translation-jobs` | 任务列表；`status`、`entity_type`、`entity_id`、`page`、`page_size` |
| POST | `/translation-jobs/:id/retry` | 重置并重新入队 |
| POST | `/translations/backfill` | 批量补全；`type=product|category|brand|page|all`、`lang`、`limit`、`force` |

> 任务列表、重试、批量补全仅平台超管可用；商品单条 AI 翻译按商品所属商户校验范围。

---

## 6. 分类 / 品牌

### 分类

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/categories` | 默认返回树；`flat=1` 返回平铺 |
| POST | `/categories` | `{name, parent_id, sort}`，仅超管 |
| PUT | `/categories/:id` | 更新，仅超管 |
| DELETE | `/categories/:id` | 删除，仅超管 |

### 品牌

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/brands` | `name`、`merchant_id`、分页 |
| GET | `/brands/options` | `merchant_id` 下拉选项 |
| POST | `/brands` | `{name, merchant_id}` |
| PUT | `/brands/:id` | 更新 |
| DELETE | `/brands/:id` | 删除 |
| POST | `/brands/:id/status` | `{status:0|1}` |

---

## 7. 订单

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/orders` | `status`、`order_no`、`phone`、`merchant_id`、分页 |
| GET | `/orders/:order_no` | 详情（商品、地址、买家） |
| POST | `/orders/:order_no/ship` | `{shipping_no, shipping_company, delivery_method}` |
| POST | `/orders/:order_no/deliver` | 标记送达 |

- `delivery_method`：`express` / `self`；快递发货时物流单号与公司必填。
- 商户管理员只能访问自己商户的订单。

### 7.1 售后退款重试

售后审核通过 / 确认收货时由服务端真正发起退款（微信通道），结果写在 `refund_log`：

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | `/aftersales/:id/refund-retry` | 上次退款失败时重试；复用同一退款单号，不会二次出款 |

- 退款状态：`pending` 待发起 / `requesting` 结果待确认 / `success` 成功 / `failed` 失败。
- **`requesting` 不提供自动重试**：请求已发出但结果未知，请到微信商户后台核对；
  该状态下再调本接口只会返回「结果待确认」，不会再次出款。
- 非微信通道（Stripe/PayPal）不支持后台自动退款，接口返回明确指引（去渠道后台操作，不触发自动返券）。
- 退款成功才会把订单置为已退款并回收该单奖励券；重复卡顿不会把订单提前标成退款。
- 商户管理员只能操作自己商户的售后。

### 7.2 商品评论（后台审核）

前台提交走 `/api/review/*`；后台页面 `/console/reviews` 与本组接口共用 `ReviewService`，权限、校验与事务口径一致。

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/reviews` | `keyword`、`status`、`rating`、`product_id`、`start_date`、`end_date`、分页 |
| GET | `/reviews/:id` | 评论详情 |
| POST | `/reviews/status` | `{ids:[1,2], status:1\|2\|3}`，批量修改状态（也接受单个 `id`） |
| POST | `/reviews/:id/reply` | `{reply:"..."}`，≤2000 字 |
| DELETE | `/reviews/:id` | 硬删除评论及其投票，不可恢复 |

```bash
# 批量通过
curl -s -X POST "$BASE/reviews/status" \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"ids":[12,13],"status":1}'

# 后台回复
curl -s -X POST "$BASE/reviews/12/reply" \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"reply":"感谢反馈，已记录并改进。"}'
```

- `status`：`0` 待审核 / `1` 已通过（前台可见）/ `2` 已拒绝 / `3` 已隐藏；状态修改只接受 `1|2|3`。
- `keyword` 覆盖评论标题/正文、作者昵称/邮箱、商品名与订单号；`rating` 为 1–5；`start_date` / `end_date` 仅接受 `YYYY-MM-DD`。
- 分页为 `{list,total,page,page_size}`；`page_size` 默认 20、最大 100；`ids` 单次最多 200 条。
- 列表/详情字段：`id`、`product_id`、`product_title`、`product_image`、`merchant_id`、`user_id`、`user_nickname`、`user_email`、
  `order_no`、`order_item_id`、`rating`、`title`、`content`、`images`、`is_anonymous`、`is_verified`、`status`、`status_label`、
  `helpful_yes`、`helpful_no`、`admin_reply`、`replied_by`、`replied_at`、`create_time`、`update_time`。
- 权限：`super` 全部；`merchant_admin` / `staff` 只能看到并操作本人 `merchant_ids` 名下商品的评论，
  越权返回「评论不存在或无权操作」（防 ID 枚举）。`replied_by` 记录当前 API 密钥所属管理员 ID。
- 删除为硬删除（连带 `product_review_vote`），不可恢复；写操作自动进入 `admin_audit_log`（模块 `reviews`）。

---

## 8. 优惠活动

超管与商家共用同一批端点，可见范围与写权限由服务端按登录身份收敛（与后台「优惠管理」页同口径）：

- `super`：全部记录可读写，可按 `merchant_id` 筛选；
- `merchant_admin` / `staff`：**读** = 本店记录 + 平台记录（`merchant_id` 为 `null`，只读可见）；
  **写** = 仅本店记录。读他店记录、写他店记录一律返回「优惠不存在」（防 ID 枚举）；
  写平台记录返回「平台优惠不可修改，如需本店促销请新建优惠」。
- 未绑定商户的商家账号：列表为空集，创建时报「当前账号未绑定商户」。

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/coupons` | `keyword`、`apply_type`、`status`、`merchant_id`（仅超管生效）、分页 |
| GET | `/coupons/:id` | 详情（含 `product_ids`） |
| POST | `/coupons` | 创建 |
| PUT | `/coupons/:id` | 更新 |
| POST | `/coupons/:id/status` | `{status:0|1}` |
| DELETE | `/coupons/:id` | 删除 |

创建示例：

```bash
curl -s -X POST "$BASE/coupons" \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{
    "name": "满 100 减 10",
    "apply_type": "claim",
    "discount_type": "fixed",
    "discount_value": "10",
    "min_amount": "100",
    "scope": "all",
    "total_qty": 100,
    "per_user_limit": 1,
    "valid_days": 30,
    "status": 1
  }'
```

字段说明见 `app/common/service/CouponService::adminSave()`。

### 归属商户（merchant_id）

- 请求里的 `merchant_id` **只对超管有效**；商家传任何值（包括别的商户 ID）都会被服务端忽略并覆盖成本人所属商户，
  更新时沿用原归属，不会因提交者不同而迁移商户。
- 列表与详情响应补 `merchant_id` / `merchant_name`（平台记录 `merchant_name` 为「平台」）/ `can_write`，
  前端按 `can_write` 决定按钮是否渲染，不要靠猜角色。
- `scope=product` 时，提交的 `product_ids` 必须全部属于该优惠的归属商户，否则报「本店优惠只能选择本商户的商品」。
- **`merchant_id` 非空的优惠（不分层级）只抵扣该商户的商品行**：门槛与减免额的计算基数都按归属商户过滤，
  所以一张商家券出现在别的商户购物车里时可用额度为 0，提示「购物车中没有该优惠适用的商品」。

### 层级（tier）

结算时按层级由低到高依次叠加，前一层扣完的余额再给下一层；`min_amount` 门槛始终按原价小计判定：

| tier | 含义 | 允许的 apply_type | 生效方式 |
|---|---|---|---|
| 10 | 商家折扣 | `auto` | 命中商户商品自动生效 |
| 20 | 平台活动 | `auto` | 全站自动生效，不落用户券记录 |
| 30 | 自动到账券 | `claim` | 系统发券到账后自动抵扣，`auto_apply` 恒为 1 |
| 40 | 手动券 / 优惠码 | `claim`、`code` | 用户在结算页选一张或输一个码 |

不传 `tier` 时按 `(apply_type, merchant_id)` 推导：`auto` + 商户 → 10、`auto` + 平台 → 20、`claim|code` → 40，
与历史数据回填口径一致。**30 层只能由营销规则写入**，在本接口显式传 `tier=30` 会被拒绝。
商家侧新建只放开「本店券」（`claim` / `code`）；`auto` 对新配置关闭，需平台创建，
但**存量归属本店的 `tier=10` 自动折扣仍可被该商家编辑与启停**。
30 层只看券实例的 `coupon_user.expire_time`：活动停了只影响继续发券，已到账的券到自己的有效期为止仍可用。
下单时逐层明细写进 `order_pay.discount_lines_json`，退款与前台展示都读这份快照，不回头重算。

---

## 8.1 营销规则（拉新奖励 / 确认收货返利）

**仅平台超管**。营销规则是平台级能力，商家账号读写一律返回「营销规则不存在」（与读他店优惠同口径，防 ID 枚举），
列表返回空集；后台「营销规则」页与管理 API 走同一批 `MarketingService` 方法，权限收口在 Service。

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/marketing/rules` | `keyword`、`type`、`status`、分页 |
| GET | `/marketing/rules/:id` | 详情 |
| POST | `/marketing/rules` | 创建 |
| PUT | `/marketing/rules/:id` | 更新 |
| POST | `/marketing/rules/:id/status` | `{status:0|1}` |
| DELETE | `/marketing/rules/:id` | 删除 |
| GET | `/marketing/rules/:id/logs` | 该规则的发放记录 |
| GET | `/marketing/logs` | 跨规则发放记录：`rule_id`、`user_id`、`order_id`、`status`、分页 |

类型与触发事件（`trigger_event` 由类型决定，传不匹配的组合报「「xxx」不支持该触发事件」）：

| type | 含义 | trigger_event | 说明 |
|---|---|---|---|
| `new_user_register_gift` | 注册礼 | `register_success` | 注册成功即发券，拉第一单转化 |
| `new_user_order_gift` | 首单礼 | `pay_success` | 首笔支付成功后发券，默认只发给此前没有成交记录的新人 |
| `order_confirm_rebate` | 确认收货返利 | `confirm_receipt` | 确认收货（手动与自动同一条路径）后按该单实付金额发放 |

创建示例（比例奖励 + 封顶 + 内联券）：

```bash
curl -s -X POST "$BASE/marketing/rules" \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{
    "name": "新人首单返 10%",
    "type": "new_user_order_gift",
    "trigger_event": "pay_success",
    "reward_mode": "percent",
    "reward_value": "10",
    "reward_cap": "20",
    "inline_coupon": {"valid_days": 30, "min_amount": "0"},
    "condition_json": {"min_order_amount": "50", "new_user_only": 1},
    "total_limit": 1000,
    "per_user_limit": 1,
    "start_time": "2026-01-01 00:00:00",
    "end_time": "2026-12-31 23:59:59",
    "priority": 0,
    "status": 1
  }'
```

字段口径：

- `reward_mode`：`fixed`（`reward_value` 为立减金额）或 `percent`（`reward_value` 为百分比，可配 `reward_cap` 封顶，
  `0` 表示不封顶）。金额与比例都按基准币种两位小数存，`fixed` 时 `reward_cap` 恒为 `0.00`。
- 奖励载体二选一：`coupon_id` 引用已有券模板（只能引用 tier 30 自动到账券 / tier 40 手动券，
  活动类优惠请直接配活动），或 `inline_coupon`（`name`/`min_amount`/`valid_days`/`expire_at`）在发放时懒生成 tier 30 券。
  两者都不给时报「优惠券有效期需填「发放后 N 天」或「固定到期日」其中之一」。
- `condition_json`：`min_order_amount`（判定口径见 `eligibility()`）、`new_user_only`（缺省：首单礼为 `true`，其余 `false`）、
  `merchant_ids` / `product_ids` / `category_ids`（限定适用范围，空=不限）。
- `total_limit` 是规则级发放总量上限（`0` = 不限），`per_user_limit` 是每人可获得次数（缺省 1）。
- `start_time` / `end_time` 只约束「活动是否继续发券」；已到账的券按券自身的有效期可用，两者互不覆盖。
- 列表与详情响应补 `reward_text`（如「实付 10%（封顶 20.00）」「立减 5.00」）、`trigger_label`、`coupon_name`、
  `granted_logs`（实际到账张数，非 `issued_qty`）；发放记录补 `rule_name`、`status_label`、`skip_label`。

发放侧不变量（改动前先看 `MarketingService` 类注释）：奖励一律以券到账，**不产生任何现金出口**；
`uk_grant(rule_id, user_id, scope_key)` 先占键再发放，重复通知/并发触发只会得到「已发放过」；
发券失败写 `status=pending`，由 `php think marketing:grant` 补偿重放；发放异常一律吞在引擎内，
**不得拖垮注册、支付通知、确认收货主流程**。

---

## 8.2 批量发券（圈选人群 → 发券任务 → 到账通知）

**仅平台超管**。与「营销规则」同属平台能力，非超管一律返回「发券任务不存在」（防 ID 枚举）。

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/marketing/grants` | `keyword`、`audience_type`、`status`、分页 |
| GET | `/marketing/grants/:id` | 详情：进度、最近 50 条发放记录、通知统计 |
| POST | `/marketing/grants` | 创建 |
| PUT | `/marketing/grants/:id` | 更新（仅 `pending` / `paused`） |
| DELETE | `/marketing/grants/:id` | 删除（仅 `pending` / `canceled`） |
| POST | `/marketing/grants/preview` | `{audience_type, audience}` → `{count}`，只统计不发放 |
| POST | `/marketing/grants/:id/run` | 推进一步（`batch_size` 可选），未完成自动续排下一批 |
| POST | `/marketing/grants/:id/cancel` | 取消，已发出的券不受影响 |
| POST | `/marketing/grants/:id/revoke` | 作废该任务发出的**未使用**券，已核销的不追 |
| POST | `/marketing/grants/:id/resend` | 失败/待发通知重新入队（`limit` 默认 100） |

人群方式（`audience_type`）：

| 值 | 含义 | `audience` 参数 |
|---|---|---|
| `all` | 全站注册用户 | — |
| `purchased` | 有过已支付订单的用户 | `days`（0=不限时间窗）、`min_amount`（0=不限） |
| `merchant_customers` | 指定商户下过单的用户 | `merchant_ids`（**必填**，空报错，不会退化为全站） |
| `import` | 名单导入（CSV 首列 / 粘贴） | `import_list`：每行一个邮箱或用户 ID，重复自动去重；无账号的邮箱记 `no_account` 跳过 |

创建示例：

```bash
curl -s -X POST "$BASE/marketing/grants" \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{
    "name": "老客回馈 5 美元券",
    "coupon_id": 12,
    "audience_type": "purchased",
    "audience": {"days": 90, "min_amount": "50"},
    "batch_size": 500,
    "start_time": "2026-12-01 00:00:00",
    "end_time": "2026-12-31 23:59:59"
  }'
```

字段与不变量：

- `coupon_id` 只能引用 tier 30（自动到账券）/ tier 40（手动券），活动类优惠直接配活动。
- 每人一条 `marketing_grant_log`，`uk_grant_user(grant_id,user_id,email)` 是幂等键：
  重复点击执行、进程重启、重复导入都不重复发；券模板自身的 `per_user_limit` 继续生效。
- 每批默认 500（上限 2000），只取主键游标推进；任务行每批写回一次计数。
- `start_time`/`end_time` 只控制还能不能发，已发出的券按自身有效期可用。
- 券到账/到期提醒/退款退回三类事务性邮件全走延迟队列，SMTP 失败只记 `marketing_notify_log`，
  不影响发券；`mail.enabled=false` 时通知记 `failed`，后台与 `resend` 可重放（每券最多 3 次）。
- 到期提醒由 `php think marketing:remind` 每日执行（提前天数取 `marketing.remind_days`，默认 3）。

---

## 9. 首页运营（活动 / 推荐位）

仅平台超管。类型：`banners`、`categories`、`notices`、`topics`、`products`。

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/home-ops` | 聚合返回 5 类数据 |
| POST | `/home-ops/:type` | 创建 |
| PUT | `/home-ops/:type/:id` | 更新 |
| DELETE | `/home-ops/:type/:id` | 删除 |
| POST | `/home-ops/:type/:id/status` | `{status:0|1}` |

Banner 示例：

```bash
curl -s -X POST "$BASE/home-ops/banners" \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"image":"https://cdn.example.com/banner.jpg","title":"Autumn Sale","link_type":"none","sort":0,"status":1}'
```

各类型字段与 `HomeOpsService::save*()` 一致。

---

## 9.1 站点单页（CMS）

平台级内容（配送说明、退换货、隐私政策、服务条款、Cookie 政策、关于我们等），**仅平台超管**。

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/pages` | 列表；`title`、`status`、`page`、`page_size`，返回 `content_length` 不返回正文 |
| GET | `/pages/:id` | 详情（含 `content` 富文本与 SEO 字段） |
| POST | `/pages` | 创建；必填 `title`、`slug` |
| PUT | `/pages/:id` | 更新（**建议提交完整字段**：缺 `content` 会被清空） |
| POST | `/pages/:id/status` | `{"status":0\|1}` |

```bash
curl -s -X POST "$BASE/pages" \
  -H "Authorization: Bearer ***" -H "Content-Type: application/json" \
  -d '{
    "title": "Shipping Information",
    "slug": "shipping",
    "content_type": "database",
    "content": "<p>Almi ships from regional warehouses…</p>",
    "seo_title": "Shipping Information: Delivery Times, Costs & Tracking",
    "seo_description": "Delivery times, shipping costs, tracking and what happens if a parcel is delayed.",
    "seo_keywords": "almi shipping, delivery times, order tracking",
    "status": 1,
    "sort": 10
  }'
```

- `slug`：`^[a-z0-9]+(?:-[a-z0-9]+)*$`，不能是 `products` / `cart` / `checkout` / `login` / `account` / `order-success` / `admin` / `api` / `index` / `home` 等保留字，全局唯一；前台地址即 `/<slug>`。
- `content_type`：`database`（富文本，默认）或 `template`（内置模板 `about` / `service` / `contact` / `page`，需同时传 `template_file`）。
- `content` **按原始 HTML 保存，不做二次过滤**（与后台富文本编辑器一致），因此该接口只对平台超管开放。注意主题没有 `.cms-content` 的表格样式，需要表格时自带内联样式。
- 记录不存在或 `status=0` 时，前台渲染占位文案「This page is not configured yet」。
- 标题会被模板自动追加 ` - <品牌名>`：`seo_title` 里不要再写品牌名，否则出现 `… | Almi - Almi`。

## 10. 系统设置

仅平台超管。

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/settings` | 返回分组与字段；敏感项只返回 `has_value` |
| POST | `/settings/:group` | 保存整组，body `{values:{...}}` 或平铺 |

```bash
curl -s -X POST "$BASE/settings/basic" \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"values":{"brand.name":"Almi","currency.code":"USD"}}'
```

---

## 10.1 币种与汇率

仅平台超管。订单/支付/退款/结算始终 USD，这里的币种只影响前台参考价。

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/currencies` | 全部币种（含停用） |
| POST | `/currencies` | 新增币种 |
| PUT | `/currencies/:id` | 更新名称/符号/小数位/状态/人工汇率 |
| DELETE | `/currencies/:id` | 删除币种（基准 USD 不可删） |
| POST | `/currencies/:id/rate/refresh` | 拉取该币种最新汇率 |
| PUT | `/currencies/:id/rate/override` | 设置人工汇率 `{rate:0.92}` |
| DELETE | `/currencies/:id/rate/override` | 清除人工汇率，恢复自动值 |
| GET | `/currency-rates` | 汇率历史；`currency`、`limit` |

```bash
# 刷新 EUR 汇率
curl -s -X POST "$BASE/currencies/2/rate/refresh" -H "Authorization: Bearer $KEY"

# 设置人工汇率
curl -s -X PUT "$BASE/currencies/2/rate/override" \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"rate":0.92}'

# 查看历史
curl -s "$BASE/currency-rates?currency=EUR&limit=20" -H "Authorization: Bearer $KEY"
```

- 同步失败或单日变动超过 `currency.sanity_percent`（默认 10%）时，该币种保留旧汇率，日志状态为 `rejected`。
- 拒绝记录会写入日志，并在配置了 `currency.alert_email` 时发送邮件（邮件服务未启用则只写日志）。
- 同一天同一币种同来源只保留一条日志（重复刷新会更新当天记录）。

---

## 10.2 站点版本

仅平台超管。用于两套独立部署选择运行形态：

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/edition` | 当前版本、是否已初始化、建议版本、基准语言/币种、商品数、订单数 |
| PUT | `/edition` | 选择/切换版本 |

```bash
curl -s -X PUT "$BASE/edition" \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"edition":"domestic","confirmed":true,"phrase":"SWITCH"}'
```

- `edition`：`international` / `domestic`
- `confirmed`：切换或首次初始化时必须为 true
- `phrase`：必须为 `SWITCH`
- **未初始化（1.0.6 升级或新部署）时允许有历史订单，仍可一次性选择版本**；
  选择后按版本回填 `order.charge_currency` / `order_pay.charge_currency`
- **已初始化且有历史订单时禁止切换**
- 普通切换不会自动换算价格或翻译内容
- `GET` 返回 `edition` 为 `unset` 表示尚未初始化，`suggested_edition` 为按支付渠道给出的建议

---

## 11. 审计日志

仅平台超管。

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/audit-logs` | `admin`、`module`、`action`、`source`、`result`、`from`、`to`、分页 |
| POST | `/audit-logs/purge` | `{days:7|30|365, confirm:1}`，删除早于 N 天的日志 |

`purge` 不可恢复；清理动作本身也会写入审计日志。

---

## 12. 系统更新

在线增量升级：检查更新、规划批次、逐步骤执行、失败重试与整批回滚。

分发地址固定：清单与资产从 `config/update.php` 的 `distribution` 分组里硬编码的 raw 地址拉取
（顺序 `gitee` → `github`，前一个失败自动切下一个）。后台「系统设置 → 更新设置」只保留
启用开关、备份保留份数、维护窗口开关，**没有**仓库地址 / 分支 / token 字段，API 也不提供修改入口（防 SSRF）。

**认证与权限**

- 认证同其它端点：`Authorization: Bearer <API Key>`（兼容 `X-API-Key`）。
- **仅平台超管可用**：非 `super` 调用返回 `{code:1,"message":"仅平台超级管理员可执行此操作"}`。
- 写操作自动写入 `admin_audit_log`：管理 API 对应模块 `updates`，后台页面 `/admin/update/*` 对应模块 `update`；动作取路径末段（`check` / `plan` / `step` / `retry` / `rollback`，`GET /updates/latest` 记为 `other`）。
- 业务编排与后台页面（「系统设置 → 更新设置」，`/admin/update/*`）共用 `UpdateService`，因此校验规则、错误消息与页面完全一致。

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/updates/latest` | 检查更新（强制回源，跳过 10 分钟缓存） |
| POST | `/updates/plan` | 规划升级：校验资产/磁盘/权限并创建批次 |
| POST | `/updates/step` | 执行下一个待处理步骤（一次请求一步） |
| POST | `/updates/retry` | 回滚失败的步骤后重跑同一步 |
| POST | `/updates/rollback` | 整批回滚（文件 + `version.json`） |
| GET | `/updates/history` | 更新历史（分页） |
| GET | `/updates/batches/:id` | 批次详情 + 步骤列表 |

### GET /updates/latest

无参数。每次调用都会重新拉取 `update.json` 并验签（不读缓存），用于人工确认最新状态。

```bash
curl -s "$BASE/updates/latest" -H "Authorization: Bearer $KEY"
```

`data` 结构：

```json
{
  "current": "1.1.0",
  "latest": "1.2.0",
  "update_available": true,
  "php_ok": true,
  "total_size": 52311,
  "steps": [
    { "seq": 1, "from": "1.1.0", "to": "1.2.0", "size": 52311 }
  ],
  "source": "gitee",
  "checked_at": "2026-10-28 10:00:00",
  "blocked_reason": null,
  "message": "发现 1 个待安装版本"
}
```

`blocked_reason` 取值（非 `null` 时 `update_available=false`）：

| 值 | 含义 | 处理 |
|---|---|---|
| `disabled` | 站点关闭了在线更新 | 在「系统设置 → 更新设置」开启 |
| `unknown_version` | 读不到有效的 `version.json` | 手工部署，或先写入当前版本号 |
| `network` | 所有分发源都拉不到清单 | 检查外网连通性；分发地址固定写在 `config/update.php`，站点侧不可改 |
| `signature` | 清单验签失败 | 核对 `config/update.php` 的 `public_key`，不要忽略 |
| `broken_chain` | 当前版本不在链上 | 按 README 手工部署到链上版本 |
| `php_too_old` | 新版本要求更高的 PHP | 先升级 PHP |
| `db_breaking` | 目标版本含不可回滚的迁移 | 备份数据库后手工升级 |
| `up_to_date` | 已是最新版本 | 无需操作 |

### POST /updates/plan

无请求体。会**强制回源**（不信任缓存），并对每个 step 的 `asset` / `ops_asset` 做 `HEAD` 探测；
任何资产在两个源上都不可达、磁盘不足、目录不可写、缺少 `zip` / `sodium`（或 `openssl`）扩展都会直接中止，**不改动任何文件**。

```bash
curl -s -X POST "$BASE/updates/plan" -H "Authorization: Bearer $KEY"
```

```json
{
  "batch_id": 12,
  "from": "1.1.0",
  "to": "1.2.0",
  "steps": [
    { "seq": 1, "from": "1.1.0", "to": "1.2.0", "size": 52311 }
  ],
  "total_size": 52311,
  "source": "gitee"
}
```

错误场景：

| 场景 | `message` 示例 |
|---|---|
| 已有未完成批次（`planned` / `running` / `failed`） | 已有未完成的更新批次（1.1.0 → 1.2.0，状态：已失败），请先完成该批次或回滚后再重新规划 |
| 读不到版本文件 | 未找到有效的 version.json，无法规划升级；请先手工部署到支持在线更新的版本 |
| 已是最新 | 当前已是最新版本（1.2.0），无需升级 |
| 验签失败 / 源不可达 | 无法获取更新清单（已尝试 Gitee、GitHub）：… |
| 断链 | 当前版本 1.0.0 不在更新链上，无法增量升级，请手工部署最新完整包 / 更新链不连续：缺少从 1.1.0 出发的增量包，请手工部署最新完整包 |
| `db_breaking` | 版本 x.y.z 含数据库结构变更（迁移不可回滚），不支持一键升级… |
| 资产缺失 | 更新包在分发源上不可用，已中止（未改动任何文件）：… |

### POST /updates/step

请求体（JSON，也接受表单 / query）：

| 字段 | 必填 | 说明 |
|---|---|---|
| `batch_id` | 是 | `plan` 返回的批次 ID |

一次请求只执行一个步骤，循环调用直到 `done=true`。步骤内容包括：下载 → 校验 `sha256` → 解压 → 备份 → 覆盖 → `vendor` 切换 → `migrate:run` → 清缓存 → 原子写 `version.json`。

```bash
curl -s -X POST "$BASE/updates/step" \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"batch_id":12}'
```

```json
{
  "done": false,
  "step": { "seq": 1, "from": "1.1.0", "to": "1.2.0", "status": "success", "ops_total": 37, "conflicts": 0 },
  "batch": { "status": "running", "progress": 1, "total_steps": 2, "current_step": 1 },
  "message": "第 1 步（1.1.0 → 1.2.0）已完成"
}
```

上面这段 JSON 就是响应的 `data` 字段。最后一步返回 `done=true`、`batch.status="success"`。中断（杀死请求、关掉页面）后重新调用即可续跑，已成功的步骤不会重做。

错误场景：

| 场景 | `message` 示例 |
|---|---|
| 缺参数 | 缺少参数 batch_id |
| 批次不存在 | 更新批次不存在 |
| 状态不允许（如已回滚/已完成） | 该批次当前状态为「已回滚」，不能执行下一步 |
| 没有待执行步骤 | 没有待执行步骤：该批次可能已全部完成，请刷新后查看 |
| 批次起点与磁盘版本不一致 | 第 1 步（1.1.0 → 1.2.0）与站点当前版本 1.3.0 不一致，已中止本步；请刷新页面… |
| 锁被占用 | 另一个更新任务正在执行，请稍后重试 |
| 清单漂移 | 更新清单已变化（1.1.0 → 1.3.0），请重新检查更新并规划 |
| 下载/哈希失败 | 第 1 步（1.1.0 → 1.2.0）增量包下载失败：Gitee 校验失败、GitHub 校验失败 |
| 迁移失败 | 第 1 步（1.1.0 → 1.2.0）数据库迁移失败：… |

失败时所属 step 置 `failed`、批次置 `failed`，现场（`runtime/update/stage`、`runtime/update/backup`）保留供排查。

### POST /updates/retry

请求体同 `step`（`{batch_id}`）。先对失败/中断的步骤做一次还原（`restoreStep`），再重跑同一步；已成功的步骤不受影响。

```bash
curl -s -X POST "$BASE/updates/retry" \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"batch_id":12}'
```

返回结构同 `step`。允许的批次状态：`planned` / `running` / `failed`；其它状态返回「该批次当前状态为「…」，不能重试」。

### POST /updates/rollback

请求体 `{batch_id}`。按 `seq` 倒序还原所有已执行步骤的文件，再从 `runtime/update/backup/{batch_no}/version.json` 还原版本号。

```bash
curl -s -X POST "$BASE/updates/rollback" \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{"batch_id":12}'
```

```json
{ "code": 0, "message": "ok", "data": { "restored_files": 37, "version": "1.1.0", "migrated": false, "status": "rolled_back" } }
```

（完整响应含外层 `{code,message,data}`；`status` 由控制器固定补为 `rolled_back`。）

- 允许的批次状态：`success` / `failed` / `running`；其它状态返回「该批次当前状态为「…」，不能回滚」。
- `migrated=true` 表示该批次跑过数据库迁移：**迁移不会回滚**，返回消息会明确提示「数据库结构未回滚（迁移只能向前）」。
- 回滚依赖本地备份；`runtime/update/backup` 被清理后**直接报错**（「本批次无法自动回滚：… 已不存在」），
  不会再「报告回滚成功但文件和版本号都没动」，此时只能手工重装。

### GET /updates/history

| 参数 | 类型 | 默认 | 说明 |
|---|---|---|---|
| `page` | int | 1 | 页码 |
| `page_size` | int | 10 | 每页条数，最大 100 |

```bash
curl -s "$BASE/updates/history?page=1&page_size=10" -H "Authorization: Bearer $KEY"
```

`data` 为分页结构 `{list,total,page,page_size}`，`list` 元素：

```json
{
  "id": 12,
  "batch_no": "202610281000ab12",
  "from_version": "1.1.0",
  "to_version": "1.2.0",
  "status": "success",
  "current_step": 2,
  "total_steps": 2,
  "total_size": 104622,
  "source": "gitee",
  "has_conflicts": false,
  "migrated": true,
  "message": null,
  "operator_id": 1,
  "operator_name": "admin",
  "created_at": "2026-10-28 10:00:00",
  "finished_at": "2026-10-28 10:02:30",
  "rolled_back_at": null
}
```

### GET /updates/batches/:id

`id` 为批次 ID（也可用 query 参数 `batch_id`，路径优先）。

```bash
curl -s "$BASE/updates/batches/12" -H "Authorization: Bearer $KEY"
```

`data` 为 `{batch, steps}`：`batch` 字段同上表；`steps` 按 `seq` 升序：

```json
{
  "batch": { "id": 12, "batch_no": "202610281000ab12", "status": "failed" },
  "steps": [
    {
      "id": 31, "seq": 1, "from_version": "1.1.0", "to_version": "1.2.0",
      "asset": "delta-1.1.0-to-1.2.0.zip", "ops_asset": "delta-1.1.0-to-1.2.0.json",
      "status": "success", "ops_total": 37, "ops_applied": 37, "conflicts": 0,
      "backup_path": "runtime/update/backup/202610281000ab12/1",
      "message": null, "started_at": "2026-10-28 10:00:05", "finished_at": "2026-10-28 10:00:20"
    }
  ]
}
```

### 完整示例：plan → step 循环 → 回滚

```bash
BASE="https://your-domain/admin-api/v1"
KEY="dak_xxx"
AUTH=(-H "Authorization: Bearer $KEY" -H "Content-Type: application/json")

# 1) 规划，取 batch_id
BATCH=$(curl -s -X POST "$BASE/updates/plan" "${AUTH[@]}" | sed -n 's/.*"batch_id":\([0-9]*\).*/\1/p')
echo "batch_id=$BATCH"

# 2) 一次一步，直到 done=true
while :; do
  RESP=$(curl -s -X POST "$BASE/updates/step" "${AUTH[@]}" -d "{\"batch_id\":$BATCH}")
  echo "$RESP"
  echo "$RESP" | grep -q '"done":true' && break
  echo "$RESP" | grep -q '"code":0' || break     # 出错时跳出，改用 retry
done

# 3) 需要时回滚整批（数据库迁移不会回滚）
curl -s -X POST "$BASE/updates/rollback" "${AUTH[@]}" -d "{\"batch_id\":$BATCH}"
```

### 状态机

`site_update.status`（批次）：

| 状态 | 含义 | 可执行动作 |
|---|---|---|
| `planned` | 已规划，尚未执行 | `step` / `retry` |
| `running` | 执行中（每个步骤期间短暂出现） | `step` 续跑 / `retry` / `rollback` |
| `success` | 全部步骤完成 | `rollback` |
| `failed` | 某一步失败，现场保留 | `retry` / `rollback` |
| `rolled_back` | 已整批回滚 | 无（需重新 `plan`） |

`site_update_step.status`（步骤）：

| 状态 | 含义 |
|---|---|
| `pending` | 待执行 |
| `running` | 执行中（状态落库后进程被杀会停在这里，用 `retry` 恢复） |
| `success` | 已成功 |
| `failed` | 失败，可 `retry` |
| `skipped` | 预留（当前版本不使用） |

并发：同一时刻只允许一个更新任务（`runtime/update/.lock` 的 `flock` 非阻塞独占），第二个请求立即返回「另一个更新任务正在执行，请稍后重试」，不会排队。

---

## 13. 安全防护

仅平台超管。后台「系统设置 → 安全设置」与下列接口共用 `SecurityService`，写操作后立即刷新运行时缓存。

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/security/overview` | 概览统计（黑白名单数、24 小时拦截/探针、Top IP）、当前设置与存储状态 |
| GET | `/security/settings` | 防护设置 + 当前访问 IP |
| PUT | `/security/settings` | 保存设置（**完整提交**，缺失的布尔项按 `false` 处理） |
| POST | `/security/cache/refresh` | 刷新黑白名单与探针规则缓存 |
| GET | `/security/ip-rules` | `list_type=blacklist\|whitelist`、`keyword`、`status`、`page`、`page_size` |
| POST | `/security/ip-rules` | 新增 `{list_type, ip, reason?, remark?, status?, expire_time?}` |
| PUT | `/security/ip-rules/:id` | 更新（完整字段） |
| DELETE | `/security/ip-rules/:id` | 删除 |
| POST | `/security/ip-rules/:id/status` | `{status:0\|1}` |
| GET | `/security/path-rules` | `keyword`、`status`、分页 |
| POST | `/security/path-rules` | 新增 `{name, match_type, pattern, status?, remark?}` |
| PUT | `/security/path-rules/:id` | 更新 |
| DELETE | `/security/path-rules/:id` | 删除 |
| POST | `/security/path-rules/:id/status` | `{status:0\|1}` |
| GET | `/security/events` | `ip`、`event_type`、`keyword`、分页 |
| POST | `/security/events/clear` | `{days:0\|N, confirm:1}`，`0` 表示清空 |

设置字段（PUT body）：

```json
{
  "enabled": true,
  "auto_block": false,
  "ua_block": false,
  "log_enabled": true,
  "threshold": 5,
  "window": 86400,
  "block_ttl": 86400,
  "trusted_proxy": false,
  "trusted_proxies": "",
  "trusted_headers": "cf-connecting-ip\nx-real-ip\nx-forwarded-for",
  "extra_whitelist": "",
  "event_retention_days": 30,
  "block_message": "Your IP has been blocked due to suspicious activity."
}
```

- `ip` 支持单个 IPv4/IPv6、CIDR（`10.0.0.0/8`）与 IPv4 通配（`192.168.1.*`）。
- `trusted_headers` 每行一个请求头，按顺序取第一个合法 IP；默认 `cf-connecting-ip` / `x-real-ip` / `x-forwarded-for`，可自行增删，留空时回退内置默认列表。
- 白名单优先级最高；`127.0.0.1`、`::1` 与已登录后台会话永不拦截。
- `event_type`：`blacklist_hit`（黑名单命中）、`probe`（探针扫描）、`bad_ua`（恶意 UA）、`auto_block`（自动封禁）。
- 命中后前台/后台返回 HTTP 403 HTML，`/api` 与 `/admin-api` 返回 `{"code":403,"message":"...","data":null}`。
- 误封自己时可用应急命令：`php think security:unblock --list` / `php think security:unblock 1.2.3.4`。

---

## 14. 权限矩阵

| 模块 | super | merchant_admin | staff |
|---|---|---|---|
| me / keys（自己的） | ✅ | ✅ | ✅ |
| media | ✅ | ✅ | ✅ |
| products / brands / orders | 全部 | 绑定商户 | 绑定商户 |
| reviews（商品评论审核） | 全部 | 本店商品评论 | 本店商品评论 |
| aftersales（退款重试） | ✅ | 本店 | 本店 |
| categories 写入 | ✅ | ❌ | ❌ |
| coupons（优惠） | 全部 | 本店可写 + 平台只读 | 本店可写 + 平台只读 |
| marketing/rules（营销规则） | ✅ | ❌ | ❌ |
| marketing/grants（批量发券） | ✅ | ❌ | ❌ |
| home-ops / settings / audit-logs | ✅ | ❌ | ❌ |
| updates（系统更新） | ✅ | ❌ | ❌ |
| security（安全防护） | ✅ | ❌ | ❌ |

越权返回 `code=1`（消息与后台页面一致）。

---

## 15. 注意事项

- 订单号、商品/分类/品牌 ID 均为数字；`order_no` 路径不要带 `-`（框架路径解析会受影响）。
- 生产环境必须使用 HTTPS；密钥只保存在服务端，不要写入前端代码或仓库。
- 图片外链导入依赖服务器 CA 证书；若报 `SSL certificate ... unable to get local issuer certificate`，请配置 PHP `curl.cainfo` 或 `openssl.cafile`。
- 接口会写审计日志；请勿在请求参数中放明文密码/密钥。