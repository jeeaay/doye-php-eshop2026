<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\exception\BizException;
use app\common\service\LanguageService;
use app\common\service\TemplateTranslationService;

/**
 * Admin API：模板翻译
 *
 * 与后台页面接口（app/admin/controller/TemplateTranslate.php）共用同一 Service 方法，
 * 因此 outcome 判定、快照结构、权限口径完全一致，不在此处复制业务判断。
 */
class TemplateTranslation extends ApiBaseController
{
    /**
     * POST /admin-api/v1/template-translations/enqueue
     *
     * body: {template, path, target_langs}  target_langs 为数组或逗号串（修 R5.1：逐语言入队）
     *
     * data: {results: [{lang, outcome, job_id}], counts: {created|queued|up_to_date|need_retry|empty: int}}
     *
     * @return \think\response\Json
     */
    public function enqueue()
    {
        return $this->runOutcome(function () {
            $this->assertSuper();
            $input = $this->input();
            $template = trim((string) ($input['template'] ?? ''));
            $path = trim((string) ($input['path'] ?? ''));
            $langs = $this->parseLangList($input['target_langs'] ?? []);

            if ($template === '' || $path === '' || $langs === []) {
                throw new BizException('参数不完整');
            }

            $data = (new TemplateTranslationService())->enqueueMany($template, $path, $langs);

            return [$data, $this->outcomeCountsMessage($data['counts'])];
        });
    }

    /**
     * POST /admin-api/v1/template-translations/backfill
     *
     * 批量入队修改过的模板文件翻译
     * body: {template, langs: []}
     *
     * data: {scanned_files, langs, created, queued, up_to_date, need_retry, empty}
     *
     * @return \think\response\Json
     */
    public function backfill()
    {
        return $this->runOutcome(function () {
            $this->assertSuper();
            $input = $this->input();
            $template = trim((string) ($input['template'] ?? ''));
            $langs = $this->parseLangList($input['langs'] ?? []);

            $result = (new TemplateTranslationService())->enqueueModified($template, $langs);

            $prefix = sprintf('扫描 %d 个文件 × %d 种语言：', (int) $result['scanned_files'], (int) $result['langs']);

            return [$result, $prefix . $this->outcomeCountsMessage($result)];
        });
    }

    /**
     * POST /admin-api/v1/template-translations/retry-failed
     *
     * 批量重试失败任务（每 (path, lang) 最新一条 failed/dead），与页面接口共用 Service
     * body: {template, langs?}
     *
     * data: {retried, skipped, remaining, message}
     *
     * @return \think\response\Json
     */
    public function retryFailed()
    {
        return $this->runOutcome(function () {
            $this->assertSuper();
            $input = $this->input();
            $template = trim((string) ($input['template'] ?? ''));
            if ($template === '') {
                throw new BizException('请先选择模板');
            }

            $result = (new TemplateTranslationService())->retryFailed($template, $this->parseLangList($input['langs'] ?? []));

            return [$result, $result['message']];
        });
    }

    /**
     * GET /admin-api/v1/template-translations/jobs
     *
     * 翻译队列状态快照（面板 + 行内徽标的唯一数据源，与页面接口同一结构）
     * query: template（必填）
     *
     * @return \think\response\Json
     */
    public function jobs()
    {
        return $this->run(function () {
            $this->assertSuper();
            $template = trim((string) $this->request->param('template', ''));
            if ($template === '') {
                throw new BizException('请先选择模板');
            }

            return (new TemplateTranslationService())->jobsSnapshot($template);
        }, '');
    }

    /**
     * 参数整形：langs 支持数组或逗号串，统一 normalizeCode
     *
     * 默认语种的过滤在 Service（enqueueMany / enqueueOne），控制器不做业务判断。
     *
     * @param mixed $langs
     * @return array<int,string>
     */
    private function parseLangList($langs): array
    {
        if (is_string($langs)) {
            $langs = array_values(array_filter(array_map('trim', explode(',', $langs))));
        }

        return array_values(array_filter(array_map(static function ($code) {
            return LanguageService::normalizeCode((string) $code);
        }, (array) $langs), static function ($code) {
            return $code !== '';
        }));
    }

    /**
     * 按 outcome 计数生成文案（与页面接口同口径，R3.3：created=0 时明确说明）
     *
     * @param array<string,mixed> $counts
     */
    private function outcomeCountsMessage(array $counts): string
    {
        $created = (int) ($counts['created'] ?? 0);
        $text = sprintf(
            '新增 %d 个 · 已在队列 %d 个 · 已是最新 %d 个 · 待重试 %d 个 · 无可翻译文本 %d 个',
            $created,
            (int) ($counts['queued'] ?? 0),
            (int) ($counts['up_to_date'] ?? 0),
            (int) ($counts['need_retry'] ?? 0),
            (int) ($counts['empty'] ?? 0)
        );

        return $created === 0 ? '没有新任务被加入队列：' . $text : $text;
    }

    /**
     * 与 ApiBaseController::run() 相同的 BizException 转换，
     * 但 message 由业务结果动态生成（闭包返回 [data, message]）。
     *
     * @param callable $fn
     * @return \think\response\Json
     */
    private function runOutcome(callable $fn)
    {
        try {
            [$data, $message] = $fn();
            return $this->ok($data, (string) $message);
        } catch (BizException $e) {
            return $this->fail($e->getMessage());
        }
    }
}
