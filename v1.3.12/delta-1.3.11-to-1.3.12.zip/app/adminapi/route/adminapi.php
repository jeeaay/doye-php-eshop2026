<?php
use app\common\middleware\AdminApiAuth;
use app\common\middleware\AdminAudit;
use app\common\middleware\RateLimit;
use think\facade\Route;

/*
 * 后台管理 API（对外前缀 /admin-api，见 config/app.php 的 app_map）
 *
 * 认证：Authorization: Bearer <API Key> 或 X-API-Key
 * 约定：动态路由必须写在同前缀静态路由之后，并 completeMatch()。
 */
Route::group('v1', function () {
    // ----- 身份 / 密钥 -----
    Route::get('me', 'Me/index');
    Route::get('keys', 'Key/index');
    Route::post('keys', 'Key/save');
    Route::delete('keys/:id', 'Key/delete')->completeMatch();

    // ----- 媒体 -----
    Route::post('media/upload', 'Media/upload');
    Route::post('media/base64', 'Media/base64');
    Route::post('media/import', 'Media/import');

    // ----- 商品 -----
    Route::get('products', 'Product/index')->completeMatch();
    Route::post('products', 'Product/save')->completeMatch();
    // 静态 products/sort、products/recommend 必须写在 products/:id 之前，且全部 completeMatch()
    Route::post('products/sort', 'Product/sort')->completeMatch();
    Route::post('products/recommend', 'Product/recommend')->completeMatch();
    Route::get('products/:id/translations', 'Product/translations')->completeMatch();
    Route::put('products/:id/translations/:lang', 'Product/saveTranslation')->completeMatch();
    Route::post('products/:id/translations/:lang/publish', 'Product/publishTranslation')->completeMatch();
    Route::post('products/:id/translations/:lang/ai', 'Product/translateTranslation')->completeMatch();
    Route::get('products/:id', 'Product/detail')->completeMatch();
    Route::put('products/:id', 'Product/update')->completeMatch();
    Route::delete('products/:id', 'Product/delete')->completeMatch();
    Route::post('products/:id/status', 'Product/status')->completeMatch();

    // ----- 分类 -----
    Route::get('categories', 'Category/index');
    Route::post('categories', 'Category/save');
    Route::put('categories/:id', 'Category/update')->completeMatch();
    Route::delete('categories/:id', 'Category/delete')->completeMatch();

    // ----- 品牌 -----
    Route::get('brands/options', 'Brand/options')->completeMatch();
    Route::get('brands', 'Brand/index')->completeMatch();
    Route::post('brands', 'Brand/save')->completeMatch();
    Route::put('brands/:id', 'Brand/update')->completeMatch();
    Route::delete('brands/:id', 'Brand/delete')->completeMatch();
    Route::post('brands/:id/status', 'Brand/status')->completeMatch();

    // ----- 站点单页（CMS，平台超管专用）-----
    // 静态 pages 必须写在 pages/:id 之前，并全部 completeMatch()
    Route::get('pages', 'Page/index')->completeMatch();
    Route::post('pages', 'Page/save')->completeMatch();
    Route::get('pages/:id', 'Page/detail')->completeMatch();
    Route::put('pages/:id', 'Page/update')->completeMatch();
    Route::post('pages/:id/status', 'Page/status')->completeMatch();

    // ----- 订单 -----
    Route::get('orders', 'Order/index')->completeMatch();
    Route::get('orders/:order_no', 'Order/detail')->completeMatch();
    Route::post('orders/:order_no/ship', 'Order/ship')->completeMatch();
    Route::post('orders/:order_no/deliver', 'Order/deliver')->completeMatch();

    // ----- 售后（本期只开放退款重试） -----
    Route::post('aftersales/:id/refund-retry', 'Aftersale/refundRetry')->completeMatch();

    // ----- 商品评论（后台审核；范围与写权限收口在 ReviewService） -----
    // 静态 reviews/status 必须写在 reviews/:id 之前，且全部 completeMatch()
    Route::get('reviews', 'Review/index')->completeMatch();
    Route::post('reviews/status', 'Review/status')->completeMatch();
    Route::post('reviews/pin', 'Review/pin')->completeMatch();
    Route::get('reviews/:id', 'Review/detail')->completeMatch();
    Route::post('reviews/:id/reply', 'Review/reply')->completeMatch();
    Route::delete('reviews/:id', 'Review/delete')->completeMatch();

    // ----- 优惠活动 -----
    Route::get('coupons', 'Coupon/index')->completeMatch();
    Route::post('coupons', 'Coupon/save')->completeMatch();
    Route::get('coupons/:id', 'Coupon/detail')->completeMatch();
    Route::put('coupons/:id', 'Coupon/update')->completeMatch();
    Route::delete('coupons/:id', 'Coupon/delete')->completeMatch();
    Route::post('coupons/:id/status', 'Coupon/status')->completeMatch();

    // ----- 营销规则（平台超管专用，权限收口在 MarketingService）-----
    Route::get('marketing/rules', 'Marketing/index')->completeMatch();
    Route::post('marketing/rules', 'Marketing/save')->completeMatch();
    Route::get('marketing/logs', 'Marketing/logs')->completeMatch();
    Route::get('marketing/rules/:id', 'Marketing/detail')->completeMatch();
    Route::put('marketing/rules/:id', 'Marketing/update')->completeMatch();
    Route::delete('marketing/rules/:id', 'Marketing/delete')->completeMatch();
    Route::post('marketing/rules/:id/status', 'Marketing/status')->completeMatch();
    Route::get('marketing/rules/:id/logs', 'Marketing/logs')->completeMatch();

    // ----- 批量发券（平台超管；preview 写在 :id 之前，避免被当成 id） -----
    Route::get('marketing/grants', 'MarketingGrant/index')->completeMatch();
    Route::post('marketing/grants', 'MarketingGrant/save')->completeMatch();
    Route::post('marketing/grants/preview', 'MarketingGrant/preview')->completeMatch();
    Route::get('marketing/grants/:id', 'MarketingGrant/detail')->completeMatch();
    Route::put('marketing/grants/:id', 'MarketingGrant/update')->completeMatch();
    Route::delete('marketing/grants/:id', 'MarketingGrant/delete')->completeMatch();
    Route::post('marketing/grants/:id/run', 'MarketingGrant/execute')->completeMatch();
    Route::post('marketing/grants/:id/cancel', 'MarketingGrant/cancel')->completeMatch();
    Route::post('marketing/grants/:id/revoke', 'MarketingGrant/revoke')->completeMatch();
    Route::post('marketing/grants/:id/resend', 'MarketingGrant/resend')->completeMatch();

    // ----- 分享拉新（只读） -----
    Route::get('share/overview', 'Share/overview')->completeMatch();
    Route::get('share/inviters', 'Share/inviters')->completeMatch();
    Route::get('share/referrals', 'Share/referrals')->completeMatch();
    Route::get('share/bindings', 'Share/bindings')->completeMatch();
    Route::get('share/rewards', 'Share/rewards')->completeMatch();

    // ----- 首页运营 -----
    Route::get('home-ops', 'HomeOps/index');
    Route::post('home-ops/:type', 'HomeOps/save')->completeMatch();
    Route::put('home-ops/:type/:id', 'HomeOps/update')->completeMatch();
    Route::delete('home-ops/:type/:id', 'HomeOps/delete')->completeMatch();
    Route::post('home-ops/:type/:id/status', 'HomeOps/status')->completeMatch();

    // ----- 站点版本 -----
    Route::get('edition', 'Edition/show');
    Route::put('edition', 'Edition/update');

    // ----- 币种与汇率 -----
    Route::get('currencies', 'Currency/index');
    Route::post('currencies', 'Currency/save');
    Route::put('currencies/:id', 'Currency/update')->completeMatch();
    Route::delete('currencies/:id', 'Currency/delete')->completeMatch();
    Route::post('currencies/:id/rate/refresh', 'Currency/refresh')->completeMatch();
    Route::put('currencies/:id/rate/override', 'Currency/override')->completeMatch();
    Route::delete('currencies/:id/rate/override', 'Currency/clearOverride')->completeMatch();
    Route::get('currency-rates', 'Currency/rates');

    // ----- AI 翻译 -----
    Route::get('translation-jobs', 'Translation/jobs');
    Route::post('translation-jobs/:id/retry', 'Translation/retry')->completeMatch();
    Route::post('translations/backfill', 'Translation/backfill');

    // ----- 模板管理（平台超管专用）-----
    Route::get('templates', 'Template/index');
    Route::post('templates/scan', 'Template/scan');
    Route::post('templates/active', 'Template/setActive');
    Route::get('templates/:name/files', 'Template/files')->completeMatch();
    Route::get('templates/:name/file-content', 'Template/fileContent')->completeMatch();

    // ----- 模板翻译 -----
    Route::get('template-translations/jobs', 'TemplateTranslation/jobs');
    Route::post('template-translations/enqueue', 'TemplateTranslation/enqueue');
    Route::post('template-translations/backfill', 'TemplateTranslation/backfill');
    Route::post('template-translations/retry-failed', 'TemplateTranslation/retryFailed');

    // ----- 系统设置 -----
    Route::get('settings', 'Setting/index');
    Route::post('settings/:group', 'Setting/save')->completeMatch();

    // ----- 系统更新（在线增量升级，平台超管专用） -----
    // 动态路由 batches/:id 必须写在同前缀静态路由之后，并 completeMatch()
    Route::get('updates/latest', 'Update/latest');
    Route::post('updates/plan', 'Update/plan');
    Route::post('updates/step', 'Update/step');
    Route::post('updates/retry', 'Update/retry');
    Route::post('updates/rollback', 'Update/rollback');
    Route::get('updates/history', 'Update/history');
    Route::get('updates/batches/:id', 'Update/batchDetail')->completeMatch();

    // ----- 安全防护（平台超管专用；completeMatch 避免子路径被静态路由前缀吞掉）-----
    Route::get('security/overview', 'Security/overview')->completeMatch();
    Route::get('security/settings', 'Security/settings')->completeMatch();
    Route::put('security/settings', 'Security/saveSettings')->completeMatch();
    Route::post('security/cache/refresh', 'Security/refreshCache')->completeMatch();
    Route::get('security/ip-rules', 'Security/ipRules')->completeMatch();
    Route::post('security/ip-rules', 'Security/saveIpRule')->completeMatch();
    Route::post('security/ip-rules/:id/status', 'Security/ipRuleStatus')->completeMatch();
    Route::put('security/ip-rules/:id', 'Security/updateIpRule')->completeMatch();
    Route::delete('security/ip-rules/:id', 'Security/deleteIpRule')->completeMatch();
    Route::get('security/path-rules', 'Security/pathRules')->completeMatch();
    Route::post('security/path-rules', 'Security/savePathRule')->completeMatch();
    Route::post('security/path-rules/:id/status', 'Security/pathRuleStatus')->completeMatch();
    Route::put('security/path-rules/:id', 'Security/updatePathRule')->completeMatch();
    Route::delete('security/path-rules/:id', 'Security/deletePathRule')->completeMatch();
    Route::post('security/events/clear', 'Security/clearEvents')->completeMatch();
    Route::get('security/events', 'Security/events')->completeMatch();

    // ----- 审计日志 -----
    Route::get('audit-logs', 'AuditLog/index');
    Route::post('audit-logs/purge', 'AuditLog/purge');
})->middleware([RateLimit::class, AdminApiAuth::class, AdminAudit::class]);