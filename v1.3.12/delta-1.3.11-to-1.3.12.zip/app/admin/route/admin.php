<?php
use app\common\middleware\AdminAudit;
use app\common\middleware\AdminAuth;
use app\common\model\Admin;
use app\common\support\AppContext;
use think\facade\Route;
use think\facade\Session;

// --- Auth: login form + login submit + logout (whitelist, no AdminAuth) ---

Route::get('login', 'auth/loginForm');
Route::post('login', 'auth/login');
Route::post('logout', 'auth/logout');

// --- Protected routes: all require AdminAuth ---

Route::group(function () {
    // Dashboard
    Route::get('index', 'index/index');

    // Products
    Route::get('products/create', 'products/create');
    Route::get('products/edit', 'products/edit');
    Route::get('products/translations', 'products/translations');
    Route::post('products/translate', 'products/translate');
    Route::get('products/translation-status', 'products/translationStatus');
    Route::post('products/backfill', 'products/backfill');
    Route::get('products', 'products/index');
    Route::post('products/upload', 'products/upload');
    Route::post('products/save', 'products/save');
    Route::post('products/delete', 'products/delete');
    Route::post('products/status', 'products/status');
    Route::post('products/sort', 'products/sort');
    Route::post('products/recommend', 'products/recommend');

    // Categories
    Route::get('categories', 'categories/index');
    Route::post('categories/save', 'categories/save');
    Route::post('categories/delete', 'categories/delete');

    // Reviews（评论管理，超管全量、商家按 merchant_ids 收敛；带子路径的静态路由必须写在裸 reviews 之前）
    Route::post('reviews/status', 'reviews/status');
    Route::post('reviews/pin', 'reviews/pin');
    Route::post('reviews/reply', 'reviews/reply');
    Route::post('reviews/delete', 'reviews/delete');
    Route::get('reviews', 'reviews/index');

    // Orders
    Route::get('orders/detail', 'orders/detail');
    Route::get('orders', 'orders/index');
    Route::post('orders/ship', 'orders/ship');
    Route::post('orders/deliver', 'orders/deliver');

    // Aftersales
    Route::get('aftersales', 'aftersales/index');
    Route::post('aftersales/approve', 'aftersales/approve');
    Route::post('aftersales/reject', 'aftersales/reject');
    Route::post('aftersales/receive', 'aftersales/receive');
    Route::post('aftersales/refund-retry', 'aftersales/refundRetry');

    // Merchants
    Route::get('merchants/detail', 'merchants/detail');
    Route::post('merchants/detail-save', 'merchants/detailSave');
    Route::post('merchants/upload', 'merchants/upload');
    Route::get('merchants', 'merchants/index');
    Route::post('merchants/save', 'merchants/save');
    Route::post('merchants/status', 'merchants/status');
    Route::post('merchants/delete', 'merchants/delete');

    // Brands（带子路径的静态路由必须写在裸 brands 之前，route_complete_match=false）
    Route::get('brands/detail', 'brands/detail');
    Route::post('brands/detail-save', 'brands/detailSave');
    Route::post('brands/upload', 'brands/upload');
    Route::post('brands/quick-add', 'brands/quickAdd');
    Route::get('brands/options', 'brands/options');
    Route::get('brands', 'brands/index');
    Route::post('brands/save', 'brands/save');
    Route::post('brands/status', 'brands/status');
    Route::post('brands/delete', 'brands/delete');

    // Staff
    Route::get('staff', 'staff/index');
    Route::get('staff/detail', 'staff/detail');
    Route::post('staff/save', 'staff/save');
    Route::post('staff/status', 'staff/status');
    Route::post('staff/delete', 'staff/delete');

    // Users（用户管理，商户可见只读；带子路径的静态路由必须写在裸 users 之前）
    Route::get('users/detail', 'users/detail');
    Route::get('users', 'users/index');

    // Settlement
    Route::get('settlement', 'settlements/index');

    // Share attribution
    Route::get('share', 'shares/index');

    // 站点版本（国内版 / 国际版，平台超管）
    Route::get('edition', 'edition/index');
    Route::post('edition/switch', 'edition/switchEdition');

    // Currency & exchange rates (platform super admin only)
    Route::post('currencies/save', 'currencies/save');
    Route::post('currencies/create', 'currencies/create');
    Route::post('currencies/delete', 'currencies/delete');
    Route::post('currencies/refresh', 'currencies/refresh');
    Route::post('currencies/override', 'currencies/override');
    Route::get('currencies/history', 'currencies/history');
    Route::get('currencies', 'currencies/index');

    // Payment channels (platform super admin only, enforced in PaymentChannelService)
    Route::get('payments', 'payments/index');
    Route::post('payments/save', 'payments/save');
    Route::post('payments/test', 'payments/test');

    // Pages（单页/CMS，平台超管专用；带子路径的静态路由必须写在裸 pages 之前）
    Route::get('pages/create', 'pages/form');
    Route::get('pages/edit', 'pages/form');
    Route::post('pages/upload', 'pages/upload');
    Route::post('pages/save', 'pages/save');
    Route::post('pages/status', 'pages/status');
    Route::post('pages/delete', 'pages/delete');
    Route::get('pages', 'pages/index');

    // Coupons（优惠管理，超管与商家共用，可见范围由 CouponService 收敛；带子路径的静态路由必须写在裸 coupons 之前）
    Route::get('coupons/create', 'coupons/form');
    Route::get('coupons/edit', 'coupons/form');
    Route::post('coupons/save', 'coupons/save');
    Route::post('coupons/status', 'coupons/status');
    Route::post('coupons/delete', 'coupons/delete');
    Route::get('coupons', 'coupons/index');

    // Marketing（营销规则，平台超管专用，权限收口在 MarketingService；带子路径的静态路由必须写在裸 marketing 之前）
    Route::get('marketing/create', 'marketing/form');
    Route::get('marketing/edit', 'marketing/form');
    Route::get('marketing/logs', 'marketing/logs');
    Route::post('marketing/save', 'marketing/save');
    Route::post('marketing/status', 'marketing/status');
    Route::post('marketing/delete', 'marketing/delete');
    Route::get('marketing', 'marketing/index');

    // MarketingGrants（批量发券，平台超管专用，权限收口在 MarketingGrantService）
    Route::get('marketing-grants/create', 'marketing_grant/form');
    Route::get('marketing-grants/edit', 'marketing_grant/form');
    Route::get('marketing-grants/detail', 'marketing_grant/detail');
    Route::post('marketing-grants/preview', 'marketing_grant/preview');
    Route::post('marketing-grants/save', 'marketing_grant/save');
    Route::post('marketing-grants/run', 'marketing_grant/run');
    Route::post('marketing-grants/cancel', 'marketing_grant/cancel');
    Route::post('marketing-grants/revoke', 'marketing_grant/revoke');
    Route::post('marketing-grants/delete', 'marketing_grant/delete');
    Route::get('marketing-grants', 'marketing_grant/index');

    // Messages（留言管理，平台超管专用；带子路径的静态路由必须写在裸 messages 之前）
    Route::get('messages/detail', 'messages/detail');
    Route::post('messages/status', 'messages/status');
    Route::post('messages/delete', 'messages/delete');
    Route::get('messages', 'messages/index');

    // Settings（账户设置：当前登录管理员自己的资料）
    Route::get('settings', 'settings/index');
    Route::post('settings/profile', 'settings/profile');
    Route::post('settings/password', 'settings/password');

    // API keys（密钥管理：仅管理当前管理员自己的密钥；子路径必须写在裸路径之前）
    Route::post('api-keys/create', 'apiKeys/create');
    Route::post('api-keys/revoke', 'apiKeys/revoke');
    Route::post('api-keys/delete', 'apiKeys/delete');
    Route::get('api-keys', 'apiKeys/index');

    // Security（安全设置，平台超管专用；子路径必须写在裸 security 之前）
    Route::post('security/settings', 'security/saveSettings');
    Route::post('security/ip-rules/save', 'security/saveIpRule');
    Route::post('security/ip-rules/delete', 'security/deleteIpRules');
    Route::post('security/ip-rules/status', 'security/setIpRuleStatus');
    Route::post('security/path-rules/save', 'security/savePathRule');
    Route::post('security/path-rules/delete', 'security/deletePathRules');
    Route::post('security/path-rules/status', 'security/setPathRuleStatus');
    Route::post('security/events/clear', 'security/clearEvents');
    Route::post('security/cache/refresh', 'security/refreshCache');
    Route::get('security', 'security/index');

    // System settings（站点系统设置，平台超管专用）
    Route::post('system/save', 'setting/save');
    Route::get('system', 'setting/index');

    // System update（在线增量更新，平台超管专用；页面已并入「系统设置 → 更新设置」）
    // route_complete_match=false：带子路径的静态路由必须写在裸 update 之前，否则 /update/detail 会命中 update/index
    Route::get('update/overview', 'update/overview');
    Route::post('update/check', 'update/check');
    Route::post('update/plan', 'update/plan');
    Route::post('update/step', 'update/step');
    Route::post('update/retry', 'update/retry');
    Route::post('update/rollback', 'update/rollback');
    Route::get('update/history', 'update/history');
    Route::get('update/detail', 'update/detail');
    Route::get('update', 'update/index');

    // Audit logs（操作日志，平台超管专用）
    Route::post('audit-logs/purge', 'auditLogs/purge');
    Route::get('audit-logs', 'auditLogs/index');

    // Homepage operations (mini-program首页运营)
    Route::get('home-ops', 'homeOps/index');
    Route::post('home-ops/banner/save', 'homeOps/saveBanner');
    Route::post('home-ops/banner/delete', 'homeOps/deleteBanner');
    Route::post('home-ops/banner/toggle', 'homeOps/toggleBanner');
    Route::post('home-ops/category/save', 'homeOps/saveHomeCategory');
    Route::post('home-ops/category/delete', 'homeOps/deleteHomeCategory');
    Route::post('home-ops/category/toggle', 'homeOps/toggleHomeCategory');
    Route::post('home-ops/notice/save', 'homeOps/saveNotice');
    Route::post('home-ops/notice/delete', 'homeOps/deleteNotice');
    Route::post('home-ops/notice/toggle', 'homeOps/toggleNotice');
    Route::post('home-ops/topic/save', 'homeOps/saveTopic');
    Route::post('home-ops/topic/delete', 'homeOps/deleteTopic');
    Route::post('home-ops/topic/toggle', 'homeOps/toggleTopic');
    Route::post('home-ops/product/save', 'homeOps/saveHomeProduct');
    Route::post('home-ops/product/delete', 'homeOps/deleteHomeProduct');
    Route::post('home-ops/product/toggle', 'homeOps/toggleHomeProduct');

    // Template management（模板管理，平台超管专用）
    Route::post('template/scan', 'template/scan');
    Route::post('template/set-active', 'template/setActive');
    Route::get('template/files', 'template/files');
    Route::get('template/file-content', 'template/fileContent');
    Route::get('template', 'template/index');

    // Template translation（模板翻译，平台超管专用）
    // 注意：route_complete_match=false，静态长路径必须排在裸路由之前（AGENTS.md 易踩坑 1）
    Route::get('template-translate/jobs', 'templateTranslate/jobs');
    Route::get('template-translate', 'templateTranslate/index');
    Route::post('template-translate/enqueue', 'templateTranslate/enqueue');
    Route::post('template-translate/enqueue-modified', 'templateTranslate/enqueueModified');
    Route::post('template-translate/retry-failed', 'templateTranslate/retryFailed');
    Route::post('template-translate/retry', 'templateTranslate/retry');

    // Multilingual settings（多语种设置，平台超管专用）
    Route::get('multilang', 'multilang/index');
    Route::post('multilang/save-settings', 'multilang/saveSettings');
    Route::post('multilang/save-language', 'multilang/saveLanguage');
    Route::post('multilang/set-default', 'multilang/setDefaultLanguage');
    Route::post('multilang/toggle-language', 'multilang/toggleLanguage');
    Route::post('multilang/delete-language', 'multilang/deleteLanguage');

    // AI configuration（AI 配置，平台超管专用）
    Route::get('ai-config', 'aiConfig/index');

    // Auth check endpoint (kept from skeleton)
    Route::get('test/whoami', function () {
        return json(['code' => 0, 'message' => 'ok', 'data' => [
            'role'         => AppContext::getAdminRole(),
            'merchant_ids' => AppContext::getMerchantIds(),
        ]]);
    });
})->middleware([AdminAuth::class, AdminAudit::class]);

// 应用根路径（/{ADMIN_PATH}）重定向到工作台
Route::get('/', function () {
    return redirect(admin_url('index'));
});
