<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\service\LanguageService;
use app\common\service\TemplateManager;
use app\common\service\TemplateTranslationService;
use app\common\service\TranslationJobService;
use app\common\support\AppContext;
use think\facade\View;

/**
 * 模板翻译管理（平台超管专用）
 *
 * AI 翻译模板 HTML 中的硬编码文字。依赖 TemplateTranslationService（Phase 4 实现）。
 */
class TemplateTranslate extends AdminBaseController
{
    public function index()
    {
        $this->assertSuper();
        $this->assignActiveMenu('template-translate');

        $manager = new TemplateManager();
        $templates = $manager->listTemplates();

        // 统计每个模板的翻译状态
        $templateStats = [];
        foreach ($templates as $tpl) {
            $templateStats[$tpl['name']] = [
                'base_files' => array_filter($tpl['langs'], fn($l) => $l === 'base') ? $tpl['files'] : 0,
                'langs'      => array_values(array_filter($tpl['langs'], fn($l) => $l !== 'base')),
            ];
        }

        // 网站已启用的语言列表（来自数据库 language 表）
        $siteLanguages = [];
        $defaultLanguage = [
            'code'        => base_locale(),
            'name'        => base_locale(),
            'native_name' => base_locale(),
        ];
        try {
            $service = new LanguageService();
            $siteLanguages = $service->enabled();
            $defaultLanguage = $service->default();
        } catch (\Throwable $e) {
            $siteLanguages = [];
        }

        // 默认语种即模板源语言，不再作为翻译目标
        $defaultCode = strtolower((string) ($defaultLanguage['code'] ?? base_locale()));
        $siteLanguages = array_values(array_filter($siteLanguages, static function ($language) use ($defaultCode): bool {
            return strtolower((string) ($language['code'] ?? '')) !== $defaultCode;
        }));

        // 常用语言预设
        $commonLanguages = LanguageService::COMMON;

        View::assign([
            'templates'          => $templates,
            'templateStats'      => $templateStats,
            'templateStatsJson'  => json_encode($templateStats, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'siteLanguages'      => $siteLanguages,
            'siteLanguagesJson'  => json_encode($siteLanguages, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'defaultLanguage'    => $defaultLanguage,
            'commonLanguages'    => $commonLanguages,
            'commonLanguagesJson'=> json_encode($commonLanguages, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ]);

        return View::fetch();
    }

    /**
     * 发起单个文件翻译，对每种已选语言分别入队（AJAX，修 R5.1）
     */
    public function enqueue()
    {
        try {
            $this->assertSuper();
            $input = $this->request->post();
            $template = trim((string) ($input['template'] ?? ''));
            $path = trim((string) ($input['path'] ?? ''));
            $langs = $this->parseLangList($input['target_langs'] ?? []);

            if ($template === '' || $path === '' || $langs === []) {
                throw new BizException('参数不完整');
            }

            $data = (new TemplateTranslationService())->enqueueMany($template, $path, $langs);

            return json([
                'code'    => 0,
                'message' => $this->outcomeCountsMessage($data['counts']),
                'data'    => $data,
            ]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 批量翻译所有修改过的文件（AJAX）
     */
    public function enqueueModified()
    {
        try {
            $this->assertSuper();
            $input = $this->request->post();
            $template = trim((string) ($input['template'] ?? ''));
            $langs = $this->parseLangList($input['langs'] ?? []);

            $result = (new TemplateTranslationService())->enqueueModified($template, $langs);

            $message = sprintf('扫描 %d 个文件 × %d 种语言：', (int) $result['scanned_files'], (int) $result['langs'])
                . $this->outcomeCountsMessage($result);

            return json(['code' => 0, 'message' => $message, 'data' => $result]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 翻译队列状态快照（AJAX，面板 + 行内徽标数据源）
     */
    public function jobs()
    {
        try {
            $this->assertSuper();
            $template = trim((string) $this->request->get('template', ''));
            if ($template === '') {
                throw new BizException('请先选择模板');
            }

            return json([
                'code'    => 0,
                'message' => '',
                'data'    => (new TemplateTranslationService())->jobsSnapshot($template),
            ]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 批量重试失败任务（AJAX）：按「每 (path, lang) 最新一条 failed/dead」口径
     */
    public function retryFailed()
    {
        try {
            $this->assertSuper();
            $input = $this->request->post();
            $template = trim((string) ($input['template'] ?? ''));
            if ($template === '') {
                throw new BizException('请先选择模板');
            }
            $result = (new TemplateTranslationService())->retryFailed(
                $template,
                $this->parseLangList($input['langs'] ?? [])
            );

            return json(['code' => 0, 'message' => $result['message'], 'data' => $result]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 重试失败的翻译任务（AJAX）
     */
    public function retry()
    {
        try {
            $this->assertSuper();
            $jobId = (int) $this->request->post('id', 0);
            if ($jobId <= 0) {
                throw new BizException('参数不完整');
            }
            (new TranslationJobService())->retry($jobId);
            return json(['code' => 0, 'message' => '任务已重新入队', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    private function assertSuper(): void
    {
        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            throw new BizException('仅平台超级管理员可访问');
        }
    }

    /**
     * 参数整形：target_langs 支持数组或逗号串，统一 normalizeCode
     *
     * 默认语种的过滤在 Service（enqueueMany），控制器不做业务判断。
     *
     * @param mixed $langs
     * @return array<int,string>
     */
    private function parseLangList($langs): array
    {
        if (is_string($langs)) {
            $langs = array_values(array_filter(array_map('trim', explode(',', $langs))));
        }

        return array_values(array_filter(array_map(static function ($code) {
            return LanguageService::normalizeCode((string) $code);
        }, (array) $langs), static function ($code) {
            return $code !== '';
        }));
    }

    /**
     * 按 outcome 计数生成中文文案（R3.3：区分新增/复用/跳过/待重试，created=0 时明确说明）
     *
     * @param array<string,mixed> $counts
     */
    private function outcomeCountsMessage(array $counts): string
    {
        $created = (int) ($counts['created'] ?? 0);
        $text = sprintf(
            '新增 %d 个 · 已在队列 %d 个 · 已是最新 %d 个 · 待重试 %d 个 · 无可翻译文本 %d 个',
            $created,
            (int) ($counts['queued'] ?? 0),
            (int) ($counts['up_to_date'] ?? 0),
            (int) ($counts['need_retry'] ?? 0),
            (int) ($counts['empty'] ?? 0)
        );

        return $created === 0 ? '没有新任务被加入队列：' . $text : $text;
    }
}
