<?php
declare(strict_types=1);

namespace app\api\controller;

use app\BaseController;
use app\common\exception\BizException;
use app\common\model\User as UserModel;
use app\common\model\UserAddress;
use app\common\service\ShippingEtaService;
use app\common\service\UserService;
use app\common\support\AppContext;
use think\facade\Db;

class User extends BaseController
{
    public function avatar()
    {
        try {
            $userId = (int)AppContext::getUserId();
            $file = $this->request->file('file');
            if (!$file || !$file->isValid()) {
                return $this->error(40001, '请选择有效的头像文件');
            }
            $ext = strtolower((string)$file->extension());
            if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true)) {
                return $this->error(40001, '头像必须是 jpg、png 或 webp 文件');
            }
            if ((int)$file->getSize() > 2 * 1024 * 1024) {
                return $this->error(40001, '头像不能超过 2MB');
            }
            $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($file->getPathname());
            if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) {
                return $this->error(40001, '头像文件内容无效');
            }
            $relativeDir = '/uploads/avatars/' . date('Ym') . '/';
            $directory = public_path() . ltrim($relativeDir, '/');
            if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
                return $this->error(50001, '上传目录不可写');
            }
            $filename = bin2hex(random_bytes(16)) . '.' . $ext;
            if (!move_uploaded_file($file->getPathname(), $directory . $filename)) {
                return $this->error(50001, '头像保存失败');
            }
            return $this->success(['url' => $relativeDir . $filename]);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    public function bindPhone()
    {
        try {
            $userId = (int)AppContext::getUserId();
            $code = (string)$this->request->post('code', '');
            $res = (new UserService())->bindPhone($userId, $code);
            return $this->success($res);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    public function profile()
    {
        $userId = (int)AppContext::getUserId();
        $user = (new UserService())->getProfile($userId);
        return $this->success([
            'id'       => $user->id,
            'openid'   => $user->openid,
            'nickname' => $user->nickname,
            'avatar'   => $user->avatar,
            'phone'    => $user->phone,
        ]);
    }

    public function update()
    {
        try {
            $userId = (int)AppContext::getUserId();
            $data = $this->request->post();

            $user = UserModel::find($userId);
            if (!$user) {
                return $this->error(40004, '用户不存在');
            }

            if (isset($data['nickname'])) {
                $user->nickname = (string)$data['nickname'];
            }
            if (isset($data['avatar'])) {
                $user->avatar = (string)$data['avatar'];
            }
            if (isset($data['phone'])) {
                $user->phone = (string)$data['phone'];
            }
            $user->save();

            return $this->success([
                'id'       => $user->id,
                'openid'   => $user->openid,
                'nickname' => $user->nickname,
                'avatar'   => $user->avatar,
                'phone'    => $user->phone,
            ]);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    public function addressList()
    {
        $userId = (int)AppContext::getUserId();
        $addresses = UserAddress::where('user_id', $userId)
            ->order('is_default', 'desc')
            ->order('create_time', 'desc')
            ->order('id', 'desc')
            ->select();

        $list = [];
        foreach ($addresses as $addr) {
            $list[] = [
                'id'            => (int)$addr->id,
                'name'          => $addr->name,
                'phone'         => $addr->phone,
                'address_detail' => $addr->address_detail,
                'country'       => (string)($addr->country ?? ''),
                'is_default'    => (int)$addr->is_default,
            ];
        }

        return $this->success($list);
    }

    public function addressAdd()
    {
        try {
            $userId = (int)AppContext::getUserId();
            $name = trim((string)$this->request->post('name', ''));
            $phone = trim((string)$this->request->post('phone', ''));
            $addressDetail = trim((string)$this->request->post('address_detail', ''));
            $isDefault = (int)$this->request->post('is_default', 0);
            // country 可选：小程序旧版不传，保持 NULL（未设置）
            $countryRaw = $this->request->post('country', '');
            if (is_array($countryRaw)) {
                return $this->error(40001, '收货国家无效');
            }
            $countryRaw = trim((string)$countryRaw);
            $country = null;
            if ($countryRaw !== '') {
                $country = (new ShippingEtaService())->normalize($countryRaw);
                if ($country === null) {
                    return $this->error(40001, '收货国家无效');
                }
            }

            // 国际版仅作联系用途，电话选填；国内版（小程序/本地配送）仍必填
            if ($name === '' || $addressDetail === '' || ($phone === '' && is_domestic_edition())) {
                return $this->error(40001, '请填写完整收货信息');
            }
            if (mb_strlen($name) > 64 || mb_strlen($phone) > 20 || mb_strlen($addressDetail) > 512) {
                return $this->error(40001, '收货信息长度超出限制');
            }

            Db::startTrans();
            try {
                $hasAddress = UserAddress::where('user_id', $userId)->find();
                $hasDefault = UserAddress::where('user_id', $userId)->where('is_default', 1)->find();
                $shouldDefault = !$hasAddress || !$hasDefault || $isDefault;
                if ($shouldDefault) {
                    UserAddress::where('user_id', $userId)->update(['is_default' => 0]);
                }

                $addr = new UserAddress();
                $addr->user_id = $userId;
                $addr->name = $name;
                $addr->phone = $phone;
                $addr->address_detail = $addressDetail;
                $addr->country = $country;
                $addr->is_default = $shouldDefault ? 1 : 0;
                $addr->save();
                Db::commit();
            } catch (\Throwable $e) {
                Db::rollback();
                throw $e;
            }

            return $this->success(['id' => $addr->id]);
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    public function addressUpdate()
    {
        try {
            $userId = (int)AppContext::getUserId();
            $id = (int)$this->request->post('id', 0);
            if (!$id) {
                return $this->error(40001, '参数错误');
            }

            $addr = UserAddress::where('id', $id)
                ->where('user_id', $userId)
                ->find();
            if (!$addr) {
                return $this->error(40004, '地址不存在');
            }

            $data = $this->request->post();
            if (isset($data['name'])) {
                $addr->name = trim((string)$data['name']);
            }
            if (isset($data['phone'])) {
                $addr->phone = trim((string)$data['phone']);
            }
            if (isset($data['address_detail'])) {
                $addr->address_detail = trim((string)$data['address_detail']);
            }
            // 国际版电话选填，国内版必填（口径与 addressAdd 一致）
            if ($addr->name === '' || $addr->address_detail === '' || ($addr->phone === '' && is_domestic_edition())) {
                return $this->error(40001, '请填写完整收货信息');
            }
            if (mb_strlen($addr->name) > 64 || mb_strlen($addr->phone) > 20 || mb_strlen($addr->address_detail) > 512) {
                return $this->error(40001, '收货信息长度超出限制');
            }
            // country 只在请求带该键时更新：不传保持原值，空字符串清空为 NULL
            if (array_key_exists('country', $data)) {
                if (is_array($data['country'])) {
                    return $this->error(40001, '收货国家无效');
                }
                $countryRaw = trim((string)$data['country']);
                if ($countryRaw === '') {
                    $addr->country = null;
                } else {
                    $country = (new ShippingEtaService())->normalize($countryRaw);
                    if ($country === null) {
                        return $this->error(40001, '收货国家无效');
                    }
                    $addr->country = $country;
                }
            }
            Db::startTrans();
            try {
                if (isset($data['is_default'])) {
                    $isDefault = (int)$data['is_default'];
                    if ($isDefault) {
                        UserAddress::where('user_id', $userId)
                            ->where('id', '<>', $id)
                            ->update(['is_default' => 0]);
                    }
                    if (!$isDefault && (int)$addr->is_default === 1) {
                        $replacement = UserAddress::where('user_id', $userId)
                            ->where('id', '<>', $id)
                            ->order('create_time', 'asc')
                            ->order('id', 'asc')
                            ->find();
                        if ($replacement) {
                            $replacement->is_default = 1;
                            $replacement->save();
                            $addr->is_default = 0;
                        } else {
                            $addr->is_default = 1;
                        }
                    } else {
                        $addr->is_default = $isDefault ? 1 : 0;
                    }
                }
                if (!UserAddress::where('user_id', $userId)->where('is_default', 1)->find()) {
                    $addr->is_default = 1;
                }
                $addr->save();
                Db::commit();
            } catch (\Throwable $e) {
                Db::rollback();
                throw $e;
            }

            return $this->success();
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }

    public function addressDelete()
    {
        try {
            $userId = (int)AppContext::getUserId();
            $id = (int)$this->request->post('id', 0);
            if (!$id) {
                return $this->error(40001, '参数错误');
            }

            $addr = UserAddress::where('id', $id)
                ->where('user_id', $userId)
                ->find();
            if (!$addr) {
                return $this->error(40004, '地址不存在');
            }
            $wasDefault = (int)$addr->is_default === 1;
            Db::startTrans();
            try {
                $addr->delete();
                if ($wasDefault) {
                    $replacement = UserAddress::where('user_id', $userId)
                        ->order('create_time', 'asc')
                        ->order('id', 'asc')
                        ->find();
                    if ($replacement) {
                        $replacement->is_default = 1;
                        $replacement->save();
                    }
                }
                Db::commit();
            } catch (\Throwable $e) {
                Db::rollback();
                throw $e;
            }

            return $this->success();
        } catch (BizException $e) {
            return $this->error(40001, $e->getMessage());
        }
    }
}
