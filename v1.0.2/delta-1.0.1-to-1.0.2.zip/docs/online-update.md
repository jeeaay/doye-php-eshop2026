# 在线增量更新 · 开发者速查

> 给维护者与后续开发的回忆版说明。站点运营者视角见 `README.md`「在线增量更新」。
> 术语：**发布端** = 维护者机器上的 CLI；**站点端** = 任意部署了本项目的网站。

## 一句话

版本号写在 `version.json`；发布端用 `git diff 上一版 本版` 生成「上一版 → 本版」的增量包，提交进**独立的 `update/` 仓库**并推送到 Gitee/GitHub；站点在后台按版本链逐步下载、验签、校验哈希、备份、覆盖、跑迁移。

## 组件

```
发布端（本机）
  release:keygen   生成 Ed25519 密钥对（仅首次）
  release:build    产出 update/v{x}/delta-*.zip + .json（+ vendor-*.zip），签发 update/update.json(.sig)
                  --push 在 update/ 独立仓库里 commit 并推 main 到 gitee/github（不推源码、不推 tag）
  release:verify   验签 + 链连续性 + 两个 raw 源的清单/资产可达 + 本地哈希
        │  git push
        ▼
Gitee raw（优先） → GitHub raw（兜底）
        │  HTTPS 拉取
        ▼
站点端
  后台「系统设置 → 更新设置」 ─┐
  管理 API /admin-api/v1/updates/* ─┴→ UpdateService（唯一编排入口）
        ├ UpdateSource  Gitee / Github / Local(测试)
        ├ UpdatePackage 验签 · 哈希 · 路径白名单 · 解压
        ├ UpdateInstaller 备份 · 原子写 · 删除 · vendor 替换 · 回滚
        └ UpdateMigrator exec 优先，Console::call 兜底
        └→ site_update / site_update_step（批次与步骤状态）
```

## 关键文件

| 路径 | 作用 |
|---|---|
| `version.json` | **唯一版本来源**（站点只认它；缺失 = 未知版本，拒绝更新） |
| `config/update.php` | 分发/推送地址、公钥、超时、可写白名单、保护路径、维护窗口（**站点不可改**） |
| `config/site.php` + `config/setting.php` | 站点可调项：启用开关、备份保留份数、维护窗口开关 |
| `app/common/command/Release*.php`、`app/common/release/*` | 发布端 |
| `app/common/service/UpdateService.php` | 站点端编排（check/plan/step/retry/rollback） |
| `app/common/service/update/*` | 源适配器、清单校验、文件安装、迁移执行 |
| `app/admin/controller/Update.php`、`app/adminapi/controller/Update.php` | 页面与 API，共用同一服务 |
| `app/common/middleware/UpdateMaintenance.php` | 升级期间前台 503，`/admin`、`/admin-api` 放行 |
| `update/` | **独立的 git 仓库**（远端根目录就是它）：清单 + 按版本目录，**历史目录不可删**；被主仓库 `.gitignore` 忽略 |
| `.trellis/spec/backend/release-guidelines.md` | 发布链硬约束（改发布逻辑前必读） |

## 发布流程

### 首次准备（每台发布机器一次）

```bash
# 1) 签名私钥：只生成一次；丢了只能换钥并让所有站点重新部署
php think release:keygen --out=runtime/release-signing.key
#    把打印出来的公钥填进 config/update.php 的 public_key 并提交

# 2) 分发仓库：主仓库不会克隆它（/update/ 被 .gitignore 忽略）
git clone git@gitee.com:jeay/doye-php-eshop2026.git update
git -C update remote add github git@github.com:jeeaay/doye-php-eshop2026.git
#    仓库还是空的时候：git -C update init -b main 后加两个 remote
```

主仓库**不要**添加 gitee / github remote——发布只发生在 `update/` 里。

### 每次发布

```bash
# 1) 改 version.json（version 不带 v，必须与 tag 一致）+ 提交 + 打 tag（tag 只留本地）
git commit -am "chore: bump version to 1.0.1"
git tag v1.0.1

# 2) 出包 → 在 update/ 独立仓库里 commit → 推送 main 到 gitee、github
php think release:build --version=1.0.1 --push

# 3) 体检（签名 / 链连续性 / 两个 raw 源的清单与资产）
php think release:verify
```

- 产物：`update/v1.0.1/delta-1.0.0-to-1.0.1.zip|json`、清单 `update/update.json(.sig)`；
  推送后它们就是远端仓库根下的 `v1.0.1/...`、`update.json`、`update.json.sig`。
- 首个 tag 没有上一版 → `release:build` 直接拒绝（基线只能手工部署）。
- 破坏性数据库迁移：加 `--db-breaking`，站点会拒绝一键升级、只给手工指引。
- 远端历史被重建（手动清空过仓库）→ 加 `--force-push`。
- `--push` 不推源码提交、不推 tag，只推分发仓库自己的 `main`。
- **兼容镜像**：每次发布还会把清单与资产复制一份到分发仓库的 `update/` 子目录，
  让仍在使用旧地址（`/raw/main/update/update.json`）的 v1.0.0 站点也能升级；
  全部站点升到 1.0.1 后可加 `--no-legacy-mirror` 停掉。

## 站点端一次升级做了什么

`check`（拉清单验签 → 找链 → 缓存 10 分钟）→ `plan`（HEAD 探测所有资产、磁盘/权限/PHP 版本、建批次）→ 每个请求执行一步：

```
下载资产 → sha256 → 解压到 runtime/update/stage →
逐条比对 before 哈希（不符 = 冲突，备份后仍覆盖）→
备份到 runtime/update/backup/{批次}/{步骤}/ →
同目录临时文件 + rename 覆盖 / unlink 删除 →
（need_vendor）解压 vendor.zip，旧目录先备份 →
php think migrate:run → 清缓存 → 原子写 version.json → 步骤成功
```

- 任一步失败：步骤 `failed`、保留现场，可「重试当前步骤」（先还原再重跑）或「整批回滚」（倒序还原文件；**DB 迁移不回滚**）。
- 并发由 `runtime/update/.lock`（flock）挡住；升级期间写 `applying.lock`，超过 `maintenance.stale_seconds`（30 分钟）视为中断并自动放行。

## 契约

`update/update.json`（累积链，推送后位于远端仓库根）：`schema / latest / php_min / steps[]`，每个 step 含 `from to asset asset_size asset_sha256 ops_asset ops_sha256 need_vendor vendor_* db_version db_breaking`。

`delta-*.json`：`ops[]`，每项 `{op: add|modify|delete, path, before, after, size}`；重命名降级为 `delete + add`。

## 不可破坏的约束

1. **信任根只有一个**：`update.json.sig` 钉住所有资产的 sha256；验签失败一律拒绝，不信任缓存。
2. **白名单只有一份**：`config/update.php` 的 `manage_roots` / `root_files` / `protected_paths`；发布端与站点端共用同一套校验，不在业务代码里另写。
3. **私钥只在维护者机器**（`runtime/release-signing.key`，已 gitignore）；公钥随代码分发。
4. **只发增量包**，没有全量包；首次部署与灾难恢复 = `git clone` + `composer install`。
5. **`update/` 历史版本目录不能删**（链式依赖），`update.json` 不能手改（只能重新签发）。
6. **公开仓库只有 `update/`**：`update/` 是独立仓库，主仓库不配置 gitee/github 远端；`--push` 只推分发分支，源码提交与 tag 一律不推。
7. **每步都幂等**：先备份再覆盖，`version.json` 每步原子写，任何中断都停在合法版本上。
8. **兼容镜像有生命周期**：`update/` 子目录只是给 v1.0.0 旧客户端的桥；站点全部 ≥1.0.1 后
   用 `--no-legacy-mirror` 关闭，避免仓库里长期存两份相同产物。

## 常见坑

- `--version` 被 ThinkPHP 注册为全局选项，`think` 入口做了 `--version=` → `--ver=` 改写；不要删那段。
- 后台路由：`update/check|plan|step|...` 必须写在裸 `update` 之前（`route_complete_match=false`）。
- Windows 上刚写入的文件/目录会被杀软短暂占用，`rename` 有重试；失败文案会说「可能被占用」。
- `exec` 被 `disable_functions` 禁用时迁移走 `Console::call`，两条路都不可用才报错。
- 每步成功会 `Cache::clear()`，Redis 里的 `token:*` 也会被清 → 前台用户会掉登录（当前为设计行为）。
- 发布端过滤用的是站点端同一份白名单：新增可写目录先改 `config/update.php`，否则该文件不会随包下发。

## 验证与排障

```bash
php think update:selftest      # 11 条验收（AC8/AC11 需真实网络与登录态，标记 SKIP）
php think release:verify       # 发布端体检
php think migrate:status       # 迁移到位
```

| 现象 | 含义 |
|---|---|
| `blocked_reason=network` + raw 404 | 还没发布过版本（`update/update.json` 不存在） |
| `blocked_reason=signature` | 公钥不匹配 / 清单被改 |
| `blocked_reason=broken_chain` | 当前版本不在链上（手工部署或中间版本被删） |
| `blocked_reason=db_breaking` | 版本标了破坏性迁移，需手工升级 |
| 前台一直 503 | `runtime/update/applying.lock` 残留；30 分钟后自动放行，或手动删除 |
| 回滚报「备份不存在」 | 批次备份已被 `backup_keep` 清理，只能手工重装 |