<?php

namespace app\common\lib;

use app\common\exception\BizException;
use think\facade\Config;

/**
 * @deprecated Use WechatPayGateway via PaymentGatewayFactory, which reads the
 *             encrypted channel config from the database. Kept as a facade
 *             for older integrations during the migration window.
 */
class WechatPay
{
    protected static function config(): array
    {
        $mchid = (string)Config::get('wechat.pay.mchid', '');
        $privateKeyPath = (string)Config::get('wechat.pay.private_key_path', '');
        $certPath = (string)Config::get('wechat.pay.platform_cert_path', '');
        if ($mchid === '' || $privateKeyPath === '' || !is_file($privateKeyPath)) {
            throw new BizException('微信支付未配置 (mchid/private_key)');
        }
        return [
            'mchid' => $mchid,
            'serial_no' => (string)Config::get('wechat.pay.serial_no', ''),
            'private_key' => file_get_contents($privateKeyPath),
            'platform_cert' => $certPath !== '' && is_file($certPath) ? file_get_contents($certPath) : '',
            'notify_url' => (string)Config::get('wechat.pay.notify_url', ''),
        ];
    }

    protected static function sign(string $message): string
    {
        $cfg = self::config();
        openssl_sign($message, $signature, $cfg['private_key'], OPENSSL_ALGO_SHA256);
        return base64_encode($signature);
    }

    protected static function authHeader(string $method, string $url, string $body): string
    {
        $cfg = self::config();
        $ts = (string)time();
        $nonce = bin2hex(random_bytes(16));
        $message = "{$method}\n{$url}\n{$ts}\n{$nonce}\n{$body}\n";
        $sig = self::sign($message);
        $mchid = $cfg['mchid'];
        $serial = $cfg['serial_no'];
        return "WECHATPAY2-SHA256-RSA2048 mchid=\"{$mchid}\",nonce_str=\"{$nonce}\",timestamp=\"{$ts}\",serial_no=\"{$serial}\",signature=\"{$sig}\"";
    }

    protected static function request(string $method, string $path, array $body = []): array
    {
        $cfg = self::config();
        $bodyStr = $body ? json_encode($body, JSON_UNESCAPED_UNICODE) : '';
        $url = '/v3' . $path;
        $ch = curl_init('https://api.mch.weixin.qq.com' . $url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_POSTFIELDS => $bodyStr,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Accept: application/json',
                'User-Agent: b2cshop/1.0',
                'Authorization: ' . self::authHeader($method, $url, $bodyStr),
            ],
            CURLOPT_TIMEOUT => 30,
        ]);
        $resp = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $data = $resp ? (json_decode($resp, true) ?: []) : [];
        if ($code >= 300) {
            throw new BizException('微信支付请求失败: ' . ($data['message'] ?? "HTTP $code"));
        }
        return $data;
    }

    public static function jsapiOrder(string $outTradeNo, int $amountFen, string $description, string $openid): array
    {
        $cfg = self::config();
        $res = self::request('POST', '/pay/transactions/jsapi', [
            'mchid' => $cfg['mchid'],
            'out_trade_no' => $outTradeNo,
            'appid' => (string)Config::get('wechat.login.appid', ''),
            'description' => $description,
            'notify_url' => $cfg['notify_url'],
            'amount' => ['total' => $amountFen, 'currency' => 'CNY'],
            'payer' => ['openid' => $openid],
        ]);
        $prepayId = $res['prepay_id'] ?? '';
        return self::buildJsapiParams($prepayId);
    }

    protected static function buildJsapiParams(string $prepayId): array
    {
        $cfg = self::config();
        $ts = (string)time();
        $nonce = bin2hex(random_bytes(16));
        $package = 'prepay_id=' . $prepayId;
        $appId = (string)Config::get('wechat.login.appid', '');
        $message = "{$appId}\n{$ts}\n{$nonce}\n{$package}\n";
        $sig = self::sign($message);
        return [
            'appId' => $appId,
            'timeStamp' => $ts,
            'nonceStr' => $nonce,
            'package' => $package,
            'signType' => 'RSA',
            'paySign' => $sig,
        ];
    }

    public static function queryOrder(string $outTradeNo): array
    {
        $cfg = self::config();
        return self::request('GET', '/pay/transactions/out-trade-no/' . $outTradeNo . '?mchid=' . $cfg['mchid']);
    }

    public static function refund(string $outTradeNo, int $refundFen, int $totalFen, string $reason): array
    {
        return self::request('POST', '/refund/domestic/refunds', [
            'out_trade_no' => $outTradeNo,
            'out_refund_no' => 'R' . $outTradeNo . time(),
            'reason' => $reason,
            'amount' => ['refund' => $refundFen, 'total' => $totalFen, 'currency' => 'CNY'],
        ]);
    }

    public static function verifyNotify(array $headers, string $rawBody): ?array
    {
        $cfg = self::config();
        if ($cfg['platform_cert'] === '') {
            throw new BizException('微信支付平台证书未配置,无法验签');
        }
        $timestamp = $headers['wechatpay-timestamp'] ?? '';
        $nonce = $headers['wechatpay-nonce'] ?? '';
        $serial = $headers['wechatpay-serial'] ?? '';
        $signature = $headers['wechatpay-signature'] ?? '';
        if ($serial === '' || $serial !== $cfg['serial_no']) {
            return null;
        }
        $message = "{$timestamp}\n{$nonce}\n{$rawBody}\n";
        $publicKey = openssl_pkey_get_public($cfg['platform_cert']);
        if ($publicKey === false) {
            throw new BizException('微信支付平台证书无效');
        }
        $ok = openssl_verify($message, base64_decode($signature), $publicKey, OPENSSL_ALGO_SHA256) === 1;
        if (!$ok) {
            return null;
        }
        $resource = json_decode($rawBody, true)['resource'] ?? [];
        $ciphertext = base64_decode($resource['ciphertext'] ?? '');
        $nonce = $resource['nonce'] ?? '';
        $aad = $resource['associated_data'] ?? '';
        $tag = substr($ciphertext, -16);
        $ciphertext = substr($ciphertext, 0, -16);
        $decryptKey = self::apiV3Key();
        $plain = openssl_decrypt($ciphertext, 'aes-256-gcm', $decryptKey, OPENSSL_RAW_DATA, $nonce, $tag, $aad);
        return $plain ? (json_decode($plain, true) ?: null) : null;
    }

    protected static function apiV3Key(): string
    {
        $key = (string)Config::get('wechat.pay.api_v3_key', '');
        if ($key === '') {
            throw new BizException('微信支付 APIv3 密钥未配置');
        }
        return $key;
    }

    public static function parseNotifyTest(string $rawBody): array
    {
        return json_decode($rawBody, true) ?: [];
    }
}
