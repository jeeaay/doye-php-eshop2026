<?php
declare(strict_types=1);

namespace app\common\command;

use app\common\exception\BizException;
use app\common\release\ManifestSigner;
use think\console\Command;
use think\console\Input;
use think\console\input\Option;
use think\console\Output;

/**
 * 发布链路体检（发布端，仅维护者机器执行）
 *
 *   php think release:verify [--insecure]
 *
 * 仓库地址、分支、分发目录全部取自 config/update.php 的 distribution 分组（硬编码，不可在后台修改）。
 *
 * 检查四件事：
 *   1. 本地 `update/update.json` 的 Ed25519 签名（信任根，失败直接终止）；
 *   2. 版本链连续性：steps[i].to === steps[i+1].from，最后一条 to === latest，from 不重复；
 *   3. 每个源 raw 地址上的清单可下载、可验签、与本地清单一致，且每个 step 的资产
 *      `{raw}/v{to}/{asset}` HEAD 可达（Content-Length 不符仅告警）；
 *   4. 本地 `update/v{to}/` 里若存在同名文件，sha256 必须与清单一致。
 *
 * 退出码：0 通过 / 1 签名无效（含 update.json 缺失）/ 2 缺环或远端清单与本地不一致 / 3 资产缺失或哈希不符
 */
class ReleaseVerify extends Command
{
    /** 单个源的单次请求超时（秒），与站点端 config/update.php 的 timeout 对齐 */
    private const HTTP_TIMEOUT = 8;

    protected function configure(): void
    {
        $this->setName('release:verify')
            ->addOption('insecure', null, Option::VALUE_NONE, '仅做可达性探测时跳过 TLS 校验（本机 CA 未配置时用，不影响清单验签）')
            ->setDescription('校验发布链签名、连续性与各来源 raw 地址的清单/资产可达性（仅维护者机器）');
    }

    protected function execute(Input $input, Output $output): int
    {
        try {
            return $this->verify($input, $output);
        } catch (BizException $e) {
            $output->writeln('<error>' . $e->getMessage() . '</error>');
            return 1;
        }
    }

    private function verify(Input $input, Output $output): int
    {
        $root   = rtrim(str_replace('\\', '/', (string) $this->app->getRootPath()), '/');
        $dirRel = $this->distributionDir();
        $dir    = $root . '/' . $dirRel;

        $manifestPath = $dir . '/update.json';
        $signPath     = $dir . '/update.json.sig';

        // ---------------- 1. 签名 ----------------
        if (!is_file($manifestPath)) {
            $output->writeln('<error>签名无效：缺少 ' . $dirRel . '/update.json</error>');
            $output->writeln('  还没有正式发布产物属正常：先执行 php think release:build --ver=<x.y.z> 生成并签发清单。');
            return 1;
        }
        if (!is_file($signPath)) {
            $output->writeln('<error>签名无效：缺少 ' . $dirRel . '/update.json.sig（清单未签发，站点端会拒绝安装）</error>');
            return 1;
        }

        $manifestJson = (string) file_get_contents($manifestPath);
        $signature    = (string) file_get_contents($signPath);

        try {
            $valid = (new ManifestSigner())->verify($manifestJson, $signature);
        } catch (BizException $e) {
            $output->writeln('<error>签名无效：' . $e->getMessage() . '</error>');
            return 1;
        }
        if (!$valid) {
            $output->writeln('<error>签名无效：update.json.sig 与 update.json 不匹配（清单被改动或私钥/公钥不是一对）</error>');
            return 1;
        }

        $manifest = json_decode(ltrim($manifestJson, "\xEF\xBB\xBF"), true);
        if (!is_array($manifest)) {
            $output->writeln('<error>签名无效：update.json 不是合法 JSON</error>');
            return 1;
        }
        $output->writeln('<info>本地签名：有效</info>');

        // ---------------- 2. 版本链 ----------------
        $chainBad = $this->chainProblems($manifest);
        if ($chainBad !== []) {
            $output->writeln('<error>缺环：</error>');
            foreach ($chainBad as $item) {
                $output->writeln('  - ' . $item);
            }
            return 2;
        }

        /** @var array<int, array<string, mixed>> $steps */
        $steps  = (array) $manifest['steps'];
        $latest = (string) ($manifest['latest'] ?? '');
        $output->writeln(sprintf('<info>版本链：连续，共 %d 步，最新版本 %s</info>', count($steps), $latest));

        // version.json 与 latest 对齐（仅告警：开发中间态可能暂时超前/落后）
        $versionFile = $root . '/version.json';
        if (is_file($versionFile)) {
            $current = json_decode(ltrim((string) file_get_contents($versionFile), "\xEF\xBB\xBF"), true);
            $currentVersion = is_array($current) ? (string) ($current['version'] ?? '') : '';
            if ($currentVersion !== '' && $currentVersion !== $latest) {
                $output->writeln("<comment>警告：version.json={$currentVersion} 与 latest={$latest} 不一致（提交前请确认）</comment>");
            }
        }

        // ---------------- 3. 各来源的清单 + 资产 ----------------
        $insecure = (bool) $input->getOption('insecure');
        $order    = $this->distributionOrder();
        $missing  = [];
        $mismatch = [];

        $output->writeln('');
        $output->writeln('<comment>检查分发地址（config/update.php 的 distribution.order）：</comment>');

        foreach ($order as $name) {
            $base = $this->rawBase($name);
            if ($base === '') {
                $missing[] = "{$name}：config/update.php 缺少 repo / raw 配置，无法校验";
                $output->writeln("  <error>{$name} 未配置</error>");
                continue;
            }

            $manifestRes = $this->get($base . '/update.json', $insecure);
            if ($manifestRes['status'] !== 200 || trim($manifestRes['body']) === '') {
                $missing[] = "{$name} 清单不可达（{$base}/update.json）："
                    . ($manifestRes['status'] > 0 ? 'HTTP ' . $manifestRes['status'] : $manifestRes['error']);
                $output->writeln("  <error>{$name} 清单不可达</error> " . $base . '/update.json');
                continue;
            }

            $sigRes = $this->get($base . '/update.json.sig', $insecure);
            if ($sigRes['status'] !== 200 || trim($sigRes['body']) === '') {
                $missing[] = "{$name} 清单签名不可达（{$base}/update.json.sig）";
                $output->writeln("  <error>{$name} 清单签名缺失</error> " . $base . '/update.json.sig');
                continue;
            }

            try {
                $remoteValid = (new ManifestSigner())->verify($manifestRes['body'], $sigRes['body']);
            } catch (BizException $e) {
                $output->writeln("<error>{$name} 远端清单验签失败：" . $e->getMessage() . '</error>');
                return 1;
            }
            if (!$remoteValid) {
                $output->writeln("<error>{$name} 远端清单验签失败：签名与 update.json 不匹配</error>");
                return 1;
            }

            $remote = json_decode(ltrim($manifestRes['body'], "\xEF\xBB\xBF"), true);
            if (!is_array($remote)) {
                $output->writeln("<error>{$name} 远端 update.json 不是合法 JSON</error>");
                return 1;
            }

            $remoteProblems = $this->chainProblems($remote);
            foreach ($remoteProblems as $item) {
                $mismatch[] = "{$name} 远端清单：" . $item;
            }

            $diff = $this->compareManifests($manifest, $remote);
            foreach ($diff as $item) {
                $mismatch[] = "{$name}：" . $item;
            }

            $output->writeln("  <info>{$name} 清单可验签</info> " . $base . '/update.json');

            // 资产可达性：以端清单为准（远端缺资产时，站点端就是升不上来）
            foreach ((array) ($remote['steps'] ?? []) as $step) {
                if (!is_array($step)) {
                    continue;
                }
                $to = (string) ($step['to'] ?? '');
                $this->checkAsset($output, $name, $base, $to, (string) ($step['asset'] ?? ''), (int) ($step['asset_size'] ?? 0), $insecure, $missing);
                $this->checkAsset($output, $name, $base, $to, (string) ($step['ops_asset'] ?? ''), (int) ($step['delta_bytes'] ?? 0), $insecure, $missing);
                // 清单不记录 vendor 包体积，只校验可达性
                $this->checkAsset($output, $name, $base, $to, (string) ($step['vendor_asset'] ?? ''), 0, $insecure, $missing);
            }
        }

        // ---------------- 4. 本地产物哈希（update/v{to}/） ----------------
        $hashBad = [];
        $hashChecked = 0;
        foreach ($steps as $step) {
            $to = (string) ($step['to'] ?? '');
            foreach ([['asset', 'asset_sha256'], ['ops_asset', 'ops_sha256'], ['vendor_asset', 'vendor_sha256']] as [$nameKey, $shaKey]) {
                $asset = (string) ($step[$nameKey] ?? '');
                if ($asset === '') {
                    continue;
                }
                $file = $dir . '/v' . $to . '/' . $asset;
                if (!is_file($file)) {
                    continue;
                }
                $hashChecked++;
                $expected = (string) ($step[$shaKey] ?? '');
                $actual   = (string) hash_file('sha256', $file);
                if ($expected === '') {
                    $hashBad[] = "{$dirRel}/v{$to}/{$asset} 在清单中没有对应哈希";
                    continue;
                }
                if (!hash_equals($expected, $actual)) {
                    $hashBad[] = "{$dirRel}/v{$to}/{$asset} 哈希不符（清单 {$expected}，本地 {$actual}）";
                    continue;
                }
                $output->writeln("  <info>本地哈希一致</info> {$dirRel}/v{$to}/{$asset}");
            }
        }
        if ($hashChecked === 0) {
            $output->writeln('<comment>提示：' . $dirRel . '/v{version}/ 下没有可比对的产物</comment>');
        }
        foreach ($hashBad as $item) {
            $output->writeln('  <error>' . $item . '</error>');
        }

        // ---------------- 汇总 ----------------
        $output->writeln('');
        if ($missing !== [] || $mismatch !== [] || $hashBad !== []) {
            if ($mismatch !== []) {
                $output->writeln('<error>远端清单与本地不一致 / 远端链有问题（CDN 可能尚未刷新，可稍后重试）：</error>');
                foreach ($mismatch as $item) {
                    $output->writeln('  - ' . $item);
                }
            }
            if ($missing !== []) {
                $output->writeln('<error>资产缺失 / 不可达：</error>');
                foreach ($missing as $item) {
                    $output->writeln('  - ' . $item);
                }
            }
            if ($hashBad !== []) {
                $output->writeln('<error>产物哈希不符：</error>');
                foreach ($hashBad as $item) {
                    $output->writeln('  - ' . $item);
                }
            }
            return $hashBad === [] && $missing === [] ? 2 : 3;
        }

        $output->writeln('<info>通过：签名有效、版本链连续、各来源清单与资产均可用</info>');
        return 0;
    }

    // ------------------------------------------------------------------
    // 清单校验
    // ------------------------------------------------------------------

    /**
     * 版本链连续性检查（本地与远端清单共用同一套口径）
     *
     * @param array<string, mixed> $manifest
     * @return string[] 问题列表（空数组表示通过）
     */
    private function chainProblems(array $manifest): array
    {
        $bad = [];

        if ((int) ($manifest['schema'] ?? 0) !== 1) {
            $bad[] = 'schema 不是 1（当前 ' . (string) ($manifest['schema'] ?? '缺失') . '）';
        }

        $steps = $manifest['steps'] ?? null;
        if (!is_array($steps) || $steps === []) {
            return array_merge($bad, ['没有任何 step']);
        }

        $latest   = (string) ($manifest['latest'] ?? '');
        if ($latest === '') {
            $bad[] = '缺少 latest';
        }

        $seenFrom = [];
        $prevTo   = null;
        foreach ($steps as $index => $step) {
            if (!is_array($step)) {
                $bad[] = '第 ' . ($index + 1) . ' 条不是对象';
                continue;
            }
            $no   = $index + 1;
            $from = (string) ($step['from'] ?? '');
            $to   = (string) ($step['to'] ?? '');
            if ($from === '' || $to === '') {
                $bad[] = "第 {$no} 条缺少 from / to";
                continue;
            }
            if (isset($seenFrom[$from])) {
                $bad[] = "from {$from} 重复出现（链分叉）";
            }
            $seenFrom[$from] = true;

            if ($prevTo !== null && $from !== $prevTo) {
                $bad[] = "缺环：上一条 to={$prevTo}，本条 from={$from}";
            }
            if (version_compare($to, $from, '<=')) {
                $bad[] = "第 {$no} 条 to={$to} 不大于 from={$from}";
            }
            foreach (['asset', 'asset_sha256', 'ops_asset', 'ops_sha256'] as $field) {
                if (empty($step[$field])) {
                    $bad[] = "第 {$no} 条缺少 {$field}";
                }
            }
            $prevTo = $to;
        }

        if ($prevTo !== null && $latest !== '' && $prevTo !== $latest) {
            $bad[] = "最后一条 to={$prevTo} 与 latest={$latest} 不一致";
        }

        return $bad;
    }

    /**
     * 比较远端与本地清单（latest + 每条 step 的关键字段）
     *
     * @param array<string, mixed> $local
     * @param array<string, mixed> $remote
     * @return string[]
     */
    private function compareManifests(array $local, array $remote): array
    {
        $diff = [];

        $localLatest  = (string) ($local['latest'] ?? '');
        $remoteLatest = (string) ($remote['latest'] ?? '');
        if ($localLatest !== $remoteLatest) {
            $diff[] = "latest 不一致（本地 {$localLatest} / 远端 {$remoteLatest}）";
        }

        $localSteps  = array_values(array_filter((array) ($local['steps'] ?? []), 'is_array'));
        $remoteSteps = array_values(array_filter((array) ($remote['steps'] ?? []), 'is_array'));
        if (count($localSteps) !== count($remoteSteps)) {
            $diff[] = 'step 数量不一致（本地 ' . count($localSteps) . ' / 远端 ' . count($remoteSteps) . '）';
            return $diff;
        }

        $fields = ['from', 'to', 'asset', 'asset_sha256', 'ops_asset', 'ops_sha256', 'vendor_asset', 'vendor_sha256'];
        foreach ($localSteps as $index => $localStep) {
            $remoteStep = $remoteSteps[$index];
            foreach ($fields as $field) {
                $a = (string) ($localStep[$field] ?? '');
                $b = (string) ($remoteStep[$field] ?? '');
                if ($a !== $b) {
                    $diff[] = '第 ' . ($index + 1) . " 条 step 的 {$field} 不一致（本地 {$a} / 远端 {$b}）";
                }
            }
        }

        return $diff;
    }

    // ------------------------------------------------------------------
    // 分发坐标（全部来自 config/update.php）
    // ------------------------------------------------------------------

    /**
     * 分发目录（默认 update）
     */
    private function distributionDir(): string
    {
        $dir = trim(str_replace('\\', '/', (string) config('update.distribution.dir', 'update')), '/');
        return $dir !== '' ? $dir : 'update';
    }

    /**
     * 源优先级（默认 gitee → github）
     *
     * @return string[]
     */
    private function distributionOrder(): array
    {
        $order = [];
        foreach ((array) config('update.distribution.order', ['gitee', 'github']) as $name) {
            $name = strtolower(trim((string) $name));
            if ($name !== '' && !in_array($name, $order, true)) {
                $order[] = $name;
            }
        }
        return $order !== [] ? $order : ['gitee', 'github'];
    }

    /**
     * 按模板拼出某源的 raw 目录（缺配置返回空串）
     */
    private function rawBase(string $name): string
    {
        $template = trim((string) config('update.distribution.sources.' . $name . '.raw', ''));
        $repo     = trim((string) config('update.distribution.sources.' . $name . '.repo', ''));
        $branch   = trim((string) config('update.distribution.branch', 'main'));
        if ($template === '' || $repo === '') {
            return '';
        }
        return rtrim(strtr($template, [
            '{repo}'   => $repo,
            '{branch}' => $branch !== '' ? $branch : 'main',
            '{dir}'    => $this->distributionDir(),
        ]), '/');
    }

    // ------------------------------------------------------------------
    // HTTP
    // ------------------------------------------------------------------

    /**
     * 检查单个资产在某源上是否可达
     *
     * @param array<int, string> $missing 缺失清单（引用累加）
     */
    private function checkAsset(
        Output $output,
        string $source,
        string $base,
        string $version,
        string $asset,
        int $expectedSize,
        bool $insecure,
        array &$missing
    ): void {
        if ($asset === '' || $version === '') {
            return;
        }

        $url = $base . '/v' . $version . '/' . $asset;
        $res = $this->head($url, $insecure);

        if ($res['status'] === 200 || $res['status'] === 206) {
            $extra = '';
            if ($res['length'] !== null && $expectedSize > 0 && $res['length'] !== $expectedSize) {
                $extra = '（Content-Length=' . $res['length'] . ' 与清单记录 ' . $expectedSize
                    . ' 不一致，部分 CDN 会返回压缩长度）';
            }
            $output->writeln("  <info>资产可达</info> {$source} v{$version}/{$asset}{$extra}");
            return;
        }

        $detail = $res['status'] > 0 ? 'HTTP ' . $res['status'] : $res['error'];
        $missing[] = "{$source} v{$version}（{$asset}）：{$detail}";
        $output->writeln("  <error>资产不可达</error> {$source} v{$version}/{$asset}：{$detail}");
    }

    /**
     * GET：返回状态码与响应体（清单与签名用）
     *
     * @param bool $insecure 跳过 TLS 校验（仅用于本机 CA 未配置时的人工排查）
     * @return array{status: int, body: string, error: string}
     */
    private function get(string $url, bool $insecure = false): array
    {
        if ($url === '') {
            return ['status' => 0, 'body' => '', 'error' => 'URL 为空'];
        }

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            $options = [
                CURLOPT_HTTPGET        => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS      => 5,
                CURLOPT_CONNECTTIMEOUT => self::HTTP_TIMEOUT,
                CURLOPT_TIMEOUT        => self::HTTP_TIMEOUT,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_SSL_VERIFYPEER => !$insecure,
                CURLOPT_USERAGENT      => 'doyecart-release-verify',
            ];
            if ($insecure) {
                $options[CURLOPT_SSL_VERIFYHOST] = 0;
            }
            $caBundle = self::caBundle();
            if (!$insecure && $caBundle !== null) {
                $options[CURLOPT_CAINFO] = $caBundle;
            }
            curl_setopt_array($ch, $options);
            $body   = curl_exec($ch);
            $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            $error  = (string) curl_error($ch);

            return [
                'status' => $status,
                'body'   => is_string($body) ? $body : '',
                'error'  => $status === 0 ? ($error !== '' ? $error : '请求失败') : '',
            ];
        }

        // 无 curl：用 stream context 兜底
        $context = stream_context_create([
            'http' => [
                'method'          => 'GET',
                'timeout'         => self::HTTP_TIMEOUT,
                'follow_location' => 1,
                'max_redirects'   => 5,
                'ignore_errors'   => true,
                'header'          => "User-Agent: doyecart-release-verify\r\n",
            ],
            'ssl' => [
                'verify_peer'      => !$insecure,
                'verify_peer_name' => !$insecure,
            ],
        ]);
        $body = @file_get_contents($url, false, $context);
        if (!is_string($body)) {
            return ['status' => 0, 'body' => '', 'error' => '请求失败（无 curl 扩展）'];
        }
        $statusLine = (string) ($http_response_header[0] ?? '');
        $status     = preg_match('#\s(\d{3})\s#', $statusLine, $m) === 1 ? (int) $m[1] : 0;

        return ['status' => $status, 'body' => $body, 'error' => ''];
    }

    /**
     * HEAD 请求：返回状态码与 Content-Length
     *
     * @param bool $insecure 跳过 TLS 校验（仅用于本机 CA 未配置时的人工排查）
     * @return array{status: int, length: ?int, error: string}
     */
    private function head(string $url, bool $insecure = false): array
    {
        if ($url === '') {
            return ['status' => 0, 'length' => null, 'error' => 'URL 模板为空'];
        }

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            $options = [
                CURLOPT_NOBODY         => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS      => 5,
                CURLOPT_CONNECTTIMEOUT => self::HTTP_TIMEOUT,
                CURLOPT_TIMEOUT        => self::HTTP_TIMEOUT,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_SSL_VERIFYPEER => !$insecure,
                CURLOPT_USERAGENT      => 'doyecart-release-verify',
            ];
            if ($insecure) {
                $options[CURLOPT_SSL_VERIFYHOST] = 0;
            }
            $caBundle = self::caBundle();
            if (!$insecure && $caBundle !== null) {
                $options[CURLOPT_CAINFO] = $caBundle;
            }
            curl_setopt_array($ch, $options);
            curl_exec($ch);
            $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            $length = curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
            $error  = (string) curl_error($ch);

            if ($status === 0 && $error !== '' && stripos($error, 'certificate') !== false) {
                $error .= '（本机未配置 CA；可设置 php.ini 的 curl.cainfo，或加 --insecure 仅做可达性探测）';
            }

            return [
                'status' => $status,
                'length' => is_numeric($length) && (int) $length >= 0 ? (int) $length : null,
                'error'  => $status === 0 ? ($error !== '' ? $error : '请求失败') : '',
            ];
        }

        // 无 curl：用 stream context 兜底
        $context = stream_context_create([
            'http' => [
                'method'          => 'HEAD',
                'timeout'         => self::HTTP_TIMEOUT,
                'follow_location' => 1,
                'max_redirects'   => 5,
                'ignore_errors'   => true,
                'header'          => "User-Agent: doyecart-release-verify\r\n",
            ],
            'ssl' => [
                'verify_peer'      => !$insecure,
                'verify_peer_name' => !$insecure,
            ],
        ]);
        $headers = @get_headers($url, true, $context);
        if (!is_array($headers) || $headers === []) {
            return ['status' => 0, 'length' => null, 'error' => '请求失败（无 curl 扩展）'];
        }
        $statusLine = (string) ($headers[0] ?? '');
        $status     = preg_match('#\s(\d{3})\s#', $statusLine, $m) === 1 ? (int) $m[1] : 0;
        $length     = null;
        if (isset($headers['Content-Length'])) {
            $raw    = is_array($headers['Content-Length']) ? end($headers['Content-Length']) : $headers['Content-Length'];
            $length = is_numeric($raw) ? (int) $raw : null;
        }

        return ['status' => $status, 'length' => $length, 'error' => ''];
    }

    /**
     * 找一个可用的 CA 证书包（Windows 上 php.ini 常常没配 curl.cainfo）
     */
    private static function caBundle(): ?string
    {
        foreach (['curl.cainfo', 'openssl.cafile'] as $key) {
            $value = trim((string) ini_get($key));
            if ($value !== '' && is_file($value)) {
                return $value;
            }
        }

        $candidates = [
            '/etc/ssl/certs/ca-certificates.crt',
            '/etc/pki/tls/certs/ca-bundle.crt',
            '/usr/local/etc/openssl/cert.pem',
            '/opt/homebrew/etc/openssl@3/cert.pem',
            'C:/Program Files/Git/mingw64/etc/ssl/certs/ca-bundle.crt',
            'C:/Program Files/Git/mingw64/ssl/certs/ca-bundle.crt',
        ];
        foreach ($candidates as $path) {
            if (is_file($path)) {
                return $path;
            }
        }

        return null;
    }
}