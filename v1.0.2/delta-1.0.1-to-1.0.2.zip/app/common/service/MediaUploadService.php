<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\exception\BizException;
use think\file\UploadedFile;

class MediaUploadService
{
    public function cleanupUnreferenced(int $olderThanSeconds = 86400, int $limit = 500): int
    {
        $root = realpath(public_path() . 'uploads/products');
        if (!$root || $olderThanSeconds < 0 || $limit < 1) {
            return 0;
        }

        $cutoff = time() - $olderThanSeconds;
        $deleted = 0;
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ($iterator as $file) {
            if (!$file->isFile() || $file->getMTime() > $cutoff || $deleted >= $limit) {
                continue;
            }
            $path = str_replace('\\', '/', $file->getPathname());
            if (!preg_match('~/products/(images|videos)/\d{6}/[a-f0-9]{32}\.(jpg|jpeg|png|webp|mp4|webm)$~', $path)) {
                continue;
            }
            $url = '/' . substr($path, strpos($path, '/uploads/'));
            $referenced = \think\facade\Db::name('product')
                ->where(function ($query) use ($url) {
                    $query->where('main_image', $url)
                        ->whereOr('video_url', $url)
                        ->whereOr('video_cover', $url)
                        ->whereOrLike('detail_html', '%' . addcslashes($url, '%_') . '%');
                })->find();
            if (!$referenced) {
                foreach (\think\facade\Db::name('product')->whereNotNull('images_json')->column('images_json') as $images) {
                    $images = is_array($images) ? $images : json_decode((string) $images, true);
                    if (is_array($images) && in_array($url, $images, true)) {
                        $referenced = true;
                        break;
                    }
                }
            }
            if (!$referenced && @unlink($file->getPathname())) {
                $deleted++;
            }
        }
        return $deleted;
    }

    public function upload(?UploadedFile $file, string $mediaType, string $namespace = 'products'): array
    {
        if (!$file || !$file->isValid()) {
            throw new BizException('请选择有效的上传文件');
        }
        if (!in_array($mediaType, ['image', 'video'], true)) {
            throw new BizException('媒体类型无效');
        }

        $isImage = $mediaType === 'image';
        $namespaceConfig = config('media.' . $namespace);
        if (!is_array($namespaceConfig) || !isset($namespaceConfig[$isImage ? 'image' : 'video'])) {
            throw new BizException('媒体资源类型无效');
        }
        $config = $namespaceConfig[$isImage ? 'image' : 'video'];
        $maxSize = (int) $config['max_size'];
        $extension = strtolower((string) $file->extension());
        $allowedExtensions = $config['extensions'];
        if ((int) $file->getSize() <= 0 || (int) $file->getSize() > $maxSize || !in_array($extension, $allowedExtensions, true)) {
            throw new BizException($isImage ? '图片必须是 10MB 以内的 jpg、png 或 webp 文件' : '视频必须是 200MB 以内的 mp4 或 webm 文件');
        }

        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($file->getPathname());
        $allowedMimes = $config['mimes'];
        if (!in_array($mime, $allowedMimes, true)) {
            throw new BizException('文件真实类型与扩展名不匹配');
        }
        $meta = ['size' => (int) $file->getSize(), 'mime' => $mime];
        if ($isImage) {
            $dimensions = @getimagesize($file->getPathname());
            if (!$dimensions) {
                throw new BizException('图片解析失败');
            }
            $meta['width'] = (int) $dimensions[0];
            $meta['height'] = (int) $dimensions[1];
        } elseif (!$this->hasVideoContainerSignature($file->getPathname(), $extension)) {
            throw new BizException('视频容器格式无效');
        }

        $month = date('Ym');
        $relativeDirectory = '/uploads/' . $namespace . '/' . ($isImage ? 'images/' : 'videos/') . $month . '/';
        $directory = public_path() . ltrim($relativeDirectory, '/');
        if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
            throw new BizException('上传目录不可写');
        }
        $filename = bin2hex(random_bytes(16)) . '.' . $extension;
        if (!move_uploaded_file($file->getPathname(), $directory . $filename)) {
            throw new BizException('文件保存失败');
        }
        return ['url' => $relativeDirectory . $filename, 'mime' => $mime] + $meta;
    }

    /**
     * 通过原始字节保存媒体（API base64 / 下载场景）
     *
     * @param string $contents     文件内容
     * @param string $originalName 原始文件名（用于推导扩展名）
     * @param string $mediaType    image | video
     * @param string $namespace    products | brands | pages | merchants
     * @return array{url:string,mime:string,size:int}
     */
    public function storeContents(string $contents, string $originalName, string $mediaType, string $namespace = 'products'): array
    {
        if ($contents === '') {
            throw new BizException('媒体内容为空');
        }

        $tmp = tempnam(sys_get_temp_dir(), 'media_');
        if ($tmp === false || file_put_contents($tmp, $contents) === false) {
            throw new BizException('媒体临时文件写入失败');
        }

        try {
            return $this->storeFromTempFile($tmp, $originalName, $mediaType, $namespace);
        } finally {
            @unlink($tmp);
        }
    }

    /**
     * 通过临时文件保存媒体
     *
     * @param string $tmpPath      临时文件路径
     * @param string $originalName 原始文件名（用于推导扩展名）
     * @param string $mediaType    image | video
     * @param string $namespace    products | brands | pages | merchants
     * @return array{url:string,mime:string,size:int}
     */
    public function storeFromTempFile(string $tmpPath, string $originalName, string $mediaType, string $namespace = 'products'): array
    {
        if (!is_file($tmpPath)) {
            throw new BizException('媒体临时文件不存在');
        }

        $config = $this->mediaConfig($namespace, $mediaType);
        $isImage = $mediaType === 'image';
        $size = (int) filesize($tmpPath);
        $extension = strtolower((string) pathinfo($originalName, PATHINFO_EXTENSION));
        if ($extension === '') {
            $extension = $this->extensionFromMime((string) ($config['mimes'][0] ?? ''), $config);
        }

        $this->assertMediaSizeAndExtension($size, $extension, $config, $isImage);

        $mime = (string) (new \finfo(FILEINFO_MIME_TYPE))->file($tmpPath);
        if (!in_array($mime, (array) $config['mimes'], true)) {
            throw new BizException('文件真实类型与扩展名不匹配');
        }

        $meta = ['size' => $size, 'mime' => $mime];
        if ($isImage) {
            $dimensions = @getimagesize($tmpPath);
            if (!$dimensions) {
                throw new BizException('图片解析失败');
            }
            $meta['width'] = (int) $dimensions[0];
            $meta['height'] = (int) $dimensions[1];
        } elseif (!$this->hasVideoContainerSignature($tmpPath, $extension)) {
            throw new BizException('视频容器格式无效');
        }

        $month = date('Ym');
        $relativeDirectory = '/uploads/' . $namespace . '/' . ($isImage ? 'images/' : 'videos/') . $month . '/';
        $directory = public_path() . ltrim($relativeDirectory, '/');
        if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
            throw new BizException('上传目录不可写');
        }
        $filename = bin2hex(random_bytes(16)) . '.' . $extension;
        if (!copy($tmpPath, $directory . $filename)) {
            throw new BizException('文件保存失败');
        }

        return ['url' => $relativeDirectory . $filename, 'mime' => $mime] + $meta;
    }

    /**
     * 解析 data:image/...;base64,... 形式的媒体
     *
     * @param string $dataUri   data URI
     * @param string $mediaType image | video
     * @param string $namespace 资源命名空间
     * @return array{url:string,mime:string,size:int}
     */
    public function parseDataUri(string $dataUri, string $mediaType, string $namespace = 'products'): array
    {
        if (!preg_match('#^data:([a-z0-9.+/-]+);base64,(.*)$#is', $dataUri, $matches)) {
            throw new BizException('base64 媒体格式无效');
        }

        $mime = strtolower(trim($matches[1]));
        $config = $this->mediaConfig($namespace, $mediaType);
        $index = array_search($mime, (array) $config['mimes'], true);
        if ($index === false) {
            throw new BizException('base64 媒体类型不受支持');
        }

        $bytes = base64_decode(preg_replace('/\s+/', '', $matches[2]) ?? '', true);
        if ($bytes === false) {
            throw new BizException('base64 内容解码失败');
        }

        $extension = $this->extensionFromMime($mime, $config);
        if ($extension === '') {
            throw new BizException('base64 媒体类型不受支持');
        }

        return $this->storeContents($bytes, 'upload.' . $extension, $mediaType, $namespace);
    }

    /**
     * 从远程 URL 下载并保存媒体
     *
     * 安全约束：仅 http/https、最多 3 次跳转、拒绝私有/环回/保留地址、
     * 超时 10 秒、大小受 config/media.php 限制。
     *
     * @param string $url       远程地址
     * @param string $mediaType image | video
     * @param string $namespace 资源命名空间
     * @return array{url:string,mime:string,size:int}
     */
    public function importFromUrl(string $url, string $mediaType, string $namespace = 'products'): array
    {
        $config = $this->mediaConfig($namespace, $mediaType);
        $maxSize = (int) $config['max_size'];

        $tmp = tempnam(sys_get_temp_dir(), 'media_url_');
        if ($tmp === false) {
            throw new BizException('媒体临时文件创建失败');
        }

        $handle = fopen($tmp, 'wb');
        if (!$handle) {
            @unlink($tmp);
            throw new BizException('媒体临时文件不可写');
        }

        $current = $url;
        $contentType = '';
        $finalUrl = $url;
        $downloaded = false;

        try {
            for ($redirect = 0; $redirect <= 3; $redirect++) {
                $this->assertSafeRemoteUrl($current);

                $location = '';
                $ch = curl_init($current);
                if ($ch === false) {
                    throw new BizException('媒体下载初始化失败');
                }

                curl_setopt_array($ch, [
                    CURLOPT_FILE            => $handle,
                    CURLOPT_FOLLOWLOCATION  => false,
                    CURLOPT_TIMEOUT         => 10,
                    CURLOPT_CONNECTTIMEOUT  => 5,
                    CURLOPT_MAXFILESIZE     => $maxSize,
                    CURLOPT_USERAGENT       => 'AlmiAdminAPI/1.0',
                    CURLOPT_SSL_VERIFYPEER  => true,
                    CURLOPT_HEADERFUNCTION  => static function ($curl, string $header) use (&$location): int {
                        if (stripos($header, 'location:') === 0) {
                            $location = trim(substr($header, 9));
                        }
                        return strlen($header);
                    },
                    CURLOPT_NOPROGRESS       => false,
                    CURLOPT_PROGRESSFUNCTION => static function ($curl, $downloadTotal, $downloaded) use ($maxSize): int {
                        return $downloaded > $maxSize ? 1 : 0;
                    },
                ]);

                $ok = curl_exec($ch);
                $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
                $contentType = (string) curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
                $finalUrl = (string) curl_getinfo($ch, CURLINFO_EFFECTIVE_URL) ?: $current;
                $error = (string) curl_error($ch);

                if ($ok === false) {
                    throw new BizException('媒体下载失败：' . ($error !== '' ? $error : '网络错误'));
                }

                if (in_array($status, [301, 302, 303, 307, 308], true)) {
                    if ($location === '' || $redirect >= 3) {
                        throw new BizException('媒体下载跳转次数过多');
                    }
                    $current = $this->resolveRedirectUrl($finalUrl, $location);
                    if (ftruncate($handle, 0) === false || rewind($handle) === false) {
                        throw new BizException('媒体临时文件重置失败');
                    }
                    continue;
                }

                if ($status < 200 || $status >= 300) {
                    throw new BizException('媒体下载失败：HTTP ' . $status);
                }

                $downloaded = true;
                break;
            }
        } finally {
            fclose($handle);
            if (!$downloaded) {
                @unlink($tmp);
            }
        }

        try {
            $size = (int) filesize($tmp);
            if ($size <= 0) {
                throw new BizException('下载内容为空');
            }
            if ($size > $maxSize) {
                throw new BizException('媒体文件超过大小限制');
            }

            $extension = strtolower((string) pathinfo((string) parse_url($finalUrl, PHP_URL_PATH), PATHINFO_EXTENSION));
            if (!in_array($extension, (array) $config['extensions'], true)) {
                $mime = strtolower(trim(explode(';', $contentType)[0]));
                $extension = $this->extensionFromMime($mime, $config);
                if ($extension === '') {
                    throw new BizException('无法识别媒体类型');
                }
            }

            return $this->storeFromTempFile($tmp, 'download.' . $extension, $mediaType, $namespace);
        } finally {
            @unlink($tmp);
        }
    }

    /**
     * 读取并校验命名空间/媒体类型配置
     *
     * @param string $namespace 资源命名空间
     * @param string $mediaType image | video
     * @return array
     */
    private function mediaConfig(string $namespace, string $mediaType): array
    {
        if (!in_array($mediaType, ['image', 'video'], true)) {
            throw new BizException('媒体类型无效');
        }
        if (!in_array($namespace, ['products', 'brands', 'pages', 'merchants'], true)) {
            throw new BizException('媒体资源类型无效');
        }

        $namespaceConfig = config('media.' . $namespace);
        $key = $mediaType === 'image' ? 'image' : 'video';
        if (!is_array($namespaceConfig) || !isset($namespaceConfig[$key])) {
            throw new BizException('媒体资源类型无效');
        }

        return (array) $namespaceConfig[$key];
    }

    /**
     * 校验大小与扩展名
     *
     * @param int   $size      字节数
     * @param string $extension 扩展名
     * @param array $config     媒体配置
     * @param bool  $isImage    是否图片
     * @return void
     */
    private function assertMediaSizeAndExtension(int $size, string $extension, array $config, bool $isImage): void
    {
        $maxSize = (int) ($config['max_size'] ?? 0);
        $maxMb = $maxSize > 0 ? (int) ceil($maxSize / 1024 / 1024) : 0;
        $label = $isImage ? '图片' : '视频';
        $extensions = implode('、', (array) ($config['extensions'] ?? []));

        if ($size <= 0 || ($maxSize > 0 && $size > $maxSize) || !in_array($extension, (array) ($config['extensions'] ?? []), true)) {
            throw new BizException($label . '必须是 ' . $maxMb . 'MB 以内的 ' . $extensions . ' 文件');
        }
    }

    /**
     * 按 MIME 推导扩展名
     *
     * @param string $mime   MIME
     * @param array  $config 媒体配置
     * @return string
     */
    private function extensionFromMime(string $mime, array $config): string
    {
        $map = [
            'image/jpeg' => 'jpg',
            'image/png'  => 'png',
            'image/webp' => 'webp',
            'video/mp4'  => 'mp4',
            'video/webm' => 'webm',
        ];
        $extension = $map[strtolower($mime)] ?? '';
        $allowed = (array) ($config['extensions'] ?? []);

        return in_array($extension, $allowed, true) ? $extension : '';
    }

    /**
     * 校验远程 URL（协议、DNS、私网地址）
     *
     * @param string $url 远程地址
     * @return void
     */
    private function assertSafeRemoteUrl(string $url): void
    {
        $parts = parse_url($url);
        if (!is_array($parts) || !in_array(strtolower((string) ($parts['scheme'] ?? '')), ['http', 'https'], true) || empty($parts['host'])) {
            throw new BizException('媒体地址协议不受支持');
        }

        $host = strtolower((string) $parts['host']);
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            $this->assertPublicIp($host);
            return;
        }

        $ips = gethostbynamel($host) ?: [];
        $records = @dns_get_record($host, DNS_AAAA) ?: [];
        foreach ($records as $record) {
            if (!empty($record['ipv6'])) {
                $ips[] = $record['ipv6'];
            }
        }
        if (!$ips) {
            throw new BizException('媒体地址域名解析失败');
        }

        foreach ($ips as $ip) {
            $this->assertPublicIp((string) $ip);
        }
    }

    /**
     * 拒绝私有/环回/保留地址
     *
     * @param string $ip IP 地址
     * @return void
     */
    private function assertPublicIp(string $ip): void
    {
        $valid = filter_var(
            $ip,
            FILTER_VALIDATE_IP,
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
        );
        if ($valid === false) {
            throw new BizException('媒体地址不允许指向内网');
        }

        if (str_starts_with($ip, '127.')
            || str_starts_with($ip, '10.')
            || str_starts_with($ip, '192.168.')
            || str_starts_with($ip, '169.254.')
            || str_starts_with($ip, '0.')
            || str_starts_with($ip, '::1')
            || str_starts_with($ip, 'fc')
            || str_starts_with($ip, 'fd')
            || str_starts_with($ip, 'fe80')) {
            throw new BizException('媒体地址不允许指向内网');
        }

        if (preg_match('/^172\.(1[6-9]|2[0-9]|3[0-1])\./', $ip)) {
            throw new BizException('媒体地址不允许指向内网');
        }
    }

    /**
     * 解析跳转地址
     *
     * @param string $baseUrl  当前地址
     * @param string $location Location 头
     * @return string
     */
    private function resolveRedirectUrl(string $baseUrl, string $location): string
    {
        if (preg_match('#^https?://#i', $location)) {
            return $location;
        }

        $parts = parse_url($baseUrl);
        if (!is_array($parts) || empty($parts['host'])) {
            throw new BizException('媒体跳转地址无效');
        }

        $scheme = strtolower((string) ($parts['scheme'] ?? 'http'));
        $host = (string) $parts['host'];
        $port = isset($parts['port']) ? ':' . (int) $parts['port'] : '';

        if (str_starts_with($location, '//')) {
            return $scheme . ':' . $location;
        }
        if (str_starts_with($location, '/')) {
            return $scheme . '://' . $host . $port . $location;
        }

        $directory = rtrim(dirname((string) ($parts['path'] ?? '/')), '/');
        return $scheme . '://' . $host . $port . $directory . '/' . $location;
    }

    private function hasVideoContainerSignature(string $path, string $extension): bool
    {
        $handle = @fopen($path, 'rb');
        if (!$handle) {
            return false;
        }
        $header = (string) fread($handle, 64);
        fclose($handle);

        if ($extension === 'webm') {
            return strncmp($header, "\x1A\x45\xDF\xA3", 4) === 0;
        }

        // ISO Base Media files contain an "ftyp" box near the beginning.
        return strpos($header, 'ftyp') !== false;
    }
}
