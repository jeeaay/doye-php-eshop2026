<?php
declare(strict_types=1);

namespace app\common\service\update;

use app\common\exception\BizException;

/**
 * 本地目录更新源（自测 / 内网镜像）
 *
 * 目录结构（base 默认 runtime/update/testsrc）：
 *   {base}/update.json
 *   {base}/update.json.sig
 *   {base}/v{version}/{assetName}
 *
 * **只在调试模式或显式设置 UPDATE_LOCAL_SOURCE=1 时可用**：生产环境开着它等于给攻击者
 * 一个「让站点从任意本地路径取包」的入口。
 */
class LocalSource implements UpdateSourceInterface
{
    private UpdatePackage $package;

    public function __construct(?UpdatePackage $package = null)
    {
        $this->package = $package ?? new UpdatePackage();
    }

    /**
     * 当前环境是否允许使用本地源
     *
     * 必须**显式**开启，绝不由 app_debug 推导：生产站点误开 debug 时不应该去读本地路径，
     * 否则错误信息会泄露服务器绝对路径，也会让人误以为「更新源是一个本地文件」。
     */
    public static function available(): bool
    {
        if (getenv('UPDATE_LOCAL_SOURCE') === '1') {
            return true;
        }
        try {
            return (bool) config('update.sources.local.enabled', false);
        } catch (\Throwable $e) {
            return false;
        }
    }

    public function name(): string
    {
        return 'local';
    }

    public function fetchManifest(): array
    {
        $this->assertAvailable();
        $base = $this->base();

        $raw = @file_get_contents($base . '/update.json');
        if ($raw === false) {
            throw new BizException("本地更新源缺少清单：{$base}/update.json");
        }
        $signature = @file_get_contents($base . '/update.json.sig');
        if ($signature === false) {
            throw new BizException("本地更新源缺少签名：{$base}/update.json.sig");
        }

        return [
            'manifest'     => $this->package->parseManifest($raw),
            'manifest_raw' => $raw,
            'signature'    => $signature,
            'source'       => 'local',
        ];
    }

    public function fetchAsset(string $assetName, string $version, string $dest): void
    {
        $this->assertAvailable();
        UpdatePackage::assertSafeAssetName($assetName);

        $source = $this->base() . '/v' . $version . '/' . $assetName;
        if (!is_file($source)) {
            throw new BizException("本地更新源缺少资产：{$source}");
        }

        $dir = dirname($dest);
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
            throw new BizException("无法创建目录：{$dir}");
        }

        $part = $dest . '.part';
        @unlink($part);
        if (!@copy($source, $part)) {
            @unlink($part);
            throw new BizException("复制本地资产失败：{$source} → {$part}");
        }
        if (is_file($dest)) {
            @unlink($dest);
        }
        if (!@rename($part, $dest)) {
            @unlink($part);
            throw new BizException("无法写入本地资产副本：{$dest}");
        }
    }

    public function headAsset(string $assetName, string $version): array
    {
        $this->assertAvailable();
        UpdatePackage::assertSafeAssetName($assetName);

        $path = $this->base() . '/v' . $version . '/' . $assetName;
        if (!is_file($path)) {
            return ['status' => 404, 'length' => null];
        }

        return ['status' => 200, 'length' => (int) filesize($path)];
    }

    // ------------------------------------------------------------------
    // 内部工具
    // ------------------------------------------------------------------

    private function assertAvailable(): void
    {
        if (!self::available()) {
            throw new BizException('本地更新源仅在调试模式（app_debug）或设置环境变量 UPDATE_LOCAL_SOURCE=1 时可用');
        }
    }

    /**
     * 本地源根目录，相对路径按项目根解析
     */
    private function base(): string
    {
        $base = str_replace('\\', '/', (string) config('update.sources.local.base', 'runtime/update/testsrc'));
        $base = trim($base);
        if ($base === '') {
            $base = 'runtime/update/testsrc';
        }
        if (preg_match('#^[A-Za-z]:/#', $base) || str_starts_with($base, '/')) {
            return rtrim($base, '/');
        }

        $root = rtrim(str_replace('\\', '/', (string) app()->getRootPath()), '/');
        return $root . '/' . ltrim($base, '/');
    }
}