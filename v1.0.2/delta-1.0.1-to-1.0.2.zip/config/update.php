<?php

/**
 * 在线更新：技术参数（站点不可改）
 *
 * 本文件只放「改了就可能造成安全问题」的技术参数：分发 / 推送地址、验签公钥、
 * 超时、可写目录白名单、保护路径。这些值不随站点变化，也不提供后台编辑入口。
 *
 * **分发地址与推送地址是唯一来源，站点端与后台均不可修改；改地址只能改本文件并随新版本发布。**
 *
 * 站点可调项（是否启用更新、备份保留份数、维护窗口开关）在 config/site.php 的 update 分组，
 * 并由 setting 表覆盖，对应后台「系统设置 → 更新设置」。
 *
 * 分发模型：`update/` 是一个**独立的 git 仓库**（仓库根目录 = update/），
 * 发布端把产物提交进该仓库并推送到 Gitee / GitHub；公开仓库里只有增量包与清单，
 * 不含任何源码。站点端按 `distribution.order` 依次从各源的 raw 地址拉取，
 * 前一个源失败自动切下一个。
 *
 * 分发源 URL 模板占位符（raw 地址就是分发仓库的根）：
 *   {repo}    仓库坐标，形如 jeay/doye-php-eshop2026（不含协议与域名）
 *   {branch}  分发分支
 */
return [
    // 单个源的单次请求超时（秒）
    'timeout' => 8,

    // 「检查更新」结果的缓存时长（秒）
    'cache_ttl' => 600,

    // 备份保留批次数量（默认值，可被站点设置 update.backup_keep 覆盖）
    'backup_keep' => 3,

    // 分发坐标：唯一来源，站点端与后台均不可修改
    'distribution' => [
        // 分发分支（清单与产物所在分支）
        'branch' => 'main',

        // 分发目录（本地的独立 git 仓库目录，仓库根 = 该目录；不参与 URL 拼接）
        'dir'    => 'update',

        // 源优先级：站点端按此顺序拉清单/资产，发布端 --push 按此顺序推送
        'order'  => ['gitee', 'github'],

        'sources' => [
            'gitee' => [
                'repo' => 'jeay/doye-php-eshop2026',
                // raw 前缀 = 分发仓库根：清单 {raw}/update.json，资产 {raw}/v{version}/{asset}
                'raw'  => 'https://gitee.com/{repo}/raw/{branch}',
                // 发布端 git push 目标
                'push' => 'git@gitee.com:jeay/doye-php-eshop2026.git',
            ],
            'github' => [
                'repo' => 'jeeaay/doye-php-eshop2026',
                'raw'  => 'https://raw.githubusercontent.com/{repo}/{branch}',
                'push' => 'git@github.com:jeeaay/doye-php-eshop2026.git',
            ],
        ],
    ],

    // 分发源 URL 模板
    'sources' => [
        'local' => [
            // 本地目录更新源（自测 / 内网镜像）：{base}/update.json、{base}/v{version}/{asset}
            // 默认关闭；自测通过 Config::set 显式打开，或设置环境变量 UPDATE_LOCAL_SOURCE=1
            'enabled' => false,
            'base'    => 'runtime/update/testsrc',
        ],
    ],

    // 清单签名公钥（Ed25519）：由 `php think release:keygen` 生成后填入
    'public_key' => 'gvQVF7WUcuv6bFiBD8DkinB7kV1ubp/uM7BUQp0WZJU=',

    // 更新允许写入的根目录（相对项目根目录，不带尾部斜杠）
    'manage_roots' => [
        'app',
        'config',
        'route',
        'database',
        'docs',
        'extend',
        'public/static',
        'public/eshop2026',
    ],

    // 允许写入的单文件（仓库根或 public/ 下的入口文件）
    // 这几份都是随代码发布的程序文件；站点私有数据不在这里（见 protected_paths）
    // 注意：update.json / update.json.sig 不在其中 —— 清单只存在于分发目录，不允许被增量包覆盖
    'root_files' => [
        'version.json',
        'CHANGELOG.md',
        'think',
        'public/index.php',
        'public/router.php',
    ],

    // 永不覆盖的路径
    // vendor 在 need_vendor 时由专门逻辑（整目录备份 + 解压替换）处理，不逐文件写入
    'protected_paths' => [
        '.env',
        'composer.json',
        'composer.lock',
        'runtime',
        'public/uploads',
        '.git',
        'vendor',
    ],

    // 维护窗口：安装期间前台返回 503，后台与管理 API 放行
    'maintenance' => [
        'enabled'        => true,
        // 标记超过这个秒数仍未清除，视为「升级进程已中断」，放行前台
        // （否则一次被杀死的步骤会把整站永久锁在 503）
        'stale_seconds'  => 1800,
        // 放行的 URL 前缀（后台页面与管理 API，避免升级把后台自己锁死）
        'allow_prefixes' => ['/admin', '/admin-api'],
    ],
];