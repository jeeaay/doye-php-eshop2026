<?php
declare(strict_types=1);

namespace app\common\service;

/**
 * 本地图片缩略图
 *
 * 1) 商品卡缩略图：上传时预生成常用尺寸；历史图片在首次前台访问时按需生成并落盘缓存。
 * 2) 首页 Banner 断点裁剪图：按视口断点宽度中心裁剪（保留中间、裁掉左右两侧），
 *    供 <img srcset> 根据实际视口宽度自动选择，避免窄屏也下载整张大图。
 *
 * 产物目录：public/uploads/thumbs/{width}/{原相对路径}
 *          public/uploads/thumbs/banner-{width}/{原相对路径}
 */
class ThumbnailService
{
    /** 首页/列表商品卡使用的宽度 */
    public const PRODUCT_CARD_WIDTH = 480;

    /** 上传后预生成的商品缩略宽度 */
    private const PRESET_WIDTHS = [160, 480, 960];

    /** 首页 Banner 断点宽度（宽 → 窄），与 srcset 的宽度描述符一致 */
    private const BANNER_WIDTHS = [1920, 1440, 1080, 768, 480];

    /** Banner 默认回退宽度（不支持 srcset 时使用） */
    private const BANNER_FALLBACK_WIDTH = 1080;

    /** 超过该像素数跳过，避免 GD 占用过多内存 */
    private const MAX_SOURCE_PIXELS = 40000000;

    private const QUALITY = 82;

    /**
     * 获取缩略图地址；非本地图片或生成失败时回退原图
     */
    public static function url(string $url, int $width = self::PRODUCT_CARD_WIDTH): string
    {
        $url = trim($url);
        if ($url === '' || $width <= 0) {
            return $url;
        }

        return self::ensure($url, $width) ?? $url;
    }

    /**
     * 首页 Banner 的 srcset 候选（宽度 => 地址）
     *
     * 按断点宽度做「保留中间、裁掉左右」的中心裁剪，只生成不超过原图宽度的档位
     * （不做放大）；原图比最大断点还宽时额外提供原图档，保证大屏/高分屏清晰度。
     *
     * @return array<int,string> 宽度升序
     */
    public static function bannerSources(string $url): array
    {
        // 未安装 GD 时无法裁剪，交给调用方回退原图（不输出 srcset）
        if (!self::gdReady()) {
            return [];
        }

        $url    = trim($url);
        $source = self::localPath($url);
        if ($source === null) {
            return [];
        }

        $info     = @getimagesize($source);
        $srcWidth = $info ? (int) $info[0] : 0;
        $srcHeight = $info ? (int) $info[1] : 0;
        if ($srcWidth <= 0 || $srcHeight <= 0 || $srcWidth * $srcHeight > self::MAX_SOURCE_PIXELS) {
            return [];
        }

        $sources = [];
        foreach (self::BANNER_WIDTHS as $width) {
            if ($width > $srcWidth) {
                continue;
            }
            $sources[$width] = $width === $srcWidth ? $url : (self::ensureBanner($url, $width) ?? $url);
        }
        if ($srcWidth > self::BANNER_WIDTHS[0]) {
            $sources[$srcWidth] = $url;
        }
        if ($sources === []) {
            $sources[$srcWidth] = $url;
        }

        ksort($sources);

        return $sources;
    }

    /**
     * Banner 默认回退图：优先 1080 档，其次最宽档，最后原图
     *
     * @param array<int,string> $sources bannerSources() 的结果
     */
    public static function bannerFallback(array $sources, string $original): string
    {
        if ($sources === []) {
            return $original;
        }
        if (isset($sources[self::BANNER_FALLBACK_WIDTH])) {
            return $sources[self::BANNER_FALLBACK_WIDTH];
        }

        return (string) $sources[array_key_last($sources)];
    }

    /**
     * 上传完成后预生成常用商品缩略尺寸（失败静默，不影响上传结果）
     */
    public function generatePresets(string $url): void
    {
        foreach (self::PRESET_WIDTHS as $width) {
            self::ensure($url, $width);
        }
    }

    /**
     * GD 是否可用
     *
     * 部分线上环境未编译 GD 扩展，直接调用 imagecreatefromjpeg() 会抛致命错误，
     * 因此所有图像处理入口均需先判断，缺失时统一回退原图。
     */
    private static function gdReady(): bool
    {
        return extension_loaded('gd')
            && function_exists('imagecreatetruecolor')
            && function_exists('imagecopyresampled')
            && function_exists('imagejpeg');
    }

    /**
     * 商品缩略图：等比缩放到目标宽度
     */
    private static function ensure(string $url, int $width): ?string
    {
        return self::variant($url, $width, (string) $width, false);
    }

    /**
     * Banner 断点图：保持原高度，左右两侧中心裁剪到目标宽度
     */
    private static function ensureBanner(string $url, int $width): ?string
    {
        return self::variant($url, $width, 'banner-' . $width, true);
    }

    /**
     * 生成/复用缓存变体
     *
     * @param string $variantDir 缓存子目录（商品缩略图用宽度，Banner 用 banner-{width}）
     * @param bool   $cropSides  true=保持原高度、中心裁剪左右两侧到目标宽度
     */
    private static function variant(string $url, int $width, string $variantDir, bool $cropSides): ?string
    {
        if (!self::gdReady()) {
            return null;
        }

        $source = self::localPath($url);
        if ($source === null) {
            return null;
        }

        $relative      = ltrim($url, '/');
        $thumbRelative = 'uploads/thumbs/' . $variantDir . '/' . substr($relative, strlen('uploads/'));
        $thumb         = public_path() . $thumbRelative;
        if (is_file($thumb) && filemtime($thumb) >= filemtime($source)) {
            return '/' . $thumbRelative;
        }

        $info = @getimagesize($source);
        if (!$info || empty($info[0]) || empty($info[1])) {
            return null;
        }
        $srcWidth  = (int) $info[0];
        $srcHeight = (int) $info[1];
        if ($srcWidth <= 0 || $srcHeight <= 0 || $srcWidth * $srcHeight > self::MAX_SOURCE_PIXELS) {
            return null;
        }
        if ($srcWidth <= $width) {
            return $url;
        }

        $image = self::read($source, (int) ($info[2] ?? 0));
        if (!$image) {
            return null;
        }

        if ($cropSides) {
            // 保留中间：左右各裁掉 (原宽 - 目标宽) / 2，高度不变
            $targetWidth  = $width;
            $targetHeight = $srcHeight;
            $srcX         = intdiv($srcWidth - $width, 2);
            $srcW         = $width;
        } else {
            $targetWidth  = $width;
            $targetHeight = max(1, (int) round($srcHeight * $width / $srcWidth));
            $srcX         = 0;
            $srcW         = $srcWidth;
        }

        $canvas = imagecreatetruecolor($targetWidth, $targetHeight);
        if (!$canvas) {
            imagedestroy($image);
            return null;
        }
        imagealphablending($canvas, false);
        imagesavealpha($canvas, true);
        $transparent = imagecolorallocatealpha($canvas, 255, 255, 255, 127);
        imagefilledrectangle($canvas, 0, 0, $targetWidth, $targetHeight, $transparent);
        imagealphablending($canvas, true);
        imagecopyresampled($canvas, $image, 0, 0, $srcX, 0, $targetWidth, $targetHeight, $srcW, $srcHeight);
        imagedestroy($image);

        $directory = dirname($thumb);
        if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
            imagedestroy($canvas);
            return null;
        }

        $saved = self::write($canvas, $thumb, strtolower((string) pathinfo($thumb, PATHINFO_EXTENSION)));
        imagedestroy($canvas);

        return $saved ? '/' . $thumbRelative : null;
    }

    /**
     * 校验并返回本地图片绝对路径；外链、缩略图目录、非法路径返回 null
     */
    private static function localPath(string $url): ?string
    {
        if ($url === ''
            || str_contains($url, '..')
            || !preg_match('~^/uploads/(?!thumbs/)[A-Za-z0-9_\-./]+\.(jpe?g|png|webp)$~i', $url)) {
            return null;
        }

        $source = public_path() . ltrim($url, '/');

        return is_file($source) ? $source : null;
    }

    /**
     * @return \GdImage|null
     */
    private static function read(string $path, int $type)
    {
        $image = match ($type) {
            IMAGETYPE_JPEG => function_exists('imagecreatefromjpeg') ? @imagecreatefromjpeg($path) : false,
            IMAGETYPE_PNG  => function_exists('imagecreatefrompng') ? @imagecreatefrompng($path) : false,
            IMAGETYPE_WEBP => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($path) : false,
            default        => false,
        };

        return $image ?: null;
    }

    /**
     * @param \GdImage $image
     */
    private static function write($image, string $path, string $extension): bool
    {
        return match ($extension) {
            'jpg', 'jpeg' => @imagejpeg($image, $path, self::QUALITY),
            'png'         => @imagepng($image, $path, 6),
            'webp'        => function_exists('imagewebp') ? @imagewebp($image, $path, self::QUALITY) : false,
            default       => false,
        };
    }
}
