<?php
use think\migration\Migrator;

/**
 * 商品增加自定义访问路径（Slug 路由）
 *
 * - custom_path：归一化后的路径标识（不带首尾 /，如 laser-cutter.html 或 laser-cutter），
 *   NULL 表示未设置，前台回落 /products/{id}
 * - custom_path_root：1 表示同时注册为根级路径（/{path}/ 直接访问）
 * - 全局唯一索引（跨商户）；NULL 不参与唯一约束，天然支持未填写
 */
class AddProductCustomPath extends Migrator
{
    /**
     * @return void
     */
    public function change()
    {
        $this->table('product')
            ->addColumn('custom_path', 'string', [
                'limit'   => 191,
                'null'    => true,
                'default' => null,
                'comment' => '自定义访问路径（归一化，全局唯一），NULL=未设置',
            ])
            ->addColumn('custom_path_root', 'boolean', [
                'limit'   => 1,
                'default' => 0,
                'comment' => '1=注册为根级路径（/{path}/）',
            ])
            ->addIndex(['custom_path'], ['unique' => true, 'name' => 'uk_product_custom_path'])
            ->update();
    }
}
