<?php
declare(strict_types=1);

namespace app\controller;

use app\common\service\PageService;
use app\common\service\ProductRouteService;

/**
 * 静态内容页 / CMS 单页
 *
 * 渲染顺序：先查后台「单页管理」创建的内容（page 表，富文本或内置模板），
 * 再查商品自定义根级路径（product.custom_path + custom_path_root=1），
 * 未命中回退到主题自带的静态页面（关于我们、联系我们、政策页等），最后 404。
 * 后台入口：/admin/pages（平台超管）。
 */
class Page extends SiteBase
{
    /** 内置静态页 slug => [标题, 视图] */
    public const PAGES = [
        'about'    => ['About', 'about'],
        'service'  => ['Our Service', 'service'],
        'contact'  => ['Contact Us', 'contact'],
        'terms'    => ['Terms & Conditions', 'page'],
        'privacy'  => ['Privacy Policy', 'page'],
        'cookies'  => ['Cookies Policy', 'page'],
        'shipping' => ['Shipping Information', 'page'],
        'returns'  => ['Refund & Return Policy', 'page'],
        'accessibility'   => ['Accessibility Statement', 'page'],
        'security'        => ['Security Policy', 'page'],
        'modern-slavery'  => ['Modern Slavery Statement', 'page'],
    ];

    /**
     * 内置静态页 slug 列表（供商品自定义路径校验复用，避免两处口径漂移）
     *
     * @return string[]
     */
    public static function builtinSlugs(): array
    {
        return array_keys(self::PAGES);
    }

    /**
     * 关于我们
     *
     * @return mixed
     */
    public function about()
    {
        return $this->detail('about');
    }

    /**
     * 我们的服务
     *
     * @return mixed
     */
    public function service()
    {
        return $this->detail('service');
    }

    /**
     * 联系我们
     *
     * @return mixed
     */
    public function contact()
    {
        return $this->detail('contact');
    }

    /**
     * 内容页详情
     *
     * @param string $slug URL 路径段
     * @return mixed
     */
    public function detail($slug = '')
    {
        $slug = strtolower(trim((string) $slug));
        $brand = $this->store->brand();

        // 1）后台创建的单页优先
        $page = (new PageService())->findBySlug($slug);
        if ($page !== null) {
            return $this->renderCmsPage($page, $brand);
        }

        // 2）商品自定义根级路径（后台开启「注册为顶级路径」的商品，如 /laser-cutter）
        $productId = (new ProductRouteService())->resolve($slug, true);
        if ($productId !== null) {
            return (new Product(app()))->detail($productId);
        }

        // 3）回退到主题内置静态页
        if (!isset(self::PAGES[$slug])) {
            return $this->notFound('Page not found');
        }
        [$title, $view] = self::PAGES[$slug];

        return $this->render($view, [
            'nav_active'   => in_array($slug, ['about', 'service', 'contact'], true) ? $slug : '',
            'page_title'   => $title . ' - ' . $brand['name'] . $brand['suffix'],
            'page_name'    => $title,
            'page_content' => '',
            'slug'         => $slug,
            'cta_url'      => $this->store->firstProductUrl(),
        ]);
    }

    /**
     * 渲染后台创建的单页
     *
     * 富文本型统一走 site/page 模板；模板型复用主题内置视图，正文内容忽略。
     *
     * @param array $page  PageService::findBySlug() 返回的单页数据
     * @param array $brand 品牌信息
     * @return mixed
     */
    private function renderCmsPage(array $page, array $brand)
    {
        $isTemplate = $page['content_type'] === PageService::TYPE_TEMPLATE;
        $view = $isTemplate && $page['template_file'] !== '' ? $page['template_file'] : 'page';
        $seoTitle = $page['seo_title'] !== '' ? $page['seo_title'] : $page['title'];

        return $this->render($view, [
            'nav_active'   => in_array($page['slug'], ['about', 'service', 'contact'], true) ? $page['slug'] : '',
            'page_title'   => $seoTitle . ' - ' . $brand['name'] . $brand['suffix'],
            'page_name'    => $page['title'],
            'page_content' => $isTemplate ? '' : $page['content'],
            'meta_desc'    => $page['seo_description'],
            'meta_keys'    => $page['seo_keywords'],
            'slug'         => $page['slug'],
            'cta_url'      => $this->store->firstProductUrl(),
        ]);
    }
}
