<?php
declare(strict_types=1);

namespace app\controller;

use app\common\service\ProductRouteService;

/**
 * 商品列表 / 详情（eshop2026 主题）
 *
 * 详情支持两种寻址：
 *   - /products/{id}、/product/{id}：数字 ID（保持兼容，不做 301）
 *   - /products/{custom_path}：后台「高级」选项卡配置的自定义访问路径
 *   - 根级 /{custom_path}/：由 Page/detail 解析后转发到本控制器
 */
class Product extends SiteBase
{
    public function list()
    {
        $categoryId = (int) $this->request->get('category_id', 0);
        $keyword = trim((string) $this->request->get('keyword', ''));
        $sort = (string) $this->request->get('sort', 'newest');
        if (!in_array($sort, ['newest', 'price-asc', 'price-desc', 'popular'], true)) {
            $sort = 'newest';
        }

        $brand = $this->store->brand();
        $result = $this->store->productCards(1, 120, $categoryId, $keyword, $sort);

        return $this->render('products', [
            'nav_active'      => 'products',
            'page_title'      => 'Products - ' . $brand['name'],
            'meta_desc'       => 'Browse our full range of home storage and organisation solutions.',
            'products'        => $result['list'],
            'total'           => $result['total'],
            'sort'            => $sort,
            'page_size'       => (int) site_config('per_page', 24),
            'categories'      => $this->store->categories(),
            'active_category' => $categoryId,
        ]);
    }

    public function detail($id = 0)
    {
        $param = trim((string) $id);
        if ($param === '' || $param === '0') {
            // 路由未绑定到有效参数（如 /products.html 被 url_html_suffix 剥离为 /products）
            return $this->notFound('Product not found');
        }

        if (ctype_digit($param)) {
            $product = $this->store->product((int) $param);
        } else {
            // 自定义访问路径：Redis 优先，MySQL 兜底（Redis 不可用时仍可访问）
            $productId = (new ProductRouteService())->resolve($param);
            $product = $productId !== null ? $this->store->product($productId) : null;
        }
        if (!$product) {
            return $this->notFound('Product not found');
        }

        $seoTitle = trim((string) ($product['seo_title'] ?? ''));
        $seoDescription = trim((string) ($product['seo_description'] ?? ''));
        if ($seoDescription === '') {
            $seoDescription = $product['brief'] !== ''
                ? $product['brief']
                : mb_substr(trim(strip_tags((string) $product['description'])), 0, 160);
        }
        $seoKeywords = trim((string) ($product['seo_keywords'] ?? ''));
        if ($seoKeywords === '') {
            $seoKeywords = implode(',', (array) ($product['tags'] ?? []));
        }

        // 页面标题：商品名称 - 副标题 - SEO 标题；缺失的部分自动省略
        $titleParts = array_filter([
            trim((string) ($product['name'] ?? '')),
            trim((string) ($product['brief'] ?? '')),
            $seoTitle,
        ], static fn (string $part): bool => $part !== '');
        $json = json_encode([
            'id'        => $product['id'],
            'name'      => $product['name'],
            'price'     => $product['price'],
            'image'     => $product['image'],
            'url'       => $product['url'],
            'brief'     => $product['brief'],
            'has_stock' => $product['has_stock'],
            'skus'      => array_map(static fn ($s) => [
                'id'        => $s['id'],
                'spec_name' => $s['spec_name'],
                'price'     => $s['price'],
                'stock'     => $s['stock'],
            ], $product['skus']),
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        // canonical 指向自定义路径（填写 slug 时）；数字路径保持 200 不重定向
        $canonicalPath = storefront_product_url($product);

        return $this->render('product', [
            'nav_active'   => 'products',
            'page_title'   => implode(' - ', $titleParts),
            'meta_desc'    => $seoDescription,
            'meta_keys'    => $seoKeywords,
            'meta_robots'  => (int) ($product['seo_noindex'] ?? 0) === 1 ? 'noindex,follow' : '',
            'product'      => $product,
            'product_json' => htmlspecialchars((string) $json, ENT_QUOTES, 'UTF-8'),
            'canonical_url'  => $this->canonicalUrl($canonicalPath),
            'hreflang_links' => $this->hreflangLinks($canonicalPath),
        ]);
    }
}