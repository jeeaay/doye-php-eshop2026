<?php
declare(strict_types=1);

namespace app\controller;

use app\common\model\Product;

/**
 * 首页（eshop2026 主题）
 *
 * 迁移自 eshop/www/template/eshop2026/pages/index.html：
 * 版式与文案保持不变；「Latest Arrivals」（前 8 个）与「Trending Now」（其余）取自商品表，
 * 首屏 Banner 在后台配置了 home_banner 时以其图片/标题/链接覆盖。
 */
class Index extends SiteBase
{
    public function index()
    {
        $brand = $this->store->brand();

        $result = $this->store->productCards(1, 24, 0, '', 'newest');
        $all = $result['list'];

        $ops = $this->store->homeOps();
        $banner = $ops['banners'][0] ?? null;

        $hero = [
            'image'    => '',
            'title'    => site_lang('home.hero_title'),
            'lead'     => site_lang('home.hero_lead'),
            'cta_text' => site_lang('home.hero_cta'),
            'cta_url'  => '/products',
        ];
        if ($banner) {
            $hero['image'] = (string) $banner['image'];
            $hero['title'] = (string) $banner['title'];
            $hero['lead'] = (string) $banner['subtitle'];
            $hero['cta_url'] = $this->resolveLink($banner['link_type'] ?? 'none', $banner['link_target'] ?? '');
            $hero['cta_text'] = $hero['cta_url'] !== '' ? site_lang('home.learn_more') : '';
        }

        return $this->render('index', [
            'nav_active'    => 'home',
            // 首页 SEO 优先取后台「系统设置 → 首页 SEO」，未配置时回退品牌默认文案
            'page_title'    => (string) site_config('seo.title', '') ?: 'Home - ' . $brand['name'],
            'meta_desc'     => (string) site_config('seo.description', '') ?: $brand['tagline'],
            'meta_keys'     => (string) site_config('seo.keywords', ''),
            'products_top'  => array_slice($all, 0, 8),
            'products_rest' => array_slice($all, 8, 8),
            'total'         => $result['total'],
            'hero'          => $hero,
            'notices'       => $ops['notices'] ?? [],
        ]);
    }

    private function resolveLink(string $type, string $target): string
    {
        $target = trim($target);
        return match ($type) {
            'product'  => $this->productLink($target),
            'category' => ctype_digit($target) ? '/products?category_id=' . (int) $target : '',
            'page', 'topic' => $target !== '' ? '/' . ltrim($target, '/') : '',
            default    => '',
        };
    }

    /**
     * Banner 商品链接：带自定义访问路径的商品优先生成 slug URL
     */
    private function productLink(string $target): string
    {
        if (!ctype_digit($target)) {
            return '';
        }
        $product = Product::where('status', 1)->whereNull('delete_time')->find((int) $target);
        return $product ? storefront_product_url($product) : '';
    }
}