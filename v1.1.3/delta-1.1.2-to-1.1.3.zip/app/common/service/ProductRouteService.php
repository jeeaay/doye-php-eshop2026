<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\exception\BizException;
use app\common\lib\RedisCache;
use app\common\model\Page;
use app\common\model\Product;
use app\controller\Page as PageController;
use think\facade\Db;

/**
 * 商品自定义访问路径服务
 *
 * 职责：
 *   - normalize()：把用户输入归一化为可存储 / 可访问的路径标识
 *   - validate() ：格式、保留字、CMS 单页占用、全局唯一校验（保存商品时调用）
 *   - resolve()  ：前台路径 → 商品 ID（Redis 优先，MySQL 兜底）
 *
 * 路由缓存：Redis key = product:route:{path} → 商品 ID，TTL 60s，
 * 商品保存 / 删除 / 停用时写时失效（AdminCrudService）。
 */
class ProductRouteService
{
    /** 路由缓存 key 前缀 */
    private const CACHE_PREFIX = 'product:route:';

    /** 路由缓存 TTL（秒） */
    private const CACHE_TTL = 60;

    /** 路径最大长度（与 varchar(191) 对齐，留出余量） */
    private const MAX_LENGTH = 190;

    /**
     * 系统保留路径（与前台静态路由冲突）
     *
     * 双保险：路由顺序本身已经保证静态路由优先，这里再拦一次，避免
     * 顶级路径被注册后遮蔽站点固定页面。
     */
    /**
     * 系统保留路径（与前台静态路由冲突）
     *
     * 双保险：路由顺序本身已经保证静态路由优先，这里再拦一次，避免
     * 顶级路径被注册后遮蔽站点固定页面。
     *
     * 注：格式校验只允许 .html 后缀，因此 sitemap.xml 这类非 .html 后缀
     * 会先被格式规则拦下；此处仍保留条目，防止未来放宽后缀时出现遮蔽。
     */
    private const RESERVED_PATHS = [
        'products', 'product', 'cart', 'checkout', 'login', 'account',
        'order-success', 'about', 'service', 'contact', 'sitemap', 'sitemap.xml',
        'admin', 'api', 'index', 'home',
    ];

    /**
     * 归一化用户输入的访问路径
     *
     * 规则：小写、去首尾斜杠与空白、空格/下划线转连字符、剔除非法字符、
     * 合并连续连字符。保留 .html 后缀（若用户输入了）。
     *
     * @param string $input 原始输入
     * @return string 归一化后的路径标识（不含首尾 /）
     */
    public function normalize(string $input): string
    {
        $path = strtolower(trim($input));
        if ($path === '') {
            return '';
        }

        // 去掉首尾斜杠
        $path = trim($path, "/ \t\n\r\0\x0B");

        // 空白与下划线统一为连字符
        $path = preg_replace('/[\s_]+/', '-', $path) ?? '';

        // 剔除非法字符（保留字母、数字、连字符与点）
        $path = preg_replace('/[^a-z0-9\-.]/', '', $path) ?? '';

        // 合并连续连字符、去掉首尾连字符
        $path = preg_replace('/-{2,}/', '-', $path) ?? '';
        $path = trim($path, '-');

        return $path;
    }

    /**
     * 校验访问路径（保存商品时调用）
     *
     * @param string   $path           归一化后的路径标识（空串表示不设置，直接放行）
     * @param int|null $exceptProductId 排除自身的商品 ID（编辑场景）
     * @throws BizException 校验不通过
     */
    public function validate(string $path, ?int $exceptProductId = null): void
    {
        if ($path === '') {
            return;
        }

        if (mb_strlen($path) > self::MAX_LENGTH) {
            throw new BizException('访问路径不能超过 ' . self::MAX_LENGTH . ' 个字符');
        }

        if (!preg_match('/^[a-z0-9\-]+(\.html)?$/', $path)) {
            throw new BizException('访问路径格式无效：仅支持小写字母、数字和连字符，可选 .html 后缀');
        }

        // 纯数字（含 123.html）与商品 ID 路径冲突：/products/{n} 会被当作数字 ID 查询，
        // 导致该 slug 永远打不开、或错误地展示成同 ID 商品，故一律拒绝。
        if (preg_match('/^\d+(\.html)?$/', $path)) {
            throw new BizException('访问路径不能是纯数字（会与商品 ID 路径冲突），请加入字母或连字符');
        }

        $base = $this->basePath($path);

        // 保留字（同时校验带 / 不带 .html 后缀两种写法）
        foreach ([$base, $path] as $candidate) {
            if (in_array($candidate, self::RESERVED_PATHS, true)) {
                throw new BizException('访问路径「' . $candidate . '」为系统保留路径，请更换');
            }
            // 主题内置静态页（about / privacy / terms 等）：根级路径会遮蔽它们
            if (in_array($candidate, PageController::builtinSlugs(), true)) {
                throw new BizException('访问路径「' . $candidate . '」为系统内置页面，请更换');
            }
        }

        // CMS 单页占用
        if (Page::where('slug', $base)->find()) {
            throw new BizException('访问路径「' . $base . '」已被内容单页占用，请更换');
        }

        // 全局唯一（排除自身）
        //
        // 必须用原生查询而不是 Product 模型：unique index
        // uk_product_custom_path 建在真实表上、包含被软删记录；而 Product 模型的
        // SoftDelete 会过滤 delete_time，导致「撞上已软删商品的路径」在校验阶段
        // 放行、到写库时才抛 1062 DuplicateException（表现为 500 而非 {code:1}）。
        $query = Db::name('product')->where('custom_path', $path);
        if ($exceptProductId) {
            $query->where('id', '<>', $exceptProductId);
        }
        if ($query->value('id')) {
            throw new BizException('访问路径「' . $path . '」已被其他商品使用，请更换');
        }
    }

    /**
     * 解析前台路径 → 商品 ID
     *
     * 注意：config/route.php 的 url_html_suffix='html'，ThinkPHP 在匹配前会剥掉 URL 结尾的
     * .html，因此传入的 $path 通常不含后缀；但商品可能把 custom_path 存成带 .html 的形态，
     * 故两种形态都要查。
     *
     * @param string $path URL 路径段（匹配时已剥离 .html 后缀）
     * @param bool   $root 是否按根级路径解析（缓存键与查询口径与服务路由区分）
     * @return int|null 商品 ID；未命中返回 null
     */
    public function resolve(string $path, bool $root = false): ?int
    {
        $path = strtolower(trim($path));
        if ($path === '') {
            return null;
        }

        // url_html_suffix 剥离后通常无后缀；带后缀时也要能命中
        $base = $this->basePath($path);
        $candidates = array_values(array_unique($base !== '' ? [$base, $base . '.html'] : [$path]));

        foreach ($candidates as $candidate) {
            $productId = RedisCache::remember(
                self::CACHE_PREFIX . ($root ? 'root:' : '') . $candidate,
                self::CACHE_TTL,
                function () use ($candidate, $root): ?int {
                    $query = Product::where('custom_path', $candidate)->where('status', 1);
                    if ($root) {
                        // 顶级路径只认显式开启「注册为顶级路径」的商品
                        $query->where('custom_path_root', 1);
                    }
                    $product = $query->find();
                    return $product ? (int) $product->id : null;
                }
            );
            if ($productId !== null && (int) $productId > 0) {
                return (int) $productId;
            }
        }

        return null;
    }

    /**
     * 失效路径缓存（保存 / 删除 / 停用商品时调用）
     *
     * @param string|null ...$paths 需要失效的路径
     */
    public function forgetRouteCache(?string ...$paths): void
    {
        foreach ($paths as $path) {
            $path = strtolower(trim((string) $path));
            if ($path === '') {
                continue;
            }

            // 顶级路径的 URL 省略 .html 后缀，缓存键与存储路径可能不一致，两者都清
            $variants = array_unique([$path, $this->basePath($path)]);
            foreach ($variants as $variant) {
                if ($variant === '') {
                    continue;
                }
                RedisCache::forget(self::CACHE_PREFIX . $variant);
                RedisCache::forget(self::CACHE_PREFIX . 'root:' . $variant);
            }
        }
    }

    /**
     * 取不带 .html 后缀的基础路径
     */
    private function basePath(string $path): string
    {
        return preg_replace('/\.html$/', '', $path) ?? $path;
    }
}
