<?php
/**
 * 独立站前台路由（默认应用，文档根 public/）
 *
 * 迁移自 Go 站点 internal/routes/site_routes.go 与 eshop2026 主题页面清单
 */
use app\common\service\StorefrontService;
use think\facade\Route;

// 站点地图（含 hreflang 备选）
Route::get('sitemap.xml', 'Sitemap/index');

// 首页
Route::get('/', 'Index/index');

// 商品（route_complete_match 全局关闭，动态规则必须写在静态规则之前）
// 单一入口：同一个 :id 段既接受数字 ID（/products/1），也接受自定义访问路径
// （/products/laser-cutter、/products/laser-cutter.html），由 Product/detail 分流。
// 注意：不要拆成第二条 products/:path 规则——全局 route_complete_match=false 时，
// 静态规则 products 会按前缀吸收 /products/anything，使 slug 落到商品列表页（隐藏 bug）。
Route::get('products/:id', 'Product/detail')->pattern(['id' => '[a-zA-Z0-9\-\.]+']);
Route::get('product/:id', 'Product/detail')->pattern(['id' => '\d+']); // 兼容旧链接（仅数字 ID）
Route::get('products', 'Product/list');

// 购物车 / 结算
Route::get('cart', 'Cart/index');
Route::get('checkout', 'Checkout/index');

// 登录
Route::get('login', 'Auth/index');

// 账户中心
Route::get('account', 'Account/index');
Route::get('account/orders', 'Account/orders');
Route::get('account/orders/:id', 'Account/orderDetail')->pattern(['id' => '\d+']);
Route::get('account/addresses', 'Account/addresses');
Route::get('account/wishlist', 'Account/wishlist');
Route::get('account/rewards', 'Account/rewards');
Route::get('account/logout', 'Account/logout');

// 下单结果 / 支付回跳
Route::get('order-success', 'Order/successPage');
Route::get('order-success/:id', 'Order/successPage')->pattern(['id' => '\d+']);

// 静态内容页 / CMS 单页：放宽为任意单段 slug，控制器内先查后台单页再回退内置页
Route::get('about', 'Page/about');
Route::get('service', 'Page/service');
Route::get('contact', 'Page/contact');
Route::get(':slug', 'Page/detail')->pattern(['slug' => '[a-zA-Z0-9\-]+']);

// 兜底 404（直接输出，避免在路由闭包里再次拼装视图响应）
Route::miss(function () {
    $brand = (new StorefrontService())->brand();
    $html = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">'
        . '<meta name="viewport" content="width=device-width, initial-scale=1.0">'
        . '<title>Page not found - ' . htmlspecialchars($brand['name'], ENT_QUOTES) . '</title>'
        . '<style>body{font-family:system-ui,-apple-system,"Segoe UI",sans-serif;color:#003366;'
        . 'display:flex;min-height:100vh;align-items:center;justify-content:center;margin:0}'
        . '.box{text-align:center;padding:40px}h1{font-size:64px;margin:0 0 8px}'
        . 'a{display:inline-block;margin-top:24px;padding:12px 28px;background:#003366;color:#fff;'
        . 'text-decoration:none;border-radius:4px}</style></head><body><div class="box">'
        . '<h1>404</h1><p>The page you requested could not be found.</p>'
        . '<a href="/">Back to home</a></div></body></html>';

    return response($html, 404)->contentType('text/html');
});