<?php

/**
 * 安全防护静态配置
 *
 * 这里的值都是「代码级」规则，不开放后台修改：
 *   - defaults          默认开关与阈值（后台「系统设置 → 安全设置」可覆盖，落 setting 表）
 *   - safe_ips          永不封禁的地址
 *   - bypass_prefixes   不参与拦截的路径前缀（静态资源、文档）
 *   - probe_patterns    内置探针/敏感路径特征（正则 => 说明）
 *   - bad_user_agents   恶意扫描器 UA 特征
 *   - trusted_headers   反向代理场景下读取真实客户端 IP 的默认请求头顺序
 *                       （后台「安全设置」可用 security.trusted_headers 覆盖并自行增删）
 *
 * 后台可改的项见 config/setting.php 的 security 分组与 config/site.php 的默认值说明。
 */
return [
    // 默认值：首次使用、数据库尚未保存任何 security.* 设置时生效
    'defaults' => [
        // 总开关：关闭后完全不拦截、不记录（后台仍可操作数据）
        'enabled'              => true,
        // 探针命中达到阈值后自动加入黑名单
        'auto_block'           => false,
        // 恶意 UA 直接封禁
        'ua_block'             => false,
        // 是否把探针/拦截事件写入 security_event
        'log_enabled'          => true,
        // 同一 IP 在统计窗口内命中多少次高风险路径后自动封禁
        'threshold'            => 5,
        // 统计窗口（秒）
        'window'               => 86400,
        // 自动封禁时长（秒），0 表示长期
        'block_ttl'            => 86400,
        // 客户端 IP 识别：是否信任反向代理请求头
        'trusted_proxy'        => false,
        // 可信代理地址（每行一个，支持 IP / CIDR），可选；REMOTE_ADDR 命中时采信代理头
        'trusted_proxies'      => '',
        // 回源密钥请求头名称：请求携带该头且值等于回源密钥时采信代理头（CDN 场景，防伪造）
        'proxy_secret_header'  => 'cdn-src-sec',
        // 回源密钥：开启「信任反向代理请求头」时必填
        'proxy_secret'         => '',
        // 额外白名单（每行一个，支持 IP / CIDR / 192.168.1.*），无需建表即可放行
        'extra_whitelist'      => '',
        // 拦截日志保留天数
        'event_retention_days' => 30,
        // 命中黑名单时返回给客户端的内容
        'block_message'        => 'Your IP has been blocked due to suspicious activity. If you believe this is a mistake, please contact support.',
    ],

    // 本地回环永不封禁，避免开发/运维误封自己
    'safe_ips' => ['127.0.0.1', '::1'],

    // 这些前缀直接放行：静态资源由 web server 处理，文档允许公开访问
    'bypass_prefixes' => [
        'static/',
        'uploads/',
        'eshop2026/',
        'admin-api/openapi.yaml',
        'favicon.ico',
        'robots.txt',
        'sitemap.xml',
    ],

    // 内置探针/敏感路径特征：命中即计一次高风险请求
    // 注意：不要加入 /\bconfig\b/、/cart/ 这类宽泛规则，本站前台自身路径会被误伤
    'probe_patterns' => [
        '/(^|\/)(admin(?:istrator)?(?:_area|_panel)?|admin\.php|back[-_]?end|manage(?:ment|r)?|panel|dashboard|cms|site[-_]?admin)(\/|\.php|$)/i' => '后台入口探测',
        '/\.env(?:[._\/-]|$)/i'                                                        => '敏感文件 .env',
        '/(^|\/)\.(git|svn|hg|aws|ssh|idea|vscode)(\/|$)/i'                            => '版本库/IDE 元数据',
        '/(^|\/)(composer\.(json|lock)|package-lock\.json|yarn\.lock|pnpm-lock\.yaml|docker-compose\.ya?ml)$/i' => '依赖/容器配置文件',
        '/(^|\/)(wp-login\.php|wp-admin|wp-config|wp-content|wp-json|xmlrpc\.php)/i'   => 'WordPress 探测',
        '/(^|\/)(phpmyadmin|adminer|pma)(\/|\.php|$)/i'                                => '数据库管理面板探测',
        '/(^|\/)(phpinfo|shell|cmd)\.php$/i'                                           => '调试/后门脚本探测',
        '/\.(sql|dump|bak|old|orig|swp|swo)$/i'                                        => '备份/转储文件',
        '/\.php(\.\d+|~)$/i'                                                           => 'PHP 备份文件',
        '/\.(ini|conf|pem|p12|pfx|crt|key)$/i'                                         => '配置/证书文件',
        '/(^|\/)(web\.config|app\.config|connectionstrings)/i'                         => '.NET 配置文件',
        '/(^|\/)(actuator|swagger|swagger-ui|v2\/api-docs|v3\/api-docs|__debug__|graphql)(\/|$)/i' => '框架探针端点',
        '/(^|\/)_(nodes|cat|cluster|search|mapping|settings|stats)(\/|$)/i'            => 'Elasticsearch 探针',
        '/(^|\/)(server-status|server-info|\.htaccess|\.htpasswd)(\/|$)/i'             => '服务器信息探测',
        '/terraform\.tfstate$/i'                                                       => 'Terraform 状态文件',
        '/(^|\/)(id_rsa|id_dsa|id_ecdsa|id_ed25519|authorized_keys)(\.|$)/i'           => 'SSH 密钥文件',
        '/(^|\/)(secrets?|credentials|api[_-]?key|private[_-]?key)([._\/-]|$)/i'       => '密钥/凭证文件',
        '/(^|\/)\.\.(\/|$)/'                                                           => '目录穿越',
        '/\.(asp|aspx|jsp|jspx|cgi|phtml|phar)$/i'                                     => '可执行脚本探测',
        '/(^|\/)vendor\//i'                                                            => '依赖源码目录探测',
    ],

    // 恶意扫描器 UA 特征（小写包含匹配）
    // 默认 ua_block=false，开启前请确认没有健康检查/监控使用 curl
    'bad_user_agents' => [
        'sqlmap', 'nikto', 'nmap', 'masscan', 'acunetix', 'nessus', 'appscan',
        'dirbuster', 'gobuster', 'ffuf', 'wfuzz', 'nuclei', 'zgrab', 'sqlpowerinjector',
        'python-requests/', 'curl/', 'wget/',
    ],

    // 反代场景下按顺序尝试的请求头（仅当 REMOTE_ADDR 命中可信代理地址、或请求携带匹配的回源密钥头时才采信）
    'trusted_headers' => [
        'cf-connecting-ip',
        'x-real-ip',
        'x-forwarded-for',
    ],
];