<?php
// +----------------------------------------------------------------------
// | 应用设置
// +----------------------------------------------------------------------

// 后台入口前缀：默认 console，可通过 .env 的 ADMIN_PATH 修改。
// 仅允许字母、数字、下划线与连字符；非法值回退 admin。
$adminPath = (string) env('ADMIN_PATH', 'admin_XsLVmkD69kWAAP6g');
$adminPath = preg_replace('/[^a-zA-Z0-9_-]/', '', $adminPath);
if ($adminPath === '' || in_array($adminPath, ['api', 'admin-api', 'adminapi', 'common'], true)) {
    $adminPath = 'console';
}
// 说明：只要前缀不是 admin，访问 /admin 会被 MultiApp 按 app_map 值反查直接返回 404。

return [
    // 应用的命名空间
    'app_namespace'    => '',
    // 是否启用路由
    'with_route'       => true,
    // 默认应用
    'default_app'      => 'index',
    // 默认时区
    'default_timezone' => 'Asia/Shanghai',
    // 后台入口前缀（模板与控制器统一通过 admin_base()/admin_url() 使用）
    'admin_path'       => $adminPath,

    // 应用映射（自动多应用模式有效）
    'app_map'          => [
        'api'       => 'api',
        $adminPath   => 'admin',
        'admin-api' => 'adminapi',
    ],
    // 域名绑定（自动多应用模式有效）
    'domain_bind'      => [],
    // 禁止URL访问的应用列表（自动多应用模式有效）
    'deny_app_list'    => ['common'],

    // 异常页面的模板文件
    'exception_tmpl'   => app()->getThinkPath() . 'tpl/think_exception.tpl',

    // 错误显示信息,非调试模式有效
    'error_message'    => '页面错误！请稍后再试～',
    // 显示错误信息
    'show_error_msg'   => false,
];
