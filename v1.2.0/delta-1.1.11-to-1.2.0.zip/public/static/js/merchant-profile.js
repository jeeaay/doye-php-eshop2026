window.initMerchantProfile = function (form, options) {
    if (!form) return null;
    const state = (options && options.state) || {};
    // 可配置项：默认值即商户详情页原行为，品牌详情页通过 options 覆盖（上传地址/字段 id）
    const config = Object.assign({
        uploadUrl: window.ADMIN_BASE + '/merchants/upload',
        editorHostId: 'merchant-description-editor',
        logoInputId: 'merchant-logo',
        logoPreviewId: 'merchant-logo-preview',
        logoFileId: 'merchant-logo-file',
        logoPickId: 'merchant-logo-pick',
        statusBadgeId: 'merchant-status-badge',
        logoAlt: 'logo 预览',
    }, options || {});
    const ToastUIEditor = window.toastui && window.toastui.Editor && window.toastui.Editor.Editor;
    if (typeof ToastUIEditor !== 'function') {
        console.error('Toast UI Editor 3.2.2 bundle did not expose toastui.Editor.Editor.');
        return null;
    }

    const $ = (id) => form.querySelector('#' + id);
    const toastError = (msg) => { if (window.AdminToast) AdminToast.error(msg); else if (window.Swal) window.Swal.fire({ icon: 'error', title: msg }); };
    const toastOk = (msg) => { if (window.AdminToast) AdminToast.success(msg); };

    const unwrapImageParagraphs = (html) => {
        if (!html) return html;
        const container = document.createElement('div');
        container.innerHTML = html;
        container.querySelectorAll('p').forEach((p) => {
            let hasImage = false;
            let onlyImages = true;
            p.childNodes.forEach((node) => {
                if (node.nodeType === 3) { if (!/^\s*$/.test(node.textContent)) onlyImages = false; return; }
                if (node.nodeName === 'IMG') { hasImage = true; return; }
                if (node.nodeName === 'BR') return;
                onlyImages = false;
            });
            if (hasImage && onlyImages) {
                const images = Array.from(p.querySelectorAll('img'));
                for (const image of images) p.parentNode.insertBefore(image, p);
                p.remove();
            }
        });
        return container.innerHTML;
    };

    async function upload(file) {
        if (!file) return null;
        const body = new FormData();
        body.append('file', file);
        const response = await fetch(config.uploadUrl, {
            method: 'POST',
            body,
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
        });
        const text = await response.text();
        let result;
        try {
            result = JSON.parse(text);
        } catch (_) {
            throw new Error('服务器返回格式异常');
        }
        if (!response.ok) throw new Error(result.message || '上传失败（' + response.status + '）');
        if (result.code !== 0) throw new Error(result.message || '上传失败');
        return result.data;
    }

    const editor = new ToastUIEditor({
        el: $(config.editorHostId),
        initialEditType: 'wysiwyg',
        previewStyle: 'vertical',
        height: '320px',
        language: 'zh-CN',
        hideModeSwitch: true,
        initialValue: state.description || '',
        hooks: {
            addImageBlobHook: async (blob, callback) => {
                try { callback((await upload(blob)).url); } catch (error) { toastError(error.message); }
            },
        },
        toolbarItems: [
            ['heading', 'bold', 'italic', 'strike'],
            ['hr', 'quote'],
            ['ul', 'ol', 'task', 'indent', 'outdent'],
            ['table', 'image', 'link'],
            ['code', 'codeblock'],
            ['scrollSync'],
        ],
    });

    const logoInput = $(config.logoInputId);
    const logoPreview = $(config.logoPreviewId);
    const renderLogoPreview = () => {
        if (!logoPreview) return;
        logoPreview.innerHTML = '';
        const url = logoInput ? logoInput.value : '';
        if (!url) {
            logoPreview.classList.add('is-empty');
            logoPreview.textContent = '尚未上传 logo';
            return;
        }
        logoPreview.classList.remove('is-empty');
        const image = document.createElement('img');
        image.src = url;
        image.alt = config.logoAlt;
        const remove = document.createElement('button');
        remove.type = 'button';
        remove.className = 'btn btn-danger btn-sm';
        remove.textContent = '移除';
        remove.onclick = () => { logoInput.value = ''; renderLogoPreview(); };
        logoPreview.append(image, remove);
    };

    const logoFile = $(config.logoFileId);
    const logoPick = $(config.logoPickId);
    if (logoPick && logoFile) logoPick.onclick = () => logoFile.click();
    if (logoFile) {
        logoFile.onchange = async (event) => {
            const file = event.target.files && event.target.files[0];
            if (!file) return;
            try {
                const data = await upload(file);
                logoInput.value = data.url;
                renderLogoPreview();
                toastOk('logo 上传成功，保存后生效');
            } catch (error) {
                toastError(error.message);
            } finally {
                event.target.value = '';
            }
        };
    }

    Object.keys(state).forEach((name) => {
        const field = form.elements[name];
        if (field && typeof field.value !== 'undefined') field.value = state[name] == null ? '' : state[name];
    });

    const statusBadge = $(config.statusBadgeId);
    if (statusBadge) {
        const enabled = Number(state.status) === 1;
        statusBadge.textContent = enabled ? '正常' : '已停用';
        statusBadge.className = 'badge ' + (enabled ? 'badge-success' : 'badge-error');
    }

    renderLogoPreview();

    form.onsubmit = async (event) => {
        event.preventDefault();
        const submit = form.querySelector('[type="submit"]');
        if (submit) submit.disabled = true;
        try {
            const payload = new FormData(form);
            payload.set('description', unwrapImageParagraphs(editor.getHTML()));
            const response = await fetch(form.action, {
                method: 'POST',
                body: payload,
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
            });
            const text = await response.text();
            let result;
            try {
                result = JSON.parse(text);
            } catch (_) {
                throw new Error('服务器返回格式异常');
            }
            if (!response.ok) throw new Error(result.message || '请求失败（' + response.status + '）');
            if (result.code !== 0) throw new Error(result.message || '保存失败');
            toastOk(result.message);
            if (options && typeof options.onSuccess === 'function') options.onSuccess(result);
        } catch (error) {
            toastError(error.message);
        } finally {
            if (submit) submit.disabled = false;
        }
    };

    return {
        destroy: () => { try { editor.destroy(); } catch (_) {} },
    };
};
