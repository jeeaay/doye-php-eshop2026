window.initProductEditor = function (form, options) {
    if (!form) return null;
    const ToastUIEditor = window.toastui && window.toastui.Editor && window.toastui.Editor.Editor;
    if (typeof ToastUIEditor !== 'function') {
        console.error('Toast UI Editor 3.2.2 bundle did not expose toastui.Editor.Editor.');
        return null;
    }
    const $ = (id) => form.querySelector('#' + id);
    const $$ = (sel) => form.querySelectorAll(sel);
    const specs = [];
    let skuState = new Map();
    let gallery = [];
    let specChangeConfirmed = false;
    let editorMode = 'wysiwyg';
    let previewEnabled = false;
    let destroyed = false;
    const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const setVal = (name, value) => { const input = form.elements[name]; if (input) input.value = value ?? ''; };
    const normalizeDateTime = (value) => { const text = String(value || '').trim(); return text ? text.replace(' ', 'T').slice(0, 16) : ''; };
    const toastError = (msg) => { if (window.AdminToast) AdminToast.error(msg); else if (window.Swal) window.Swal.fire({ icon: 'error', title: msg }); };
    const toastOk = (msg) => { if (window.AdminToast) AdminToast.success(msg); };
    const batchInput = document.createElement('input');
    batchInput.type = 'file';
    batchInput.multiple = true;
    batchInput.accept = 'image/jpeg,image/png,image/webp';
    batchInput.style.display = 'none';
    batchInput.setAttribute('aria-hidden', 'true');
    form.appendChild(batchInput);
    const batchButton = document.createElement('button');
    batchButton.type = 'button';
    batchButton.className = 'rich-batch-image-btn';
    batchButton.setAttribute('aria-label', '批量上传图片');
    batchButton.title = '批量上传图片';
    batchButton.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="14" height="14" rx="2"></rect><path d="M3 13l3.5-3.5a2 2 0 0 1 2.8 0L15 15"></path><circle cx="8" cy="8" r="1.4" fill="currentColor" stroke="none"></circle><path d="M7 21h12a2 2 0 0 0 2-2V7"></path></svg>';
    batchButton.onclick = (event) => { event.stopPropagation(); batchInput.click(); };
    batchInput.onchange = async (event) => {
        const files = event.target.files;
        if (!files || !files.length) return;
        if (editorMode === 'html') syncDescription('wysiwyg');
        try { descriptionEditor.focus(); } catch (_) {}
        const inserted = [];
        for (const file of files) {
            try { const data = await upload(file, 'image'); inserted.push({ imageUrl: data.url, altText: (file.name.replace(/\.[^.]+$/, '') || 'image') }); }
            catch (error) { toastError(error.message); }
        }
        for (const item of inserted) { try { descriptionEditor.exec('addImage', item); } catch (error) { toastError(error.message); } }
        event.target.value = '';
    };
    const descriptionEditor = new ToastUIEditor({
        el: $('rich-editor'), initialEditType: 'wysiwyg', previewStyle: 'vertical', height: '360px', language: 'zh-CN',
        hideModeSwitch: true, initialValue: '',
        events: { change: () => refreshDescriptionPreview() },
        hooks: { addImageBlobHook: async (blob, callback) => { try { callback((await upload(blob, 'image')).url); } catch (error) { toastError(error.message); } } },
        toolbarItems: [
            ['heading', 'bold', 'italic', 'strike'],
            ['hr', 'quote'],
            ['ul', 'ol', 'task', 'indent', 'outdent'],
            ['table', 'image', 'link', { name: 'batchImage', el: batchButton, tooltip: '批量上传图片' }],
            ['code', 'codeblock'],
            ['scrollSync']
        ]
    });
    const descriptionSection = form.querySelector('.product-description-editor');
    const htmlSource = $('detail-html-source');
    const unwrapImageParagraphs = (html) => {
        if (!html) return html;
        const container = document.createElement('div');
        container.innerHTML = html;
        container.querySelectorAll('p').forEach((p) => {
            let hasImage = false, onlyImages = true;
            p.childNodes.forEach((node) => {
                if (node.nodeType === 3) { if (!/^\s*$/.test(node.textContent)) onlyImages = false; return; }
                if (node.nodeName === 'IMG') { hasImage = true; return; }
                if (node.nodeName === 'BR') return;
                onlyImages = false;
            });
            if (hasImage && onlyImages) {
                const imgs = Array.from(p.querySelectorAll('img'));
                for (const img of imgs) p.parentNode.insertBefore(img, p);
                p.remove();
            }
        });
        return container.innerHTML;
    };
    const currentHtml = () => editorMode === 'html' ? htmlSource.value : unwrapImageParagraphs(descriptionEditor.getHTML());
    const setDescriptionHtml = (html) => { descriptionEditor.setHTML(html || ''); htmlSource.value = html || ''; };
    const syncDescription = (mode) => {
        const html = currentHtml();
        if (mode === 'html') {
            htmlSource.value = html;
        } else if (editorMode === 'html') {
            descriptionEditor.setHTML(htmlSource.value);
        }
        if (mode !== 'html') descriptionEditor.changeMode(mode === 'markdown' ? 'markdown' : 'wysiwyg');
        editorMode = mode;
        if (descriptionSection) descriptionSection.dataset.editorMode = mode;
        htmlSource.classList.toggle('active', mode === 'html');
        $$('.description-mode-switch [data-editor-mode]').forEach((button) => { const active = button.dataset.editorMode === mode; button.classList.toggle('active', active); button.setAttribute('aria-selected', active ? 'true' : 'false'); });
        refreshDescriptionPreview();
    };
    $$('.description-mode-switch [data-editor-mode]').forEach((button) => button.onclick = () => syncDescription(button.dataset.editorMode));
    function refreshDescriptionPreview() {
        const frame = $('description-preview');
        const panel = $('description-preview-panel');
        panel.hidden = !previewEnabled;
        if (!previewEnabled) { frame.srcdoc = ''; return; }
        const doc = frame.contentDocument;
        doc.open();
        doc.write('<!doctype html><meta charset="utf-8"><style>body{font:14px sans-serif;line-height:1.7;padding:14px}img{max-width:100%;height:auto}</style>' + currentHtml());
        doc.close();
    }
    const setPreviewEnabled = (enabled) => {
        previewEnabled = Boolean(enabled);
        $('preview-enabled-state').value = previewEnabled ? '1' : '0';
        const toggle = $('preview-description');
        toggle.checked = previewEnabled;
        toggle.setAttribute('aria-checked', previewEnabled ? 'true' : 'false');
        $('preview-description-status').textContent = previewEnabled ? '已开启' : '已关闭';
        refreshDescriptionPreview();
    };
    $('preview-description').onchange = (event) => setPreviewEnabled(event.target.checked);
    htmlSource.oninput = () => refreshDescriptionPreview();
    const snapshotSkus = () => $$('#sku-rows tr').forEach((row) => { skuState.set(row.dataset.key, { code: row.querySelector('[data-field="code"]').value, price: row.querySelector('[data-field="price"]').value, stock: row.querySelector('[data-field="stock"]').value, status: row.querySelector('[data-field="status"]').checked }); });
    const specsValid = () => !specs.length || specs.every((spec) => String(spec.name || '').trim() && Array.isArray(spec.values) && spec.values.length && spec.values.every((value) => String(value ?? '').trim()));
    const combinations = () => specs.reduce((rows, spec) => rows.flatMap((row) => spec.values.map((value) => ({ ...row, [spec.name]: value }))), [{}]);
    const rebuildSkuRows = () => {
        snapshotSkus();
        const error = $('sku-config-error');
        if (!specsValid()) {
            error.textContent = '规格配置尚未完整：请填写每个规格名称和至少一个规格值。已有 SKU 数据已保留，完成配置后将自动更新组合。';
            error.hidden = false;
            $('sku-empty-tip').hidden = true;
            $('sku-step').hidden = false;
            return false;
        }
        error.hidden = true;
        return true;
    };
    const renderSkus = () => {
        if (!rebuildSkuRows()) return;
        const rows = $('sku-rows'); rows.innerHTML = '';
        const combos = combinations();
        $('sku-empty-tip').hidden = combos.length > 0;
        $('sku-step').hidden = false;
        combos.forEach((values) => { const key = JSON.stringify(Object.keys(values).sort().map((name) => [name, values[name]])); const previous = skuState.get(key) || {}; const index = rows.children.length; const tr = document.createElement('tr'); tr.dataset.key = key;
            tr.innerHTML = `<td>${Object.entries(values).map(([name, value]) => `${escapeHtml(name)}: ${escapeHtml(value)}`).join(' / ') || '默认规格'}<input type="hidden" name="skus[${index}][spec_values_json]" value="${escapeHtml(JSON.stringify(values))}"><input type="hidden" name="skus[${index}][spec_name]" value="${escapeHtml(Object.values(values).join(' / ') || '默认规格')}"></td><td><input data-field="code" name="skus[${index}][sku_code]" value="${escapeHtml(previous.code || '')}"></td><td><input data-field="price" name="skus[${index}][price]" type="number" min="0" step="0.01" required value="${escapeHtml(previous.price || '')}"></td><td><input data-field="stock" name="skus[${index}][stock]" type="number" min="0" step="1" required value="${escapeHtml(previous.stock || '0')}"></td><td><input data-field="status" name="skus[${index}][status]" type="checkbox" value="1" ${previous.status !== false ? 'checked' : ''}></td>`;
            rows.appendChild(tr);
        });
    };
    const renderSpecs = () => { const host = $('spec-editor'); host.innerHTML = ''; specs.forEach((spec, index) => {
        const card = document.createElement('div'); card.className = 'spec-card';
        card.innerHTML = `<div class="spec-card-head"><span class="spec-card-index">${index + 1}</span><input class="spec-name-input" aria-label="规格名称" value="${escapeHtml(spec.name)}" placeholder="规格名称，如：颜色"><button class="btn btn-danger btn-sm spec-remove" type="button">删除</button></div><div class="spec-values"><span class="spec-values-chips"></span><div class="spec-value-add"><input aria-label="添加规格值" placeholder="输入规格值后回车，如：红色"><button class="btn btn-outline btn-sm" type="button">添加</button></div></div>`;
        const [nameInput] = card.querySelectorAll('.spec-name-input');
        const chipsHost = card.querySelector('.spec-values-chips');
        const [valueInput, valueAddBtn] = card.querySelectorAll('.spec-value-add input, .spec-value-add button');
        const removeBtn = card.querySelector('.spec-remove');
        nameInput.onchange = async () => { snapshotSkus(); const oldName = spec.name; const nextName = nameInput.value.trim(); if (!nextName || nextName === oldName) { if (!nextName) { nameInput.value = oldName; spec.name = oldName; } return; } if ($('product-id').value && !(await AdminConfirm.ask({ title: '确认重命名规格？', text: `重命名规格"${oldName}"会影响已有 SKU 组合数据，确认继续？`, confirmText: '继续' }))) { nameInput.value = oldName; return; } const migrated = new Map(); skuState.forEach((value, key) => migrated.set(JSON.stringify(JSON.parse(key).map(([name, item]) => [name === oldName ? nextName : name, item]).sort((a, b) => a[0].localeCompare(b[0]))), value)); skuState = migrated; specChangeConfirmed = Boolean($('product-id').value); spec.name = nextName; renderSkus(); };
        const removeValue = async (value) => { snapshotSkus(); if ($('product-id').value && !(await AdminConfirm.ask({ title: '确认删除规格值？', text: `删除规格值"${value}"会移除受影响的组合，确认继续？`, confirmText: '删除' }))) return; if ($('product-id').value) specChangeConfirmed = true; spec.values = spec.values.filter((v) => v !== value); renderSpecs(); renderSkus(); };
        const addValues = () => { const next = [...new Set([...spec.values, ...valueInput.value.split(/[,，\s]+/).map((v) => v.trim()).filter(Boolean)])]; if (next.length === spec.values.length) { valueInput.value = ''; return; } spec.values = next; valueInput.value = ''; renderSpecs(); renderSkus(); };
        valueAddBtn.onclick = addValues;
        valueInput.onkeydown = (event) => { if (event.key === 'Enter') { event.preventDefault(); addValues(); } };
        removeBtn.onclick = async () => { snapshotSkus(); if ($('product-id').value && [...skuState.values()].some((sku) => sku.price || sku.code || Number(sku.stock) > 0) && !(await AdminConfirm.ask({ title: '确认删除规格？', text: '删除规格维度会移除相关 SKU 价格和库存，确认继续？', confirmText: '删除' }))) return; if ($('product-id').value) specChangeConfirmed = true; specs.splice(index, 1); renderSpecs(); renderSkus(); };
        spec.values.forEach((value) => { const chip = document.createElement('span'); chip.className = 'spec-chip'; chip.innerHTML = `${escapeHtml(value)}<button type="button" aria-label="删除 ${escapeHtml(value)}">×</button>`; chip.querySelector('button').onclick = () => removeValue(value); chipsHost.appendChild(chip); });
        if (!spec.values.length) chipsHost.innerHTML = '<span class="spec-chip-empty">尚无规格值，请在下方添加</span>';
        host.appendChild(card);
    }); };
    $('sku-batch-apply').onclick = () => { const batchPrice = $('sku-batch-apply').closest('tr').querySelector('[data-batch="price"]').value; const batchStock = $('sku-batch-apply').closest('tr').querySelector('[data-batch="stock"]').value; const batchCode = $('sku-batch-apply').closest('tr').querySelector('[data-batch="code"]').value; if (batchPrice === '' && batchStock === '' && batchCode === '') { toastError('请先填写要批量填充的内容'); return; } $$('#sku-rows tr').forEach((row) => { if (batchCode !== '') row.querySelector('[data-field="code"]').value = batchCode; if (batchPrice !== '') row.querySelector('[data-field="price"]').value = batchPrice; if (batchStock !== '') row.querySelector('[data-field="stock"]').value = batchStock; }); snapshotSkus(); toastOk('已批量填充'); };
    async function upload(file, mediaType) { if (!file) return null; const body = new FormData(); body.append('file', file); body.append('media_type', mediaType); const result = await (await fetch(window.ADMIN_BASE + '/products/upload', { method: 'POST', body })).json(); if (result.code !== 0) throw new Error(result.message); return result.data; }
    const renderMainPreview = () => { const url = $('main-image').value; $('main-preview').innerHTML = url ? `<img src="${escapeHtml(url)}" style="max-width:160px" alt="主图预览"><button class="btn btn-danger btn-sm" type="button" id="remove-main">移除</button>` : ''; if ($('remove-main')) $('remove-main').onclick = () => { $('main-image').value = ''; renderMainPreview(); }; };
    $('main-file').onchange = async (event) => { try { const data = await upload(event.target.files[0], 'image'); $('main-image').value = data.url; renderMainPreview(); } catch (error) { toastError(error.message); } };
    $('gallery-files').onchange = async (event) => { try { for (const file of event.target.files) gallery.push((await upload(file, 'image')).url); renderGallery(); } catch (error) { toastError(error.message); } };
    const renderGallery = () => { $('gallery-preview').innerHTML = ''; gallery.forEach((url, index) => { const item = document.createElement('div'); item.innerHTML = `<img src="${escapeHtml(url)}" alt=""><button class="btn btn-danger btn-sm" type="button">移除</button><button class="btn btn-outline btn-sm" type="button">上移</button><button class="btn btn-outline btn-sm" type="button">下移</button>`; const buttons = item.querySelectorAll('button'); buttons[0].onclick = () => { gallery.splice(index, 1); renderGallery(); }; buttons[1].onclick = () => { if (index) [gallery[index - 1], gallery[index]] = [gallery[index], gallery[index - 1]]; renderGallery(); }; buttons[2].onclick = () => { if (index < gallery.length - 1) [gallery[index + 1], gallery[index]] = [gallery[index], gallery[index + 1]]; renderGallery(); }; $('gallery-preview').appendChild(item); }); };
    const renderVideoPreview = () => { const url = $('video-url').value; $('video-preview').innerHTML = url ? `<video controls style="max-width:360px" src="${escapeHtml(url)}"></video><button class="btn btn-danger btn-sm" type="button" id="remove-video">移除</button>` : ''; if ($('remove-video')) $('remove-video').onclick = () => { $('video-url').value = ''; $('video-meta').value = ''; renderVideoPreview(); }; };
    $('video-file').onchange = async (event) => { try { const data = await upload(event.target.files[0], 'video'); $('video-url').value = data.url; $('video-meta').value = JSON.stringify({ size: data.size, mime: data.mime, width: data.width, height: data.height, duration: data.duration }); renderVideoPreview(); } catch (error) { toastError(error.message); } };
    $('add-spec').onclick = () => { specs.push({ name: `规格${specs.length + 1}`, values: [] }); renderSpecs(); renderSkus(); };
    // ---- 品牌联动：按当前商户加载可选品牌，支持在表单内快速添加品牌 ----
    const brandSelect = $('product-brand-select');
    const merchantField = form.elements['merchant_id'];
    const defaultMerchantId = Number(form.dataset.defaultMerchantId || 0);
    let brandLoadToken = 0;
    /** 计算当前应使用的商户 ID：超管读商户下拉；其余用服务端注入的默认商户 */
    const currentMerchantId = () => (merchantField ? Number(merchantField.value || 0) : defaultMerchantId);
    /** 用品牌列表重建下拉选项，并尝试选中 selectedId */
    const renderBrandOptions = (brands, selectedId) => {
        if (!brandSelect) return;
        brandSelect.innerHTML = '<option value="">无品牌</option>';
        (brands || []).forEach((item) => {
            const option = document.createElement('option');
            option.value = item.id;
            option.textContent = item.name;
            brandSelect.appendChild(option);
        });
        const target = Number(selectedId || 0);
        if (target && (brands || []).some((item) => Number(item.id) === target)) {
            brandSelect.value = String(target);
        }
    };
    /** 按当前商户加载品牌下拉；无商户时禁用并提示「请先选择商户」 */
    const loadBrands = async (selectedId) => {
        if (!brandSelect) return;
        const token = ++brandLoadToken;
        const merchantId = currentMerchantId();
        if (!merchantId) {
            brandSelect.innerHTML = '<option value="">无品牌</option>';
            brandSelect.disabled = true;
            brandSelect.title = '请先选择商户';
            return;
        }
        brandSelect.disabled = false;
        brandSelect.title = '';
        try {
            const resp = await fetch(window.ADMIN_BASE + '/brands/options?merchant_id=' + encodeURIComponent(merchantId), { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
            const result = await resp.json();
            if (token !== brandLoadToken) return;
            if (result.code !== 0) throw new Error(result.message || '品牌加载失败');
            renderBrandOptions(result.data, selectedId);
        } catch (error) {
            if (token === brandLoadToken) toastError(error.message);
        }
    };
    // 超管切换商户时清空已选品牌并重新加载
    if (merchantField) merchantField.onchange = () => loadBrands(0);
    const brandQuickBtn = $('brand-quick-add-btn');
    if (brandQuickBtn) brandQuickBtn.onclick = () => {
        if (!brandSelect) return;
        const merchantId = currentMerchantId();
        if (!merchantId) { toastError('请先选择商户'); return; }
        const html = '<form id="swal-quick-brand" class="admin-form" style="text-align:left">'
            + '<div class="form-field" style="flex:1 1 100%"><label class="form-label">品牌名称</label>'
            + '<input name="name" required maxlength="64" placeholder="请输入品牌名称"></div>'
            + '<p class="text-sub" style="flex:1 1 100%;margin:0;font-size:12px;line-height:18px">'
            + '仅需填写名称；若该商户下已存在同名品牌将直接复用。</p></form>';
        AdminModal.form({
            title: '快速添加品牌',
            html,
            confirmText: '创建',
            onConfirm: async (popup) => {
                const input = popup.querySelector('#swal-quick-brand input[name="name"]');
                const name = (input && input.value ? input.value : '').trim();
                if (!name) { AdminToast.error('品牌名称不能为空'); return false; }
                const body = new FormData();
                body.append('merchant_id', merchantId);
                body.append('name', name);
                const result = await AdminAjax.post(window.ADMIN_BASE + '/brands/quick-add', body);
                const brand = result.data || {};
                if (brand.id && !Array.from(brandSelect.options).some((option) => Number(option.value) === Number(brand.id))) {
                    const option = document.createElement('option');
                    option.value = brand.id;
                    option.textContent = brand.name;
                    brandSelect.appendChild(option);
                }
                if (brand.id) brandSelect.value = String(brand.id);
                AdminToast.success(brand.created ? '品牌已创建并选中' : '已存在同名品牌，已为你选中');
                return true;
            },
        });
    };
    const reset = () => { form.reset(); $('product-id').value = ''; $('main-image').value = ''; renderMainPreview(); $('video-url').value = ''; $('video-cover').value = ''; $('video-meta').value = ''; renderVideoPreview(); setDescriptionHtml(''); htmlSource.value = ''; setPreviewEnabled(false); syncDescription('wysiwyg'); gallery = []; specs.splice(0); skuState = new Map(); specChangeConfirmed = false; renderGallery(); renderSpecs(); $('sku-step').hidden = true; $('sku-empty-tip').hidden = false; $('sku-rows').innerHTML = ''; };
    const loadState = (state) => { reset(); Object.keys(state).filter((name) => !['images_json', 'specs_json', 'skus', 'detail_html', 'video_meta_json', 'published_at'].includes(name)).forEach((name) => setVal(name, state[name])); const publishedInput = form.elements['published_at']; if (publishedInput) publishedInput.value = normalizeDateTime(state.published_at); loadBrands(Number(state.brand_id || 0)); $('main-image').value = state.main_image || ''; renderMainPreview(); $('video-url').value = state.video_url || ''; $('video-cover').value = state.video_cover || ''; $('video-meta').value = typeof state.video_meta_json === 'string' ? state.video_meta_json : JSON.stringify(state.video_meta_json || {}); renderVideoPreview(); setDescriptionHtml(state.detail_html || ''); setPreviewEnabled(String(state.preview_enabled || '0') === '1'); try { gallery = typeof state.images_json === 'string' ? JSON.parse(state.images_json) : (state.images_json || []); } catch (_) { gallery = []; } try { specs.splice(0, specs.length, ...(typeof state.specs_json === 'string' ? JSON.parse(state.specs_json) : (state.specs_json || []))); } catch (_) { specs.splice(0); } let skus = []; try { skus = typeof state.skus === 'string' ? JSON.parse(state.skus) : (state.skus || []); } catch (_) {} skus.forEach((sku) => { let values = sku.spec_values_json || {}; if (typeof values === 'string') { try { values = JSON.parse(values); } catch (_) { values = {}; } } skuState.set(JSON.stringify(Object.keys(values).sort().map((name) => [name, values[name]])), { code: sku.sku_code || '', price: sku.price, stock: sku.stock, status: Number(sku.status) === 1 }); }); renderGallery(); renderSpecs(); renderSkus(); };
    form.onsubmit = async (event) => { event.preventDefault(); snapshotSkus(); if (!rebuildSkuRows()) { toastError('请先完成规格配置'); return; } if (!$('sku-rows').querySelector('input[data-field="status"]:checked')) { toastError('至少保留一条启用 SKU'); return; } const payload = new FormData(form); payload.set('images_json', JSON.stringify(gallery)); payload.set('specs_json', JSON.stringify(specs.map((s) => ({ name: s.name, values: s.values })))); payload.set('spec_change_confirmed', specChangeConfirmed ? '1' : '0'); for (const name of [...payload.keys()]) if (name.startsWith('skus[')) payload.delete(name); payload.set('skus', JSON.stringify([...$$('#sku-rows tr')].map((row) => ({ spec_name: row.querySelector('input[name$="[spec_name]"]').value, spec_values_json: row.querySelector('input[name$="[spec_values_json]"]').value, sku_code: row.querySelector('[data-field="code"]').value, price: row.querySelector('[data-field="price"]').value, stock: row.querySelector('[data-field="stock"]').value, status: row.querySelector('[data-field="status"]').checked ? 1 : 0 })))); payload.set('detail_html', currentHtml()); payload.set('video_meta_json', $('video-meta').value || '{}'); try { const resp = await fetch(form.action, { method: 'POST', body: payload }); const result = await resp.json(); if (result.code === 0) { if (options && options.onSuccess) options.onSuccess(result); } else { toastError(result.message); } } catch (error) { toastError(error.message); } };
    const destroy = () => { if (destroyed) return; destroyed = true; try { descriptionEditor.destroy(); } catch (_) {} };
    // 初始化时按当前商户加载一次品牌下拉（编辑页随后由 loadState 以已选品牌重新加载，token 保证最后一次生效）
    loadBrands(0);
    renderSkus();
    return { loadState, reset, destroy };
};
