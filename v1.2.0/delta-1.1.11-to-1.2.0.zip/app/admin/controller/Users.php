<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\service\UserAdminService;
use app\common\support\AppContext;
use think\facade\View;

/**
 * 后台用户管理控制器（只读）
 *
 * 数据组装全部委托 UserAdminService；
 * 平台超管可见全部用户，商户管理员 / 员工仅可见与本商户有订单关系的用户。
 * 本期不提供任何写操作（无 status 字段、无编辑/删除入口）。
 */
class Users extends AdminBaseController
{
    /**
     * 用户列表页
     *
     * @return mixed
     */
    public function index()
    {
        $this->assignActiveMenu('users');

        $filters = [
            'keyword' => trim((string) $this->request->get('keyword', '')),
            'source'  => (string) $this->request->get('source', ''),
        ];
        $page = max(1, (int) $this->request->get('page', 1));

        $result = (new UserAdminService())->adminList($filters, $page, 20);

        View::assign('users', $result['list']);
        View::assign('filters', $filters);
        View::assign('is_super', $this->isSuper() ? 1 : 0);
        View::assign('can_write', 0);   // 本期只读
        View::assign('pages', $result['pager']->render());
        return View::fetch();
    }

    /**
     * 用户详情页
     *
     * @return mixed
     */
    public function detail()
    {
        $this->assignActiveMenu('users');

        $id = filter_var($this->request->get('id'), FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($id === false) {
            return redirect(admin_url('users'))->with('error', '用户不存在');
        }

        $page = max(1, (int) $this->request->get('page', 1));

        try {
            $detail = (new UserAdminService())->adminDetail((int) $id, $page, 10);
        } catch (BizException $e) {
            return redirect(admin_url('users'))->with('error', $e->getMessage());
        }

        View::assign('user', $detail['user']);
        View::assign('addresses', $detail['addresses']);
        View::assign('orders', $detail['orders']);
        View::assign('order_count', $detail['order_count']);
        View::assign('paid_sum', $detail['paid_sum']);
        View::assign('orders_link', $detail['orders_pager']->render());
        View::assign('can_write', 0);   // 本期只读
        return View::fetch();
    }

    /**
     * 是否平台超级管理员
     *
     * @return bool
     */
    private function isSuper(): bool
    {
        return AppContext::getAdminRole() === AdminRole::SUPER;
    }
}
