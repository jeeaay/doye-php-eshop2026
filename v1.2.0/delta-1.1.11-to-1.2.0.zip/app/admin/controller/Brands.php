<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\model\Admin;
use app\common\model\Brand;
use app\common\model\Merchant;
use app\common\service\AdminCrudService;
use app\common\service\MediaUploadService;
use app\common\support\AppContext;
use think\facade\View;

/**
 * 后台品牌管理控制器
 *
 * 形态对齐 app/admin/controller/Merchants.php：写入全部委托 AdminCrudService。
 */
class Brands extends AdminBaseController
{
    /**
     * 品牌列表页
     *
     * @return mixed
     */
    public function index()
    {
        $this->assignActiveMenu('brands');

        $service = new AdminCrudService();
        $isSuper = AppContext::getAdminRole() === AdminRole::SUPER;

        // 非超管由 Brand 的 MerchantScope 自动限制为本人所属商户，无需手写过滤
        $query = Brand::order('sort')->order('id', 'desc');
        $name = trim((string) $this->request->get('name', ''));
        $merchantId = (int) $this->request->get('merchant_id', 0);
        if ($name !== '') {
            $query->whereLike('name', '%' . $name . '%');
        }
        if ($isSuper && $merchantId > 0) {
            $query->where('merchant_id', $merchantId);
        }

        $brands = $query->paginate(20, false, [
            'query' => [
                'name'        => $name,
                'merchant_id' => $merchantId ?: null,
            ],
        ]);

        // 批量取商户名与创建者名，避免逐行查询
        $merchantIds = [];
        $creatorIds = [];
        foreach ($brands as $brand) {
            $merchantIds[] = (int) $brand->merchant_id;
            if ($brand->creator_id) {
                $creatorIds[] = (int) $brand->creator_id;
            }
        }
        $merchantNames = $merchantIds
            ? Merchant::whereIn('id', array_unique($merchantIds))->column('name', 'id')
            : [];
        $creatorNames = $creatorIds
            ? Admin::whereIn('id', array_unique($creatorIds))->column('username', 'id')
            : [];

        $list = [];
        foreach ($brands as $brand) {
            $list[] = [
                'id'            => (int) $brand->id,
                'name'          => $brand->name,
                'logo'          => $brand->logo ?: '',
                'merchant_id'   => (int) $brand->merchant_id,
                'merchant_name' => $merchantNames[(int) $brand->merchant_id] ?? '-',
                'creator_name'  => $brand->creator_id ? ($creatorNames[(int) $brand->creator_id] ?? '-') : '-',
                'sort'          => (int) $brand->sort,
                'status'        => (int) $brand->status,
                'can_write'     => $service->canWriteBrand($brand),
            ];
        }

        View::assign('brands', $list);
        View::assign('filters', ['name' => $name, 'merchant_id' => $merchantId]);
        View::assign('is_super', $isSuper ? 1 : 0);
        View::assign('can_create', $isSuper || !empty(AppContext::getMerchantIds()));
        View::assign('merchants', $isSuper ? Merchant::order('id')->select() : []);
        // 供列表页「新增」弹窗渲染归属商户下拉：
        // 超管列出全部商户；非超管仅在绑定多个商户时列出本人所属商户（PRD AC1「多商户员工需显式选择」）
        $merchantOptions = [];
        $selectableMerchantIds = $isSuper ? [] : AppContext::getMerchantIds();
        if ($isSuper || count($selectableMerchantIds) > 1) {
            $merchantQuery = $isSuper
                ? Merchant::order('id')
                : Merchant::whereIn('id', $selectableMerchantIds)->order('id');
            foreach ($merchantQuery->field('id,name')->select() as $merchant) {
                $merchantOptions[] = ['id' => (int) $merchant->id, 'name' => $merchant->name];
            }
        }
        View::assign('merchant_options_json', json_encode($merchantOptions, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT));
        View::assign('pages', $brands->render());
        return View::fetch();
    }

    /**
     * 品牌详情页
     *
     * @return mixed
     */
    public function detail()
    {
        $this->assignActiveMenu('brands');

        $id = filter_var($this->request->get('id'), FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($id === false) {
            return redirect(admin_url('brands'))->with('error', '品牌不存在');
        }
        try {
            $brand = (new AdminCrudService())->brandDetail((int) $id);
        } catch (BizException $e) {
            return redirect(admin_url('brands'))->with('error', $e->getMessage());
        }

        View::assign('brand', $brand);
        View::assign('brand_json', json_encode($brand, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT));
        return View::fetch('brands/detail');
    }

    /**
     * 新增/更新品牌基础信息（列表弹窗）
     *
     * @return \think\response\Json
     */
    public function save()
    {
        try {
            $id = $this->request->post('id') ? (int) $this->request->post('id') : null;
            (new AdminCrudService())->saveBrand($this->request->post(), $id);
            return json(['code' => 0, 'message' => '品牌已保存', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 保存品牌详情资料
     *
     * @return \think\response\Json
     */
    public function detailSave()
    {
        try {
            (new AdminCrudService())->saveBrandDetail($this->request->post(), (int) $this->request->post('id', 0));
            return json(['code' => 0, 'message' => '品牌资料已保存', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 品牌 logo / 富文本图片上传（brands 命名空间）
     *
     * @return \think\response\Json
     */
    public function upload()
    {
        try {
            $data = (new MediaUploadService())->upload($this->request->file('file'), 'image', 'brands');
            return json(['code' => 0, 'message' => 'ok', 'data' => $data]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 启用/停用品牌
     *
     * @return \think\response\Json
     */
    public function status()
    {
        try {
            (new AdminCrudService())->toggleBrand((int) $this->request->post('id'), (int) $this->request->post('status'));
            return json(['code' => 0, 'message' => '品牌状态已更新', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 删除品牌
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        try {
            (new AdminCrudService())->deleteBrand((int) $this->request->post('id'));
            return json(['code' => 0, 'message' => '品牌已删除', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 商品表单内快速添加品牌（仅名称；同名自动复用）
     *
     * @return \think\response\Json
     */
    public function quickAdd()
    {
        try {
            $result = (new AdminCrudService())->quickAddBrand(
                (int) $this->request->post('merchant_id'),
                (string) $this->request->post('name', '')
            );
            return json(['code' => 0, 'message' => 'ok', 'data' => $result]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 商品表单品牌下拉数据（按商户过滤）
     *
     * @return \think\response\Json
     */
    public function options()
    {
        try {
            $options = (new AdminCrudService())->brandOptions((int) $this->request->get('merchant_id'));
            return json(['code' => 0, 'message' => 'ok', 'data' => $options]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }
}
