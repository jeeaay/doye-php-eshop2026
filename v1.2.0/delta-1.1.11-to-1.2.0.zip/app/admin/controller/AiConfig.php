<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\service\SettingService;
use app\common\support\AppContext;
use think\facade\View;

/**
 * AI 配置（平台超管专用）
 *
 * AI 翻译接口的地址、密钥、模型与成本参数（config/setting.php 的 translation 分组）。
 */
class AiConfig extends AdminBaseController
{
    /**
     * AI 配置页面
     *
     * @return mixed
     */
    public function index()
    {
        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可配置 AI');
        }
        $this->assignActiveMenu('ai-config');

        View::assign('translation_group', (new SettingService())->group('translation'));

        return View::fetch();
    }
}
