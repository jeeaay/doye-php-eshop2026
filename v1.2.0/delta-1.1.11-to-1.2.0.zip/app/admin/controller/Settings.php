<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\model\Admin;
use think\facade\Session;
use think\facade\View;

class Settings extends AdminBaseController
{
    public function index()
    {
        $this->assignActiveMenu('settings');

        $sessionAdmin = Session::get('admin');
        $admin = Admin::find($sessionAdmin['id']);

        $roleText = $this->roleText($admin->role);

        View::assign('admin_info', [
            'username'  => $admin->username,
            'role_text' => $roleText,
            'email'     => $admin->email ?: '',
        ]);

        return View::fetch();
    }

    public function profile()
    {
        $sessionAdmin = Session::get('admin');
        $admin = Admin::find((int) ($sessionAdmin['id'] ?? 0));
        if (!$admin) return redirect(admin_url('login'));
        $admin->email = trim((string) $this->request->post('email', '')) ?: null;
        $admin->save();
        return redirect(admin_url('settings'))->with('success', '资料已保存');
    }

    public function password()
    {
        $sessionAdmin = Session::get('admin');
        $admin = Admin::find((int) ($sessionAdmin['id'] ?? 0));
        $old = (string) $this->request->post('old_password', '');
        $new = (string) $this->request->post('new_password', '');
        if (!$admin || !password_verify($old, (string) $admin->password_hash) || strlen($new) < 8) {
            return redirect(admin_url('settings'))->with('error', '原密码错误或新密码少于 8 位');
        }
        $admin->password_hash = password_hash($new, PASSWORD_DEFAULT);
        $admin->save();
        return redirect(admin_url('settings'))->with('success', '密码已更新');
    }

    private function roleText(string $role): string
    {
        return match ($role) {
            AdminRole::SUPER => '平台超级管理员',
            AdminRole::MERCHANT_ADMIN => '商户管理员',
            AdminRole::STAFF => '普通员工',
            default => '未知角色',
        };
    }
}
