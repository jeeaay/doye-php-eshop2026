<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\support\AppContext;
use app\common\model\Merchant;
use app\common\service\MediaUploadService;
use think\facade\View;
use app\common\service\AdminCrudService;
use app\common\exception\BizException;

class Merchants extends AdminBaseController
{
    public function index()
    {
        $this->assignActiveMenu('merchants');

        $query = Merchant::order('id', 'desc');
        $name = trim((string) $this->request->get('name', ''));
        $phone = trim((string) $this->request->get('phone', ''));
        if ($name !== '') $query->whereLike('name', '%' . $name . '%');
        if ($phone !== '') $query->whereLike('phone', '%' . $phone . '%');

        $role = AppContext::getAdminRole();
        $merchantIds = AppContext::getMerchantIds();
        if ($role !== AdminRole::SUPER) {
            if (!empty($merchantIds)) {
                $query->whereIn('id', $merchantIds);
            } else {
                $query->whereRaw('1 = 0');
            }
        }

        $merchants = $query->paginate(20);

        $list = [];
        foreach ($merchants as $merchant) {
            $list[] = [
                'id'          => $merchant->id,
                'name'        => $merchant->name,
                'contact'     => $merchant->contact ?: '-',
                'phone'       => $merchant->phone ?: '-',
                'address'     => $merchant->address ?: '-',
                'create_time' => $merchant->create_time ? (string)$merchant->create_time : '-',
                'status'      => $merchant->status,
            ];
        }

        View::assign('merchants', $list);
        View::assign('filters', ['name' => $name, 'phone' => $phone]);
        View::assign('pages', $merchants->render());
        return View::fetch();
    }

    public function detail()
    {
        $this->assignActiveMenu('merchants');

        $id = filter_var($this->request->get('id'), FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($id === false) {
            return redirect(admin_url('merchants'))->with('error', '商户不存在');
        }
        try {
            $merchant = (new AdminCrudService())->merchantDetail((int) $id);
        } catch (BizException $e) {
            return redirect(admin_url('merchants'))->with('error', $e->getMessage());
        }

        View::assign('merchant', $merchant);
        View::assign('merchant_json', json_encode($merchant, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT));
        return View::fetch('merchants/detail');
    }

    public function save()
    {
        try {
            $id = $this->request->post('id') ? (int) $this->request->post('id') : null;
            (new AdminCrudService())->saveMerchant($this->request->post(), $id);
            return json(['code' => 0, 'message' => '商户已保存', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    public function detailSave()
    {
        try {
            (new AdminCrudService())->saveMerchantDetail($this->request->post(), (int) $this->request->post('id', 0));
            return json(['code' => 0, 'message' => '商户资料已保存', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    public function upload()
    {
        try {
            $data = (new MediaUploadService())->upload($this->request->file('file'), 'image', 'merchants');
            return json(['code' => 0, 'message' => 'ok', 'data' => $data]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    public function status()
    {
        try {
            (new AdminCrudService())->toggleMerchant((int) $this->request->post('id'), (int) $this->request->post('status'));
            return json(['code' => 0, 'message' => '商户状态已更新', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    public function delete()
    {
        try {
            (new AdminCrudService())->deleteMerchant((int) $this->request->post('id'));
            return json(['code' => 0, 'message' => '商户已删除', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }
}
