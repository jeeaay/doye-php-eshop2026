<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\model\Category;
use app\common\model\Merchant;
use app\common\model\Product;
use app\common\service\AdminCrudService;
use app\common\service\LanguageService;
use app\common\service\MediaUploadService;
use app\common\service\TranslationJobService;
use app\common\support\AppContext;
use think\facade\View;

class Products extends AdminBaseController
{
    private function getMerchantOptions(): array
    {
        $query = Merchant::where('status', 1)->order('id');
        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            $query->whereIn('id', AppContext::getMerchantIds());
        }
        return $query->select()->all();
    }

    /**
     * 商品表单默认商户 ID（注入给前端品牌联动使用）
     *
     * 超管无默认商户（返回 0，需手动选择）；非超管取绑定商户中的第一个。
     *
     * @return int
     */
    private function defaultMerchantId(): int
    {
        if (AppContext::getAdminRole() === AdminRole::SUPER) {
            return 0;
        }
        return (int) (AppContext::getMerchantIds()[0] ?? 0);
    }

    /**
     * 商品表单可编辑的翻译语种（不含基准语种 en）
     *
     * @return array<int,array<string,mixed>>
     */
    private function translationLanguages(): array
    {
        $languages = [];
        foreach ((new LanguageService())->enabled() as $language) {
            if (strtolower((string) $language['code']) === base_locale()) {
                continue;
            }
            $languages[] = $language;
        }
        return $languages;
    }

    public function create()
    {
        $this->assignActiveMenu('products');
        $languages = $this->translationLanguages();
        View::assign('mode', 'create');
        View::assign('product', []);
        View::assign('product_json', '{}');
        View::assign('languages', $languages);
        View::assign('multilingual_enabled', (bool) site_config('i18n.enabled', false) && $languages !== []);
        View::assign('translations_json', '{}');
        View::assign('price_currency', base_currency_code());
        View::assign('categories', Category::order('sort')->select());
        View::assign('merchants', $this->getMerchantOptions());
        View::assign('default_merchant_id', $this->defaultMerchantId());
        return View::fetch('products/form');
    }

    public function edit()
    {
        $this->assignActiveMenu('products');
        $id = filter_var($this->request->get('id'), FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($id === false) {
            return redirect(admin_url('products'))->with('error', '商品不存在');
        }
        try {
            $product = (new AdminCrudService())->productDetail($id);
        } catch (BizException $e) {
            return redirect(admin_url('products'))->with('error', $e->getMessage());
        }
        $merchants = $this->getMerchantOptions();
        if (!in_array((int) $product['merchant_id'], array_map(static fn($merchant) => (int) $merchant->id, $merchants), true)) {
            $merchants[] = Merchant::find((int) $product['merchant_id']);
        }
        $translations = (array) ($product['translations'] ?? []);
        unset($product['translations']);
        $languages = $this->translationLanguages();

        View::assign('mode', 'edit');
        View::assign('product', $product);
        View::assign('product_json', json_encode($product, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT));
        View::assign('languages', $languages);
        View::assign('multilingual_enabled', (bool) site_config('i18n.enabled', false) && $languages !== []);
        View::assign('translations_json', json_encode($translations, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT));
        View::assign('price_currency', base_currency_code());
        View::assign('categories', Category::order('sort')->select());
        View::assign('merchants', array_filter($merchants));
        // 编辑时默认商户固定为商品所属商户，供品牌联动使用
        View::assign('default_merchant_id', (int) $product['merchant_id']);
        return View::fetch('products/form');
    }

    public function index()
    {
        $this->assignActiveMenu('products');

        $query = Product::with(['category', 'skus', 'brand']);
        $keyword = trim((string) $this->request->get('keyword', ''));
        $categoryId = (int) $this->request->get('category_id', 0);
        $status = $this->request->get('status', '');
        if ($keyword !== '') $query->whereLike('title', '%' . $keyword . '%');
        if ($categoryId) $query->where('category_id', $categoryId);
        if ($status !== '') $query->where('status', (int) $status);
        $products = $query
            ->order('id', 'desc')
            ->paginate(20, false, [
                'query' => [
                    'keyword' => $keyword,
                    'category_id' => $categoryId ?: null,
                    'status' => $status,
                ],
            ]);

        $list = [];
        foreach ($products as $product) {
            $stock = 0;
            foreach ($product->skus as $sku) {
                $stock += $sku->stock;
            }
            $prices = $product->skus->map(static fn($sku) => (float) $sku->price)->all();
            $statusText = [0 => '草稿', 1 => '出售中', 2 => '已下架'][$product->status] ?? '未知';
            $list[] = [
                'id'             => $product->id,
                'category_id'    => $product->category_id,
                'title'          => $product->title,
                'main_image'     => $product->main_image,
                'category_name'  => $product->category?->name ?? '-',
                'brand_name'     => $product->brand?->name ?? '-',
                'price'          => $prices ? number_format(min($prices), 2, '.', '') : '0.00',
                'stock'          => $stock,
                'status'         => $product->status,
            ];
        }

        View::assign('products', $list);
        View::assign('categories', Category::order('sort')->select());
        View::assign('merchants', $this->getMerchantOptions());
        View::assign('filters', ['keyword' => $keyword, 'category_id' => $categoryId, 'status' => $status]);
        View::assign('pages', $products->render());
        return View::fetch();
    }

    public function save()
    {
        try {
            $payload = $this->request->post();
            $id = !empty($payload['id']) ? (int) $payload['id'] : null;
            (new AdminCrudService())->saveProduct($payload, $id);
            return json(['code' => 0, 'message' => '商品已保存', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 读取商品全部语种译文（后台编辑页刷新用）
     *
     * @return \think\response\Json
     */
    public function translations()
    {
        try {
            $id = (int) $this->request->get('id', 0);
            $detail = (new AdminCrudService())->productDetail($id);
            return json(['code' => 0, 'message' => 'ok', 'data' => $detail['translations'] ?? []]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 商品单语种 AI 翻译入队
     *
     * @return \think\response\Json
     */
    public function translate()
    {
        try {
            $id = (int) $this->request->post('id', 0);
            $lang = strtolower(trim((string) $this->request->post('lang', '')));
            $force = (int) $this->request->post('force', 0) === 1;
            if ($id <= 0 || $lang === '') {
                throw new BizException('商品或语种参数无效');
            }
            (new AdminCrudService())->productDetail($id); // 范围校验
            $jobIds = (new TranslationJobService())->enqueue('product', $id, [$lang], $force, 10);
            if (!$jobIds) {
                return json(['code' => 0, 'message' => '该语种已是最新，无需翻译', 'data' => ['job_ids' => []]]);
            }
            return json(['code' => 0, 'message' => '已加入翻译队列', 'data' => ['job_ids' => $jobIds]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 查询翻译任务状态
     *
     * @return \think\response\Json
     */
    public function translationStatus()
    {
        try {
            $jobId = (int) $this->request->get('job_id', 0);
            $job = \app\common\model\TranslationJob::find($jobId);
            if (!$job) {
                throw new BizException('翻译任务不存在');
            }
            return json(['code' => 0, 'message' => 'ok', 'data' => (new TranslationJobService())->payload($job)]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 批量补全商品缺失翻译（平台超管）
     *
     * @return \think\response\Json
     */
    public function backfill()
    {
        try {
            if (AppContext::getAdminRole() !== AdminRole::SUPER) {
                throw new BizException('仅平台超管可执行批量翻译');
            }
            $result = (new TranslationJobService())->enqueueMissing('product', [], 200, false);
            return json([
                'code'    => 0,
                'message' => '已加入翻译队列：' . $result['jobs'] . ' 个任务',
                'data'    => $result,
            ]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    public function upload()
    {
        try {
            $data = (new MediaUploadService())->upload($this->request->file('file'), (string) $this->request->post('media_type', 'image'));
            return json(['code' => 0, 'message' => 'ok', 'data' => $data]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    public function delete()
    {
        try {
            (new AdminCrudService())->deleteProduct((int) $this->request->post('id'));
            return json(['code' => 0, 'message' => '商品已删除', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    public function status()
    {
        try {
            (new AdminCrudService())->toggleProduct((int) $this->request->post('id'), (int) $this->request->post('status'));
            return json(['code' => 0, 'message' => '商品状态已更新', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }
}
