<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\service\AuditLogService;
use app\common\service\SettingService;
use app\common\service\UpdateService;
use app\common\support\AppContext;
use think\facade\View;

/**
 * 系统设置（站点级）
 *
 * 仅平台超级管理员可访问：站点名称、首页 SEO、联系方式、配送文案、SMTP 邮件服务、社交链接等。
 * 页面按 config/setting.php 的分组注册表渲染，切标签不刷新页面，按分组整组保存。
 *
 * 除注册表分组外还有两个内置标签：
 *   - update（更新设置）：在线增量更新，包含版本卡片/升级/历史，数据由 /admin/update/overview 按需加载；
 *   - logs（操作日志清理）：把原来固定显示在页面底部的清理卡片收进标签。
 */
class Setting extends AdminBaseController
{
    /**
     * 系统设置页面
     *
     * @return \think\response\View|\think\response\Redirect
     */
    public function index()
    {
        $this->assignActiveMenu('setting');

        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可访问系统设置');
        }

        $groups = (new SettingService())->groupList();
        $tabs = array_column($groups, 'key');
        $tabs[] = 'logs';
        $active = (string) $this->request->get('tab', '');
        if ($active === '' || !in_array($active, $tabs, true)) {
            $active = (string) ($tabs[0] ?? 'basic');
        }

        $auditStats = (new AuditLogService())->stats();
        $purgeOptions = [];
        foreach ((array) config('audit.cleanup_options', [7, 30, 365]) as $days) {
            $purgeOptions[] = [
                'days'  => (int) $days,
                'count' => (int) ($auditStats['purge'][(int) $days] ?? 0),
            ];
        }

        // 更新面板首屏只注入「当前版本」这类本地可读数据；检查更新/历史走 AJAX，
        // 避免打开系统设置就被分发源的网络超时拖慢。
        $versionData = (new UpdateService())->currentVersion();
        $current = $versionData !== null ? trim((string) ($versionData['version'] ?? '')) : '';

        View::assign([
            'setting_groups'         => $groups,
            'active_tab'             => $active,
            'audit_stats'            => $auditStats,
            'purge_options'          => $purgeOptions,
            'update_current_version' => $current !== '' ? $current : '未识别（手工部署）',
            'update_released_at'     => $this->formatTime((string) ($versionData['released_at'] ?? '')),
            'update_db_version'      => (string) ($versionData['db_version'] ?? '') ?: '—',
            'update_php_min'         => (string) ($versionData['php_min'] ?? '') ?: '—',
        ]);

        return View::fetch();
    }

    /**
     * 保存某个设置分组（AJAX）
     *
     * 表单字段以 values[key] 形式提交，避免 PHP 把键名中的点号转成下划线
     * （如 brand.name 会变成 brand_name）。
     *
     * @return \think\response\Json
     */
    public function save()
    {
        try {
            if (AppContext::getAdminRole() !== AdminRole::SUPER) {
                throw new BizException('仅平台超级管理员可修改系统设置');
            }

            $group  = (string) $this->request->post('group', '');
            $values = (array) $this->request->post('values', []);

            (new SettingService())->save($group, $values);

            return json(['code' => 0, 'message' => '设置已保存', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * ISO8601 → 本地可读时间（解析失败原样返回）
     */
    private function formatTime(string $value): string
    {
        $value = trim($value);
        if ($value === '') {
            return '—';
        }
        $ts = strtotime($value);
        return $ts === false ? $value : date('Y-m-d H:i', $ts);
    }
}
