<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\exception\BizException;
use app\common\lib\payment\PaymentChannelCatalog;
use app\common\service\PaymentChannelService;
use think\facade\View;

class Payments extends AdminBaseController
{
    public function index()
    {
        $this->assignActiveMenu('payments');
        try {
            $channels = (new PaymentChannelService())->adminList($this->request->domain());
        } catch (BizException $e) {
            return redirect(admin_url('index'))->with('error', $e->getMessage());
        }
        View::assign('channels', $channels);
        return View::fetch();
    }

    public function save()
    {
        try {
            $code = (string) $this->request->post('code', '');
            (new PaymentChannelService())->save($code, $this->request->post());
            $env = (int) $this->request->post('test_mode', 0) === 1 ? '测试/沙箱' : '正式';
            return json(['code' => 0, 'message' => PaymentChannelCatalog::label($code) . $env . '环境配置已保存', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    public function test()
    {
        try {
            $code = (string) $this->request->post('code', '');
            $testMode = (int) $this->request->post('test_mode', 0) === 1;
            $message = (new PaymentChannelService())->test($code, $testMode);
            return json(['code' => 0, 'message' => '连接测试通过', 'data' => ['message' => $message]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        } catch (\Throwable $e) {
            return json(['code' => 1, 'message' => '连接测试失败：' . $e->getMessage(), 'data' => null]);
        }
    }
}