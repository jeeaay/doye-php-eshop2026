<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\OrderStatus;
use app\common\enum\AdminRole;
use app\common\model\Order;
use app\common\service\OrderService;
use think\facade\View;
use app\common\service\AdminCrudService;
use app\common\service\CurrencyService;
use app\common\support\AppContext;
use app\common\exception\BizException;

class Orders extends AdminBaseController
{
    public function index()
    {
        $this->assignActiveMenu('orders');

        $status = $this->request->get('status');
        $orderNo = $this->request->get('order_no', '');
        $phone = trim((string) $this->request->get('phone', ''));

        $query = Order::with(['user', 'items']);

        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            $merchantIds = AppContext::getMerchantIds();
            if (empty($merchantIds)) {
                $query->where('merchant_id', 0);
            } else {
                $query->whereIn('merchant_id', $merchantIds);
            }
        }

        if ($orderNo) {
            $query->whereLike('order_no', "%{$orderNo}%");
        }
        if ($phone !== '') {
            $query->whereHas('user', function ($q) use ($phone) { $q->whereLike('phone', "%{$phone}%"); });
        }
        if ($status !== '' && $status !== null) {
            $query->where('status', (int)$status);
        }

        $orders = $query->order('id', 'desc')->paginate(20);

        $statusTabs = [
            ['label' => '全部订单', 'status' => ''],
            ['label' => '待付款',   'status' => '0'],
            ['label' => '待发货',   'status' => '1'],
            ['label' => '配送中',   'status' => '2'],
            ['label' => '已完成',   'status' => '4'],
            ['label' => '已关闭',   'status' => '-1'],
        ];
        foreach ($statusTabs as &$tab) {
            $tab['url'] = admin_url('orders') . '?' . http_build_query(array_filter([
                'order_no' => $orderNo,
                'phone'    => $phone,
                'status'   => $tab['status'],
            ], fn ($v) => $v !== '' && $v !== null));
            $tab['active'] = (string)($status ?? '') === $tab['status'];
        }
        unset($tab);

        $baseSymbol = (string) ((new CurrencyService())->base()['symbol'] ?? '$');
        $list = [];
        foreach ($orders as $order) {
            $firstItem = $order->items->first();
            $statusColor = match ($order->status) {
                OrderStatus::PENDING_PAY  => 'var(--text-sub)',
                OrderStatus::PENDING_SHIP => 'var(--warning)',
                OrderStatus::SHIPPING     => 'var(--primary)',
                OrderStatus::DELIVERED    => 'var(--primary)',
                OrderStatus::COMPLETED    => 'var(--success)',
                OrderStatus::CANCELLED    => 'var(--text-sub)',
                OrderStatus::REFUNDED     => 'var(--error)',
                default                   => 'var(--text-main)',
            };
            $list[] = [
                'order_no'       => $order->order_no,
                'create_time'    => $order->create_time ? (string)$order->create_time : '',
                'product_title'  => $firstItem ? (is_string($firstItem->sku_snapshot_json) ? json_decode($firstItem->sku_snapshot_json, true)['title'] ?? '' : ($firstItem->sku_snapshot_json['title'] ?? '')) : '',
                'product_image'  => $firstItem ? (is_string($firstItem->sku_snapshot_json) ? json_decode($firstItem->sku_snapshot_json, true)['main_image'] ?? '' : ($firstItem->sku_snapshot_json['main_image'] ?? '')) : '',
                'spec'           => $firstItem ? (is_string($firstItem->sku_snapshot_json) ? json_decode($firstItem->sku_snapshot_json, true)['spec_name'] ?? '' : ($firstItem->sku_snapshot_json['spec_name'] ?? '')) : '',
                'unit_price'     => $firstItem ? $baseSymbol . number_format((float)$firstItem->unit_price, 2) : '',
                'quantity'       => $firstItem ? $firstItem->quantity : 0,
                'buyer_name'     => $order->user?->nickname ?? '用户' . $order->user_id,
                'buyer_phone'    => $order->user?->phone ? substr_replace($order->user->phone, '****', 3, 4) : '',
                'status_text'    => OrderStatus::label($order->status),
                'status_color'   => $statusColor,
                'total_amount'   => $baseSymbol . number_format((float)$order->total_amount, 2),
                'shipping_fee'   => $baseSymbol . '0.00',
                'shipping_no'    => $order->shipping_no ?? '',
                'shipping_company' => $order->shipping_company ?? '',
                'delivery_method' => $order->delivery_method ?? '',
            ];
        }

        View::assign('orders', $list);
        View::assign('filters', ['order_no' => $orderNo, 'phone' => $phone, 'status' => $status]);
        View::assign('status_tabs', $statusTabs);
        View::assign('pages', $orders->render());
        return View::fetch();
    }

    public function detail()
    {
        $this->assignActiveMenu('orders');

        $orderNo = (string) $this->request->get('order_no', '');
        if ($orderNo === '') {
            return redirect(admin_url('orders'))->with('error', '参数错误');
        }

        $order = Order::with(['items', 'address', 'user', 'pay', 'merchant'])
            ->where('order_no', $orderNo)
            ->find();

        $merchantIds = AppContext::getMerchantIds();
        if (!$order || (AppContext::getAdminRole() !== AdminRole::SUPER && (empty($merchantIds) || !in_array((int) $order->merchant_id, $merchantIds, true)))) {
            return redirect(admin_url('orders'))->with('error', '订单不存在');
        }

        $deliveryMethod = (string)($order->delivery_method ?? '');
        $deliveryMethodLabel = match ($deliveryMethod) {
            'self'    => '商家自行配送',
            'express' => '快递物流',
            default   => '',
        };

        $statusColor = match ((int)$order->status) {
            OrderStatus::PENDING_PAY  => 'var(--text-sub)',
            OrderStatus::PENDING_SHIP => 'var(--warning)',
            OrderStatus::SHIPPING     => 'var(--primary)',
            OrderStatus::DELIVERED    => 'var(--primary)',
            OrderStatus::COMPLETED    => 'var(--success)',
            OrderStatus::CANCELLED    => 'var(--text-sub)',
            OrderStatus::REFUNDED     => 'var(--error)',
            default                   => 'var(--text-main)',
        };

        $baseSymbol = (string) ((new CurrencyService())->base()['symbol'] ?? '$');
        $items = [];
        foreach ($order->items as $item) {
            $snap = $item->sku_snapshot_json;
            if (is_string($snap)) {
                $snap = json_decode($snap, true) ?: [];
            }
            $items[] = [
                'title'       => $snap['title'] ?? '',
                'spec_name'   => $snap['spec_name'] ?? '',
                'main_image'  => $snap['main_image'] ?? '',
                'unit_price'  => $baseSymbol . number_format((float)$item->unit_price, 2),
                'quantity'    => $item->quantity,
                'total_price' => $baseSymbol . number_format((float)$item->total_price, 2),
            ];
        }

        $addr = $order->address;

        $display = (new OrderService())->displaySummary($order);
        View::assign('order', [
            'order_no'            => $order->order_no,
            'create_time'         => $order->create_time ? (string)$order->create_time : '',
            'status_text'         => OrderStatus::label((int)$order->status),
            'status_color'        => $statusColor,
            'total_amount'        => $display['charge_text'],
            'display_total'       => $display['local_text'],
            'display_currency'    => $display['currency'],
            'remark'              => (string)($order->remark ?? ''),
            'buyer_name'          => $order->user?->nickname ?? '用户' . $order->user_id,
            'buyer_phone'         => $order->user?->phone ?? '',
            'delivery_method'     => $deliveryMethod,
            'delivery_method_label'=> $deliveryMethodLabel,
            'shipping_no'         => (string)($order->shipping_no ?? ''),
            'shipping_company'    => (string)($order->shipping_company ?? ''),
            'ship_at'             => $order->ship_at ? (string)$order->ship_at : '',
        ]);
        View::assign('items', $items);
        View::assign('address', [
            'name'           => $addr ? $addr->name : '',
            'phone'          => $addr ? $addr->phone : '',
            'address_detail' => $addr ? $addr->address_detail : '',
        ]);

        return View::fetch();
    }

    public function ship()
    {
        try {
            (new AdminCrudService())->shipOrder(
                (string) $this->request->post('order_no'),
                (string) $this->request->post('shipping_no'),
                (string) $this->request->post('shipping_company'),
                (string) $this->request->post('delivery_method', 'express')
            );
            return json(['code' => 0, 'message' => '订单已发货', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    public function deliver()
    {
        try {
            (new AdminCrudService())->markDelivered((string) $this->request->post('order_no'));
            return redirect(admin_url('orders'))->with('success', '订单已标记送达');
        } catch (BizException $e) {
            return redirect(admin_url('orders'))->with('error', $e->getMessage());
        }
    }
}
