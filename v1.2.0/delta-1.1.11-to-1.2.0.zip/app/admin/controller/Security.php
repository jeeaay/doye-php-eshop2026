<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\service\SecurityService;
use app\common\support\AppContext;
use think\facade\View;

/**
 * 安全设置（系统设置 → 安全设置）
 *
 * 页面：IP 黑白名单、探针规则、拦截日志与防护开关，切标签不刷新页面以外的前端交互。
 * 仅平台超级管理员可访问；所有写操作与 /admin-api/v1/security/* 复用 SecurityService。
 */
class Security extends AdminBaseController
{
    /** 允许的标签 */
    private const TABS = ['overview', 'settings', 'blacklist', 'whitelist', 'path-rules', 'events'];

    /**
     * 安全设置页面
     *
     * @return \think\response\View|\think\response\Redirect
     */
    public function index()
    {
        $this->assignActiveMenu('security');

        if (!$this->isSuper()) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可访问安全设置');
        }

        $service = new SecurityService();

        $tab = (string) $this->request->get('tab', 'overview');
        if (!in_array($tab, self::TABS, true)) {
            $tab = 'overview';
        }

        $page    = max(1, (int) $this->request->get('page', 1));
        $keyword = trim((string) $this->request->get('keyword', ''));
        $status  = $this->request->get('status', '');

        $rows  = [];
        $pager = null;
        $total = 0;

        $eventFilters = [
            'ip'         => trim((string) $this->request->get('ip', '')),
            'event_type' => trim((string) $this->request->get('event_type', '')),
            'keyword'    => $keyword,
        ];

        if ($tab === 'blacklist' || $tab === 'whitelist') {
            $result = $service->ipRuleList([
                'list_type' => $tab,
                'keyword'   => $keyword,
                'status'    => $status,
            ], $page, 20);
            $rows  = $result['list'];
            $pager = $result['pager'];
            $total = $result['total'];
        } elseif ($tab === 'path-rules') {
            $result = $service->pathRuleList([
                'keyword' => $keyword,
                'status'  => $status,
            ], $page, 20);
            $rows  = $result['list'];
            $pager = $result['pager'];
            $total = $result['total'];
        } elseif ($tab === 'events') {
            $result = $service->eventList($eventFilters, $page, 30);
            $rows  = $result['list'];
            $pager = $result['pager'];
            $total = $result['total'];
        }

        View::assign([
            'tab'           => $tab,
            'settings'      => $service->settingsForForm(),
            'overview'      => $service->overview(),
            'current_ip'    => $service->currentIp(),
            'storage_ready' => $service->storageReady(),
            'rows'          => $rows,
            'pager'         => $pager,
            'pager_html'    => $pager !== null ? $pager->render() : '',
            'total'         => $total,
            'keyword'       => $keyword,
            'status'        => $status,
            'event_filters' => $eventFilters,
        ]);

        return View::fetch();
    }

    /**
     * 保存防护设置
     *
     * @return \think\response\Json
     */
    public function saveSettings()
    {
        try {
            $this->assertSuper();
            (new SecurityService())->saveSettings((array) $this->request->post());

            return json(['code' => 0, 'message' => '安全设置已保存', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 新增/修改黑白名单
     *
     * @return \think\response\Json
     */
    public function saveIpRule()
    {
        try {
            $this->assertSuper();
            $id   = (int) $this->request->post('id', 0);
            $data = [
                'list_type'   => (string) $this->request->post('list_type', 'blacklist'),
                'ip'          => (string) $this->request->post('ip', ''),
                'reason'      => (string) $this->request->post('reason', ''),
                'remark'      => (string) $this->request->post('remark', ''),
                'status'      => (int) $this->request->post('status', 1),
                'expire_time' => (string) $this->request->post('expire_time', ''),
            ];

            $row = (new SecurityService())->saveIpRule($data, $id > 0 ? $id : null);

            return json([
                'code'    => 0,
                'message' => $id > 0 ? '已更新' : '已添加',
                'data'    => $row,
            ]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 删除黑白名单（批量）
     *
     * @return \think\response\Json
     */
    public function deleteIpRules()
    {
        try {
            $this->assertSuper();
            $count = (new SecurityService())->deleteIpRules((array) $this->request->post('ids', []));

            return json(['code' => 0, 'message' => '已删除 ' . $count . ' 条记录', 'data' => ['count' => $count]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 启用/停用黑白名单
     *
     * @return \think\response\Json
     */
    public function setIpRuleStatus()
    {
        try {
            $this->assertSuper();
            $id     = (int) $this->request->post('id', 0);
            $status = (int) $this->request->post('status', 1);
            (new SecurityService())->setIpRuleStatus($id, $status);

            return json(['code' => 0, 'message' => $status === 1 ? '已启用' : '已停用', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 新增/修改探针规则
     *
     * @return \think\response\Json
     */
    public function savePathRule()
    {
        try {
            $this->assertSuper();
            $id   = (int) $this->request->post('id', 0);
            $data = [
                'name'       => (string) $this->request->post('name', ''),
                'match_type' => (string) $this->request->post('match_type', 'contains'),
                'pattern'    => (string) $this->request->post('pattern', ''),
                'remark'     => (string) $this->request->post('remark', ''),
                'status'     => (int) $this->request->post('status', 1),
            ];

            $row = (new SecurityService())->savePathRule($data, $id > 0 ? $id : null);

            return json([
                'code'    => 0,
                'message' => $id > 0 ? '已更新' : '已添加',
                'data'    => $row,
            ]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 删除探针规则（批量）
     *
     * @return \think\response\Json
     */
    public function deletePathRules()
    {
        try {
            $this->assertSuper();
            $count = (new SecurityService())->deletePathRules((array) $this->request->post('ids', []));

            return json(['code' => 0, 'message' => '已删除 ' . $count . ' 条规则', 'data' => ['count' => $count]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 启用/停用探针规则
     *
     * @return \think\response\Json
     */
    public function setPathRuleStatus()
    {
        try {
            $this->assertSuper();
            $id     = (int) $this->request->post('id', 0);
            $status = (int) $this->request->post('status', 1);
            (new SecurityService())->setPathRuleStatus($id, $status);

            return json(['code' => 0, 'message' => $status === 1 ? '已启用' : '已停用', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 清理拦截日志
     *
     * @return \think\response\Json
     */
    public function clearEvents()
    {
        try {
            $this->assertSuper();
            if ((int) $this->request->post('confirm', 0) !== 1) {
                throw new BizException('请先确认清理操作');
            }

            $days  = max(0, (int) $this->request->post('days', 0));
            $count = (new SecurityService())->clearEvents($days);

            return json(['code' => 0, 'message' => '已清理 ' . $count . ' 条日志', 'data' => ['count' => $count]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 手动刷新运行时缓存
     *
     * @return \think\response\Json
     */
    public function refreshCache()
    {
        try {
            $this->assertSuper();
            (new SecurityService())->refreshCache();

            return json(['code' => 0, 'message' => '规则缓存已刷新', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 仅平台超管可操作
     *
     * @return void
     * @throws BizException
     */
    private function assertSuper(): void
    {
        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            throw new BizException('仅平台超级管理员可操作安全设置');
        }
    }

    /**
     * 当前登录管理员是否为平台超管
     *
     * @return bool
     */
    private function isSuper(): bool
    {
        return AppContext::getAdminRole() === AdminRole::SUPER;
    }
}