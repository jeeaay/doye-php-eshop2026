<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\service\MessageService;
use app\common\support\AppContext;
use think\facade\View;

/**
 * 后台留言管理（平台级）
 *
 * 仅平台超级管理员可访问：查看独立站联系表单留言、标记已读/未读、删除。
 * `site_message` 不区分商户，因此不做 merchant 维度过滤。
 * 控制器只做取值与响应封装，校验与批量口径统一在 {@see MessageService}。
 */
class Messages extends AdminBaseController
{
    /**
     * 留言列表页
     *
     * @return \think\response\View|\think\response\Redirect
     */
    public function index()
    {
        $this->assignActiveMenu('messages');

        if (!$this->isSuper()) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可管理留言');
        }

        $filters = [
            'keyword' => trim((string) $this->request->get('keyword', '')),
            'status'  => $this->request->get('status', ''),
        ];

        $result = (new MessageService())->adminList($filters, (int) $this->request->get('page', 1));

        View::assign('messages', $result['list']);
        View::assign('filters', $filters);
        View::assign('unread', $result['unread']);
        View::assign('messages_link', $result['pager']->render());

        return View::fetch();
    }

    /**
     * 留言详情页（打开即自动置为已读）
     *
     * @return \think\response\View|\think\response\Redirect
     */
    public function detail()
    {
        $this->assignActiveMenu('messages');

        if (!$this->isSuper()) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可管理留言');
        }

        try {
            $message = (new MessageService())->adminDetail((int) $this->request->get('id', 0));
        } catch (BizException $e) {
            return redirect(admin_url('messages'))->with('error', $e->getMessage());
        }

        View::assign('message', $message);

        return View::fetch('messages/detail');
    }

    /**
     * 批量标记留言为已读 / 未读
     *
     * 批量入参统一为 `ids` 数组，单条操作前端也传 `ids=[id]`，只保留一条代码路径。
     *
     * @return \think\response\Json
     */
    public function status()
    {
        try {
            if (!$this->isSuper()) {
                throw new BizException('仅平台超级管理员可管理留言');
            }

            $ids    = (array) $this->request->post('ids', []);
            $status = (int) $this->request->post('status', 1);

            $count = (new MessageService())->setStatus($ids, $status);

            return json([
                'code'    => 0,
                'message' => $status === 1 ? '已标记为已读' : '已标记为未读',
                'data'    => ['count' => $count],
            ]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 批量删除留言
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        try {
            if (!$this->isSuper()) {
                throw new BizException('仅平台超级管理员可管理留言');
            }

            $ids   = (array) $this->request->post('ids', []);
            $count = (new MessageService())->adminDelete($ids);

            return json(['code' => 0, 'message' => '留言已删除', 'data' => ['count' => $count]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 当前登录管理员是否为平台超级管理员
     *
     * @return bool
     */
    private function isSuper(): bool
    {
        return AppContext::getAdminRole() === AdminRole::SUPER;
    }
}
