<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\model\Page;
use app\common\service\MediaUploadService;
use app\common\service\PageService;
use app\common\support\AppContext;
use think\facade\View;

/**
 * 后台单页（CMS）管理控制器
 *
 * 平台级内容，仅平台超级管理员可维护：隐私政策、退换货、关于我们等页面。
 * 列表页 + 独立编辑页（富文本编辑器），写入委托 {@see PageService}。
 */
class Pages extends AdminBaseController
{
    /**
     * 单页列表
     *
     * @return \think\response\View|\think\response\Redirect
     */
    public function index()
    {
        $this->assignActiveMenu('pages');

        if (!$this->isSuper()) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可管理单页');
        }

        $title  = trim((string) $this->request->get('title', ''));
        $status = $this->request->get('status', '');

        $query = Page::order('sort')->order('id', 'desc');
        if ($title !== '') {
            $query->whereLike('title', '%' . $title . '%');
        }
        if ($status !== '' && $status !== null) {
            $query->where('status', (int) $status);
        }

        $pages = $query->paginate(20, false, [
            'query' => ['title' => $title, 'status' => $status],
        ]);

        $list = [];
        foreach ($pages as $page) {
            $list[] = [
                'id'           => (int) $page->id,
                'title'        => (string) $page->title,
                'slug'         => (string) $page->slug,
                'content_type' => (string) $page->content_type,
                'status'       => (int) $page->status,
                'sort'         => (int) $page->sort,
                'update_time'  => (string) $page->update_time,
            ];
        }

        View::assign('pages_list', $list);
        View::assign('filters', ['title' => $title, 'status' => $status]);
        View::assign('pages_link', $pages->render());

        return View::fetch();
    }

    /**
     * 新增 / 编辑单页表单
     *
     * @return \think\response\View|\think\response\Redirect
     */
    public function form()
    {
        $this->assignActiveMenu('pages');

        if (!$this->isSuper()) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可管理单页');
        }

        $service = new PageService();
        $id = (int) $this->request->get('id', 0);
        $page = [
            'id'              => 0,
            'title'           => '',
            'slug'            => '',
            'content_type'    => PageService::TYPE_DATABASE,
            'template_file'   => '',
            'content'         => '',
            'seo_title'       => '',
            'seo_keywords'    => '',
            'seo_description' => '',
            'status'          => 1,
            'sort'            => 0,
        ];

        if ($id > 0) {
            try {
                $page = $service->detail($id);
            } catch (BizException $e) {
                return redirect(admin_url('pages'))->with('error', $e->getMessage());
            }
        }

        View::assign('page', $page);
        View::assign('templates', $service->templateOptions());

        return View::fetch('pages/form');
    }

    /**
     * 保存单页（新增或更新）
     *
     * @return \think\response\Json
     */
    public function save()
    {
        try {
            if (!$this->isSuper()) {
                throw new BizException('仅平台超级管理员可管理单页');
            }

            $id = (int) $this->request->post('id', 0);
            $newId = (new PageService())->saveItem((array) $this->request->post(), $id ?: null);

            return json(['code' => 0, 'message' => '单页已保存', 'data' => ['id' => $newId]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 上线 / 下线单页
     *
     * @return \think\response\Json
     */
    public function status()
    {
        try {
            if (!$this->isSuper()) {
                throw new BizException('仅平台超级管理员可管理单页');
            }

            (new PageService())->toggleItem((int) $this->request->post('id'), (int) $this->request->post('status'));

            return json(['code' => 0, 'message' => '页面状态已更新', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 删除单页
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        try {
            if (!$this->isSuper()) {
                throw new BizException('仅平台超级管理员可管理单页');
            }

            (new PageService())->deleteItem((int) $this->request->post('id'));

            return json(['code' => 0, 'message' => '单页已删除', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 富文本编辑器图片上传（pages 命名空间）
     *
     * @return \think\response\Json
     */
    public function upload()
    {
        try {
            if (!$this->isSuper()) {
                throw new BizException('仅平台超级管理员可管理单页');
            }

            $data = (new MediaUploadService())->upload($this->request->file('file'), 'image', 'pages');

            return json(['code' => 0, 'message' => 'ok', 'data' => $data]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 当前登录账号是否为平台超级管理员
     *
     * @return bool
     */
    private function isSuper(): bool
    {
        return AppContext::getAdminRole() === AdminRole::SUPER;
    }
}
