<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\model\Language;
use app\common\service\LanguageService;
use app\common\service\SettingService;
use app\common\support\AppContext;
use think\facade\View;

/**
 * 多语种设置（平台超管专用）
 *
 * 多语言管理：语种注册表维护（启用/停用、新增、删除）+ i18n 参数设置。
 * 多货币展示设置与汇率管理统一收敛到「货币与汇率」页面。
 */
class Multilang extends AdminBaseController
{
    /**
     * 多语言管理（默认页）
     *
     * @return mixed
     */
    public function index()
    {
        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可管理多语种设置');
        }
        $this->assignActiveMenu('multilang');

        $languages = Language::order('is_default', 'desc')->order('sort')->order('id')->select()->toArray();
        foreach ($languages as &$language) {
            $language['code'] = LanguageService::normalizeCode((string) $language['code']);
        }
        unset($language);

        View::assign([
            'languages'           => $languages,
            'i18n_group'          => (new SettingService())->group('i18n'),
            'language_currencies' => $this->currencyCodes(),
        ]);

        return View::fetch();
    }

    /**
     * 保存多语种相关设置分组（仅允许 i18n）
     *
     * @return \think\response\Json
     */
    public function saveSettings()
    {
        try {
            $this->assertSuper();

            $group  = (string) $this->request->post('group', '');
            $values = (array) $this->request->post('values', []);

            if (!in_array($group, ['i18n'], true)) {
                throw new BizException('不支持保存该设置分组');
            }

            (new SettingService())->save($group, $values);

            return json(['code' => 0, 'message' => '设置已保存', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 新增 / 编辑语种
     *
     * @return \think\response\Json
     */
    public function saveLanguage()
    {
        try {
            $this->assertSuper();

            $id         = (int) $this->request->post('id', 0);
            $code       = LanguageService::normalizeCode((string) $this->request->post('code', ''));
            $name       = trim((string) $this->request->post('name', ''));
            $nativeName = trim((string) $this->request->post('native_name', ''));
            $direction  = (string) $this->request->post('direction', 'ltr');
            $currency   = strtoupper(trim((string) $this->request->post('default_currency', '')));
            $status     = (int) $this->request->post('status', 1) === 1 ? 1 : 0;
            $sort       = (int) $this->request->post('sort', 0);

            if (!preg_match('/^[a-z]{2}(-[a-z]{2,4})?$/', $code)) {
                throw new BizException('语言代码格式不正确，例如 en、zh、pt-br');
            }
            if ($name === '' || $nativeName === '') {
                throw new BizException('请填写语种名称与原生名称');
            }
            if (!in_array($direction, ['ltr', 'rtl'], true)) {
                $direction = 'ltr';
            }
            if ($currency !== '' && !preg_match('/^[A-Z]{3}$/', $currency)) {
                throw new BizException('默认币种请填写 3 位代码，如 USD');
            }

            $exists = Language::where('code', $code)->where('id', '<>', $id)->find();
            if ($exists) {
                throw new BizException('语言代码 ' . $code . ' 已存在');
            }

            if ($id > 0) {
                $row = Language::find($id);
                if (!$row) {
                    throw new BizException('语种不存在或已被删除');
                }
                // 默认语种（模板源语言）不允许停用，保证兜底链路可用
                if ((int) $row->is_default === 1) {
                    $status = 1;
                }
                $row->code             = $code;
                $row->name             = $name;
                $row->native_name      = $nativeName;
                $row->direction        = $direction;
                $row->default_currency = $currency !== '' ? $currency : null;
                $row->status           = $status;
                $row->sort             = $sort;
                $row->save();
            } else {
                $row = new Language();
                $row->code             = $code;
                $row->name             = $name;
                $row->native_name      = $nativeName;
                $row->direction        = $direction;
                $row->default_currency = $currency !== '' ? $currency : null;
                $row->status           = $status;
                $row->is_default       = 0;
                $row->sort             = $sort;
                $row->save();
            }

            (new LanguageService())->flush();

            return json(['code' => 0, 'message' => $id > 0 ? '语种已更新' : '语种已添加', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 设为默认语种（默认语种即模板源语言）
     *
     * @return \think\response\Json
     */
    public function setDefaultLanguage()
    {
        try {
            $this->assertSuper();

            $id = (int) $this->request->post('id', 0);
            $row = Language::find($id);
            if (!$row) {
                throw new BizException('语种不存在或已被删除');
            }
            if ((int) $row->status !== 1) {
                throw new BizException('请先启用该语言，再设为默认');
            }

            Language::where('is_default', 1)->where('id', '<>', $id)->update(['is_default' => 0]);
            $row->is_default = 1;
            $row->save();

            (new LanguageService())->flush();

            return json(['code' => 0, 'message' => '已设为默认语种（模板源语言）', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 启用 / 停用语种
     *
     * @return \think\response\Json
     */
    public function toggleLanguage()
    {
        try {
            $this->assertSuper();

            $id = (int) $this->request->post('id', 0);
            $row = Language::find($id);
            if (!$row) {
                throw new BizException('语种不存在或已被删除');
            }
            if ((int) $row->is_default === 1) {
                throw new BizException('默认语种不可停用');
            }

            $row->status = (int) $row->status === 1 ? 0 : 1;
            $row->save();

            (new LanguageService())->flush();

            return json(['code' => 0, 'message' => $row->status === 1 ? '语种已启用' : '语种已停用', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 删除语种
     *
     * @return \think\response\Json
     */
    public function deleteLanguage()
    {
        try {
            $this->assertSuper();

            $id = (int) $this->request->post('id', 0);
            $row = Language::find($id);
            if (!$row) {
                throw new BizException('语种不存在或已被删除');
            }
            if ((int) $row->is_default === 1) {
                throw new BizException('默认语种不可删除');
            }

            $row->delete();
            (new LanguageService())->flush();

            return json(['code' => 0, 'message' => '语种已删除', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 币种下拉候选（默认币种字段用）
     *
     * @return array<int,string>
     */
    private function currencyCodes(): array
    {
        try {
            $codes = \app\common\model\Currency::order('sort')->order('id')->column('code');
            return array_values(array_unique(array_map('strtoupper', $codes)));
        } catch (\Throwable $e) {
            return ['USD', 'EUR', 'GBP', 'JPY', 'CNY'];
        }
    }

    /**
     * 平台超管校验
     *
     * @return void
     */
    private function assertSuper(): void
    {
        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            throw new BizException('仅平台超级管理员可管理多语种设置');
        }
    }
}
