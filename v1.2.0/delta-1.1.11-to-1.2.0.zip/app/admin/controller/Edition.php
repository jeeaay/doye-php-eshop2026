<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\service\EditionService;
use app\common\support\AppContext;
use think\facade\View;

/**
 * 站点版本（国内版 / 国际版）
 */
class Edition extends AdminBaseController
{
    /**
     * 版本概览
     *
     * @return mixed
     */
    public function index()
    {
        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            return redirect(admin_url('index'))->with('error', '仅平台超管可切换站点版本');
        }
        $this->assignActiveMenu('edition');
        $summary = (new EditionService())->summary();
        View::assign('summary', $summary);
        View::assign('summary_json', json_encode($summary, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT));
        return View::fetch();
    }

    /**
     * 切换版本
     *
     * @return \think\response\Json
     */
    public function switchEdition()
    {
        try {
            $data = $this->request->post();
            $result = (new EditionService())->switchEdition(
                (string) ($data['edition'] ?? ''),
                (int) ($data['confirmed'] ?? 0) === 1,
                (string) ($data['phrase'] ?? '')
            );
            return json(['code' => 0, 'message' => '站点版本已切换', 'data' => $result]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }
}