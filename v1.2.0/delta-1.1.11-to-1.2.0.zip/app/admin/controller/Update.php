<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\service\SettingService;
use app\common\service\UpdateService;
use app\common\support\AppContext;
use think\facade\Log;
use think\facade\View;

/**
 * 系统更新（在线增量升级）
 *
 * 仅平台超级管理员可访问；页面只做展示与交互，全部编排委托 UpdateService，
 * 与 /admin-api/v1/updates/* 共用同一套方法（AGENTS.md 强制成对）。
 *
 * 页面已合并进「系统设置 → 更新设置」标签（/admin/system?tab=update）：
 *   - index()    旧入口 /admin/update 直接跳转到该标签；
 *   - overview() 更新面板首屏数据（版本 / 检查结果 / 历史 / 未完成批次），由标签页按需加载。
 * 动作（/admin/update/*）返回 JSON：{code, message, data}，code === 0 表示成功。
 * 写操作自动进入 admin_audit_log（AdminAudit 中间件已覆盖该路由组），不要手写审计。
 */
class Update extends AdminBaseController
{
    /** 越权提示（页面与 JSON 共用） */
    private const PERMISSION_MESSAGE = '仅平台超级管理员可访问系统更新';

    /** 兜底异常文案：底层细节只进日志，不给运营看堆栈 */
    private const FATAL_MESSAGE = '更新执行失败，请查看操作日志或联系技术支持';

    /** 页面首屏展示的历史条数 */
    private const HISTORY_LIMIT = 5;

    /**
     * 更新设置页面（独立于系统设置）
     *
     * @return \think\response\View
     */
    public function index()
    {
        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            return redirect(admin_url('index'))->with('error', self::PERMISSION_MESSAGE);
        }
        $this->assignActiveMenu('update');

        // 复用 setting/index.html 传递的版本信息（用于首屏展示）
        $version = null;
        try {
            $version = (new UpdateService())->currentVersion();
        } catch (\Throwable $e) {
            Log::error('[update] 读取当前版本失败：' . $e->getMessage());
        }

        $currentVersion = $version['version'] ?? '';
        View::assign([
            'update_current_version' => $currentVersion,
            'update_group'           => (new SettingService())->group('update'),
            'update_released_at'     => $version['released_at'] ?? '',
            'update_db_version'      => $version['db_version'] ?? '',
            'update_php_min'         => $version['php_min'] ?? '',
        ]);

        return View::fetch();
    }

    /**
     * 更新面板首屏数据（设置页切换到「更新设置」标签时按需拉取）
     *
     * @return \think\response\Json
     */
    public function overview()
    {
        return $this->guardedJson(function (): array {
            $service = new UpdateService();

            $version = null;
            try {
                $version = $service->currentVersion();
            } catch (\Throwable $e) {
                Log::error('[update] 读取当前版本失败：' . $e->getMessage());
            }

            $check = $this->safeCheck($service);

            try {
                $history = $service->history(1, self::HISTORY_LIMIT);
            } catch (\Throwable $e) {
                Log::error('[update] 读取更新历史失败：' . $e->getMessage());
                $history = ['list' => [], 'total' => 0, 'page' => 1, 'page_size' => self::HISTORY_LIMIT];
            }

            return [
                'version'    => $version,
                'check'      => $check,
                'history'    => $history,
                'unfinished' => $this->findUnfinished((array) ($history['list'] ?? [])),
            ];
        });
    }

    /**
     * 检查更新（强制回源）
     *
     * @return \think\response\Json
     */
    public function check()
    {
        return $this->guardedJson(static function (): array {
            return (new UpdateService())->check(true);
        });
    }

    /**
     * 规划升级（只读校验 + 建批次）
     *
     * @return \think\response\Json
     */
    public function plan()
    {
        return $this->guardedJson(static function (): array {
            return (new UpdateService())->plan();
        });
    }

    /**
     * 执行下一步
     *
     * @return \think\response\Json
     */
    public function step()
    {
        return $this->guardedJson(function (): array {
            return (new UpdateService())->runNextStep($this->batchId());
        });
    }

    /**
     * 重试当前失败/中断步骤
     *
     * @return \think\response\Json
     */
    public function retry()
    {
        return $this->guardedJson(function (): array {
            return (new UpdateService())->retry($this->batchId());
        });
    }

    /**
     * 整批回滚
     *
     * @return \think\response\Json
     */
    public function rollback()
    {
        return $this->guardedJson(function (): array {
            $result = (new UpdateService())->rollback($this->batchId());
            // 状态语义与 design.md §3.4 对齐：前端只认 status 字段
            $result['status'] = 'rolled_back';
            return $result;
        });
    }

    /**
     * 更新历史（分页）
     *
     * @return \think\response\Json
     */
    public function history()
    {
        return $this->guardedJson(function (): array {
            $page = max(1, (int) $this->request->param('page', 1));
            $size = (int) $this->request->param('page_size', 10);
            if ($size <= 0) {
                $size = 10;
            }
            return (new UpdateService())->history($page, min($size, 100));
        });
    }

    /**
     * 批次明细（含步骤列表）
     *
     * @return \think\response\Json
     */
    public function detail()
    {
        return $this->guardedJson(function (): array {
            return (new UpdateService())->batchDetail($this->batchId());
        });
    }

    // ==================================================================
    // 内部工具
    // ==================================================================

    /**
     * 统一执行 JSON 动作：超管校验 + 异常收敛
     *
     * @param callable $fn 业务闭包
     * @return \think\response\Json
     */
    private function guardedJson(callable $fn)
    {
        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            return json(['code' => 1, 'message' => self::PERMISSION_MESSAGE, 'data' => null]);
        }

        try {
            return json(['code' => 0, 'message' => 'ok', 'data' => $fn()]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        } catch (\Throwable $e) {
            Log::error('[update] ' . self::FATAL_MESSAGE . '：' . $e->getMessage() . "\n" . $e->getTraceAsString());
            return json(['code' => 1, 'message' => self::FATAL_MESSAGE, 'data' => null]);
        }
    }

    /**
     * 读取批次号（JSON body / 表单 / query 均支持）
     *
     * @return int
     * @throws BizException
     */
    private function batchId(): int
    {
        $id = (int) $this->request->post('batch_id', 0);
        if ($id <= 0) {
            $id = (int) $this->request->param('batch_id', 0);
        }
        if ($id <= 0) {
            throw new BizException('缺少参数 batch_id');
        }
        return $id;
    }

    /**
     * 检查更新（页面首屏用，任何异常都降级成可展示结果）
     *
     * @return array<string,mixed>
     */
    private function safeCheck(UpdateService $service): array
    {
        try {
            return $service->check(false);
        } catch (\Throwable $e) {
            Log::error('[update] 检查更新失败：' . $e->getMessage());

            return [
                'current'          => '',
                'latest'           => '',
                'update_available' => false,
                'php_ok'           => true,
                'total_size'       => 0,
                'steps'            => [],
                'source'           => null,
                'checked_at'       => date('Y-m-d H:i:s'),
                'blocked_reason'   => 'error',
                'message'          => self::FATAL_MESSAGE,
            ];
        }
    }

    /**
     * 从最近历史里找未完成的批次（planned / running / failed）
     *
     * @param array<int,array<string,mixed>> $list
     * @return array<string,mixed>|null
     */
    private function findUnfinished(array $list): ?array
    {
        foreach ($list as $row) {
            $status = (string) ($row['status'] ?? '');
            if (in_array($status, ['planned', 'running', 'failed'], true)) {
                return $row;
            }
        }
        return null;
    }
}
