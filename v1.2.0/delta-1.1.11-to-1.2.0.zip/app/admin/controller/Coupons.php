<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\service\CouponService;
use app\common\support\AppContext;
use think\facade\View;

/**
 * 后台优惠管理（平台级）
 *
 * 仅平台超级管理员可访问：全站自动优惠、无门槛券、满减券、指定商品券、优惠码券。
 * 优惠面向全站发放，不区分商户，因此不做 merchant 维度过滤。
 */
class Coupons extends AdminBaseController
{
    /**
     * 优惠列表页
     *
     * @return \think\response\View|\think\response\Redirect
     */
    public function index()
    {
        $this->assignActiveMenu('coupons');

        if (!$this->isSuper()) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可管理优惠');
        }

        $filters = [
            'keyword'    => trim((string) $this->request->get('keyword', '')),
            'apply_type' => (string) $this->request->get('apply_type', ''),
            'status'     => $this->request->get('status', ''),
        ];

        $result = (new CouponService())->adminList($filters, (int) $this->request->get('page', 1));

        View::assign('coupons', $result['list']);
        View::assign('filters', $filters);
        View::assign('coupons_link', $result['pager']->render());
        return View::fetch();
    }

    /**
     * 新增 / 编辑优惠表单
     *
     * @return \think\response\View|\think\response\Redirect
     */
    public function form()
    {
        $this->assignActiveMenu('coupons');

        if (!$this->isSuper()) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可管理优惠');
        }

        $service = new CouponService();
        $id = (int) $this->request->get('id', 0);

        $coupon = [
            'id'             => 0,
            'name'           => '',
            'code'           => '',
            'apply_type'     => 'claim',
            'discount_type'  => 'fixed',
            'discount_value' => '5.00',
            'min_amount'     => '0.00',
            'max_discount'   => '0.00',
            'scope'          => 'all',
            'total_qty'      => 0,
            'per_user_limit' => 1,
            'valid_days'     => 0,
            'start_time'     => '',
            'end_time'       => '',
            'status'         => 1,
            'sort'           => 0,
            'remark'         => '',
            'product_ids'    => [],
        ];

        if ($id > 0) {
            try {
                $coupon = (new CouponService())->adminDetail($id);
            } catch (BizException $e) {
                return redirect(admin_url('coupons'))->with('error', $e->getMessage());
            }
        }

        View::assign('coupon', $coupon);
        View::assign('coupon_json', json_encode($coupon, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT));
        View::assign('products_json', json_encode($service->productOptions(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT));
        return View::fetch('coupons/form');
    }

    /**
     * 保存优惠（新增 / 更新）
     *
     * @return \think\response\Json
     */
    public function save()
    {
        try {
            if (!$this->isSuper()) {
                throw new BizException('仅平台超级管理员可管理优惠');
            }
            $data = $this->request->post();
            $id = !empty($data['id']) ? (int) $data['id'] : null;
            $couponId = (new CouponService())->adminSave($data, $id);
            return json(['code' => 0, 'message' => '优惠已保存', 'data' => ['id' => $couponId]]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 启用 / 停用优惠
     *
     * @return \think\response\Json
     */
    public function status()
    {
        try {
            if (!$this->isSuper()) {
                throw new BizException('仅平台超级管理员可管理优惠');
            }
            (new CouponService())->adminToggle(
                (int) $this->request->post('id', 0),
                (int) $this->request->post('status', 1)
            );
            return json(['code' => 0, 'message' => '优惠状态已更新', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 删除优惠
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        try {
            if (!$this->isSuper()) {
                throw new BizException('仅平台超级管理员可管理优惠');
            }
            (new CouponService())->adminDelete((int) $this->request->post('id', 0));
            return json(['code' => 0, 'message' => '优惠已删除', 'data' => null]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 当前登录管理员是否为平台超级管理员
     *
     * @return bool
     */
    private function isSuper(): bool
    {
        return AppContext::getAdminRole() === AdminRole::SUPER;
    }
}
