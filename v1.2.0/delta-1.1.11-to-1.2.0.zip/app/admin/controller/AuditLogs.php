<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\service\AuditLogService;
use app\common\support\AppContext;
use think\facade\View;

/**
 * 后台操作日志
 *
 * 仅平台超级管理员可查看与清理。
 */
class AuditLogs extends AdminBaseController
{
    /**
     * 日志列表
     *
     * @return mixed
     */
    public function index()
    {
        $this->assignActiveMenu('audit-logs');

        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            return redirect(admin_url('index'))->with('error', '仅平台超级管理员可查看操作日志');
        }

        $filters = [
            'admin'  => trim((string) $this->request->get('admin', '')),
            'module' => trim((string) $this->request->get('module', '')),
            'action' => trim((string) $this->request->get('action', '')),
            'source' => trim((string) $this->request->get('source', '')),
            'result' => trim((string) $this->request->get('result', '')),
            'from'   => trim((string) $this->request->get('from', '')),
            'to'     => trim((string) $this->request->get('to', '')),
        ];

        $page = max(1, (int) $this->request->get('page', 1));
        $result = (new AuditLogService())->paginate($filters, $page, 20);

        View::assign('logs', $result['list']);
        View::assign('pages', $result['pager']->render());
        View::assign('total', $result['total']);
        View::assign('filters', $filters);
        View::assign('stats', (new AuditLogService())->stats());
        View::assign('module_options', (array) config('audit.modules', []));
        View::assign('action_options', (array) config('audit.actions', []));

        return View::fetch();
    }

    /**
     * 清理日志
     *
     * @return \think\response\Json
     */
    public function purge()
    {
        try {
            if (AppContext::getAdminRole() !== AdminRole::SUPER) {
                throw new BizException('仅平台超级管理员可清理日志');
            }
            if ((string) $this->request->post('confirm', '') !== '1') {
                throw new BizException('请确认清理操作');
            }

            $days = (int) $this->request->post('days', 0);
            $deleted = (new AuditLogService())->purge($days);

            return json([
                'code'    => 0,
                'message' => '已清理 ' . $deleted . ' 条日志',
                'data'    => ['days' => $days, 'deleted' => $deleted],
            ]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }
}