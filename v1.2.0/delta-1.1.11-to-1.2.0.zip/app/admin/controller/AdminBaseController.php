<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\BaseAdminController;
use app\common\enum\AdminRole;
use app\common\support\AdminMenu;
use think\facade\Session;
use think\facade\View;

class AdminBaseController extends BaseAdminController
{
    protected function initialize()
    {
        parent::initialize();
        $admin = Session::get('admin');
        $role  = (string) ($admin['role'] ?? AdminRole::STAFF);

        View::assign('admin_base', admin_base());
        View::assign('admin_username', $admin['username'] ?? 'Admin');
        View::assign('admin_title', $this->adminTitle($role));
        View::assign('admin_role', $role);
        View::assign('active_menu', '');
        View::assign('admin_menu', AdminMenu::tree($role, ''));
        View::assign('active_group', '');
        View::assign('active_sub', '');
        View::assign('page_breadcrumb', ['group' => '', 'item' => '']);
    }

    /**
     * 标记当前页面：同时刷新菜单高亮、展开分组与顶部面包屑
     *
     * @param string $menu 页面标识（与 config/admin_menu.php 的 active 对应）
     * @return void
     */
    protected function assignActiveMenu(string $menu): void
    {
        $admin = Session::get('admin');
        $role  = (string) ($admin['role'] ?? AdminRole::STAFF);

        View::assign('active_menu', $menu);
        View::assign('admin_menu', AdminMenu::tree($role, $menu));
        View::assign('active_group', AdminMenu::activeGroup($menu));
        View::assign('active_sub', AdminMenu::activeSub($menu));
        View::assign('page_breadcrumb', AdminMenu::breadcrumb($menu));
    }

    private function adminTitle(string $role): string
    {
        if ($role === AdminRole::SUPER) {
            return 'Platform Super Admin';
        }
        return '商户管理后台';
    }
}