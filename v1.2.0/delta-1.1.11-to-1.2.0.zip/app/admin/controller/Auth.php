<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\enum\AdminRole;
use app\common\lib\RedisCache;
use app\common\middleware\AdminAuth;
use app\common\model\Admin;
use app\common\service\AuditLogService;
use think\facade\Db;
use think\facade\Session;
use think\facade\View;

class Auth extends AdminBaseController
{
    /** 同一 IP + 账号连续失败上限 */
    private const LOGIN_MAX_ATTEMPTS = 5;
    /** 同一 IP 失败上限（防撞库） */
    private const LOGIN_IP_MAX_ATTEMPTS = 30;
    /** 失败统计与锁定时长（秒） */
    private const LOGIN_DECAY_SECONDS = 900;

    public function loginForm()
    {
        if (Session::has('admin')) {
            return redirect(admin_url('index'));
        }
        View::assign('error', '');
        return View::fetch('auth/login');
    }

    public function login()
    {
        $username = (string)$this->request->post('username', '');
        $password = (string)$this->request->post('password', '');

        if (!$username || !$password) {
            View::assign('error', '请输入账号和密码');
            return View::fetch('auth/login');
        }

        $ip      = client_ip() ?: (string) $this->request->ip();
        $userKey = $this->failureKey($ip, $username);
        $ipKey   = $this->failureKey($ip, '');

        $lockedSeconds = max(
            $this->lockSeconds($userKey, self::LOGIN_MAX_ATTEMPTS),
            $this->lockSeconds($ipKey, self::LOGIN_IP_MAX_ATTEMPTS)
        );
        if ($lockedSeconds > 0) {
            View::assign('error', '尝试次数过多，请 ' . max(1, (int) ceil($lockedSeconds / 60)) . ' 分钟后再试');
            return View::fetch('auth/login');
        }

        $admin = Admin::where('username', $username)->find();
        if (!$admin) {
            $this->recordLoginFailure($userKey, $ipKey);
            $this->auditLogin($username, null, '账号或密码错误');
            View::assign('error', '账号或密码错误');
            return View::fetch('auth/login');
        }

        if ((int) $admin->status !== 1) {
            $this->recordLoginFailure($userKey, $ipKey);
            $this->auditLogin($username, $admin, '账号已禁用');
            View::assign('error', '账号或密码错误');
            return View::fetch('auth/login');
        }

        if (!password_verify($password, (string) $admin->password_hash)) {
            $this->recordLoginFailure($userKey, $ipKey);
            $this->auditLogin($username, $admin, '账号或密码错误');
            View::assign('error', '账号或密码错误');
            return View::fetch('auth/login');
        }

        $merchantIds = $admin->role === AdminRole::SUPER
            ? []
            : array_map('intval', Db::table('admin_merchant')->where('admin_id', $admin->id)->column('merchant_id'));

        Session::set('admin', [
            'id'           => (int)$admin->id,
            'username'     => $admin->username,
            'role'         => $admin->role,
            'merchant_ids' => $merchantIds,
            'expire_at'    => time() + (int)config('session.expire', 2592000),
        ]);

        // 清空该账号的失败计数，并更换 Session ID 防止会话固定
        $this->clearFailure($userKey);
        Session::regenerate();

        $this->auditLogin($admin->username, $admin, null);

        return redirect(admin_url('index'));
    }

    public function logout()
    {
        $admin = Session::get('admin');
        if (is_array($admin)) {
            (new AuditLogService())->record([
                'admin_id'       => (int) ($admin['id'] ?? 0) ?: null,
                'admin_username' => (string) ($admin['username'] ?? ''),
                'role'           => $admin['role'] ?? null,
                'auth_source'    => 'session',
                'module'         => 'auth',
                'action'         => 'logout',
                'method'         => 'POST',
                'path'           => admin_url('logout'),
                'summary'        => '管理员登出',
                'detail'         => ['username' => (string) ($admin['username'] ?? '')],
                'ip'             => client_ip() ?: (string) $this->request->ip(),
                'user_agent'     => (string) $this->request->header('user-agent', ''),
                'http_status'    => 200,
                'result_code'    => 0,
            ]);
        }

        Session::clear();
        return redirect(admin_url('login'));
    }

    /**
     * 失败计数键：账号维度带用户名，IP 维度传空用户名
     */
    private function failureKey(string $ip, string $username): string
    {
        return 'admin-login-fail:' . md5($ip . '|' . strtolower($username));
    }

    private function sessionFailureKey(string $key): string
    {
        return 'login_' . $key;
    }

    private function failureCount(string $key): int
    {
        try {
            $raw = RedisCache::client()->get($key);
            return $raw === null ? 0 : (int) $raw;
        } catch (\Throwable $e) {
            $state = Session::get($this->sessionFailureKey($key));
            return is_array($state) ? (int) ($state['count'] ?? 0) : 0;
        }
    }

    /**
     * 剩余锁定秒数；未达到上限时返回 0
     */
    private function lockSeconds(string $key, int $maxAttempts): int
    {
        if ($this->failureCount($key) < $maxAttempts) {
            return 0;
        }

        try {
            $ttl = RedisCache::ttl($key);
            return $ttl > 0 ? $ttl : self::LOGIN_DECAY_SECONDS;
        } catch (\Throwable $e) {
            $state = Session::get($this->sessionFailureKey($key));
            $until = is_array($state) ? (int) ($state['until'] ?? 0) : 0;
            return $until > time() ? $until - time() : 0;
        }
    }

    private function recordLoginFailure(string $userKey, string $ipKey): void
    {
        $this->recordFailure($userKey);
        $this->recordFailure($ipKey);
    }

    private function recordFailure(string $key): void
    {
        try {
            $count = RedisCache::inc($key);
            if ($count === 1) {
                RedisCache::expire($key, self::LOGIN_DECAY_SECONDS);
            }
            return;
        } catch (\Throwable $e) {
            // Redis 不可用时降级为会话计数，避免登录功能整体不可用
        }

        $sessionKey = $this->sessionFailureKey($key);
        $state      = Session::get($sessionKey);
        $count      = is_array($state) ? (int) ($state['count'] ?? 0) + 1 : 1;
        Session::set($sessionKey, [
            'count' => $count,
            'until' => time() + self::LOGIN_DECAY_SECONDS,
        ]);
    }

    private function clearFailure(string $key): void
    {
        try {
            RedisCache::del($key);
        } catch (\Throwable $e) {
            // 忽略：计数会在窗口结束后自然过期
        }
        Session::delete($this->sessionFailureKey($key));
    }

    /**
     * 记录登录事件
     *
     * @param string      $username   尝试登录的用户名
     * @param Admin|null  $admin      匹配到的账号（失败时可能为空）
     * @param string|null $error      失败原因；null 表示成功
     * @return void
     */
    private function auditLogin(string $username, ?Admin $admin, ?string $error): void
    {
        $success = $error === null;
        (new AuditLogService())->record([
            'admin_id'       => $admin ? (int) $admin->id : null,
            'admin_username' => $username,
            'role'           => $admin?->role,
            'auth_source'    => 'login',
            'module'         => 'auth',
            'action'         => 'login',
            'method'         => 'POST',
            'path'           => admin_url('login'),
            'summary'        => $success ? '登录成功' : '登录失败：' . $error,
            'detail'         => ['username' => $username],
            'ip'             => client_ip() ?: (string) $this->request->ip(),
            'user_agent'     => (string) $this->request->header('user-agent', ''),
            'http_status'    => 200,
            'result_code'    => $success ? 0 : 1,
            'error_message'  => $success ? '' : (string) $error,
        ]);
    }
}
