<?php

namespace app\common\middleware;

use app\common\support\AppContext;
use think\facade\Config;
use think\facade\Session;
use think\Request;

class AdminAuth
{
    public function handle(Request $request, \Closure $next)
    {
        $admin = Session::get('admin');
        if (empty($admin) || empty($admin['id'])) {
            return $this->deny($request);
        }

        $now      = time();
        $expireAt = (int)($admin['expire_at'] ?? 0);

        // 已超过有效期，强制登出
        if ($expireAt > 0 && $now >= $expireAt) {
            Session::delete('admin');
            return $this->deny($request);
        }

        // 剩余有效期不足15天时自动续期至30天（旧会话无 expire_at 时立即补齐）
        $renewThreshold = (int)Config::get('session.admin_renew_threshold', 1296000);
        if ($expireAt === 0 || $expireAt - $now < $renewThreshold) {
            $admin['expire_at'] = $now + (int)Config::get('session.expire', 2592000);
            Session::set('admin', $admin);
        }

        AppContext::setAdminId((int) ($admin['id'] ?? 0) ?: null);
        AppContext::setAdminRole($admin['role'] ?? null);
        AppContext::setMerchantIds($admin['merchant_ids'] ?? []);
        AppContext::setAuthSource('session');
        AppContext::setApiKeyId(null);
        AppContext::setAdminUsername((string) ($admin['username'] ?? ''));
        return $next($request);
    }

    protected function deny(Request $request)
    {
        if ($request->isAjax()) {
            return json(['code' => 401, 'message' => '未登录', 'data' => null], 401);
        }
        return redirect(admin_url('login'));
    }
}
