<?php
declare(strict_types=1);

namespace app\common\middleware;

use Closure;
use think\Request;
use think\Response;

/**
 * 后台旧入口拦截
 *
 * 后台入口前缀由 .env 的 ADMIN_PATH 决定（默认 console）。
 * 当入口不是 admin 时，直接访问 /admin 一律返回 404，不进入多应用解析，
 * 避免暴露「app not exists」之类的错误信息。
 */
class AdminEntryGuard
{
    public function handle(Request $request, Closure $next): Response
    {
        $path  = ltrim($request->pathinfo(), '/');
        $first = strtolower((string) current(explode('/', $path)));

        if ($first === 'admin' && strtolower(admin_path()) !== 'admin') {
            return response('Not Found', 404)->contentType('text/html');
        }

        return $next($request);
    }
}
