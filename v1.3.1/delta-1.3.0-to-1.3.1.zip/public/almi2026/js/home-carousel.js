/*
 * 首页轻量轮播：自动播放 + 圆点指示器，零依赖。
 *
 * 标记约定（幻灯片必须是 [data-carousel] 的直接子元素）：
 *   <div data-carousel data-carousel-interval="6000">
 *     <div data-carousel-slide>...</div>   x N
 *     <div data-carousel-dots></div>       圆点按钮由本脚本注入
 *   </div>
 * 少于 2 张时不注入圆点、不起定时器，仅把唯一一张标为当前，保持静态首屏表现。
 */
(function () {
  var DEFAULT_INTERVAL = 5000;

  function slidesOf(root) {
    var list = [];
    for (var i = 0; i < root.children.length; i++) {
      if (root.children[i].hasAttribute('data-carousel-slide')) { list.push(root.children[i]); }
    }
    return list;
  }

  function initCarousel(root) {
    if (root.hasAttribute('data-carousel-ready')) { return; }
    root.setAttribute('data-carousel-ready', '1');

    var slides = slidesOf(root);
    if (slides.length < 2) {
      // 单张也要标记为当前：隐藏规则由 html.js-carousel 生效，不补这一步会把唯一一张图压成空白
      for (var s = 0; s < slides.length; s++) {
        slides[s].classList.add('is-active');
        slides[s].setAttribute('aria-hidden', 'false');
      }
      return;
    }

    var interval = parseInt(root.getAttribute('data-carousel-interval'), 10);
    if (!interval || interval < 1000) { interval = DEFAULT_INTERVAL; }

    var dotsHost = root.querySelector('[data-carousel-dots]');
    var dots = [];
    var index = 0;
    var timer = null;
    var paused = false; // 悬停/聚焦期间切走标签页再切回时，不应恢复自动播放

    if (dotsHost) {
      for (var n = 0; n < slides.length; n++) {
        var dot = document.createElement('button');
        dot.type = 'button';
        dot.className = 'h-carousel__dot';
        dot.setAttribute('data-carousel-dot', String(n));
        dot.setAttribute('aria-label', 'Show image ' + (n + 1));
        dotsHost.appendChild(dot);
        dots.push(dot);
      }
    }

    function paint() {
      for (var i = 0; i < slides.length; i++) {
        slides[i].classList.toggle('is-active', i === index);
        slides[i].setAttribute('aria-hidden', i === index ? 'false' : 'true');
      }
      for (var j = 0; j < dots.length; j++) {
        dots[j].classList.toggle('is-active', j === index);
        if (j === index) { dots[j].setAttribute('aria-current', 'true'); } else { dots[j].removeAttribute('aria-current'); }
      }
    }

    function stop() {
      if (timer) { clearInterval(timer); timer = null; }
    }

    function start() {
      stop();
      // 自动轮播属于非必要动效，尊重系统的减弱动效偏好，只保留手动切换
      if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) { return; }
      timer = setInterval(function () { index = (index + 1) % slides.length; paint(); }, interval);
    }

    root.addEventListener('pointerenter', function () { paused = true; stop(); });
    root.addEventListener('pointerleave', function () { paused = false; start(); });
    root.addEventListener('focusin', function () { paused = true; stop(); });
    root.addEventListener('focusout', function (e) {
      if (!root.contains(e.relatedTarget)) { paused = false; start(); }
    });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) { stop(); } else if (!paused) { start(); }
    });

    if (dotsHost) {
      dotsHost.addEventListener('click', function (e) {
        var btn = e.target.closest ? e.target.closest('[data-carousel-dot]') : null;
        if (!btn) { return; }
        index = parseInt(btn.getAttribute('data-carousel-dot'), 10) || 0;
        paint();
        // 点圆点时指针通常还停在区域内，处于 paused 就别把自动播放重新拉起来
        if (!paused) { start(); }
      });
    }

    paint();
    start();
  }

  function init() {
    // CSS 里的隐藏规则只在 html.js-carousel 下生效：脚本失效时首屏仍是完整可见的静态图
    document.documentElement.classList.add('js-carousel');
    var roots = document.querySelectorAll('[data-carousel]');
    for (var i = 0; i < roots.length; i++) { initCarousel(roots[i]); }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
