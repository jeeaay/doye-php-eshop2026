# 前台模板内联样式治理计划（templates/almi2026）

> 目标：把 `templates/almi2026/*.html` 里"本可以写进样式表"的内联样式迁到
> `public/almi2026/css/**`；只保留必须由 JS / Alpine 在运行时决定的属性。
> 本文所有数字来自 2026-11-18 的实测扫描（脚本见文末附录）。

## 0. 执行结果（2026-11-18 已完成）

| 指标 | 治理前 | 治理后 |
|---|---:|---:|
| 内联 `style="…"` | 289 | **8**（全部是 JS/Alpine 控制的 `display:none`） |
| 模板内 `<style>` 块 | 4 | **0** |
| 被引用但缺失的页面 CSS | 9 | **0** |
| 死模板 | 4 | 0（已删除） |

**保留下来的 8 处**（均为运行时状态，无法静态化）：

- `cart.html` ×4：`#empty-cart` 与 3 个折扣行，由 `cart.js` 直接读写 `el.style.display`；
- `checkout.html` ×3：`#coupon-discount-row`、`#cart-local-row` 与一个默认隐藏行，同上；
- `login.html` ×1：验证码步骤的 `style="display:none"`，防 Alpine 初始化前闪现。

**落地文件**

- 新增公共片段：`templates/almi2026/inc/benefits.html`（替换 11 个页面里复制的福利横幅）
- 新增页面样式：`public/almi2026/css/pages/{account,cart,checkout,login,contact,page,order-success,service,about}.css`
- 补充全局样式：`public/almi2026/css/site-addons.css`（页头/页脚/语言切换器/locale 提示/RTL 覆盖）
- 追加页面样式：`pages/homepage.css`、`pages/product-detail.css`
- 审计工具：`tools/audit-inline-styles.mjs`（`node tools/audit-inline-styles.mjs`）

**零视觉差异怎么验的**：用 `git worktree` 拉一份 HEAD 版本跑在 8011，与改造后（8010）
逐页比对**每个元素的 40 项计算样式**（display/尺寸/内外边距/字号/颜色/边框/圆角/flex/grid 等）：

- 桌面 1440：19 个路由（首页、列表、详情、购物车、结算、登录、8 个账户页、关于、服务、联系、
  内容页、下单成功）
- 移动 390（iframe 视口）：首页、购物车、结算、登录、账户、联系、商品详情

结果：除 URL origin 不同外 **0 差异**。为达成这一点，额外做了 3 处"权重校正"（见 §4.1）。

**顺手修掉的 4 个连带问题**

1. `error.html` 引用不存在的 `/tape2026/`（CSS + 背景图 404）→ 改用主题资源，去掉死链；
2. `account-orders.html` / `account_order_detail.html` 把 `{:template_asset(...)}` 写在 `{literal}` 里
   （订单无图时会输出字面量字符串当图片地址）→ 改为 `data-fallback-img` + JS 读取；
3. `cart.html`、`contact.html`、`order_success.html` 在 `page_script` 里多写了 `</html>` → 删除；
4. 补建 9 个"模板已引用、文件不存在"的页面 CSS（此前每次访问都 404）。

**未做（属于设计任务，不在"搬位置"范围）**

- `service.html` 的 `service-card__*`、`account-content`、`cart-sidebar`、`product-detail-page`
  等类至今没有任何 CSS（页面这些区域本来就没有样式），补全设计另开任务；
- `cart.html` "Everyone is buying it…" 推荐区是硬编码 demo（外链图片 + `/product-detail` 死链），
  现已用 `{if condition="0"}` 关闭渲染，接真实推荐接口后改回 `condition="1"` 即可；
- `app.sass` 仍缺 10 个 `pages/*.sass` 分片，构建链未恢复。

---

## 1. 现状扫描结果

---

## 1. 现状扫描结果

| 指标 | 数值 |
|---|---|
| 内联 `style="…"` 属性 | **289 处**（24 个模板文件，141 种不同声明） |
| `<style>` 块 | **4 个**：`layout/base.html` ×2、`product.html` ×1、`contact.html` ×1 |
| JS 里硬编码的 `style="…"` | **0**（`public/almi2026/js/*.js` 只有 `.style.display` 切换） |
| 在用模板（controller 会 render 的） | 20 个，占 **271 处** |
| 死模板（无任何引用） | 4 个，占 **18 处** |

### 1.1 在用模板内联数量分布（按治理收益排序）

| 模板 | 内联 | 目标样式文件 |
|---|---:|---|
| `checkout.html` | 50 | `css/pages/checkout.css`（新建） |
| `cart.html` | 33 | `css/pages/cart.css`（新建） |
| `account-wishlist.html` | 25 | `css/pages/account.css`（新建） |
| `layout/base.html` | 21 + 2 个 `<style>` | `css/site-addons.css` |
| `login.html` | 21 | `css/pages/login.css`（新建） |
| `account-logout.html` | 19 | `css/pages/account.css` |
| `account-overview.html` | 15 | `css/pages/account.css` |
| `service.html` | 14 | `css/pages/service.css`（新建） |
| `account-coupons.html` | 13 | `css/pages/account.css` |
| `index.html` | 12 | `css/pages/homepage.css` |
| `account_order_detail.html` | 9 | `css/pages/account.css` |
| `product.html` | 9 + 1 个 `<style>` | `css/pages/product-detail.css` |
| `contact.html` | 6 + `<style>` 5 条 | `css/pages/contact.css`（新建） |
| `account-orders.html` | 5 | `css/pages/account.css` |
| `page.html` | 5 | `css/pages/page.css`（新建，需补 `extra_css`） |
| `account-rewards.html` | 4 | `css/pages/account.css` |
| `products.html` | 4 | `css/pages/product-list.css` |
| `order_success.html` | 3 | `css/pages/order-success.css`（新建） |
| `error.html` | 2 | `css/pages/page.css`（与 `page.html` 共用 hero） |
| `account-addresses.html` | 1 | `css/pages/account.css` |

### 1.2 重复度最高的声明（说明这是复制粘贴债，不是个别特例）

| 出现次数 | 声明 | 分布 |
|---:|---|---|
| 28 | `flex:1;min-width:200px;padding:20px` | 7 个模板的同一段"福利横幅" |
| 28 | `filter:brightness(0.35);margin:0 auto 16px` | 同上 |
| 28 | `font-size:.875rem;font-weight:600` | 同上 |
| 7 | `display:flex;justify-content:space-between;flex-wrap:wrap;text-align:center` | 同上（4 项的外层网格） |
| 6 | `margin-top:80px;border-top:1px solid rgba(0,0,0,.05);padding-bottom:0` | 同上（外层 section） |
| 16 | `filter:brightness(0.35)` | `index` / `login` / `product` / `products` 的图片灰化 |
| 8 | `max-width:1000px`（两种写法） | 8 个账户页的内容容器 |

> 结论：**112 处（约 41%）来自同一段福利横幅被复制了 7 份**。

### 1.3 扫描发现的 4 个连带问题（顺手一起修，否则迁完样式页面仍是坏的）

1. **9 个页面样式文件被引用但不存在**（线上每次访问都 404）：
   `about.css`、`account.css`、`cart.css`、`checkout.css`、`contact.css`、`login.css`、`order-success.css`、`service.css`、`page.css`。
   模板里 `<link>` 已经写好了，只是文件从来没建 —— 这就是内联样式泛滥的根因。
2. **`app.sass` 的构建链已断**：`@use "pages/login"`、`pages/account`、`pages/cart`… 共 10 个 sass 分片都不存在，
   现在无法重新编译 `app.css`。→ 本次**不改** `app.css` / `common.css` / `promo.css`（有 sass 源，改了会被下次编译覆盖）。
3. **`error.html` 指向不存在的主题**：`/tape2026/css/app.css`、`/tape2026/img/inside-banner.jpg` 全部 404，
   且 `.article-hero`、`.hero-title`、`.hero-desc` 在任何 CSS 里都没有定义（404 页目前是无样式的）。
4. **大量模板 class 没有任何对应 CSS**（`account-content`、`service-card__highlight`、`cart-sidebar`、
   `empty-cart`、`product-detail-page`、`contact-form__desc`、`article-hero`、`cms-content`…），
   这正是"只能靠内联补样式"的原因，补页面 CSS 时一并落地。

---

## 2. 治理规则（先定规则，再动手）

### 2.1 样式放哪

| 类型 | 落地位置 | 理由 |
|---|---|---|
| 单页专用 | `public/almi2026/css/pages/{page}.css` | 模板已引用，按需加载，不污染全站 |
| ≥3 页复用（页头/页脚/福利带/通用小组件） | `public/almi2026/css/site-addons.css` | 手写纯 CSS、无 sass 源、已全局加载 |
| 窄屏覆盖 | `public/almi2026/css/mobile.css` | 项目约定（`@media (max-width:767.98px)`） |
| 禁止 | `app.css` / `common.css` / `promo.css` | 有 sass 源且 `app.sass` 已断，手改会被覆盖 |

- 页面 CSS 的选择器**必须用页面根类收敛**：`.cart-page …`、`.checkout-page …`、`.account-page …`、`.service-page …`；
  不要写裸标签选择器（如 `input{...}`），避免影响全站。
- 图片/背景资源在 CSS 里用**相对路径**：`url('../img/login-bg.jpg')`。
  不要在 CSS 里写死 `/almi2026/...`（`template_asset()` 依赖 `site.template`，换主题会崩）。
- 模板里的 `<style>` 迁走后**不再需要 `{literal}`**；万一必须保留，仍须 `{literal}…{/literal}`。

### 2.2 什么允许继续内联（约 10~15 处）

| 场景 | 处理 |
|---|---|
| JS 用 `el.style.display` 控显隐（`cart.js`） | **保留初始 `display:none`**，其余布局属性搬 CSS |
| Alpine `x-show` 防闪（`login.html` OTP 步骤） | 保留 `style="display:none"` |
| 运行时计算出的纯色/进度/尺寸（如颜色色块由数据决定） | 只留动态属性本身，静态部分搬 CSS |
| 后台内容富文本（`{$page_content|raw}`） | 不在治理范围 |

### 2.3 动态内联的替换写法

| 现状 | 改造后 |
|---|---|
| `account-coupons.html:79` JS 拼 `opacity:' + (faded ? '.65' : '1')` | `class="coupon-card${faded ? ' is-faded' : ''}"` + `.coupon-card.is-faded{opacity:.65}` |
| `checkout.html:173` `:style="… 'border-color:#ff5f18;…' : 'opacity:.55;…'"` | `:class="{ 'is-selected': …, 'is-disabled': !c.usable }"` |
| `checkout.html:195` `:style="'…color:' + (promoError ? '#c00' : '#0a7d28')"` | `:class="{ 'is-error': promoError, 'is-success': !promoError }"` |

统一状态类命名：`.is-selected` / `.is-disabled` / `.is-faded` / `.is-error` / `.is-success` / `.is-active`
（与 `site-addons.css` 里 `.sku-value.is-active`、`.site-toast.is-visible` 已有约定一致）。

---

## 3. 执行阶段

> 每阶段独立可发布、可回滚；建议每阶段一个 commit。

### P0 · 基线与工具（0.5 天）

1. `php think run -p 8000`，对 12 个在用页面录音截图基线（桌面 1440、移动 390）：
   `/`、`/products`、`/products/{id}`、`/cart`、`/checkout`、`/login`、
   `/account`、`/account/orders`、`/account/addresses`、`/account/wishlist`、`/account/coupons`、
   `/service`、`/contact`、`/page/{slug}`、404。
2. 把附录里的审计脚本落到 `tools/audit-inline-styles.mjs`（dev-only，不进运行时），
   之后每阶段跑一次看总量曲线：`289 → 目标 ≤ 15`。

### P1 · 删除死模板（减少 18 处噪声 + 全部 `/tape2026/` 死链）

`app/controller` 只 render `account-overview` / `account-orders` / `account_order_detail` /
`account-addresses` / `account-wishlist` / `account-rewards` / `account-coupons` / `account-logout`，
且 `PageService::TEMPLATES` 白名单只有 `about/service/contact/page`，因此以下 4 个文件确认无引用：

- `templates/almi2026/account.html`
- `templates/almi2026/account_addresses.html`
- `templates/almi2026/account_orders.html`
- `templates/almi2026/_page.html`

处理：`git rm` 或 `git mv` 到归档目录；**不要**再花时间迁移这 4 个文件里的内联样式。

### P2 · 全站骨架（`layout/base.html` + 复用组件，约 1 天）

1. **抽公共片段** `templates/almi2026/inc/benefits.html`：4 项福利横幅（保 2 年 / 积分 / 30 天退款 / 免费退货），
   用 `{include file="inc/benefits"}` 替换 7 处重复（cart / checkout / service / account-overview /
   account-wishlist / account-logout 等），一次干掉 112 处内联。
2. 该横幅的类已在 `app.css` 定义（`.home-benefits-new`、`__grid`、`.benefit-item`），**只补 3 条**到 `site-addons.css`：
   - `.benefit-item img{width:32px;height:32px;margin:0 auto 16px;filter:brightness(.35)}`
     （现有 CSS 只写了 `.benefit-item svg`，而模板用的是 `<img src="*.svg">`，不补就会变回彩色图标）
   - `.home-benefits-new--page{margin-top:80px;padding-bottom:0}`（页面内嵌态的间距）
   - `.benefit-item p{font-size:.875rem;font-weight:600}` 如与现有 `.8125rem/#666` 冲突，用 `--page` 修饰类覆盖，避免动首页。
3. `base.html` 的 21 处内联 → `site-addons.css`：
   `.site-logo svg`、`.site-logo__text`、`.site-header__actions-guest`、`.site-header__actions-user`、
   `.social-icons img{filter:brightness(.3)}`、`.payment-card--amex/--mastercard/--maestro/--visa/--paypal/--applepay`、
   `.region-selector`、`.region-selector label/select`。
4. `base.html` 两个 `<style>`（区域切换器 14 条 + locale 提示 4 条）→ `site-addons.css`；
   RTL 6 条 → `site-addons.css` 里用 `[dir="rtl"] …` 选择器，删掉 `{if condition="$locale_dir == 'rtl'"}` 包裹。
5. `contact.html` `page_script` 里的 `<style>` 5 条 → `pages/contact.css`（其中 `[x-cloak]` 已在 `common.css`，删除重复）。

**验收**：`base.html` 内联 = 0；7 个页面的福利带视觉一致；首页福利带无变化。

### P3 · 补建 8 个缺失的页面样式文件（约 2 天）

按"文件已 link、内容为空"的事实补文件，每建一个就把它对应模板的内联搬进去：

| 新文件 | 吸收的内联 | 同时补的缺失 class |
|---|---:|---|
| `pages/account.css` | 约 100 | `.account-content`、`.wishlist-empty/-error/-loading`、`.coupon-tabs/-tab`、账户表格与状态徽章 |
| `pages/cart.css` | 33 | `.empty-cart`、`.cart-sidebar`、`.summary-row`、`.color-swatch--*` |
| `pages/checkout.css` | 50 | `.checkout-toast`、`.cart-toast--*`、`.coupon-option`、`.promo-message`、`.addr-option`、`.form-hint` |
| `pages/login.css` | 21 | `.login-aside`、`.login-benefits`、`.login-consent`、`.login-otp` |
| `pages/service.css` | 14 | `.service-hero__lead`、`.service-card__highlight*`、`.service-shipping/-returns/-warranty/-support`、`.service-contact*` |
| `pages/page.css` | 5（+ `error.html` 2） | `.article-hero`、`.article-hero-w`、`.hero-title`、`.hero-desc`、`.cms-content`、`.policy-placeholder`、`.breadcrumb` 补齐 |
| `pages/order-success.css` | 3 | `.order-success` 相关空态 |
| `pages/about.css` | 0 | **模板无内联也无缺失 class → 建议删掉 `about.html` 里的 `about.css` link**，而不是建空文件 |

注意点：

- `page.html` 目前**没有 `extra_css` block**，需新增并引入 `pages/page.css`；
- `error.html` 同时修正 `/tape2026/css/app.css` → `{:template_asset('css/app.css')}`，
  背景图 `/tape2026/img/inside-banner.jpg` 不存在（全站只有 `login-bg.jpg` / `index-banner2.jpg`），改用现有图或删除该行；
- 页面 CSS 里统一用 `url('../img/…')`。

### P4 · 结算 / 购物车 / 登录三个重灾区（含 P3 的落地，约 2 天）

这三个页面各 20~50 处，逐条分类，**不要整体替换**：

- `checkout.html`：50 处 → 表单错误/提示文案（`.form-error` 已在 `site-addons.css`，直接复用，删内联）、
  优惠券列表项、地址选择、订单摘要行、浮动 toast；2 处 Alpine `:style` 改 `:class`。
- `cart.html`：33 处 → 空态、右侧摘要、3 个 `display:none` 行（保留内联显隐，其余搬 CSS）、
  推荐商品区（注意该区是**硬编码 demo 数据**，`href="/product-detail"` 是无效路由 + 外链图片，
  建议后续接真实数据或整块删除，本次只做样式归位）。
- `login.html`：21 处 → 左侧权益说明、验证码倒计时、同意条款区；OTP 步骤的 `display:none` 保留。

### P5 · 剩余页面收尾（约 1 天）

`index.html`(12) → `pages/homepage.css`；`products.html`(4) → `pages/product-list.css`；
`product.html`(9 + `<style>` 14 条) → `pages/product-detail.css`（把 `product-description` 那一段整块搬走，
删掉模板里的 `{literal}<style>…`）；`service/about/contact/page/order_success/error` 按 P3 收尾。

### P6 · 验收与清理（0.5 天）

1. 审计脚本复跑：内联总数 ≤ 15，且每一处都能在 PR 描述里说明"为什么必须内联"。
2. DevTools Network：页面样式 404 = 0。
3. 视觉比对 P0 截图（桌面 + 移动）；重点看：
   - 福利横幅（由 `display:flex` 回归到 `app.css` 的 4 列 grid，**这是预期变化**，必须确认桌面/移动都正常）；
   - 页脚支付图标颜色、社媒图标灰化；
   - 结算页优惠券选中态/禁用态、促销码红绿文案。
4. 交互回归：购物车增减删、优惠券选择、地址选择、登录验证码、心愿单增删、联系我们表单提交。
5. `git commit` 说明里附"内联 289 → N"。

---

## 4. 风险清单

| 风险 | 说明 | 应对 |
|---|---|---|
| 福利带布局回归 | 内联 `display:flex` 现在**压住**了 `app.css` 的 `grid` 规则；删内联后桌面变 4 列 grid | 单独 commit，附前后截图；确认 `mobile.css` 已有 2 列规则 |
| `.btn` 被页面样式污染 | 多处内联覆盖了 `.btn` 的 padding/背景（如 `cart.html:15`） | 页面 CSS 必须挂在页面根类下：`.cart-page .btn--cta{…}` |
| 图标变彩色 | 模板对 `<img src="*.svg">` 用 `filter:brightness()`，而现有 CSS 只覆盖 `svg` 标签 | P2 里补 `.benefit-item img` / `.social-icons img` 规则 |
| `display:none` 由 JS 接管 | `cart.js` 用 `style.display = ''`/`'none'` 切换 | 初始 `display:none` 保留在模板；CSS 里只写布局，不写 `display` |
| 误删在用模板 | 4 个 snake_case 模板看似重复但可能被后台单页引用 | 已核对 `PageService::TEMPLATES` 白名单；删除前再 `grep` 一次 |
| 动了编译产物 | `app.css` 由 sass 生成且构建链已断 | 明确不改 `app.css/common.css/promo.css`；如需共享样式优先 `site-addons.css` |

---

## 5. 不在本次范围

- 恢复 sass 构建（补 `pages/*.sass` 分片并接回 `app.sass`）——建议单独开任务。
- 购物车"推荐商品"硬编码 demo 数据换真实接口、`/product-detail` 死链。
- 后台（`app/admin`）页面样式。
- 富文本内容（CMS 正文）的排版统一。

---

## 附录 · 审计脚本

```js
// tools/audit-inline-styles.mjs  —— 只读扫描，输出各模板内联样式统计与重复度
// node tools/audit-inline-styles.mjs
```

统计口径：
- 内联属性：`style\s*=\s*"([^"]*)"`（会同时命中 Alpine `:style="…"` 与 JS 字符串里的 `style="…"`，
  这类需要人工判定为"动态，保留"）；
- `<style>` 块：`<style` 计数；
- 重复度：去掉空白与结尾分号后分组计数；
- CSS 侧：把 `public/almi2026/css/**/*.css` 解析成 `{选择器: 声明}` 建索引，用于判断"这条内联是否已经等价于某个类"。

---

## 附录 B · 后台（app/admin/view）

后台视图没有走主题模板，样式入口是 `public/static/css/style.css`（含 `--primary` 等设计令牌与
`.card/.table/.btn/.badge/.admin-form` 等组件）与各页面 `{block name="head"}` 里追加的样式。

### 已完成：密钥管理页（`api_keys/index.html`）

- 19 处内联 → **0**；新增页面样式 `public/static/css/api-keys-page.css`，
  由 `{block name="head"}` 引入（带 `?v=20261118` 版本串，和 `product-page.css` 的用法一致）。
- 类命名：页面级 `.api-keys-*`；弹窗表单 `.admin-modal-form / __field / __label / __control`；
  SweetAlert 明文框 `.swal-plain-note / .swal-plain-key`。
- 踩到的坑：`.table td` 自带 `padding:16px`（权重 0,1,1），空态单元格的 `padding:40px 0`
  必须写成 `.table td.api-keys-empty` 才能盖住原内联值。
- 验收：逐项比对迁移前后计算样式（说明文字间距、`<pre>` 全部 13 项、表头列宽、弹窗表单控件、
  Swal 输入框），并截图确认主页面与创建弹窗无变化。

### 待办：其余后台视图

后台仍有 **594 处内联样式，分布在 45 个视图**（`security` 66、`staff` 40、`audit_logs` 38、
`marketing/form` 30、`orders/index` 28…），且 30+ 个视图在 `{block name="head"}` 里还有页面级
`<style>` 块。建议按同样方式推进：

1. 每个视图建 `public/static/css/{页面}-page.css`，`{block name="head"}` 引入；
2. 反复出现的块（`#d9d9d9` 表单控件 43 处、`.btn-primary` 白色图标 9 处、空表格行 2 处）
   上提到 `style.css` 做成 `.admin-modal-form__control`、`.btn-primary .icon-svg`、`.table-empty`；
3. 迁移前注意 `.table td/th`、`.card`、`.btn` 这些基础规则的权重，页面类要够权重才盖得住。
