# 后台内联样式迁移规范（app/admin/view）

> 目标：把后台视图里的静态内联样式 `style="…"` 与页面级 `<style>` 块搬到 CSS 文件。
> **只搬位置，不改版式**：迁移后每个元素的计算样式必须与迁移前逐项一致。
> 基线数据已由 `__adminBase`（浏览器 localStorage，`http://127.0.0.1:8000`）采集，
> 迁移完成后由主会话逐页比对验收。

## 1. 产出物

每个视图一个页面样式文件，路径与命名：

| 视图 | 页面样式文件 |
|---|---|
| `app/admin/view/orders/index.html` | `public/static/css/pages/orders-index.css` |
| `app/admin/view/marketing_grant/form.html` | `public/static/css/pages/marketing-grant-form.css` |

（`_` 统一转 `-`；`marketing_grant` → `marketing-grant`）

在视图里用 ThinkPHP 的 `head` 块引入，放在 `{block name="title"}` 之后：

```html
{block name="head"}<link rel="stylesheet" href="/static/css/pages/orders-index.css?v=20261118">{/block}
```

如果视图已经有 `{block name="head"}`（里面通常是页面级 `<style>` 块），
**把 `<link>` 加进该块，同时把 `<style>` 块的全部内容搬进页面 CSS 文件并删除 `<style>` 标签**。

### 1.1 link 的位置必须等于原 `<style>` 的位置（重要）

原 head 块里如果**还有别的 stylesheet link**（如 `product-page.css`、`toastui-editor.css`），
新的页面 CSS `<link>` 必须排在它们**之后**——因为被搬走的 `<style>` 原本就在这些 link 后面，
排到前面会让同权重规则的取胜顺序反转（已实测踩过：`product-page.css` 的
`.product-editor label{color:var(--text-main)}` 反过来盖掉了
`.translation-panel label{color:#374151}`，导致 9 处 label 颜色回归）。

判断口径：**页面 CSS 必须是 head 块里最后一个 stylesheet**。

## 2. 什么时候必须保留内联

以下情况**不要动**（迁移后仍保留 `style="…"`）：

1. **模板动态值**：值里含 `{$…}` / `{:`，例如 `style="color: {$order.status_color}"`、
   `style="height: {$stat.pct}%"`。
2. **JS 运行时写入的显隐**：元素初始 `style="display:none"`，随后由脚本 `el.style.display` 切换
   （订单发货弹窗、优惠码行、Tab 切换等）。初始值必须保留。
3. **Alpine 的 `x-show` 防闪**：`x-show="…"` 配 `style="display:none"`，同上保留。
4. **JS 运行时算出来的值**：值本身由拼接/三元/变量插值得到，
   例如 `style="color:' + (ok ? '#0a7d28' : '#c00') + '"`。

**判定口径看"值"，不看它写在哪里**：
JS 字符串里拼出来的 HTML，只要 style 的**值是字面常量**（`display:flex;width:100%;margin:0` 这种），
就属于静态声明，**同样要迁成类**（页面 CSS 在该页全局生效，类能匹配到）。
只有上面第 4 种"值本身是算出来的"才保留。

除此之外的**全部**静态声明都要搬走。

## 3. 类名与样式归属

### 3.1 优先用 `public/static/css/style.css` 里已有的共享类

以下共享类已在 `style.css` 末尾就位，能用就用（**不要改 style.css**）：

```
按钮白图标：  .btn-primary .icon-svg-sm            （直接删掉内联 filter 即可）
空表格行：    .table-empty                          （padding:24px 0;text-align:center）

弹窗表单：    .admin-modal-form                     text-align:left
             .admin-modal-form__field              margin-bottom:16px（最后一个是 0）
             .admin-modal-form__label              display:block;font-weight:500;margin-bottom:6px
             .admin-modal-form__control            width:100%;height:36px;padding:0 12px;border:1px solid #d9d9d9;border-radius:4px;font:inherit
             .admin-modal-form__control--muted     额外 background:#f5f5f5
             .admin-modal-form__check-list         border…;padding:8px;max-height:120px;overflow-y:auto
             .admin-modal-form__radio-row          display:flex;align-items:center;cursor:pointer
             .admin-modal-form__radio-row--spaced  额外 margin-bottom:8px
             .admin-modal-form__radio              margin-right:8px
明文密钥弹窗：.swal-plain-note / .swal-plain-key

字号对齐：    .text-xs(12px) .text-sm(13px) .text-left .text-center .text-right
间距：        .mt-4 .mt-6 .mt-8 .mt-10 .mt-12 .mt-20
              .mb-0 .mb-4 .mb-6 .mb-12 .mb-20   （已有 .mt-16 .mb-16 .mb-24）
flex：        .flex-1 .flex-2 .flex-fill(1 1 100%) .flex-wrap .items-start .items-center
              .gap-4 .gap-10                     （已有 .gap-8 .gap-16 .gap-24）
尺寸：        .thumb-48  .w-full .w-48 .w-80 .w-90 .w-110 .w-120 .w-140 .w-150 .w-160
              .w-170 .w-180 .w-200 .w-220 .w-240 .w-250 .w-260
              .mw-120 .mw-140 .mw-160 .mw-180 .mw-200 .mw-220 .mw-240 .mw-250 .mw-260
              .form-field.basis-120/140/180/200/220/240/320   （表单字段 flex:0 1 Npx）
```

**注意：`.mb-8` 和 `.gap-12` 故意没有定义**（部分旧视图已经在用这两个 class 但一直没有样式，
定义它们会顺带改变那些页面）。遇到 `margin-bottom:8px` / `gap:12px` 请在页面 CSS 里写页面自己的类。

### 3.2 其余写进页面 CSS

- 选择器**尽量两段式**，用页面根类或结构父类收敛，例如：
  `.orders-page .order-product-thumb`、`.table .col-spec`、`.coupon-card__meta`。
- 页面根类可以复用视图已有的：`<main class="…">` / 卡片容器 id（如 `#api-keys-page`）。
- **类名前缀用页面自己的词**，避免和其它页面撞名（例如 orders 用 `order-`，staff 用 `staff-`）。
- **权重自查（重要）**：`style.css` 里 `.table td/th`、`.card`、`.btn`、`.admin-form input/select`、
  `.badge` 都带基础规则。如果某个内联属性在同元素上会被这些规则覆盖，
  页面 CSS 里要把选择器写到足够权重（两段式或加类名），否则迁移后值会变回去。
  已知坑示例：空表格行 `padding:40px 0` 必须写 `.table td.api-keys-empty` 才盖得住 `.table td` 的 16px。

## 4. 不要做的事

- 不要改 `public/static/css/style.css`、`app/admin/view/layout/base.html`、
  `app/admin/route/admin.php`、控制器。
- 不要改你负责范围之外的视图或 CSS 文件。
- 不要重排/增删 DOM 结构，**只增删 `class` 属性里的类名**。
- 不要改样式值（颜色、尺寸、间距原样搬）。
- 不要顺手"优化"版式或补齐缺失样式——本任务只搬位置。
- 不要执行 git 提交。

## 5. 自检清单（每个文件完成后逐条过）

1. `Select-String -Path <视图> -Pattern 'style="'` 结果只剩 §2 允许保留的那几类；
2. `<style` 标签为 0；
3. 页面 CSS 里每条规则的值与原内联逐字一致（含 `#` 颜色大小写、单位、小数）；
4. 新增类名在其它后台视图里没有被用过（避免"突然生效"）：
   `Select-String -Path app/admin/view/*/*.html -Pattern 'class="[^"]*\b<类名>\b'`
5. 引入链接带 `?v=20261118`；
6. 用 `git diff --stat -- <你的文件>` 确认只改了自己负责的文件。

## 6. 汇报格式

完成后回报：文件清单、每文件"迁移前 N 处 → 迁移后 M 处"、
新增页面 CSS 路径、保留内联的具体条目与理由（按 §2 分类）。
