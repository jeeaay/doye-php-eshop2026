# 后台内联样式迁移 · 执行报告（已完成）

规范：`docs/admin-inline-refactor-spec.md`
开始日期：2026-11-18

## 一、结果

| 指标 | 开始 | 结束 |
|---|---:|---:|
| 后台视图内联 `style="…"` | **594** | **22**（全部为规范 §2 允许保留） |
| 页面级 `<style>` 块 | **33** | **0** |
| 页面样式文件 `public/static/css/pages/*.css` | 0 | **43** |
| `style.css` 共享层新增 | — | 1 个区块（`.admin-modal-form*` / `.btn-primary .icon-svg-sm` / `.table-empty` / 字号·间距·flex·尺寸工具类 / 布局规则） |

覆盖 `app/admin/view` 下全部 45 个视图（含 `layout/base.html`）。

## 二、验收（三层，全部通过）

### 1. DOM 计算样式基线（主验收）

迁移前把每个后台路由上「带内联样式元素」的 **42 项计算样式**存进浏览器 `__adminBase`，
迁移后逐元素按文档序索引对齐比对：

- **40 个页面、572 个元素、0 差异、0 失败**
- `layout/base.html` 管的是侧边栏/页头/页脚（不在 `.page-content` 内），单独用 `__adminShellBefore`
  的 **83 个元素**比对：**0 差异**

### 2. 静态覆盖检查 `node tools/verify-admin-inline.mjs --all`

对照 `git show HEAD:<视图>` 的原始内联，逐条确认迁移后 CSS 中存在同值声明：

- **42 个视图、1135 条原声明、0 条未覆盖**
- 工具会展开 `margin/padding` 简写再比对，以兼容 `.mt-6` + `.mb-24` 这种拆分迁移

### 3. 人工断言（JS 注入内容，基线覆盖不到的部分）

| 页面 | 结果 |
|---|---|
| `staff` 新增人员弹窗 | form `text-align:left`、field `16px`、label `block/500/6px`、control `100%/36px/12px/#d9d9d9/4px/font:inherit`、勾选列表 `1px/8px/120px/auto` 全部一致 |
| `api_keys` 创建弹窗 | 同上，`padding`/`border-radius` 逐项一致 |
| `home_ops` Tab 面板 | 5 处 `display` 保留并复验 |

## 三、保留的 22 处内联（规范 §2）

| 类别 | 数量 | 位置 |
|---|---:|---|
| 模板动态值 `{$…}` | 6 | `orders/detail`(`status_color`)、`orders/index`(`status_color`)、`index/index`(`$bar`)、`marketing_grant/index`(`$g.progress`)、`marketing_grant/detail`(`$grant.progress`)、`payments`(`$channel.color`) |
| JS `el.style.display` 切换的初始值 | 13 | `update`(5)、`home_ops`(5)、`orders/index`(1)、`multilang`(1) |
| Alpine `:style` / `x-show` 防闪 | 3 | `layout/base`(3 个 `:style`：侧栏宽度、两级菜单箭头旋转) |

（`pages/form` 的 1 处 `display:none` 属 `x-show` 防闪，也计入 JS 显隐类。）

## 四、验收过程中发现并修复的 3 个问题

1. **9 处 label 颜色回归**（`products/create`）：新 `<link>` 被放在 `product-page.css` **之前**，
   而原 `<style>` 在它**之后**，同权重规则顺序反转。
   → 把 5 个多 link 视图（`products/form`、`products/index`、`brands/detail`、`merchants/detail`、`pages/form`）
   的页面 CSS 调到 head 块最后一位。已写入规范 §1.1。
2. **`security` 首轮漏迁 11 处**：把 JS 字符串里的静态值当成运行时值保留。
   → 规范 §2 补充「判定看值不看位置」，返工归零。
3. **`marketing_grant/form` 的 `<style>` 从来没生效过**：它写在 `{block name="extra_css"}`，
   而后台 layout 只有 `title/head/content/script` 四个块。
   → 用 `git stash` 还原原版实测确认（`.mg-section` 的 `margin-bottom` 为 0px、页面无该 style 标签）；
   处理方式是**规则原样保留在 CSS 里但用注释包裹**：`<style>` 归零、内容不丢、渲染与基线完全一致。
   日后要启用，把注释去掉即可，但会带来约 13 个元素的视觉变化，需当作"顺带修复"重新验收。

另外：`products/create` 等 toastui 编辑器页在编辑器初始化期间会有瞬时状态差异，
比对时需加 ~1.5s 稳定等待（连跑两次 0 差异）。

## 五、产出文件

- **规范**：`docs/admin-inline-refactor-spec.md`（判定口径、共享类清单、权重自查、link 顺序规则、自检清单）
- **工具**：
  - `tools/verify-admin-inline.mjs` —— 对照 git HEAD 的静态覆盖检查（`--all` 全量）
  - `tools/audit-inline-styles.mjs` —— 前台模板内联审计
- **共享层**：`public/static/css/style.css`
- **页面样式**：`public/static/css/pages/*.css` ×43
- **被修改的视图**：`app/admin/view/**` 全部 45 个（含 `layout/base.html`）

## 六、遗留与建议

1. **`marketing_grant/form` 的注释规则**：确认要不要启用（会改版式，需单独验收）。
2. **`.mb-8` / `.gap-12` 故意未定义**：旧视图已在用但一直没样式，定义它们会顺带改变那些页面；
   本次用页面自己的类承载 `gap:12px` / `margin-bottom:8px`。日后若要统一，需逐页确认。
3. **`marketing_grant/form` 原先的 `extra_css` 写法**：说明后台 layout 与前台模板块名不一致，
   迁移其它页面时若再遇到 `extra_css`/`extra_head` 之类块名，要先确认 layout 是否真的有这个块。
4. 前台模板（`templates/almi2026`）的内联治理见 `docs/inline-style-refactor-plan.md`（已完成，289 → 8）。
