<?php
use think\migration\Migrator;

/**
 * 商品评论与「有用/无用」投票
 *
 * product_review：
 * - uk_order_item(order_item_id)：一个订单商品只允许一条评论；
 *   后台删除走硬删除（连带投票），避免软删除行长期占用唯一键；
 * - idx_product_status_time(product_id, status, create_time)：前台统计与列表（status=1）；
 * - idx_merchant_status(merchant_id, status)：后台按商户收敛；
 * - idx_user(user_id)：资格查询与后续「我的评论」扩展；
 * - merchant_id 是商品归属快照，非超管后台依赖 MerchantModel 自动过滤。
 *
 * product_review_vote：
 * - uk_review_user(review_id, user_id)：同一用户同一评论只保留一票；
 * - idx_review_vote(review_id, vote)：按评论统计有用/无用。
 */
class CreateProductReview extends Migrator
{
    /**
     * 执行迁移
     *
     * @return void
     */
    public function change()
    {
        $review = $this->table('product_review', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '商品评论（已购用户提交，后台审核后前台可见）',
        ]);
        $review->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('product_id', 'biginteger', ['signed' => false, 'null' => false])
            ->addColumn('merchant_id', 'biginteger', ['signed' => false, 'null' => true, 'comment' => '商品归属快照，后台数据范围'])
            ->addColumn('user_id', 'biginteger', ['signed' => false, 'null' => false])
            ->addColumn('order_id', 'biginteger', ['signed' => false, 'null' => false])
            ->addColumn('order_item_id', 'biginteger', ['signed' => false, 'null' => false, 'comment' => '订单商品行，唯一'])
            ->addColumn('rating', 'tinyinteger', ['signed' => false, 'null' => false, 'comment' => '1-5 星'])
            ->addColumn('title', 'string', ['limit' => 120, 'null' => true])
            ->addColumn('content', 'text', ['null' => false])
            ->addColumn('images_json', 'json', ['null' => true, 'comment' => '图片地址数组，最多 6 张'])
            ->addColumn('is_anonymous', 'tinyinteger', ['limit' => 1, 'default' => 0, 'comment' => '1=匿名展示'])
            ->addColumn('is_verified', 'tinyinteger', ['limit' => 1, 'default' => 1, 'comment' => '1=已购标识'])
            ->addColumn('status', 'tinyinteger', ['default' => 0, 'comment' => '0=待审核 1=已通过 2=已拒绝 3=已隐藏'])
            ->addColumn('helpful_yes', 'integer', ['default' => 0, 'comment' => '有用计数'])
            ->addColumn('helpful_no', 'integer', ['default' => 0, 'comment' => '无用计数'])
            ->addColumn('admin_reply', 'text', ['null' => true])
            ->addColumn('replied_by', 'biginteger', ['signed' => false, 'null' => true])
            ->addColumn('replied_at', 'datetime', ['null' => true])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addColumn('update_time', 'datetime', ['null' => true])
            ->addColumn('delete_time', 'datetime', ['null' => true])
            ->addIndex(['order_item_id'], ['unique' => true, 'name' => 'uk_order_item'])
            ->addIndex(['product_id', 'status', 'create_time'], ['name' => 'idx_product_status_time'])
            ->addIndex(['merchant_id', 'status'], ['name' => 'idx_merchant_status'])
            ->addIndex(['user_id'], ['name' => 'idx_user'])
            ->create();

        $vote = $this->table('product_review_vote', [
            'id'          => false,
            'primary_key' => ['id'],
            'engine'      => 'InnoDB',
            'collation'   => 'utf8mb4_unicode_ci',
            'comment'     => '评论有用/无用投票',
        ]);
        $vote->addColumn('id', 'biginteger', ['identity' => true, 'signed' => false])
            ->addColumn('review_id', 'biginteger', ['signed' => false, 'null' => false])
            ->addColumn('user_id', 'biginteger', ['signed' => false, 'null' => false])
            ->addColumn('vote', 'tinyinteger', ['null' => false, 'comment' => '1=有用 2=无用'])
            ->addColumn('create_time', 'datetime', ['null' => true])
            ->addIndex(['review_id', 'user_id'], ['unique' => true, 'name' => 'uk_review_user'])
            ->addIndex(['review_id', 'vote'], ['name' => 'idx_review_vote'])
            ->create();
    }
}
