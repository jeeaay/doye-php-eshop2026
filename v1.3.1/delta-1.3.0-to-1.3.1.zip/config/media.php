<?php

return [
    'products' => [
        'image' => [
            'max_size' => 10 * 1024 * 1024,
            'extensions' => ['jpg', 'jpeg', 'png', 'webp'],
            'mimes' => ['image/jpeg', 'image/png', 'image/webp'],
        ],
        'video' => [
            'max_size' => 200 * 1024 * 1024,
            'extensions' => ['mp4', 'webm'],
            'mimes' => ['video/mp4', 'video/webm'],
        ],
    ],
    'merchants' => [
        'image' => [
            'max_size' => 10 * 1024 * 1024,
            'extensions' => ['jpg', 'jpeg', 'png', 'webp'],
            'mimes' => ['image/jpeg', 'image/png', 'image/webp'],
        ],
    ],
    // 品牌 logo 上传规格，与 merchants 完全一致
    'brands' => [
        'image' => [
            'max_size' => 10 * 1024 * 1024,
            'extensions' => ['jpg', 'jpeg', 'png', 'webp'],
            'mimes' => ['image/jpeg', 'image/png', 'image/webp'],
        ],
    ],
    // 单页（CMS）富文本内插图
    'pages' => [
        'image' => [
            'max_size' => 10 * 1024 * 1024,
            'extensions' => ['jpg', 'jpeg', 'png', 'webp'],
            'mimes' => ['image/jpeg', 'image/png', 'image/webp'],
        ],
    ],
    // 商品评论配图（与 pages 规格一致；路径 /uploads/reviews/images/YYYYMM/）
    'reviews' => [
        'image' => [
            'max_size' => 10 * 1024 * 1024,
            'extensions' => ['jpg', 'jpeg', 'png', 'webp'],
            'mimes' => ['image/jpeg', 'image/png', 'image/webp'],
        ],
    ],
];
