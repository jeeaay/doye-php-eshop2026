<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\exception\BizException;
use app\common\model\Page as PageModel;
use app\common\service\PageService;

/**
 * 管理 API：站点单页（CMS）
 *
 * 平台级内容（配送说明、退换货、隐私政策、服务条款、Cookie 政策等），
 * 不带商户维度，仅平台超级管理员可读写；写入委托 {@see PageService}，
 * 与后台「单页管理」共用同一套校验（slug 规则、保留字、唯一性）。
 */
class Page extends ApiBaseController
{
    /**
     * GET /admin-api/v1/pages
     *
     * 支持 title / status / page / page_size
     *
     * @return \think\response\Json
     */
    public function index()
    {
        return $this->run(function () {
            $this->assertSuper();
            [$page, $size] = $this->pageParams();

            $title  = trim((string) $this->request->param('title', ''));
            $status = $this->request->param('status', '');

            $query = PageModel::order('sort')->order('id', 'desc');
            if ($title !== '') {
                $query->whereLike('title', '%' . $title . '%');
            }
            if ($status !== '' && $status !== null) {
                $query->where('status', (int) $status);
            }

            $pager = $query->paginate($size, false, [
                'page'  => $page,
                'query' => ['title' => $title, 'status' => $status],
            ]);

            $list = [];
            foreach ($pager->items() as $row) {
                $list[] = [
                    'id'             => (int) $row->id,
                    'title'          => (string) $row->title,
                    'slug'           => (string) $row->slug,
                    'content_type'   => (string) $row->content_type,
                    'status'         => (int) $row->status,
                    'sort'           => (int) $row->sort,
                    'content_length' => mb_strlen((string) $row->content),
                    'update_time'    => $row->update_time ? (string) $row->update_time : '',
                ];
            }

            return $this->pagePayload($list, $pager, $page, $size);
        });
    }

    /**
     * GET /admin-api/v1/pages/:id
     *
     * @return \think\response\Json
     */
    public function detail()
    {
        return $this->run(function () {
            $this->assertSuper();
            return (new PageService())->detail((int) $this->request->param('id', 0));
        });
    }

    /**
     * POST /admin-api/v1/pages
     *
     * 必填 title / slug；content_type 省略时为 database（富文本）
     *
     * @return \think\response\Json
     */
    public function save()
    {
        return $this->run(function () {
            $this->assertSuper();
            $data = $this->input();
            $id   = (new PageService())->saveItem($data, null);
            return ['id' => $id];
        }, '单页已创建');
    }

    /**
     * PUT /admin-api/v1/pages/:id
     *
     * 建议提交完整字段：saveItem 对缺省字段按默认值处理（content 会被清空）
     *
     * @return \think\response\Json
     */
    public function update()
    {
        return $this->run(function () {
            $this->assertSuper();
            $id = (int) $this->request->param('id', 0);
            if ($id <= 0) {
                throw new BizException('缺少单页 ID');
            }
            (new PageService())->saveItem($this->input(), $id);
            return ['id' => $id];
        }, '单页已更新');
    }

    /**
     * POST /admin-api/v1/pages/:id/status
     *
     * body {status:0|1}，0 下线、1 上线
     *
     * @return \think\response\Json
     */
    public function status()
    {
        return $this->run(function () {
            $this->assertSuper();
            $input = $this->input();
            if (!isset($input['status']) || !in_array((int) $input['status'], [0, 1], true)) {
                throw new BizException('单页状态无效');
            }
            (new PageService())->toggleItem(
                (int) $this->request->param('id', 0),
                (int) $input['status']
            );
            return null;
        }, '单页状态已更新');
    }
}
