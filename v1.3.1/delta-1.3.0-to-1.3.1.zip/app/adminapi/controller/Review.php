<?php
declare(strict_types=1);

namespace app\adminapi\controller;

use app\common\service\ReviewService;
use think\Paginator;

/**
 * 管理 API：商品评论（后台审核）
 *
 * 与后台页面 `/console/reviews` 共用 {@see ReviewService}：
 * 数据范围（超管全量 / 商家按 merchant_ids）与写权限、参数校验、事务都在 Service 层，
 * 控制器只做参数整形与统一响应封装。
 */
class Review extends ApiBaseController
{
    /**
     * GET /admin-api/v1/reviews
     *
     * @return \think\response\Json
     */
    public function index()
    {
        return $this->run(function () {
            [$page, $size] = $this->pageParams();

            $filters = [
                'keyword'    => $this->textParam('keyword'),
                'status'     => $this->textParam('status'),
                'rating'     => $this->intParam('rating'),
                'product_id' => $this->intParam('product_id'),
                'start_date' => $this->textParam('start_date'),
                'end_date'   => $this->textParam('end_date'),
            ];

            $result = (new ReviewService())->adminList($filters, $page, $size);
            $pager  = Paginator::make([], (int) $result['page_size'], (int) $result['page'], (int) $result['total']);

            return $this->pagePayload($result['list'], $pager, $page, (int) $result['page_size']);
        });
    }

    /**
     * GET /admin-api/v1/reviews/:id
     *
     * @return \think\response\Json
     */
    public function detail()
    {
        return $this->run(function () {
            return (new ReviewService())->adminDetail((int) $this->request->param('id', 0));
        });
    }

    /**
     * POST /admin-api/v1/reviews/status
     *
     * 批量修改状态，body：{ids:[1,2], status:1|2|3}；也接受单个 id 与逗号分隔的 ids。
     *
     * @return \think\response\Json
     */
    public function status()
    {
        return $this->run(function () {
            $input  = $this->input();
            $ids    = $input['ids'] ?? $input['id'] ?? [];
            $status = (int) ($input['status'] ?? 0);

            if (is_string($ids)) {
                $ids = explode(',', $ids);
            } elseif (is_scalar($ids)) {
                $ids = [$ids];
            }
            if (!is_array($ids)) {
                $ids = [];
            }

            $count = (new ReviewService())->adminUpdateStatus($ids, $status);

            return [
                'count'        => $count,
                'status'       => $status,
                'status_label' => ReviewService::STATUS_LABELS[$status] ?? '',
            ];
        }, '评论状态已更新');
    }

    /**
     * POST /admin-api/v1/reviews/:id/reply
     *
     * body：{reply:"..."}；返回更新后的评论详情（含 admin_reply / replied_at）。
     *
     * @return \think\response\Json
     */
    public function reply()
    {
        return $this->run(function () {
            $input = $this->input();
            $reply = $input['reply'] ?? '';
            if (!is_scalar($reply)) {
                $reply = '';
            }

            return (new ReviewService())->adminReply(
                (int) $this->request->param('id', 0),
                (string) $reply
            );
        }, '回复已保存');
    }

    /**
     * DELETE /admin-api/v1/reviews/:id
     *
     * 硬删除评论及其投票记录（不可恢复，审计中间件会记录 DELETE）。
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        return $this->run(function () {
            $count = (new ReviewService())->adminDelete([(int) $this->request->param('id', 0)]);

            return ['count' => $count];
        }, '评论已删除');
    }

    /**
     * 整数查询参数（数组/空值收敛为 0）
     *
     * @param string $key 参数名
     * @return int
     */
    private function intParam(string $key): int
    {
        $value = $this->request->param($key, 0);

        return is_scalar($value) ? (int) $value : 0;
    }

    /**
     * 标量查询参数（数组/空值统一为空串，避免 Service 收到脏类型）
     *
     * @param string $key 参数名
     * @return string
     */
    private function textParam(string $key): string
    {
        $value = $this->request->param($key, '');

        return is_scalar($value) ? trim((string) $value) : '';
    }
}
