<?php
declare(strict_types=1);

namespace app\common\model;

/**
 * 评论有用/无用投票
 *
 * 表只有 create_time，没有 update_time：显式关掉 $updateTime，
 * 否则 Query::update() 会尝试写不存在的列（见 database-guidelines）。
 */
class ProductReviewVote extends BaseModel
{
    protected $name = 'product_review_vote';
    protected $autoWriteTimestamp = 'datetime';
    protected $updateTime = false;
}
