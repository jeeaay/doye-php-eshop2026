<?php
declare(strict_types=1);

namespace app\admin\controller;

use app\common\exception\BizException;
use app\common\service\ReviewService;
use think\facade\View;
use think\Paginator;

/**
 * 后台评论管理
 *
 * 平台超管与商家共用这一页：可见范围与写权限全部由 {@see ReviewService} 收敛
 * （ProductReview 继承 MerchantModel，非超管自动按 merchant_ids 过滤），
 * 控制器只做参数整形与 JSON 响应封装，不重复写角色判断。
 *
 * 路由：/console/reviews（页面）、reviews/status|reply|delete（写操作）。
 */
class Reviews extends AdminBaseController
{
    /** 后台列表每页条数 */
    private const PAGE_SIZE = 20;

    /**
     * 评论列表页
     *
     * @return \think\response\View
     */
    public function index()
    {
        $this->assignActiveMenu('reviews');

        $filters = [
            'keyword'    => $this->scalarText('keyword'),
            'status'     => $this->scalarText('status'),
            'rating'     => $this->scalarInt('rating'),
            'product_id' => $this->scalarInt('product_id'),
        ];
        $page = max(1, $this->scalarInt('page', 1));

        $result = (new ReviewService())->adminList($filters, $page, self::PAGE_SIZE);

        $rows = [];
        foreach ($result['list'] as $row) {
            $row['author_display'] = $this->maskAuthor((string) $row['user_nickname'], (string) $row['user_email']);
            $rows[] = $row;
        }

        $query = [];
        foreach ($filters as $key => $value) {
            if ($value !== '' && $value !== 0) {
                $query[$key] = $value;
            }
        }

        $pages = Paginator::make([], self::PAGE_SIZE, $page, (int) $result['total'], false, [
            'path'  => admin_url('reviews'),
            'query' => $query,
        ]);

        View::assign('reviews', $rows);
        View::assign('filters', $filters);
        View::assign('product_id_input', $filters['product_id'] > 0 ? (string) $filters['product_id'] : '');
        View::assign('total', (int) $result['total']);
        View::assign('pages', $pages->render());

        return View::fetch();
    }

    /**
     * 批量修改状态（通过 / 拒绝 / 隐藏）
     *
     * 单条操作前端也传 `ids=[id]`，只保留一条代码路径。
     *
     * @return \think\response\Json
     */
    public function status()
    {
        try {
            $status = (int) $this->request->post('status', 0);
            $count  = (new ReviewService())->adminUpdateStatus($this->postIds('ids', 'id'), $status);

            $label = match ($status) {
                ReviewService::STATUS_APPROVED => '已通过',
                ReviewService::STATUS_REJECTED => '已拒绝',
                ReviewService::STATUS_HIDDEN   => '已隐藏',
                default                        => '已更新',
            };

            return json([
                'code'    => 0,
                'message' => $count . ' 条评论' . $label,
                'data'    => ['count' => $count, 'status' => $status],
            ]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 后台回复评论
     *
     * @return \think\response\Json
     */
    public function reply()
    {
        try {
            $id     = (int) $this->request->post('id', 0);
            $reply  = (string) $this->request->post('reply', '');
            $review = (new ReviewService())->adminReply($id, $reply);

            return json([
                'code'    => 0,
                'message' => '回复已保存',
                'data'    => $review,
            ]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 批量删除评论（含投票，不可恢复）
     *
     * @return \think\response\Json
     */
    public function delete()
    {
        try {
            $count = (new ReviewService())->adminDelete($this->postIds('ids', 'id'));

            return json([
                'code'    => 0,
                'message' => $count . ' 条评论已删除',
                'data'    => ['count' => $count],
            ]);
        } catch (BizException $e) {
            return json(['code' => 1, 'message' => $e->getMessage(), 'data' => null]);
        }
    }

    /**
     * 后台列表作者展示名：有昵称用昵称，否则邮箱脱敏（页面不直接铺原始邮箱）
     *
     * @param string $nickname 昵称
     * @param string $email    邮箱
     * @return string
     */
    private function maskAuthor(string $nickname, string $email): string
    {
        $nickname = trim($nickname);
        if ($nickname !== '') {
            return $nickname;
        }

        $email = trim($email);
        if ($email === '' || !str_contains($email, '@')) {
            return '—';
        }

        [$local, $domain] = explode('@', $email, 2);
        $first = mb_substr($local, 0, 1);

        return ($first !== '' ? $first : '*') . '***@' . $domain;
    }

    /**
     * 读取 POST 的批量 ID（支持 ids[] 数组、逗号分隔字符串与单个 id）
     *
     * @param string $idsKey 批量字段名
     * @param string $idKey  单条字段名
     * @return array<int,int>
     */
    private function postIds(string $idsKey, string $idKey = 'id'): array
    {
        $ids = $this->request->post($idsKey, []);
        if (is_string($ids)) {
            $ids = explode(',', $ids);
        }
        if (!is_array($ids)) {
            $ids = [];
        }

        $single = $this->request->post($idKey, 0);
        if (is_scalar($single) && (int) $single > 0) {
            $ids[] = $single;
        }

        return array_values($ids);
    }

    /**
     * 标量查询参数（数组/空值统一收敛为空串，避免模板与 Service 收到脏类型）
     *
     * @param string $key     参数名
     * @param string $default 缺省值
     * @return string
     */
    private function scalarText(string $key, string $default = ''): string
    {
        $value = $this->request->get($key, $default);

        return is_scalar($value) ? trim((string) $value) : $default;
    }

    /**
     * 整数查询参数
     *
     * @param string $key     参数名
     * @param int    $default 缺省值
     * @return int
     */
    private function scalarInt(string $key, int $default = 0): int
    {
        $value = $this->request->get($key, $default);

        return is_scalar($value) ? (int) $value : $default;
    }
}
