<?php
declare(strict_types=1);

namespace app\common\service;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\model\Currency;
use app\common\model\Language;
use app\common\model\Order;
use app\common\model\PaymentChannel;
use app\common\model\Product;
use app\common\model\Setting;
use app\common\support\AppContext;
use think\facade\Db;

/**
 * 站点版本（国内版 / 国际版）
 *
 * 两套独立部署共用同一套代码：
 *   国内版：中文基准 + CNY + 小程序 + 微信/支付宝
 *   国际版：英文基准 + USD + 独立站 + 多语言/多货币 + Stripe/PayPal
 *
 * 版本切换只改「基准语言/基准币种/功能开关」，不做价格换算和内容翻译。
 */
class EditionService
{
    public const INTERNATIONAL = 'international';
    public const DOMESTIC = 'domestic';

    /**
     * 当前版本概览
     *
     * @return array<string,mixed>
     */
    public function summary(): array
    {
        $initialized = $this->isInitialized();
        $edition = $initialized ? site_edition() : 'unset';
        $products = (int) Product::count();
        $orders = (int) Order::count();
        $suggested = $this->suggestEdition();
        $channelEdition = $edition === 'unset' ? ($suggested ?? self::INTERNATIONAL) : $edition;

        return [
            'edition'       => $edition,
            'edition_label' => $initialized
                ? ($edition === self::DOMESTIC ? '国内版' : '国际版')
                : '未初始化',
            'initialized'   => $initialized,
            'base_locale'   => base_locale(),
            'base_currency' => base_currency_code(),
            'products'      => $products,
            'orders'        => $orders,
            'can_switch'    => $orders === 0 || !$initialized,
            'requires_confirm' => $products > 0 || !$initialized,
            'suggested_edition' => $suggested,
            'channels'      => $channelEdition === self::DOMESTIC ? ['wechat', 'alipay'] : ['stripe', 'paypal'],
        ];
    }

    /**
     * 是否已经显式选择过站点版本
     *
     * 1.0.6 及更早的站点没有 site.edition 设置，升级后首次进入需要选择历史数据版本。
     */
    public function isInitialized(): bool
    {
        try {
            return Setting::where('key', 'site.edition')->find() !== null;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * 根据已启用的支付渠道给出历史数据版本建议
     *
     * @return string|null domestic / international / null
     */
    public function suggestEdition(): ?string
    {
        try {
            $codes = array_map('strval', PaymentChannel::where('enabled', 1)->column('code'));
        } catch (\Throwable $e) {
            return null;
        }
        $domestic = array_intersect($codes, ['wechat', 'alipay']);
        $international = array_intersect($codes, ['stripe', 'paypal']);
        if ($domestic && !$international) {
            return self::DOMESTIC;
        }
        if ($international) {
            return self::INTERNATIONAL;
        }
        return null;
    }

    /**
     * 切换版本
     *
     * @param string $edition international|domestic
     * @param bool $confirmed 有商品时必须显式确认
     * @param string $phrase 必须为 SWITCH
     * @return array<string,mixed>
     */
    public function switchEdition(string $edition, bool $confirmed, string $phrase): array
    {
        if (AppContext::getAdminRole() !== AdminRole::SUPER) {
            throw new BizException('仅平台超管可切换站点版本');
        }
        $edition = strtolower(trim($edition));
        if (!in_array($edition, [self::INTERNATIONAL, self::DOMESTIC], true)) {
            throw new BizException('站点版本无效');
        }
        if ($phrase !== 'SWITCH') {
            throw new BizException('请输入 SWITCH 确认切换');
        }

        $initialized = $this->isInitialized();
        if ($initialized && $edition === site_edition()) {
            return $this->summary();
        }
        if ($initialized) {
            if ((int) Order::count() > 0) {
                throw new BizException('已有历史订单，版本切换需走迁移流程，不能直接切换');
            }
            if ((int) Product::count() > 0 && !$confirmed) {
                throw new BizException('已有商品，请先备份并确认价格/文案需要重新维护');
            }
        } elseif (!$confirmed) {
            throw new BizException('请先备份数据库，并确认现有数据所属的历史版本');
        }

        $baseLocale = $edition === self::DOMESTIC ? 'zh' : 'en';
        $baseCurrency = $edition === self::DOMESTIC ? 'CNY' : 'USD';
        $language = Language::where('code', $baseLocale)->find();
        $currency = Currency::where('code', $baseCurrency)->find();
        if (!$language || !$currency) {
            throw new BizException('基准语言或基准币种不存在，请先执行数据库迁移');
        }

        Db::startTrans();
        try {
            SettingService::set('site.edition', $edition);
            SettingService::set('i18n.enabled', $edition === self::DOMESTIC ? '0' : '1');
            SettingService::set('i18n.default_locale', $baseLocale);
            SettingService::set('currency.enabled', $edition === self::DOMESTIC ? '0' : '1');
            SettingService::set('currency.default_code', $baseCurrency);

            // 基准语言：同一时间只有一个 is_default
            foreach (Language::select() as $row) {
                $row->is_default = strtolower((string) $row->code) === $baseLocale ? 1 : 0;
                if (strtolower((string) $row->code) === $baseLocale) {
                    $row->status = 1;
                }
                $row->save();
            }

            // 基准币种：同一时间只有一个 is_base
            foreach (Currency::select() as $row) {
                $row->is_base = strtoupper((string) $row->code) === $baseCurrency ? 1 : 0;
                if (strtoupper((string) $row->code) === $baseCurrency) {
                    $row->status = 1;
                }
                $row->save();
            }

            // 旧版本升级：首次选择历史数据版本时，补齐订单/支付单的币种快照
            if (!$initialized) {
                $this->backfillLegacy($edition, $baseCurrency);
            }

            Db::commit();
        } catch (\Throwable $e) {
            Db::rollback();
            throw $e;
        }

        (new LanguageService())->flush();
        (new CurrencyService())->flush();
        SettingService::flush();

        return $this->summary();
    }

    /**
     * 兼容 1.0.6 及更早版本的订单数据
     *
     * 旧版本没有 charge_currency：升级迁移默认写成 USD。
     * 首次选择历史数据版本时按用户选择回填，避免国内版历史订单显示成 USD。
     */
    private function backfillLegacy(string $edition, string $baseCurrency): void
    {
        if ($edition === self::DOMESTIC) {
            $now = date('Y-m-d H:i:s');
            Db::name('order')->where('id', '>', 0)->update([
                'charge_currency'      => 'CNY',
                'display_currency'     => 'CNY',
                'display_rate'         => '1',
                'display_total_amount' => Db::raw('total_amount'),
                'display_rate_at'      => Db::raw("IFNULL(create_time, '{$now}')"),
            ]);
        } else {
            Db::name('order')->where('id', '>', 0)->update(['charge_currency' => 'USD']);
        }

        Db::name('order_pay')->where('id', '>', 0)->update(['charge_currency' => $baseCurrency]);
    }
}