# DoyeCart 管理 API 使用说明（给 AI 助手 / 脚本作者）

配合 [`admin-api.md`](./admin-api.md) 使用。接口文档讲"有哪些接口、字段是什么"，本文讲"按什么顺序做、哪里会翻车"。

---

## 0. 开始前先问用户两件事

1. **站点地址**，如 `https://www.example.com`（不带结尾斜杠）
2. **API 密钥**，`dak_` 开头，后台「密钥管理」创建，**明文只显示一次**

其余信息都能从接口查到，不要凭猜测开始。

下文用 `<BASE>` 表示 `站点地址 + /admin-api/v1`，例如 `https://www.example.com/admin-api/v1`。

---

## 1. 认证与响应约定

- 认证只认请求头：`Authorization: Bearer <API 密钥>`（兼容 `X-API-Key`）。
  **把密钥放进 query 参数一律 401**，不要试。
- 只走 HTTPS。
- **HTTP 状态码恒为 200**，成败看响应体：`code:0` 成功，`code:1` 业务失败（以 `message` 为准）。
- 401 未认证/密钥失效、403 被安全策略拦截、429 限流（默认 120 次/分钟/IP）。
- 分页返回 `{list, total, page, page_size}`，`page_size` 默认 20、最大 100。
- 金额是两位小数字符串，时间格式 `Y-m-d H:i:s`。

自检：`GET /me` 返回当前账号、角色和密钥信息，开工前先跑一次确认密钥可用。

---

## 2. 商品字段（`POST/PUT /products`）

### 必填

`title`、`category_id`、`main_image`；**创建**还必须有至少 1 条 `skus`。

> `PUT` 也校验这三项——只改 SEO 或详情时，先 `GET /products/:id` 取原值一并提交，否则返回 `code:1 商品名称、分类和主图不能为空`。

### 图片分两处，不要混

| 字段 | 用途 | 限制 |
|---|---|---|
| `main_image` | 列表/卡片主图 | 单张，取展示图第一张 |
| `images_json` | 展示图集（详情页轮播） | 数组，主图排第一位，最多 10 张 |
| `detail_html` | 商品描述正文 | **只放文字**：`h2/h3/ul/ol/p/strong`，不要 `<img>`/`<iframe>`/`<video>` |

- 图片地址传**相对路径** `/uploads/products/images/YYYYMM/<hash>.jpg`。
  传本站绝对 URL 会被当外链重新下载转存，磁盘上多一份重复文件。
- 文件名后缀统一 `.jpg`（服务端存盘取上传文件名）。
- 上传接口：`POST /media/upload`，`multipart/form-data`，字段 `file`、`type=image`、`namespace=products`。
  返回的 `data` **可能是对象也可能是数组**，两种形态都要兼容；`url` 是相对路径，拼域名后 `HEAD` 校验 `200` + `image/jpeg`。

### SEO 与路径

- `seo_title`、`seo_description`（≤160 字符）、`seo_keywords`（**必填，不传即空**）、`tags`（数组）。
- `custom_path`：自定义路径，形如 `my-product.html`。只允许 `a-z0-9-`，不能纯数字，不能撞 `products`/`cart`/`about` 等保留字，**全局唯一**。
- `custom_path_root=1` 时同时注册根级路径 `/my-product/`。
- **前台 URL 会去掉 `.html`**：`my-product.html` → `/my-product`，两种写法都能打开。

### 状态与规格

- `status`：`0` 草稿 / `1` 上架 / `2` 下架。批量改状态：`POST /products/:id/status` body `{status:0|1|2}`。
- 规格：`specs_json` + `skus[{spec_name, spec_values_json, price, stock, sku_code, status}]`。
  **无规格商品**写 `specs_json: []` + 单条 `spec_name:'Default'`，服务端会归一成「默认规格」，这是预期行为。
- 规格值可关联展示图（可选）：`specs_json[{name, values, value_images:{规格值: 图片URL}}]`，
  图片必须是该商品 `images_json` 里的展示图（不能是主图/视频），一个值一张图，多个值可共用；非法 URL 返回 `code:1`。
  外链 / data URI 展示图会先转存为本地地址，`value_images` 填同一原始地址即可自动映射。
- 改动规格结构必须显式传 `spec_change_confirmed: 1`，否则 `code:1`。
- `sku_code` **服务端不校验唯一**，需要自己查重。
- 价格/库存落在 SKU 上；商品行的 `price` 可能是 `null`，列表接口会聚合显示。

### 多语种

主表只存英文。**商品创建后系统自动跑 AI 翻译**（`zh/ru/fr/ar/ja/it/de/pt/es`，`translations[lang].source = 'ai'`），几分钟内落地，不需要手动触发。
`PUT` 不传 `translations` 不会清空已有译文；反过来，别为了"补翻译"重复调 `POST /products/:id/translations/:lang/ai`（`force=1` 会覆盖人工稿）。

---

## 3. 批量发布流程

```
盘点素材 → 定主图与展示顺序 → 分类 → 图片转 .jpg → 上传 → 写文案 → 建 1 个试跑 → 回读校验 → 批量建其余
```

1. **分类**：`GET /categories` 取现有分类（默认树，`flat=1` 平铺）。装不下就 `POST /categories` `{name, parent_id:0, sort}` 新建（仅平台超管），**回读拿 id 再填 `category_id`**，不要按顺序猜。
2. **主图**：展示顺序 = `images_json` 顺序，主图必须第一。无法看图时按命名推：`zt.jpg`/`主图.jpg`/`zong.jpeg` 优先，否则取文件名里数字最小的（`z.jpg` 比 `z02.jpg` 小）。
3. **上传**：分批，每张成功立刻把 `staged → url` 映射写盘。执行环境通常有 300 秒硬超时，一次跑几十张会中断且丢进度。
4. **文案**：按素材（如 `简介.txt`）改写成目标语言，`detail_html` 4–6 个分节，纯文字。
5. **先建 1 个**，`GET /products/:id` 逐字段核对无误，再批量建其余——一起建只会把同一个错误复制 N 遍。
6. **收尾**：见下方校验清单。

---

## 4. 首页推荐位（banner）

`GET /home-ops` 聚合返回 `banners / categories / notices / topics / products`。

banner 字段：`image`、`title`、`subtitle`、`link_type`、`link_target`、`sort`、`status`。

| 操作 | 接口 |
|---|---|
| 建 | `POST /home-ops/banners` |
| 改 | `PUT /home-ops/banners/:id` |
| 上下线 | `POST /home-ops/banners/:id/status` `{status:0|1}` |
| 删 | `DELETE /home-ops/banners/:id` |

- `link_type` 只支持 `product` / `category` / `page` / `topic` / `none`。
  `product` 的 `link_target` 填**商品 id（数字）**，`category` 填分类 id，`page`/`topic` 填路径。
- **商品未上架时链接解析为空**，首页 hero 不渲染 CTA 按钮。所以 banner 可以先建好并置 `status=0`，等商品上架后再开。
- **首页一次只渲染 `banners[0]`**（排序 `sort asc, id asc`）。同一时刻只有排序最靠前的一条能出现在 hero，多余的建了也不会显示；要做轮播得改模板。

---

## 5. 其他接口速查

| 功能 | 接口 |
|---|---|
| 身份自检 / 密钥自助 | `GET /me`、`GET/POST /keys`、`DELETE /keys/:id` |
| 媒体上传 | `POST /media/upload`、`/media/base64`、`/media/import` |
| 分类 | `GET/POST/PUT/DELETE /categories`（写操作仅超管） |
| 站点单页（CMS） | `GET /pages`、`GET/POST/PUT /pages`、`POST /pages/:id/status`（仅超管） |
| 品牌 | `GET /brands`、`/brands/options`、`POST/PUT/DELETE /brands` |
| 订单 | `GET /orders`、`/orders/:order_no`、`POST .../ship`、`.../deliver` |
| 优惠券 | `GET/POST/PUT/DELETE /coupons`（仅超管） |
| 设置 / 币种 / 审计 / 更新 / 安全 | `/settings`、`/currencies`、`/audit-logs`、`/updates`、`/security`（仅超管） |

> `GET /media/list`、`media/delete` 在本系统**不存在**（会返回 500 `controller not exists`）。

### 站点单页（CMS）

配送说明、退换货、隐私政策、服务条款、Cookie 政策这类静态页存在 `page` 表，前台按 `slug` 渲染成 `/<slug>`。

- 建：`POST /pages`，必填 `title` + `slug`（小写字母/数字/中划线，非保留字，全局唯一）。
- 改：`PUT /pages/:id`——**必须提交完整字段**，漏掉 `content` 会被清空。
- 上下线：`POST /pages/:id/status {status:0|1}`；下线后前台回到占位文案「This page is not configured yet」。
- `content` 存原始 HTML，不做二次过滤（只有超管能写）；主题**没有** `.cms-content` 的表格样式，表格要自带内联样式。
- 页面标题由模板拼成 `seo_title + " - <品牌名>"`，`seo_title` 里别再写品牌名。

---

## 6. 回读校验清单（建完必做）

对每个商品 `GET /products/:id`：

1. `title` / `subtitle` / `category_id` 与提交一致
2. `main_image == images_json[0]`，`images_json` 顺序与预期逐位相等
3. 每张图 `HEAD` → `200` + `image/jpeg`
4. `detail_html` 与提交串**逐字相等**，且不含 `<img`
5. `seo_*` 与 `tags` 回读相等，`seo_description` ≤160
6. `custom_path` 唯一，`custom_path_root` 符合预期
7. `status` 正确；`price`/`stock` 从 `skus[0]` 读
8. **SKU 编码全局查重**
9. 前台验证：草稿 slug 返回 404 属正常；用**已上架**商品的 URL 确认路由通

---

## 7. 铁律与常见坑

1. **只用 API，不要试图登录后台点按钮**；要看前台效果就用 HTTP GET 抓页面。
2. 业务失败**先读 `message`**；写操作重试前先读一次，确认是否已落库，避免重复创建。
3. **不编造价格、库存、分类**——素材里通常没有价格，缺信息先问用户。
4. 批量操作前**先出计划并确认三件事**：价格与库存、分类归属、上架状态（默认存草稿）。
5. 上传接口的 `data` 形态不固定（对象 / 数组），代码要兼容，否则 `KeyError: 0`。
6. 一次性跑大批量上传会撞 300 秒超时且丢进度：分批 + 每张落盘。
7. 中文目录名做 slug 会得到空串，导致所有产品写进同一目录互相覆盖——先定好英文 slug 再落盘。
8. 试跑商品和批量循环各自生成 SKU 编码时最容易撞号，收尾必须查重。
9. 草稿商品前台 404 不是路由坏了。
10. 根目录的 banner/广告图不属于商品，不要顺手收进 `images_json`。

---

## 8. 一份最小可用示例

```bash
BASE="https://www.example.com/admin-api/v1"
KEY="dak_xxxxxxxxxxxxxxxx"

# 1) 认证自检
curl -s "$BASE/me" -H "Authorization: Bearer $KEY"

# 2) 取分类，拿 category_id
curl -s "$BASE/categories" -H "Authorization: Bearer $KEY"

# 3) 上传一张图（返回的 url 是相对路径）
curl -s -X POST "$BASE/media/upload" -H "Authorization: Bearer $KEY" \
  -F "file=@C:/path/to/01.jpg" -F "type=image" -F "namespace=products"

# 4) 建草稿商品
curl -s -X POST "$BASE/products" \
  -H "Authorization: Bearer $KEY" -H "Content-Type: application/json" \
  -d '{
    "title": "Example Product",
    "subtitle": "One-line selling point.",
    "category_id": 1,
    "merchant_id": 1,
    "brand_id": 0,
    "main_image": "/uploads/products/images/202611/xxxxxxxx.jpg",
    "images_json": ["/uploads/products/images/202611/xxxxxxxx.jpg"],
    "detail_html": "<h2>Example Product</h2><p>Description text only.</p>",
    "status": 0,
    "seo_title": "Example Product | Brand",
    "seo_description": "Short description under 160 characters.",
    "seo_keywords": "keyword one, keyword two, keyword three",
    "tags": ["tag one", "tag two"],
    "custom_path": "example-product.html",
    "custom_path_root": 1,
    "specs_json": [],
    "skus": [{"spec_name": "Default", "spec_values_json": {}, "price": "19.99", "stock": 100, "sku_code": "SKU-001", "status": 1}]
  }'

# 5) 回读校验
curl -s "$BASE/products/12" -H "Authorization: Bearer $KEY"

# 6) 上架
curl -s -X POST "$BASE/products/12/status" -H "Authorization: Bearer $KEY" \
  -H "Content-Type: application/json" -d '{"status":1}'
```
