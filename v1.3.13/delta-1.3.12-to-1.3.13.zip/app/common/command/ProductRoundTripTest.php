<?php
declare(strict_types=1);

namespace app\common\command;

use app\common\enum\AdminRole;
use app\common\exception\BizException;
use app\common\model\Category;
use app\common\model\Merchant;
use app\common\service\AdminCrudService;
use app\common\support\AppContext;
use think\console\Command;
use think\console\Input;
use think\console\input\Option;
use think\console\Output;
use think\facade\Db;

class ProductRoundTripTest extends Command
{
    protected function configure(): void
    {
        $this->setName('product:roundtrip')
            ->addOption('allow-test-db', null, Option::VALUE_NONE, 'Confirm this command may write temporary test rows')
            ->setDescription('Verify product media, rich text, two-dimension SKU persistence and merchant isolation');
    }

    protected function execute(Input $input, Output $output): int
    {
        if (!$input->getOption('allow-test-db')) {
            $output->writeln('<error>Refusing to run without --allow-test-db.</error>');
            return 1;
        }

        $merchant = Merchant::find(1);
        $category = Category::find(1);
        if (!$merchant || !$category) {
            $output->writeln('<error>Requires existing merchant ID 1 and category ID 1.</error>');
            return 1;
        }

        $mediaDirectory = public_path() . 'uploads/products/images/';
        $videoDirectory = public_path() . 'uploads/products/videos/';
        $month = date('Ym');
        $directory = $mediaDirectory . $month . '/';
        $videoPath = $videoDirectory . $month . '/';
        if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
            $output->writeln('<error>Cannot create test media directory.</error>');
            return 1;
        }
        if (!is_dir($videoPath) && !mkdir($videoPath, 0755, true) && !is_dir($videoPath)) {
            $output->writeln('<error>Cannot create test video directory.</error>');
            return 1;
        }
        $filename = bin2hex(random_bytes(16)) . '.png';
        $videoFilename = bin2hex(random_bytes(16)) . '.mp4';
        $url = '/uploads/products/images/' . $month . '/' . $filename;
        $videoUrl = '/uploads/products/videos/' . $month . '/' . $videoFilename;
        $pixel = base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/pZsAAAAASUVORK5CYII=');
        if (file_put_contents($directory . $filename, $pixel) === false) {
            $output->writeln('<error>Cannot write test media file.</error>');
            return 1;
        }
        if (file_put_contents($videoPath . $videoFilename, "\x00\x00\x00\x18ftypisom\x00\x00\x02\x00isomiso2") === false) {
            @unlink($directory . $filename);
            $output->writeln('<error>Cannot write test video file.</error>');
            return 1;
        }

        $previousRole = AppContext::getAdminRole();
        $previousMerchantIds = AppContext::getMerchantIds();
        Db::startTrans();
        try {
            AppContext::setAdminRole(AdminRole::SUPER);
            AppContext::setMerchantIds([]);
            $service = new AdminCrudService();
            $saved = $service->saveProduct([
                'title' => 'roundtrip-' . bin2hex(random_bytes(6)),
                'category_id' => (int) $category->id,
                'merchant_id' => (int) $merchant->id,
                 'main_image' => $url,
                 'images_json' => json_encode([$url]),
                 'video_url' => $videoUrl,
                 'video_meta_json' => json_encode(['size' => 1234, 'mime' => 'video/mp4', 'duration' => 9]),
                 'detail_html' => '<p>Round-trip <strong>rich text</strong><script>alert(1)</script><a href="//evil.example">bad link</a><img src="javascript:alert(1)" onerror="alert(2)"></p>',
                'specs_json' => json_encode([
                    ['name' => 'Color', 'values' => ['Red', 'Blue'], 'value_images' => ['Red' => $url]],
                    ['name' => 'Size', 'values' => ['S', 'M']],
                ]),
                'skus' => json_encode([
                    ['spec_values_json' => ['Color' => 'Red', 'Size' => 'S'], 'price' => '10.00', 'stock' => 3, 'sku_code' => 'RT1', 'status' => 1],
                    ['spec_values_json' => ['Color' => 'Red', 'Size' => 'M'], 'price' => '11.00', 'stock' => 4, 'sku_code' => 'RT2', 'status' => 1],
                    ['spec_values_json' => ['Color' => 'Blue', 'Size' => 'S'], 'price' => '12.00', 'stock' => 5, 'sku_code' => 'RT3', 'status' => 1],
                    ['spec_values_json' => ['Color' => 'Blue', 'Size' => 'M'], 'price' => '13.00', 'stock' => 6, 'sku_code' => 'RT4', 'status' => 1],
                ]),
                'status' => 0,
            ]);

            $detail = $service->productDetail((int) $saved->id);
             if ($detail['main_image'] !== $url || $detail['images_json'] !== [$url]
                 || $detail['video_url'] !== $videoUrl
                || $detail['video_meta_json']['duration'] !== 9
                 || str_contains($detail['detail_html'], 'script') || str_contains($detail['detail_html'], 'javascript') || str_contains($detail['detail_html'], 'onerror') || str_contains($detail['detail_html'], '//evil.example')
                || count($detail['specs_json']) !== 2 || count($detail['skus']) !== 4
                || ($detail['specs_json'][0]['value_images']['Red'] ?? '') !== $url) {
                throw new \RuntimeException('Product media, rich text, SKU, or spec image round-trip failed.');
            }

            $skuCount = (int) Db::name('product_sku')->where('product_id', $saved->id)->count();
            $edited = $service->saveProduct([
                'title' => $saved->title . '-edited', 'category_id' => (int) $category->id,
                 'merchant_id' => (int) $merchant->id, 'main_image' => $url, 'images_json' => json_encode([$url]),
                 'video_url' => $videoUrl,
                'video_meta_json' => json_encode(['size' => 5678, 'mime' => 'video/mp4', 'duration' => 12]),
                'detail_html' => $detail['detail_html'], 'specs_json' => json_encode($detail['specs_json']),
                'skus' => json_encode($detail['skus']), 'status' => 0, 'spec_change_confirmed' => '0',
            ], (int) $saved->id);
            if ((int) Db::name('product_sku')->where('product_id', $saved->id)->count() !== $skuCount) {
                throw new \RuntimeException('Editing a product created duplicate SKUs.');
            }
            try {
                $service->saveProduct([
                    'title' => 'should-reject-spec-image', 'category_id' => (int) $category->id,
                    'merchant_id' => (int) $merchant->id, 'main_image' => $url,
                    'images_json' => json_encode([]),
                    'specs_json' => json_encode([
                        ['name' => 'Color', 'values' => ['Red'], 'value_images' => ['Red' => $url]],
                    ]),
                    'skus' => json_encode([
                        ['spec_values_json' => ['Color' => 'Red'], 'price' => '10.00', 'stock' => 1, 'status' => 1],
                    ]),
                    'status' => 0,
                ], (int) $saved->id);
                throw new \RuntimeException('Spec image outside the product gallery was accepted.');
            } catch (BizException $e) {
                if (!str_contains($e->getMessage(), '必须来自商品展示图片')) throw $e;
            }
            $editedTitle = (string) $edited->title;
             $skuIds = Db::name('product_sku')->where('product_id', $saved->id)->column('id');
             Db::name('cart')->insert(['user_id' => 1, 'sku_id' => $skuIds[0], 'quantity' => 1, 'selected' => 1]);
             try {
                 $service->saveProduct([
                     'title' => 'should-rollback', 'category_id' => (int) $category->id,
                     'merchant_id' => (int) $merchant->id, 'main_image' => $url,
                     'video_url' => $videoUrl, 'images_json' => json_encode([$url]),
                     'specs_json' => json_encode([['name' => 'Color', 'values' => ['Red']]]),
                     'skus' => json_encode([['spec_values_json' => ['Color' => 'Red'], 'price' => '10.00', 'stock' => 3, 'status' => 1]]),
                     'spec_change_confirmed' => '1', 'status' => 0,
                 ], (int) $saved->id);
                 throw new \RuntimeException('Transactional product save was accepted.');
             } catch (BizException $e) {
                 $persisted = Db::name('product')->where('id', $saved->id)->value('title');
                 if ((string) $persisted !== $editedTitle
                     || (int) Db::name('product_sku')->where('product_id', $saved->id)->count() !== $skuCount) {
                     throw new \RuntimeException('Unexpected rollback state.');
                 }
             } finally {
                 Db::name('cart')->where('sku_id', $skuIds[0])->delete();
             }

             $invalidInputs = [
                 [
                     ['spec_values_json' => ['Color' => 'Red', 'Size' => 'S'], 'price' => '-1', 'stock' => 3, 'status' => 1],
                 ],
                 [
                     ['spec_values_json' => ['Color' => 'Red', 'Size' => 'S'], 'price' => '10', 'stock' => 3, 'status' => 1],
                     ['spec_values_json' => ['Color' => 'Red', 'Size' => 'S'], 'price' => '11', 'stock' => 3, 'status' => 1],
                 ],
             ];
             foreach ($invalidInputs as $invalidSkus) {
                 try {
                     $service->saveProduct([
                         'title' => $editedTitle, 'category_id' => (int) $category->id,
                         'merchant_id' => (int) $merchant->id, 'main_image' => $url,
                         'video_url' => $videoUrl, 'images_json' => json_encode([$url]),
                         'specs_json' => json_encode([['name' => 'Color', 'values' => ['Red']], ['name' => 'Size', 'values' => ['S']]]),
                         'skus' => json_encode($invalidSkus), 'spec_change_confirmed' => '1', 'status' => 0,
                     ], (int) $saved->id);
                     throw new \RuntimeException('Invalid SKU input was accepted.');
                 } catch (BizException $e) {
                     // Negative values and duplicate combinations must be rejected before persistence.
                 }
             }

            AppContext::setAdminRole(AdminRole::MERCHANT_ADMIN);
            AppContext::setMerchantIds([(int) $merchant->id + 999999]);
            try {
                $service->productDetail((int) $saved->id);
                throw new \RuntimeException('Merchant isolation failed: cross-merchant product was readable.');
            } catch (BizException $e) {
                if ($e->getMessage() !== '商品不存在') throw $e;
            }

            Db::rollback();
            $output->writeln('<info>OK: media/rich-text/two-dimension SKU round-trip and merchant isolation.</info>');
            return 0;
        } catch (\Throwable $e) {
            Db::rollback();
            $output->writeln('<error>' . $e->getMessage() . '</error>');
            return 1;
        } finally {
            AppContext::clear();
            if ($previousRole !== null) AppContext::setAdminRole($previousRole);
            if (!empty($previousMerchantIds)) AppContext::setMerchantIds($previousMerchantIds);
            if (is_file($directory . $filename)) @unlink($directory . $filename);
            if (is_file($videoPath . $videoFilename)) @unlink($videoPath . $videoFilename);
        }
    }
}
