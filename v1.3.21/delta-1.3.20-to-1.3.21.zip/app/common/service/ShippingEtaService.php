<?php
declare(strict_types=1);

namespace app\common\service;

/**
 * 商品发货时效规则（海外仓）
 *
 * 本类是全站唯一的规则来源：海外仓白名单、仓覆盖国家、配送区域 → 仓映射、
 * 国家选择器分组、时效天数与展示文案。控制器 / 模板 / 管理 API 只调用这里，
 * 不要各写一份映射。
 *
 * 两套「目的地」语义并存，不要混用：
 * - 配送区域（REGIONS / normalizeRegion()）：商品详情页「配送至」下拉与时效计算入口；
 * - 国家码（countries() / normalize()）：收货地址表单与地址 API 的 ISO2 校验。
 */
class ShippingEtaService
{
    /** 海外仓白名单（固定顺序：多仓命中同一目的地时按此顺序取第一个） */
    public const WAREHOUSES = ['north_america', 'germany', 'korea'];

    /** 各海外仓覆盖的国家（ISO2） */
    public const COVERAGE = [
        'north_america' => ['US', 'CA', 'MX'],
        'germany'       => [
            'AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR',
            'HU', 'IE', 'IT', 'LV', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK',
            'SI', 'ES', 'SE', 'GB',
        ],
        'korea'         => ['KR'],
    ];

    /** 「其他国家」哨兵值：不算海外仓，按卖家发货计算 */
    public const OTHER_COUNTRY = 'OTHER';

    /**
     * 配送区域（详情页「配送至」下拉，顺序即下拉顺序）
     *
     * warehouse 为该区域对应的海外仓；null = 不做海外仓，按卖家发货计算。
     * 区域 → 仓的映射只在这里定义，前端只消费服务端算好的文案。
     */
    public const REGIONS = [
        'north_america' => ['warehouse' => 'north_america'],
        'europe'        => ['warehouse' => 'germany'],
        'asia'          => ['warehouse' => null],
        'korea'         => ['warehouse' => 'korea'],
        'south_america' => ['warehouse' => null],
        'africa'        => ['warehouse' => null],
        'other'         => ['warehouse' => null],
    ];

    /**
     * 国家英文标准名（本版不做国家名翻译，选择器直接展示）
     * 同时充当国家码合法集合：只有出现在这里的国家码才被接受
     */
    private const COUNTRY_NAMES = [
        // North America
        'US' => 'United States',
        'CA' => 'Canada',
        'MX' => 'Mexico',
        // Europe（EU27 + GB）
        'AT' => 'Austria',
        'BE' => 'Belgium',
        'BG' => 'Bulgaria',
        'HR' => 'Croatia',
        'CY' => 'Cyprus',
        'CZ' => 'Czechia',
        'DK' => 'Denmark',
        'EE' => 'Estonia',
        'FI' => 'Finland',
        'FR' => 'France',
        'DE' => 'Germany',
        'GR' => 'Greece',
        'HU' => 'Hungary',
        'IE' => 'Ireland',
        'IT' => 'Italy',
        'LV' => 'Latvia',
        'LT' => 'Lithuania',
        'LU' => 'Luxembourg',
        'MT' => 'Malta',
        'NL' => 'Netherlands',
        'PL' => 'Poland',
        'PT' => 'Portugal',
        'RO' => 'Romania',
        'SK' => 'Slovakia',
        'SI' => 'Slovenia',
        'ES' => 'Spain',
        'SE' => 'Sweden',
        'GB' => 'United Kingdom',
        // Asia
        'KR' => 'South Korea',
        // 兜底
        'OTHER' => 'Other countries',
    ];

    /**
     * 选择器分组：分组 key => 取哪个仓的覆盖国家
     * other 组单独追加（只有 OTHER 一项）
     */
    private const GROUPS = [
        'north_america' => 'north_america',
        'europe'        => 'germany',
        'asia'          => 'korea',
    ];

    /**
     * 国家选择器数据（optgroup 结构）
     *
     * @return array<int,array{key:string,label:string,countries:array<int,array{code:string,name:string}>}>
     */
    public function countries(): array
    {
        $groups = [];

        foreach (self::GROUPS as $groupKey => $warehouse) {
            $items = [];
            foreach (self::COVERAGE[$warehouse] as $code) {
                $items[] = ['code' => $code, 'name' => $this->countryName($code)];
            }

            $groups[] = [
                'key'       => $groupKey,
                'label'     => site_lang('shipping.zone.' . $groupKey),
                'countries' => $items,
            ];
        }

        $groups[] = [
            'key'       => 'other',
            'label'     => site_lang('shipping.zone.other'),
            'countries' => [
                ['code' => self::OTHER_COUNTRY, 'name' => $this->countryName(self::OTHER_COUNTRY)],
            ],
        ];

        return $groups;
    }

    /**
     * 配送区域列表（详情页「配送至」下拉，7 项固定顺序）
     *
     * label 走 shipping.region.*；韩国项文案含品牌 Coupang（各语种不翻译品牌名），
     * 但 textForRegion() 的时效文案仍用 shipping.warehouse.korea（韩国仓）。
     *
     * @return array<int,array{code:string,label:string}>
     */
    public function regions(): array
    {
        $regions = [];
        foreach (array_keys(self::REGIONS) as $code) {
            $regions[] = ['code' => $code, 'label' => site_lang('shipping.region.' . $code)];
        }

        return $regions;
    }

    /**
     * 归一化配送区域：区域码优先，其次兼容旧的 ISO2 / OTHER 值，都不命中返回 null
     *
     * 旧 cookie / 旧链接（?ship_to=DE、?ship_to=OTHER）因此仍可用，由调用方重写为区域码。
     * 注意本方法接受区域码，地址 API 的 ISO2 校验必须继续用 normalize()。
     */
    public function normalizeRegion(string $value): ?string
    {
        $value = strtolower(trim($value));
        if ($value === '') {
            return null;
        }

        // 区域码优先：避免与 ISO2 混淆（区域码都是小写长名）
        if (array_key_exists($value, self::REGIONS)) {
            return $value;
        }

        // 兼容旧值：合法国家码（含 OTHER）映射到区域
        $country = $this->normalize($value);

        return $country === null ? null : $this->regionOfCountry($country);
    }

    /**
     * 归一化国家码：大写去空白，命中覆盖国家或 OTHER 才返回，否则 null
     */
    public function normalize(string $code): ?string
    {
        $code = strtoupper(trim($code));
        if ($code === '') {
            return null;
        }

        return array_key_exists($code, self::COUNTRY_NAMES) ? $code : null;
    }

    /**
     * 站点默认收货国家（配置非法时回落 US）
     */
    public function defaultCountry(): string
    {
        $configured = (string) site_config('shipping.default_country', 'US');

        return $this->normalize($configured) ?? 'US';
    }

    /**
     * 站点默认配送区域（默认 country 非法时回落 US => north_america）
     */
    public function defaultRegion(): string
    {
        return $this->regionOfCountry($this->defaultCountry());
    }

    /**
     * 海外仓发货时效（工作日）
     */
    public function overseasDays(): int
    {
        return max(1, (int) site_config('shipping.eta_overseas_days', 7));
    }

    /**
     * 卖家（国内）发货时效（工作日）
     */
    public function sellerDays(): int
    {
        return max(1, (int) site_config('shipping.eta_seller_days', 14));
    }

    /**
     * 国家码所属配送区域
     *
     * US/CA/MX => north_america；GB + EU27（即 germany 仓覆盖）=> europe；KR => korea；
     * OTHER / 空 / 未知国家 => other。复用 COVERAGE，不再维护第二份国家清单。
     *
     * 注意：反查按 REGIONS 声明顺序取第一个命中。若将来把欧洲再拆成两个区域并映射同一个
     * germany 仓，第二个区域永远反查不到；届时需要为地址映射单独声明优先级。
     */
    public function regionOfCountry(string $country): string
    {
        $code = $this->normalize($country);
        if ($code === null || $code === self::OTHER_COUNTRY) {
            return 'other';
        }

        foreach (self::REGIONS as $region => $config) {
            $warehouse = $config['warehouse'];
            if ($warehouse !== null && in_array($code, self::COVERAGE[$warehouse], true)) {
                return $region;
            }
        }

        return 'other';
    }

    /**
     * 计算发货时效（按配送区域）
     *
     * 区域对应的仓被商品持有 => 海外仓时效；否则（含无仓区域 / 商品无该仓）回落到卖家发货。
     * 区域非法或为空时按 other（卖家发货）处理。
     *
     * @param array<int,string> $warehouses 商品所属海外仓
     * @return array{warehouse:string|null,days:int}
     */
    public function estimate(array $warehouses, string $region): array
    {
        $region = $this->normalizeRegion($region) ?? 'other';
        $warehouse = self::REGIONS[$region]['warehouse'];
        if ($warehouse === null) {
            return ['warehouse' => null, 'days' => $this->sellerDays()];
        }

        foreach ($warehouses as $code) {
            if (is_string($code) && $code === $warehouse) {
                return ['warehouse' => $warehouse, 'days' => $this->overseasDays()];
            }
        }

        return ['warehouse' => null, 'days' => $this->sellerDays()];
    }

    /**
     * 仓名语言键（模板 / 后台提示复用）
     */
    public function warehouseLabelKey(string $code): string
    {
        return 'shipping.warehouse.' . $code;
    }

    /**
     * 指定商品 + 配送区域的最终时效文案（唯一判定入口）
     *
     * @param array<int,string> $warehouses 商品所属海外仓
     */
    public function textForRegion(array $warehouses, string $region): string
    {
        $eta = $this->estimate($warehouses, $region);
        if ($eta['warehouse'] !== null) {
            return site_lang('shipping.eta_warehouse', [
                'warehouse' => site_lang($this->warehouseLabelKey($eta['warehouse'])),
                'days'      => $eta['days'],
            ]);
        }

        return site_lang('shipping.eta_seller', ['days' => $eta['days']]);
    }

    /**
     * 指定商品的「区域码 => 时效文案」映射（供前台切换配送区域时直接查表）
     *
     * 规则只在本服务计算，前端不得再自行推导区域 → 仓。
     *
     * @param array<int,string> $warehouses 商品所属海外仓
     * @return array<string,string>
     */
    public function textsByRegion(array $warehouses): array
    {
        $texts = [];
        foreach (array_keys(self::REGIONS) as $code) {
            $texts[$code] = $this->textForRegion($warehouses, $code);
        }

        return $texts;
    }

    /**
     * 「国家码 => 区域码」映射（含 OTHER => other），供前端把默认收货地址映射到区域
     *
     * @return array<string,string>
     */
    public function countryRegions(): array
    {
        $map = [];
        foreach (array_keys(self::COUNTRY_NAMES) as $code) {
            $map[$code] = $this->regionOfCountry($code);
        }

        return $map;
    }

    /**
     * 国家英文标准名（未登记的国家码原样返回，避免出现空白选项）
     */
    private function countryName(string $code): string
    {
        return self::COUNTRY_NAMES[$code] ?? $code;
    }
}
