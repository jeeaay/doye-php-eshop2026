<?php
declare(strict_types=1);

namespace app\controller;

use app\common\service\CouponService;
use app\common\service\ProductRouteService;
use app\common\service\ReviewService;
use app\common\service\ShippingEtaService;
use think\facade\Cookie;

/**
 * 商品列表 / 详情（eshop2026 主题）
 *
 * 详情支持两种寻址：
 *   - /products/{id}、/product/{id}：数字 ID（保持兼容，不做 301）
 *   - /products/{custom_path}：后台「高级」选项卡配置的自定义访问路径
 *   - 根级 /{custom_path}/：由 Page/detail 解析后转发到本控制器
 */
class Product extends SiteBase
{
    public function list()
    {
        $categoryId = (int) $this->request->get('category_id', 0);
        $keyword = trim((string) $this->request->get('keyword', ''));
        $sort = (string) $this->request->get('sort', 'newest');
        if (!in_array($sort, ['newest', 'price-asc', 'price-desc', 'popular'], true)) {
            $sort = 'newest';
        }

        $brand = $this->store->brand();
        $result = $this->store->productCards(1, 120, $categoryId, $keyword, $sort);

        return $this->render('products', [
            'nav_active'      => 'products',
            'page_title'      => 'Products - ' . $brand['name'],
            'meta_desc'       => 'Browse our full range of home storage and organisation solutions.',
            'products'        => $result['list'],
            'total'           => $result['total'],
            'sort'            => $sort,
            'page_size'       => (int) site_config('per_page', 24),
            'categories'      => $this->store->categories(),
            'active_category' => $categoryId,
            'flash_promotions' => (new CouponService())->activePlatformPromotions(),
        ]);
    }

    public function detail($id = 0)
    {
        $param = trim((string) $id);
        if ($param === '' || $param === '0') {
            // 路由未绑定到有效参数（如 /products.html 被 url_html_suffix 剥离为 /products）
            return $this->notFound('Product not found');
        }

        if (ctype_digit($param)) {
            $product = $this->store->product((int) $param);
        } else {
            // 自定义访问路径：Redis 优先，MySQL 兜底（Redis 不可用时仍可访问）
            $productId = (new ProductRouteService())->resolve($param);
            $product = $productId !== null ? $this->store->product($productId) : null;
        }
        if (!$product) {
            return $this->notFound('Product not found');
        }

        $seoTitle = trim((string) ($product['seo_title'] ?? ''));
        $seoDescription = trim((string) ($product['seo_description'] ?? ''));
        if ($seoDescription === '') {
            $seoDescription = $product['brief'] !== ''
                ? $product['brief']
                : mb_substr(trim(strip_tags((string) $product['description'])), 0, 160);
        }
        $seoKeywords = trim((string) ($product['seo_keywords'] ?? ''));
        if ($seoKeywords === '') {
            $seoKeywords = implode(',', (array) ($product['tags'] ?? []));
        }

        // 页面标题：商品名称 - 副标题 - SEO 标题；缺失的部分自动省略
        $titleParts = array_filter([
            trim((string) ($product['name'] ?? '')),
            trim((string) ($product['brief'] ?? '')),
            $seoTitle,
        ], static fn (string $part): bool => $part !== '');
        // 首屏选中 SKU（与 site-pages.js 的默认 selectedSkuId 一致）：
        // 价格区与粘性购买条共用同一份展示文案，避免「服务端最低价 / 前端首个 SKU 价」两套口径
        $initialSku = $product['skus'][0] ?? null;
        $buyboxPrice = format_money($initialSku ? $initialSku['price'] : $product['price']);
        $buyboxOriginalRaw = (string) ($initialSku['original_price'] ?? '');
        $buyboxOriginal = ($buyboxOriginalRaw !== '' && (float) $buyboxOriginalRaw > (float) ($initialSku['price'] ?? 0))
            ? format_money($buyboxOriginalRaw)
            : '';

        $json = json_encode([
            'id'        => $product['id'],
            'name'      => $product['name'],
            'price'     => $product['price'],
            // 展示币种文案（换算 + 符号）；JS 不做汇率换算，只做取值替换
            'price_display' => format_money($product['price']),
            'image'     => $product['image'],
            'url'       => $product['url'],
            'brief'     => $product['brief'],
            'has_stock' => $product['has_stock'],
            'skus'      => array_map(static fn ($s) => [
                'id'        => $s['id'],
                'spec_name' => $s['spec_name'],
                'price'     => $s['price'],
                'price_display'    => format_money($s['price']),
                // 划线原价：数值用于「原价 > 售价」判断，文案用于直接渲染（空串 = 不展示）
                'original_price'   => (string) ($s['original_price'] ?? ''),
                'original_display' => (string) ($s['original_price'] ?? '') !== '' ? format_money($s['original_price']) : '',
                'stock'     => $s['stock'],
                // 规格值关联的展示图片（前台组合按钮缩略图 + 滚动联动）；无关联为空字符串
                'image'     => (string) ($s['image'] ?? ''),
            ], $product['skus']),
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        // canonical 指向自定义路径（填写 slug 时）；数字路径保持 200 不重定向
        $canonicalPath = storefront_product_url($product);

        // 评论：首屏服务端渲染（SEO / 无 JS 可用），筛选与加载更多由前端接管
        $reviewService = new ReviewService();
        $reviewSummary = $reviewService->summary((int) $product['id']);
        $reviewPage    = $reviewService->listApproved((int) $product['id'], [], 1, ReviewService::PAGE_SIZE);

        $vars = [
            'nav_active'   => 'products',
            'page_title'   => implode(' - ', $titleParts),
            'meta_desc'    => $seoDescription,
            'meta_keys'    => $seoKeywords,
            'meta_robots'  => (int) ($product['seo_noindex'] ?? 0) === 1 ? 'noindex,follow' : '',
            'product'      => $product,
            // 价格区首屏文案（无 JS 时也有价；有 original 时渲染划线价）
            'buybox_price'    => $buyboxPrice,
            'buybox_original' => $buyboxOriginal,
            'related_products' => $this->store->relatedProducts((int) $product['id'], (int) $product['category_id']),
            'product_json' => htmlspecialchars((string) $json, ENT_QUOTES, 'UTF-8'),
            'canonical_url'  => $this->canonicalUrl($canonicalPath),
            'hreflang_links' => $this->hreflangLinks($canonicalPath),
            'review_summary'   => $reviewSummary,
            'review_stars'     => $this->reviewStarStates((float) $reviewSummary['avg']),
            'reviews'          => $reviewPage['list'],
            'reviews_total'    => (int) $reviewPage['total'],
            'review_page_size' => ReviewService::PAGE_SIZE,
        ];

        // 配送时效模块只在国际版渲染（国内版保持原有文案）
        if (!is_domestic_edition()) {
            $shippingEta = new ShippingEtaService();
            $shipTo = $this->resolveShipTo($shippingEta);
            $warehouses = (array) ($product['warehouses'] ?? []);

            $vars['ship_to']           = $shipTo;
            $vars['regions']           = $shippingEta->regions();
            $vars['shipping_eta_text'] = $shippingEta->textForRegion($warehouses, $shipTo);
            // 免刷新切换区域：按「本商品仓库 × 区域」预生成文案，JS 只查表，不重算规则
            $vars['eta_by_region_json'] = $this->jsonAttribute(
                $shippingEta->textsByRegion($warehouses)
            );
            // 默认收货地址（国家级）由前端补：国家 → 区域映射同样由服务端下发
            $vars['region_by_country_json'] = $this->jsonAttribute(
                $shippingEta->countryRegions()
            );
        }

        $html = $this->render('product', $vars);
        if (!is_string($html)) {
            return $html;
        }

        // 页面内容随语种与 ship_to cookie 变化，避免 CDN 把 A 国页面缓存给 B 国
        return response($html)
            ->contentType('text/html')
            ->header(['Vary' => 'Accept-Language, Cookie']);
    }

    /**
     * 解析「配送至」区域
     *
     * 优先级：?ship_to（合法则写 cookie 1 年，视为用户显式选择）> ship_to cookie > 站点默认区域。
     * 合法的旧值（ISO2 国家码 / OTHER，如 ?ship_to=DE、旧 cookie）会映射为区域码并重写 cookie；
     * 非法 query 值忽略且不写 cookie。
     */
    private function resolveShipTo(ShippingEtaService $service): string
    {
        $queryCode = $this->request->get('ship_to', '');
        $fromQuery = $service->normalizeRegion(is_scalar($queryCode) ? (string) $queryCode : '');
        if ($fromQuery !== null) {
            Cookie::set('ship_to', $fromQuery, 31536000);

            return $fromQuery;
        }

        $cookieRaw = Cookie::get('ship_to', '');
        $cookieRaw = is_scalar($cookieRaw) ? (string) $cookieRaw : '';
        $fromCookie = $service->normalizeRegion($cookieRaw);
        if ($fromCookie === null) {
            // 非法残留 cookie 会让前端误以为用户已显式选择，清掉以恢复默认地址推断
            if (trim($cookieRaw) !== '') {
                Cookie::delete('ship_to');
            }

            return $service->defaultRegion();
        }

        // 旧 cookie（ISO2 / OTHER）已被映射为区域码：重写一次，后续请求不再重复映射
        if (strtolower(trim($cookieRaw)) !== $fromCookie) {
            Cookie::set('ship_to', $fromCookie, 31536000);
        }

        return $fromCookie;
    }

    /**
     * data-* 属性用的 JSON：只 htmlspecialchars 一次（模板用 |raw，双重转义会让 JSON.parse 失败）
     */
    private function jsonAttribute(array $data): string
    {
        return htmlspecialchars(
            (string) json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            ENT_QUOTES,
            'UTF-8'
        );
    }

    /**
     * 5 颗星的展示状态：满星 → 半星 → 空星（空星复用 star.svg + opacity）
     *
     * @param float $avg 平均分（0-5，1 位小数）
     * @return array<int,string> 长度恒为 5，值 ∈ full|half|empty
     */
    private function reviewStarStates(float $avg): array
    {
        $avg  = max(0.0, min(5.0, $avg));
        $full = (int) floor($avg);
        $half = ($avg - $full) >= 0.5 ? 1 : 0;
        $empty = max(0, 5 - $full - $half);

        return array_merge(
            array_fill(0, $full, 'full'),
            $half === 1 ? ['half'] : [],
            array_fill(0, $empty, 'empty')
        );
    }
}