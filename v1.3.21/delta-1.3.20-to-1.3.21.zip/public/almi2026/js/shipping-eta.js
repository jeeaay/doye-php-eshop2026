/*
 * 商品详情页「配送至」区域选择器（免刷新）与默认地址推断
 *
 * 服务端已按 ?ship_to / ship_to cookie / 站点默认区域渲染首屏，并通过 data-* 下发：
 *   - data-eta-by-region      区域码 => 时效文案（规则只在 ShippingEtaService 计算）
 *   - data-region-by-country  国家码 => 区域码（把默认收货地址映射到区域）
 *
 * 本脚本只做两件事：
 *   1. 用户切换区域：查表更新 .product-eta，写 ship_to cookie，不提交表单、不改 URL；
 *   2. 无显式选择且已登录：用默认收货地址的国家校正选择器与文案，不写 cookie。
 *
 * data-* 缺失（如国内版）直接返回，不隐藏「应用」按钮，保留表单 GET 兜底。
 * 任何异常静默降级，保持服务端渲染结果。
 */
(function () {
  'use strict';

  var COOKIE_NAME = 'ship_to';
  var COOKIE_MAX_AGE = 31536000;
  var FALLBACK_REGION = 'other';

  /** cookie 里是否已有显式选择 */
  function hasShipToCookie() {
    var pairs = String(document.cookie || '').split(';');
    for (var i = 0; i < pairs.length; i++) {
      var pair = pairs[i];
      var eq = pair.indexOf('=');
      var name = (eq === -1 ? pair : pair.slice(0, eq)).replace(/^\s+|\s+$/g, '');
      if (name === COOKIE_NAME) { return true; }
    }
    return false;
  }

  /** 写 ship_to cookie（1 年、全站、SameSite=Lax） */
  function writeShipToCookie(region) {
    document.cookie = COOKIE_NAME + '=' + encodeURIComponent(region)
      + '; Max-Age=' + COOKIE_MAX_AGE
      + '; path=/'
      + '; SameSite=Lax';
  }

  /** URL 已带 ship_to（旧链接 / 无 JS 提交）时同步为新区域；不带则保持干净 URL */
  function syncUrlRegion(region) {
    try {
      if (!window.history || !window.history.replaceState || !window.URL) { return; }
      var url = new URL(window.location.href);
      if (!url.searchParams.has('ship_to')) { return; }
      url.searchParams.set('ship_to', region);
      window.history.replaceState(null, '', url.pathname + url.search + url.hash);
    } catch (e) { /* 静默：URL 不更新也不影响 cookie */ }
  }

  /** data-* 上的 JSON，解析失败返回 null */
  function readJSON(text) {
    if (!text) { return null; }
    try {
      var value = JSON.parse(text);
      return value && typeof value === 'object' ? value : null;
    } catch (e) {
      return null;
    }
  }

  /** 对象自有键取值，缺失返回空串（避免命中原型链） */
  function lookup(map, key) {
    if (!map || !key) { return ''; }
    return Object.prototype.hasOwnProperty.call(map, key) ? String(map[key]) : '';
  }

  /** 默认地址（无默认标记时取第一条） */
  function pickAddress(list) {
    if (!list || typeof list.length !== 'number' || !list.length) { return null; }
    for (var i = 0; i < list.length; i++) {
      if (list[i] && Number(list[i].is_default) === 1) { return list[i]; }
    }
    return list[0];
  }

  /** 与 select 选项对齐（该 option 不存在时保持原值） */
  function syncSelect(select, region) {
    if (!select || !region) { return; }
    var options = select.options || [];
    for (var i = 0; i < options.length; i++) {
      if (String(options[i].value) === String(region)) {
        select.value = region;
        return;
      }
    }
  }

  /** 更新时效文案（文案缺失时保持原值） */
  function applyRegionText(box, texts, region) {
    var text = lookup(texts, region);
    if (!text) { return; }
    var eta = box.querySelector('.product-eta');
    if (eta) { eta.textContent = text; }
  }

  function init() {
    var box = document.querySelector('.product-delivery-info');
    if (!box) { return; }

    var texts = readJSON(box.getAttribute('data-eta-by-region'));
    var regionByCountry = readJSON(box.getAttribute('data-region-by-country'));
    // 缺任一映射：不接管交互，「应用」按钮保持可见走表单提交
    if (!texts || !regionByCountry) { return; }

    var select = box.querySelector('select[name="ship_to"]');

    // 1) 免刷新切换：只更新文案 + cookie（URL 有 ship_to 时同步，保证刷新不回退）
    if (select) {
      select.addEventListener('change', function () {
        try {
          var region = String(select.value || '');
          if (!region) { return; }
          applyRegionText(box, texts, region);
          writeShipToCookie(region);
          syncUrlRegion(region);
        } catch (e) { /* 静默：保持服务端渲染结果 */ }
      });

      // 事件已接管：隐藏兜底提交按钮。.btn 的 display 会覆盖 [hidden]，必须用 style
      var applyButton = box.querySelector('[data-region-apply]');
      if (applyButton) { applyButton.style.display = 'none'; }
    }

    // 2) 默认地址推断：仅在没有显式选择且已登录时生效，不写 cookie
    if (!select || hasShipToCookie()) { return; }
    if (!window.StoreAuth || !window.StoreAuth.isLoggedIn()) { return; }
    if (!window.StoreAddress || typeof window.StoreAddress.list !== 'function') { return; }

    try {
      Promise.resolve(window.StoreAddress.list()).then(function (list) {
        try {
          var address = pickAddress(list);
          var country = address && address.country ? String(address.country).toUpperCase() : '';
          // 地址没有国家：保持服务端（站点默认区域）结果
          if (!country) { return; }
          var region = lookup(regionByCountry, country) || FALLBACK_REGION;
          syncSelect(select, region);
          applyRegionText(box, texts, region);
        } catch (e) { /* 静默：保持服务端渲染结果 */ }
      }, function () { /* 静默：接口失败不影响页面 */ });
    } catch (e) { /* 静默 */ }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
