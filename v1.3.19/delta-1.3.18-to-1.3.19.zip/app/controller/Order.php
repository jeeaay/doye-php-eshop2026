<?php
declare(strict_types=1);

namespace app\controller;

use app\common\lib\payment\PaymentChannelCatalog;
use app\common\model\OrderPay;

/**
 * 下单成功 / 支付回跳
 *
 * 原 Go 站点是 GET /order-success/:cart_id，服务端用 cart 数据渲染。
 * PHP 后台是 order_pay + 多个子订单模型，支付渠道（PayPal/Stripe…）回跳只带 pay_id，
 * 因此页面骨架固定，数据由 order_success 页面脚本通过 /api/payment/status、/api/order/list 拉取。
 */
class Order extends SiteBase
{
    public function successPage($id = 0)
    {
        $brand = $this->store->brand();
        // Stripe/PayPal/站内跳转的参数名不一致：统一收敛到 pay_id
        $payId = (int) ($this->request->get('pay_id', 0));
        if ($payId <= 0) {
            $payId = (int) ($this->request->get('order_pay_id', 0));
        }
        if ($payId <= 0) {
            $payId = (int) $id;
        }
        // PayPal approve 回跳只带 token（= PayPal 订单号）：反查到支付单后跳规范地址
        if ($payId <= 0) {
            $token = trim((string) ($this->request->get('token', '')));
            if ($token !== '') {
                $pay = OrderPay::where('channel', PaymentChannelCatalog::PAYPAL)
                    ->where('trade_no', $token)
                    ->find();
                if ($pay) {
                    return redirect('/order-success?pay_id=' . (int) $pay->id);
                }
            }
        }
        $orderId = (int) ($this->request->get('order_id', 0));

        return $this->render('order_success', [
            'nav_active' => '',
            'page_title' => 'Order Success - ' . $brand['name'] . $brand['suffix'],
            'pay_id'     => $payId,
            'order_id'   => $orderId,
        ]);
    }
}
